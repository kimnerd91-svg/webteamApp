<?php
include_once('./_auth_check.php');
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>병원 관리자</title>
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Pretendard', 'Apple SD Gothic Neo', sans-serif; background: #f5f6fa; color: #1a1a2e; min-height: 100vh; }
        .wrap { max-width: 720px; margin: 0 auto; padding: 64px 24px; }
        .hello { font-size: 13px; color: #16a34a; font-weight: 700; margin-bottom: 8px; }
        h1 { font-size: 26px; font-weight: 800; margin-bottom: 6px; }
        .sub { color: #9999bb; font-size: 14px; margin-bottom: 32px; }
        .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 14px; }
        .menu_card { background: #fff; border: 1px solid #e8eaf0; border-radius: 14px; padding: 24px 20px; text-decoration: none; color: #1a1a2e; transition: box-shadow .15s, transform .05s; display: block; }
        .menu_card:hover { box-shadow: 0 6px 20px rgba(0,0,0,.08); transform: translateY(-2px); }
        .menu_card .ico { font-size: 28px; margin-bottom: 12px; }
        .menu_card .t { font-size: 16px; font-weight: 700; margin-bottom: 4px; }
        .menu_card .d { font-size: 12px; color: #9999bb; }
        .logout { display: inline-block; margin-top: 30px; color: #9999bb; font-size: 13px; text-decoration: underline; }
    </style>
</head>
<body>
    <div class="wrap">
        <p class="hello">CLINIC ADMIN</p>
        <h1><?= htmlspecialchars($member['mb_name']) ?>님, 환영합니다</h1>
        <p class="sub">병원 관리자 페이지입니다. <?= $CLINIC_IS_SUPER ? '(최고관리자 모드)' : '' ?></p>

        <div class="grid">
            <a class="menu_card" href="/clinic/qa_manager.php">
                <div class="ico">💬</div><div class="t">문의 관리</div><div class="d">상담 접수·상태·메모</div>
            </a>
            <a class="menu_card" href="/clinic/column_admin.php">
                <div class="ico">📝</div><div class="t">칼럼 관리</div><div class="d">닥터칼럼 작성·수정</div>
            </a>
            <a class="menu_card" href="/clinic/before_after_manager.php">
                <div class="ico">🦷</div><div class="t">임상증례</div><div class="d">전후 케이스 등록</div>
            </a>
            <a class="menu_card" href="/clinic/non_covered_manager.php">
                <div class="ico">💰</div><div class="t">비급여 수가표</div><div class="d">가격표 관리</div>
            </a>
            <a class="menu_card" href="/clinic/popup_manager.php">
                <div class="ico">🔔</div><div class="t">팝업 관리</div><div class="d">사이트 팝업</div>
            </a>
        </div>

        <a class="logout" href="/newadm/auth/logout.php">로그아웃</a>
    </div>
</body>
</html>
