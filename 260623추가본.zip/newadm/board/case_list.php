<?php
chdir(dirname(__FILE__) . '/../..');
include_once('./_common.php');

// ============================================================
// 안전 SQL 함수
// ============================================================
function safe_sql_query($query)
{
    if (function_exists('sql_query')) return sql_query($query);
    return false;
}
function safe_sql_fetch_array($result)
{
    if (function_exists('sql_fetch_array')) return sql_fetch_array($result);
    return false;
}

// ============================================================
// AJAX 추가 로드 처리
// ============================================================
if (isset($_GET['ajax_load'])) {
    $offset   = (int)$_GET['offset'];
    $tab      = $_GET['tab'] ?? 'all';
    $limit    = 12;

    if ($tab === 'all') {
        $result = sql_query("SELECT * FROM dm_case WHERE is_visible = 1 ORDER BY case_date DESC, id DESC LIMIT {$limit} OFFSET {$offset}");
    } else {
        $cat_map = [
            'implant'  => '임플란트',
            'denture'  => '틀니',
            'cosmetic' => '심미치료',
            'general'  => '일반진료',
            'nerve'    => '신경치료',
        ];
        $cat_name = sql_real_escape_string($cat_map[$tab] ?? '');
        $result   = sql_query("SELECT * FROM dm_case WHERE is_visible = 1 AND category = '{$cat_name}' ORDER BY case_date DESC, id DESC LIMIT {$limit} OFFSET {$offset}");
    }

    $items = [];
    if ($result) while ($row = sql_fetch_array($result)) $items[] = $row;

    header('Content-Type: application/json');
    echo json_encode([
        'items'    => $items,
        'has_more' => count($items) === $limit,
    ]);
    exit;
}

// ============================================================
// 카테고리 → tab id 매핑
// ============================================================
$cat_map = [
    '임플란트' => 'implant',
    '틀니'     => 'denture',
    '심미치료' => 'cosmetic',
    '일반진료' => 'general',
    '신경치료' => 'nerve',
];

// ============================================================
// 초기 12개 + 탭별 카운트
// ============================================================

// 전체 탭 초기 12개
$r_all    = safe_sql_query("SELECT * FROM dm_case WHERE is_visible = 1 ORDER BY case_date DESC, id DESC LIMIT 12");
$case_all = [];
if ($r_all) while ($row = safe_sql_fetch_array($r_all)) $case_all[] = $row;

$total_all = (int)(sql_fetch("SELECT COUNT(*) as cnt FROM dm_case WHERE is_visible = 1")['cnt'] ?? 0);

// 탭별 초기 12개 + 카운트
$case_tabs  = [];
$tab_counts = [];
foreach ($cat_map as $cat_name => $tab_id) {
    $esc = sql_real_escape_string($cat_name);
    $r   = safe_sql_query("SELECT * FROM dm_case WHERE is_visible = 1 AND category = '{$esc}' ORDER BY case_date DESC, id DESC LIMIT 12");
    $case_tabs[$tab_id] = [];
    if ($r) while ($row = safe_sql_fetch_array($r)) $case_tabs[$tab_id][] = $row;
    $cnt_row = sql_fetch("SELECT COUNT(*) as cnt FROM dm_case WHERE is_visible = 1 AND category = '{$esc}'");
    $tab_counts[$tab_id] = (int)($cnt_row['cnt'] ?? 0);
}

// 로그인 여부
$is_logged_in = !empty($member['mb_id']);

// ============================================================
// 렌더 함수
// ============================================================
function render_case_card($case, $is_logged_in)
{
    $id    = (int)$case['id'];
    $title = htmlspecialchars($case['title'] ?? '');
    $date  = $case['case_date'] ? date('Y.m.d', strtotime($case['case_date'])) : '';
    $thumb = '/images/imsang.png';
    if (!empty($case['content'])) {
        $content_clean = stripslashes($case['content']);
        if (preg_match('/<img[^>]+src=["\']([^"\']+)["\'][^>]*>/i', $content_clean, $m)) {
            $thumb = htmlspecialchars($m[1]);
        }
    }
    $overlay_style = $is_logged_in ? ' style="display:none;"' : '';
    ob_start();
?>
    <a href="/sub/board/case_review.php?id=<?= $id ?>" class="box d-block text-decoration-none"
        data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
        <div class="imgBox position-relative u-round-30">
            <img class="w-100" src="<?= $thumb ?>" alt="<?= $title ?>" />
            <div class="overlay u-round-20 w-100 h-100 position-absolute d-flex justify-content-center align-items-center flex-column"
                style="top:0;left:0;background-color:rgba(0,0,0,0.8);"
                <?= $overlay_style ?>>
                <h6 class="u-txt-white t-fs-14 u-lh-18 fw-bold">전, 후 케이스는 로그인 후 확인 가능합니다.</h6>
                <p class="c-fs-8 u-lh-15 fw-300 u-txt-gray-500">
                    ※ 서울다온치과는 의료법을 준수하며 해당 게시물은<br />
                    의료법 제56조에 의거하여 로그인 후 열람이 가능합니다.
                </p>
            </div>
        </div>
        <div class="titleBox u-p-30">
            <h5 class="u-txt-black fw-500 t-fs-20 u-lh-16 u-ls-10 u-mb-8"><?= $title ?></h5>
            <p class="u-txt-gray-700 c-fs-18 fw-400 u-lh-16 u-ls-10"><?= $date ?></p>
        </div>
    </a>
<?php
    return ob_get_clean();
}

function render_empty_tab() {
    return '<div class="review-empty-tab w-100" style="min-height:300px; display:flex; justify-content:center; align-items:center;">
        <p class="u-txt-gray-500 c-fs-20 fw-400">작성된 증례가 없습니다.</p>
    </div>';
}

include_once(G5_PATH . '/head_sub.php');
include_once(G5_PATH . '/head.php');
?>

<main class="u-pretendard case_list" data-aos="fade-up" data-aos-duration="1000">
    <div class="intro d-flex justify-content-center align-items-center flex-column u-gap-20 position-relative u-mt-80 u-mt-20-sm">
        <h6 class="t-fs-20 fw-700 u-lh-14 u-ls-10 u-txt-white" style="text-transform: uppercase;">Dentist Story</h6>
        <h2 class="t-fs-46 t-fs-32-sm fw-700 u-lh-14 u-ls-15 u-txt-white text-center u-mb-40">치과진료에 대한 다양한<br>궁금증과 치료 연구를 위한 증례 이야기</h2>
        <p class="d-none d-md-block position-absolute c-fs-14 fw-300 u-lh-16 text-center u-txt-white u-px-30 u-py-20 u-round-10 w-nowrap" style="background-color: rgba(255,255,255,0.3); bottom: 80px;">
            *본 컬럼은 56조 제 1항의 의료법을 준수하여 작성되었으며 실제 내원 환자분의 동의하에 공개된 치료과정의 사진이 포함되어 있습니다.<br>
            개인에 따라 진료 및 치료방법이 다르게 적용될 수 있으며, 효과와 부작용이 다르게 나타날수 있는점을 안내 드립니다.
        </p>
    </div>
     <!-- <ul class="u-fluid u-fluid-xl-sm mx-auto d-flex flex-wrap flex-lg-nowrap tabs">
        <li class="col-4 col-lg-2 text-center u-bb-1 u-solid">
            <a href="/sub/introduce.php" class="c-fs-18 u-lh-16 u-py-10 u-px-30 d-flex align-items-center justify-content-center w-100 h-100 u-ls-10">진료 철학</a>
        </li>
        <li class="col-4 col-lg-2 text-center u-bb-1 u-solid">
            <a href="/sub/doctors.php" class="c-fs-18 u-lh-16 u-py-10 u-px-30 d-flex align-items-center justify-content-center w-100 h-100 u-ls-10 d-block">의료진 소개</a>
        </li>
        <li class="col-4 col-lg-2 text-center u-bb-1 u-solid">
            <a href="/sub/device.php" class="c-fs-18 u-lh-16 u-py-10 u-px-30 d-flex align-items-center justify-content-center w-100 h-100 u-ls-10 d-block">장비소개</a>
        </li>
        <li class="col-4 col-lg-2 text-center u-bb-1 u-solid">
            <a href="/sub/info.php" class="c-fs-18 u-lh-16 u-py-10 u-px-30 d-flex align-items-center justify-content-center w-100 h-100 u-ls-10 d-block">오시는 길</a>
        </li>
        <li class="col-4 col-lg-2 text-center u-bb-1 u-solid active">
            <a href="/sub/board/case_list.php" class="c-fs-18 u-lh-16 u-py-10 u-px-30 d-flex align-items-center justify-content-center w-100 h-100 u-ls-10 d-block u-txt-sub">임상증례</a>
        </li>
        <li class="col-4 col-lg-2 text-center u-bb-1 u-solid ">
            <a href="/sub/column_list.php" class="c-fs-18 u-lh-16 u-py-10 u-px-30 d-flex align-items-center justify-content-center w-100 h-100 u-ls-10 d-block ">원장님 칼럼</a>
        </li>
    </ul> -->
    <section id="sect01" class="u-py-150">
        <div class="u-fluid u-fluid-xl-sm">

            <!-- 탭 버튼 -->
            <div class="tabs w-100 mx-auto u-mb-100" data-aos="fade-up" data-aos-duration="1000">
                <ul class="w-100 g-cols-fit-12 g-flex-3 u-gap-20 mx-auto"
                    data-aos="fade-up" data-aos-delay="500" data-aos-duration="1000">
                    <li>
                        <button type="button" class="review-tab-btn flex-1 u-b-solid u-bd-1 u-bc-gray-300 u-round-full c-fs-18 fw-500 u-lh-16 u-ls-15 w-100 u-txt-gray-500 u-py-16 active"
                            data-tab="all">전체</button>
                    </li>
                    <li>
                        <button type="button" class="review-tab-btn flex-1 u-b-solid u-bd-1 u-bc-gray-300 u-round-full c-fs-18 fw-500 u-lh-16 u-ls-15 w-100 u-txt-gray-500 u-py-16"
                            data-tab="implant">임플란트</button>
                    </li>
                    <li>
                        <button type="button" class="review-tab-btn flex-1 u-b-solid u-bd-1 u-bc-gray-300 u-round-full c-fs-18 fw-500 u-lh-16 u-ls-15 w-100 u-txt-gray-500 u-py-16"
                            data-tab="denture">틀니</button>
                    </li>
                    <li>
                        <button type="button" class="review-tab-btn flex-1 u-b-solid u-bd-1 u-bc-gray-300 u-round-full c-fs-18 fw-500 u-lh-16 u-ls-15 w-100 u-txt-gray-500 u-py-16"
                            data-tab="cosmetic">심미보철</button>
                    </li>
                    <li>
                        <button type="button" class="review-tab-btn flex-1 u-b-solid u-bd-1 u-bc-gray-300 u-round-full c-fs-18 fw-500 u-lh-16 u-ls-15 w-100 u-txt-gray-500 u-py-16"
                            data-tab="general">일반진료</button>
                    </li>
                    <li>
                        <button type="button" class="review-tab-btn flex-1 u-b-solid u-bd-1 u-bc-gray-300 u-round-full c-fs-18 fw-500 u-lh-16 u-ls-15 w-100 u-txt-gray-500 u-py-16"
                            data-tab="nerve">신경치료</button>
                    </li>
                </ul>
            </div>

            <!-- 탭 컨테이너 -->
            <div class="tab-container u-mb-60" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">

                <?php
                // tab_id => [초기데이터, 전체카운트]
                $tab_configs = [
                    'all'      => [$case_all,              $total_all],
                    'implant'  => [$case_tabs['implant'],  $tab_counts['implant']],
                    'denture'  => [$case_tabs['denture'],  $tab_counts['denture']],
                    'cosmetic' => [$case_tabs['cosmetic'], $tab_counts['cosmetic']],
                    'general'  => [$case_tabs['general'],  $tab_counts['general']],
                    'nerve'    => [$case_tabs['nerve'],    $tab_counts['nerve']],
                ];
                $first = true;
                foreach ($tab_configs as $tab_id => [$data, $total]):
                    $has_more = $total > 12;
                    $active   = $first ? ' active' : '';
                    $first    = false;
                ?>
                    <div class="review-tab-contents g-cols-fit-12 g-flexble-2 u-gap-24<?= $active ?>" id="tab-<?= $tab_id ?>">
                        <?php if (!empty($data)):
                            foreach ($data as $cs) echo render_case_card($cs, $is_logged_in);
                        else: echo render_empty_tab();
                        endif; ?>
                    </div>
                    <?php if ($has_more): ?>
                        <div id="lazyTrigger-<?= $tab_id ?>" class="lazy-trigger" data-tab="<?= $tab_id ?>" style="height:1px; margin-top:60px;"></div>
                        <div id="loadingSpinner-<?= $tab_id ?>" class="lazy-spinner text-center u-py-40" style="display:none;">
                            <div class="spinner-border" style="color:var(--sub-color);" role="status"></div>
                            <p class="u-txt-gray-500 c-fs-16 u-mt-12">불러오는 중...</p>
                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>

            </div>
        </div>
    </section>
</main>
<script>
(function () {
    'use strict';

    const IS_LOGGED_IN = <?= $is_logged_in ? 'true' : 'false' ?>;
    const LAZY_URL     = '/sub/case_review_page.php';

    const tabBtns     = document.querySelectorAll('#sect01 .review-tab-btn');
    const tabContents = document.querySelectorAll('#sect01 .review-tab-contents');

    const state = {
        all:      { offset: 12, loading: false, done: false },
        implant:  { offset: 12, loading: false, done: false },
        denture:  { offset: 12, loading: false, done: false },
        cosmetic: { offset: 12, loading: false, done: false },
        general:  { offset: 12, loading: false, done: false },
        nerve:    { offset: 12, loading: false, done: false },
    };

    let currentTab = 'all';

    // 초기 상태 — 첫 탭만 표시
    tabContents.forEach((c, i) => {
        const isEmpty = c.querySelector('.review-empty-tab');
        c.style.display = i === 0 ? (isEmpty ? 'flex' : 'grid') : 'none';
    });

    // 탭 전환
    tabBtns.forEach(btn => {
        btn.addEventListener('click', function () {
            tabBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');

            tabContents.forEach(c => { c.style.display = 'none'; });
            currentTab = this.dataset.tab;

            const target = document.getElementById('tab-' + currentTab);
            if (target) {
                const isEmpty = target.querySelector('.review-empty-tab');
                target.style.display = isEmpty ? 'flex' : 'grid';
            }
        });
    });

    // 이스케이프
    function esc(str) {
        return String(str || '')
            .replace(/&/g, '&amp;').replace(/</g, '&lt;')
            .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    // 카드 렌더
    function renderCard(rv) {
        const id    = rv.id;
        const title = esc(rv.title || '');
        const date  = rv.case_date ? rv.case_date.substr(0, 10).replace(/-/g, '.') : '';
        let thumb   = '/images/imsang.png';
        if (rv.content) {
            const m = rv.content.match(/<img[^>]+src=["']([^"']+)["'][^>]*>/i);
            if (m) thumb = esc(m[1]);
        }
        const overlay = IS_LOGGED_IN ? 'style="display:none;"' : '';
        return `<a href="/sub/board/case_review.php?id=${id}" class="box d-block text-decoration-none">
            <div class="imgBox position-relative u-round-30">
                <img class="w-100" src="${thumb}" alt="${title}">
                <div class="overlay u-round-20 w-100 h-100 position-absolute d-flex justify-content-center align-items-center flex-column"
                    style="top:0;left:0;background-color:rgba(0,0,0,0.8);" ${overlay}>
                    <h6 class="u-txt-white t-fs-14 u-lh-18 fw-bold">전, 후 케이스는 로그인 후 확인 가능합니다.</h6>
                    <p class="c-fs-8 u-lh-15 fw-300 u-txt-gray-500">
                        ※ 서울다온치과는 의료법을 준수하며 해당 게시물은<br>
                        의료법 제56조에 의거하여 로그인 후 열람이 가능합니다.
                    </p>
                </div>
            </div>
            <div class="titleBox u-p-30">
                <h5 class="u-txt-black fw-500 t-fs-20 u-lh-16 u-ls-10 u-mb-8">${title}</h5>
                <p class="u-txt-gray-700 c-fs-18 fw-400 u-lh-16 u-ls-10">${date}</p>
            </div>
        </a>`;
    }

    // 레이지로딩
    function loadMore(tab) {
        const s = state[tab];
        if (s.loading || s.done) return;
        s.loading = true;

        const spinner = document.getElementById('loadingSpinner-' + tab);
        if (spinner) spinner.style.display = 'block';

        fetch(`${LAZY_URL}?ajax_load=1&tab=${tab}&offset=${s.offset}`)
            .then(r => r.json())
            .then(data => {
                if (spinner) spinner.style.display = 'none';
                s.loading = false;

                const grid = document.getElementById('tab-' + tab);

                if (data.items.length > 0) {
                    const emptyEl = grid.querySelector('.review-empty-tab');
                    if (emptyEl) {
                        emptyEl.remove();
                        grid.style.display = 'grid';
                    }
                }

                data.items.forEach(rv => grid.insertAdjacentHTML('beforeend', renderCard(rv)));
                s.offset += data.items.length;

                if (!data.has_more) {
                    s.done = true;
                    const trigger = document.getElementById('lazyTrigger-' + tab);
                    if (trigger) trigger.remove();
                }
            })
            .catch(() => {
                if (spinner) spinner.style.display = 'none';
                s.loading = false;
            });
    }

    // IntersectionObserver
    document.querySelectorAll('#sect01 .lazy-trigger').forEach(trigger => {
        const tab = trigger.dataset.tab;
        new IntersectionObserver(entries => {
            if (entries[0].isIntersecting) loadMore(tab);
        }, { rootMargin: '200px' }).observe(trigger);
    });

})();
</script>

<?php include_once(G5_PATH . '/tail.php'); ?>
