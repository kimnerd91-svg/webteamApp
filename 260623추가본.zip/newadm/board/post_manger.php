<?php
include_once('./_common.php');
include_once('./_auth_check.php');
if (file_exists(G5_LIB_PATH.'/thumbnail.lib.php')) {
    include_once(G5_LIB_PATH.'/thumbnail.lib.php');
}

// 모든 게시판 UNION 쿼리
$sql_bo = " SELECT bo_table, bo_subject FROM {$g5['board_table']} ORDER BY bo_table ASC ";
$res_bo = sql_query($sql_bo);
$union_queries = array();
while ($bo = sql_fetch_array($res_bo)) {
    $tmp_write_table = $g5['write_prefix'] . $bo['bo_table'];
    $check = sql_query(" SHOW TABLES LIKE '$tmp_write_table' ");
    if (sql_num_rows($check) > 0) {
        $union_queries[] = " SELECT '{$bo['bo_table']}' as bo_table, '{$bo['bo_subject']}' as bo_subject, wr_id, wr_subject, wr_name, wr_datetime, wr_option FROM $tmp_write_table WHERE wr_is_comment = 0 ";
    }
}

$total_count = 0;
$result = null;
if (!empty($union_queries)) {
    $full_union_sql = implode(" UNION ALL ", $union_queries);
    $total_res = sql_fetch(" SELECT count(*) as cnt FROM ($full_union_sql) as t ");
    $total_count = (int)$total_res['cnt'];
    $rows = 12;
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    if ($page < 1) $page = 1;
    $total_page  = ceil($total_count / $rows);
    $from_record = ($page - 1) * $rows;
    $sql = " SELECT * FROM ($full_union_sql) as t ORDER BY wr_datetime DESC LIMIT $from_record, $rows ";
    $result = sql_query($sql);
}
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>게시물 통합 관리</title>
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Pretendard', 'Apple SD Gothic Neo', sans-serif; background: #f5f6fa; color: #1a1a2e; }
        #admin_wrapper { display: flex; min-height: 100vh; }
        .content_area { flex: 1; padding: 40px; overflow-x: hidden; }

        /* 헤더 */
        .page_header { display: flex; align-items: baseline; gap: 12px; margin-bottom: 28px; }
        .page_title { font-size: 22px; font-weight: 700; color: #1a1a2e; }
        .total_count { font-size: 14px; color: #9999bb; font-weight: 400; }

        /* 그리드 */
        .post_grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 20px; margin-bottom: 40px; }

        .post_card {
            background: #fff; border-radius: 12px; border: 1px solid #e8eaf0;
            box-shadow: 0 2px 12px rgba(0,0,0,0.06); overflow: hidden;
            display: flex; flex-direction: column; transition: all 0.2s;
        }
        .post_card:hover { transform: translateY(-3px); box-shadow: 0 8px 24px rgba(0,0,0,0.1); }

        .thumb_wrap { aspect-ratio: 16/9; overflow: hidden; background: #f5f6fa; }
        .thumb_wrap img { width: 100%; height: 100%; object-fit: cover; display: block; }

        .post_body { padding: 18px; flex: 1; display: flex; flex-direction: column; gap: 6px; }

        .post_board_badge {
            display: inline-block; padding: 3px 10px; background: #ede9fe;
            color: #4f46e5; border-radius: 20px; font-size: 11px; font-weight: 700;
            width: fit-content;
        }
        .post_date { font-size: 12px; color: #9999bb; margin-left: auto; white-space: nowrap; }
        .post_badge_row { display: flex; align-items: center; gap: 8px; }

        .post_title {
            font-size: 15px; font-weight: 700; color: #1a1a2e; line-height: 1.4;
            display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;
            text-decoration: none;
        }
        .post_title:hover { color: #4f46e5; }

        .post_author { font-size: 12px; color: #9999bb; }

        .post_actions { display: flex; gap: 8px; margin-top: auto; padding-top: 12px; }
        .btn_view, .btn_edit, .btn_del {
            flex: 1; text-align: center; padding: 8px; border-radius: 7px;
            font-size: 13px; font-weight: 700; text-decoration: none; transition: all 0.2s;
            border: none; cursor: pointer;
        }
        .btn_view { background: #f5f6fa; color: #444466; border: 1px solid #e8eaf0; }
        .btn_view:hover { background: #e8eaf0; }
        .btn_edit { background: #4f46e5; color: #fff; }
        .btn_edit:hover { background: #4338ca; }
        .btn_del { background: #fee2e2; color: #dc2626; flex: 0; padding: 8px 12px; }
        .btn_del:hover { background: #fecaca; }

        /* 빈 상태 */
        .empty_card {
            background: #fff; border-radius: 12px; border: 1px solid #e8eaf0;
            padding: 80px 20px; text-align: center; color: #9999bb; font-size: 14px;
        }

        /* 페이지네이션 */
        .pagination { display: flex; justify-content: center; gap: 6px; }
        .pagination a {
            display: inline-flex; align-items: center; justify-content: center;
            width: 36px; height: 36px; border-radius: 8px; font-size: 13px; font-weight: 600;
            text-decoration: none; color: #5c5c7a; background: #fff;
            border: 1px solid #e8eaf0; transition: all 0.2s;
        }
        .pagination a:hover { background: #ede9fe; color: #4f46e5; border-color: #c4b5fd; }
        .pagination a.active { background: #4f46e5; color: #fff; border-color: #4f46e5; }
    </style>
</head>
<body>
<div id="admin_wrapper">
    <?php include_once('./aside.php'); ?>

    <main class="content_area">

        <div class="page_header">
            <h2 class="page_title">게시물 통합 관리</h2>
            <span class="total_count">총 <?= number_format($total_count) ?>개</span>
        </div>

        <?php if ($result && $total_count > 0): ?>
        <div class="post_grid">
            <?php while ($row = sql_fetch_array($result)): 
                $post_url = G5_BBS_URL."/board.php?bo_table=".$row['bo_table']."&wr_id=".$row['wr_id'];
                $edit_url = G5_BBS_URL."/write.php?w=u&bo_table=".$row['bo_table']."&wr_id=".$row['wr_id'];
                $img_src = 'https://via.placeholder.com/400x225/f5f6fa/9999bb?text=No+Image';
                if (function_exists('get_list_thumbnail')) {
                    $thumb = get_list_thumbnail($row['bo_table'], $row['wr_id'], 400, 225, false, true);
                    if (isset($thumb['src']) && $thumb['src']) $img_src = $thumb['src'];
                }
            ?>
            <div class="post_card">
                <a href="<?= $post_url ?>" target="_blank" class="thumb_wrap">
                    <img src="<?= $img_src ?>" alt="썸네일" loading="lazy">
                </a>
                <div class="post_body">
                    <div class="post_badge_row">
                        <span class="post_board_badge"><?= htmlspecialchars($row['bo_subject']) ?></span>
                        <span class="post_date"><?= substr($row['wr_datetime'], 2, 8) ?></span>
                    </div>
                    <a href="<?= $post_url ?>" target="_blank" class="post_title">
                        <?= htmlspecialchars($row['wr_subject']) ?>
                    </a>
                    <span class="post_author"><?= htmlspecialchars($row['wr_name']) ?></span>
                    <div class="post_actions">
                        <a href="<?= $post_url ?>" target="_blank" class="btn_view">보기</a>
                        <a href="<?= $edit_url ?>" class="btn_edit">수정</a>
                        <button onclick="delete_post('<?= $row['bo_table'] ?>', '<?= $row['wr_id'] ?>')" class="btn_del">✕</button>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>

        <div class="pagination">
            <?php for ($p = 1; $p <= $total_page; $p++): ?>
            <a href="?page=<?= $p ?>" class="<?= ($p == $page) ? 'active' : '' ?>"><?= $p ?></a>
            <?php endfor; ?>
        </div>

        <?php else: ?>
        <div class="empty_card">데이터가 없습니다.</div>
        <?php endif; ?>

    </main>
</div>

<script>
function delete_post(bo_table, wr_id) {
    if (confirm('정말 이 게시물을 삭제하시겠습니까?')) {
        location.href = "./board_list.php?bo_table=" + bo_table + "&delete_wr_id=" + wr_id;
    }
}
</script>
</body>
</html>