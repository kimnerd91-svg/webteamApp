<?php
chdir(dirname(__FILE__) . '/../..');
include_once('./_common.php');

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if (!$id) {
    header('Location: /');
    exit;
}

// view_count 컬럼 없으면 자동 추가
$chk = sql_query("SHOW COLUMNS FROM `dm_case` LIKE 'view_count'");
if (sql_num_rows($chk) == 0) {
    sql_query("ALTER TABLE `dm_case` ADD COLUMN `view_count` INT(11) DEFAULT 0 AFTER `is_visible`");
}

$case = sql_fetch("SELECT * FROM dm_case WHERE id = {$id} AND is_visible = 1");
if (!$case) {
    header('Location: /');
    exit;
}

// ============================================================
// 간편 가입 처리
// ============================================================
$quick_join_error = '';
if (isset($_POST['quick_join'])) {
    $new_id = preg_replace('/[^a-zA-Z0-9_]/', '', trim($_POST['new_mb_id']));
    $new_hp = preg_replace('/[^0-9]/', '', trim($_POST['new_mb_hp']));

    if (strlen($new_id) < 3) {
        $quick_join_error = '아이디는 3자 이상 영문/숫자로 입력해주세요.';
    } elseif (strlen($new_hp) < 10) {
        $quick_join_error = '올바른 휴대폰 번호를 입력해주세요.';
    } else {
        // 중복 체크
        $dup = sql_fetch("SELECT mb_id FROM {$g5['member_table']} WHERE mb_id = '{$new_id}'");
        if ($dup) {
            $quick_join_error = '이미 사용 중인 아이디입니다.';
        } else {
            // 임시 비밀번호 자동 생성
            $tmp_pw  = substr(md5(uniqid(rand(), true)), 0, 10);
            $enc_pw  = get_encrypt_string($tmp_pw);
            $now     = G5_TIME_YMDHIS;
            $ip      = $_SERVER['REMOTE_ADDR'];
            $hp_esc  = sql_real_escape_string($new_hp);

            sql_query("INSERT INTO {$g5['member_table']}
                SET mb_id             = '{$new_id}',
                    mb_password       = '{$enc_pw}',
                    mb_name           = '{$new_id}',
                    mb_hp             = '{$hp_esc}',
                    mb_email          = '',
                    mb_level          = 1,
                    mb_datetime       = '{$now}',
                    mb_email_certify  = '{$now}',
                    mb_certify        = 'hp',
                    mb_login_ip       = '{$ip}'");

            // 그누보드 세션으로 자동 로그인
            $new_mb = sql_fetch("SELECT * FROM {$g5['member_table']} WHERE mb_id = '{$new_id}'");
            $mb_key = md5($new_mb['mb_password'] . $_SERVER['REMOTE_ADDR'] . $new_mb['mb_datetime']);

            echo '<!DOCTYPE html><html><body>
<form id="auto_login" method="post" action="' . G5_BBS_URL . '/login_check.php">
    <input type="hidden" name="mb_id" value="' . htmlspecialchars($new_id) . '">
    <input type="hidden" name="mb_password" value="' . htmlspecialchars($tmp_pw) . '">
    <input type="hidden" name="url" value="/sub/board/case_review.php?id=' . $id . '">
</form>
<script>document.getElementById("auto_login").submit();</script>
</body></html>';
            exit;
        }
    }
}

// 조회수 증가 (세션 중복 방지)
if (empty($_SESSION['viewed_case_' . $id])) {
    sql_query("UPDATE dm_case SET view_count = view_count + 1 WHERE id = {$id}");
    $_SESSION['viewed_case_' . $id] = true;
    $case['view_count'] = (int)$case['view_count'] + 1;
}

$is_logged_in = !empty($member['mb_id']);

$prev = sql_fetch("SELECT id, title FROM dm_case WHERE is_visible = 1 AND id > {$id} ORDER BY id ASC LIMIT 1");
$next = sql_fetch("SELECT id, title FROM dm_case WHERE is_visible = 1 AND id < {$id} ORDER BY id DESC LIMIT 1");

$date  = $case['case_date'] ? date('Y.m.d', strtotime($case['case_date'])) : '';
$files = [];

include_once(G5_PATH . '/head_sub.php');
include_once(G5_PATH . '/head.php');
?>

<main class="u-pretendard case_review">
    <div class="intro d-flex justify-content-center align-items-center flex-column u-gap-20">
        <h6 class="t-fs-20 fw-700 u-lh-14 u-ls-10 u-txt-white"><?= htmlspecialchars($cf_site_name) ?> 소개</h6>
        <h2 class="t-fs-46 fw-700 u-lh-14 u-ls-15 u-txt-white">치료사례</h2>
        <p class="c-fs-22 fw-400 u-lh-16 u-ls-10 text-center u-txt-gray-300 u-mt-10">치과진료에 대한 다양한 궁금증과 치료 연구를 위한 증례 이야기</p>
    </div>
    <div class="content u-py-120 u-1440">
        <div class="u-bt-1 u-bb-1 u-solid u-bc-dark">

            <div class="content_head text-start u-py-30 u-px-20">
                <span class="c-fs-16 fw-500 u-lh-15 u-ls-10 u-txt-sub">
                    <?php echo htmlspecialchars($case['category'] ?? ''); ?>
                </span>
                <h5 class="t-fs-28 fw-500 u-lh-14 u-ls-10 u-txt-dark u-mb-16">
                    <?php echo htmlspecialchars($case['title'] ?? ''); ?>
                </h5>
                <div class="d-flex justify-content-between align-items-center">
                    <div class="d-flex u-gap-20">
                        <span class="d-flex u-gap-4 u-txt-gray-500 c-fs-16 fw-400 u-lh-15 u-ls-10">
                            <strong class="t-fs-16 fw-500 u-lh-15 u-ls-10 u-txt-dark">작성자</strong>
                            관리자
                        </span>
                        <span>|</span>
                        <span class="d-flex u-gap-4 u-txt-gray-500 c-fs-16 fw-400 u-lh-15 u-ls-10">
                            <strong class="t-fs-16 fw-500 u-lh-15 u-ls-10 u-txt-dark">조회</strong>
                            <?php echo number_format((int)$case['view_count']); ?>
                        </span>
                    </div>
                    <div>
                        <p class="c-fs-16 u-txt-gray-500 fw-400 u-lh-15"><?php echo $date; ?></p>
                    </div>
                </div>
            </div>

            <div class="content_body u-py-120 text-center u-bt-1 u-bc-gray-200 u-solid">
                <?php if (!$is_logged_in): ?>
                    <div class="vh-100">
                        <div style="filter:blur(8px);user-select:none;pointer-events:none;">
                            <?php echo $case['content']; ?>
                        </div>
                        <div class="position-fixed d-flex flex-column justify-content-center align-items-center u-gap-24 u-p-32" style="inset:0;background:rgba(0,0,0,0.82);z-index:999;">
                            <div class="u-bg-light w-max w-100-sm text-center u-p-40 u-round-20 shadow-soft">
                                <h6 class="u-txt-dark t-fs-28 fw-700 u-mb-20 u-lh-14 u-ls-10">
                                    전, 후 케이스 열람을 위해 <br>
                                    <span class="u-txt-sub" style="text-decoration: underline!important;">임시 아이디</span>를 발급받으세요
                                </h6>
                                <p class="u-txt-gray-600 fw-400 c-fs-14 u-lh-15 u-ls-10 u-mb-30 text-center">
                                    ※ <?= htmlspecialchars($cf_site_name) ?>는 의료법을 준수하며 해당 게시물은<br>
                                    의료법 제56조에 의거하여 로그인 후 열람이 가능합니다.
                                </p>

                                <?php if ($quick_join_error): ?>
                                    <div style="background:#ef4444;color:#fff;padding:10px 16px;border-radius:8px;font-size:13px;margin-bottom:16px;">
                                        <?php echo htmlspecialchars($quick_join_error); ?>
                                    </div>
                                <?php endif; ?>

                                <form method="post" action="/sub/board/case_review.php?id=<?php echo $id; ?>"
                                    class="d-flex flex-column u-gap-20;">
                                    <input type="hidden" name="quick_join" value="1">
                                    <input type="text" name="new_mb_id"
                                        placeholder="사용할 아이디 (영문/숫자 3자 이상)"
                                        value="<?php echo htmlspecialchars($_POST['new_mb_id'] ?? ''); ?>"
                                        class="u-txt-gray-400 u-py-10 u-px-18 u-round-10 u-lh-16 u-ls-10 u-bg-white u-bd-1 u-solid u-bc-gray-400 c-fs-16 w-100 u-mb-10"
                                        style="box-sizing:border-box;"
                                        required>
                                    <input type="tel" name="new_mb_hp"
                                        placeholder="휴대폰 번호 (- 없이 입력)"
                                        value="<?php echo htmlspecialchars($_POST['new_mb_hp'] ?? ''); ?>"
                                        class="u-txt-gray-400 u-py-10 u-px-18 u-round-10 u-lh-16 u-ls-10 u-bg-white u-bd-1 u-solid u-bc-gray-400 c-fs-16 w-100"
                                        style="box-sizing:border-box;"
                                        required>
                                    <button type="submit"
                                        class="u-px-30 u-py-16 u-round-full u-bd-n u-bg-main t-fs-20 u-lh-15 u-ls-10 u-txt-white fw-700 cursor-pointer w-100 u-mt-30">
                                        임시 아이디 발급 후 바로 보기
                                    </button>
                                </form>

                                <p class="u-txt-gray-600 c-fs-16 fw-400 u-lh-15 u-ls-10 text-center u-mt-30">
                                    이미 계정이 있으신가요?
                                    <a href="<?php echo G5_BBS_URL; ?>/login.php?url=<?php echo urlencode($_SERVER['REQUEST_URI']); ?>"
                                       class="u-txt-sub fw-600">로그인</a>
                                </p>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <?php echo $case['content']; ?>
                <?php endif; ?>
            </div>

            <div class="content_tail">

                <?php if (!empty($files)): ?>
                    <div class="content_file u-px-60 u-py-20 d-flex align-items-center u-gap-80 u-mb-20">
                        <?php foreach ($files as $fi => $file): ?>
                            <h4 class="t-fs-22 fw-400 u-lh-16 u-ls-10 u-txt-dark">파일<?php echo $fi + 1; ?></h4>
                            <div class="d-flex flex-column">
                                <a href="<?php echo htmlspecialchars($file['url']); ?>" download
                                    class="u-txt-dark c-fs-16 fw-400 u-lh-14 u-ls-10">
                                    <?php echo htmlspecialchars($file['name']); ?>
                                </a>
                                <span class="u-txt-gray-700 c-fs-12 fw-400 u-lh-14 u-ls-10">
                                    (파일크기 : <?php echo $file['size_str']; ?> / 다운로드 : <?php echo (int)$file['download_cnt']; ?>)
                                </span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <div class="d-flex align-items-center u-bt-1 u-bc-gray-200 u-solid u-gap-20">
                    <div class="w-max d-flex u-gap-10 align-items-center u-bg-gray-100 u-py-14 u-px-40">
                        <h4 class="t-fs-22 fw-400 u-lh-16 u-ls-10 u-txt-dark">
                            <span class="material-symbols-outlined">keyboard_arrow_up</span>다음글
                        </h4>
                    </div>
                    <div>
                        <?php if ($next): ?>
                            <a href="/sub/board/case_review.php?id=<?php echo (int)$next['id']; ?>"
                                class="c-fs-16 u-txt-gray-700 fw-400 u-lh-14 u-ls-10 text-decoration-none">
                                <?php echo htmlspecialchars($next['title'] ?? ''); ?>
                            </a>
                        <?php else: ?>
                            <p class="c-fs-16 u-txt-gray-700 fw-400 u-lh-14 u-ls-10">다음글이 없습니다.</p>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="d-flex align-items-center u-gap-20">
                    <div class="w-max d-flex u-gap-10 align-items-center u-bg-gray-100 u-py-14 u-px-40">
                        <h4 class="t-fs-22 fw-400 u-lh-16 u-ls-10 u-txt-dark">
                            <span class="material-symbols-outlined">keyboard_arrow_down</span>이전글
                        </h4>
                    </div>
                    <div>
                        <?php if ($prev): ?>
                            <a href="/sub/board/case_review.php?id=<?php echo (int)$prev['id']; ?>"
                                class="c-fs-16 u-txt-gray-700 fw-400 u-lh-14 u-ls-10 text-decoration-none">
                                <?php echo htmlspecialchars($prev['title'] ?? ''); ?>
                            </a>
                        <?php else: ?>
                            <p class="c-fs-16 u-txt-gray-700 fw-400 u-lh-14 u-ls-10">이전글이 없습니다.</p>
                        <?php endif; ?>
                    </div>
                </div>

            </div>
        </div>
    </div>
</main>

<?php include_once(G5_PATH . '/tail.php'); ?>
