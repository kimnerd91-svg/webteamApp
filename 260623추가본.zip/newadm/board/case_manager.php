<?php
include_once('../_common.php');
include_once('../_auth_check.php');
include_once('/head_sub.php');

$case_table = 'dm_case';
$table_exists = sql_query("SHOW TABLES LIKE '{$case_table}'");
if (sql_num_rows($table_exists) == 0) {
    sql_query("CREATE TABLE `{$case_table}` (`id` int(11) NOT NULL AUTO_INCREMENT,`category` varchar(50) DEFAULT NULL,`title` varchar(255) DEFAULT NULL,`content` text NOT NULL,`case_date` date DEFAULT NULL,`is_visible` tinyint(1) DEFAULT 1,`display_order` int(11) DEFAULT 0,`created_at` datetime DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY (`id`),KEY `idx_visible_order` (`is_visible`, `display_order`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;", false);
    $table_created = true;
} else {
    $chk = sql_query("SHOW COLUMNS FROM `{$case_table}` LIKE 'title'");
    if (sql_num_rows($chk) == 0) sql_query("ALTER TABLE `{$case_table}` ADD COLUMN `title` varchar(255) DEFAULT NULL AFTER `category`");
}

if (isset($_POST['action'])) {
    if ($_POST['action'] == 'delete') { $id=(int)$_POST['id']; sql_query("DELETE FROM {$case_table} WHERE id={$id}"); echo json_encode(['success'=>true]); exit; }
    if ($_POST['action'] == 'save' || $_POST['action'] == 'update') {
        $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
        $category  = sql_real_escape_string(trim($_POST['category']));
        $title     = sql_real_escape_string(trim($_POST['title'] ?? ''));
        $content   = sql_real_escape_string(str_replace(['&quot;','"',"\\"],'',htmlspecialchars_decode($_POST['content'])));
        $case_date = sql_real_escape_string(trim($_POST['case_date']));
        $is_visible = isset($_POST['is_visible']) ? 1 : 0;
        if ($id > 0) sql_query("UPDATE {$case_table} SET category='{$category}',title='{$title}',content='{$content}',case_date='{$case_date}',is_visible={$is_visible} WHERE id={$id}");
        else sql_query("INSERT INTO {$case_table} (category,title,content,case_date,is_visible) VALUES ('{$category}','{$title}','{$content}','{$case_date}',{$is_visible})");
        echo json_encode(['success'=>true]); exit;
    }
    if ($_POST['action'] == 'toggle_visible') { $id=(int)$_POST['id']; $iv=(int)$_POST['is_visible']; sql_query("UPDATE {$case_table} SET is_visible={$iv} WHERE id={$id}"); echo json_encode(['success'=>true]); exit; }
}

$result = sql_query("SELECT * FROM {$case_table} ORDER BY display_order ASC, id DESC");
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>증례 관리</title>
    <script src="https://cdn.ckeditor.com/ckeditor5/39.0.1/classic/ckeditor.js"></script>
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Pretendard', 'Apple SD Gothic Neo', sans-serif; background: #f5f6fa; color: #1a1a2e; }
        #admin_wrapper { display: flex; min-height: 100vh; }
        .content_area { flex: 1; padding: 40px; overflow-x: hidden; }

        .page_header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 28px; }
        .page_title  { font-size: 22px; font-weight: 700; }
        .btn_add { padding: 10px 20px; background: #4f46e5; color: #fff; border: none; border-radius: 8px; font-size: 13px; font-weight: 700; cursor: pointer; transition: all 0.2s; box-shadow: 0 4px 12px rgba(79,70,229,0.25); }
        .btn_add:hover { background: #4338ca; }

        .alert_success { padding: 14px 18px; background: #d1fae5; color: #065f46; border-radius: 9px; margin-bottom: 20px; font-size: 13px; font-weight: 600; }

        .card { background: #fff; border-radius: 12px; box-shadow: 0 2px 12px rgba(0,0,0,0.06); border: 1px solid #e8eaf0; overflow: hidden; }
        .table_wrap { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; min-width: 640px; }
        thead th { background: #f5f6fa; padding: 12px 18px; font-size: 12px; font-weight: 700; color: #9999bb; text-align: left; border-bottom: 2px solid #e8eaf0; }
        tbody td { padding: 14px 18px; border-bottom: 1px solid #f5f6fa; vertical-align: middle; font-size: 14px; color: #444466; cursor: pointer; }
        tbody tr:last-child td { border-bottom: none; }
        tbody tr:hover td { background: #fafafa; }

        .cat_badge { display: inline-block; padding: 3px 10px; background: #ede9fe; color: #4f46e5; border-radius: 20px; font-size: 11px; font-weight: 700; }
        .preview { max-width: 320px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 13px; color: #9999bb; }
        .btn_del_row { padding: 5px 12px; background: #fee2e2; color: #dc2626; border: none; border-radius: 6px; font-size: 12px; font-weight: 700; cursor: pointer; transition: all 0.2s; }
        .btn_del_row:hover { background: #fecaca; }
        .empty_row td { text-align: center; padding: 56px; color: #9999bb; }

        /* 토글 스위치 */
        .sw { position: relative; display: inline-block; width: 44px; height: 22px; }
        .sw input { opacity: 0; width: 0; height: 0; }
        .sl { position: absolute; cursor: pointer; inset: 0; background: #d1d5e0; border-radius: 22px; transition: .3s; }
        .sl:before { content: ''; position: absolute; height: 16px; width: 16px; left: 3px; bottom: 3px; background: #fff; border-radius: 50%; transition: .3s; }
        input:checked + .sl { background: #4f46e5; }
        input:checked + .sl:before { transform: translateX(22px); }

        /* 모달 */
        .modal_overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.55); z-index: 10000; align-items: flex-start; justify-content: center; padding: 40px 20px; overflow-y: auto; }
        .modal_overlay.active { display: flex; }
        .modal_box { background: #fff; border-radius: 14px; width: 100%; max-width: 820px; overflow: hidden; animation: modal_in 0.25s ease; margin: auto; }
        @keyframes modal_in { from { transform: translateY(-20px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
        .modal_hd { padding: 22px 24px; border-bottom: 1px solid #e8eaf0; display: flex; align-items: center; justify-content: space-between; }
        .modal_hd h3 { font-size: 17px; font-weight: 700; }
        .modal_close { background: none; border: none; font-size: 22px; cursor: pointer; color: #9999bb; }
        .modal_close:hover { color: #1a1a2e; }
        .modal_bd { padding: 24px; display: flex; flex-direction: column; gap: 18px; }
        .toggle_row { display: flex; align-items: center; gap: 12px; background: #f5f6fa; padding: 13px 16px; border-radius: 9px; }
        .toggle_row label { font-size: 13px; font-weight: 700; color: #1a1a2e; }
        .form_grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
        .form_group label { display: block; font-size: 12px; font-weight: 700; color: #9999bb; margin-bottom: 6px; }
        select, input[type="text"], input[type="date"] {
            width: 100%; height: 44px; border: 1px solid #e8eaf0; border-radius: 8px;
            padding: 0 14px; font-size: 14px; background: #f5f6fa; transition: all 0.2s;
        }
        select:focus, input:focus { outline: none; border-color: #4f46e5; background: #fff; box-shadow: 0 0 0 3px rgba(79,70,229,0.1); }
        .ck-editor__editable { min-height: 360px !important; }
        .modal_ft { padding: 16px 24px; border-top: 1px solid #e8eaf0; display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
        .btn_cancel { padding: 12px; border-radius: 8px; background: #f5f6fa; color: #5c5c7a; border: 1px solid #e8eaf0; font-size: 14px; font-weight: 700; cursor: pointer; transition: all 0.2s; }
        .btn_cancel:hover { background: #e8eaf0; }
        .btn_save { padding: 12px; border-radius: 8px; background: #4f46e5; color: #fff; border: none; font-size: 14px; font-weight: 700; cursor: pointer; transition: all 0.2s; }
        .btn_save:hover { background: #4338ca; }
    </style>
</head>
<body>
<div id="admin_wrapper">
    <?php include_once('../aside.php'); ?>
    <main class="content_area">

        <?php if (isset($table_created)): ?>
        <div class="alert_success">✔ 증례 테이블이 생성되었습니다!</div>
        <?php endif; ?>

        <div class="page_header">
            <h2 class="page_title">증례 관리</h2>
            <button onclick="openModal()" class="btn_add">+ 증례 추가</button>
        </div>

        <div class="card">
            <div class="table_wrap">
                <table>
                    <thead>
                        <tr>
                            <th style="width:64px;">노출</th>
                            <th style="width:110px;">카테고리</th>
                            <th style="width:180px;">제목</th>
                            <th>내용</th>
                            <th style="width:100px;">작성일</th>
                            <th style="width:70px; text-align:center;">삭제</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i = 0;
                        while ($case = sql_fetch_array($result)):
                            $i++;
                        ?>
                        <tr onclick="editCase(<?= $case['id'] ?>)">
                            <td onclick="event.stopPropagation()">
                                <label class="sw">
                                    <input type="checkbox" <?= $case['is_visible'] ? 'checked' : '' ?> onchange="toggleVisible(<?= $case['id'] ?>, this.checked)">
                                    <span class="sl"></span>
                                </label>
                            </td>
                            <td><?php if ($case['category']): ?><span class="cat_badge"><?= htmlspecialchars($case['category']) ?></span><?php endif; ?></td>
                            <td><strong><?= htmlspecialchars($case['title'] ?? '') ?></strong></td>
                            <td><div class="preview"><?= htmlspecialchars(strip_tags($case['content'])) ?></div></td>
                            <td style="font-size:12px; color:#9999bb;"><?= $case['case_date'] ?></td>
                            <td style="text-align:center;" onclick="event.stopPropagation()">
                                <button class="btn_del_row" onclick="deleteCase(<?= $case['id'] ?>)">삭제</button>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                        <?php if ($i === 0): ?>
                        <tr class="empty_row"><td colspan="6">등록된 증례가 없습니다.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</div>

<!-- 증례 모달 -->
<div class="modal_overlay" id="caseModal">
    <div class="modal_box">
        <div class="modal_hd">
            <h3 id="modalTitle">증례 추가</h3>
            <button class="modal_close" onclick="closeModal()">✕</button>
        </div>
        <form id="caseForm">
            <input type="hidden" id="caseId" name="id">
            <div class="modal_bd">
                <div class="toggle_row">
                    <label class="sw"><input type="checkbox" id="isVisible" name="is_visible" checked><span class="sl"></span></label>
                    <label>노출 여부</label>
                </div>
                <div class="form_grid">
                    <div class="form_group">
                        <label>시술 카테고리</label>
                        <select id="category" name="category">
                            <option value="">선택</option>
                            <option value="임플란트">임플란트</option>
                            <option value="심미치료">심미치료</option>
                            <option value="자연치아 살리기">자연치아 살리기</option>
                            <option value="기타">기타</option>
                        </select>
                    </div>
                    <div class="form_group">
                        <label>작성일</label>
                        <input type="date" id="caseDate" name="case_date" value="<?= date('Y-m-d') ?>">
                    </div>
                </div>
                <div class="form_group">
                    <label>제목 *</label>
                    <input type="text" id="title" name="title" placeholder="증례 제목을 입력해주세요" required>
                </div>
                <div class="form_group">
                    <label>증례 내용 *</label>
                    <textarea id="content" name="content"></textarea>
                </div>
            </div>
            <div class="modal_ft">
                <button type="button" class="btn_cancel" onclick="closeModal()">취소</button>
                <button type="submit" class="btn_save">저장</button>
            </div>
        </form>
    </div>
</div>

<script>
let editor, editorReady = false;
document.addEventListener('DOMContentLoaded', function() {
    ClassicEditor.create(document.querySelector('#content'), {
        language: 'ko',
        toolbar: ['bold','italic','|','bulletedList','numberedList','|','link','imageUpload','|','undo','redo'],
        placeholder: '증례 내용을 입력해주세요'
    }).then(newEditor => {
        editor = newEditor; editorReady = true;
        editor.plugins.get('FileRepository').createUploadAdapter = (loader) => ({
            upload: () => loader.file.then(file => new Promise((resolve, reject) => {
                const fd = new FormData(); fd.append('upload', file);
                fetch('/newadm/board/case_upload.php', { method:'POST', body:fd })
                    .then(r => r.text()).then(text => {
                        const data = JSON.parse(text);
                        if (data.url) resolve({ default: data.url.replace(/^["']|["']$/g,'') });
                        else reject(data.error.message);
                    }).catch(e => reject('업로드 실패: '+e));
            })),
            abort: () => {}
        });
    }).catch(e => console.error(e));
});

function openModal(id = null) {
    if (!editorReady) { alert('에디터 로딩 중...'); return; }
    document.getElementById('caseForm').reset();
    document.getElementById('caseId').value = '';
    document.getElementById('isVisible').checked = true;
    document.getElementById('caseDate').value = new Date().toISOString().split('T')[0];
    if (editor) editor.setData('');
    document.getElementById('modalTitle').textContent = id ? '증례 수정' : '증례 추가';
    if (id) loadCaseData(id);
    document.getElementById('caseModal').classList.add('active');
}
function closeModal() { document.getElementById('caseModal').classList.remove('active'); }
function editCase(id) { openModal(id); }

function loadCaseData(id) {
    <?php
    sql_data_seek($result, 0);
    $cases = [];
    while ($row = sql_fetch_array($result)) $cases[$row['id']] = $row;
    echo "const cases = " . json_encode($cases) . ";";
    ?>
    const r = cases[id]; if (!r) return;
    document.getElementById('caseId').value       = r.id;
    document.getElementById('category').value     = r.category || '';
    document.getElementById('title').value        = r.title || '';
    document.getElementById('caseDate').value     = r.case_date || '';
    document.getElementById('isVisible').checked  = r.is_visible == 1;
    if (editor) editor.setData(r.content || '');
}

document.getElementById('caseForm').addEventListener('submit', function(e) {
    e.preventDefault();
    if (!editorReady) { alert('에디터 준비 안됨'); return; }
    const content = editor.getData();
    if (!content.trim()) { alert('내용을 입력해주세요.'); return; }
    const fd = new FormData(this);
    fd.set('content', content);
    fd.append('action', document.getElementById('caseId').value ? 'update' : 'save');
    fetch('', { method:'POST', body:fd }).then(r=>r.json()).then(d => {
        if (d.success) { closeModal(); location.reload(); } else alert('저장 실패');
    }).catch(() => alert('오류 발생'));
});

function toggleVisible(id, v) {
    const fd = new FormData(); fd.append('action','toggle_visible'); fd.append('id',id); fd.append('is_visible',v?1:0);
    fetch('', { method:'POST', body:fd }).then(r=>r.json()).then(d => { if (!d.success) location.reload(); });
}
function deleteCase(id) {
    if (!confirm('정말 삭제하시겠습니까?')) return;
    const fd = new FormData(); fd.append('action','delete'); fd.append('id',id);
    fetch('', { method:'POST', body:fd }).then(r=>r.json()).then(d => { if (d.success) location.reload(); });
}
</script>
</body>
</html>
