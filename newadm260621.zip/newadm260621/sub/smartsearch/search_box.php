<?php
/**
 * search_box.php  —  전역 검색창 (자동완성 미리보기 포함)
 *   사용:  <?php include_once(G5_PATH . '/sub/smartsearch/search_box.php'); ?>
 *   동작:  입력 → 미리보기 드롭다운(키워드·증상단서 매칭) → 선택 시 진료 이동
 *          또는 엔터/검색버튼 → /sub/smartsearch/search_smart.php?q=... 이동
 *   데이터: /data/search_suggest.json (인덱스 빌드 시 생성)
 */
?>
<div class="gsearch-wrap">
  <form class="gsearch" method="get" action="/sub/smartsearch/search_smart.php" role="search" autocomplete="off">
    <input type="text" id="gsearchInput" name="q" placeholder="진료·증상을 검색해 보세요 (예: 이가 아파요)" autocomplete="off" aria-label="통합검색" aria-expanded="false" aria-controls="gsearchPreview">
    <button type="submit" aria-label="검색"><span class="material-symbols-outlined">search</span></button>
  </form>
  <div class="gsearch-preview" id="gsearchPreview" role="listbox" hidden></div>
</div>
<style>
  .gsearch-wrap{position:relative;max-width:440px}
  .gsearch{display:flex;align-items:center;gap:6px;background:#fff;border:1px solid #e3ddd0;border-radius:999px;padding:5px 5px 5px 18px}
  .gsearch input{flex:1;border:0;outline:0;font:inherit;font-size:15px;background:transparent;color:#1f2a2a}
  .gsearch button{flex:none;width:38px;height:38px;border:0;border-radius:50%;background:#1f5e54;color:#fff;display:grid;place-items:center;cursor:pointer}
  .gsearch button:hover{background:#19534a}
  .gsearch .material-symbols-outlined{font-size:20px}
  .gsearch-preview{position:absolute;top:calc(100% + 6px);left:0;right:0;background:#fff;border:1px solid #e3ddd0;border-radius:16px;box-shadow:0 12px 28px rgba(0,0,0,.10);padding:6px;z-index:50;max-height:340px;overflow-y:auto}
  .gsp-item{display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:10px;text-decoration:none;color:#1f2a2a;cursor:pointer}
  .gsp-item:hover,.gsp-item.active{background:#f3f0e8}
  .gsp-ic{flex:none;width:26px;height:26px;border-radius:50%;display:grid;place-items:center;font-size:14px;background:#eef4f2}
  .gsp-body{flex:1;min-width:0}
  .gsp-term{font-size:14.5px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .gsp-term mark{background:#fdf3c4;color:inherit;padding:0 1px;border-radius:2px}
  .gsp-name{font-size:12px;color:#7c8a86;margin-top:1px}
  .gsp-tag{flex:none;font-size:10.5px;font-weight:700;padding:2px 7px;border-radius:999px}
  .gsp-tag.kw{background:#e7f0ee;color:#1f5e54}
  .gsp-tag.sy{background:#fbeede;color:#b5742a}
  .gsp-empty{padding:14px 12px;color:#9aa4a1;font-size:13px;text-align:center}
</style>
<script>
(function(){
  var input = document.getElementById('gsearchInput');
  var box   = document.getElementById('gsearchPreview');
  if(!input||!box) return;
  var DATA=null, loaded=false, activeIdx=-1, items=[];

  function norm(s){ return (s||'').toLowerCase().replace(/\s+/g,''); }
  // 부위어/통증어 동의어 정규화 (search_smart의 ss_canon과 동일 기조)
  function canon(s){
    s=norm(s);
    var map={'이빨':'이','치아':'이','어금니':'이','앞니':'이','윗니':'이','아랫니':'이','잇빨':'이',
      '아파요':'아파','아픕니다':'아파','아픔':'아파','아프':'아파','쑤셔':'아파','쑤시':'아파',
      '욱신거려':'욱신','욱신거':'욱신','찌릿':'욱신','시려요':'시려','시린':'시려','시림':'시려','시리':'시려'};
    for(var k in map){ s=s.split(k).join(map[k]); }
    return s;
  }
  async function load(){
    if(loaded) return;
    loaded=true;
    try{
      var r=await fetch('/data/search_suggest.json',{cache:'no-cache'});
      var j=await r.json();
      DATA = (j&&j.items)?j.items:[];
    }catch(e){ DATA=[]; }
  }
  function render(q){
    var nq=canon(q);
    items=[];
    if(nq.length>=1 && DATA){
      var seen={};
      for(var i=0;i<DATA.length;i++){
        var it=DATA[i];
        var ct=canon(it.term);
        // 부분일치(양방향): 입력이 단서를 포함하거나, 단서가 입력을 포함
        if(ct.indexOf(nq)>=0 || nq.indexOf(ct)>=0){
          var key=it.name+'|'+it.term;
          if(seen[key])continue; seen[key]=1;
          items.push(it);
          if(items.length>=8)break;
        }
      }
    }
    activeIdx=-1;
    if(items.length===0){
      if(q.trim().length>=1){
        box.innerHTML='<div class="gsp-empty">엔터를 눌러 \''+escapeHtml(q)+'\' 통합검색</div>';
        box.hidden=false; input.setAttribute('aria-expanded','true');
      }else{ hide(); }
      return;
    }
    var html='';
    items.forEach(function(it,idx){
      var tag = it.type==='symptom' ? '<span class="gsp-tag sy">증상</span>' : '<span class="gsp-tag kw">진료</span>';
      var ic  = it.type==='symptom' ? '💬' : '🦷';
      html+='<a class="gsp-item" data-idx="'+idx+'" href="'+escapeHtml(it.url)+'">'
          + '<span class="gsp-ic">'+ic+'</span>'
          + '<span class="gsp-body"><span class="gsp-term">'+highlight(it.term,q)+'</span>'
          + '<span class="gsp-name">'+escapeHtml(it.name)+'</span></span>'
          + tag + '</a>';
    });
    box.innerHTML=html;
    box.hidden=false; input.setAttribute('aria-expanded','true');
  }
  function highlight(term,q){
    var nq=norm(q); var nt=norm(term);
    var pos=nt.indexOf(nq);
    if(nq===''||pos<0) return escapeHtml(term);
    // 원문 기준 하이라이트는 근사치(정규화 좌표라 단순 표시)
    return escapeHtml(term).replace(new RegExp('('+escapeReg(q.trim())+')','i'),'<mark>$1</mark>');
  }
  function escapeHtml(s){return (s||'').replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
  function escapeReg(s){return s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');}
  function hide(){ box.hidden=true; box.innerHTML=''; activeIdx=-1; input.setAttribute('aria-expanded','false'); }
  function setActive(n){
    var els=box.querySelectorAll('.gsp-item');
    if(!els.length)return;
    if(n<0)n=els.length-1; if(n>=els.length)n=0;
    els.forEach(function(e){e.classList.remove('active');});
    els[n].classList.add('active'); activeIdx=n;
    els[n].scrollIntoView({block:'nearest'});
  }

  var t=null;
  input.addEventListener('input',function(){
    var q=this.value;
    clearTimeout(t);
    t=setTimeout(function(){ load().then(function(){ render(q); }); },80);
  });
  input.addEventListener('focus',function(){ if(this.value.trim()){ load().then(function(){ render(input.value); }); } });
  input.addEventListener('keydown',function(e){
    var els=box.querySelectorAll('.gsp-item');
    if(box.hidden||!els.length) return;
    if(e.key==='ArrowDown'){ e.preventDefault(); setActive(activeIdx+1); }
    else if(e.key==='ArrowUp'){ e.preventDefault(); setActive(activeIdx-1); }
    else if(e.key==='Enter'){
      if(activeIdx>=0 && els[activeIdx]){ e.preventDefault(); location.href=els[activeIdx].getAttribute('href'); }
    } else if(e.key==='Escape'){ hide(); }
  });
  document.addEventListener('click',function(e){
    if(!e.target.closest('.gsearch-wrap')) hide();
  });
})();
</script>
