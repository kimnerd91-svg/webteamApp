<?php
chdir(dirname(__FILE__) . '/..');
include_once('./_common.php');

global $connect_db;
$db = $connect_db;

$table        = 'g5_column';
$cat_table    = 'g5_column_cat';
$column_path  = '/sub';
$column_label = '임상증례';

$page     = max(1, (int)($_GET['page'] ?? 1));
$per_page = 9;
$offset   = ($page - 1) * $per_page;
$sel_tag  = trim($_GET['tag'] ?? '');
$sel_cat  = (int)($_GET['cat'] ?? 0);

// 카테고리 목록 + 게시물 수
$cats = [];
$cats_r = mysqli_query($db, "SELECT c.*, COUNT(g.id) as post_count
    FROM `{$cat_table}` c
    LEFT JOIN `{$table}` g ON g.cat_id = c.id
    GROUP BY c.id
    ORDER BY c.sort ASC, c.id ASC");
if ($cats_r) while ($c = mysqli_fetch_assoc($cats_r)) $cats[] = $c;

// 전체 수
$total_all = (int)(mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) as cnt FROM `{$table}`"))['cnt'] ?? 0);

// WHERE 조건
$where = '1=1';
if ($sel_tag) {
    $tag_esc = mysqli_real_escape_string($db, $sel_tag);
    $where .= " AND tags LIKE '%{$tag_esc}%'";
}
if ($sel_cat) {
    $where .= " AND cat_id={$sel_cat}";
}

// 총 게시물 수
$r = mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) AS cnt FROM `{$table}` WHERE {$where}"));
$total       = (int)($r['cnt'] ?? 0);
$total_pages = max(1, ceil($total / $per_page));

// 게시물 목록 (JSON-LD 스키마용으로도 재사용되므로 항상 실행)
$posts_r = mysqli_query($db, "SELECT id, title, subtitle, thumbnail, tags, created_at, hit
    FROM `{$table}` WHERE {$where} ORDER BY id DESC LIMIT {$offset},{$per_page}");
$post_list = [];
if ($posts_r) while ($row = mysqli_fetch_assoc($posts_r)) $post_list[] = $row;

// 인기태그 TOP 10 (홈 레이아웃에서는 5개만 slice해서 사용)
$tag_counts = [];
$tags_r = mysqli_query($db, "SELECT tags FROM `{$table}` WHERE tags != ''");
if ($tags_r) {
    while ($tr = mysqli_fetch_assoc($tags_r)) {
        foreach (explode(',', $tr['tags']) as $t) {
            $t = trim($t);
            if ($t) $tag_counts[$t] = ($tag_counts[$t] ?? 0) + 1;
        }
    }
}
arsort($tag_counts);
$popular_tags = array_slice($tag_counts, 0, 10, true);

// 인기글 TOP 10 (홈 레이아웃에서는 5개만 slice해서 사용)
$popular_posts = [];
$pop_r = mysqli_query($db, "SELECT id, title FROM `{$table}` ORDER BY hit DESC LIMIT 10");
if ($pop_r) while ($pp = mysqli_fetch_assoc($pop_r)) $popular_posts[] = $pp;

// ── 홈 레이아웃 여부: 필터/페이지 파라미터가 전혀 없을 때만 ──
$show_home_layout = !$sel_cat && !$sel_tag && $page <= 1;

if ($show_home_layout) {
    // 최신글 스와이퍼 (카테고리 무관, 최신순 6개, 부족하면 반복해서 채움)
    $swiper_r = mysqli_query($db, "SELECT id, title, subtitle, thumbnail, cat_id, created_at
        FROM `{$table}` ORDER BY id DESC LIMIT 6");
    $swiper_posts = [];
    if ($swiper_r) while ($row = mysqli_fetch_assoc($swiper_r)) $swiper_posts[] = $row;

    if (!empty($swiper_posts) && count($swiper_posts) < 6) {
        $orig = $swiper_posts;
        while (count($swiper_posts) < 6) $swiper_posts = array_merge($swiper_posts, $orig);
        $swiper_posts = array_slice($swiper_posts, 0, 6);
    }

    // 카테고리 id → 이름 매핑 (스와이퍼 카드 라벨용)
    $cat_name_map = [];
    foreach ($cats as $c) $cat_name_map[(int)$c['id']] = $c['name'];

    // 게시물 있는 카테고리 중 랜덤 최대 2개
    $cats_with_posts = array_values(array_filter($cats, function ($c) {
        return (int)$c['post_count'] > 0;
    }));
    shuffle($cats_with_posts);
    $shown_cats = array_slice($cats_with_posts, 0, 2);

    // 카테고리별 게시물: 1row(3) + LOAD MORE 시 최대 3row(9)
    $home_per_cat = 9;
    foreach ($shown_cats as $idx => $cat) {
        $cid = (int)$cat['id'];
        $cp_r = mysqli_query($db, "SELECT id, title, subtitle, thumbnail, tags, created_at, hit
            FROM `{$table}` WHERE cat_id={$cid} ORDER BY id DESC LIMIT {$home_per_cat}");
        $cp_list = [];
        if ($cp_r) while ($row = mysqli_fetch_assoc($cp_r)) $cp_list[] = $row;
        $shown_cats[$idx]['posts'] = $cp_list;
    }
}

include_once(G5_PATH . '/head_sub.php');
include_once(G5_PATH . '/head.php');
?>

<?php if ($show_home_layout): ?>

    <main class="u-pretendard column-list-home u-bg-white u-pb-150">

        <!-- ── 최신글 스와이퍼 (카테고리 무관) ── -->
        <?php if (!empty($swiper_posts)): ?>
            <section class="u-pt-150  u-mb-100 u-mb-60-sm">
                <div class="u-fluid-lg u-fluid-xl-sm d-flex justify-content-between align-items-center u-mb-40 u-mb-60-sm">
                    <h1 class="u-maruburi u-txt-dark c-fs-48 c-fs-32-sm fw-400 u-lh-15 u-ls-15">닥터칼럼</h1>
                    <div class="clh-view-toggle" role="group" aria-label="보기 방식 전환">
                        <button type="button" class="clh-view-btn active" data-view="thumb">
                            <span class="material-symbols-outlined">grid_view</span> THUMB
                        </button>
                        <button type="button" class="clh-view-btn" data-view="list">
                            <span class="material-symbols-outlined">list</span> LIST
                        </button>
                    </div>
                </div>
                <div class="clh-swiper-wrap">
                    <div class="swiper clh-swiper">
                        <div class="swiper-wrapper">
                            <?php foreach ($swiper_posts as $sp):
                                $thumb = !empty($sp['thumbnail']) ? $sp['thumbnail'] : '/images/no_image.png';
                                $href  = $column_path . '/column.php?id=' . (int)$sp['id'];
                                $cname = $cat_name_map[(int)$sp['cat_id']] ?? '';
                            ?>
                                <div class="swiper-slide ">
                                    <a class="d-block" href="<?= $href ?>">
                                        <div class=" u-round-20">
                                            <img class="u-ratio-5-3 w-100 h-100 u-obj-cover" src="<?= htmlspecialchars($thumb) ?>" alt="<?= htmlspecialchars($sp['title']) ?>">
                                        </div>
                                    </a>
                                    <?php if ($cname): ?>
                                        <p class="u-txt-point c-fs-13 fw-600 u-mt-20 u-mb-8 u-ls-10"><?= htmlspecialchars(mb_strtoupper($cname)) ?></p>
                                    <?php endif; ?>
                                    <a href="<?= $href ?>">
                                        <h2 class="u-notoserif u-txt-dark t-fs-22 t-fs-18-sm fw-400 u-lh-13"><?= htmlspecialchars($sp['title']) ?></h2>
                                    </a>
                                    <?php if (!empty($sp['subtitle'])): ?>
                                        <p class="u-txt-gray-500 c-fs-14 u-mt-8"><?= htmlspecialchars($sp['subtitle']) ?></p>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <button type="button" class="clh-swiper-nav clh-swiper-prev" aria-label="이전">
                        <span class="material-symbols-outlined">arrow_back</span>
                    </button>
                    <button type="button" class="clh-swiper-nav clh-swiper-next" aria-label="다음">
                        <span class="material-symbols-outlined">arrow_forward</span>
                    </button>
                </div>
            </section>
        <?php endif; ?>

        <!-- ── 랜덤 카테고리 섹션 (최대 2개) ── -->
        <?php foreach ($shown_cats as $cat):
            $cid       = (int)$cat['id'];
            $cat_posts = $cat['posts'];
            if (empty($cat_posts)) continue;
        ?>
            <section class="clh-cat-section u-mb-100 u-mb-60-sm" data-cat-id="<?= $cid ?>">
                <div class="clh-cat-header">
                    <div class="u-fluid-lg u-fluid-xl-sm d-flex justify-content-between align-items-center">
                        <h2 class="u-notoserif u-txt-dark t-fs-32 t-fs-24-sm fw-400 u-lh-11">
                            <?= htmlspecialchars($cat['name']) ?>
                            <sup class="c-fs-14 u-txt-gray-500 fw-400"><?= (int)$cat['post_count'] ?></sup>
                        </h2>
                        <a class="c-fs-13 u-txt-gray-500 u-ls-10" href="<?= $column_path ?>/column_list.php?cat=<?= $cid ?>">전체보기</a>
                    </div>
                </div>

                <div class="u-fluid-lg u-fluid-xl-sm ">
                    <div class="clh-grid">
                        <?php foreach ($cat_posts as $i => $row):
                            $tags   = array_filter(array_map('trim', explode(',', $row['tags'] ?? '')));
                            $thumb  = !empty($row['thumbnail']) ? $row['thumbnail'] : '/images/no_image.png';
                            $href   = $column_path . '/column.php?id=' . (int)$row['id'];
                            $hidden = $i >= 3 ? ' clh-hidden' : '';
                        ?>
                            <article class="flex-wrap flex-lg-nowrap clh-card<?= $hidden ?>">
                                <span class="clh-card-cat"><?= htmlspecialchars(mb_strtoupper($cat['name'])) ?></span>
                                <a class="u-mb-24 clh-card-thumb" href="<?= $href ?>">
                                    <div class="u-ratio-4-3 u-round-20">
                                        <img class="w-100 h-100 u-obj-cover" src="<?= htmlspecialchars($thumb) ?>" alt="<?= htmlspecialchars($row['title']) ?>">
                                    </div>
                                </a>
                                <?php if (!empty($tags)): ?>
                                    <p class="d-flex flex-wrap u-gap-4 u-my-16 clh-card-tags">
                                        <?php foreach ($tags as $tag): ?>
                                            <a class="u-txt-gray-600 c-fs-12 fw-600 u-bg-gray-100 u-round-8 u-px-10 u-py-4" href="<?= $column_path ?>/column_list.php?tag=<?= urlencode($tag) ?>">
                                                <?= htmlspecialchars($tag) ?>
                                            </a>
                                        <?php endforeach; ?>
                                    </p>
                                <?php endif; ?>
                                <a href="<?= $href ?>" class="clh-card-title-link">
                                    <h3 class="u-txt-dark c-fs-20 fw-400 u-lh-13 u-ls-10 u-mb-8 clh-card-title"><?= htmlspecialchars($row['title']) ?></h3>
                                </a>
                                <?php if (!empty($row['subtitle'])): ?>
                                    <p class="u-txt-gray-500 c-fs-14 u-lh-15 u-ls-10 clh-card-subtitle"><?= htmlspecialchars($row['subtitle']) ?></p>
                                <?php endif; ?>
                            </article>
                        <?php endforeach; ?>
                    </div>

                    <?php if (count($cat_posts) > 3): ?>
                        <div class="text-center u-mt-60 u-mt-40-sm">
                            <button type="button" class="clh-load-more-btn">LOAD MORE</button>
                        </div>
                    <?php endif; ?>
                </div>
            </section>
        <?php endforeach; ?>

        <!-- ── 하단 인기태그 / 인기글 (top5, flex-row) ── -->
        <section class="u-fluid-lg u-fluid-xl-sm u-py-60 u-bt-1 u-bc-gray-300 u-px-20-sm">
            <div class="d-flex flex-column flex-lg-row u-gap-60 u-gap-40-sm u-py-40-sm">
                <div class="flex-1">
                    <p class="u-notoserif u-txt-dark c-fs-18 fw-400 u-mb-20">인기태그 TOP 5</p>
                    <ul class="d-flex flex-wrap u-gap-10">
                        <?php foreach (array_slice($popular_tags, 0, 5, true) as $tag => $cnt): ?>
                            <li>
                                <a class="u-txt-gray-600 c-fs-12 fw-600 u-bg-gray-100 u-round-8 u-px-10 u-py-4" href="<?= $column_path ?>/column_list.php?tag=<?= urlencode($tag) ?>">
                                    <?= htmlspecialchars($tag) ?>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <div class="flex-1">
                    <p class="u-notoserif u-txt-dark c-fs-18 fw-400 u-mb-20">인기글 TOP 5</p>
                    <ul>
                        <?php foreach (array_slice($popular_posts, 0, 5) as $i => $pp): ?>
                            <li class="u-mb-10">
                                <span class="u-txt-dark c-fs-14 fw-400 u-mr-8"><?= $i + 1 ?>.</span>
                                <a class="u-txt-dark c-fs-14 fw-400" href="<?= $column_path ?>/column.php?id=<?= (int)$pp['id'] ?>">
                                    <?= htmlspecialchars($pp['title']) ?>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </section>

    </main>



<?php else:
    // 상단 타이틀: 카테고리명 / #태그명 / 전체
    $filtered_title = '전체';
    if ($sel_cat) {
        foreach ($cats as $c) {
            if ((int)$c['id'] === $sel_cat) {
                $filtered_title = $c['name'];
                break;
            }
        }
    } elseif ($sel_tag) {
        $filtered_title = '#' . $sel_tag;
    }
?>
    <main class="u-pretendard column-list-home column-list-filtered u-bg-white u-pb-150">

        <section class="u-pt-150 u-mb-100 u-mb-60-sm">
            <div class="u-fluid-lg u-fluid-xl-sm d-flex justify-content-between align-items-center u-mb-40 u-mb-60-sm">
                <h1 class="u-maruburi u-txt-dark c-fs-48 c-fs-32-sm fw-400 u-lh-15 u-ls-15"><?= htmlspecialchars($filtered_title) ?></h1>
                <div class="clh-view-toggle" role="group" aria-label="보기 방식 전환">
                    <button type="button" class="clh-view-btn active" data-view="thumb">
                        <span class="material-symbols-outlined">grid_view</span> THUMB
                    </button>
                    <button type="button" class="clh-view-btn" data-view="list">
                        <span class="material-symbols-outlined">list</span> LIST
                    </button>
                </div>
            </div>

            <div class="u-fluid-lg u-fluid-xl-sm">
                <?php if (empty($post_list)): ?>
                    <p class="u-txt-gray-500 c-fs-16">등록된 칼럼이 없습니다.</p>
                <?php else: ?>
                    <div class="clh-grid">
                        <?php foreach ($post_list as $row):
                            $tags  = array_filter(array_map('trim', explode(',', $row['tags'] ?? '')));
                            $thumb = !empty($row['thumbnail']) ? $row['thumbnail'] : '/images/no_image.png';
                            $href  = $column_path . '/column.php?id=' . (int)$row['id'];
                        ?>
                            <article class="flex-wrap flex-lg-nowrap clh-card">
                                <span class="clh-card-cat"><?= htmlspecialchars(mb_strtoupper($filtered_title)) ?></span>
                                <a class="u-mb-24 clh-card-thumb" href="<?= $href ?>">
                                    <div class="u-ratio-4-3 u-round-20">
                                        <img class="w-100 h-100 u-obj-cover" src="<?= htmlspecialchars($thumb) ?>" alt="<?= htmlspecialchars($row['title']) ?>">
                                    </div>
                                </a>
                                <?php if (!empty($tags)): ?>
                                    <p class="d-flex flex-wrap u-gap-4 u-my-16 clh-card-tags">
                                        <?php foreach ($tags as $tag): ?>
                                            <a class="u-txt-gray-600 c-fs-12 fw-600 u-bg-gray-100 u-round-8 u-px-10 u-py-4" href="<?= $column_path ?>/column_list.php?tag=<?= urlencode($tag) ?>">
                                                <?= htmlspecialchars($tag) ?>
                                            </a>
                                        <?php endforeach; ?>
                                    </p>
                                <?php endif; ?>
                                <a href="<?= $href ?>" class="clh-card-title-link">
                                    <h3 class="u-txt-dark c-fs-20 fw-400 u-lh-13 u-ls-10 u-mb-8 clh-card-title"><?= htmlspecialchars($row['title']) ?></h3>
                                </a>
                                <?php if (!empty($row['subtitle'])): ?>
                                    <p class="u-txt-gray-500 c-fs-14 u-lh-15 u-ls-10 clh-card-subtitle"><?= htmlspecialchars($row['subtitle']) ?></p>
                                <?php endif; ?>
                            </article>
                        <?php endforeach; ?>
                    </div>

                    <?php if ($total_pages > 1): ?>
                        <nav class="d-flex justify-content-center u-gap-10 u-mt-60 u-mt-40-sm">
                            <?php if ($page > 1): ?>
                                <a class="clh-page-link" href="?page=<?= $page - 1 ?><?= $sel_tag ? '&tag=' . urlencode($sel_tag) : '' ?><?= $sel_cat ? '&cat=' . $sel_cat : '' ?>">&lsaquo;</a>
                            <?php endif; ?>
                            <?php for ($p = max(1, $page - 4); $p <= min($total_pages, $page + 4); $p++): ?>
                                <a class="clh-page-link<?= $p === $page ? ' active' : '' ?>" href="?page=<?= $p ?><?= $sel_tag ? '&tag=' . urlencode($sel_tag) : '' ?><?= $sel_cat ? '&cat=' . $sel_cat : '' ?>"><?= $p ?></a>
                            <?php endfor; ?>
                            <?php if ($page < $total_pages): ?>
                                <a class="clh-page-link" href="?page=<?= $page + 1 ?><?= $sel_tag ? '&tag=' . urlencode($sel_tag) : '' ?><?= $sel_cat ? '&cat=' . $sel_cat : '' ?>">&rsaquo;</a>
                            <?php endif; ?>
                        </nav>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </section>

        <!-- ── 하단 인기태그 / 인기글 (top5, flex-row) ── -->
        <section class="u-fluid-lg u-fluid-xl-sm u-py-60 u-bt-1 u-bc-gray-300 u-px-20-sm">
            <div class="d-flex flex-column flex-lg-row u-gap-60 u-gap-40-sm u-py-40-sm">
                <div class="flex-1">
                    <p class="u-notoserif u-txt-dark c-fs-18 fw-400 u-mb-20">인기태그 TOP 5</p>
                    <ul class="d-flex flex-wrap u-gap-10">
                        <?php foreach (array_slice($popular_tags, 0, 5, true) as $tag => $cnt): ?>
                            <li>
                                <a class="u-txt-gray-600 c-fs-12 fw-600 u-bg-gray-100 u-round-8 u-px-10 u-py-4" href="<?= $column_path ?>/column_list.php?tag=<?= urlencode($tag) ?>">
                                    <?= htmlspecialchars($tag) ?>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <div class="flex-1">
                    <p class="u-notoserif u-txt-dark c-fs-18 fw-400 u-mb-20">인기글 TOP 5</p>
                    <ul>
                        <?php foreach (array_slice($popular_posts, 0, 5) as $i => $pp): ?>
                            <li class="u-mb-10">
                                <span class="u-txt-dark c-fs-14 fw-400 u-mr-8"><?= $i + 1 ?>.</span>
                                <a class="u-txt-dark c-fs-14 fw-400" href="<?= $column_path ?>/column.php?id=<?= (int)$pp['id'] ?>">
                                    <?= htmlspecialchars($pp['title']) ?>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </section>

    </main>
    <?php endif; ?>

        <style>
        /* ── column_list_home.css (홈 레이아웃 전용, 복사용으로 별도 관리) ── */


        /* 스와이퍼 */
        .clh-swiper-wrap {
            position: relative;
        }
        .u-ratio-5-3 {
            aspect-ratio: 5 / 3;
        }

        .clh-swiper {
            padding: 0 12vw;
        }

        @media (max-width: 768px) {
            .clh-swiper {
                padding: 0 8vw;
            }
        }

        .clh-swiper .swiper-slide {
            opacity: .45;
            transition: opacity .3s;
        }

        .clh-swiper .swiper-slide-active {
            opacity: 1;
        }

        .clh-swiper-nav {
            position: absolute;
            top: 30%;
            transform: translateY(-50%);
            width: var(--sp-42);
            height: var(--sp-42);
            border-radius: 50%;
            border: 1px solid var(--gray-300, #e5e7eb);
            background: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            z-index: 2;
        }

        .clh-swiper-prev {
            left: var(--sp-12);
        }

        .clh-swiper-next {
            right: var(--sp-12);
        }

        @media (max-width: 768px) {
            .clh-swiper-nav {
                display: none;
            }
        }

        /* 카테고리 섹션 헤더 — 스크롤 시 상단 고정 */
        .clh-cat-header {
            position: sticky;
            top: 0;
            z-index: 5;
            background: #fff;
            border-bottom: 1px solid var(--gray-300, #e5e7eb);
            padding: var(--sp-24) 0;
            margin-bottom: var(--sp-40);
        }

        .clh-cat-header .u-fluid-lg u-fluid-xl-sm {
            padding-top: 0;
            padding-bottom: 0;
        }

        /* 카드 그리드 — 1row 3개 */
        .clh-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: var(--sp-40) var(--sp-32);
        }

        @media (max-width: 992px) {
            .clh-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 600px) {
            .clh-grid {
                grid-template-columns: 1fr;
            }
        }

        .clh-card.clh-hidden {
            display: none;
        }

        .clh-view-list .clh-grid img {
            display: none;
        }

        .clh-load-more-btn {
            padding: var(--sp-14) var(--sp-40);
            background: var(--main-color, #304F4E);
            color: #fff;
            border: none;
            border-radius: var(--sp-4);
            font-size: var(--sp-14);
            font-weight: 600;
            letter-spacing: .05em;
            cursor: pointer;
            transition: background .2s;
        }

        .clh-load-more-btn:hover {
            background: var(--point, #D7AC7A);
        }

        .clh-load-more-btn.clh-done {
            display: none;
        }

        /* 보기 방식 토글 버튼 */
        .clh-view-toggle {
            display: flex;
            border: 1px solid var(--gray-300, #e5e7eb);
            border-radius: var(--sp-4);
            overflow: hidden;
        }

        .clh-view-btn {
            display: flex;
            align-items: center;
            gap: var(--sp-6);
            padding: var(--sp-10) var(--sp-20);
            background: #fff;
            color: var(--gray-500, #6b7280);
            border: none;
            font-size: var(--sp-14);
            font-weight: 600;
            letter-spacing: .03em;
            cursor: pointer;
            transition: background .2s, color .2s;
        }

        .clh-view-btn .material-symbols-outlined {
            font-size: 1var(--sp-6);
        }

        .clh-view-btn.active {
            background: var(--dark, #2c2c2c);
            color: #fff;
        }

        .clh-view-btn:not(.active):hover {
            background: var(--gray-100, #f8f8f8);
        }

        /* 카테고리 라벨 — 기본(THUMB 모드)에서는 숨김 */
        .clh-card-cat {
            display: none;
        }

        /* ── LIST 모드 ── */
        .clh-view-list .clh-grid {
            display: block;
        }

        .clh-view-list .clh-card.clh-hidden {
            display: none;
        }

        .clh-view-list .clh-card {
            display: flex;
            align-items: center;
            gap: var(--sp-24);
            padding: var(--sp-20) 0;
            border-top: 1px solid var(--dark, #2c2c2c);
        }

        .clh-view-list .clh-card:last-child {
            border-bottom: 1px solid var(--dark, #2c2c2c);
        }

        .clh-view-list .clh-card-thumb {
            display: none;
        }

        .clh-view-list .clh-card-subtitle {
            display: none;
        }

        .clh-view-list .clh-card-cat {
            display: block;
            order: 1;
            flex: 0 0 var(--sp-100);
            color: var(--main-color, #304F4E);
            font-size: var(--sp-14);
            font-weight: 700;
            letter-spacing: .05em;
        }

        .clh-view-list .clh-card-title-link {
            order: 2;
            flex: 1 1 auto;
        }

        .clh-view-list .clh-card-title {
            order: 2;
            font-size: var(--sp-16);
            font-weight: 700;
            margin-bottom: 0;
        }

        .clh-view-list .clh-card-tags {
            order: 3;
            flex: 0 0 auto;
            margin-bottom: 0;
        }

        .clh-view-list .clh-card-tags a {
            border: none;
            background: var(--gray-100, #f8f8f8);
            color: var(--gray-500, #6b7280);
        }



        .clh-page-link {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: var(--sp-36);
            height: var(--sp-36);
            border: 1px solid var(--gray-300, #e5e7eb);
            border-radius: var(--sp-4);
            color: var(--gray-500, #6b7280);
            font-size: var(--sp-14);
            text-decoration: none;
        }

        .clh-page-link.active {
            background: var(--dark, #2c2c2c);
            color: #fff;
            border-color: var(--dark, #2c2c2c);
        }
    </style>

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200">
    <script>
        document.addEventListener('DOMContentLoaded', function() {

            // ── THUMB / LIST 보기 전환 ──
            document.querySelectorAll('.clh-view-btn').forEach(function(btn) {
                btn.addEventListener('click', function() {
                    var view = btn.dataset.view;
                    document.querySelectorAll('.clh-view-btn').forEach(function(b) {
                        b.classList.remove('active');
                    });
                    btn.classList.add('active');
                    var main = document.querySelector('.column-list-home');
                    if (main) main.classList.toggle('clh-view-list', view === 'list');
                });
            });

            // ── 카테고리별 LOAD MORE: 숨겨둔 카드 노출 후 버튼 숨김 ──
            document.querySelectorAll('.clh-load-more-btn').forEach(function(btn) {
                btn.addEventListener('click', function() {
                    var section = btn.closest('.clh-cat-section');
                    if (!section) return;
                    section.querySelectorAll('.clh-hidden').forEach(function(card) {
                        card.classList.remove('clh-hidden');
                    });
                    btn.classList.add('clh-done');
                });
            });

            // ── 최신글 스와이퍼 초기화 (사이트 전역 Swiper 재사용) ──
            if (typeof Swiper !== 'undefined' && document.querySelector('.clh-swiper')) {
                new Swiper('.clh-swiper', {
                    slidesPerView: 1.4,
                    centeredSlides: true,
                    spaceBetween: 20,
                    loop: true,
                    autoplay: {
                        delay: 3500,
                        disableOnInteraction: false
                    },
                    navigation: {
                        nextEl: '.clh-swiper-next',
                        prevEl: '.clh-swiper-prev',
                    },
                     breakpoints: {
        768: { slidesPerView: 2.2, spaceBetween: 28 },
        992: { slidesPerView: 3, spaceBetween: 32 },
    },

                });
            }
        });
    </script>


<?php
// ── JSON-LD 스키마 (레이아웃과 무관하게 항상 동일 로직) ────────
$protocol  = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$base_url  = $protocol . '://' . $_SERVER['HTTP_HOST'];
$page_url  = $base_url . strtok($_SERVER['REQUEST_URI'], '?');
$site_name = $cf_site_name ?: ($cf_title ?: '');
$clinic_ref = ['@id' => $base_url . '/#organization'];

// BreadcrumbList
$breadcrumb = [
    '@context' => 'https://schema.org',
    '@type'    => 'BreadcrumbList',
    '@id'      => $page_url . '#breadcrumb',
    'itemListElement' => [
        ['@type' => 'ListItem', 'position' => 1, 'name' => $site_name, 'item' => $base_url],
        ['@type' => 'ListItem', 'position' => 2, 'name' => $column_label, 'item' => $base_url . $column_path . '/column_list.php'],
    ],
];

// Blog (칼럼 목록)
$blog_posts = [];
foreach ($post_list as $row) {
    $item_url  = $base_url . $column_path . '/column.php?id=' . (int)$row['id'];
    $thumb_url = !empty($row['thumbnail']) ? (strpos($row['thumbnail'], 'http') === 0 ? $row['thumbnail'] : $base_url . $row['thumbnail']) : '';
    $entry = [
        '@type'         => 'BlogPosting',
        'headline'      => $row['title'] ?? '',
        'url'           => $item_url,
        'datePublished' => $row['created_at'] ?? '',
        'author'        => $clinic_ref,
    ];
    if ($row['subtitle']) $entry['description'] = $row['subtitle'];
    if ($thumb_url)       $entry['image']       = $thumb_url;
    $blog_posts[] = $entry;
}

$blog_schema = [
    '@context'  => 'https://schema.org',
    '@type'     => 'Blog',
    '@id'       => $page_url . '#blog',
    'name'      => $column_label . ' — ' . $site_name,
    'url'       => $page_url,
    'inLanguage' => 'ko-KR',
    'isPartOf'  => ['@id' => $base_url . '/#website'],
    'publisher' => $clinic_ref,
    'breadcrumb' => ['@id' => $page_url . '#breadcrumb'],
    'blogPost'  => $blog_posts,
];

$json_opts = JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT;
?>
<script type="application/ld+json">
    <?= json_encode($breadcrumb, $json_opts) ?>
</script>
<script type="application/ld+json">
    <?= json_encode($blog_schema, $json_opts) ?>
</script>
<?php include_once(G5_PATH . '/tail.php'); ?>