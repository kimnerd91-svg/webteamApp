<?php
include_once(G5_PATH . '/head_sub.php');

if (empty($dm_conf)) {
    $dm_conf = sql_fetch("SELECT * FROM dm_config WHERE cf_id = 1");
}

$admin_root = '/newadm';
$current_full_path = $_SERVER['SCRIPT_NAME'];

function check_expiring_content()
{
    $now = time();
    $alerts = [];
    $popup_query = "SELECT nw_id, nw_subject, nw_end_time, nw_status FROM dm_popup WHERE nw_status = 1 AND nw_end_time != '0000-00-00 00:00:00' AND nw_end_time > NOW() ORDER BY nw_end_time ASC";
    $popup_result = @sql_query($popup_query);
    if ($popup_result) {
        while ($popup = sql_fetch_array($popup_result)) {
            $end_time = strtotime($popup['nw_end_time']);
            $time_left = $end_time - $now;
            $days_left = floor($time_left / 86400);
            $hours_left = floor($time_left / 3600);
            if ($time_left > 0 && $time_left <= 259200) {
                $alerts[] = ['type' => 'popup', 'id' => $popup['nw_id'], 'title' => $popup['nw_subject'], 'end_time' => $popup['nw_end_time'], 'time_left' => $time_left, 'days_left' => $days_left, 'hours_left' => $hours_left, 'urgency' => $hours_left <= 24 ? 'critical' : 'warning'];
            }
        }
    }
    $banner_result = @sql_query("SELECT id, name, images FROM mainbanner");
    if ($banner_result) {
        while ($banner = sql_fetch_array($banner_result)) {
            if (!$banner['images']) continue;
            $images = json_decode($banner['images'], true);
            if (!is_array($images)) continue;
            foreach ($images as $idx => $img) {
                if (!isset($img['visible']) || !$img['visible']) continue;
                if (!isset($img['end_date']) || !$img['end_date']) continue;
                $end_time = strtotime($img['end_date'] . ' 23:59:59');
                $time_left = $end_time - $now;
                $days_left = floor($time_left / 86400);
                $hours_left = floor($time_left / 3600);
                if ($time_left > 0 && $time_left <= 259200) {
                    $alerts[] = ['type' => 'banner', 'id' => $banner['id'], 'title' => $banner['name'] . ' (이미지 ' . ($idx + 1) . ')', 'end_time' => $img['end_date'], 'time_left' => $time_left, 'days_left' => $days_left, 'hours_left' => $hours_left, 'urgency' => $hours_left <= 24 ? 'critical' : 'warning'];
                }
            }
        }
    }
    return $alerts;
}

$expiring_alerts = check_expiring_content();
$should_show_alert = false;
$filtered_alerts = [];
foreach ($expiring_alerts as $alert) {
    $cookie_name = 'alert_' . $alert['type'] . '_' . $alert['id'] . '_dismiss';
    $last_shown = isset($_COOKIE[$cookie_name]) ? (int)$_COOKIE[$cookie_name] : 0;
    $now = time();
    $interval = $alert['hours_left'] <= 24 ? 14400 : 86400;
    if ($now - $last_shown >= $interval) {
        $should_show_alert = true;
        $filtered_alerts[] = $alert;
    }
}
?>

<!-- 글래스모피즘 관리자 테마 — aside가 모든 매니저에 include되므로 여기서 한 번 로드하면 전역 적용 -->
<link rel="stylesheet" href="<?php echo $admin_root; ?>/css/admin_theme.css?ver=1">

<aside id="adm_aside">
    <div class="brand_area">
        <span class="brand_logo">
            <?php if (isset($dm_conf['cf_logo']) && $dm_conf['cf_logo']): ?>
                <img style="filter:brightness(100); max-width: 200px;" src="<?= G5_DATA_URL ?>/common/<?= $dm_conf['cf_logo'] ?>" alt="<?= $dm_conf['cf_site_name'] ?>" style="max-height:44px;">
            <?php else: ?>
                <?= $dm_conf['cf_site_name'] ?: 'AdminSystem' ?>
            <?php endif; ?>
        </span>
        <!-- <button type="button" class="toggle_btn" onclick="toggleSidebar()" title="사이드바 접기/펼치기">
            <span class="material-symbols-outlined" id="toggle_icon">menu_open</span>
        </button> -->
    </div>

    <?php if (count($expiring_alerts) > 0): ?>
        <div class="alert_badge_wrap" onclick="showExpiringAlerts()">
            <span class="material-symbols-outlined" style="font-size:18px;">notifications_active</span>
            <span class="alert_badge_text">만료 임박 알림</span>
            <span class="alert_badge_count"><?= count($expiring_alerts) ?></span>
        </div>
    <?php endif; ?>

    <nav class="nav_menu">
        <?php
        $menus = [
            ['/index.php', 'dashboard', '대시보드', [$admin_root . '/index.php']],
            ['/config/site_config.php', 'settings', '사이트 설정', [$admin_root . '/config/site_config.php', $admin_root . '/config/site_config_update.php']],

            // 🏥 병원 정보 — 병원 실체(의료진) + 그 스키마 출력(PSM) + 다국어
            ['#', 'local_hospital', '병원 정보', [], [
                ['/hospital/doctor_manager.php', 'medical_services', '의료진 관리', [$admin_root . '/hospital/doctor_manager.php']],
                ['/hospital/page_seo_manager.php', 'manufacturing', 'SEO·스키마 관리', [$admin_root . '/hospital/page_seo_manager.php']],
                ['/hospital/multilang_manager.php', 'translate', '다국어 관리', [$admin_root . '/hospital/multilang_manager.php']],
                ['/hospital/non_covered_manager.php', 'payments', '비급여 관리', [$admin_root . '/system/non_covered_manager.php']],
            ]],

            // 📝 게시판/텍스트 — 글로 작성하는 것
            ['#', 'article', '게시판/텍스트', [], [
                ['/board/board_manager.php', 'view_list', '게시판 설정', [$admin_root . '/board/board_manager.php', $admin_root . '/board/board_create_update.php', $admin_root . '/board/board_post_list.php', $admin_root . '/board/write_direct.php']],
                ['/board/column_admin.php', 'feed', '칼럼 관리', [$admin_root . '/board/column_admin.php']],
                ['/board/review_manager.php', 'reviews', '리뷰 관리', [$admin_root . '/board/review_manager.php']],
                ['/board/qa_manager.php', 'help', '문의 관리', [$admin_root . '/board/qa_manager.php']],
                ['/board/faq_manager.php', 'live_help', 'FAQ 관리', [$admin_root . '/board/faq_manager.php']],
            ]],

            // 🖼️ 콘텐츠/노출 — 화면에 보이는 콘텐츠 요소(+장비)
            ['#', 'perm_media', '콘텐츠/노출', [], [
                ['/content/banner_manager.php', 'panorama', '배너 관리', [$admin_root . '/content/banner_manager.php']],
                ['/content/slide_manager.php', 'slideshow', '슬라이드 관리', [$admin_root . '/content/slide_manager.php']],
                ['/content/popup_manager.php', 'aspect_ratio', '팝업 관리', [$admin_root . '/content/popup_manager.php', $admin_root . '/content/popup_form.php', $admin_root . '/content/popup_update.php']],
                ['/content/before_after_manager.php', 'compare_arrows', 'B/A 관리', [$admin_root . '/content/before_after_manager.php']],
                ['/content/blog_manager.php', 'rss_feed', '블로그/갤러리 관리', [$admin_root . '/content/blog_manager.php']],
                ['/content/device_manager.php', 'devices', '장비 관리', [$admin_root . '/content/device_manager.php']],
                ['/content/social_manager.php', 'devices', '유튜브/인스타 관리', [$admin_root . '/content/social_manager.php']],
                ['/content/parallax_manager.php', 'vertical_align_center', '패럴럭스 관리', [$admin_root . '/content/parallax_manager.php']],
            ]],

            // 🔍 검색 — 사이트 검색 기능
            ['#', 'travel_explore', '검색', [], [
                ['/search/smartsearch_manager.php', 'saved_search', '스마트 서치 관리', [$admin_root . '/search/smartsearch_manager.php']],
                ['/search/dict_manager.php', 'dictionary', '의학사전', [$admin_root . '/search/dict_manager.php']],
            ]],

            // 👥 운영 — 시스템/기타
            ['#', 'admin_panel_settings', '운영', [], [
                ['/member/member_manager.php', 'group', '회원 관리', [$admin_root . '/member/member_manager.php']],

                ['/backup/db_backup_manager.php', 'backup', 'DB백업 관리', [$admin_root . '/backup/db_backup_manager.php']],
            ]],
        ];

        foreach ($menus as $menu) {
            $has_submenu = isset($menu[4]) && !empty($menu[4]);
            $link_url = $menu[0] === '#' ? '#' : $admin_root . $menu[0];
            $active = '';
            if ($has_submenu) {
                foreach ($menu[4] as $submenu) {
                    if (in_array($current_full_path, $submenu[3])) {
                        $active = 'active';
                        break;
                    }
                }
            } else {
                $active = in_array($current_full_path, $menu[3]) ? 'active' : '';
            }

            if ($has_submenu) {
                echo "<div class='nav_group " . ($active ? 'open' : '') . "'>
                        <a href='javascript:void(0)' class='nav-link parent " . ($active ? 'active' : '') . "' onclick='toggleSubmenu(this)' title='{$menu[2]}'>
                            <span class='material-symbols-outlined'>{$menu[1]}</span>
                            <b>{$menu[2]}</b>
                            <span class='material-symbols-outlined submenu_arrow'>expand_more</span>
                        </a>
                        <div class='submenu'>";
                foreach ($menu[4] as $submenu) {
                    $sub_active = in_array($current_full_path, $submenu[3]) ? 'active' : '';
                    $sub_link = $admin_root . $submenu[0];
                    echo "<a href='{$sub_link}' class='nav-link sub {$sub_active}' title='{$submenu[2]}'>
                            <span class='material-symbols-outlined'>{$submenu[1]}</span>
                            <b>{$submenu[2]}</b>
                          </a>";
                }
                echo "</div></div>";
            } else {
                echo "<a href='{$link_url}' class='nav-link {$active}' title='{$menu[2]}'>
                        <span class='material-symbols-outlined'>{$menu[1]}</span>
                        <b>{$menu[2]}</b>
                      </a>";
            }
        }

        $logout_path = $admin_root . '/auth/logout.php';
        ?>

        <div class="nav_footer">
            <a href='<?= $logout_path ?>' class='nav-link logout_link' title='로그아웃'>
                <span class='material-symbols-outlined'>logout</span>
                <b>로그아웃</b>
            </a>
        </div>
    </nav>
</aside>

<!-- 만료 알림 모달 -->
<div id="expiringModal" class="expiring_modal">
    <div class="expiring_modal_inner">
        <div class="expiring_modal_hd">
            <h3>만료 임박 알림</h3>
            <button class="expiring_close_btn" onclick="closeExpiringModal()">✕</button>
        </div>
        <div class="expiring_modal_bd">
            <p style="font-size:13px; color:#9999bb; margin-bottom:16px;">다음 콘텐츠의 노출 기한이 임박했습니다:</p>
            <div id="alertList"></div>
        </div>
        <div class="expiring_modal_ft">
            <button onclick="dismissAllAlerts()">모두 확인</button>
        </div>
    </div>
</div>

<style>
    /* ── 사이드바 레이아웃 ── */
    #adm_aside {
        background: #1a1a2e;
        width: 220px;
        flex-shrink: 0;
        height: 100vh;
        position: fixed;
        left: 0;
        top: 0;
        display: flex;
        flex-direction: column;
        z-index: 1020;
        overflow: hidden;
        transition: width 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .brand_area {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0 16px;
        min-height: 68px;
        border-bottom: 1px solid #252540;
        flex-shrink: 0;
    }

    .brand_logo {
        font-size: 17px;
        font-weight: 900;
        color: #fff;
        letter-spacing: 0.5px;
        white-space: nowrap;
        overflow: hidden;
        transition: opacity 0.3s;
    }

    .toggle_btn {
        background: none;
        border: none;
        color: #9999bb;
        cursor: pointer;
        padding: 6px;
        display: flex;
        align-items: center;
        border-radius: 7px;
        transition: all 0.2s;
        flex-shrink: 0;
    }

    .toggle_btn:hover {
        background: #252540;
        color: #fff;
    }

    .toggle_btn .material-symbols-outlined {
        font-size: 20px;
    }

    /* 알림 배지 */
    .alert_badge_wrap {
        margin: 10px 14px;
        padding: 10px 14px;
        background: linear-gradient(135deg, #ef4444, #dc2626);
        border-radius: 10px;
        display: flex;
        align-items: center;
        gap: 8px;
        cursor: pointer;
        color: #fff;
        font-size: 12px;
        font-weight: 700;
        animation: pulse_alert 2s infinite;
        flex-shrink: 0;
    }

    .alert_badge_text {
        flex: 1;
    }

    .alert_badge_count {
        background: rgba(255, 255, 255, 0.25);
        padding: 2px 7px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 800;
    }

    @keyframes pulse_alert {

        0%,
        100% {
            box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.6);
        }

        50% {
            box-shadow: 0 0 0 7px rgba(239, 68, 68, 0);
        }
    }

    /* 네비 메뉴 */
    .nav_menu {
        flex: 1;
        padding: 16px 10px;
        overflow-y: auto;
        overflow-x: hidden;
        display: flex;
        flex-direction: column;
    }

    .nav_menu::-webkit-scrollbar {
        width: 4px;
    }

    .nav_menu::-webkit-scrollbar-thumb {
        background: #252540;
        border-radius: 4px;
    }

    .nav-link {
        display: flex !important;
        align-items: center !important;
        gap: 10px !important;
        padding: 11px 14px !important;
        color: #9999bb !important;
        border-radius: 10px !important;
        text-decoration: none !important;
        margin-bottom: 2px !important;
        transition: all 0.2s !important;
        font-size: 14px !important;
        font-weight: 500 !important;
        white-space: nowrap;
        overflow: hidden;
    }

    .nav-link .material-symbols-outlined {
        font-size: 18px !important;
        flex-shrink: 0 !important;
    }

    .nav-link b {
        font-weight: 500;
    }

    .nav-link:hover {
        background: #252540 !important;
        color: #fff !important;
    }

    .nav-link.active {
        background: #4f46e5 !important;
        color: #fff !important;
        box-shadow: 0 4px 12px rgba(79, 70, 229, 0.3);
    }

    /* 서브메뉴 */
    .nav_group {}

    .nav-link.parent {
        position: relative;
    }

    .submenu_arrow {
        position: absolute !important;
        right: 12px;
        font-size: 16px !important;
        transition: transform 0.3s;
        color: #9999bb !important;
    }

    .submenu {
        max-height: 0;
        overflow: hidden;
        transition: max-height 0.3s ease;
        background: rgba(0, 0, 0, 0.2);
        border-radius: 8px;
        margin: 2px 0;
    }

    .nav_group.open .submenu {
        max-height: 400px;
    }

    .nav_group.open .submenu_arrow {
        transform: rotate(180deg);
    }

    .nav-link.sub {
        padding-left: 44px !important;
        font-size: 13px !important;
    }

    .nav-link.sub .material-symbols-outlined {
        font-size: 16px !important;
    }

    /* 푸터(로그아웃) */
    .nav_footer {
        margin-top: auto;
        padding-top: 14px;
        border-top: 1px solid #252540;
    }

    .logout_link {
        color: rgba(255, 255, 255, 0.4) !important;
    }

    .logout_link:hover {
        background: #252540 !important;
        color: rgba(255, 255, 255, 0.7) !important;
    }

    /* 접힌 상태 */
    #adm_aside.collapsed {
        width: 64px;
    }

    #adm_aside.collapsed .brand_logo {
        opacity: 0;
        width: 0;
        pointer-events: none;
    }

    #adm_aside.collapsed .nav-link b,
    #adm_aside.collapsed .nav-link span:not(.material-symbols-outlined) {
        display: none;
    }

    #adm_aside.collapsed .nav-link {
        justify-content: center;
        padding: 11px 0 !important;
        gap: 0 !important;
    }

    #adm_aside.collapsed .submenu_arrow,
    #adm_aside.collapsed .submenu,
    #adm_aside.collapsed .alert_badge_wrap {
        display: none;
    }

    /* 만료 알림 모달 */
    .expiring_modal {
        display: none;
        position: fixed;
        inset: 0;
        background: rgba(0, 0, 0, 0.6);
        z-index: 10000;
        align-items: center;
        justify-content: center;
    }

    .expiring_modal.active {
        display: flex;
    }

    .expiring_modal_inner {
        background: #fff;
        border-radius: 14px;
        width: 90%;
        max-width: 580px;
        max-height: 80vh;
        overflow: hidden;
        display: flex;
        flex-direction: column;
        animation: modal_in 0.25s ease;
    }

    @keyframes modal_in {
        from {
            transform: translateY(-30px);
            opacity: 0;
        }

        to {
            transform: translateY(0);
            opacity: 1;
        }
    }

    .expiring_modal_hd {
        padding: 22px 24px;
        border-bottom: 1px solid #e8eaf0;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    .expiring_modal_hd h3 {
        margin: 0;
        font-size: 18px;
        font-weight: 700;
        color: #1a1a2e;
    }

    .expiring_close_btn {
        background: none;
        border: none;
        font-size: 22px;
        cursor: pointer;
        color: #9999bb;
        line-height: 1;
    }

    .expiring_close_btn:hover {
        color: #1a1a2e;
    }

    .expiring_modal_bd {
        padding: 20px 24px;
        overflow-y: auto;
        flex: 1;
    }

    .expiring_modal_ft {
        padding: 16px 24px;
        border-top: 1px solid #e8eaf0;
        text-align: center;
    }

    .expiring_modal_ft button {
        padding: 10px 32px;
        background: #4f46e5;
        color: #fff;
        border: none;
        border-radius: 8px;
        font-weight: 700;
        cursor: pointer;
        transition: all 0.2s;
    }

    .expiring_modal_ft button:hover {
        background: #4338ca;
    }

    .alert_item {
        padding: 14px 16px;
        margin-bottom: 10px;
        border-radius: 9px;
        border: 1px solid #e8eaf0;
    }

    .alert_item.critical {
        border-color: #fca5a5;
        background: #fff5f5;
    }

    .alert_item.warning {
        border-color: #fcd34d;
        background: #fffbeb;
    }

    .alert_item_hd {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 6px;
    }

    .alert_type_badge {
        padding: 3px 8px;
        border-radius: 5px;
        font-size: 11px;
        font-weight: 800;
    }

    .alert_type_badge.popup {
        background: #4f46e5;
        color: #fff;
    }

    .alert_type_badge.banner {
        background: #7c3aed;
        color: #fff;
    }

    .alert_item_title {
        font-weight: 700;
        font-size: 14px;
        color: #1a1a2e;
    }

    .alert_item_time {
        font-size: 12px;
        color: #9999bb;
        margin-bottom: 8px;
    }

    .alert_item_urgency {
        display: inline-block;
        padding: 4px 10px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 800;
    }

    .alert_item_urgency.critical {
        background: #ef4444;
        color: #fff;
    }

    .alert_item_urgency.warning {
        background: #f59e0b;
        color: #fff;
    }
</style>

<script>
    const expiringAlerts = <?= json_encode($filtered_alerts) ?>;
    const allAlerts = <?= json_encode($expiring_alerts) ?>;

    function toggleSubmenu(el) {
        const group = el.closest('.nav_group');
        group.classList.toggle('open');
    }

    function toggleSidebar() {
        const aside = document.getElementById('adm_aside');
        const icon = document.getElementById('toggle_icon');
        aside.classList.toggle('collapsed');
        const collapsed = aside.classList.contains('collapsed');
        icon.innerText = collapsed ? 'menu' : 'menu_open';
        localStorage.setItem('sidebar_collapsed', collapsed ? 'true' : 'false');
    }

    function showExpiringAlerts() {
        const list = document.getElementById('alertList');
        list.innerHTML = '';
        allAlerts.forEach(a => {
            const timeText = a.hours_left <= 24 ?
                a.hours_left + '시간 ' + Math.floor((a.time_left % 3600) / 60) + '분 남음' :
                a.days_left + '일 ' + Math.floor((a.time_left % 86400) / 3600) + '시간 남음';
            list.innerHTML += `<div class="alert_item ${a.urgency}">
            <div class="alert_item_hd">
                <span class="alert_type_badge ${a.type}">${a.type === 'popup' ? '팝업' : '배너'}</span>
                <span class="alert_item_title">${a.title}</span>
            </div>
            <div class="alert_item_time">종료: ${a.end_time}</div>
            <span class="alert_item_urgency ${a.urgency}">${a.urgency === 'critical' ? '긴급' : '주의'} — ${timeText}</span>
        </div>`;
        });
        document.getElementById('expiringModal').classList.add('active');
    }

    function closeExpiringModal() {
        document.getElementById('expiringModal').classList.remove('active');
    }

    function dismissAllAlerts() {
        allAlerts.forEach(a => {
            const name = 'alert_' + a.type + '_' + a.id + '_dismiss';
            const exp = new Date(Date.now() + (a.hours_left <= 24 ? 14400000 : 86400000));
            document.cookie = name + '=' + Date.now() + ';expires=' + exp.toUTCString() + ';path=/';
        });
        closeExpiringModal();
        const badge = document.querySelector('.alert_badge_wrap');
        if (badge) badge.style.display = 'none';
    }

    (function() {
        const aside = document.getElementById('adm_aside');
        const icon = document.getElementById('toggle_icon');
        if (localStorage.getItem('sidebar_collapsed') === 'true') {
            aside.classList.add('collapsed');
            icon.innerText = 'menu';
        }
        document.querySelectorAll('.nav_group').forEach(g => {
            if (g.querySelector('.nav-link.active')) g.classList.add('open');
        });
        if (expiringAlerts.length > 0) setTimeout(showExpiringAlerts, 500);
    })();

    document.getElementById('expiringModal').addEventListener('click', function(e) {
        if (e.target === this) closeExpiringModal();
    });
</script>