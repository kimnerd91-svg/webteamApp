<?php
include_once('../_common.php'); 
// include_once(G5_PATH.'/head_sub.php');

// ── 개발자 모드 허용 여부 ──
// 관리자(mb_level >= 10)가 "기본 1명"일 때만 개발자 모드 로그인 허용.
// 관리자가 추가(2명 이상)되면 보안상 개발자 우회 로그인 차단.
$admin_count = (int) (sql_fetch("SELECT COUNT(*) AS cnt FROM {$g5['member_table']} WHERE mb_level >= 10")['cnt'] ?? 0);
$dev_mode_allowed = ($admin_count <= 1);

// --- 자동 로그인 체크 로직 ---
if (!isset($_SESSION['ss_mb_id']) || !$_SESSION['ss_mb_id']) {
    if (isset($_COOKIE['adm_auto_login']) && $_COOKIE['adm_auto_login']) {
        $token = sql_real_escape_string($_COOKIE['adm_auto_login']);
        
        $sql = " SELECT * FROM {$g5['member_table']} WHERE mb_memo = '$token' AND mb_level >= 10 LIMIT 1 ";
        $row = sql_fetch($sql);

        if (isset($row['mb_id']) && $row['mb_id']) {
            set_session('ss_mb_id', $row['mb_id']);
            $_SESSION['adm_mb_id'] = $row['mb_id'];
            $_SESSION['adm_mb_name'] = $row['mb_name'];
            $_SESSION['adm_login_time'] = time();
            
            sql_query(" UPDATE {$g5['member_table']} SET mb_today_login = '".G5_TIME_YMDHIS."', mb_login_ip = '{$_SERVER['REMOTE_ADDR']}' WHERE mb_id = '{$row['mb_id']}' ");
            
            goto_url('/newadm/index.php');
        }
    }
}

// 이미 로그인되어 있으면 대시보드로
if(isset($_SESSION['adm_mb_id']) && $_SESSION['adm_mb_id']) {
    goto_url('/newadm/index.php');
}

$error_msg = '';

// 임시 관리자 로그인 (개발용)
if(isset($_GET['mode']) && $_GET['mode'] == 'dev_login') {
    // 관리자가 추가된 상태면 개발자 우회 로그인 차단 (URL 직접 접근 방어)
    if (!$dev_mode_allowed) {
        alert_toast('관리자가 등록되어 개발자 모드 로그인이 비활성화되었습니다.', '/newadm/auth/login.php', 'error');
        exit;
    }
    set_session('ss_mb_id', 'admin');
    $_SESSION['adm_mb_id'] = 'admin';
    $_SESSION['adm_mb_name'] = '관리자';
    $_SESSION['adm_login_time'] = time();
    goto_url('/newadm/index.php');
}

// 로그인 처리
if(isset($_POST['mode']) && $_POST['mode'] == 'login') {
    $mb_id = sql_real_escape_string(trim($_POST['mb_id']));
    $mb_password = trim($_POST['mb_password']);
    $auto_login = $_POST['auto_login'] ?? '';
    
    if(!$mb_id || !$mb_password) {
        $error_msg = '아이디와 비밀번호를 입력해주세요.';
    } else {
        $sql = " SELECT * FROM {$g5['member_table']} WHERE mb_id = '$mb_id' ";
        $row = sql_fetch($sql);
        
        if(!$row['mb_id']) {
            $error_msg = '존재하지 않는 아이디입니다.';
        } else if($row['mb_level'] < 10) {
            $error_msg = '관리자 권한이 없습니다. (Level 10 이상 필요)';
        } else {
            if(check_password($mb_password, $row['mb_password'])) {
                set_session('ss_mb_id', $row['mb_id']);
                $_SESSION['adm_mb_id'] = $row['mb_id'];
                $_SESSION['adm_mb_name'] = $row['mb_name'];
                $_SESSION['adm_login_time'] = time();
                
                if($auto_login == '1') {
                    $auto_login_token = md5($row['mb_id'].time().rand());
                    setcookie('adm_auto_login', $auto_login_token, time() + (86400 * 7), '/');
                    sql_query("UPDATE {$g5['member_table']} SET mb_memo = '$auto_login_token' WHERE mb_id = '$mb_id'");
                }
                
                sql_query(" UPDATE {$g5['member_table']} SET mb_today_login = '".G5_TIME_YMDHIS."', mb_login_ip = '{$_SERVER['REMOTE_ADDR']}' WHERE mb_id = '$mb_id' ");
                
                goto_url('/newadm/index.php');
            } else {
                $error_msg = '비밀번호가 일치하지 않습니다.';
            }
        }
    }
}

// 비밀번호 찾기 처리
if(isset($_POST['mode']) && $_POST['mode'] == 'reset_password') {
    $reset_email = sql_real_escape_string(trim($_POST['reset_email']));
    
    if(!$reset_email) {
        $error_msg = '이메일 주소를 입력해주세요.';
    } else {
        $sql = " SELECT mb_id, mb_name, mb_email FROM {$g5['member_table']} WHERE mb_email = '$reset_email' AND mb_level >= 10 ";
        $row = sql_fetch($sql);
        
        if(!$row['mb_id']) {
            $error_msg = '등록된 이메일 주소가 없거나 관리자 권한이 없습니다.';
        } else {
            $new_password = "0000";
            $hash_password = get_encrypt_string($new_password);
            
            sql_query(" UPDATE {$g5['member_table']} SET mb_password = '$hash_password' WHERE mb_id = '{$row['mb_id']}' ");
            
       alert_toast('비밀번호가 0000으로 리셋되었습니다.\n로그인 후 반드시 변경해주세요.', './login.php', 'success');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>관리자 로그인 - NEW ADM</title>
    <link rel="stylesheet" href="/css/setting.css">
    <link rel="stylesheet" href="/css/admin.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" />
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-card {
            width: 100%;
            max-width: 450px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.1);
        }
        .input-wrapper { position: relative; width: 100%; }
        .input-wrapper .material-symbols-outlined {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            z-index: 10;
            pointer-events: none;
        }
        .input-wrapper .u-input { padding-left: 48px !important; }
        .modal-overlay {
            display: none; position: fixed; top: 0; left: 0; 
            width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999;
            align-items: center; justify-content: center;
        }
        .adm-check-wrap { display: flex; align-items: center; gap: 10px; cursor: pointer; }
        .adm-checkbox {
            appearance: none; -webkit-appearance: none;
            width: 22px; height: 22px; border: 2px solid #dee2e6;
            border-radius: 6px; background-color: #fff;
            position: relative; cursor: pointer; margin: 0; transition: all 0.2s;
        }
        .adm-checkbox:checked { background-color: var(--main-color, #007bff); border-color: var(--main-color, #007bff); }
        .adm-checkbox:checked::after {
            content: "✔"; position: absolute; top: 50%; left: 50%;
            transform: translate(-50%, -50%); color: #fff; font-size: 14px;
        }
        .error-msg {
            background: #fee; border: 1px solid #fcc; color: #c33;
            padding: 12px; border-radius: 8px; margin-bottom: 16px; font-size: 14px;
        }
        .w-100 { width: 100%; }

        .u-input {
            max-width: calc(100% - 64px);
        }
    </style>
</head>
<body class="u-p-20">

    <div class="login-card u-bg-white rounded-24 u-p-40">
        <header class="text-center u-mb-36">
            <h1 class="u-txt-main fw-900 t-fs-32 u-mb-8">관리자 로그인</h1>
            <p class="u-txt-muted c-fs-14">NEW ADM 관리자 전용</p>
        </header>

        <?php if($error_msg) { ?>
        <div class="error-msg"><?php echo $error_msg; ?></div>
        <?php } ?>

        <form method="post" action="">
            <input type="hidden" name="mode" value="login">
            
            <div class="u-mb-16">
                <label class="d-block u-mb-8 fw-700 u-txt-title c-fs-14">아이디</label>
                <div class="input-wrapper">
                    <span class="material-symbols-outlined u-txt-gray-400">person</span>
                    <input type="text" name="mb_id" class="u-input" placeholder="관리자 아이디 입력" required autofocus>
                </div>
            </div>

            <div class="u-mb-16">
                <label class="d-block u-mb-8 fw-700 u-txt-title c-fs-14">비밀번호</label>
                <div class="input-wrapper">
                    <span class="material-symbols-outlined u-txt-gray-400">lock</span>
                    <input type="password" name="mb_password" class="u-input" placeholder="비밀번호 입력" required>
                </div>
            </div>

            <div class="d-flex a-center u-gap-8 u-mb-16">
                <label class="adm-check-wrap">
                    <input type="checkbox" name="auto_login" value="1" class="adm-checkbox">
                    <span class="adm-label c-fs-14">자동 로그인 (7일간 유지)</span>
                </label>
            </div>

            <button type="submit" class="u-btn u-btn-main u-w-full u-py-12 w-100 rounded-8 t-fs-16 fw-bold u-press u-mb-8">로그인</button>
            <button type="button" onclick="openResetModal()" class="u-txt-muted c-fs-14 fw-700 cursor-pointer" style="background:none; border:none; padding:10px 0; width:100%; text-align:center;">
                비밀번호를 잊으셨나요?
            </button>
            
            <?php if ($dev_mode_allowed): ?>
            <div class="u-mt-16 u-p-12 u-bg-soft rounded-8 text-center">
                <a href="?mode=dev_login" class="u-txt-gray-600 c-fs-13">🔧 개발자 모드 로그인 (테스트용)</a>
            </div>
            <?php endif; ?>
        </form>
    </div>

    <div class="modal-overlay" id="resetModal">
        <div class="u-bg-white rounded-16 u-p-40 u-w-full" style="max-width: 400px;">
            <h2 class="t-fs-20 fw-700 u-mb-16">비밀번호 찾기</h2>
            <p class="u-txt-muted c-fs-14 u-mb-20">비밀번호를 0000으로 리셋합니다.</p>
            <form method="post">
                <input type="hidden" name="mode" value="reset_password">
                <div class="u-mb-24">
                    <label class="d-block u-mb-8 fw-700 c-fs-14">이메일 주소</label>
                    <input type="email" name="reset_email" class="u-input" placeholder="example@email.com" required>
                </div>
                <div class="d-flex u-gap-12">
                    <button type="button" class="u-btn u-bg-gray-200 u-txt-body u-py-12 flex-grow-1 rounded-8 fw-600" onclick="closeResetModal()">취소</button>
                    <button type="submit" class="u-btn u-btn-main u-py-12 flex-grow-1 rounded-8 fw-600">리셋</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        const resetModal = document.getElementById('resetModal');
        const openResetModal = () => { resetModal.style.display = 'flex'; };
        const closeResetModal = () => { resetModal.style.display = 'none'; };
        resetModal.addEventListener('click', (e) => { if(e.target === resetModal) closeResetModal(); });
    </script>
</body>
</html>