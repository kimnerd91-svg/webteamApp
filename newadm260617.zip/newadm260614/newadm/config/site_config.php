<?php
include_once('../_common.php');
include_once('./_auth_check.php');

function _verify_extract($raw) {
    $raw = trim($raw);
    if ($raw === '') return '';
    if (stripos($raw, '<meta') !== false || stripos($raw, '&lt;meta') !== false) {
        $decoded = html_entity_decode($raw, ENT_QUOTES);
        preg_match_all('~content\s*=\s*"([^"]*)"~i', $decoded, $m1);
        preg_match_all("~content\s*=\s*'([^']*)'~i", $decoded, $m2);
        $all = array_merge($m1[1], $m2[1]);
        $cands = array();
        foreach ($all as $c) {
            $c = trim($c);
            if ($c !== '' && strpos($c,'<')===false && strpos($c,'>')===false && preg_match('/^[A-Za-z0-9._-]+$/', $c)) {
                $cands[] = $c;
            }
        }
        if ($cands) {
            usort($cands, function($a,$b){ return strlen($b)-strlen($a); });
            return $cands[0];
        }
        if ($all) return trim(end($all));
    }
    return $raw;
}

if ((int)$member['mb_level'] < 10) {
    alert('접근 권한이 없습니다.', '/newadm/index.php');
}

// ============================================================
// POST 처리 — 사이트맵 크롤러 생성
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'generate_sitemap') {
    header('Content-Type: application/json');
    set_time_limit(60);

    // 정식 도메인 우선 사용, 없으면 현재 서버 도메인
    $official_domain = isset($_POST['official_domain']) ? trim(stripslashes($_POST['official_domain'])) : '';
    if ($official_domain) {
        $site_url = rtrim($official_domain, '/');
        // 한글 도메인 → 퓨니코드 자동 변환
        // 예: https://산본중심치과.com → https://xn--h32bh6fmn5f2a570bb4b.com
        if (function_exists('idn_to_ascii') && preg_match('#^(https?://)(.+)$#i', $site_url, $m)) {
            $scheme_part = $m[1];
            $host_part   = $m[2];
            // 호스트에 비ASCII 문자가 있을 때만 변환
            if (preg_match('/[^\x00-\x7F]/', $host_part)) {
                $converted = idn_to_ascii($host_part, IDNA_DEFAULT, INTL_IDNA_VARIANT_UTS46);
                if ($converted !== false) {
                    $site_url = $scheme_part . $converted;
                }
            }
        }
    } else {
        $scheme   = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? 'https' : 'http';
        $host     = $_SERVER['HTTP_HOST'];
        $site_url = rtrim($scheme . '://' . $host, '/');
    }
    $max_urls = 300;   // 최대 수집 URL 수
    $max_depth = 3;    // 크롤 깊이

    // 제외할 패턴 (관리자, 로그인, 에셋 등)
    $exclude_patterns = array(
        '/newadm', '/adm', '/admin', '/wp-admin',
        '/login', '/logout', '/register',
        '/data/', '/plugin/', '/theme/', '/extend/',
        '.css', '.js', '.jpg', '.jpeg', '.png', '.gif', '.webp',
        '.svg', '.ico', '.pdf', '.zip', '.xml',
        'javascript:', 'mailto:', 'tel:', '#',
        '?recentposts=', '?p=', 'utm_', 'fbclid',
    );

    // 추가 제외 경로 (관리자가 설정)
    $exclude_raw = isset($_POST['sitemap_exclude']) ? stripslashes(trim($_POST['sitemap_exclude'])) : '';
    $extra_excludes = array_filter(array_map('trim', explode("\n", $exclude_raw)));
    $exclude_patterns = array_merge($exclude_patterns, $extra_excludes);

    // URL 정규화
    function normalize_url($url, $site_url) {
        $url = trim($url);
        if (!$url || $url === '/') return $site_url . '/';
        // 미치환 JS 템플릿 리터럴 제거 (예: ?id=${id})
        if (strpos($url, '${') !== false) return null;
        if (strpos($url, 'http') === 0) {
            if (strpos($url, $site_url) !== 0) return null;
            $path = substr($url, strlen($site_url));
            // 이중 슬래시 정리
            $path = preg_replace('#/+#', '/', $path);
            $norm = $site_url . rtrim($path, '/');
            // 홈 URL 통일 (슬래시 있는 버전으로)
            return ($norm === $site_url) ? $site_url . '/' : $norm;
        }
        if ($url[0] === '/') {
            // 이중 슬래시 정리
            $url = preg_replace('#/+#', '/', $url);
            $norm = $site_url . rtrim($url, '/');
            return ($norm === $site_url) ? $site_url . '/' : $norm;
        }
        return null;
    }

    // URL 제외 여부 확인
    function should_exclude($url, $patterns) {
        // 미치환 템플릿 리터럴은 항상 제외
        if (strpos($url, '${') !== false) return true;
        foreach ($patterns as $p) {
            if ($p && stripos($url, $p) !== false) return true;
        }
        return false;
    }

    // curl로 페이지 fetch
    function fetch_page($url) {
        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt_array($ch, array(
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_TIMEOUT        => 8,
                CURLOPT_MAXREDIRS      => 3,
                CURLOPT_USERAGENT      => 'SitemapBot/1.0',
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_HTTPHEADER     => array('Accept: text/html'),
            ));
            $body = curl_exec($ch);
            $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            return ($code >= 200 && $code < 400) ? $body : false;
        }
        // curl 없으면 file_get_contents
        $ctx = stream_context_create(array('http' => array(
            'timeout'     => 8,
            'user_agent'  => 'SitemapBot/1.0',
            'ignore_errors' => false,
        )));
        return @file_get_contents($url, false, $ctx);
    }

    // HTML에서 내부 링크 추출
    function extract_links($html, $site_url) {
        if (!$html) return array();
        $links = array();
        if (preg_match_all('/<a[^>]+href=["\']([^"\'#][^"\']*)["\'][^>]*>/i', $html, $m)) {
            foreach ($m[1] as $href) {
                $href = html_entity_decode(trim($href));
                $norm = normalize_url($href, $site_url);
                if ($norm) $links[] = $norm;
            }
        }
        return array_unique($links);
    }

    // ── 크롤링 시작 ─────────────────────────────────────────
    $queue    = array($site_url . '/');  // 크롤 대기열
    $visited  = array();                 // 이미 방문한 URL
    $found    = array();                 // 수집된 URL
    $depth_map = array($site_url . '/' => 0);

    while (!empty($queue) && count($found) < $max_urls) {
        $current = array_shift($queue);

        if (isset($visited[$current])) continue;
        $visited[$current] = true;

        if (should_exclude($current, $exclude_patterns)) continue;

        $current_depth = isset($depth_map[$current]) ? $depth_map[$current] : 0;

        $html = fetch_page($current);
        if ($html === false) continue;

        $found[$current] = true;

        if ($current_depth < $max_depth) {
            $links = extract_links($html, $site_url);
            foreach ($links as $link) {
                if (!isset($visited[$link]) && !should_exclude($link, $exclude_patterns)) {
                    if (!in_array($link, $queue)) {
                        $queue[] = $link;
                        $depth_map[$link] = $current_depth + 1;
                    }
                }
            }
        }
    }

    // ── XML 생성 ────────────────────────────────────────────
    $today    = date('Y-m-d');
    $url_list = array_keys($found);

    // 홈 우선 정렬
    usort($url_list, function($a, $b) use ($site_url) {
        if ($a === $site_url . '/') return -1;
        if ($b === $site_url . '/') return  1;
        return strcmp($a, $b);
    });

    $xml  = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
    foreach ($url_list as $u) {
        $priority = ($u === $site_url . '/') ? '1.0' : '0.8';
        $xml .= "  <url>\n";
        $xml .= "    <loc>" . htmlspecialchars($u, ENT_XML1) . "</loc>\n";
        $xml .= "    <lastmod>{$today}</lastmod>\n";
        $xml .= "    <changefreq>weekly</changefreq>\n";
        $xml .= "    <priority>{$priority}</priority>\n";
        $xml .= "  </url>\n";
    }
    $xml .= '</urlset>';

    $path = $_SERVER['DOCUMENT_ROOT'] . '/sitemap.xml';
    $ok   = file_put_contents($path, $xml);

    if ($ok !== false) {
        echo json_encode(array(
            'success' => true,
            'count'   => count($url_list),
            'urls'    => $url_list,
            'sitemap' => $site_url . '/sitemap.xml',
        ));
    } else {
        echo json_encode(array('success' => false, 'message' => '파일 쓰기 실패. 권한을 확인하세요. (' . $path . ')'));
    }
    exit;
}

// ============================================================
// POST 처리 — robots.txt 생성
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'generate_robots') {
    header('Content-Type: application/json');

    // 정식 도메인 우선 사용, 없으면 현재 서버 도메인
    $official_domain = isset($_POST['official_domain']) ? trim(stripslashes($_POST['official_domain'])) : '';
    if ($official_domain) {
        $site_url = rtrim($official_domain, '/');
        // 한글 도메인 → 퓨니코드 자동 변환
        if (function_exists('idn_to_ascii') && preg_match('#^(https?://)(.+)$#i', $site_url, $m)) {
            if (preg_match('/[^\x00-\x7F]/', $m[2])) {
                $converted = idn_to_ascii($m[2], IDNA_DEFAULT, INTL_IDNA_VARIANT_UTS46);
                if ($converted !== false) $site_url = $m[1] . $converted;
            }
        }
    } else {
        $scheme   = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? 'https' : 'http';
        $host     = $_SERVER['HTTP_HOST'];
        $site_url = rtrim($scheme . '://' . $host, '/');
    }

    $disallow_raw = isset($_POST['robots_disallow']) ? stripslashes(trim($_POST['robots_disallow'])) : '';
    $disallow_list = array_filter(array_map('trim', explode("\n", $disallow_raw)));

    $allow_raw = isset($_POST['robots_allow']) ? stripslashes(trim($_POST['robots_allow'])) : '';
    $allow_list = array_filter(array_map('trim', explode("\n", $allow_raw)));

    // robots.txt 생성
    $txt  = "# robots.txt - generated by site_config\n";
    $txt .= "# " . date('Y-m-d H:i:s') . "\n\n";

    // ── AI 인용 봇 명시 허용 (AI 답변 노출용) ──
    $citation_bots = array('ChatGPT-User', 'OAI-SearchBot', 'PerplexityBot', 'Claude-User', 'Claude-SearchBot', 'Google-Extended');
    foreach ($citation_bots as $bot) {
        $txt .= "User-agent: {$bot}\n";
        $txt .= "Allow: /\n";
        $txt .= "Disallow: /newadm/\n";
        $txt .= "Disallow: /adm/\n\n";
    }

    // ── 무의미/대역폭 낭비 봇 차단 ──
    $junk_bots = array('AhrefsBot', 'SemrushBot', 'MJ12bot', 'DotBot', 'DataForSeoBot', 'BLEXBot');
    foreach ($junk_bots as $bot) {
        $txt .= "User-agent: {$bot}\n";
        $txt .= "Disallow: /\n\n";
    }

    // ── 일반 크롤러 (네이버/구글 등) ──
    $txt .= "User-agent: *\n";

    // Allow 먼저
    foreach ($allow_list as $a) {
        $a = '/' . ltrim($a, '/');
        $txt .= "Allow: {$a}\n";
    }

    // 기본 Disallow (관리자, 데이터 폴더)
    $default_disallow = array('/newadm/', '/adm/', '/data/', '/plugin/', '/extend/');
    foreach ($default_disallow as $d) {
        $txt .= "Disallow: {$d}\n";
    }
    // 추가 Disallow
    foreach ($disallow_list as $d) {
        $d = '/' . ltrim($d, '/');
        $txt .= "Disallow: {$d}\n";
    }

    $txt .= "\nSitemap: {$site_url}/sitemap.xml\n";

    $path = $_SERVER['DOCUMENT_ROOT'] . '/robots.txt';
    $ok   = file_put_contents($path, $txt);

    if ($ok !== false) {
        echo json_encode(array('success' => true, 'content' => $txt, 'url' => $site_url . '/robots.txt'));
    } else {
        echo json_encode(array('success' => false, 'message' => '파일 쓰기 실패. 권한을 확인하세요. (' . $path . ')'));
    }
    exit;
}

// ============================================================
// POST 처리 (AJAX 저장)
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save') {

    function upload_config_file($file_key, $allowed = array('jpg','jpeg','png','gif','webp','ico','svg')) {
        if (!isset($_FILES[$file_key]) || $_FILES[$file_key]['error'] != 0) return null;
        $dir = G5_DATA_PATH . '/common/';
        if (!is_dir($dir)) mkdir($dir, 0755, true);
        $ext = strtolower(pathinfo($_FILES[$file_key]['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, $allowed)) return null;
        $fn = 'config_' . $file_key . '_' . time() . '.' . $ext;
        return move_uploaded_file($_FILES[$file_key]['tmp_name'], $dir . $fn) ? $fn : null;
    }

    $sets = array();

    $text_fields = array(
        'cf_site_name','cf_title','cf_description','cf_ga_id','cf_gtm_id',
        'cf_add_script','cf_add_body_script',
        'cf_company_name','cf_ceo_name','cf_business_number','cf_tel',
        'cf_slogan',
        'cf_address','cf_lat','cf_lng',
        'cf_naver_booking','cf_naver_talk','cf_kakao','cf_blog','cf_instagram',
'cf_google_business','cf_sns_extra',
        'cf_kakao_rest_key','cf_kakao_client_secret',
        'cf_naver_client_id','cf_naver_secret','cf_google_client_id',
        'cf_privacy_policy','cf_terms',
        'cf_gsc_verification', 'cf_naver_verification',
        'cf_sitemap_urls', 'cf_robots_disallow', 'cf_robots_allow',
        'cf_city','cf_open_time','cf_close_time','cf_sat_open','cf_sat_close',
        'cf_youtube','cf_night_days','cf_night_open','cf_night_close',
        'cf_lunch_open','cf_lunch_close','cf_address_detail', 'cf_address_add','cf_address_base',
        'cf_founded_year', 'cf_expertise', 'cf_global_faq',
        'cf_official_domain', 'cf_canonical_base',
'cf_gsc_site_url',    'cf_site_status', 'cf_hours_override',
'cf_sido', 'cf_sigungu',
    );
    // ── 인증 입력값에서 content 코드만 추출 (양방향, _verify_extract 재사용) ──
    function extract_verification_content($raw) { return _verify_extract(trim($raw)); }
    // ── 헬퍼: 전화번호 하이픈 정규화 ──
    function format_tel($raw) {
        $d = preg_replace('/[^0-9]/', '', $raw);
        if ($d === '') return '';
        if (strpos($d, '02') === 0) {
            if (strlen($d) === 10) return substr($d,0,2).'-'.substr($d,2,4).'-'.substr($d,6,4);
            if (strlen($d) === 9)  return substr($d,0,2).'-'.substr($d,2,3).'-'.substr($d,5,4);
        } else {
            if (strlen($d) === 11) return substr($d,0,3).'-'.substr($d,3,4).'-'.substr($d,7,4);
            if (strlen($d) === 10) return substr($d,0,3).'-'.substr($d,3,3).'-'.substr($d,6,4);
        }
        return $raw;
    }
    // ── 헬퍼: 사업자등록번호 하이픈 정규화 ──
    function format_biznum($raw) {
        $d = preg_replace('/[^0-9]/', '', $raw);
        if (strlen($d) === 10) return substr($d,0,3).'-'.substr($d,3,2).'-'.substr($d,5,5);
        return $raw;
    }
    foreach ($text_fields as $f) {
        $val = isset($_POST[$f]) ? stripslashes($_POST[$f]) : '';
        if ($f === 'cf_gsc_verification' || $f === 'cf_naver_verification') $val = extract_verification_content($val);
        if ($f === 'cf_tel')             $val = format_tel($val);
        if ($f === 'cf_business_number') $val = format_biznum($val);
        $sets[] = "`{$f}` = '" . sql_real_escape_string($val) . "'";
    }

    $sets[] = "`cf_social_login_use` = " . (isset($_POST['cf_social_login_use']) ? 1 : 0);

    $logo_new = upload_config_file('logo_file');
    if ($logo_new) $sets[] = "`cf_logo` = '" . sql_real_escape_string($logo_new) . "'";

    $favicon_new = upload_config_file('favicon_file');
    if ($favicon_new) $sets[] = "`cf_favicon` = '" . sql_real_escape_string($favicon_new) . "'";

    $og_new = upload_config_file('og_file');
    if ($og_new) $sets[] = "`cf_og_image` = '" . sql_real_escape_string($og_new) . "'";

    // 행이 없으면 먼저 INSERT, 있으면 UPDATE
    $exist = sql_fetch("SELECT cf_id FROM dm_config WHERE cf_id = 1");
    if (!$exist) {
        sql_query("INSERT INTO dm_config (cf_id) VALUES (1)");
    }
    sql_query("UPDATE dm_config SET " . implode(', ', $sets) . " WHERE cf_id = 1");

    header('Content-Type: application/json');
    echo json_encode(array('success' => true));
    exit;
}

// ============================================================
// 컬럼 자동 생성
// ============================================================
$columns = array(
    'cf_og_image'            => "varchar(255) DEFAULT ''",
    'cf_favicon'             => "varchar(255) DEFAULT ''",
    'cf_logo'                => "varchar(255) DEFAULT ''",
    'cf_site_name'           => "varchar(255) DEFAULT ''",
    'cf_company_name'        => "varchar(255) DEFAULT ''",
    'cf_ceo_name'            => "varchar(100) DEFAULT ''",
    'cf_business_number'     => "varchar(50)  DEFAULT ''",
    'cf_tel'                 => "varchar(50)  DEFAULT ''",
    'cf_address'             => "varchar(500) DEFAULT ''",
    'cf_lat'                 => "varchar(50)  DEFAULT ''",
    'cf_lng'                 => "varchar(50)  DEFAULT ''",
    'cf_privacy_policy'      => "longtext",
    'cf_terms'               => "longtext",
    'cf_naver_booking'       => "varchar(500) DEFAULT ''",
    'cf_naver_talk'          => "varchar(500) DEFAULT ''",
    'cf_kakao'               => "varchar(500) DEFAULT ''",
    'cf_blog'                => "varchar(500) DEFAULT ''",
    'cf_instagram'           => "varchar(500) DEFAULT ''",
    'cf_kakao_rest_key'      => "varchar(255) DEFAULT ''",
    'cf_kakao_client_secret' => "varchar(255) DEFAULT ''",
    'cf_naver_client_id'     => "varchar(255) DEFAULT ''",
    'cf_naver_secret'        => "varchar(255) DEFAULT ''",
    'cf_google_client_id'    => "varchar(255) DEFAULT ''",
    'cf_social_login_use'    => "tinyint(4)   DEFAULT '0'",
    'cf_ga_id'               => "varchar(50)  DEFAULT ''",
    'cf_gtm_id'              => "varchar(50)  DEFAULT ''",
    // [변경] cf_ga4_property_id 제거 — cf_ga_id(G-XXXXXXX)와 중복
    // [변경] cf_gsc_verification: 전체 <meta> 태그 저장 → text 타입
    'cf_gsc_verification'    => "text",
    // [변경] cf_naver_verification: 전체 <meta> 태그 저장 → text 타입
    'cf_naver_verification'  => "text",
    'cf_add_script'          => "text",
    'cf_add_body_script'     => "text",
    'cf_sitemap_urls'        => "text",
    'cf_robots_disallow'     => "text",
    'cf_robots_allow'        => "text",
    'cf_city'                => "varchar(100) DEFAULT ''",
    'cf_open_time'           => "varchar(10)  DEFAULT '09:00'",
    'cf_close_time'          => "varchar(10)  DEFAULT '18:00'",
    'cf_sat_open'            => "varchar(10)  DEFAULT '09:00'",
    'cf_sat_close'           => "varchar(10)  DEFAULT '13:00'",
    'cf_youtube'             => "varchar(500) DEFAULT ''",
    'cf_night_days'          => "varchar(100) DEFAULT ''",
    'cf_night_open'          => "varchar(10)  DEFAULT ''",
    'cf_night_close'         => "varchar(10)  DEFAULT ''",
    'cf_lunch_open'  => "varchar(10)  DEFAULT '13:00'",
'cf_lunch_close' => "varchar(10)  DEFAULT '14:00'",
'cf_address_detail' => "varchar(255) DEFAULT ''",
'cf_address_add'    => "varchar(255) DEFAULT ''",
'cf_address_base'   => "varchar(255) DEFAULT ''",
    'cf_founded_year'    => "varchar(4)   DEFAULT ''",
    'cf_slogan'          => "varchar(255) DEFAULT ''",   // 병원 정체성 한 줄 → Dentist slogan (GEO)
    'cf_expertise'       => "text",
    'cf_global_faq'      => "longtext",
    'cf_official_domain'  => "varchar(255) DEFAULT ''",
    'cf_canonical_base'   => "varchar(255) DEFAULT ''",
    'cf_google_business'     => "varchar(500) DEFAULT ''",
'cf_sns_extra'           => "text",
'cf_gsc_site_url'     => "varchar(255) DEFAULT ''",
'cf_site_status' => "varchar(20) DEFAULT 'dev'",   // dev=제작중, live=운영중
'cf_hours_override'  => "text",   // 예외 진료시간 JSON (요일별 오버라이드)
    'cf_sido'            => "varchar(40)  DEFAULT ''",   // 시/도 → addressRegion
    'cf_sigungu'         => "varchar(40)  DEFAULT ''",   // 시/군/구 → addressLocality
);
foreach ($columns as $col => $type) {
    $check = sql_query("SHOW COLUMNS FROM `dm_config` LIKE '$col'");
    if (sql_num_rows($check) == 0) {
        sql_query("ALTER TABLE `dm_config` ADD `$col` $type");
    }
}

$dm_conf = sql_fetch("SELECT * FROM dm_config WHERE cf_id = 1");
if (!$dm_conf) {
    sql_query("INSERT INTO dm_config (cf_id) VALUES (1)");
    $dm_conf = sql_fetch("SELECT * FROM dm_config WHERE cf_id = 1");
}
// 헬퍼: Gnuboard addslashes 자동적용 → DB값 표시 시 항상 stripslashes 처리
function cf_val($v) { return htmlspecialchars(stripslashes($v ?? '')); }
// 인증 태그 표시용: 이미 전체 <meta> 태그로 깨져 저장된 값이어도 content 코드값만 뽑아 표시
// (저장 시 extract_verification_content로 정리되지만, 과거 깨진 값도 화면엔 깔끔히 보이게)
function cf_verify_val($v) { return htmlspecialchars(_verify_extract(stripslashes($v ?? ''))); }
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>사이트 기본정보 관리</title>
    <script src="//t1.daumcdn.net/mapjsapi/bundle/postcode/prod/postcode.v2.js"></script>
    <script src="//dapi.kakao.com/v2/maps/sdk.js?appkey=YOUR_KAKAO_API_KEY&libraries=services"></script>
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Pretendard', 'Apple SD Gothic Neo', sans-serif; background: #f5f6fa; color: #1a1a2e; }
        #admin_wrapper { display: flex; min-height: 100vh; }
        .content_area { flex: 1; padding: 40px 40px 120px; overflow-x: hidden; }
        .page_title { font-size: 22px; font-weight: 700; color: #1a1a2e; margin-bottom: 28px; }

        .section_card { background: #fff; border-radius: 12px; box-shadow: 0 2px 12px rgba(0,0,0,0.06); border: 1px solid #e8eaf0; padding: 28px; margin-bottom: 20px; }
        .section_hd { display: flex; align-items: center; gap: 14px; margin-bottom: 24px; }
        .section_icon { width: 42px; height: 42px; border-radius: 10px; background: #ede9fe; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
        .section_icon .material-symbols-outlined { font-size: 20px; color: #4f46e5; }
        .section_hd_txt h3 { font-size: 16px; font-weight: 700; color: #1a1a2e; }
        .section_hd_txt p  { font-size: 12px; color: #9999bb; margin-top: 2px; }

        .form_grid { display: grid; grid-template-columns: 1fr 1fr; gap: 18px; margin-bottom: 18px; }
        .form_group { margin-bottom: 18px; }
        .form_group label { display: block; font-size: 13px; font-weight: 700; color: #1a1a2e; margin-bottom: 7px; }
        .form_group small { display: block; font-size: 11px; color: #9999bb; margin-top: 5px; }
        input[type="text"], textarea, select { width: 100%; border: 1px solid #e8eaf0; border-radius: 8px; padding: 0 14px; font-size: 14px; background: #f5f6fa; color: #1a1a2e; transition: all 0.2s; }
        input[type="text"] { height: 44px; }
        textarea { padding: 12px 14px; resize: vertical; }
        input:focus, textarea:focus, select:focus { outline: none; border-color: #4f46e5; background: #fff; box-shadow: 0 0 0 3px rgba(79,70,229,0.1); }
        input[type="file"] { width: 100%; padding: 9px 14px; border: 1px dashed #e8eaf0; border-radius: 8px; background: #f5f6fa; font-size: 13px; cursor: pointer; }
        input[type="file"]:hover { border-color: #4f46e5; background: #ede9fe; }
        .preview_img { display: block; margin-top: 8px; border-radius: 7px; border: 1px solid #e8eaf0; padding: 6px; background: #f5f6fa; }

        .addr_row { display: flex; gap: 10px; margin-bottom: 10px; }
        .addr_row input { flex: 1; }
        .btn_addr { height: 44px; padding: 0 16px; background: #4f46e5; color: #fff; border: none; border-radius: 8px; font-size: 13px; font-weight: 700; cursor: pointer; white-space: nowrap; flex-shrink: 0; transition: all 0.2s; }
        .btn_addr:hover { background: #4338ca; }

        .social_box { border: 1px solid #e8eaf0; border-radius: 9px; padding: 18px; margin-bottom: 16px; }
        .social_box > label { display: flex; align-items: center; gap: 8px; font-size: 14px; font-weight: 700; margin-bottom: 14px; }
        .social_box > label img { height: 18px; }

        .info_box { background: #f5f6fa; border-radius: 8px; padding: 14px 16px; font-size: 12px; color: #5c5c7a; line-height: 1.7; }
        .info_box code { background: #ede9fe; color: #4f46e5; padding: 2px 6px; border-radius: 4px; font-size: 12px; }

        .checkbox_row { display: flex; align-items: center; gap: 10px; padding: 13px 16px; background: #f5f6fa; border-radius: 9px; margin-bottom: 18px; }
        .checkbox_row label { font-size: 14px; font-weight: 700; cursor: pointer; }
        .checkbox_row input[type="checkbox"] { width: auto; height: auto; cursor: pointer; }

        .label_with_btn { display: flex; align-items: center; justify-content: space-between; margin-bottom: 7px; }
        .label_with_btn span { font-size: 13px; font-weight: 700; color: #1a1a2e; }
        .btn_schema { display: inline-flex; align-items: center; gap: 6px; padding: 7px 14px; background: #4f46e5; color: #fff; border: none; border-radius: 7px; font-size: 12px; font-weight: 700; cursor: pointer; transition: all 0.2s; }
        .btn_schema:hover { background: #4338ca; }
        .btn_schema .material-symbols-outlined { font-size: 14px; }

        .btn_sitemap { display: inline-flex; align-items: center; gap: 6px; padding: 7px 14px; background: #059669; color: #fff; border: none; border-radius: 7px; font-size: 12px; font-weight: 700; cursor: pointer; transition: all 0.2s; }
        .btn_sitemap:hover { background: #047857; }
        .btn_sitemap:disabled { opacity: 0.6; cursor: not-allowed; }
        .sitemap_result { display: none; margin-top: 12px; padding: 12px 16px; background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 8px; font-size: 13px; color: #166534; }
        .sitemap_result a { color: #059669; font-weight: 700; }
        .sitemap_result.error { background: #fef2f2; border-color: #fecaca; color: #dc2626; }
        .btn_save { padding: 13px 48px; background: #4f46e5; color: #fff; border: none; border-radius: 10px; font-size: 15px; font-weight: 700; cursor: pointer; box-shadow: 0 4px 16px rgba(79,70,229,0.3); transition: all 0.2s; }
        .btn_save:hover { background: #4338ca; transform: translateY(-1px); }
        .btn_save:disabled { opacity: 0.6; cursor: not-allowed; transform: none; }

        .toast_cfg { position: fixed; bottom: 76px; left: 50%; transform: translateX(-50%); padding: 12px 28px; border-radius: 50px; font-size: 14px; font-weight: 700; color: #fff; z-index: 99999; opacity: 0; transition: opacity .3s; pointer-events: none; white-space: nowrap; }
        .toast_cfg.show { opacity: 1; }
        .toast_cfg.success { background: #10b981; }
        .toast_cfg.error   { background: #ef4444; }
    </style>
</head>
<body>
<div id="admin_wrapper">
    <?php include_once('../aside.php'); ?>

    <main class="content_area">
        <h2 class="page_title">사이트 기본정보 관리</h2>

        <form id="siteConfigForm" enctype="multipart/form-data">

            <!-- ① SEO Part 1: 기본 노출 정보 -->
            <div class="section_card">
                <div class="section_hd">
                    <div class="section_icon"><span class="material-symbols-outlined">search</span></div>
                    <div class="section_hd_txt"><h3>SEO 및 검색 최적화</h3><p>네이버·구글 검색 노출을 위한 메타 정보</p></div>
                </div>
                <div class="form_grid">
                    <div class="form_group"><label>사이트 공식 명칭</label><input type="text" name="cf_site_name" value="<?= cf_val($dm_conf['cf_site_name'] ?? '') ?>" placeholder="예: 연세세브란스치과"></div>
                    <div class="form_group"><label>브라우저 타이틀 (Title Tag)</label><input type="text" name="cf_title" value="<?= cf_val($dm_conf['cf_title'] ?? '') ?>" placeholder="검색 결과에 표시될 제목"></div>
                </div>
                <div class="form_group">
                    <label>사이트 설명 (Meta Description)</label>
                    <textarea name="cf_description" rows="4" placeholder="검색 결과 아래에 표시되는 설명글"><?= cf_val($dm_conf['cf_description'] ?? '') ?></textarea>
                </div>
                <div class="form_group">
                    <label>사이트 로고</label>
                    <input type="file" name="logo_file" accept=".png,.jpg,.jpeg,.svg">
                    <?php if (!empty($dm_conf['cf_logo'])): ?>
                    <img src="<?= G5_DATA_URL ?>/common/<?= cf_val($dm_conf['cf_logo'] ?? '') ?>" style="max-height:52px;" class="preview_img">
                    <?php endif; ?>
                    <small>권장: 가로 200px 이상 PNG 또는 SVG</small>
                </div>
                <div class="form_grid">
                    <div class="form_group">
                        <label>파비콘 (Favicon)</label>
                        <input type="file" name="favicon_file" accept=".ico,.png,.svg">
                        <?php if (!empty($dm_conf['cf_favicon'])): ?>
                        <img src="<?= G5_DATA_URL ?>/common/<?= cf_val($dm_conf['cf_favicon'] ?? '') ?>" style="height:28px;" class="preview_img">
                        <?php endif; ?>
                        <small>권장: 32×32 px</small>
                    </div>
                    <div class="form_group">
                        <label>SNS 공유 이미지 (Open Graph)</label>
                        <input type="file" name="og_file" accept="image/*">
                        <?php if (!empty($dm_conf['cf_og_image'])): ?>
                        <img src="<?= G5_DATA_URL ?>/common/<?= cf_val($dm_conf['cf_og_image'] ?? '') ?>" style="height:40px; border-radius:6px;" class="preview_img">
                        <?php endif; ?>
                        <small>권장: 1200×630 px</small>
                    </div>
                </div>
  <div class="form_group">
    <label>사이트 공개 상태 <small style="font-weight:400;color:#9999bb;">— 제작중이면 검색 노출 차단(noindex)</small></label>
    <select name="cf_site_status" style="height:44px;">
        <option value="dev"  <?= ($dm_conf['cf_site_status'] ?? 'dev')==='dev'  ? 'selected' : '' ?>>🚧 제작중 (검색 노출 차단)</option>
        <option value="live" <?= ($dm_conf['cf_site_status'] ?? '')==='live' ? 'selected' : '' ?>>✅ 운영중 (검색 노출 허용)</option>
    </select>
    <small><strong>제작중</strong>: noindex로 검색엔진 색인 차단 · <strong>운영중</strong>: 정상 노출. 오픈 시 '운영중'으로 변경하세요.</small>
</div>
            </div>

            <!-- ② 회사 정보 -->
            <div class="section_card">
                <div class="section_hd">
                    <div class="section_icon"><span class="material-symbols-outlined">business</span></div>
                    <div class="section_hd_txt"><h3>회사 정보</h3><p>푸터 영역에 표시될 사업자 정보</p></div>
                </div>
                <div class="form_grid">
                    <div class="form_group"><label>회사명 / 상호</label><input type="text" name="cf_company_name" value="<?= cf_val($dm_conf['cf_company_name'] ?? '') ?>" placeholder="(주)연세세브란스"></div>
                    <div class="form_group"><label>대표자명</label><input type="text" name="cf_ceo_name" value="<?= cf_val($dm_conf['cf_ceo_name'] ?? '') ?>" placeholder="홍길동"></div>
                </div>
                <div class="form_grid">
                    <div class="form_group"><label>사업자등록번호</label><input type="text" name="cf_business_number" id="cf_business_number" value="<?= cf_val($dm_conf['cf_business_number'] ?? '') ?>" placeholder="123-45-67890" maxlength="12"></div>
                    <div class="form_group">
                        <label style="display:flex; align-items:center; gap:6px;">개원연도 <small style="font-weight:400;color:#9999bb; white-space:nowrap;">— 구글 스키마 foundingDate용</small></label>
                        <input type="text" name="cf_founded_year" value="<?= cf_val($dm_conf['cf_founded_year'] ?? '') ?>" placeholder="2015" maxlength="4">
                        <small>4자리 연도. 구글 LocalBusiness 스키마에 자동 반영됩니다.</small>
                    </div>
                </div>
                <div class="form_group">
                    <label style="display:flex; align-items:center; gap:6px;">
                        병원 정체성 한 줄 (슬로건)
                        <small style="font-weight:400; color:#9999bb; white-space:nowrap;">— 스키마 slogan · GEO 브랜딩 핵심</small>
                    </label>
                    <input type="text" name="cf_slogan" value="<?= cf_val($dm_conf['cf_slogan'] ?? '') ?>" placeholder="예: 자연치아를 살리는 치과 · 디지털 임플란트 특화">
                    <small>AI가 "이 병원 = ___"으로 기억할 한 문장. 시술 나열이 아니라 <strong>차별 정체성</strong>을 적으세요. Dentist 스키마 slogan에 자동 반영됩니다.</small>
                </div>
                <div class="form_group">
                    <label style="display:flex; align-items:center; gap:6px;">
                        전문 진료
                        <small style="font-weight:400; color:#9999bb; white-space:nowrap;">— 스키마 knowsAbout · GEO / E-E-A-T 자동 반영</small>
                    </label>
                    <div id="expertise_chip_wrap" style="display:flex; flex-wrap:wrap; gap:8px; padding:10px 14px; border:1px solid #e8eaf0; border-radius:8px; background:#f5f6fa; min-height:48px; cursor:text;" onclick="document.getElementById('expertise_input').focus()">
                        <span id="expertise_chip_list" style="display:contents;"></span>
                        <input type="text" id="expertise_input" placeholder="진료명 입력 후 Enter" style="border:none; background:transparent; outline:none; font-size:14px; min-width:160px; flex:1; padding:2px 0;">
                    </div>
                    <input type="hidden" name="cf_expertise" id="cf_expertise_hidden" value="<?= cf_val($dm_conf['cf_expertise'] ?? '') ?>">
                    <small>진료 항목을 입력하고 Enter. 예: <em>미세현미경치료</em> · <em>심미접착수복</em> · <em>임플란트</em> → 스키마 자동생성 시 knowsAbout에 반영됩니다.</small>
                </div>
                <style>
                    .expertise-chip { display:inline-flex; align-items:center; gap:5px; background:#4f46e5; color:#fff; font-size:12px; font-weight:600; padding:4px 10px; border-radius:20px; }
                    .expertise-chip button { background:none; border:none; color:rgba(255,255,255,0.7); cursor:pointer; font-size:14px; line-height:1; padding:0; }
                    .expertise-chip button:hover { color:#fff; }
                </style>
                <div class="form_group">
                    <label>대표전화</label>
                    <input type="text" name="cf_tel" id="cf_tel" value="<?= cf_val($dm_conf['cf_tel'] ?? '') ?>" placeholder="02-1234-5678" maxlength="13">
                </div>
                <div class="form_group">
                    <label>주소</label>
                    <div class="addr_row">
                        <input type="text" id="address" value="<?= cf_val($dm_conf['cf_address_base'] ?? '') ?>" placeholder="주소 검색" readonly>
                        <button type="button" onclick="searchAddress()" class="btn_addr">주소 검색</button>
                    </div>
                    <input type="text" id="address_detail" name="cf_address_detail" value="<?= cf_val($dm_conf['cf_address_detail'] ?? '') ?>" placeholder="상세주소 (예: 3층, 101호)" style="margin-bottom:6px;">
                    <input type="text" id="address_add" name="cf_address_add" value="<?= cf_val($dm_conf['cf_address_add'] ?? '') ?>" placeholder="추가 안내 (선택 — 예: 산본역 3번 출구 앞)" style="margin-bottom:6px;">
                    <input type="hidden" name="cf_address_base" id="cf_address_base" value="<?= cf_val($dm_conf['cf_address_base'] ?? '') ?>">
                    <input type="hidden" name="cf_address" id="cf_address_full" value="<?= cf_val($dm_conf['cf_address'] ?? '') ?>">
                    <input type="hidden" name="cf_lat" id="cf_lat" value="<?= cf_val($dm_conf['cf_lat'] ?? '') ?>">
                    <input type="hidden" name="cf_lng" id="cf_lng" value="<?= cf_val($dm_conf['cf_lng'] ?? '') ?>">
                    <small>주소 검색 시 지도 좌표(위도/경도)가 자동 저장됩니다.</small>
                </div>
                <div class="form_group">
                    <label>지역 (시/도 · 시군구) <small style="font-weight:400;color:#9999bb;">— 구글 로컬 검색·JSON-LD addressRegion/addressLocality에 사용</small></label>
                    <div style="display:flex; gap:10px;">
                        <select name="cf_sido" id="cf_sido" style="flex:1; height:44px;">
                            <option value="">시/도 선택</option>
                        </select>
                        <select name="cf_sigungu" id="cf_sigungu" style="flex:1; height:44px;">
                            <option value="">시/군/구 선택</option>
                        </select>
                    </div>
                    <input type="hidden" name="cf_city" id="cf_city_legacy" value="<?= cf_val($dm_conf['cf_city'] ?? '') ?>">
                    <small>표준 행정구역에서 선택하면 데이터가 정확히 저장됩니다. (기존 자유입력값: <?= cf_val($dm_conf['cf_city'] ?? '') ?: '없음' ?>)</small>
                    <script>
                    (function(){
                        var REGIONS = {
"서울특별시":["종로구","중구","용산구","성동구","광진구","동대문구","중랑구","성북구","강북구","도봉구","노원구","은평구","서대문구","마포구","양천구","강서구","구로구","금천구","영등포구","동작구","관악구","서초구","강남구","송파구","강동구"],
"부산광역시":["중구","서구","동구","영도구","부산진구","동래구","남구","북구","해운대구","사하구","금정구","강서구","연제구","수영구","사상구","기장군"],
"대구광역시":["중구","동구","서구","남구","북구","수성구","달서구","달성군","군위군"],
"인천광역시":["중구","동구","미추홀구","연수구","남동구","부평구","계양구","서구","강화군","옹진군"],
"광주광역시":["동구","서구","남구","북구","광산구"],
"대전광역시":["동구","중구","서구","유성구","대덕구"],
"울산광역시":["중구","남구","동구","북구","울주군"],
"세종특별자치시":["세종특별자치시"],
"경기도":["수원시","성남시","의정부시","안양시","부천시","광명시","평택시","동두천시","안산시","고양시","과천시","구리시","남양주시","오산시","시흥시","군포시","의왕시","하남시","용인시","파주시","이천시","안성시","김포시","화성시","광주시","양주시","포천시","여주시","연천군","가평군","양평군"],
"강원특별자치도":["춘천시","원주시","강릉시","동해시","태백시","속초시","삼척시","홍천군","횡성군","영월군","평창군","정선군","철원군","화천군","양구군","인제군","고성군","양양군"],
"충청북도":["청주시","충주시","제천시","보은군","옥천군","영동군","증평군","진천군","괴산군","음성군","단양군"],
"충청남도":["천안시","공주시","보령시","아산시","서산시","논산시","계룡시","당진시","금산군","부여군","서천군","청양군","홍성군","예산군","태안군"],
"전북특별자치도":["전주시","군산시","익산시","정읍시","남원시","김제시","완주군","진안군","무주군","장수군","임실군","순창군","고창군","부안군"],
"전라남도":["목포시","여수시","순천시","나주시","광양시","담양군","곡성군","구례군","고흥군","보성군","화순군","장흥군","강진군","해남군","영암군","무안군","함평군","영광군","장성군","완도군","진도군","신안군"],
"경상북도":["포항시","경주시","김천시","안동시","구미시","영주시","영천시","상주시","문경시","경산시","의성군","청송군","영양군","영덕군","청도군","고령군","성주군","칠곡군","예천군","봉화군","울진군","울릉군"],
"경상남도":["창원시","진주시","통영시","사천시","김해시","밀양시","거제시","양산시","의령군","함안군","창녕군","고성군","남해군","하동군","산청군","함양군","거창군","합천군"],
"제주특별자치도":["제주시","서귀포시"]
};
                        var savedSido    = <?= json_encode(stripslashes($dm_conf['cf_sido'] ?? '')) ?>;
                        var savedSigungu = <?= json_encode(stripslashes($dm_conf['cf_sigungu'] ?? '')) ?>;
                        var sidoSel = document.getElementById('cf_sido');
                        var sgSel   = document.getElementById('cf_sigungu');

                        // 시/도 채우기
                        Object.keys(REGIONS).forEach(function(sido){
                            var o = document.createElement('option');
                            o.value = sido; o.textContent = sido;
                            if (sido === savedSido) o.selected = true;
                            sidoSel.appendChild(o);
                        });

                        function fillSigungu(sido, selected){
                            sgSel.innerHTML = '<option value="">시/군/구 선택</option>';
                            (REGIONS[sido] || []).forEach(function(sg){
                                var o = document.createElement('option');
                                o.value = sg; o.textContent = sg;
                                if (sg === selected) o.selected = true;
                                sgSel.appendChild(o);
                            });
                        }

                        // 초기 복원
                        if (savedSido) fillSigungu(savedSido, savedSigungu);

                        // 시/도 변경 → 시군구 갱신
                        sidoSel.addEventListener('change', function(){
                            fillSigungu(this.value, '');
                        });
                    })();
                    </script>
                </div>

                <!-- 진료시간: 평일/토요일/점심 한 줄, 야간시간, 야간요일 -->
                <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:16px; margin-bottom:16px;">
                    <div class="form_group" style="margin-bottom:0;">
                        <label>평일 진료시간 <small style="font-weight:400;color:#9999bb;">— "지금 진료 중" 표시 / HH:MM 형식</small></label>
                        <div style="display:flex; gap:8px; align-items:center;">
                            <input type="text" name="cf_open_time" value="<?= cf_val($dm_conf['cf_open_time'] ?? '') ?: '09:00' ?>" style="flex:1;" placeholder="09:00">
                            <span style="color:#9999bb; flex-shrink:0;">~</span>
                            <input type="text" name="cf_close_time" value="<?= cf_val($dm_conf['cf_close_time'] ?? '') ?: '18:00' ?>" style="flex:1;" placeholder="18:00">
                        </div>
                    </div>
                    <div class="form_group" style="margin-bottom:0;">
                        <label>토요일 진료시간 <small style="font-weight:400;color:#9999bb;">— 미운영 시 비워두세요.</small></label>
                        <div style="display:flex; gap:8px; align-items:center;">
                            <input type="text" name="cf_sat_open" value="<?= cf_val($dm_conf['cf_sat_open'] ?? '') ?: '09:00' ?>" style="flex:1;" placeholder="09:00">
                            <span style="color:#9999bb; flex-shrink:0;">~</span>
                            <input type="text" name="cf_sat_close" value="<?= cf_val($dm_conf['cf_sat_close'] ?? '') ?: '13:00' ?>" style="flex:1;" placeholder="13:00">
                        </div>
                    </div>
                    <div class="form_group" style="margin-bottom:0;">
                        <label>점심시간 <small style="font-weight:400;color:#9999bb;">— HH:MM 형식</small></label>
                        <div style="display:flex; gap:8px; align-items:center;">
                            <input type="text" name="cf_lunch_open" value="<?= cf_val($dm_conf['cf_lunch_open'] ?? '') ?: '13:00' ?>" style="flex:1;" placeholder="13:00">
                            <span style="color:#9999bb; flex-shrink:0;">~</span>
                            <input type="text" name="cf_lunch_close" value="<?= cf_val($dm_conf['cf_lunch_close'] ?? '') ?: '14:00' ?>" style="flex:1;" placeholder="14:00">
                        </div>
                    </div>
                </div>
                <div class="form_group">
                    <label>야간진료 시간 <small style="font-weight:400;color:#9999bb;">— 미운영 시 비워두세요.</small></label>
                    <div style="display:flex; gap:8px; align-items:center;">
                        <input type="text" name="cf_night_open" value="<?= cf_val($dm_conf['cf_night_open'] ?? '') ?>" style="width:110px;" placeholder="18:00">
                        <span style="color:#9999bb;">~</span>
                        <input type="text" name="cf_night_close" value="<?= cf_val($dm_conf['cf_night_close'] ?? '') ?>" style="width:110px;" placeholder="20:30">
                    </div>
                </div>
                <div class="form_group">
                    <label>야간진료 요일 <small style="font-weight:400;color:#9999bb;">— 없으면 선택 안 하면 됩니다.</small></label>
                    <?php
                    $night_days_saved = array_filter(array_map('trim', explode(',', $dm_conf['cf_night_days'] ?? '')));
                    $day_options = ['Monday'=>'월요일','Tuesday'=>'화요일','Wednesday'=>'수요일','Thursday'=>'목요일','Friday'=>'금요일','Saturday'=>'토요일'];
                    ?>
                    <div style="display:flex; gap:8px; flex-wrap:wrap;" id="night_days_wrap">
                        <?php foreach ($day_options as $val => $label): ?>
                        <label style="display:flex; align-items:center; gap:4px; cursor:pointer; padding:6px 14px; border:1px solid #ddd; border-radius:20px; font-size:14px; user-select:none;"
                               class="night-day-chip <?= in_array($val, $night_days_saved) ? 'active' : '' ?>"
                               data-val="<?= $val ?>">
                            <input type="checkbox" value="<?= $val ?>" <?= in_array($val, $night_days_saved) ? 'checked' : '' ?> style="display:none;">
                            <?= $label ?> <small style="color:#9999bb;"><?= $val ?></small>
                        </label>
                        <?php endforeach; ?>
                    </div>
                    <input type="hidden" name="cf_night_days" id="cf_night_days_hidden" value="<?= cf_val($dm_conf['cf_night_days'] ?? '') ?>">
                    <style>
                        .night-day-chip.active { border-color: var(--admin-color, #5c6bc0); background: var(--admin-color, #5c6bc0); color: #fff; }
                        .night-day-chip.active small { color: rgba(255,255,255,0.7) !important; }
                    </style>
                    <script>
                    (function(){
                        document.querySelectorAll('.night-day-chip').forEach(function(chip) {
                            chip.addEventListener('click', function() {
                                var cb = chip.querySelector('input[type=checkbox]');
                                cb.checked = !cb.checked;
                                chip.classList.toggle('active', cb.checked);
                                var checked = [];
                                document.querySelectorAll('.night-day-chip input:checked').forEach(function(c){ checked.push(c.value); });
                                document.getElementById('cf_night_days_hidden').value = checked.join(',');
                            });
                        });
                    })();
                    </script>
                </div>

                <!-- 예외 진료시간 (요일별 오버라이드) -->
                <div class="form_group">
                    <label>예외 진료시간 <small style="font-weight:400;color:#9999bb;">— 기본/야간과 다른 특정 요일만 추가 (일요일 진료·단축진료 등)</small></label>
                    <div id="hours_override_wrap"></div>
                    <button type="button" id="addOverrideBtn" style="display:inline-flex;align-items:center;gap:6px;padding:9px 18px;background:#f5f6fa;border:1px solid #e8eaf0;border-radius:8px;font-size:13px;font-weight:700;color:#4f46e5;cursor:pointer;margin-top:8px;">
                        <span class="material-symbols-outlined" style="font-size:16px;">add</span> 예외 요일 추가
                    </button>
                    <input type="hidden" name="cf_hours_override" id="cf_hours_override_hidden" value="<?= cf_val($dm_conf['cf_hours_override'] ?? '') ?>">
                    <small>해당 요일은 평일/토요일 기본값과 야간 설정을 무시하고 여기 값으로 스키마가 생성됩니다. 점심 미설정 시 평일 공통 점심이 적용됩니다.</small>
                    <style>
                        .ovr-row { display:grid; grid-template-columns:120px 1fr auto; gap:10px; align-items:start; padding:12px; border:1px solid #e8eaf0; border-radius:9px; background:#f9f9fc; margin-bottom:10px; }
                        .ovr-row select, .ovr-row input[type=text] { height:40px; border:1px solid #e8eaf0; border-radius:7px; padding:0 10px; font-size:13px; background:#fff; }
                        .ovr-times { display:flex; flex-direction:column; gap:8px; }
                        .ovr-line { display:flex; gap:6px; align-items:center; flex-wrap:wrap; }
                        .ovr-line .sep { color:#9999bb; }
                        .ovr-lunch-box { display:none; }
                        .ovr-lunch-box.show { display:flex; }
                        .ovr-chk { display:flex; align-items:center; gap:5px; font-size:12px; color:#5c5c7a; cursor:pointer; user-select:none; white-space:nowrap; }
                        .ovr-del { width:40px; height:40px; border:none; background:#fee2e2; color:#dc2626; border-radius:8px; font-size:18px; cursor:pointer; }
                        .ovr-del:hover { background:#dc2626; color:#fff; }
                        .ovr-label-in { width:100%; margin-top:6px; }
                    </style>
                    <script>
                    (function(){
                        var wrap   = document.getElementById('hours_override_wrap');
                        var hidden = document.getElementById('cf_hours_override_hidden');
                        var addBtn = document.getElementById('addOverrideBtn');
                        if (!wrap || !hidden) return;

                        var DAYS = [
                            ['Monday','월요일'],['Tuesday','화요일'],['Wednesday','수요일'],
                            ['Thursday','목요일'],['Friday','금요일'],['Saturday','토요일'],['Sunday','일요일']
                        ];

                        function dayOptions(sel) {
                            return DAYS.map(function(d){
                                return '<option value="'+d[0]+'"'+(d[0]===sel?' selected':'')+'>'+d[1]+'</option>';
                            }).join('');
                        }

                        function addRow(data) {
                            data = data || {};
                            var row = document.createElement('div');
                            row.className = 'ovr-row';
                            var lunchOn = !!(data.lunch && data.lunch.length === 2);
                            row.innerHTML =
                                '<select class="ovr-day">'+dayOptions(data.day||'Sunday')+'</select>'+
                                '<div class="ovr-times">'+
                                    '<div class="ovr-line">'+
                                        '<input type="text" class="ovr-open"  style="width:90px;" placeholder="10:00" value="'+(data.open||'')+'">'+
                                        '<span class="sep">~</span>'+
                                        '<input type="text" class="ovr-close" style="width:90px;" placeholder="14:00" value="'+(data.close||'')+'">'+
                                        '<label class="ovr-chk"><input type="checkbox" class="ovr-lunchoff" '+(data.lunchOff?'checked':'')+'> 점심 없음</label>'+
                                        '<label class="ovr-chk"><input type="checkbox" class="ovr-lunchon" '+(lunchOn?'checked':'')+'> 점심 따로</label>'+
                                    '</div>'+
                                    '<div class="ovr-line ovr-lunch-box'+(lunchOn?' show':'')+'">'+
                                        '<span style="font-size:12px;color:#9999bb;">점심</span>'+
                                        '<input type="text" class="ovr-lunch-s" style="width:90px;" placeholder="13:00" value="'+(lunchOn?data.lunch[0]:'')+'">'+
                                        '<span class="sep">~</span>'+
                                        '<input type="text" class="ovr-lunch-e" style="width:90px;" placeholder="14:00" value="'+(lunchOn?data.lunch[1]:'')+'">'+
                                    '</div>'+
                                    '<input type="text" class="ovr-label ovr-label-in" placeholder="라벨(선택): 단축진료 / 야간진료 등" value="'+(data.label?String(data.label).replace(/"/g,"&quot;"):'')+'">'+
                                '</div>'+
                                '<button type="button" class="ovr-del">×</button>';
                            wrap.appendChild(row);

                            var lunchOnCb  = row.querySelector('.ovr-lunchon');
                            var lunchOffCb = row.querySelector('.ovr-lunchoff');
                            var lunchBox   = row.querySelector('.ovr-lunch-box');

                            lunchOnCb.addEventListener('change', function(){
                                lunchBox.classList.toggle('show', lunchOnCb.checked);
                                if (lunchOnCb.checked) lunchOffCb.checked = false; // 상호배타
                                sync();
                            });
                            lunchOffCb.addEventListener('change', function(){
                                if (lunchOffCb.checked) { lunchOnCb.checked = false; lunchBox.classList.remove('show'); }
                                sync();
                            });
                            row.querySelectorAll('input,select').forEach(function(el){
                                el.addEventListener('input',  sync);
                                el.addEventListener('change', sync);
                            });
                            row.querySelector('.ovr-del').addEventListener('click', function(){ row.remove(); sync(); });
                            sync();
                        }

                        function sync() {
                            var rows = wrap.querySelectorAll('.ovr-row');
                            var out = [];
                            rows.forEach(function(r){
                                var day   = r.querySelector('.ovr-day').value;
                                var open  = r.querySelector('.ovr-open').value.trim();
                                var close = r.querySelector('.ovr-close').value.trim();
                                if (!open || !close) return; // 시간 없으면 스킵
                                var obj = { day: day, open: open, close: close };
                                var label = r.querySelector('.ovr-label').value.trim();
                                if (label) obj.label = label;
                                if (r.querySelector('.ovr-lunchoff').checked) {
                                    obj.lunchOff = true;
                                } else if (r.querySelector('.ovr-lunchon').checked) {
                                    var ls = r.querySelector('.ovr-lunch-s').value.trim();
                                    var le = r.querySelector('.ovr-lunch-e').value.trim();
                                    if (ls && le) obj.lunch = [ls, le];
                                }
                                out.push(obj);
                            });
                            hidden.value = JSON.stringify(out);
                        }

                        // 기존 저장값 복원
                        var saved = [];
                        try { saved = JSON.parse(hidden.value || '[]'); } catch(e) {}
                        if (Array.isArray(saved)) saved.forEach(addRow);

                        addBtn.addEventListener('click', function(){ addRow(); });
                    })();
                    </script>
                </div>
            </div>

            <!-- ③ SEO Part 2: 기술적 설정 -->
            <div class="section_card">
                <div class="section_hd">
                    <div class="section_icon"><span class="material-symbols-outlined">monitoring</span></div>
                    <div class="section_hd_txt"><h3>검색 분석 및 스크립트</h3><p>GA4 연동, 검색엔진 인증, 구조화 데이터</p></div>
                </div>
                <div class="form_grid">
                    <div class="form_group">
                        <label style="display:flex; align-items:center; gap:6px;">구글 애널리틱스 측정 ID <small style="font-weight:400; color:#9999bb; white-space:nowrap;">— GA4 추적 태그용</small></label>
                        <input type="text" name="cf_ga_id" value="<?= cf_val($dm_conf['cf_ga_id'] ?? '') ?>" placeholder="G-XXXXXXXXXX">
                        <small>사이트 head에 삽입. 방문자 데이터 수집에 사용됩니다.</small>
                    </div>
                    <div class="form_group">
                        <label style="display:flex; align-items:center; gap:6px;">Google Tag Manager ID <small style="font-weight:400; color:#9999bb; white-space:nowrap;">— GTM</small></label>
                        <input type="text" name="cf_gtm_id" value="<?= cf_val($dm_conf['cf_gtm_id'] ?? '') ?>" placeholder="GTM-XXXXXXX">
                        <small>입력하면 head/body에 GTM 스니펫이 자동 삽입됩니다.</small>
                    </div>
                </div>
                <div class="form_grid">
                    <div class="form_group">
                        <?php
                        /*
                         * [변경] Google Search Console 인증
                         * - 이전: content 값만 input[type=text]에 입력
                         * - 이후: Search Console에서 제공하는 <meta> 태그 전체를 textarea에 붙여넣기
                         */
                        ?>
                        <label>Google Search Console 인증 태그</label>
                        <input type="text" name="cf_gsc_verification" style="font-family:monospace; font-size:12px;" placeholder='gVqF505... (코드값만) 또는 <meta> 태그 전체' value="<?= cf_verify_val($dm_conf['cf_gsc_verification'] ?? '') ?>">
                        <small>Search Console → 소유권 확인 → <strong>HTML 태그</strong> 전체를 그대로 붙여넣으세요.</small>
                    </div>
                    <div class="form_group">
    <label>GSC 사이트 속성 (siteUrl) <small style="font-weight:400;color:#9999bb;">— 대시보드 노출 데이터 조회용</small></label>
    <input type="text" name="cf_gsc_site_url" value="<?= cf_val($dm_conf['cf_gsc_site_url'] ?? '') ?>" placeholder="sc-domain:example.com 또는 https://example.com/">
    <small>Search Console 속성 형식 그대로. <strong>도메인 속성</strong>이면 <code>sc-domain:도메인</code>, <strong>URL 접두어</strong>면 <code>https://도메인/</code></small>
</div>
                    <div class="form_group">
                        <?php
                        /*
                         * [변경] 네이버 웹마스터 인증
                         * - 이전: content 값만 input[type=text]에 입력
                         * - 이후: 서치어드바이저에서 제공하는 <meta> 태그 전체를 textarea에 붙여넣기
                         */
                        ?>
                        <label>네이버 웹마스터 인증 태그</label>
                        <input type="text" name="cf_naver_verification" style="font-family:monospace; font-size:12px;" placeholder='23182f... (코드값만) 또는 <meta> 태그 전체' value="<?= cf_verify_val($dm_conf['cf_naver_verification'] ?? '') ?>">
                        <small>서치어드바이저 → 사이트 등록 → <strong>HTML 태그</strong> 전체를 그대로 붙여넣으세요.</small>
                    </div>
                </div>
                <div class="form_group">
                    <div class="label_with_btn">
                        <span>HEAD 추가 스크립트</span>
                        <button type="button" class="btn_schema" onclick="generateSchema()">
                            <span class="material-symbols-outlined">auto_awesome</span> 스키마 자동 생성
                        </button>
                        <button type="button" class="btn_schema" style="background:#059669;" onclick="generateCanonical()">
                            <span class="material-symbols-outlined">link</span> 캐노니컬 생성
                        </button>
                    </div>
                    <textarea name="cf_add_script" id="cf_add_script" rows="7" style="font-family:monospace; font-size:12px;" placeholder="<script>...</script>"><?= cf_val($dm_conf['cf_add_script'] ?? '') ?></textarea>
                    <small>GTM HEAD, 네이버 애널리틱스 등. 스키마 자동 생성 시 기존 스키마는 교체됩니다.</small>
                </div>
                <div class="form_group">
                    <label>BODY 시작 스크립트</label>
                    <textarea name="cf_add_body_script" rows="5" style="font-family:monospace; font-size:12px;" placeholder="<noscript>...</noscript>"><?= cf_val($dm_conf['cf_add_body_script'] ?? '') ?></textarea>
                    <small>GTM BODY (noscript) 코드를 붙여넣으세요.</small>
                </div>
            </div>


            <!-- ③-2. 공통 FAQ 스키마 -->
            <div class="section_card">
                <div class="section_hd">
                    <div class="section_icon"><span class="material-symbols-outlined">quiz</span></div>
                    <div class="section_hd_txt">
                        <h3>공통 FAQ 스키마</h3>
                        <p>모든 페이지 &lt;head&gt;에 자동 삽입 — 진료시간·주차·예약 등 공통 질문 (페이지별 FAQ와 중복 없이 작성)</p>
                    </div>
                </div>
                <div id="faq_rows_wrap">
                    <div class="faq-row-hd"><span>질문 (Question)</span><span>답변 (Answer)</span><span></span></div>
                </div>
                <button type="button" onclick="addFaqRow()" style="display:inline-flex;align-items:center;gap:6px;padding:9px 18px;background:#f5f6fa;border:1px solid #e8eaf0;border-radius:8px;font-size:13px;font-weight:700;color:#4f46e5;cursor:pointer;margin-bottom:8px;">
                    <span class="material-symbols-outlined" style="font-size:16px;">add</span> 질문 추가
                </button>
                <input type="hidden" name="cf_global_faq" id="cf_global_faq_hidden" value="<?= cf_val($dm_conf['cf_global_faq'] ?? '') ?>">
                <div style="font-size:12px;color:#9999bb;margin-top:4px;">저장 시 FAQ 스키마로 자동 변환되어 모든 페이지 head에 삽입됩니다. 페이지별 FAQ와 질문이 겹치지 않도록 공통 질문만 입력하세요.</div>
                <style>
                    .faq-row { display:grid; grid-template-columns:1fr 1fr 36px; gap:10px; align-items:start; margin-bottom:10px; }
                    .faq-row input, .faq-row textarea { width:100%; border:1px solid #e8eaf0; border-radius:8px; padding:10px 14px; font-size:13px; background:#f5f6fa; font-family:inherit; resize:vertical; }
                    .faq-row input:focus, .faq-row textarea:focus { outline:none; border-color:#4f46e5; background:#fff; }
                    .faq-row-del { width:36px; height:36px; border:none; background:#fee2e2; color:#dc2626; border-radius:8px; font-size:18px; cursor:pointer; display:flex; align-items:center; justify-content:center; flex-shrink:0; }
                    .faq-row-del:hover { background:#dc2626; color:#fff; }
                    .faq-row-hd { display:grid; grid-template-columns:1fr 1fr 36px; gap:10px; margin-bottom:6px; }
                    .faq-row-hd span { font-size:11px; font-weight:700; color:#9999bb; }
                </style>
            </div>

            <!-- ④ 사이트맵 + robots.txt 한 row -->
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:24px; margin-bottom:24px;">

                <!-- 사이트맵 -->
                <div class="section_card" style="margin-bottom:0;">
                    <div class="section_hd">
                        <div class="section_icon"><span class="material-symbols-outlined">travel_explore</span></div>
                        <div class="section_hd_txt">
                            <h3>사이트맵 (sitemap.xml)</h3>
                            <p>자동 크롤링하여 sitemap.xml 생성</p>
                        </div>
                    </div>
                    <div class="form_group">
                        <label>정식 도메인 <span style="color:#ef4444;">*</span> <small style="font-weight:400;color:#9999bb;">— sitemap.xml URL 기준</small></label>
                        <input type="text" name="cf_official_domain" id="cf_official_domain" class="form_input" value="<?= cf_val($dm_conf['cf_official_domain'] ?? '') ?>" placeholder="https://산본중심치과.com" oninput="previewPunycode(this.value)">
                        <div id="punycode_preview" style="display:none;margin-top:6px;padding:8px 12px;background:#ede9fe;border-radius:7px;font-size:12px;color:#4f46e5;font-family:monospace;">
                            퓨니코드 변환: <span id="punycode_result"></span>
                        </div>
                        <small>임시 도메인이 아닌 <strong>실제 서비스 도메인</strong>을 입력하세요. 한글 도메인은 퓨니코드로 자동 변환됩니다.</small>
                    </div>
                    <div class="form_group">
                        <label>캐노니컬 기준 URL <small style="font-weight:400;color:#9999bb;">— 전체 페이지 canonical 기준 도메인</small></label>
                        <div style="display:flex;gap:8px;align-items:center;">
                            <input type="text" name="cf_canonical_base" id="cf_canonical_base" class="form_input" value="<?= cf_val($dm_conf['cf_canonical_base'] ?? '') ?>" placeholder="https://www.example.com" style="flex:1;">
                            <button type="button" class="btn_schema" style="background:#059669;white-space:nowrap;" onclick="generateCanonical()">
                                <span class="material-symbols-outlined" style="font-size:14px;">link</span> 자동 생성
                            </button>
                        </div>
                        <small>비어있으면 서버 도메인 자동 사용. 반드시 <strong>전체 설정 저장</strong>을 눌러야 적용됩니다.</small>
                    </div>
                    <div class="form_group">
                        <label>제외할 경로 <small style="font-weight:400;color:#9999bb;">(한 줄에 하나씩)</small></label>
                        <textarea name="cf_sitemap_exclude" id="cf_sitemap_exclude" rows="4" style="font-family:monospace;font-size:12px;" placeholder="/mypage&#10;/cart&#10;/board"><?= cf_val($dm_conf['cf_sitemap_urls'] ?? '') ?></textarea>
                        <small>/newadm, /data/, .js, .css 등은 자동 제외됩니다.</small>
                    </div>
                    <div class="info_box" style="margin-bottom:16px; font-size:12px;">
                        홈에서 시작해 최대 3단계, 300개 URL 자동 수집<br>
                        <code>https://<?= htmlspecialchars($_SERVER['HTTP_HOST']) ?>/sitemap.xml</code>
                    </div>
                    <button type="button" class="btn_sitemap" id="sitemapBtn" onclick="generateSitemap()">
                        <span class="material-symbols-outlined" style="font-size:15px;">travel_explore</span>
                        sitemap.xml 생성
                    </button>
                    <div class="sitemap_result" id="sitemapResult"></div>
                    <div id="sitemapUrlList" style="display:none;margin-top:12px;">
                        <div style="font-size:12px;font-weight:700;color:#9999bb;margin-bottom:8px;">수집된 URL 목록</div>
                        <div id="sitemapUrlInner" style="background:#f5f6fa;border-radius:8px;padding:12px 16px;font-family:monospace;font-size:12px;line-height:2;max-height:200px;overflow-y:auto;border:1px solid #e8eaf0;"></div>
                    </div>
                </div>

                <!-- robots.txt -->
                <div class="section_card" style="margin-bottom:0;">
                    <div class="section_hd">
                        <div class="section_icon"><span class="material-symbols-outlined">robot_2</span></div>
                        <div class="section_hd_txt">
                            <h3>robots.txt</h3>
                            <p>검색엔진 크롤러 접근 제어 설정</p>
                        </div>
                    </div>
                    <div class="form_group">
                        <label>추가 Disallow <small style="font-weight:400;color:#9999bb;">(크롤러 차단 경로)</small></label>
                        <textarea name="cf_robots_disallow" id="cf_robots_disallow" rows="4" style="font-family:monospace;font-size:12px;" placeholder="/mypage&#10;/cart&#10;/search"><?= cf_val($dm_conf['cf_robots_disallow'] ?? '') ?></textarea>
                        <small>/newadm/, /adm/, /data/, /plugin/ 은 자동 포함됩니다.</small>
                    </div>
                    <div class="form_group">
                        <label>Allow <small style="font-weight:400;color:#9999bb;">(명시적 허용 경로 — 선택)</small></label>
                        <textarea name="cf_robots_allow" id="cf_robots_allow" rows="4" style="font-family:monospace;font-size:12px;" placeholder="/public&#10;/static"><?= cf_val($dm_conf['cf_robots_allow'] ?? '') ?></textarea>
                        <small>Disallow 내 특정 경로만 허용할 때 사용합니다.</small>
                    </div>
                    <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-top:4px;">
                        <button type="button" class="btn_sitemap" id="robotsBtn" onclick="generateRobots()" style="background:#7c3aed;">
                            <span class="material-symbols-outlined" style="font-size:15px;">robot_2</span>
                            robots.txt 생성
                        </button>
                        <a id="robotsLink" href="/robots.txt" target="_blank" style="display:none;font-size:13px;color:#7c3aed;font-weight:700;text-decoration:none;">→ 현재 robots.txt 보기</a>
                    </div>
                    <div class="sitemap_result" id="robotsResult" style="display:none;"></div>
                    <div id="robotsPreview" style="display:none;margin-top:12px;">
                        <div style="font-size:12px;font-weight:700;color:#9999bb;margin-bottom:8px;">생성된 내용</div>
                        <pre id="robotsPreviewContent" style="background:#f5f6fa;border-radius:8px;padding:14px 16px;font-family:monospace;font-size:12px;line-height:1.8;border:1px solid #e8eaf0;white-space:pre-wrap;word-break:break-all;max-height:200px;overflow-y:auto;"></pre>
                    </div>
                </div>
            </div>

            <!-- ⑤ SNS 링크 -->
            <div class="section_card">
                <div class="section_hd">
                    <div class="section_icon"><span class="material-symbols-outlined">share</span></div>
                    <div class="section_hd_txt"><h3>SNS 링크 관리</h3><p>푸터 및 퀵메뉴에 표시될 SNS 링크</p></div>
                </div>
                <div class="form_grid">
                    <div class="form_group"><label>네이버 예약</label><input type="text" name="cf_naver_booking" value="<?= cf_val($dm_conf['cf_naver_booking'] ?? '') ?>" placeholder="https://naver.me/xxxxx"></div>
                    <div class="form_group"><label>네이버 톡톡</label><input type="text" name="cf_naver_talk" value="<?= cf_val($dm_conf['cf_naver_talk'] ?? '') ?>" placeholder="https://talk.naver.com/xxxxx"></div>
                </div>
                <div class="form_grid">
                    <div class="form_group"><label>카카오톡 채널</label><input type="text" name="cf_kakao" value="<?= cf_val($dm_conf['cf_kakao'] ?? '') ?>" placeholder="https://pf.kakao.com/_xxxxx"></div>
                    <div class="form_group"><label>네이버 블로그</label><input type="text" name="cf_blog" value="<?= cf_val($dm_conf['cf_blog'] ?? '') ?>" placeholder="https://blog.naver.com/xxxxx"></div>
                </div>
                <div class="form_grid">
                    <div class="form_group"><label>인스타그램</label><input type="text" name="cf_instagram" value="<?= cf_val($dm_conf['cf_instagram'] ?? '') ?>" placeholder="https://www.instagram.com/xxxxx"></div>
                    <div class="form_group"><label class="d-flex align-items-center u-gap-4">유튜브 채널 <small style="font-weight:400;color:#9999bb;">— JSON-LD sameAs에 사용</small></label><input type="text" name="cf_youtube" value="<?= cf_val($dm_conf['cf_youtube'] ?? '') ?>" placeholder="https://www.youtube.com/@채널명"></div>
                </div>
                <div class="form_group"><label>구글 비즈니스 프로필 <small style="font-weight:400;color:#9999bb;">— JSON-LD sameAs에 사용</small></label><input type="text" name="cf_google_business" value="<?= cf_val($dm_conf['cf_google_business'] ?? '') ?>" placeholder="https://www.google.com/maps/place/..."></div>
                <div class="form_group"><label>기타 채널 (sameAs 추가) <small style="font-weight:400;color:#9999bb;">— 한 줄에 하나씩, JSON-LD sameAs에만 사용 (퀵메뉴 미반영)</small></label><textarea name="cf_sns_extra" rows="3" placeholder="https://blog.naver.com/두번째블로그&#10;https://www.doctornow.co.kr/..."><?= cf_val($dm_conf['cf_sns_extra'] ?? '') ?></textarea></div>
            </div>

            <!-- ⑥ 소셜 로그인 -->
            <div class="section_card">
                <div class="section_hd">
                    <div class="section_icon"><span class="material-symbols-outlined">login</span></div>
                    <div class="section_hd_txt"><h3>소셜 로그인 API 설정</h3><p>간편로그인 연동을 위한 API 키 관리</p></div>
                </div>
                <div class="checkbox_row">
                    <input type="checkbox" id="cf_social_login_use" name="cf_social_login_use" value="1" <?= !empty($dm_conf['cf_social_login_use']) ? 'checked' : '' ?>>
                    <label for="cf_social_login_use">소셜 로그인 기능 활성화</label>
                </div>
                <div class="form_grid">
                    <div class="social_box">
                        <label><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQnOACrRJyk-4693gXNbbpXfQ4OVXSWm3sl5g&s" alt="카카오"> 카카오 REST API 키</label>
                        <div class="form_group" style="margin-bottom:10px;"><input type="text" name="cf_kakao_rest_key" value="<?= cf_val($dm_conf['cf_kakao_rest_key'] ?? '') ?>" placeholder="REST API 키"></div>
                        <div class="form_group" style="margin-bottom:0;"><input type="text" name="cf_kakao_client_secret" value="<?= cf_val($dm_conf['cf_kakao_client_secret'] ?? '') ?>" placeholder="Client Secret 키"></div>
                    </div>
                    <div class="social_box">
                        <label><img src="https://cdn-1.webcatalog.io/catalog/group-naver/group-naver-icon-unplated.png?v=1714774575036" alt="네이버"> 네이버 API</label>
                        <div class="form_group" style="margin-bottom:10px;"><input type="text" name="cf_naver_client_id" value="<?= cf_val($dm_conf['cf_naver_client_id'] ?? '') ?>" placeholder="Client ID"></div>
                        <div class="form_group" style="margin-bottom:0;"><input type="text" name="cf_naver_secret" value="<?= cf_val($dm_conf['cf_naver_secret'] ?? '') ?>" placeholder="Client Secret"></div>
                    </div>
                </div>
                <div class="info_box">Redirect URI: <code>http://<?= $_SERVER['HTTP_HOST'] ?>/plugin/social_login/callback.php</code></div>
            </div>

            <!-- ⑦ 법적 고지 -->
            <div class="section_card">
                <div class="section_hd">
                    <div class="section_icon"><span class="material-symbols-outlined">gavel</span></div>
                    <div class="section_hd_txt"><h3>법적 고지</h3><p>개인정보처리방침, 이용약관</p></div>
                </div>
                <div class="form_group">
                    <label>개인정보처리방침</label>
                    <textarea name="cf_privacy_policy" rows="9" placeholder="개인정보처리방침 내용을 입력하세요"><?= cf_val($dm_conf['cf_privacy_policy'] ?? '') ?></textarea>
                    <small>HTML 태그 사용 가능</small>
                </div>
                <div class="form_group">
                    <label>이용약관</label>
                    <textarea name="cf_terms" rows="9" placeholder="이용약관 내용을 입력하세요"><?= cf_val($dm_conf['cf_terms'] ?? '') ?></textarea>
                    <small>HTML 태그 사용 가능</small>
                </div>
            </div>

        </form>
    </main>
</div>

<div class="save_bar" style="position: fixed;
    bottom: 5vh;
    left: 50%;
    transform: translateX(-50%);">
    <button type="button" style="width: 25vw;" id="saveBtn" onclick="saveConfig()" class="btn_save">전체 설정 저장하기</button>
</div>
<div class="toast_cfg" id="toastCfg"></div>

<script>
// 저장된 주소 불러오기
window.addEventListener('DOMContentLoaded', function() {
    var baseAddr   = <?= json_encode(stripslashes($dm_conf['cf_address'] ?? '')) ?>;
    var detailAddr = <?= json_encode(stripslashes($dm_conf['cf_address_detail'] ?? '')) ?>;
    if (baseAddr)   document.getElementById('address').value        = baseAddr;
    if (detailAddr) document.getElementById('address_detail').value = detailAddr;
});

function searchAddress() {
    var postcode = new daum.Postcode({
        oncomplete: function(data) {
            // 보여주는 input + 기본주소 hidden에 저장
            document.getElementById('address').value         = data.address;
            document.getElementById('cf_address_base').value = data.address;
            // 상세주소 초기화 후 포커스
            document.getElementById('address_detail').value  = '';
            document.getElementById('address_detail').focus();
            // 전체 주소 업데이트
            updateFullAddress();
            // 좌표 저장
            new kakao.maps.services.Geocoder().addressSearch(data.address, function(result, status) {
                if (status === kakao.maps.services.Status.OK) {
                    document.getElementById('cf_lat').value = result[0].y;
                    document.getElementById('cf_lng').value = result[0].x;
                }
            });
            postcode.close();
        }
    });
    postcode.open();
}

function updateFullAddress() {
    var base   = document.getElementById('cf_address_base').value;
    var detail = document.getElementById('address_detail').value.trim();
    var add    = document.getElementById('address_add').value.trim();
    var full   = base;
    if (detail) full += ' ' + detail;
    if (add)    full += ' ' + add;
    document.getElementById('cf_address_full').value = full;
}

// 상세주소/추가안내 입력 시 전체 주소 실시간 업데이트
document.getElementById('address_detail').addEventListener('input', updateFullAddress);
document.getElementById('address_add').addEventListener('input', updateFullAddress);

document.getElementById('cf_tel').addEventListener('input', function(e) {
    var v = e.target.value.replace(/[^0-9]/g, ''), f = '';
    if (v.indexOf('02') === 0) {
        if (v.length < 3)       f = v;
        else if (v.length <= 5) f = v.slice(0,2) + '-' + v.slice(2);
        else if (v.length <= 9) f = v.slice(0,2) + '-' + v.slice(2,5) + '-' + v.slice(5,9);
        else                    f = v.slice(0,2) + '-' + v.slice(2,6) + '-' + v.slice(6,10);
    } else {
        if (v.length < 4)        f = v;
        else if (v.length <= 7)  f = v.slice(0,3) + '-' + v.slice(3);
        else if (v.length <= 10) f = v.slice(0,3) + '-' + v.slice(3,6) + '-' + v.slice(6,10);
        else                     f = v.slice(0,3) + '-' + v.slice(3,7) + '-' + v.slice(7,11);
    }
    e.target.value = f || v;
});

// 사업자등록번호 자동 하이픈 (000-00-00000)
(function(){
    var bn = document.getElementById('cf_business_number');
    if (!bn) return;
    bn.addEventListener('input', function(e) {
        var v = e.target.value.replace(/[^0-9]/g, ''), f = '';
        if (v.length < 4)      f = v;
        else if (v.length < 6) f = v.slice(0,3) + '-' + v.slice(3);
        else                   f = v.slice(0,3) + '-' + v.slice(3,5) + '-' + v.slice(5,10);
        e.target.value = f;
    });
})();

function showToastCfg(msg, type) {
    var t = document.getElementById('toastCfg');
    t.className = 'toast_cfg ' + (type || 'success');
    t.textContent = msg;
    setTimeout(function(){ t.classList.add('show'); }, 10);
    setTimeout(function(){ t.classList.remove('show'); }, 2600);
}

function generateRobots() {
    var btn     = document.getElementById('robotsBtn');
    var result  = document.getElementById('robotsResult');
    var preview = document.getElementById('robotsPreview');
    var link    = document.getElementById('robotsLink');

    btn.disabled = true;
    btn.innerHTML = '<span class="material-symbols-outlined" style="font-size:15px;">hourglass_top</span> 생성 중...';
    result.style.display = 'none';
    preview.style.display = 'none';

    var fd = new FormData();
    fd.append('action',           'generate_robots');
    fd.append('official_domain',  document.getElementById('cf_official_domain').value);
    fd.append('robots_disallow',  document.getElementById('cf_robots_disallow').value);
    fd.append('robots_allow',     document.getElementById('cf_robots_allow').value);

    fetch('', { method: 'POST', body: fd })
        .then(function(r) { return r.json(); })
        .then(function(d) {
            result.style.display = 'block';
            if (d.success) {
                result.className = 'sitemap_result';
                result.innerHTML = '✅ robots.txt 생성 완료 &nbsp;→&nbsp; <a href="' + d.url + '" target="_blank">' + d.url + '</a>';
                document.getElementById('robotsPreviewContent').textContent = d.content;
                preview.style.display = 'block';
                link.style.display = 'inline';
                showToastCfg('robots.txt 생성 완료 ✅', 'success');
            } else {
                result.className = 'sitemap_result error';
                result.textContent = '❌ ' + (d.message || '생성 실패');
                showToastCfg('robots.txt 생성 실패', 'error');
            }
        })
        .catch(function(e) {
            result.style.display = 'block';
            result.className = 'sitemap_result error';
            result.textContent = '❌ 오류: ' + e.message;
        })
        .finally(function() {
            btn.disabled = false;
            btn.innerHTML = '<span class="material-symbols-outlined" style="font-size:15px;">robot_2</span> robots.txt 생성';
        });
}

// 퓨니코드 미리보기 (한글 도메인 감지 시)
function previewPunycode(val) {
    var preview = document.getElementById('punycode_preview');
    var result  = document.getElementById('punycode_result');
    val = val.trim();
    // 한글 포함 여부 확인
    if (!val || !/[ㄱ-ㅎ가-힣]/.test(val)) {
        preview.style.display = 'none';
        return;
    }
    try {
        // URL에서 프로토콜+호스트 분리
        var match = val.match(/^(https?:\/\/)(.+)$/i);
        if (match) {
            var host = match[2];
            // URL API로 퓨니코드 변환 (브라우저 내장)
            var encoded = new URL('http://' + host).hostname;
            if (encoded && encoded !== host) {
                result.textContent = match[1] + encoded;
                preview.style.display = 'block';
                return;
            }
        }
    } catch(e) {}
    preview.style.display = 'none';
}

// 페이지 로드 시 저장된 값으로 미리보기 초기화
window.addEventListener('DOMContentLoaded', function() {
    var domainInput = document.getElementById('cf_official_domain');
    if (domainInput && domainInput.value) previewPunycode(domainInput.value);
});

function generateSitemap() {
    var officialDomain = document.getElementById('cf_official_domain').value.trim();
    if (!officialDomain) {
        showToastCfg('❌ 정식 도메인을 먼저 입력하고 저장해주세요.', 'error');
        document.getElementById('cf_official_domain').focus();
        document.getElementById('cf_official_domain').style.borderColor = '#ef4444';
        setTimeout(function(){ document.getElementById('cf_official_domain').style.borderColor = ''; }, 3000);
        return;
    }

    var btn    = document.getElementById('sitemapBtn');
    var result = document.getElementById('sitemapResult');
    var urlList = document.getElementById('sitemapUrlList');
    var urlInner = document.getElementById('sitemapUrlInner');

    btn.disabled = true;
    btn.innerHTML = '<span class="material-symbols-outlined" style="font-size:15px;">hourglass_top</span> 크롤링 중... (최대 60초)';
    result.style.display = 'none';
    urlList.style.display = 'none';

    var fd = new FormData();
    fd.append('action', 'generate_sitemap');
    fd.append('official_domain', officialDomain);
    fd.append('sitemap_exclude', document.getElementById('cf_sitemap_exclude').value);
    fd.append('cf_sitemap_urls', document.getElementById('cf_sitemap_exclude').value);

    fetch('', { method: 'POST', body: fd })
        .then(function(r) { return r.json(); })
        .then(function(d) {
            result.style.display = 'block';
            if (d.success) {
                result.className = 'sitemap_result';
                result.innerHTML = '✅ 생성 완료! 총 <strong>' + d.count + '개</strong> URL 수집 &nbsp;→&nbsp; <a href="' + d.sitemap + '" target="_blank">' + d.sitemap + '</a>';
                showToastCfg('sitemap.xml 생성 완료 (' + d.count + '개) ✅', 'success');
                if (d.urls && d.urls.length) {
                    urlInner.innerHTML = d.urls.map(function(u) {
                        return '<a href="' + u + '" target="_blank" style="color:#4f46e5;text-decoration:none;">' + u + '</a>';
                    }).join('<br>');
                    urlList.style.display = 'block';
                }
            } else {
                result.className = 'sitemap_result error';
                result.textContent = '❌ ' + (d.message || '생성 실패');
                showToastCfg('사이트맵 생성 실패', 'error');
            }
        })
        .catch(function(e) {
            result.style.display = 'block';
            result.className = 'sitemap_result error';
            result.textContent = '❌ 오류: ' + e.message;
        })
        .finally(function() {
            btn.disabled = false;
            btn.innerHTML = '<span class="material-symbols-outlined" style="font-size:15px;">travel_explore</span> 지금 크롤링하여 sitemap.xml 생성';
        });
}

function generateCanonical() {
    var official = document.getElementById('cf_official_domain').value.trim();
    var base = official || window.location.origin;
    // https 강제 + 끝슬래시 제거
    base = base.replace(/^http:\/\//i, 'https://').replace(/\/$/, '');
    // 한글도메인 → 퓨니코드
    try {
        var m = base.match(/^(https?:\/\/)(.+)$/i);
        if (m && /[^\x00-\x7F]/.test(m[2])) {
            var enc = new URL('http://' + m[2]).hostname;
            if (enc) base = m[1] + enc;
        }
    } catch(e) {}
    document.getElementById('cf_canonical_base').value = base;
    showToastCfg('✅ 캐노니컬 기준 URL 설정: ' + base + ' — 저장 버튼을 눌러 적용하세요.', 'success');
}

function generateSchema() {
    // 정식도메인 우선: 입력돼 있으면 접근 URL 무시하고 그 도메인으로 @id/url 생성. 한글도메인은 퓨니코드.
    function officialHost() {
        var official = (document.getElementById('cf_official_domain') ? document.getElementById('cf_official_domain').value.trim() : '');
        var base = official || window.location.origin;
        base = base.replace(/^http:\/\//i, 'https://').replace(/\/+$/, '');
        // 한글 등 비ASCII 호스트 → 퓨니코드
        try {
            var m = base.match(/^(https?:\/\/)(.+)$/i);
            if (m && /[^\x00-\x7F]/.test(m[2])) {
                var enc = new URL('http://' + m[2]).hostname;
                if (enc) base = m[1] + enc;
            }
        } catch(e) {}
        return base;
    }

    // 폼에서 값 수집
    var siteName  = document.querySelector('[name=cf_site_name]').value.trim();
    var siteUrl   = window.location.origin;
    var desc      = document.querySelector('[name=cf_description]').value.trim();
    var tel       = document.querySelector('[name=cf_tel]').value.trim();
    var address   = document.getElementById('cf_address_full').value.trim();
    var sido      = document.querySelector('[name=cf_sido]') ? document.querySelector('[name=cf_sido]').value.trim() : '';
    var sigungu   = document.querySelector('[name=cf_sigungu]') ? document.querySelector('[name=cf_sigungu]').value.trim() : '';
    var cityLegacy = document.querySelector('[name=cf_city]') ? document.querySelector('[name=cf_city]').value.trim() : '';
    var lat       = document.getElementById('cf_lat').value.trim();
    var lng       = document.getElementById('cf_lng').value.trim();
    var openTime  = document.querySelector('[name=cf_open_time]') ? document.querySelector('[name=cf_open_time]').value.trim() : '';
    var closeTime = document.querySelector('[name=cf_close_time]') ? document.querySelector('[name=cf_close_time]').value.trim() : '';
    var satOpen   = document.querySelector('[name=cf_sat_open]') ? document.querySelector('[name=cf_sat_open]').value.trim() : '';
    var satClose  = document.querySelector('[name=cf_sat_close]') ? document.querySelector('[name=cf_sat_close]').value.trim() : '';
    var nightDays = document.querySelector('[name=cf_night_days]') ? document.querySelector('[name=cf_night_days]').value.trim() : '';
    var nightOpen = document.querySelector('[name=cf_night_open]') ? document.querySelector('[name=cf_night_open]').value.trim() : '';
    var nightClose= document.querySelector('[name=cf_night_close]') ? document.querySelector('[name=cf_night_close]').value.trim() : '';
    var youtube   = document.querySelector('[name=cf_youtube]') ? document.querySelector('[name=cf_youtube]').value.trim() : '';
    var instagram = document.querySelector('[name=cf_instagram]').value.trim();
    var blog      = document.querySelector('[name=cf_blog]').value.trim();
    var kakao     = document.querySelector('[name=cf_kakao]').value.trim();
    var foundedYear = document.querySelector('[name=cf_founded_year]') ? document.querySelector('[name=cf_founded_year]').value.trim() : '';
    var slogan      = document.querySelector('[name=cf_slogan]') ? document.querySelector('[name=cf_slogan]').value.trim() : '';
    var expertiseRaw = document.getElementById('cf_expertise_hidden') ? document.getElementById('cf_expertise_hidden').value.trim() : '';
    var expertiseArr = expertiseRaw ? expertiseRaw.split(',').map(function(s){return s.trim();}).filter(Boolean) : [];

  // Dentist 스키마 구성 — 정식도메인 우선(있으면 접근 URL 무시), 한글도메인은 퓨니코드 변환
    var host = officialHost();
    var dentist = {
        "@context": "https://schema.org",
        "@type": "Dentist",
        "@id": host + "/#organization",
        "name": siteName,
        "url": host,
        "medicalSpecialty": "https://schema.org/Dentistry",
        "priceRange": "$$"
    };

    if (desc) dentist.description = desc;
    if (slogan) dentist.slogan = slogan;
    if (tel)  dentist.telephone   = tel;
    if (foundedYear)          dentist.foundingDate = foundedYear;
    if (expertiseArr.length)  dentist.knowsAbout   = expertiseArr.length === 1 ? expertiseArr[0] : expertiseArr;

    // 주소 — 시/도=addressRegion, 시군구=addressLocality. 신규 셀렉트 우선, 없으면 cf_city 폴백
    if (address || sido || sigungu || cityLegacy) {
        dentist.address = { "@type": "PostalAddress", "addressCountry": "KR" };
        if (sido)    dentist.address.addressRegion   = sido;
        if (sigungu) dentist.address.addressLocality = sigungu;
        // 신규 필드가 둘 다 없을 때만 레거시 cf_city를 addressLocality로 폴백
        if (!sido && !sigungu && cityLegacy) dentist.address.addressLocality = cityLegacy;
        if (address) dentist.address.streetAddress   = address;
    }

    // 좌표
    if (lat && lng) {
        dentist.geo = {
            "@type": "GeoCoordinates",
            "latitude":  lat,
            "longitude": lng
        };
    }

    // ── 진료시간 — 요일별 최종값 계산 (우선순위: 예외 > 야간 > 기본) ──
    var lunchOpen  = document.querySelector('[name=cf_lunch_open]')  ? document.querySelector('[name=cf_lunch_open]').value.trim()  : '';
    var lunchClose = document.querySelector('[name=cf_lunch_close]') ? document.querySelector('[name=cf_lunch_close]').value.trim() : '';

    // 예외 오버라이드 파싱
    var overrideArr = [];
    var ovrHidden = document.getElementById('cf_hours_override_hidden');
    if (ovrHidden) { try { overrideArr = JSON.parse(ovrHidden.value || '[]'); } catch(e) {} }
    var overrideMap = {};
    overrideArr.forEach(function(o){ if (o && o.day) overrideMap[o.day] = o; });

    var ALL_DAYS = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"];
    var WEEKDAYS = ["Monday","Tuesday","Wednesday","Thursday","Friday"];
    var nightDayArr = nightDays ? nightDays.split(',').map(function(d){ return d.trim(); }) : [];

    // 각 요일의 기본 진료시간(예외 적용 전) 결정
    function baseHoursFor(day) {
        // 토요일
        if (day === "Saturday") {
            if (satOpen && satClose) return { open: satOpen, close: satClose, lunch: null };
            return null; // 토요일 미운영
        }
        // 일요일은 기본 휴진 (예외에서만 진료)
        if (day === "Sunday") return null;
        // 평일
        if (WEEKDAYS.indexOf(day) === -1) return null;
        // 야간 요일이면 마감만 야간으로
        if (nightDayArr.indexOf(day) !== -1 && nightOpen && nightClose) {
            return { open: nightOpen, close: nightClose, lunch: (lunchOpen && lunchClose) ? [lunchOpen, lunchClose] : null };
        }
        // 일반 평일
        if (openTime && closeTime) {
            return { open: openTime, close: closeTime, lunch: (lunchOpen && lunchClose) ? [lunchOpen, lunchClose] : null };
        }
        return null;
    }

    // 요일별 최종 시간 (예외 우선)
    var dayHours = {}; // day -> {open, close, lunch:[s,e]|null}
    ALL_DAYS.forEach(function(day){
        if (overrideMap[day]) {
            var o = overrideMap[day];
            if (!o.open || !o.close) return; // 시간 없으면 스킵
            var lunch = null;
            if (o.lunchOff) {
                lunch = null;                       // 점심 없음
            } else if (o.lunch && o.lunch.length === 2) {
                lunch = [o.lunch[0], o.lunch[1]];   // 예외 전용 점심
            } else if (lunchOpen && lunchClose) {
                lunch = [lunchOpen, lunchClose];    // 평일 공통 점심
            }
            dayHours[day] = { open: o.open, close: o.close, lunch: lunch };
        } else {
            var b = baseHoursFor(day);
            if (b) dayHours[day] = b;
        }
    });

    // OpeningHoursSpecification 생성 (점심 있으면 오전/오후 2개로 분리)
    var hours = [];
    ALL_DAYS.forEach(function(day){
        var h = dayHours[day];
        if (!h) return;
        if (h.lunch && h.lunch.length === 2) {
            hours.push({ "@type":"OpeningHoursSpecification", "dayOfWeek":day, "opens":h.open,      "closes":h.lunch[0] });
            hours.push({ "@type":"OpeningHoursSpecification", "dayOfWeek":day, "opens":h.lunch[1],  "closes":h.close });
        } else {
            hours.push({ "@type":"OpeningHoursSpecification", "dayOfWeek":day, "opens":h.open, "closes":h.close });
        }
    });
    if (hours.length) dentist.openingHoursSpecification = hours;

  // sameAs — http(s)로 시작하는 것만 포함
    var googleBiz = document.querySelector('[name=cf_google_business]') ? document.querySelector('[name=cf_google_business]').value.trim() : '';
    var snsExtraRaw = document.querySelector('[name=cf_sns_extra]') ? document.querySelector('[name=cf_sns_extra]').value.trim() : '';
    var snsExtraArr = snsExtraRaw ? snsExtraRaw.split(/\r\n|\r|\n/).map(function(s){ return s.trim(); }) : [];

    var sameAs = [youtube, instagram, blog, kakao, googleBiz].concat(snsExtraArr).filter(function(v) {
        return v && v.indexOf('http') === 0;
    });
    // 중복 제거
    sameAs = sameAs.filter(function(v, i){ return sameAs.indexOf(v) === i; });
    if (sameAs.length) dentist.sameAs = sameAs;

    // WebSite 노드 (publisher → Dentist 참조)
    var website = {
        "@context": "https://schema.org",
        "@type": "WebSite",
        "@id": host + "/#website",
        "name": siteName,
        "url": host,
        "inLanguage": "ko-KR",
        "publisher": { "@id": host + "/#organization" }
    };

    // WebSite + Dentist 배열로 묶어서 삽입
    var graph = [website, dentist];

    // cf_add_script 에 기존 JSON-LD 교체 후 삽입
    var schemaBlock = '<script type="application/ld+json">\n'
        + JSON.stringify(graph, null, 2)
        + '\n<\/script>';
    var ta      = document.getElementById('cf_add_script');
    var cleaned = ta.value
        .replace(/<script[^>]*type=["']application\/ld\+json["'][^>]*>[\s\S]*?<\/script>/gi, '')
        .trim();

    ta.value = (cleaned ? cleaned + '\n\n' : '') + schemaBlock;
    showToastCfg('✅ 스키마 생성 완료! 반드시 아래 [전체 설정 저장] 버튼을 눌러 저장하세요.', 'success');
}

function saveConfig() {
    var btn = document.getElementById('saveBtn');
    btn.disabled = true;
    btn.textContent = '저장 중...';
    var fd = new FormData(document.getElementById('siteConfigForm'));
    fd.append('action', 'save');
    fetch('', { method: 'POST', body: fd })
        .then(function(r) { return r.json(); })
        .then(function(d) {
            if (d.success) {
                showToastCfg('저장되었습니다! ✅', 'success');
                setTimeout(function(){ location.reload(); }, 900);
            } else {
                showToastCfg('저장 실패', 'error');
            }
        })
        .catch(function(e) { showToastCfg('오류: ' + e.message, 'error'); })
        .finally(function() {
            btn.disabled = false;
            btn.textContent = '전체 설정 저장하기';
        });
}
// ── 공통 FAQ 관리 ────────────────────────────────────────
(function() {
    var wrap   = document.getElementById('faq_rows_wrap');
    var hidden = document.getElementById('cf_global_faq_hidden');
    if (!wrap || !hidden) return;

    // 기존 저장값 복원
    var saved = [];
    try { saved = JSON.parse(hidden.value || '[]'); } catch(e) {}
    if (Array.isArray(saved) && saved.length) {
        saved.forEach(function(item) { addRow(item.q || '', item.a || ''); });
    }

    window.addFaqRow = function() { addRow('', ''); };

    function addRow(q, a) {
        var row = document.createElement('div');
        row.className = 'faq-row';
        row.innerHTML =
            '<input type="text" placeholder="예: 진료시간이 어떻게 되나요?" value="' + esc(q) + '">' +
            '<textarea rows="2" placeholder="예: 평일 09:30~18:30, 토요일 09:00~14:00입니다.">' + escTxt(a) + '</textarea>' +
            '<button type="button" class="faq-row-del" onclick="this.parentNode.remove(); syncFaq();">×</button>';
        wrap.appendChild(row);
        row.querySelector('input').addEventListener('input', syncFaq);
        row.querySelector('textarea').addEventListener('input', syncFaq);
        syncFaq();
    }

    function syncFaq() {
        var rows = wrap.querySelectorAll('.faq-row');
        var data = [];
        rows.forEach(function(row) {
            var q = row.querySelector('input').value.trim();
            var a = row.querySelector('textarea').value.trim();
            if (q || a) data.push({ q: q, a: a });
        });
        hidden.value = JSON.stringify(data);
    }

    function esc(s)    { return (s||'').replace(/"/g, '&quot;'); }
    function escTxt(s) { return (s||'').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
})();
(function() {
    var input  = document.getElementById('expertise_input');
    var list   = document.getElementById('expertise_chip_list');
    var hidden = document.getElementById('cf_expertise_hidden');
    if (!input || !list || !hidden) return;
    var items = [];
    var saved = hidden.value.trim();
    if (saved) saved.split(',').forEach(function(t) { t=t.trim(); if(t){items.push(t);renderChip(t);} });
    input.addEventListener('keydown', function(e) {
        if (e.key !== 'Enter' && e.key !== ',') return;
        e.preventDefault();
        var val = input.value.trim().replace(/,/g,'');
        if (!val || items.indexOf(val) !== -1) { input.value=''; return; }
        items.push(val); renderChip(val); sync(); input.value='';
    });
    function renderChip(text) {
        var chip = document.createElement('span');
        chip.className = 'expertise-chip';
        chip.appendChild(document.createTextNode(text));
        var del = document.createElement('button');
        del.type = 'button'; del.innerHTML = '×';
        del.onclick = function() { items.splice(items.indexOf(text),1); chip.remove(); sync(); };
        chip.appendChild(del); list.appendChild(chip);
    }
    function sync() { hidden.value = items.join(','); }
})();
</script>
</body>
</html>