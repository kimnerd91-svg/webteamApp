<?php
if (!defined('_GNUBOARD_')) exit;

// ============================================
// dm_config 사이트 설정 조회
// ============================================
// 조회 실패 시 빈 배열로 폴백. 개별 키 방어는 아래 전역변수 할당부의 ?? '' 가 담당.
$dm_conf = @sql_fetch("SELECT * FROM dm_config WHERE cf_id = 1");
if (!$dm_conf) $dm_conf = [];

// ============================================
// 전역 변수로 꺼내기 (모든 페이지에서 바로 사용 가능)
// ============================================

// 기본 정보
$cf_site_name        = $dm_conf['cf_site_name']        ?? '';
$cf_title            = $dm_conf['cf_title']            ?? '';
$cf_description      = $dm_conf['cf_description']      ?? '';
$cf_tel              = $dm_conf['cf_tel']              ?? '';
$cf_address          = $dm_conf['cf_address']          ?? '';
$cf_ceo_name         = $dm_conf['cf_ceo_name']         ?? '';
$cf_company_name     = $dm_conf['cf_company_name']     ?? '';
$cf_business_number  = $dm_conf['cf_business_number']  ?? '';

// 진료시간
$cf_open_time        = $dm_conf['cf_open_time']        ?? '';
$cf_close_time       = $dm_conf['cf_close_time']       ?? '';
$cf_sat_open         = $dm_conf['cf_sat_open']         ?? '';
$cf_sat_close        = $dm_conf['cf_sat_close']        ?? '';
$cf_night_days       = $dm_conf['cf_night_days']       ?? '';
$cf_night_open       = $dm_conf['cf_night_open']       ?? '';
$cf_night_close      = $dm_conf['cf_night_close']      ?? '';
$cf_lunch_open       = $dm_conf['cf_lunch_open']       ?? '';
$cf_lunch_close      = $dm_conf['cf_lunch_close']      ?? '';

// 법적
$cf_privacy_policy   = $dm_conf['cf_privacy_policy']   ?? '';
$cf_terms            = $dm_conf['cf_terms']            ?? '';

// 소셜 로그인
$cf_social_login_use = $dm_conf['cf_social_login_use'] ?? 0;

// 이미지 URL (G5_DATA_URL 조합)
$cf_logo    = !empty($dm_conf['cf_logo'])
    ? G5_DATA_URL . '/common/' . $dm_conf['cf_logo']
    : '';
$cf_favicon = !empty($dm_conf['cf_favicon'])
    ? G5_DATA_URL . '/common/' . $dm_conf['cf_favicon']
    : '';
$cf_og      = !empty($dm_conf['cf_og_image'])
    ? G5_DATA_URL . '/common/' . $dm_conf['cf_og_image']
    : '';

// 스크립트
$cf_ga_id            = $dm_conf['cf_ga_id']            ?? '';
$cf_add_script       = $dm_conf['cf_add_script']       ?? '';
$cf_add_body_script  = $dm_conf['cf_add_body_script']  ?? '';

// 외부 링크
$cf_blog             = $dm_conf['cf_blog']             ?? '';
$cf_kakao            = $dm_conf['cf_kakao']            ?? '';
$cf_naver_booking    = $dm_conf['cf_naver_booking']    ?? '';
$cf_naver_talk       = $dm_conf['cf_naver_talk']       ?? '';
$cf_instagram        = $dm_conf['cf_instagram']        ?? '';
$cf_youtube          = $dm_conf['cf_youtube']          ?? '';

// 주소
$cf_address_base     = $dm_conf['cf_address_base']     ?? '';
$cf_address_detail   = $dm_conf['cf_address_detail']   ?? '';
$cf_address_add      = $dm_conf['cf_address_add']      ?? '';

// 추적/인증
// [변경] cf_ga4_property_id 제거 — cf_ga_id 하나로 통합
// [변경] GSC·Naver: DB에 전체 <meta> 태그가 저장되므로 stripslashes만 적용 후 그대로 출력
$cf_gtm_id             = $dm_conf['cf_gtm_id']             ?? '';
$cf_gsc_verification   = stripslashes($dm_conf['cf_gsc_verification']   ?? '');
$cf_naver_verification = stripslashes($dm_conf['cf_naver_verification'] ?? '');

// GEO / 스키마
$cf_founded_year     = $dm_conf['cf_founded_year']     ?? '';
$cf_expertise        = $dm_conf['cf_expertise']        ?? '';
$cf_global_faq       = $dm_conf['cf_global_faq']       ?? '';

// 지역 (cascading 셀렉트) — addressRegion / addressLocality 소스
$cf_sido             = $dm_conf['cf_sido']             ?? '';
$cf_sigungu          = $dm_conf['cf_sigungu']          ?? '';

// 기타
$cf_city             = $dm_conf['cf_city']             ?? '';  // 레거시 폴백
$cf_lat              = $dm_conf['cf_lat']              ?? '';
$cf_lng              = $dm_conf['cf_lng']              ?? '';

// 사이트 상태 (dev/live 노인덱스 토글)
$cf_site_status      = $dm_conf['cf_site_status']      ?? 'dev';

// ============================================
// dm_page_seo 통합 조회 (seo_title · seo_desc · og_image · schema_json 한 번에)
// - page_seo_manager.php에서 경로별로 입력한 메타·스키마를 현재 경로로 1회 조회
// - 페이지가 $g5['title']/$page_description을 직접 지정했으면 그게 우선, 없으면 psm 값 주입
// - 우선순위: 페이지 직접 지정 > dm_page_seo > 전역(cf_title/cf_description)
// - 경로 정규화 규칙: pathname + (id 파라미터 있으면 ?id=값만). page_seo_manager와 동일해야 매칭됨
// - column.php(칼럼 상세)는 자체 동적 스키마/메타를 쓰므로 psm 스킵 (중복 방지)
// ============================================
$__pseo_row = null;
if (!defined('G5_IS_ADMIN')) {
    $__pseo_path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    $__is_column = (strpos($__pseo_path, '/column.php') !== false);
    if (!$__is_column) {
        if (isset($_GET['id']) && $_GET['id'] !== '') {
            $__pseo_path .= '?id=' . preg_replace('/[^0-9A-Za-z_-]/', '', $_GET['id']);
        }
        $__pseo_key = sql_escape_string($__pseo_path);
        $__pseo_row = @sql_fetch("SELECT seo_title, seo_desc, og_image, schema_json FROM dm_page_seo WHERE path = '{$__pseo_key}' LIMIT 1");

        if ($__pseo_row) {
            // title: 페이지가 $g5['title']을 직접 지정 안 했을 때만 psm seo_title 주입
            // (빈 문자열로 미리 set 돼 있어도 채워지도록 empty 체크)
            if (empty($g5['title']) && !empty(trim($__pseo_row['seo_title'] ?? ''))) {
                $g5['title'] = trim($__pseo_row['seo_title']);
            }
            // description: 페이지가 직접 지정 안 했을 때만 psm seo_desc 주입
            if (empty($page_description) && !empty(trim($__pseo_row['seo_desc'] ?? ''))) {
                $page_description = trim($__pseo_row['seo_desc']);
            }
            // og_image: 페이지가 직접 지정 안 했을 때만 psm og_image 주입
            if (empty($page_og_image) && !empty(trim($__pseo_row['og_image'] ?? ''))) {
                $page_og_image = trim($__pseo_row['og_image']);
            }
        }
    }
}

// ============================================
// 테마 head_sub.php 위임 처리 (그누보드 표준)
// ============================================
if (!defined('G5_IS_ADMIN') && defined('G5_THEME_PATH') && is_file(G5_THEME_PATH . '/head_sub.php')) {
    require_once(G5_THEME_PATH . '/head_sub.php');
    return;
}

$g5_debug['php']['begin_time'] = $begin_time = get_microtime();

if (empty($g5['title'])) {
    $g5['title']    = $cf_title;
    $g5_head_title  = $g5['title'];
} else {
    $g5_head_title = $g5['title'];
}

$g5['title']    = strip_tags($g5['title']);
$g5_head_title  = strip_tags($g5_head_title);

$g5['lo_location'] = addslashes($g5['title']);
if (!$g5['lo_location'])
    $g5['lo_location'] = addslashes(clean_xss_tags($_SERVER['REQUEST_URI']));
$g5['lo_url'] = addslashes(clean_xss_tags($_SERVER['REQUEST_URI']));
if (strstr($g5['lo_url'], '/' . G5_ADMIN_DIR . '/') || $is_admin == 'super') $g5['lo_url'] = '';

// ===== 메타/OG 최종 확정 (페이지 > dm_page_seo > 전역) =====
$meta_description = !empty($page_description) ? $page_description : $cf_description;
$og_title        = !empty($g5['title']) ? $g5['title'] : ($dm_conf['cf_site_name'] ?? $cf_title);
$og_description  = !empty($page_description) ? $page_description : $cf_description;
$og_image_final  = !empty($page_og_image) ? $page_og_image : $cf_og;

// ===== 다국어 버퍼링 시작 =====
$lang = $_GET['lang'] ?? 'ko';
$allowed_langs = ['ko', 'en', 'ja', 'zh'];
if (!in_array($lang, $allowed_langs)) $lang = 'ko';
if ($lang !== 'ko') ob_start();
// ================================
?>
<!doctype html>
<html lang="ko">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <?php
    if (defined('G5_IS_ADMIN') || $cf_site_status !== 'live'):
    ?>
    <meta name="robots" content="noindex, nofollow">
    <?php else: ?>
    <meta name="robots" content="index, follow">
    <?php endif; ?>
    <?php if (!empty($cf_gsc_verification)): ?>
    <meta name="google-site-verification" content="<?= htmlspecialchars($cf_gsc_verification) ?>">
    <?php endif; ?>
    <?php if (!empty($cf_naver_verification)): ?>
    <meta name="naver-site-verification" content="<?= htmlspecialchars($cf_naver_verification) ?>">
    <?php endif; ?>
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">
    <meta property="og:url" content="https://<?php echo $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>">
<meta property="og:site_name" content="<?php echo htmlspecialchars($dm_conf['cf_site_name'] ?? $cf_title); ?>">

    <?php if (!defined('G5_IS_ADMIN')): ?>
<meta name="description" content="<?php echo htmlspecialchars($meta_description); ?>">
        <meta property="og:type" content="website">
<meta property="og:title" content="<?php echo htmlspecialchars($og_title); ?>">
        <meta property="og:description" content="<?php echo htmlspecialchars($og_description); ?>">
        <?php if ($og_image_final): ?>
            <meta property="og:image" content="<?php echo htmlspecialchars($og_image_final); ?>">
        <?php endif; ?>
        <?php if ($cf_favicon): ?>
            <link rel="shortcut icon" href="<?php echo $cf_favicon; ?>" type="image/x-icon">
        <?php endif; ?>
    <?php endif; ?>

    <?php if (!empty($cf_gtm_id)): ?>
    <!-- Google Tag Manager -->
    <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','<?= htmlspecialchars($cf_gtm_id) ?>');</script>
    <!-- End Google Tag Manager -->
    <?php endif; ?>

    <?php if ($cf_ga_id): ?>
        <!-- Google Analytics 4 -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo $cf_ga_id; ?>"></script>
        <script>
            window.dataLayer = window.dataLayer || [];

            function gtag() {
                dataLayer.push(arguments);
            }
            gtag('js', new Date());
            gtag('config', '<?php echo $cf_ga_id; ?>');
        </script>
    <?php endif; ?>

    <?php if (trim($cf_add_script) !== ''): ?>
        <?php echo "\n    " . stripslashes($cf_add_script) . "\n"; ?>
    <?php endif; ?>
    <?php
// ============================================
// 페이지별 스키마 출력 (dm_page_seo.schema_json)
// - 위에서 이미 조회한 $__pseo_row 재사용 (중복 쿼리 없음)
// - 전역 Dentist/WebSite는 위 cf_add_script가 이미 뿌리므로 여기선 중복 출력하지 않음
// ============================================
if (!defined('G5_IS_ADMIN') && $__pseo_row && !empty(trim($__pseo_row['schema_json'] ?? ''))) {
    echo "\n    " . stripslashes($__pseo_row['schema_json']) . "\n";
}
?>
    <?php
// 공통 FAQ 스키마 자동 삽입
$cf_global_faq_raw = $dm_conf['cf_global_faq'] ?? '';
if (!empty(trim($cf_global_faq_raw))) {
    $faq_items = json_decode($cf_global_faq_raw, true);
    // ... FAQ schema 렌더링
}
?>

    <title><?php echo $g5_head_title; ?></title>

    <?php if (!defined('G5_IS_ADMIN')): ?>
        <link rel="canonical" href="<?php
            if (!empty($page_canonical)) {
                // 페이지가 직접 지정한 canonical 우선 (예: column.php의 ?id= 포함 URL)
                echo htmlspecialchars($page_canonical, ENT_QUOTES);
            } else {
                $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
                $host     = htmlspecialchars($_SERVER['HTTP_HOST'], ENT_QUOTES);
                $path     = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
                echo $protocol . '://' . $host . $path;
            }
        ?>">
    <?php endif; ?>

    <script>
        var g5_url       = "<?php echo G5_URL ?>";
        var g5_bbs_url   = "<?php echo G5_BBS_URL ?>";
        var g5_is_member = "<?php echo isset($is_member) ? $is_member : ''; ?>";
        var g5_is_admin  = "<?php echo isset($is_admin)  ? $is_admin  : ''; ?>";
        var g5_is_mobile = "<?php echo G5_IS_MOBILE ?>";
    </script>

    <!-- ========================================== -->
    <!-- CSS -->
    <!-- ========================================== -->
    <!-- 1. Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/newadmin.css">

    <!-- 2. SETTING.CSS -->
    <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/setting.css">

    <!-- 3. BASE_CORE.CSS -->
    <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/base_core.css">

    <!-- 4. 외부 라이브러리 CSS -->
    <link rel="stylesheet" href="https://unpkg.com/aos@2.3.1/dist/aos.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/dist/web/static/pretendard.css">

    <!-- 5. 그누보드 관리자 CSS -->
    <?php if (defined('G5_IS_ADMIN')): ?>
        <link rel="stylesheet" href="<?php echo G5_ADMIN_URL; ?>/css/admin.css?ver=<?php echo G5_CSS_VER; ?>">
    <?php endif; ?>

    <!-- 6. 커스텀 CSS -->
    <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/index.css">
    <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/header.css">
    <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/sub.css">
    <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/implant.css">
    <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/natural.css">
    <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/general.css">
    <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/pain.css">
    <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/simmi.css">
    <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/orthodontics.css">
    <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/children.css">
        <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/tail.css">
        <link rel="preload" as="video" href="/images/pcvideo.mp4">

    <!-- ========================================== -->
    <!-- JS -->
    <!-- ========================================== -->
    <script src="<?php echo G5_JS_URL ?>/jquery-1.12.4.min.js"></script>
    <script src="<?php echo G5_JS_URL ?>/jquery-migrate-1.4.1.min.js"></script>
    <script src="/newjs/medi.js"></script>

    <!-- Bootstrap JS -->
    <!-- [defer] 독립 라이브러리 — 인라인 jQuery 의존 없음 -->
    <script defer src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI"
        crossorigin="anonymous"></script>

    <!-- ───────────────────────────────────────────────
         GSAP / Swiper / AOS 는 defer 미적용 (의도적).
         페이지 본문 인라인(gsap.to / new Swiper / AOS.init)이
         직접 호출하므로 defer 시 "not defined" 위험.
         전환하려면 각 인라인을 DOMContentLoaded로 감싼 뒤 전수 테스트.
    ─────────────────────────────────────────────── -->
    <!-- GSAP -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollToPlugin.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/Flip.min.js"></script>

    <!-- Swiper -->
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

    <!-- AOS -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

    <!-- CKEditor -->
    <!-- [defer] 에디터 페이지에서만 ClassicEditor.create() 호출 -->
    <script defer src="https://cdn.ckeditor.com/ckeditor5/40.2.0/classic/ckeditor.js"></script>

    <?php
    add_javascript('<script src="' . G5_JS_URL . '/common.js?ver=' . G5_JS_VER . '"></script>', 0);
    add_javascript('<script src="' . G5_JS_URL . '/wrest.js?ver='  . G5_JS_VER . '"></script>', 0);
    ?>

</head>

<body<?php echo isset($g5['body_script']) ? $g5['body_script'] : ''; ?>>
<?php if (!empty($cf_gtm_id)): ?>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=<?= htmlspecialchars($cf_gtm_id) ?>" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<?php endif; ?>