<?php
include_once('../_common.php');
include_once('../_auth_check.php');
if (!$is_admin) { header('Location: /bbs/login.php?url='.urlencode($_SERVER['REQUEST_URI'])); exit; }
global $connect_db; $db = $connect_db;

/* ============================================================
   social_manager.php — 유튜브(RSS 자동) + 인스타(수동) 통합 소셜 매니저
   데이터: dm_social 한 테이블. 프론트는 social_render()로 single/grid/list/mixed 출력.
   ============================================================ */

// ── 테이블 자동 생성 ──
sql_query("CREATE TABLE IF NOT EXISTS `dm_social` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `platform` VARCHAR(20) NOT NULL DEFAULT 'youtube',   /* youtube / instagram */
    `source` VARCHAR(10) NOT NULL DEFAULT 'manual',      /* auto(rss) / manual */
    `title` VARCHAR(500) DEFAULT '',
    `url` VARCHAR(1000) DEFAULT '',
    `thumbnail` VARCHAR(1000) DEFAULT '',
    `video_id` VARCHAR(50) DEFAULT '',                   /* 유튜브 영상ID (사이트내 재생용) */
    `caption` TEXT,
    `pub_date` DATETIME DEFAULT NULL,
    `guid` VARCHAR(255) DEFAULT '',                      /* 자동수집 중복방지 */
    `is_visible` TINYINT(1) DEFAULT 1,
    `display_order` INT(11) DEFAULT 0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `platform` (`platform`),
    KEY `guid` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$dm_conf = sql_fetch("SELECT cf_youtube FROM dm_config WHERE cf_id = 1");
$cf_youtube = $dm_conf['cf_youtube'] ?? '';

// ── 공통 fetch (블로그 매니저 패턴) ──
function sm_fetch($url) {
    $ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0.0.0 Safari/537.36';
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER=>true, CURLOPT_FOLLOWLOCATION=>true, CURLOPT_TIMEOUT=>10,
            CURLOPT_MAXREDIRS=>5, CURLOPT_USERAGENT=>$ua, CURLOPT_SSL_VERIFYPEER=>false,
        ]);
        $body = curl_exec($ch); $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
        return ($code>=200 && $code<400) ? $body : false;
    }
    $ctx = stream_context_create(['http'=>['timeout'=>10,'user_agent'=>$ua]]);
    return @file_get_contents($url, false, $ctx);
}

// ── 채널 URL → channel_id 추출 (/channel/UC.. 직접, @핸들/커스텀은 페이지에서 추출) ──
function sm_resolve_channel_id($url) {
    if (preg_match('#youtube\.com/channel/(UC[\w-]+)#', $url, $m)) return $m[1];
    // @handle, /c/, /user/ 형태 → 페이지 HTML에서 channelId 추출
    $html = sm_fetch($url);
    if ($html && preg_match('#"channelId":"(UC[\w-]+)"#', $html, $m)) return $m[1];
    if ($html && preg_match('#<link rel="canonical" href="https://www\.youtube\.com/channel/(UC[\w-]+)">#', $html, $m)) return $m[1];
    return '';
}

// ============================================================
// AJAX
// ============================================================
if ($_SERVER['REQUEST_METHOD']==='POST' && !empty($_POST['action'])) {
    header('Content-Type: application/json; charset=utf-8');
    $a = $_POST['action'];

    // 유튜브 RSS 동기화
    if ($a === 'sync_youtube') {
        if (!$cf_youtube) { echo json_encode(['success'=>0,'message'=>'사이트 설정(cf_youtube)에 유튜브 채널 주소가 없습니다.']); exit; }
        $cid = sm_resolve_channel_id($cf_youtube);
        if (!$cid) { echo json_encode(['success'=>0,'message'=>'채널 ID를 찾지 못했습니다. 채널 URL을 확인하세요.']); exit; }

        $rss = "https://www.youtube.com/feeds/videos.xml?channel_id={$cid}";
        $xml_raw = sm_fetch($rss);
        if (!$xml_raw) { echo json_encode(['success'=>0,'message'=>'RSS 수집 실패']); exit; }
        $xml = @simplexml_load_string($xml_raw);
        if (!$xml) { echo json_encode(['success'=>0,'message'=>'RSS 파싱 실패']); exit; }

        $yt = $xml->children('http://www.youtube.com/xml/schemas/2015');
        $media_ns = 'http://search.yahoo.com/mrss/';
        $new = 0; $ord = 0;
        foreach ($xml->entry as $entry) {
            $ytc = $entry->children('http://www.youtube.com/xml/schemas/2015');
            $vid = (string)$ytc->videoId;
            if (!$vid) continue;
            $guid = 'yt_' . $vid;
            $exist = sql_fetch("SELECT id FROM dm_social WHERE guid='".sql_escape_string($guid)."' LIMIT 1");
            if ($exist) continue;

            $title = sql_escape_string((string)$entry->title);
            $link  = sql_escape_string((string)$entry->link['href']);
            $thumb = "https://i.ytimg.com/vi/{$vid}/hqdefault.jpg";
            $pub   = date('Y-m-d H:i:s', strtotime((string)$entry->published));
            sql_query("INSERT INTO dm_social (platform, source, title, url, thumbnail, video_id, pub_date, guid, display_order)
                       VALUES ('youtube','auto','$title','$link','$thumb','".sql_escape_string($vid)."','$pub','".sql_escape_string($guid)."', $ord)");
            $new++; $ord++;
        }
        echo json_encode(['success'=>1,'new'=>$new,'channel_id'=>$cid]); exit;
    }

    // 인스타 수동 추가 (이미지+링크+캡션)
    if ($a === 'add_instagram') {
        $title = sql_escape_string(trim($_POST['title'] ?? ''));
        $url   = sql_escape_string(trim($_POST['url'] ?? ''));
        $thumb = sql_escape_string(trim($_POST['thumbnail'] ?? ''));
        $cap   = sql_escape_string(trim($_POST['caption'] ?? ''));
        if (!$url || !$thumb) { echo json_encode(['success'=>0,'message'=>'링크와 이미지는 필수입니다.']); exit; }
        sql_query("INSERT INTO dm_social (platform, source, title, url, thumbnail, caption, pub_date)
                   VALUES ('instagram','manual','$title','$url','$thumb','$cap', NOW())");
        echo json_encode(['success'=>1]); exit;
    }

    if ($a === 'toggle') {
        $id=(int)$_POST['id']; $v=(int)$_POST['v'];
        sql_query("UPDATE dm_social SET is_visible=$v WHERE id=$id");
        echo json_encode(['success'=>1]); exit;
    }
    if ($a === 'delete') {
        $id=(int)$_POST['id'];
        sql_query("DELETE FROM dm_social WHERE id=$id");
        echo json_encode(['success'=>1]); exit;
    }
    echo json_encode(['success'=>0,'message'=>'unknown']); exit;
}

// 목록
$rows = [];
$r = sql_query("SELECT * FROM dm_social ORDER BY pub_date DESC, id DESC");
while ($row = sql_fetch_array($r)) $rows[] = $row;
?>
<!DOCTYPE html>
<html lang="ko"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>소셜 관리</title>
</head><body>
<div style="display:flex;min-height:100vh;">
    <?php include_once('../aside.php'); ?>
    <main class="content_area" style="flex:1;padding:40px;">

<div class="sm-wrap">
  <div class="guide_box">
    <h2>📱 소셜 관리 (유튜브 · 인스타)</h2>
    <p>유튜브는 사이트 설정의 채널 주소(cf_youtube)에서 <b>자동 수집</b>, 인스타는 <b>수동 등록</b>합니다.
       프론트에는 <code>social_render(['mode'=>'grid'])</code> 형태로 single/grid/list/mixed 출력.</p>
  </div>

  <div class="card">
    <h3>① 유튜브 자동 수집</h3>
    <p class="muted">현재 채널: <?= $cf_youtube ? htmlspecialchars($cf_youtube) : '<b style="color:#dc2626;">cf_youtube 미설정</b> — 사이트 설정에서 채널 URL 입력' ?></p>
    <button class="btn_primary" onclick="syncYT()">최신 영상 가져오기</button>
    <span id="ytStat" class="muted"></span>
  </div>

  <div class="card">
    <h3>② 인스타 수동 등록</h3>
    <div class="ig-form">
      <input type="text" id="ig_url" placeholder="인스타 게시물 링크 (필수)">
      <input type="text" id="ig_thumb" placeholder="이미지 URL (필수)">
      <input type="text" id="ig_title" placeholder="제목 (선택)">
      <textarea id="ig_caption" placeholder="캡션 (선택)" rows="2"></textarea>
      <button class="btn_primary" onclick="addIG()">인스타 카드 추가</button>
      <span id="igStat" class="muted"></span>
    </div>
  </div>

  <div class="card">
    <h3>③ 등록된 콘텐츠 (<?= count($rows) ?>)</h3>
    <table class="sm-table">
      <thead><tr><th>플랫폼</th><th>썸네일</th><th>제목</th><th>수집</th><th>노출</th><th>관리</th></tr></thead>
      <tbody>
      <?php foreach ($rows as $row): ?>
        <tr>
          <td><span class="badge <?= $row['platform'] ?>"><?= $row['platform']==='youtube'?'▶ YT':'IG' ?></span></td>
          <td><?php if($row['thumbnail']):?><img src="<?= htmlspecialchars($row['thumbnail']) ?>" class="thumb"><?php endif;?></td>
          <td class="ttl"><?= htmlspecialchars($row['title'] ?: $row['caption']) ?></td>
          <td><?= $row['source']==='auto'?'자동':'수동' ?></td>
          <td><input type="checkbox" <?= $row['is_visible']?'checked':'' ?> onchange="tog(<?= $row['id'] ?>,this.checked?1:0)"></td>
          <td><button class="btn_ghost" onclick="del(<?= $row['id'] ?>)">삭제</button></td>
        </tr>
      <?php endforeach; ?>
      <?php if(!$rows):?><tr><td colspan="6" class="muted" style="text-align:center;padding:30px;">등록된 콘텐츠가 없습니다.</td></tr><?php endif;?>
      </tbody>
    </table>
  </div>
</div>

<style>
.sm-wrap{max-width:900px;margin:0 auto;}
.guide_box{background:#f0f4ff;border:1px solid #d6e0ff;border-radius:12px;padding:18px 22px;margin-bottom:18px;}
.card{background:#fff;border:1px solid #e8eaf0;border-radius:12px;padding:20px 24px;margin-bottom:16px;}
.card h3{margin:0 0 12px;font-size:15px;}
.muted{color:#9999bb;font-size:12.5px;}
.ig-form{display:flex;flex-direction:column;gap:8px;max-width:480px;}
.ig-form input,.ig-form textarea{border:1px solid #e8eaf0;border-radius:8px;padding:9px 12px;font-size:13px;}
.btn_primary{background:#4f46e5;color:#fff;border:none;border-radius:8px;padding:9px 18px;font-size:13px;font-weight:700;cursor:pointer;align-self:flex-start;}
.btn_ghost{background:#f5f6fa;border:1px solid #e8eaf0;border-radius:7px;padding:5px 12px;font-size:12px;cursor:pointer;}
.sm-table{width:100%;border-collapse:collapse;font-size:13px;}
.sm-table th,.sm-table td{padding:9px 10px;border-bottom:1px solid #f0f3f8;text-align:left;vertical-align:middle;}
.sm-table .thumb{width:64px;height:40px;object-fit:cover;border-radius:6px;}
.sm-table .ttl{max-width:300px;}
.badge{padding:3px 9px;border-radius:20px;font-size:11px;font-weight:700;}
.badge.youtube{background:#fee2e2;color:#dc2626;}
.badge.instagram{background:#fce7f3;color:#db2777;}
</style>

<script>
function post(d,cb){var f=new FormData();for(var k in d)f.append(k,d[k]);
  fetch(location.href,{method:'POST',body:f}).then(r=>r.json()).then(cb);}
function syncYT(){document.getElementById('ytStat').textContent='수집 중…';
  post({action:'sync_youtube'},d=>{document.getElementById('ytStat').textContent=
    d.success?('✅ 새 영상 '+d.new+'개'):('❌ '+d.message); if(d.success)setTimeout(()=>location.reload(),800);});}
function addIG(){post({action:'add_instagram',url:ig_url.value,thumbnail:ig_thumb.value,title:ig_title.value,caption:ig_caption.value},
  d=>{document.getElementById('igStat').textContent=d.success?'✅ 추가됨':('❌ '+d.message); if(d.success)setTimeout(()=>location.reload(),600);});}
function tog(id,v){post({action:'toggle',id:id,v:v},d=>{});}
function del(id){if(!confirm('삭제할까요?'))return;post({action:'delete',id:id},d=>{if(d.success)location.reload();});}
</script>

    </main>
</div>
</body></html>
