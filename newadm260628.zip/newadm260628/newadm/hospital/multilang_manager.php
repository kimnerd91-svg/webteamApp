<?php
include_once('../_common.php');
include_once('./_auth_check.php');
if (!$is_admin) { header('Location: /bbs/login.php?url='.urlencode($_SERVER['REQUEST_URI'])); exit; }

// 그누보드 DB 핸들 확보 (PSM과 동일 패턴)
global $connect_db;
$db = $connect_db;

/* ============================================================
   다국어 매니저 v3  (1단계: 자동 마킹 + 크롤 적재)
   - 기존 v2(JSON파일/extractKorean)는 폐기. DB(dm_i18n) 방식으로 신규.
   - 언어 분리는 URL 쿼리방식(?lang=en). .htaccess 불필요.
   ============================================================ */

// ── Gemini 키: site_config(dm_config.cf_gemini_key) 공용 (PSM/dict_manager와 동일) ──
$col_gk = mysqli_fetch_assoc(mysqli_query($db, "SHOW COLUMNS FROM dm_config LIKE 'cf_gemini_key'"));
if (!$col_gk) { mysqli_query($db, "ALTER TABLE dm_config ADD `cf_gemini_key` VARCHAR(255) NULL DEFAULT ''"); }
$__gk = mysqli_fetch_assoc(mysqli_query($db, "SELECT cf_gemini_key, cf_langs FROM dm_config WHERE cf_id = 1"));
$GEMINI_KEY = trim($__gk['cf_gemini_key'] ?? '');
$SITE_LANGS = trim($__gk['cf_langs'] ?? 'ko');

// ── dm_i18n 테이블 자동 생성 ──
// site_id: 멀티사이트/SaaS 대비(현재 1 고정). i18n_key가 진짜 식별자.
mysqli_query($db, "CREATE TABLE IF NOT EXISTS `dm_i18n` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `site_id` INT NOT NULL DEFAULT 1,
    `i18n_key` VARCHAR(80) NOT NULL,
    `page_path` VARCHAR(255) DEFAULT '',
    `ko` TEXT,
    `en` TEXT,
    `ja` TEXT,
    `zh` TEXT,
    `ko_hash` CHAR(32) DEFAULT '',
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uq_site_key` (`site_id`, `i18n_key`)
) DEFAULT CHARSET=utf8mb4");

$SITE_ID = 1;

/* ============================================================
   AJAX 핸들러 (공통 출력 전에 처리)
   ============================================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['action'])) {
    header('Content-Type: application/json; charset=utf-8');
    $action = $_POST['action'];

    // ── 1) 크롤: 마킹된 URL 목록을 돌며 data-i18n 수집 → DB upsert ──
    if ($action === 'crawl') {
        $urls = array_filter(array_map('trim', explode("\n", $_POST['urls'] ?? '')));
        if (!$urls) { echo json_encode(['success'=>false,'message'=>'URL이 없습니다.']); exit; }

        $collected = 0; $inserted = 0; $updated = 0; $pages = 0; $errors = [];

        foreach ($urls as $url) {
            if (!preg_match('#^https?://#i', $url)) { $errors[] = "건너뜀(잘못된 URL): $url"; continue; }
            $html = @file_get_contents($url);
            if ($html === false) { $errors[] = "불러오기 실패: $url"; continue; }
            $pages++;
            $path = parse_url($url, PHP_URL_PATH) ?: '/';

            // data-i18n="key" 요소의 key + 내부 텍스트 추출
            $dom = new DOMDocument();
            libxml_use_internal_errors(true);
            $dom->loadHTML('<?xml encoding="utf-8" ?>' . $html);
            libxml_clear_errors();
            $xp = new DOMXPath($dom);
            $nodes = $xp->query('//*[@data-i18n]');

            foreach ($nodes as $node) {
                $key = trim($node->getAttribute('data-i18n'));
                $ko  = trim(preg_replace('/\s+/', ' ', $node->textContent));
                if ($key === '' || $ko === '') continue;
                $collected++;
                $hash = md5($ko);

                $keyE = mysqli_real_escape_string($db, $key);
                $koE  = mysqli_real_escape_string($db, $ko);
                $pE   = mysqli_real_escape_string($db, $path);

                // 이미 있으면: ko가 바뀐 경우에만 갱신(해시 비교) — 번역값(en/ja/zh)은 보존
                $row = mysqli_fetch_assoc(mysqli_query($db,
                    "SELECT id, ko_hash FROM dm_i18n WHERE site_id=$SITE_ID AND i18n_key='$keyE' LIMIT 1"));
                if ($row) {
                    if ($row['ko_hash'] !== $hash) {
                        mysqli_query($db, "UPDATE dm_i18n SET ko='$koE', ko_hash='$hash', page_path='$pE'
                                           WHERE id=" . (int)$row['id']);
                        $updated++;
                    }
                } else {
                    mysqli_query($db, "INSERT INTO dm_i18n (site_id, i18n_key, page_path, ko, ko_hash)
                                       VALUES ($SITE_ID, '$keyE', '$pE', '$koE', '$hash')");
                    $inserted++;
                }
            }
        }

        echo json_encode([
            'success'  => true,
            'pages'    => $pages,
            'collected'=> $collected,
            'inserted' => $inserted,
            'updated'  => $updated,
            'errors'   => $errors
        ]);
        exit;
    }

    // ── 2) 적재 현황: DB 통계 ──
    if ($action === 'stats') {
        $total = (int)(mysqli_fetch_row(mysqli_query($db, "SELECT COUNT(*) FROM dm_i18n WHERE site_id=$SITE_ID"))[0] ?? 0);
        $enDone = (int)(mysqli_fetch_row(mysqli_query($db, "SELECT COUNT(*) FROM dm_i18n WHERE site_id=$SITE_ID AND en<>'' AND en IS NOT NULL"))[0] ?? 0);
        echo json_encode(['success'=>true, 'total'=>$total, 'en_done'=>$enDone]);
        exit;
    }

    echo json_encode(['success'=>false, 'message'=>'알 수 없는 action']);
    exit;
}

?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>다국어 관리</title>
</head>
<body>
<div style="display:flex;min-height:100vh;">
    <?php include_once('../aside.php'); ?>
    <main class="content_area" style="flex:1;padding:40px;overflow-x:hidden;">

<div class="page_wrap">

  <!-- ============================================================
       사용 방법 (상단 고정 안내)
       ============================================================ -->
  <div class="guide_box">
    <h2 class="guide_title">📘 다국어 매니저 사용 방법</h2>
    <p class="guide_lead">번역은 4단계로 진행됩니다. <b>마킹 → 크롤 적재 → 번역 → 출력</b>. 이 화면은 1·2단계(마킹 + 적재)입니다.</p>
    <ol class="guide_steps">
      <li><b>① 자동 마킹</b> — 페이지 HTML을 아래 박스에 붙여넣고 [자동 마킹]을 누르면, 한국어 텍스트마다 <code>data-i18n="키"</code>가 자동으로 박힌 HTML이 나옵니다. 그 결과를 복사해 실제 페이지 파일에 반영하세요.
        <ul>
          <li>같은 문장은 같은 키로 묶입니다(메뉴·푸터 반복 텍스트 자동 통합).</li>
          <li>번역에서 빼고 싶은 요소는 <code>data-no-i18n</code> 속성을 직접 달면 마킹에서 제외됩니다(전화번호·영문·숫자는 자동 제외).</li>
          <li>이미 <code>data-i18n</code>이 있는 요소는 건드리지 않습니다(여러 번 돌려도 안전).</li>
        </ul>
      </li>
      <li><b>② 크롤 적재</b> — 마킹을 반영한 페이지들의 URL을 아래에 한 줄에 하나씩 넣고 [크롤 적재]를 누르면, <code>data-i18n</code> 텍스트가 DB(<code>dm_i18n</code>)에 모입니다. 원문이 바뀐 항목만 갱신되고, 기존 번역값은 보존됩니다.</li>
      <li><b>③ 번역</b> (다음 단계) — 모인 텍스트를 언어별(EN/JA/ZH)로 편집 + Gemini 자동번역 + 의료법 검수.</li>
      <li><b>④ 출력</b> (다음 단계) — 페이지 접속 시 <code>?lang=en</code> 등에 따라 서버에서 해당 언어로 치환(없으면 한국어 폴백).</li>
    </ol>
    <p class="guide_note">⚠️ 번역 대상에 <b>data-i18n 마킹이 없으면 크롤이 아무것도 못 모읍니다</b>(생텍스트는 스캔하지 않음). 반드시 ①을 먼저 하세요.</p>
  </div>

  <!-- ============================================================
       ① 자동 마킹 도구 (브라우저에서 즉시 처리)
       ============================================================ -->
  <div class="card">
    <h3 class="card_title">① 자동 마킹 — HTML에 data-i18n 자동 삽입</h3>
    <label class="fld_label">페이지 HTML 붙여넣기</label>
    <textarea id="markInput" class="ta" rows="8" placeholder="<section> ... 페이지 HTML 전체 또는 일부 ... </section>"></textarea>
    <div class="btn_row">
      <button class="btn_primary" onclick="runMark()">자동 마킹</button>
      <span id="markStat" class="stat_txt"></span>
    </div>
    <label class="fld_label">결과 (복사해서 페이지 파일에 반영)</label>
    <textarea id="markOutput" class="ta" rows="8" readonly placeholder="마킹 결과가 여기에 나옵니다"></textarea>
    <div class="btn_row">
      <button class="btn_ghost" onclick="copyOut()">결과 복사</button>
    </div>
  </div>

  <!-- ============================================================
       ② 크롤 적재
       ============================================================ -->
  <div class="card">
    <h3 class="card_title">② 크롤 적재 — 마킹된 페이지 URL 수집</h3>
    <label class="fld_label">URL 목록 (한 줄에 하나)</label>
    <textarea id="crawlUrls" class="ta" rows="5" placeholder="https://example.com/&#10;https://example.com/about&#10;https://example.com/implant"></textarea>
    <div class="btn_row">
      <button class="btn_primary" onclick="runCrawl()">크롤 적재</button>
      <button class="btn_ghost" onclick="loadStats()">현황 새로고침</button>
      <span id="crawlStat" class="stat_txt"></span>
    </div>
    <div id="crawlResult" class="result_box" style="display:none;"></div>
    <div id="statsBox" class="stats_box"></div>
  </div>

</div>

<style>
.page_wrap { max-width: 920px; margin: 0 auto; padding: 20px; }
.guide_box { background:#f0f4ff; border:1px solid #d6e0ff; border-radius:12px; padding:20px 24px; margin-bottom:20px; }
.guide_title { margin:0 0 8px; font-size:18px; color:#2c3e80; }
.guide_lead { margin:0 0 12px; font-size:14px; color:#445; }
.guide_steps { margin:0; padding-left:20px; font-size:13px; line-height:1.8; color:#445; }
.guide_steps > li { margin-bottom:8px; }
.guide_steps ul { margin:4px 0; padding-left:18px; font-size:12.5px; color:#667; }
.guide_note { margin:12px 0 0; font-size:12.5px; color:#b4520a; background:#fff6ec; border-radius:8px; padding:8px 12px; }
.guide_box code, .card code { background:#e6ecff; padding:1px 6px; border-radius:4px; font-size:12px; color:#3344aa; }
.card { background:#fff; border:1px solid #e8eaf0; border-radius:12px; padding:20px 24px; margin-bottom:18px; }
.card_title { margin:0 0 14px; font-size:15px; color:#333; }
.fld_label { display:block; font-size:12px; font-weight:700; color:#9999bb; margin:10px 0 6px; }
.ta { width:100%; box-sizing:border-box; border:1px solid #e8eaf0; border-radius:8px; padding:10px 12px; font-size:13px; font-family:ui-monospace,monospace; resize:vertical; }
.btn_row { display:flex; align-items:center; gap:10px; margin:10px 0; }
.btn_primary { background:#4f46e5; color:#fff; border:none; border-radius:8px; padding:10px 20px; font-size:13px; font-weight:700; cursor:pointer; }
.btn_ghost { background:#f5f6fa; color:#556; border:1px solid #e8eaf0; border-radius:8px; padding:10px 18px; font-size:13px; cursor:pointer; }
.stat_txt { font-size:12.5px; color:#667; }
.result_box { background:#fafbff; border:1px solid #e8eaf0; border-radius:8px; padding:12px 14px; font-size:12.5px; line-height:1.7; color:#445; margin-top:10px; }
.stats_box { margin-top:12px; font-size:13px; color:#445; }
.stats_box b { color:#4f46e5; }
</style>

<script>
/* ============================================================
   ① 자동 마킹 — 브라우저 DOMParser로 처리
   규칙: 한국어 텍스트를 직접 가진 잎 요소에 data-i18n="t-{해시}" 삽입
   ============================================================ */
var MARK_TAGS = ['H1','H2','H3','H4','H5','H6','P','LI','A','SPAN','BUTTON','TH','TD','FIGCAPTION','DT','DD','STRONG','EM','LABEL','BLOCKQUOTE','SUMMARY','CAPTION'];

// 한국어 포함 여부
function hasKorean(s){ return /[가-힣]/.test(s); }

// 간단 해시 → 8자리 (텍스트 동일 = 키 동일)
function hashKey(str){
    var h = 5381, i = str.length;
    while(i) { h = (h * 33) ^ str.charCodeAt(--i); }
    var hex = (h >>> 0).toString(16);
    while (hex.length < 8) hex = '0' + hex;
    return 't-' + hex.slice(0, 8);
}

function runMark(){
    var raw = document.getElementById('markInput').value;
    if (!raw.trim()) { setStat('markStat', 'HTML을 붙여넣으세요.'); return; }

    var parser = new DOMParser();
    // 조각 HTML도 파싱되도록 body로 감쌈
    var docu = parser.parseFromString('<div id="__root">' + raw + '</div>', 'text/html');
    var root = docu.getElementById('__root');
    var marked = 0, reused = 0;
    var seen = {};

    MARK_TAGS.forEach(function(tag){
        var els = root.getElementsByTagName(tag);
        Array.prototype.slice.call(els).forEach(function(el){
            // 제외 조건
            if (el.hasAttribute('data-i18n')) return;        // 이미 마킹됨
            if (el.hasAttribute('data-no-i18n')) return;     // 수동 제외
            if (el.closest('[data-no-i18n]')) return;        // 부모가 제외
            // 자식 요소가 있으면(텍스트만 든 잎이 아니면) 건너뜀 → 안쪽 잎에서 잡음
            var hasElementChild = false;
            for (var i=0;i<el.children.length;i++){
                if (MARK_TAGS.indexOf(el.children[i].tagName) !== -1) { hasElementChild = true; break; }
            }
            if (hasElementChild) return;
            var txt = (el.textContent || '').replace(/\s+/g,' ').trim();
            if (!txt || !hasKorean(txt)) return;             // 한국어 없으면 제외(숫자·영문·전화 자동 스킵)

            var key = hashKey(txt);
            if (seen[key]) reused++; else { seen[key] = true; }
            el.setAttribute('data-i18n', key);
            marked++;
        });
    });

    document.getElementById('markOutput').value = root.innerHTML;
    setStat('markStat', '✅ 마킹 ' + marked + '개 (고유 키 ' + Object.keys(seen).length + '개, 중복 통합 ' + reused + '개)');
}

function copyOut(){
    var out = document.getElementById('markOutput');
    out.select();
    document.execCommand('copy');
    setStat('markStat', '복사됨 ✅');
}

/* ============================================================
   ② 크롤 적재
   ============================================================ */
function runCrawl(){
    var urls = document.getElementById('crawlUrls').value.trim();
    if (!urls) { setStat('crawlStat', 'URL을 입력하세요.'); return; }
    setStat('crawlStat', '크롤 중…');

    var fd = new FormData();
    fd.append('action', 'crawl');
    fd.append('urls', urls);

    fetch(location.href, { method:'POST', body:fd })
        .then(function(r){ return r.json(); })
        .then(function(d){
            if (!d.success) { setStat('crawlStat', '❌ ' + (d.message||'실패')); return; }
            setStat('crawlStat', '✅ 완료');
            var box = document.getElementById('crawlResult');
            box.style.display = 'block';
            var html = '페이지 ' + d.pages + '개 처리 · 수집 ' + d.collected + '건 · '
                     + '신규 ' + d.inserted + ' · 갱신 ' + d.updated;
            if (d.errors && d.errors.length) {
                html += '<br><span style="color:#b4520a;">' + d.errors.join('<br>') + '</span>';
            }
            box.innerHTML = html;
            loadStats();
        })
        .catch(function(e){ setStat('crawlStat', '❌ 통신 오류'); });
}

function loadStats(){
    var fd = new FormData();
    fd.append('action', 'stats');
    fetch(location.href, { method:'POST', body:fd })
        .then(function(r){ return r.json(); })
        .then(function(d){
            if (!d.success) return;
            document.getElementById('statsBox').innerHTML =
                'DB 적재 현황: 총 <b>' + d.total + '</b>개 키 · 영어 번역 완료 <b>' + d.en_done + '</b>개';
        });
}

function setStat(id, msg){ document.getElementById(id).textContent = msg; }

// 초기 현황 로드
loadStats();
</script>

<?php
// 닫기
?>
    </main>
</div>
</body>
</html>