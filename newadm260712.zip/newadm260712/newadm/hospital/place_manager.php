<?php
include_once('../_common.php');
include_once('../_auth_check.php');

/* ── 멀티대시/wf 프로파일 내보내기 (export_profile) ─────────────────
   중앙 멀티대시가 각 병원에서 GEO 프로파일을 긁어가는 송신 엔드포인트.
   관리자 세션 없이 토큰으로만 접근하므로 $is_admin 체크보다 앞에 배치.
   (column_admin.php의 receive_external과 같은 패턴 — 방향만 송신)
   URL 예: place_manager.php?action=export_profile&token=kimnerd91          */
// ── 병원 GEO 프로파일 생성 (export GET + push 공용) ──
function pm_build_profile() {
    global $connect_db, $g5;
    // ★ SELECT * 사용: 사이트마다 dm_config 컬럼 구성이 달라서, 컬럼을 명시하면
    //   없는 컬럼 하나 때문에 쿼리 전체가 실패해 모든 값이 빈다. 전부 가져와 있는 것만 씀.
    $cf = sql_fetch("SELECT * FROM dm_config WHERE cf_id = 1") ?: [];

    $doctors = json_decode($cf['cf_doctors'] ?? '[]', true);
    if (!is_array($doctors)) $doctors = [];
    $doctors_out = [];
    foreach ($doctors as $d) {
        $doctors_out[] = [
            'name'     => $d['name']     ?? ($d['doctor_name'] ?? ''),
            'position' => $d['position'] ?? ($d['title'] ?? ''),
            'degree'   => $d['degree']   ?? ($d['career'] ?? ''),
        ];
    }
    $rd = @sql_query("SELECT name, position, degree FROM dm_doctors WHERE is_visible=1 ORDER BY display_order ASC");
    if ($rd) { while ($row = sql_fetch_array($rd)) $doctors_out[] = ['name'=>$row['name'], 'position'=>$row['position'], 'degree'=>$row['degree']]; }

    $services = [];
    $nc_file = G5_DATA_PATH . '/content/non_covered.json';
    if (is_file($nc_file)) {
        $nc = json_decode(file_get_contents($nc_file), true);
        if (is_array($nc)) {
            array_walk_recursive($nc, function($v, $k) use (&$services) {
                if (in_array($k, ['name','item','title','항목명'], true) && is_string($v) && trim($v) !== '') $services[] = trim($v);
            });
        }
    }
    $equipment = [];
    $re = @sql_query("SELECT name, category, tags FROM dm_equipment ORDER BY display_order ASC");
    if ($re) { while ($row = sql_fetch_array($re)) $equipment[] = ['name'=>$row['name'], 'category'=>$row['category'], 'tags'=>$row['tags']]; }
    $expertise = array_values(array_filter(array_map('trim', preg_split('/[\r\n,]+/', $cf['cf_expertise'] ?? ''))));

    $aitab = [];
    $ra = @sql_query("SELECT item_key, status, note FROM dm_place_aitab_check");
    if ($ra) { while ($row = sql_fetch_array($ra)) $aitab[$row['item_key']] = ['status'=>$row['status'], 'note'=>$row['note']]; }

    $pstate_x = sql_fetch("SELECT place_url, place_id, last_checked FROM dm_place_state WHERE id=1") ?: [];

    $has_naver_key  = !empty(trim($cf['cf_naver_client_id'] ?? '')) && !empty(trim($cf['cf_naver_secret'] ?? ''));
    $has_gemini_key = !empty(trim($cf['cf_gemini_key'] ?? ''));

    return [
        'ok' => true,
        'exported_at' => date('c'),
        'identity' => [
            'site_name'     => $cf['cf_site_name'] ?? '',
            'org_grade'     => $cf['cf_org_grade'] ?? '',
            'org_specialty' => $cf['cf_org_specialty'] ?? '',
            'expertise'     => $expertise,
            'founded_year'  => $cf['cf_founded_year'] ?? '',
        ],
        'region' => [
            'sido'    => $cf['cf_sido'] ?? '',
            'sigungu' => $cf['cf_sigungu'] ?? '',
            'gu'      => $cf['cf_gu'] ?? '',
            'gu_dong' => $cf['cf_gu_dong'] ?? '',
            // 검색·표시용 전체 지역명 (예: "안산시 상록구")
            'full'    => trim(($cf['cf_sigungu'] ?? '') . ' ' . ($cf['cf_gu'] ?? '')),
            'lat'     => $cf['cf_lat'] ?? '',
            'lng'     => $cf['cf_lng'] ?? '',
        ],
        'nap' => [
            'tel'           => $cf['cf_tel'] ?? '',
            'address'       => $cf['cf_address'] ?? '',
            'naver_booking' => $cf['cf_naver_booking'] ?? '',
            'place_url'     => $pstate_x['place_url'] ?? '',
            'place_id'      => $pstate_x['place_id'] ?? '',
        ],
        'doctors'   => $doctors_out,
        'services'  => array_values(array_unique($services)),
        'equipment' => $equipment,
        'pm_status' => [
            'aitab_check'  => $aitab,
            'last_checked' => $pstate_x['last_checked'] ?? null,
        ],
        'keys' => [
            'has_naver_key'  => $has_naver_key,
            'has_gemini_key' => $has_gemini_key,
        ],
    ];
}

// ── 플레이스 스크래핑 진단 (네이버가 서버 요청을 막는지 실제로 확인) ──
if (($_GET['action'] ?? '') === 'export_profile') {
    global $connect_db; $db = $connect_db;
    while (ob_get_level()) ob_end_clean();
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }
    header('Content-Type: application/json; charset=utf-8');

    $tok = $_GET['token'] ?? '';
    if (!$tok || !hash_equals('kimnerd91', $tok)) {
        http_response_code(403);
        echo json_encode(['ok'=>false, 'message'=>'토큰 불일치'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    echo json_encode(pm_build_profile(), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}
if (!$is_admin) { header('Location: /bbs/login.php?url='.urlencode($_SERVER['REQUEST_URI'])); exit; }
global $connect_db; $db = $connect_db;

/* ============================================================
   place_manager.php — 네이버 플레이스/평판 주간 점검 (site_config 완전 자동연동)
   설정 입력 없음 — 병원명(cf_site_name), 주소(cf_address), 예약링크(cf_naver_booking),
   자사블로그(cf_blog), API키(cf_naver_client_id/secret), Gemini(cf_gemini_key) 전부 재사용.

   ① NAP 점검  : 네이버 지역검색 API(공식) — 병원명 검색 → 주소·전화 공식 데이터로 대조 (크롤 아님, 안정)
   ② 리뷰 점검  : cf_naver_booking 리다이렉트로 플레이스 URL 자동확보 → 자동추출 시도(best-effort) + 수동 붙여넣기 → Gemini 정상/불만/악성 분류
   ③ 블로그 언급 : 블로그검색 API(공식) — 병원명+자동별칭 검색, 자사 블로그 제외, 지역·치과 키워드로 관련성 판정
   ④ 지식iN 질문 : 지식iN검색 API(공식) — 지역+치과 키워드 신규질문 수집 (답변 초안 파이프라인의 앞단)
   ============================================================ */

// ── 테이블 자동 생성 (dm_social 패턴) ──
sql_query("CREATE TABLE IF NOT EXISTS `dm_place_state` (
    `id` INT(11) NOT NULL DEFAULT 1,
    `place_url` VARCHAR(500) DEFAULT '',
    `place_id` VARCHAR(50) DEFAULT '',
    `last_checked` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
sql_query("INSERT IGNORE INTO dm_place_state (id) VALUES (1)");

sql_query("CREATE TABLE IF NOT EXISTS `dm_place_check` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `checked_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `matched_title` VARCHAR(300) DEFAULT '',
    `phone_status` VARCHAR(10) DEFAULT '',
    `phone_found` VARCHAR(50) DEFAULT '',
    `address_status` VARCHAR(10) DEFAULT '',
    `address_found` VARCHAR(300) DEFAULT '',
    `api_ok` TINYINT(1) DEFAULT 0,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

sql_query("CREATE TABLE IF NOT EXISTS `dm_place_review` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `source` VARCHAR(10) DEFAULT 'manual',
    `content` TEXT,
    `sentiment` VARCHAR(10) DEFAULT '',
    `sentiment_note` VARCHAR(300) DEFAULT '',
    `content_hash` VARCHAR(64) DEFAULT '',
    `is_read` TINYINT(1) DEFAULT 0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `content_hash` (`content_hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

sql_query("CREATE TABLE IF NOT EXISTS `dm_blog_mention` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `title` VARCHAR(500) DEFAULT '',
    `description` TEXT,
    `link` VARCHAR(500) DEFAULT '',
    `link_hash` VARCHAR(64) DEFAULT '',
    `blogger_name` VARCHAR(200) DEFAULT '',
    `post_date` VARCHAR(20) DEFAULT '',
    `relevance` VARCHAR(10) DEFAULT '',           /* 관련 / 확인필요 */
    `matched_kw` VARCHAR(100) DEFAULT '',
    `is_read` TINYINT(1) DEFAULT 0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `link_hash` (`link_hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

sql_query("CREATE TABLE IF NOT EXISTS `dm_kin_question` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `title` VARCHAR(500) DEFAULT '',
    `description` TEXT,
    `link` VARCHAR(500) DEFAULT '',
    `link_hash` VARCHAR(64) DEFAULT '',
    `search_kw` VARCHAR(100) DEFAULT '',
    `is_read` TINYINT(1) DEFAULT 0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `link_hash` (`link_hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// 언급 구분 컬럼 (own=자사, competitor=타업체) — 기존 테이블에도 자동 추가
foreach (['dm_blog_mention','dm_kin_question'] as $__t) {
    $__c = sql_query("SHOW COLUMNS FROM `{$__t}` LIKE 'mention_type'");
    if ($__c && !sql_fetch_array($__c)) {
        sql_query("ALTER TABLE `{$__t}` ADD COLUMN `mention_type` VARCHAR(15) DEFAULT 'own'");
    }
}


sql_query("CREATE TABLE IF NOT EXISTS `dm_place_aitab_check` (
    `item_key` VARCHAR(30) NOT NULL,
    `status` VARCHAR(10) DEFAULT '확인필요',
    `note` VARCHAR(300) DEFAULT '',
    `updated_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`item_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ── site_config 값 전부 자동 로드 ──
$dm_conf = sql_fetch("SELECT * FROM dm_config WHERE cf_id = 1") ?: [];
$SITE_NAME    = trim($dm_conf['cf_site_name'] ?? '');
$SITE_TEL     = trim($dm_conf['cf_tel'] ?? '');
$SITE_ADDR    = trim($dm_conf['cf_address'] ?? '');
// 지역: 시군구 + 구 조합 (예: "안산시 상록구") — 검색 정확도용
$SITE_SIGUNGU = trim(trim($dm_conf['cf_sigungu'] ?? '') . ' ' . trim($dm_conf['cf_gu'] ?? ''));
$SITE_EXPERTISE = trim($dm_conf['cf_expertise'] ?? '');
$SITE_SPECIALTY = trim($dm_conf['cf_org_specialty'] ?? '');

// ── 업종별 문맥 키워드 (site_config의 cf_org_specialty 기준) ──
// "타업체 언급"을 판정할 때, 같은 업종의 업체 글만 잡기 위함
$SPECIALTY_MAP = [
    'dentist'        => ['치과','치의학','임플란트','교정','스케일링','충치','신경치료','보철','틀니','치아','잇몸','사랑니','턱관절'],
    'dermatology'    => ['피부과','피부','레이저','보톡스','필러','여드름','기미','리프팅'],
    'orthopedic'     => ['정형외과','디스크','관절','척추','재활','도수치료'],
    'plasticsurgery' => ['성형외과','성형','쌍꺼풀','코성형','안면윤곽','지방흡입'],
];
$SPECIALTY_KWS = $SPECIALTY_MAP[$SITE_SPECIALTY] ?? $SPECIALTY_MAP['dentist'];

// ── 진료과목(cf_org_specialty) → 업종 키워드 매핑 ──
// 타업체 언급을 "같은 업종"으로만 한정하기 위함 (치과면 치과 글만)
$SPECIALTY_MAP = [
    'dentist'        => ['치과', '치의학', '임플란트', '교정'],
    'dermatology'    => ['피부과', '피부'],
    'orthopedic'     => ['정형외과', '정형'],
    'plasticsurgery' => ['성형외과', '성형'],
    'oriental'       => ['한의원', '한방'],
    'internal'       => ['내과'],
    'ophthalmology'  => ['안과'],
    'otolaryngology' => ['이비인후과'],
];
$ORG_SPECIALTY = trim($dm_conf['cf_org_specialty'] ?? '');
$SPECIALTY_KWS = $SPECIALTY_MAP[$ORG_SPECIALTY] ?? [];
// 매핑에 없으면 병원명에서 업종 추출 시도 (예: "서울상록수치과" → "치과")
if (empty($SPECIALTY_KWS)) {
    foreach ($SPECIALTY_MAP as $sp => $kws) {
        if (mb_strpos($SITE_NAME, $kws[0]) !== false) { $SPECIALTY_KWS = $kws; break; }
    }
}
$NAVER_BOOK   = trim($dm_conf['cf_naver_booking'] ?? '');
$OWN_BLOG     = trim($dm_conf['cf_blog'] ?? '');
$NAVER_ID     = trim($dm_conf['cf_naver_client_id'] ?? '');
$NAVER_SECRET = trim($dm_conf['cf_naver_secret'] ?? '');
$GEMINI_KEY   = trim($dm_conf['cf_gemini_key'] ?? '');

// 멀티대시 수신 주소 (export 전송 대상) — 메디템플릿 index로 push
define('PM_DASH_URL', 'https://medintemplate.mycafe24.com/index.php');
define('PM_DASH_TOKEN', 'kimnerd91');

$pstate = sql_fetch("SELECT * FROM dm_place_state WHERE id=1");
$last_checked = $pstate['last_checked'] ?? null;
$days_since = $last_checked ? floor((time() - strtotime($last_checked)) / 86400) : null;
$needs_check = ($days_since === null || $days_since >= 7);

// ── 자동 별칭 생성 : "서울상록수치과의원" → [원명, -의원, 치과의원→치과, 지역접두 제거형] ──
function pm_gen_aliases($name) {
    $out = [];
    $n = trim($name);
    if (!$n) return $out;
    $out[] = $n;
    $v = preg_replace('/의원$/u', '', $n);            if ($v !== $n) $out[] = $v;
    $v2 = preg_replace('/치과의원$/u', '치과', $n);    if ($v2 !== $n) $out[] = $v2;
    // 지역 접두사 제거형 (예: "서울상록수치과" → "상록수치과") — 3글자 이상 남을 때만
    foreach ($out as $a) {
        if (preg_match('/^(서울|부산|대구|인천|광주|대전|울산|경기|송도|강남|분당|일산|수원)(.+치과.*)$/u', $a, $m) && mb_strlen($m[2]) >= 4) {
            $out[] = $m[2];
        }
    }
    return array_values(array_unique(array_filter($out, function($s){ return mb_strlen($s) >= 3; })));
}

// ── 주소에서 지역 키워드 추출 (구/동/시) ──
function pm_extract_regions($addr) {
    $regions = [];
    if (preg_match_all('/([가-힣]{1,6}(?:광역시|특별시|시|군|구|동|읍|면|로|길))(?=\s|$|\d)/u', $addr, $mm)) {
        foreach ($mm[1] as $t) {
            // 도로명(로/길)은 제외하고 행정단위만
            if (preg_match('/(로|길)$/u', $t)) continue;
            $t2 = preg_replace('/(광역시|특별시)$/u', '', $t);
            if (mb_strlen($t2) >= 2) $regions[] = $t2;
        }
    }
    return array_values(array_unique($regions));
}

$ALIASES = pm_gen_aliases($SITE_NAME);
$REGIONS = pm_extract_regions($SITE_ADDR);

// ── 자사 블로그 ID 추출 (언급 목록에서 자사 글 제외용) ──
function pm_own_blog_id($blog_url) {
    if (preg_match('#blog\.naver\.com/([\w\-.]+)#', $blog_url, $m)) return $m[1];
    return '';
}
$OWN_BLOG_ID = pm_own_blog_id($OWN_BLOG);

// ── 공통 fetch ──
function pm_fetch($url, &$final_url = null) {
    // ★ 이 설정 그대로여야 네이버 플레이스가 응답한다(진단으로 검증됨).
    //   특히 CURLOPT_ENCODING='' (gzip 자동해제)가 없으면 빈 응답처럼 보인다.
    $ua = 'Mozilla/5.0 (Linux; Android 12; SM-S906N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36';
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 8,
            CURLOPT_TIMEOUT        => 20,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_USERAGENT      => $ua,
            CURLOPT_ENCODING       => '',          // gzip/deflate 자동 해제 ★필수
            CURLOPT_COOKIEFILE     => '',          // 세션 쿠키 유지
            CURLOPT_HTTPHEADER     => [
                'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language: ko-KR,ko;q=0.9,en;q=0.8',
                'Cache-Control: no-cache',
                'Referer: https://m.place.naver.com/',
            ],
        ]);
        $body = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $final_url = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
        curl_close($ch);
        return ($code >= 200 && $code < 400 && strlen((string)$body) > 100) ? $body : false;
    }
    $ctx = stream_context_create(['http'=>['timeout'=>20,'user_agent'=>$ua,'follow_location'=>1]]);
    return @file_get_contents($url, false, $ctx);
}

// ── 네이버 오픈API 공통 호출 ──
function pm_naver_api($endpoint, $query, $id, $secret, $display = 30) {
    $ch = curl_init("https://openapi.naver.com/v1/search/{$endpoint}.json?query=".urlencode($query)."&display={$display}&sort=date");
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER=>true,
        CURLOPT_HTTPHEADER=>["X-Naver-Client-Id: {$id}", "X-Naver-Client-Secret: {$secret}"],
        CURLOPT_TIMEOUT=>10,
    ]);
    $resp = curl_exec($ch); $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    if ($code !== 200) return null;
    return json_decode($resp, true);
}

function pm_norm_tel($s) { return preg_replace('/[^0-9]/', '', (string)$s); }

// ── 플레이스 URL 자동 확보 : cf_naver_booking(naver.me 단축링크) 리다이렉트 추적 ──
function pm_resolve_place($book_url) {
    if (!$book_url) return ['url'=>'', 'id'=>''];
    $final = null;
    pm_fetch($book_url, $final);
    if (!$final) return ['url'=>'', 'id'=>''];
    $pid = '';

    // (1) 정식 플레이스 URL
    if (preg_match('#(?:place|m\.place)\.naver\.com/(?:hospital|place|clinic)/(\d+)#', $final, $m)) {
        $pid = $m[1];
    }
    // (2) appLink URL (m.map.naver.com/appLink.naver?pinId=123456) — pinId가 곧 플레이스ID
    elseif (preg_match('#[?&]pinId=(\d+)#', $final, $m)) {
        $pid = $m[1];
    }
    // (3) 기타 id= 파라미터
    elseif (preg_match('#[?&]id=(\d+)#', $final, $m)) {
        $pid = $m[1];
    }

    // ID를 얻으면 스크래핑 가능한 정식 플레이스 URL로 재구성
    // (appLink URL은 앱 실행용이라 그대로 긁으면 리뷰/영업시간/사진이 전부 실패함)
    $url = $pid ? ('https://m.place.naver.com/hospital/' . $pid) : $final;
    return ['url'=>$url, 'id'=>$pid];
}

// ── 스크래핑 가능한 플레이스 URL 확보 (저장된 값이 appLink 등 잘못된 형식이면 재확보) ──
function pm_get_place_url($pstate, $NAVER_BOOK) {
    $purl = trim($pstate['place_url'] ?? '');
    // 정식 플레이스 URL(m.place.naver.com/...)이 아니면 잘못 저장된 것 → 재확보
    $is_valid = $purl && preg_match('#m\.place\.naver\.com/(?:hospital|place|clinic)/\d+#', $purl);
    if (!$is_valid && $NAVER_BOOK) {
        $r = pm_resolve_place($NAVER_BOOK);
        if ($r['url'] && $r['id']) {
            $purl = $r['url'];
            sql_query("UPDATE dm_place_state SET place_url='".sql_escape_string($purl)."', place_id='".sql_escape_string($r['id'])."' WHERE id=1");
        } elseif ($r['url']) {
            $purl = $r['url'];
        }
    }
    return $purl;
}

// ── Gemini 감성 분류 ──
function pm_gemini_sentiment($key, $text) {
    if (!$key) return ['label'=>'미분류', 'note'=>'Gemini 키 미설정'];
    $sys = <<<SYS
당신은 병원 리뷰 모니터링 담당자입니다. 아래 리뷰 한 건을 3단계 중 하나로 분류하세요.
- 정상: 일반적인 긍정/중립 후기
- 불만: 불편·아쉬움 표현이 있으나 의료분쟁·법적 이슈 수준은 아님
- 악성: 의료사고·과실 암시, 협박성 표현, 허위사실 의심, 심각한 명예훼손, 경쟁업체 어뷰징 의심

출력은 반드시 아래 JSON 하나만:
{"label":"정상|불만|악성","note":"한 문장 이유"}
SYS;
    $payload = [
        'system_instruction' => ['parts'=>[['text'=>$sys]]],
        'contents' => [['role'=>'user','parts'=>[['text'=>$text]]]],
        'generationConfig' => ['temperature'=>0.1, 'maxOutputTokens'=>800, 'responseMimeType'=>'application/json'],
    ];
    $ch = curl_init("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=".$key);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER=>true, CURLOPT_POST=>true,
        CURLOPT_HTTPHEADER=>['Content-Type: application/json'],
        CURLOPT_POSTFIELDS=>json_encode($payload, JSON_UNESCAPED_UNICODE),
        CURLOPT_TIMEOUT=>30, CURLOPT_SSL_VERIFYPEER=>false,
    ]);
    $resp = curl_exec($ch); $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    if ($code !== 200) return ['label'=>'미분류', 'note'=>'Gemini 호출 실패('.$code.')'];
    $j = json_decode($resp, true);
    $txt = trim(preg_replace('/```json|```/', '', $j['candidates'][0]['content']['parts'][0]['text'] ?? ''));
    $parsed = json_decode($txt, true);
    if (is_array($parsed) && !empty($parsed['label'])) {
        return ['label'=>$parsed['label'], 'note'=>$parsed['note'] ?? ''];
    }
    // 폴백 1: 응답 안에 JSON 조각이 섞여 있으면 그것만 뽑기
    if (preg_match('/\{[^{}]*"label"[^{}]*\}/u', $txt, $m)) {
        $p2 = json_decode($m[0], true);
        if (is_array($p2) && !empty($p2['label'])) return ['label'=>$p2['label'], 'note'=>$p2['note'] ?? ''];
    }
    // 폴백 2: 라벨 단어만이라도 찾기
    foreach (['악성','불만','정상'] as $lb) {
        if (mb_strpos($txt, $lb) !== false) return ['label'=>$lb, 'note'=>'자동판정(형식 폴백)'];
    }
    return ['label'=>'미분류', 'note'=>'응답 파싱 실패: '.mb_substr($txt, 0, 60)];
}

// ── 블로그 글 관련성 판정 : 자사병원 글이 맞는지 (지역명 또는 치과 키워드 포함 여부) ──
function pm_blog_relevance($title, $desc, $regions, $aliases) {
    $text = $title . ' ' . $desc;
    // 별칭 완전일치가 이미 검색조건이므로, 동명 타업체 걸러내기: 지역명 포함 or 치과 문맥
    foreach ($regions as $rg) {
        if (mb_strpos($text, $rg) !== false) return ['relevance'=>'관련', 'kw'=>$rg];
    }
    if (mb_strpos($text, '치과') !== false || mb_strpos($text, '임플란트') !== false || mb_strpos($text, '교정') !== false) {
        return ['relevance'=>'관련', 'kw'=>'치과문맥'];
    }
    return ['relevance'=>'확인필요', 'kw'=>''];
}

// ============================================================
// 점검 실행 함수들 (단독/일괄 공용)
// ============================================================

function pm_do_nap($SITE_NAME, $SITE_TEL, $SITE_ADDR, $ALIASES, $NAVER_ID, $NAVER_SECRET) {
    if (!$NAVER_ID || !$NAVER_SECRET) return ['success'=>0,'message'=>'네이버 API 키 미설정'];
    if (!$SITE_NAME) return ['success'=>0,'message'=>'cf_site_name 미설정'];

    // 지역검색 API — 병원명(+별칭)으로 검색, 주소가 가장 근접한 결과 채택
    $best = null;
    foreach ($ALIASES as $kw) {
        $j = pm_naver_api('local', $kw, $NAVER_ID, $NAVER_SECRET, 5);
        if (!$j || empty($j['items'])) continue;
        foreach ($j['items'] as $it) {
            $t = strip_tags($it['title'] ?? '');
            $road = $it['roadAddress'] ?? '';
            // 주소 앞 10글자 겹침으로 자사 판정
            $a1 = preg_replace('/\s+/', '', $road);
            $a2 = preg_replace('/\s+/', '', $SITE_ADDR);
            $addr_hit = ($a2 && $a1 && (strpos($a1, mb_substr($a2,0,10)) !== false || strpos($a2, mb_substr($a1,0,10)) !== false));
            $name_hit = (mb_strpos(preg_replace('/\s+/','',$t), preg_replace('/\s+/','',$kw)) !== false);
            if ($addr_hit || ($name_hit && !$best)) {
                $best = ['title'=>$t, 'road'=>$road, 'tel'=>$it['telephone'] ?? '', 'addr_hit'=>$addr_hit];
                if ($addr_hit) break 2; // 주소까지 맞으면 확정
            }
        }
        usleep(150000);
    }

    if (!$best) {
        sql_query("INSERT INTO dm_place_check (matched_title, phone_status, address_status, api_ok) VALUES ('', 'unknown', 'unknown', 0)");
        return ['success'=>0,'message'=>'지역검색에서 병원을 찾지 못했습니다 — 플레이스 미등록이거나 상호가 크게 다를 수 있습니다.'];
    }

    $phone_found = $best['tel'];
    $address_found = $best['road'];
    $phone_status = 'unknown'; $address_status = 'unknown';
    if ($phone_found) $phone_status = (pm_norm_tel($phone_found) === pm_norm_tel($SITE_TEL)) ? 'match' : 'mismatch';
    if ($address_found) $address_status = $best['addr_hit'] ? 'match' : 'mismatch';

    sql_query("INSERT INTO dm_place_check (matched_title, phone_status, phone_found, address_status, address_found, api_ok)
               VALUES ('".sql_escape_string($best['title'])."','".sql_escape_string($phone_status)."','".sql_escape_string($phone_found)."','".sql_escape_string($address_status)."','".sql_escape_string($address_found)."', 1)");
    return ['success'=>1,'matched'=>$best['title'],'phone_status'=>$phone_status,'address_status'=>$address_status];
}

// ── 네이버 플레이스 임베디드 JSON(__APOLLO_STATE__) 추출 ──
//    페이지 안에 GraphQL 정규화 캐시가 통째로 들어있다. 정규식으로 긁지 말고 이걸 파싱한다.
function pm_extract_apollo($html) {
    $anchor = strpos($html, '__APOLLO_STATE__');
    if ($anchor === false) return null;
    $eq = strpos($html, '=', $anchor);
    if ($eq === false) return null;
    $start = strpos($html, '{', $eq);
    if ($start === false) return null;

    // 문자열/이스케이프를 존중하며 중괄호 짝 맞추기
    $len = strlen($html); $depth = 0; $in_str = false; $esc = false;
    for ($i = $start; $i < $len; $i++) {
        $ch = $html[$i];
        if ($in_str) {
            if ($esc) { $esc = false; continue; }
            if ($ch === '\\') { $esc = true; continue; }
            if ($ch === '"') $in_str = false;
            continue;
        }
        if ($ch === '"') { $in_str = true; continue; }
        if ($ch === '{') $depth++;
        elseif ($ch === '}') {
            $depth--;
            if ($depth === 0) {
                $data = json_decode(substr($html, $start, $i - $start + 1), true);
                return is_array($data) ? $data : null;
            }
        }
    }
    return null;
}

// 방문자 리뷰 추출 (본문·날짜·사업주답글 여부)
function pm_apollo_reviews($apollo) {
    $out = [];
    foreach ($apollo as $val) {
        if (!is_array($val)) continue;
        if (($val['__typename'] ?? '') !== 'VisitorReview') continue;
        $body = trim((string)($val['body'] ?? ''));
        if ($body === '' || mb_strlen($body) < 5) continue;
        $reply = $val['reply'] ?? null;
        $out[] = [
            'body'      => $body,
            'date'      => (string)($val['visited'] ?? ($val['created'] ?? '')),
            'has_reply' => (is_array($reply) && trim((string)($reply['body'] ?? '')) !== ''),
        ];
    }
    return $out;
}

// 영업시간 추출 (요일별 시작/종료)
function pm_apollo_hours($apollo) {
    foreach ($apollo as $val) {
        if (!is_array($val) || !isset($val['businessHours']) || !is_array($val['businessHours'])) continue;
        $list = $val['businessHours'];
        if (!isset($list[0]) || !is_array($list[0])) continue;
        $days = [];
        foreach ($list as $wh) {
            if (!is_array($wh)) continue;
            $day = (string)($wh['day'] ?? '');
            $bh  = $wh['businessHours'] ?? null;
            if ($day === '' || !is_array($bh)) continue;
            $s = (string)($bh['start'] ?? ''); $e = (string)($bh['end'] ?? '');
            if ($s === '' && $e === '') continue;
            $days[] = $day.' '.$s.'~'.$e;
        }
        if ($days) return $days;
    }
    return [];
}

function pm_do_reviews($place_url, $GEMINI_KEY) {
    if (!$place_url) return ['success'=>0,'message'=>'플레이스 URL 미확보 — 사이트 설정의 네이버 예약링크를 등록하세요.','new'=>0];
    $rurl = preg_replace('#/(home|review)(/.*)?$#', '', rtrim($place_url,'/')) . '/review/visitor';
    $html = pm_fetch($rurl);
    if (!$html) return ['success'=>0,'message'=>'리뷰 페이지 수집 실패 — 수동 붙여넣기를 이용하세요.','new'=>0];

    $apollo = pm_extract_apollo($html);
    $reviews = $apollo ? pm_apollo_reviews($apollo) : [];

    if (empty($reviews)) {
        return ['success'=>0,'message'=>'리뷰 데이터를 못 찾았습니다(네이버 구조 변경 가능) — 수동 붙여넣기를 이용하세요.','new'=>0];
    }

    $new = 0; $replied = 0;
    foreach ($reviews as $rv) {
        if ($rv['has_reply']) $replied++;
        $hash = hash('sha256', $rv['body']);
        if (sql_fetch("SELECT id FROM dm_place_review WHERE content_hash='".$hash."'")) continue;
        $sent = pm_gemini_sentiment($GEMINI_KEY, $rv['body']);
        $note = trim($sent['note'] . ($rv['has_reply'] ? '' : ' / 사업주 답글 없음'));
        sql_query("INSERT INTO dm_place_review (source, content, sentiment, sentiment_note, content_hash)
                   VALUES ('auto','".sql_escape_string($rv['body'])."','".sql_escape_string($sent['label'])."','".sql_escape_string($note)."','$hash')");
        $new++;
    }
    return ['success'=>1,'new'=>$new,
            'message'=>'리뷰 '.count($reviews).'건 확인 (답글 '.$replied.'건) · 신규 '.$new.'건'];
}


// ── 언급 분류: own(자사) / competitor(동종 타업체) / null(무관 — 버림) ──
//   own        : 병원명 AND 지역명
//   competitor : 지역명 AND 업종키워드(치과 등) AND 병원명 없음
//   그 외      : 수집하지 않음 (전혀 무관한 글)
function pm_classify_mention($title, $desc, $ALIASES, $SIGUNGU, $SPECIALTY_KWS) {
    $blob = preg_replace('/\s+/', '', $title.$desc);

    // 병원명 포함 여부
    $name_hit = false;
    foreach ($ALIASES as $a) {
        if (mb_strpos($blob, preg_replace('/\s+/','',$a)) !== false) { $name_hit = true; break; }
    }

    // 지역명 포함 여부 (병원명이 지역명을 품을 수 있어 병원명 제거 후 탐색)
    $blob_wo_name = $blob;
    foreach ($ALIASES as $a) { $blob_wo_name = str_replace(preg_replace('/\s+/','',$a), '', $blob_wo_name); }
    $region_hit = false;
    if ($SIGUNGU) {
        foreach (preg_split('/\s+/', $SIGUNGU) as $rg) {
            $rg = trim($rg); if ($rg === '') continue;
            $rg_short = preg_replace('/(시|군|구)$/u', '', $rg);
            if (mb_strpos($blob_wo_name, $rg) !== false || ($rg_short && mb_strpos($blob_wo_name, $rg_short) !== false)) { $region_hit = true; break; }
        }
    } else { $region_hit = true; }   // 지역 미설정이면 지역 조건 무시

    // 업종 키워드 포함 여부 (치과 등) — 무관한 글 배제
    $spec_hit = empty($SPECIALTY_KWS);   // 업종 미설정이면 통과
    foreach ($SPECIALTY_KWS as $kw) {
        if (mb_strpos($blob, $kw) !== false) { $spec_hit = true; break; }
    }
    if (!$spec_hit) return null;   // 업종과 무관한 글 → 버림

    if ($name_hit && $region_hit) return 'own';
    if ($name_hit && !$region_hit) return null;          // 동명 타지역 병원 → 버림
    if (!$name_hit && $region_hit) return 'competitor';  // 같은 지역 동종 타업체
    return null;
}

function pm_do_blog($ALIASES, $SIGUNGU, $SPECIALTY_KWS, $OWN_BLOG_ID, $NAVER_ID, $NAVER_SECRET) {
    if (!$NAVER_ID || !$NAVER_SECRET) return ['success'=>0,'message'=>'네이버 API 키 미설정','new'=>0];
    $new = 0; $new_own = 0; $new_comp = 0;

    // 검색어: 자사(병원명, 병원명+지역) + 타업체(지역+업종)
    $queries = [];
    foreach ($ALIASES as $kw) {
        $queries[] = $kw;
        if ($SIGUNGU) $queries[] = $SIGUNGU.' '.$kw;
    }
    if ($SIGUNGU && !empty($SPECIALTY_KWS)) $queries[] = $SIGUNGU.' '.$SPECIALTY_KWS[0];
    $queries = array_values(array_unique($queries));

    foreach ($queries as $kw) {
        $j = pm_naver_api('blog', $kw, $NAVER_ID, $NAVER_SECRET, 30);
        if (!$j) continue;
        foreach (($j['items'] ?? []) as $it) {
            $link = strip_tags($it['link'] ?? '');
            if (!$link) continue;
            if ($OWN_BLOG_ID && strpos($link, 'blog.naver.com/'.$OWN_BLOG_ID) !== false) continue;
            $title = strip_tags($it['title'] ?? '');
            $desc  = strip_tags($it['description'] ?? '');

            $mtype = pm_classify_mention($title, $desc, $ALIASES, $SIGUNGU, $SPECIALTY_KWS);
            if (!$mtype) continue;   // 무관한 글 / 동명 타지역 → 버림

            $lhash = hash('sha256', $link);
            if (sql_fetch("SELECT id FROM dm_blog_mention WHERE link_hash='".$lhash."'")) continue;
            $rel = pm_blog_relevance($title, $desc, $SIGUNGU ? [$SIGUNGU] : [], $ALIASES);
            sql_query("INSERT INTO dm_blog_mention (title, description, link, link_hash, blogger_name, post_date, relevance, matched_kw, mention_type)
                       VALUES ('".sql_escape_string($title)."','".sql_escape_string($desc)."','".sql_escape_string($link)."','$lhash','".sql_escape_string(strip_tags($it['bloggername'] ?? ''))."','".sql_escape_string($it['postdate'] ?? '')."','".sql_escape_string($rel['relevance'])."','".sql_escape_string($rel['kw'])."','".$mtype."')");
            $new++;
            if ($mtype === 'own') $new_own++; else $new_comp++;
        }
        usleep(200000);
    }
    return ['success'=>1,'new'=>$new,'own'=>$new_own,'competitor'=>$new_comp];
}

function pm_do_kin($ALIASES, $SIGUNGU, $SPECIALTY_KWS, $NAVER_ID, $NAVER_SECRET) {
    if (!$NAVER_ID || !$NAVER_SECRET) return ['success'=>0,'message'=>'네이버 API 키 미설정','new'=>0];
    $kws = [];
    foreach ($ALIASES as $a) {
        $kws[] = $a;
        if ($SIGUNGU) $kws[] = $SIGUNGU.' '.$a;
    }
    if ($SIGUNGU && !empty($SPECIALTY_KWS)) $kws[] = $SIGUNGU.' '.$SPECIALTY_KWS[0];
    $kws = array_values(array_unique($kws));

    $new = 0; $new_own = 0; $new_comp = 0;
    foreach ($kws as $kw) {
        $j = pm_naver_api('kin', $kw, $NAVER_ID, $NAVER_SECRET, 20);
        if (!$j) continue;
        foreach (($j['items'] ?? []) as $it) {
            $link = strip_tags($it['link'] ?? '');
            if (!$link) continue;
            $title = strip_tags($it['title'] ?? '');
            $desc  = strip_tags($it['description'] ?? '');

            $mtype = pm_classify_mention($title, $desc, $ALIASES, $SIGUNGU, $SPECIALTY_KWS);
            if (!$mtype) continue;

            $lhash = hash('sha256', $link);
            if (sql_fetch("SELECT id FROM dm_kin_question WHERE link_hash='".$lhash."'")) continue;
            sql_query("INSERT INTO dm_kin_question (title, description, link, link_hash, search_kw, mention_type)
                       VALUES ('".sql_escape_string($title)."','".sql_escape_string($desc)."','".sql_escape_string($link)."','$lhash','".sql_escape_string($kw)."','".$mtype."')");
            $new++;
            if ($mtype === 'own') $new_own++; else $new_comp++;
        }
        usleep(200000);
    }
    return ['success'=>1,'new'=>$new,'own'=>$new_own,'competitor'=>$new_comp];
}

function pm_aitab_set($key, $status, $note) {
    sql_query("UPDATE dm_place_aitab_check SET status='".sql_escape_string($status)."', note='".sql_escape_string($note)."', updated_at=NOW() WHERE item_key='".sql_escape_string($key)."'");
}

// ── AI탭 체크리스트 자동감지 (best-effort) ──
// 네이버 플레이스 홈 페이지 임베디드 JSON을 정규식으로 파싱. 리뷰 자동추출과 동일한 방식 —
// 비공식 구조 의존이라 네이버 페이지 개편 시 매칭 실패할 수 있음(실패해도 기존 수동값 유지, 에러 아님).
function pm_do_aitab_auto($place_url, $EXPERTISE = '', $NAVER_BOOK = '') {
    // ── 1단계: site_config 내부값으로 먼저 채움 (네이버 안 긁어도 되는 항목) ──
    // 진료항목: cf_expertise에 항목이 있으면 양호
    $exp_items = array_values(array_filter(array_map('trim', preg_split('/[\r\n,]+/', $EXPERTISE))));
    if (count($exp_items) >= 3) {
        pm_aitab_set('menu_detail', '양호', '내부값: 진료과목 '.count($exp_items).'개(site_config)');
    } elseif (count($exp_items) >= 1) {
        pm_aitab_set('menu_detail', '미흡', '진료과목이 '.count($exp_items).'개뿐 → 사이트설정에서 3개 이상 등록하고, 네이버 플레이스에도 동일하게 입력하세요');
    }
    // 예약연동: cf_naver_booking 있으면 양호
    if (trim($NAVER_BOOK) !== '') {
        pm_aitab_set('booking_link', '양호', '내부값: 예약링크 설정됨(cf_naver_booking)');
    }

    // ── 2단계: 나머지(운영시간·사진·리뷰답글) + 내부값 없던 항목은 네이버 플레이스 자동감지 ──
    if (!$place_url) {
        // 플레이스 URL 없음 — 내부값으로 못 채운 항목은 확인불가로
        foreach (['hours','photo_recent','review_reply'] as $k) pm_aitab_set_if_empty($k, '확인불가', '사이트 설정의 네이버 예약링크(cf_naver_booking)가 없거나 잘못됐습니다 → 플레이스 URL을 확보해야 자동감지가 됩니다');
        if (count($exp_items) === 0) pm_aitab_set_if_empty('menu_detail', '확인불가', '진료항목이 등록돼 있지 않습니다 → 사이트 설정의 전문진료 항목을 채우고 플레이스 메뉴도 등록하세요');
        if (trim($NAVER_BOOK) === '') pm_aitab_set_if_empty('booking_link', '확인불가', '사이트 설정에 네이버 예약링크가 없습니다 → 예약 연동 후 링크를 등록하세요');
        return ['success'=>1,'matched'=>0,'message'=>'내부값만 반영(플레이스 URL 없음)'];
    }
    $home_url = preg_replace('#/(home|review)(/.*)?$#', '', rtrim($place_url,'/')) . '/home';
    $html = pm_fetch($home_url);
    if (!$html) {
        // ── 3단계: 플레이스마저 막힘 → 내부값 없던 항목은 확인불가 ──
        foreach (['hours','photo_recent','review_reply'] as $k) pm_aitab_set_if_empty($k, '확인불가', '네이버가 플레이스 페이지를 막았습니다 → 네이버 플레이스에서 직접 확인 후 아래에서 수동 기록하세요');
        return ['success'=>0,'matched'=>0,'message'=>'플레이스 수집 실패 — 내부값 외 항목은 확인불가 처리'];
    }

    $matched = 0;
    $apollo = pm_extract_apollo($html);   // ★ 임베디드 GraphQL 캐시 파싱 (정규식 추측 대신 구조 파싱)

    // ── 운영시간 ──
    $hours = $apollo ? pm_apollo_hours($apollo) : [];
    if ($hours) {
        pm_aitab_set('hours', '양호', '자동감지: ' . implode(' / ', array_slice($hours, 0, 7)));
        $matched++;
    } else {
        pm_aitab_set_if_empty('hours', '확인불가', '플레이스에 영업시간이 등록돼 있지 않습니다 → 네이버 플레이스에서 영업시간을 등록하세요');
    }

    // ── 진료항목: 내부값(cf_expertise)이 3개 미만일 때만 플레이스로 보강 ──
    if (count($exp_items) < 3 && $apollo) {
        $menus = 0;
        foreach ($apollo as $v) {
            if (!is_array($v)) continue;
            $tn = $v['__typename'] ?? '';
            if (stripos($tn, 'Menu') !== false && trim((string)($v['name'] ?? '')) !== '') $menus++;
        }
        if ($menus >= 3) { pm_aitab_set('menu_detail', '양호', '자동감지: 플레이스 진료항목 '.$menus.'개'); $matched++; }
    }

    // ── 대표 사진 최신성 ──
    $photo_dates = [];
    if ($apollo) {
        foreach ($apollo as $v) {
            if (!is_array($v)) continue;
            $tn = $v['__typename'] ?? '';
            if (stripos($tn, 'Photo') === false && stripos($tn, 'Image') === false) continue;
            foreach (['date','regDate','uploadDate','created','createdAt'] as $dk) {
                $dv = (string)($v[$dk] ?? '');
                if (preg_match('/(\d{4})[-.](\d{2})[-.](\d{2})/', $dv, $dm)) { $photo_dates[] = $dm[1].'-'.$dm[2].'-'.$dm[3]; break; }
            }
        }
    }
    if ($photo_dates) {
        rsort($photo_dates); $latest = $photo_dates[0];
        $days = floor((time() - strtotime($latest)) / 86400);
        pm_aitab_set('photo_recent', $days <= 180 ? '양호' : '미흡',
            $days <= 180 ? '최근 사진 '.$latest.' ('.$days.'일 전)' : '사진이 오래됐습니다 ('.$latest.', '.$days.'일 전) → 플레이스에 최신 사진을 올리세요');
        $matched++;
    } else {
        pm_aitab_set_if_empty('photo_recent', '확인불가', '플레이스 사진 날짜를 확인할 수 없습니다 → 대표 사진이 최신인지 직접 확인하세요');
    }

    // ── 예약 버튼 (내부 예약링크가 없을 때만 교차확인) ──
    if (trim($NAVER_BOOK) === '') {
        if (strpos($html, 'hasBooking":true') !== false || strpos($html, 'BookingButton') !== false) {
            pm_aitab_set('booking_link', '양호', '자동감지: 플레이스 예약 버튼 확인'); $matched++;
        } else {
            pm_aitab_set_if_empty('booking_link', '확인불가', '플레이스에 예약 버튼이 없습니다 → 네이버 예약을 연동하세요');
        }
    }

    // ── 리뷰 답글률 (구조 파싱) ──
    $rurl = preg_replace('#/(home|review)(/.*)?$#', '', rtrim($place_url,'/')) . '/review/visitor';
    $rhtml = pm_fetch($rurl);
    if ($rhtml) {
        $rapollo = pm_extract_apollo($rhtml);
        $revs = $rapollo ? pm_apollo_reviews($rapollo) : [];
        $total = count($revs);
        $replied = 0;
        foreach ($revs as $rv) if ($rv['has_reply']) $replied++;
        if ($total > 0) {
            $rate = round($replied / $total * 100);
            if ($rate >= 70)      pm_aitab_set('review_reply', '양호', "답글률 {$rate}% ({$replied}/{$total}건) — 잘 관리되고 있습니다");
            elseif ($replied > 0) pm_aitab_set('review_reply', '미흡', "답글률 {$rate}% ({$replied}/{$total}건) → 답글 없는 리뷰 " . ($total-$replied) . "건에 답글을 다세요 (AI탭 신뢰 신호)");
            else                  pm_aitab_set('review_reply', '미흡', "답글 0건 ({$total}건 리뷰 전부 미응답) → 네이버 플레이스 리뷰에 답글을 다세요");
            $matched++;
        } else {
            pm_aitab_set_if_empty('review_reply', '확인불가', '리뷰 데이터를 읽지 못했습니다 (네이버 구조 변경 가능)');
        }
    } else {
        pm_aitab_set_if_empty('review_reply', '확인불가', '리뷰 페이지 수집 실패');
    }

    return ['success'=>1,'matched'=>$matched];
}

// 값이 비어있거나 '확인필요'일 때만 설정 (내부값·자동감지가 이미 채운 건 안 덮음)
function pm_aitab_set_if_empty($key, $status, $note) {
    $cur = sql_fetch("SELECT status FROM dm_place_aitab_check WHERE item_key='".sql_escape_string($key)."'");
    if (!$cur || ($cur['status'] ?? '확인필요') === '확인필요') pm_aitab_set($key, $status, $note);
}

// ============================================================
// AJAX
// ============================================================
if ($_SERVER['REQUEST_METHOD']==='POST' && !empty($_POST['action'])) {
    header('Content-Type: application/json; charset=utf-8');
    $a = $_POST['action'];

    // 플레이스 URL 자동 확보 (booking 리다이렉트)
    if ($a === 'resolve_place') {
        $r = pm_resolve_place($NAVER_BOOK);
        if (!$r['url']) { echo json_encode(['success'=>0,'message'=>'cf_naver_booking이 없거나 리다이렉트 추적 실패']); exit; }
        sql_query("UPDATE dm_place_state SET place_url='".sql_escape_string($r['url'])."', place_id='".sql_escape_string($r['id'])."' WHERE id=1");
        echo json_encode(['success'=>1,'url'=>$r['url'],'id'=>$r['id']]); exit;
    }

    if ($a === 'run_nap')  { echo json_encode(pm_do_nap($SITE_NAME,$SITE_TEL,$SITE_ADDR,$ALIASES,$NAVER_ID,$NAVER_SECRET)); exit; }
    if ($a === 'run_blog') { echo json_encode(pm_do_blog($ALIASES,$SITE_SIGUNGU,$SPECIALTY_KWS,$OWN_BLOG_ID,$NAVER_ID,$NAVER_SECRET)); exit; }
    if ($a === 'run_kin')  { echo json_encode(pm_do_kin($ALIASES,$SITE_SIGUNGU,$SPECIALTY_KWS,$NAVER_ID,$NAVER_SECRET)); exit; }
    if ($a === 'run_aitab_auto') {
        $purl = pm_get_place_url($pstate, $NAVER_BOOK);
        echo json_encode(pm_do_aitab_auto($purl, $SITE_EXPERTISE, $NAVER_BOOK)); exit;
    }
    if ($a === 'run_reviews') {
        $purl = pm_get_place_url($pstate, $NAVER_BOOK);
        echo json_encode(pm_do_reviews($purl, $GEMINI_KEY)); exit;
    }

    // 리뷰 수동 붙여넣기
    if ($a === 'add_reviews_manual') {
        $raw = $_POST['reviews_text'] ?? '';
        $chunks = preg_split('/\n\s*---\s*\n|\n{2,}/u', trim($raw));
        $new = 0; $dup = 0;
        foreach ($chunks as $c) {
            $c = trim($c);
            if (mb_strlen($c) < 5) continue;
            $hash = hash('sha256', $c);
            if (sql_fetch("SELECT id FROM dm_place_review WHERE content_hash='".$hash."'")) { $dup++; continue; }
            $sent = pm_gemini_sentiment($GEMINI_KEY, $c);
            sql_query("INSERT INTO dm_place_review (source, content, sentiment, sentiment_note, content_hash)
                       VALUES ('manual','".sql_escape_string($c)."','".sql_escape_string($sent['label'])."','".sql_escape_string($sent['note'])."','$hash')");
            $new++;
        }
        echo json_encode(['success'=>1,'new'=>$new,'dup'=>$dup]); exit;
    }

    // 일괄 실행
    if ($a === 'run_all') {
        $out = [];
        $out['nap'] = pm_do_nap($SITE_NAME,$SITE_TEL,$SITE_ADDR,$ALIASES,$NAVER_ID,$NAVER_SECRET);

        $purl = pm_get_place_url($pstate, $NAVER_BOOK);
        $out['reviews'] = pm_do_reviews($purl, $GEMINI_KEY);
        $out['blog'] = pm_do_blog($ALIASES,$SITE_SIGUNGU,$SPECIALTY_KWS,$OWN_BLOG_ID,$NAVER_ID,$NAVER_SECRET);
        $out['kin'] = pm_do_kin($ALIASES,$SITE_SIGUNGU,$SPECIALTY_KWS,$NAVER_ID,$NAVER_SECRET);
        $out['aitab'] = pm_do_aitab_auto($purl, $SITE_EXPERTISE, $NAVER_BOOK);
        sql_query("UPDATE dm_place_state SET last_checked=NOW() WHERE id=1");
        echo json_encode(['success'=>1,'results'=>$out]); exit;
    }

    // 대시보드로 프로파일 전송 (push)
    if ($a === 'push_to_dash') {
        $profile = pm_build_profile();
        $payload = json_encode($profile, JSON_UNESCAPED_UNICODE);
        $url = PM_DASH_URL . '?action=receive_profile&token=' . urlencode(PM_DASH_TOKEN);
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $payload,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
            CURLOPT_TIMEOUT => 12,
            CURLOPT_CONNECTTIMEOUT => 6,
            CURLOPT_SSL_VERIFYPEER => false,
        ]);
        $resp = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);
        if ($resp === false || $err) { echo json_encode(['success'=>0,'message'=>'대시 전송 실패: '.$err]); exit; }
        if ($code !== 200) { echo json_encode(['success'=>0,'message'=>'대시 응답 HTTP '.$code]); exit; }
        $d = json_decode($resp, true);
        echo json_encode(['success'=>1,'message'=>($d['message'] ?? '전송 완료'),'site'=>$profile['identity']['site_name']]); exit;
    }

    // 프로파일 미리보기 (전송 없이 화면 확인용)
    if ($a === 'preview_profile') {
        echo json_encode(['success'=>1,'profile'=>pm_build_profile()], JSON_UNESCAPED_UNICODE); exit;
    }

    // 기존 수집분 재분류/정리 — 옛 필터로 들어온 무관한 글 제거
    // 플레이스 URL 재확보
    if ($a === 'resolve_place') {
        if (!$NAVER_BOOK) { echo json_encode(['success'=>0,'message'=>'사이트 설정에 네이버 예약링크가 없습니다']); exit; }
        $r = pm_resolve_place($NAVER_BOOK);
        if (!$r['id']) { echo json_encode(['success'=>0,'message'=>'예약링크에서 플레이스 ID를 못 찾았습니다 — 링크를 확인하세요']); exit; }
        sql_query("UPDATE dm_place_state SET place_url='".sql_escape_string($r['url'])."', place_id='".sql_escape_string($r['id'])."' WHERE id=1");
        echo json_encode(['success'=>1,'message'=>'플레이스 URL 확보: '.$r['url']]); exit;
    }

    // 자동수집 리뷰 초기화 후 재수집 (옛 파서가 사업주 답글까지 리뷰로 저장한 오염 데이터 정리)
    if ($a === 'reset_reviews') {
        $del = 0;
        $r = sql_query("SELECT COUNT(*) AS c FROM dm_place_review WHERE source='auto'");
        if ($row = sql_fetch_array($r)) $del = (int)$row['c'];
        sql_query("DELETE FROM dm_place_review WHERE source='auto'");   // 수동 붙여넣기분은 보존

        $purl = pm_get_place_url($pstate, $NAVER_BOOK);
        if (!$purl) { echo json_encode(['success'=>1,'message'=>'자동수집 리뷰 '.$del.'건 삭제 완료 (플레이스 URL이 없어 재수집은 못 했습니다)']); exit; }
        $res = pm_do_reviews($purl, $GEMINI_KEY);
        echo json_encode([
            'success' => 1,
            'message' => '기존 자동수집 '.$del.'건 삭제 → 재수집 '.($res['new'] ?? 0).'건'
                       . (empty($res['success']) ? ' (재수집 실패: '.($res['message'] ?? '').')' : ''),
        ]); exit;
    }

    if ($a === 'purge_mentions') {
        $removed = 0; $reclassed = 0;
        foreach ([['dm_blog_mention','blog'], ['dm_kin_question','kin']] as $tt) {
            $tbl = $tt[0];
            $r = sql_query("SELECT id, title, description FROM `{$tbl}`");
            while ($row = sql_fetch_array($r)) {
                $mt = pm_classify_mention($row['title'], $row['description'], $ALIASES, $SITE_SIGUNGU, $SPECIALTY_KWS);
                if (!$mt) { sql_query("DELETE FROM `{$tbl}` WHERE id=".(int)$row['id']); $removed++; }
                else { sql_query("UPDATE `{$tbl}` SET mention_type='".$mt."' WHERE id=".(int)$row['id']); $reclassed++; }
            }
        }
        echo json_encode(['success'=>1,'removed'=>$removed,'kept'=>$reclassed,
            'message'=>'무관한 글 '.$removed.'건 삭제 · '.$reclassed.'건 재분류']); exit;
    }

    if ($a === 'mark') {
        $tbl = ['review'=>'dm_place_review','mention'=>'dm_blog_mention','kin'=>'dm_kin_question'][$_POST['type'] ?? ''] ?? '';
        $id = (int)($_POST['id'] ?? 0);
        if ($tbl && $id) { sql_query("UPDATE {$tbl} SET is_read=1 WHERE id={$id}"); echo json_encode(['success'=>1]); exit; }
        echo json_encode(['success'=>0]); exit;
    }
    if ($a === 'del') {
        $tbl = ['review'=>'dm_place_review','mention'=>'dm_blog_mention','kin'=>'dm_kin_question'][$_POST['type'] ?? ''] ?? '';
        $id = (int)($_POST['id'] ?? 0);
        if ($tbl && $id) { sql_query("DELETE FROM {$tbl} WHERE id={$id}"); echo json_encode(['success'=>1]); exit; }
        echo json_encode(['success'=>0]); exit;
    }

    // AI탭 체크리스트 저장
    if ($a === 'save_aitab') {
        $key = $_POST['item_key'] ?? '';
        $status = $_POST['status'] ?? '확인필요';
        $note = $_POST['note'] ?? '';
        $allowed_keys = ['menu_detail','hours','review_reply','booking_link','photo_recent'];
        $allowed_status = ['양호','미흡','확인불가','확인필요'];
        if (!in_array($key, $allowed_keys) || !in_array($status, $allowed_status)) { echo json_encode(['success'=>0,'message'=>'잘못된 값']); exit; }
        sql_query("UPDATE dm_place_aitab_check SET status='".sql_escape_string($status)."', note='".sql_escape_string($note)."', updated_at=NOW() WHERE item_key='".sql_escape_string($key)."'");
        echo json_encode(['success'=>1]); exit;
    }

    echo json_encode(['success'=>0,'message'=>'unknown']); exit;
}

// ── 화면 데이터 ──
$last_nap = sql_fetch("SELECT * FROM dm_place_check ORDER BY id DESC LIMIT 1");

$reviews = [];
$r = sql_query("SELECT * FROM dm_place_review ORDER BY (sentiment='악성') DESC, (sentiment='불만') DESC, id DESC LIMIT 100");
while ($row = sql_fetch_array($r)) $reviews[] = $row;
$mal_count = 0; $rv_unread = 0;
foreach ($reviews as $rv) { if ($rv['sentiment']==='악성') $mal_count++; if (!$rv['is_read']) $rv_unread++; }

$mentions = []; $mentions_comp = [];
$r2 = sql_query("SELECT * FROM dm_blog_mention ORDER BY (relevance='관련') DESC, id DESC LIMIT 150");
while ($row = sql_fetch_array($r2)) {
    if (($row['mention_type'] ?? 'own') === 'competitor') $mentions_comp[] = $row;
    else $mentions[] = $row;
}
$mt_unread = 0; foreach ($mentions as $mv) if (!$mv['is_read']) $mt_unread++;
$mtc_unread = 0; foreach ($mentions_comp as $mv) if (!$mv['is_read']) $mtc_unread++;

$kins = []; $kins_comp = [];
$r3 = sql_query("SELECT * FROM dm_kin_question ORDER BY id DESC LIMIT 100");
while ($row = sql_fetch_array($r3)) {
    if (($row['mention_type'] ?? 'own') === 'competitor') $kins_comp[] = $row;
    else $kins[] = $row;
}
$kin_unread = 0; foreach ($kins as $kv) if (!$kv['is_read']) $kin_unread++;
$kinc_unread = 0; foreach ($kins_comp as $kv) if (!$kv['is_read']) $kinc_unread++;

// ── ⑤ AI탭 노출 체크리스트 (2026-06-26 정식 출시 — 네이버 공식 API가 제공 안 하는 항목이라 수동 점검) ──
$AITAB_ITEMS = [
    'menu_detail'  => '진료항목 상세 입력 (임플란트·교정 등 구체적 기입)',
    'hours'        => '운영시간 정확성 (점심시간·휴진일 포함 실제와 일치)',
    'review_reply' => '리뷰 답글 (사업주 답변이 최근까지 달려있는지)',
    'booking_link' => '네이버 예약 연동',
    'photo_recent' => '대표 사진 최신성 (6개월 이내 업로드)',
];
foreach ($AITAB_ITEMS as $key => $label) {
    sql_query("INSERT IGNORE INTO dm_place_aitab_check (item_key, status) VALUES ('".sql_escape_string($key)."', '확인필요')");
}
$aitab_rows = [];
$r4 = sql_query("SELECT * FROM dm_place_aitab_check");
while ($row = sql_fetch_array($r4)) $aitab_rows[$row['item_key']] = $row;
// 예약연동은 cf_naver_booking 설정 여부로 참고용 힌트만 제공 (상태 자체는 수동 확정)
$aitab_booking_hint = $NAVER_BOOK ? '설정됨 (' . mb_substr($NAVER_BOOK, 0, 40) . ')' : '미설정';
$aitab_gap_count = 0;
foreach ($AITAB_ITEMS as $key => $label) { if (($aitab_rows[$key]['status'] ?? '확인필요') !== '양호') $aitab_gap_count++; }
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>플레이스 관리</title>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'Pretendard','Apple SD Gothic Neo',sans-serif;background:#f5f6fa;color:#1a1a2e;}
#admin_wrapper{display:flex;min-height:100vh;}
.content_area{flex:1;padding:40px;overflow-x:hidden;display:flex;flex-direction:column;gap:20px;}
.page_header{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;}
.page_title{font-size:22px;font-weight:700;display:flex;align-items:center;gap:10px;}
.pm_tabs{display:flex;gap:6px;background:#eef0f7;border-radius:12px;padding:5px;margin-bottom:4px;flex-wrap:wrap;}
.pm_tab{flex:1;min-width:110px;padding:11px 8px;border:none;border-radius:9px;background:transparent;font-size:13.5px;font-weight:700;color:#7a83a0;cursor:pointer;font-family:inherit;transition:.15s;white-space:nowrap;}
.pm_tab:hover{color:#4f46e5;}
.pm_tab.on{background:#fff;color:#4f46e5;box-shadow:0 2px 8px rgba(80,70,229,.12);}
.tab_dot{display:inline-block;min-width:17px;padding:0 5px;border-radius:9px;background:#ef4444;color:#fff;font-size:10.5px;font-weight:800;line-height:17px;text-align:center;vertical-align:middle;}
.tab_dot.gray{background:#9ca3af;}
.card{background:#fff;border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,.06);border:1px solid #e8eaf0;overflow:hidden;}
.card_hd{padding:14px 20px;border-bottom:1px solid #e8eaf0;display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;}
.card_hd_title{font-size:14px;font-weight:700;display:flex;align-items:center;gap:6px;}
.card_hd_title .material-symbols-outlined{font-size:16px;color:#4f46e5;}
.card_body{padding:20px;}
.btn_primary{padding:9px 20px;background:#4f46e5;color:#fff;border:none;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer;transition:all .2s;display:inline-flex;align-items:center;gap:5px;font-family:inherit;}
.btn_primary:hover{background:#4338ca;}
.btn_primary:disabled{opacity:.5;cursor:not-allowed;}
.btn_sm{padding:5px 12px;background:#eef2ff;color:#4f46e5;border:none;border-radius:6px;font-size:11px;font-weight:700;cursor:pointer;}
.btn_sm:hover{background:#4f46e5;color:#fff;}
.btn_del{padding:5px 12px;background:#fee2e2;color:#dc2626;border:none;border-radius:6px;font-size:11px;font-weight:700;cursor:pointer;}
.btn_del:hover{background:#dc2626;color:#fff;}
.form_group{margin-bottom:14px;}
.form_group label{display:block;font-size:12px;font-weight:700;color:#9999bb;margin-bottom:5px;}
.form_input{width:100%;padding:9px 12px;border:1px solid #e8eaf0;border-radius:8px;font-size:13px;background:#f5f6fa;color:#1a1a2e;font-family:inherit;transition:all .2s;outline:none;}
.form_input:focus{border-color:#4f46e5;background:#fff;box-shadow:0 0 0 3px rgba(79,70,229,.1);}
textarea.form_input{resize:vertical;min-height:60px;line-height:1.6;}
.btn_row{display:flex;align-items:center;gap:10px;margin-top:6px;flex-wrap:wrap;}
.muted{color:#9999bb;font-size:12.5px;}
.info_box{background:#ede9fe;border-radius:10px;padding:14px 18px;font-size:13px;color:#4f46e5;line-height:1.7;}
.info_box code,.card_body code{background:#fff;border:1px solid #d6d0fb;padding:1px 6px;border-radius:4px;font-size:12px;color:#4f46e5;}
.warn_box{background:#fffbeb;border-radius:10px;padding:12px 16px;font-size:12.5px;color:#92400e;line-height:1.6;border:1px solid #fde68a;margin-bottom:10px;}
.auto_grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:12px;}
.auto_item{padding:12px 14px;border-radius:10px;background:#f5f6fa;font-size:12.5px;}
.auto_item .lbl{font-size:11px;font-weight:700;color:#9999bb;margin-bottom:4px;}
.auto_item .val{font-weight:700;word-break:break-all;}
.auto_item .val.none{color:#dc2626;}
.status_badge{display:inline-flex;align-items:center;gap:5px;padding:6px 14px;border-radius:20px;font-size:12.5px;font-weight:700;}
.status_badge.due{background:#fef2f2;color:#dc2626;}
.status_badge.ok{background:#f0fdf4;color:#059669;}
.nap_grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;}
@media(max-width:680px){.nap_grid{grid-template-columns:1fr;}}
.nap_item{padding:14px 16px;border-radius:10px;background:#f5f6fa;}
.nap_item .lbl{font-size:11px;font-weight:700;color:#9999bb;margin-bottom:6px;}
.nap_item .val{font-size:13px;font-weight:600;line-height:1.5;}
.chip{display:inline-flex;align-items:center;gap:4px;padding:3px 10px;border-radius:20px;font-size:11px;font-weight:700;margin-top:6px;}
.chip.match{background:#f0fdf4;color:#059669;}
.chip.mismatch{background:#fef2f2;color:#dc2626;}
.chip.unknown{background:#f5f6fa;color:#9999bb;}
.tabbar{display:flex;gap:6px;border-bottom:1px solid #e8eaf0;padding:0 20px;overflow-x:auto;}
.tabbtn{padding:12px 4px;background:none;border:none;border-bottom:2px solid transparent;font-size:13px;font-weight:700;color:#9999bb;cursor:pointer;font-family:inherit;margin-right:16px;white-space:nowrap;}
.tabbtn.active{color:#4f46e5;border-bottom-color:#4f46e5;}
.rv_card{border:1px solid #e8eaf0;border-radius:10px;padding:14px 16px;margin-bottom:10px;}
.rv_card.malicious{border-color:#fca5a5;background:#fff5f5;}
.rv_card.unhappy{border-color:#fde68a;background:#fffbeb;}
.rv_hd{display:flex;align-items:center;gap:8px;margin-bottom:8px;flex-wrap:wrap;}
.sent_badge{padding:3px 10px;border-radius:20px;font-size:11px;font-weight:800;}
.sent_badge.정상{background:#f0fdf4;color:#059669;}
.sent_badge.불만{background:#fffbeb;color:#d97706;}
.sent_badge.악성{background:#fef2f2;color:#dc2626;}
.sent_badge.미분류{background:#f5f6fa;color:#9999bb;}
.src_badge{padding:2px 9px;border-radius:20px;font-size:10.5px;font-weight:700;background:#eef2ff;color:#4f46e5;}
.rel_badge{padding:2px 9px;border-radius:20px;font-size:10.5px;font-weight:700;}
.rel_badge.관련{background:#f0fdf4;color:#059669;}
.rel_badge.확인필요{background:#fffbeb;color:#d97706;}
.rv_text{font-size:13.5px;line-height:1.6;color:#3a3a55;margin-bottom:6px;}
.rv_note{font-size:12px;color:#9999bb;font-style:italic;}
.mt_card{border:1px solid #e8eaf0;border-radius:10px;padding:14px 16px;margin-bottom:10px;}
.mt_title{font-size:14px;font-weight:700;margin-bottom:4px;}
.mt_title a{color:#1a1a2e;text-decoration:none;}
.mt_title a:hover{color:#4f46e5;}
.mt_desc{font-size:12.5px;color:#9999bb;line-height:1.5;margin-bottom:6px;}
.mt_meta{font-size:11.5px;color:#9999bb;}
.empty_state{text-align:center;padding:48px;color:#9999bb;font-size:14px;}
.toast{position:fixed;top:20px;right:20px;padding:12px 18px;border-radius:10px;font-size:13px;font-weight:600;display:flex;align-items:center;gap:7px;z-index:1000001!important;box-shadow:0 4px 16px rgba(0,0,0,.12);animation:tin .22s ease;}
.toast.ok{background:#f0fdf4;border:1px solid #bbf7d0;color:#059669;}
.toast.error{background:#fef2f2;border:1px solid #fecaca;color:#dc2626;}
@keyframes tin{from{opacity:0;transform:translateX(12px)}to{opacity:1;transform:none}}
.spin{animation:spin 1s linear infinite;}
@keyframes spin{to{transform:rotate(360deg);}}
</style>
</head>
<body>
<div id="admin_wrapper">
    <?php include_once('../aside.php'); ?>
    <main class="content_area">

        <div class="page_header">
            <h2 class="page_title">
                <span class="material-symbols-outlined" style="font-size:22px;color:#4f46e5;">storefront</span>
                플레이스 관리
            </h2>
            <?php if ($needs_check): ?>
                <span class="status_badge due"><span class="material-symbols-outlined" style="font-size:15px;">warning</span><?= $days_since===null ? '점검 기록 없음' : $days_since.'일 경과 — 주간 점검 필요' ?></span>
            <?php else: ?>
                <span class="status_badge ok"><span class="material-symbols-outlined" style="font-size:15px;">check_circle</span>최근 점검: <?= $days_since ?>일 전</span>
            <?php endif; ?>
        </div>

        <div class="info_box">
            <strong>💡 완전 자동연동</strong> — 병원명·주소·전화·예약링크·자사블로그·API키 전부 <b>사이트 설정 값을 그대로 사용</b>합니다. 여기서 입력할 것은 없습니다. ①NAP과 ③블로그·④지식iN은 <b>네이버 공식 API</b>라 안정적이고, ②리뷰 자동추출만 best-effort(실패 시 수동 붙여넣기)입니다.
        </div>

        <!-- 탭 네비게이션 -->
        <div class="pm_tabs">
            <button class="pm_tab on" data-tab="identity" onclick="switchPmTab('identity',this)">🏥 플레이스 신원</button>
            <button class="pm_tab" data-tab="mention" onclick="switchPmTab('mention',this)">💬 자사 언급<?php if($mt_unread+$kin_unread>0):?> <span class="tab_dot"><?= $mt_unread+$kin_unread ?></span><?php endif;?></button>
            <button class="pm_tab" data-tab="competitor" onclick="switchPmTab('competitor',this)">🏢 타업체 언급<?php if(count($mentions_comp)+count($kins_comp)>0):?> <span class="tab_dot gray"><?= count($mentions_comp)+count($kins_comp) ?></span><?php endif;?></button>
            <button class="pm_tab" data-tab="aitab" onclick="switchPmTab('aitab',this)">🔎 AI탭 준비</button>
            <button class="pm_tab" data-tab="export" onclick="switchPmTab('export',this)">🚀 내보내기</button>
        </div>

        <!-- ===== 탭: 신원 ===== -->
        <div class="pm_pane" data-pane="identity">
        <?php
        // 플레이스 URL 확보 상태 — 이게 없으면 리뷰·영업시간·사진 자동감지가 전부 불가
        $__purl = trim($pstate['place_url'] ?? '');
        $__purl_ok = $__purl && preg_match('#m\.place\.naver\.com/(?:hospital|place|clinic)/\d+#', $__purl);
        ?>
        <div class="card" style="border-left:4px solid <?= $__purl_ok ? '#10b981' : '#ef4444' ?>;">
            <div class="card_body" style="padding:16px 18px;">
                <?php if ($__purl_ok): ?>
                    <div style="font-weight:800;color:#047857;font-size:14px;margin-bottom:4px;">✓ 네이버 플레이스 연결됨</div>
                    <div class="muted" style="font-size:12.5px;">
                        <a href="<?= htmlspecialchars($__purl) ?>" target="_blank" style="color:#4f46e5;"><?= htmlspecialchars($__purl) ?></a>
                        — 리뷰·영업시간·사진 자동감지가 가능합니다.
                    </div>
                <?php else: ?>
                    <div style="font-weight:800;color:#b91c1c;font-size:14px;margin-bottom:6px;">✕ 네이버 플레이스 미확보 — 아래 기능 대부분이 동작하지 않습니다</div>
                    <div style="font-size:12.5px;color:#7f1d1d;line-height:1.7;">
                        플레이스 URL이 없으면 <b>리뷰 자동추출·영업시간·사진 최신성·리뷰답글</b> 확인이 전부 불가능합니다.<br>
                        <b>해결:</b> 사이트 설정(site_config)의 <code>네이버 예약 링크</code>에 플레이스 예약 URL을 넣으면 자동으로 확보됩니다.
                        <?php if (!empty($NAVER_BOOK)): ?>
                            <br><span style="color:#92400e;">현재 등록된 예약링크: <?= htmlspecialchars(mb_substr($NAVER_BOOK,0,60)) ?> — 이 링크에서 플레이스 ID를 못 찾았습니다. 링크가 올바른지 확인하세요.</span>
                        <?php else: ?>
                            <br><span style="color:#92400e;">현재 예약링크가 비어 있습니다.</span>
                        <?php endif; ?>
                    </div>
                    <button class="btn_sm" style="margin-top:10px;" onclick="run('resolve_place','플레이스 URL 재확보')">플레이스 URL 다시 찾기</button>
                <?php endif; ?>
            </div>
        </div>

        <!-- 자동 인식된 값 -->
        <div class="card">
            <div class="card_hd"><span class="card_hd_title"><span class="material-symbols-outlined">auto_awesome</span>자동 인식된 설정 (site_config)</span></div>
            <div class="card_body">
                <?php if (!$NAVER_ID || !$NAVER_SECRET): ?>
                <div class="warn_box">⚠ 네이버 API 키 미설정 — NAP·블로그·지식iN 점검이 동작하지 않습니다. 사이트 설정 &gt; 네이버 API에 등록하세요.</div>
                <?php endif; ?>
                <?php if (!$GEMINI_KEY): ?>
                <div class="warn_box">⚠ Gemini 키 미설정 — 리뷰 감성분류가 동작하지 않습니다. SEO·스키마 관리에서 등록하면 공유됩니다.</div>
                <?php endif; ?>
                <div class="auto_grid">
                    <div class="auto_item"><div class="lbl">병원명 + 자동 별칭</div><div class="val"><?= $ALIASES ? htmlspecialchars(implode(' · ', $ALIASES)) : '<span class="none">cf_site_name 미설정</span>' ?></div></div>
                    <div class="auto_item"><div class="lbl">지역 키워드 (주소에서 추출)</div><div class="val"><?= $REGIONS ? htmlspecialchars(implode(' · ', $REGIONS)) : '<span class="none">cf_address 미설정</span>' ?></div></div>
                    <div class="auto_item"><div class="lbl">플레이스 URL (예약링크에서 자동확보)</div><div class="val"><?= $pstate['place_url'] ? htmlspecialchars(mb_substr($pstate['place_url'],0,60)).'…' : ($NAVER_BOOK ? '미확보 — 점검 실행 시 자동 시도' : '<span class="none">cf_naver_booking 미설정 (리뷰 자동추출만 제한)</span>') ?></div></div>
                    <div class="auto_item"><div class="lbl">자사 블로그 (언급에서 제외)</div><div class="val"><?= $OWN_BLOG_ID ? htmlspecialchars($OWN_BLOG_ID) : '없음' ?></div></div>
                </div>
            </div>
        </div>

        <!-- 일괄 실행 -->
        <div class="card">
            <div class="card_body" style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;">
                <div>
                    <b style="font-size:14px;">이번 주 점검 실행</b>
                    <p class="muted" style="margin-top:4px;">NAP 대조 + 리뷰 수집·분류 + 블로그 신규언급 + 지식iN 신규질문을 버튼 하나로 실행합니다.</p>
                </div>
                <button class="btn_primary" id="runAllBtn" onclick="runAll()"><span class="material-symbols-outlined" id="runAllIco" style="font-size:15px;">play_arrow</span>지금 점검 실행</button>
            </div>
        </div>

        <!-- ① NAP -->
        <div class="card">
            <div class="card_hd"><span class="card_hd_title"><span class="material-symbols-outlined">fact_check</span>① NAP 점검 (공식 지역검색 API)</span>
                <button class="btn_sm" onclick="run('run_nap','NAP 점검')">단독 실행</button>
            </div>
            <div class="card_body">
                <?php if ($last_nap): ?>
                <?php if ($last_nap['matched_title']): ?><p class="muted" style="margin-bottom:10px;">매칭된 플레이스: <b style="color:#1a1a2e;"><?= htmlspecialchars($last_nap['matched_title']) ?></b></p><?php endif; ?>
                <div class="nap_grid">
                    <div class="nap_item">
                        <div class="lbl">전화번호</div>
                        <div class="val">사이트: <?= htmlspecialchars($SITE_TEL ?: '미설정') ?><br>플레이스: <?= htmlspecialchars($last_nap['phone_found'] ?: '(API 미제공 — 최근 지역검색 API가 전화번호를 비워 주는 경우 있음)') ?></div>
                        <span class="chip <?= $last_nap['phone_status'] ?>"><?= ['match'=>'✓ 일치','mismatch'=>'✕ 불일치','unknown'=>'? 미확인'][$last_nap['phone_status']] ?? '미확인' ?></span>
                    </div>
                    <div class="nap_item">
                        <div class="lbl">주소</div>
                        <div class="val">사이트: <?= htmlspecialchars($SITE_ADDR ?: '미설정') ?><br>플레이스: <?= htmlspecialchars($last_nap['address_found'] ?: '미확인') ?></div>
                        <span class="chip <?= $last_nap['address_status'] ?>"><?= ['match'=>'✓ 일치','mismatch'=>'✕ 불일치','unknown'=>'? 미확인'][$last_nap['address_status']] ?? '미확인' ?></span>
                    </div>
                </div>
                <p class="muted" style="margin-top:12px;">마지막 점검: <?= htmlspecialchars($last_nap['checked_at']) ?></p>
                <?php else: ?>
                <div class="empty_state">아직 점검 기록이 없습니다.</div>
                <?php endif; ?>
            </div>
        </div>

        <!-- ② 리뷰 -->
        <div class="card">
            <div class="card_hd">
                <span class="card_hd_title"><span class="material-symbols-outlined">rate_review</span>② 리뷰 점검 <?php if($mal_count>0):?><span class="sent_badge 악성" style="margin-left:6px;"><?= $mal_count ?>건 악성</span><?php endif; ?></span>
                <button class="btn_sm" onclick="run('run_reviews','리뷰 자동추출')">자동 추출 시도</button>
                <button class="btn_sm" style="color:#b91c1c;border-color:#fecaca;" onclick="resetReviews()">정리 후 재수집</button>
            </div>
            <div id="reviewAutoStatus" style="display:none;padding:12px 18px;font-size:13px;font-weight:600;border-bottom:1px solid #f0f0f5;"></div>
            <div class="card_body" style="border-bottom:1px solid #f0f0f5;">
                <div class="form_group">
                    <label>리뷰 수동 붙여넣기 (여러 건은 <code>---</code> 또는 빈 줄로 구분) — 붙여넣으면 Gemini가 정상/불만/악성 자동분류</label>
                    <textarea id="reviews_text" class="form_input" rows="4" placeholder="리뷰1 내용...&#10;---&#10;리뷰2 내용..."></textarea>
                </div>
                <div class="btn_row">
                    <button class="btn_primary" onclick="addReviewsManual()"><span class="material-symbols-outlined" style="font-size:15px;">add</span>분석·등록</button>
                    <span id="rvStat" class="muted"></span>
                </div>
            </div>
            <div class="tabbar">
                <button class="tabbtn active" onclick="filterRv('all',this)">전체 (<?= count($reviews) ?>)</button>
                <button class="tabbtn" onclick="filterRv('악성',this)">악성만 (<?= $mal_count ?>)</button>
                <button class="tabbtn" onclick="filterRv('unread',this)">미확인 (<?= $rv_unread ?>)</button>
            </div>
            <div class="card_body">
                <?php if ($reviews): foreach ($reviews as $rv):
                    $cls = $rv['sentiment']==='악성' ? 'malicious' : ($rv['sentiment']==='불만' ? 'unhappy' : '');
                ?>
                <div class="rv_card <?= $cls ?>" data-sent="<?= htmlspecialchars($rv['sentiment']) ?>" data-read="<?= $rv['is_read'] ?>" id="rv-<?= $rv['id'] ?>">
                    <div class="rv_hd">
                        <span class="sent_badge <?= htmlspecialchars($rv['sentiment']) ?>"><?= htmlspecialchars($rv['sentiment'] ?: '미분류') ?></span>
                        <span class="src_badge"><?= $rv['source']==='auto'?'자동':'수동' ?></span>
                        <?php if(!$rv['is_read']): ?><span class="muted" style="font-weight:700;color:#4f46e5;">● 미확인</span><?php endif; ?>
                        <span class="muted" style="margin-left:auto;"><?= htmlspecialchars($rv['created_at']) ?></span>
                    </div>
                    <p class="rv_text"><?= nl2br(htmlspecialchars($rv['content'])) ?></p>
                    <?php if($rv['sentiment_note']): ?><p class="rv_note">💬 <?= htmlspecialchars($rv['sentiment_note']) ?></p><?php endif; ?>
                    <div class="btn_row" style="margin-top:8px;">
                        <?php if(!$rv['is_read']): ?><button class="btn_sm" onclick="mark('review',<?= $rv['id'] ?>)">확인 완료</button><?php endif; ?>
                        <button class="btn_del" onclick="del('review',<?= $rv['id'] ?>,'rv')">삭제</button>
                    </div>
                </div>
                <?php endforeach; else: ?>
                <div class="empty_state">등록된 리뷰가 없습니다.</div>
                <?php endif; ?>
            </div>
        </div>

        </div><!-- /탭:신원 -->

        <!-- ===== 탭: 언급 모니터링 ===== -->
        <div class="pm_pane" data-pane="mention" style="display:none;">
        <!-- ③ 블로그 언급 -->
        <div class="card">
            <div class="card_hd">
                <span class="card_hd_title"><span class="material-symbols-outlined">rss_feed</span>③ 블로그 신규언급 (공식 API) <?php if($mt_unread>0):?><span class="sent_badge 불만" style="margin-left:6px;"><?= $mt_unread ?>건 신규</span><?php endif; ?></span>
                <button class="btn_sm" onclick="run('run_blog','블로그 체크')">단독 실행</button>
            </div>
            <div class="card_body">
                <p class="muted" style="margin-bottom:14px;"><b>병원명 + 지역명(<?= htmlspecialchars($SITE_SIGUNGU ?: '미설정') ?>)이 모두 있는 글만</b> 여기 표시됩니다. 자사 블로그(<?= $OWN_BLOG_ID ? htmlspecialchars($OWN_BLOG_ID) : '미설정' ?>) 글은 제외. 같은 지역 <b>타업체 글은 "타업체 언급" 탭</b>에서 따로 보세요.</p>
                <div style="background:#fef9c3;border:1px solid #fde68a;border-radius:8px;padding:10px 13px;margin-bottom:14px;font-size:12px;color:#854d0e;">
                    옛 필터로 수집된 무관한 글이 남아있다면 <button class="btn_sm" style="margin:0 4px;" onclick="purgeMentions()">기존 목록 재분류·정리</button> 를 눌러 정리하세요.
                </div>
                <?php if ($mentions): foreach ($mentions as $mv): ?>
                <div class="mt_card" id="mt-<?= $mv['id'] ?>">
                    <div class="mt_title">
                        <span class="rel_badge <?= htmlspecialchars($mv['relevance']) ?>"><?= htmlspecialchars($mv['relevance']) ?><?= $mv['matched_kw'] ? ' · '.htmlspecialchars($mv['matched_kw']) : '' ?></span>
                        <a href="<?= htmlspecialchars($mv['link']) ?>" target="_blank" rel="noopener"><?= htmlspecialchars($mv['title']) ?></a>
                        <?php if(!$mv['is_read']):?><span class="muted" style="color:#4f46e5;font-weight:700;">● 신규</span><?php endif; ?>
                    </div>
                    <div class="mt_desc"><?= htmlspecialchars(mb_substr($mv['description'],0,120)) ?></div>
                    <div class="mt_meta"><?= htmlspecialchars($mv['blogger_name']) ?> · <?= htmlspecialchars($mv['post_date']) ?></div>
                    <div class="btn_row" style="margin-top:8px;">
                        <?php if(!$mv['is_read']): ?><button class="btn_sm" onclick="mark('mention',<?= $mv['id'] ?>)">확인 완료</button><?php endif; ?>
                        <button class="btn_del" onclick="del('mention',<?= $mv['id'] ?>,'mt')">삭제</button>
                    </div>
                </div>
                <?php endforeach; else: ?>
                <div class="empty_state">등록된 언급이 없습니다.</div>
                <?php endif; ?>
            </div>
        </div>

        <!-- ④ 지식iN 신규질문 -->
        <div class="card">
            <div class="card_hd">
                <span class="card_hd_title"><span class="material-symbols-outlined">contact_support</span>④ 지식iN 신규질문 (공식 API) <?php if($kin_unread>0):?><span class="sent_badge 불만" style="margin-left:6px;"><?= $kin_unread ?>건 신규</span><?php endif; ?></span>
                <button class="btn_sm" onclick="run('run_kin','지식iN 체크')">단독 실행</button>
            </div>
            <div class="card_body">
                <p class="muted" style="margin-bottom:14px;">지역 키워드(<?= $REGIONS ? htmlspecialchars(implode(', ', array_slice($REGIONS,0,2))) : '없음' ?>)+치과 조합으로 신규 질문 수집. 원장 인증계정 답변용 후보 — 답변 초안 생성은 다음 단계에서 연동 예정.</p>
                <?php if ($kins): foreach ($kins as $kv): ?>
                <div class="mt_card" id="kn-<?= $kv['id'] ?>">
                    <div class="mt_title">
                        <a href="<?= htmlspecialchars($kv['link']) ?>" target="_blank" rel="noopener"><?= htmlspecialchars($kv['title']) ?></a>
                        <?php if(!$kv['is_read']):?><span class="muted" style="color:#4f46e5;font-weight:700;">● 신규</span><?php endif; ?>
                    </div>
                    <div class="mt_desc"><?= htmlspecialchars(mb_substr($kv['description'],0,120)) ?></div>
                    <div class="mt_meta">검색어: <?= htmlspecialchars($kv['search_kw']) ?></div>
                    <div class="btn_row" style="margin-top:8px;">
                        <?php if(!$kv['is_read']): ?><button class="btn_sm" onclick="mark('kin',<?= $kv['id'] ?>)">확인 완료</button><?php endif; ?>
                        <button class="btn_del" onclick="del('kin',<?= $kv['id'] ?>,'kn')">삭제</button>
                    </div>
                </div>
                <?php endforeach; else: ?>
                <div class="empty_state">수집된 질문이 없습니다.</div>
                <?php endif; ?>
            </div>
        </div>

        </div><!-- /탭:언급 -->

        <!-- ===== 탭: 타업체 언급 ===== -->
        <div class="pm_pane" data-pane="competitor" style="display:none;">
        <div class="card">
            <div class="card_hd">
                <span class="card_hd_title"><span class="material-symbols-outlined">domain</span>같은 지역 타업체 블로그 <span class="muted" style="font-weight:400;margin-left:6px;"><?= count($mentions_comp) ?>건</span></span>
            </div>
            <div class="card_body">
                <p class="muted" style="margin-bottom:14px;">지역(<?= htmlspecialchars($SITE_SIGUNGU ?: '미설정') ?>) + 업종(<?= $SPECIALTY_KWS ? htmlspecialchars($SPECIALTY_KWS[0]) : '미설정' ?>) 글 중 <b>우리 병원명이 없는 것</b> — 경쟁 동향 참고용입니다.</p>
                <?php if ($mentions_comp): foreach ($mentions_comp as $mv): ?>
                <div class="item">
                    <div class="item_top">
                        <a href="<?= htmlspecialchars($mv['link']) ?>" target="_blank" class="item_title"><?= htmlspecialchars($mv['title']) ?></a>
                    </div>
                    <div class="item_desc"><?= htmlspecialchars(mb_substr($mv['description'],0,110)) ?></div>
                    <div class="item_meta"><?= htmlspecialchars($mv['blogger_name']) ?> · <?= htmlspecialchars($mv['post_date']) ?></div>
                    <div class="btn_row" style="margin-top:8px;">
                        <button class="btn_del" onclick="del('mention',<?= $mv['id'] ?>,'mt')">삭제</button>
                    </div>
                </div>
                <?php endforeach; else: ?>
                <div class="empty_state">수집된 타업체 언급이 없습니다.</div>
                <?php endif; ?>
            </div>
        </div>

        <div class="card">
            <div class="card_hd">
                <span class="card_hd_title"><span class="material-symbols-outlined">help</span>같은 지역 타업체 지식iN <span class="muted" style="font-weight:400;margin-left:6px;"><?= count($kins_comp) ?>건</span></span>
            </div>
            <div class="card_body">
                <p class="muted" style="margin-bottom:14px;">우리 병원이 언급되지 않은 같은 지역·업종 질문 — <b>답변을 달면 노출 기회</b>가 됩니다.</p>
                <?php if ($kins_comp): foreach ($kins_comp as $kv): ?>
                <div class="item">
                    <div class="item_top">
                        <a href="<?= htmlspecialchars($kv['link']) ?>" target="_blank" class="item_title"><?= htmlspecialchars($kv['title']) ?></a>
                    </div>
                    <div class="item_desc"><?= htmlspecialchars(mb_substr($kv['description'],0,110)) ?></div>
                    <div class="btn_row" style="margin-top:8px;">
                        <button class="btn_del" onclick="del('kin',<?= $kv['id'] ?>,'kin')">삭제</button>
                    </div>
                </div>
                <?php endforeach; else: ?>
                <div class="empty_state">수집된 타업체 질문이 없습니다.</div>
                <?php endif; ?>
            </div>
        </div>
        </div><!-- /탭:타업체 -->

        <!-- ===== 탭: AI탭 준비 ===== -->
        <div class="pm_pane" data-pane="aitab" style="display:none;">
        <!-- ⑤ AI탭 노출 체크리스트 -->
        <div class="card">
            <div class="card_hd">
                <span class="card_hd_title"><span class="material-symbols-outlined">travel_explore</span>⑤ AI탭 노출 체크리스트 <?php if($aitab_gap_count>0):?><span class="sent_badge 불만" style="margin-left:6px;"><?= $aitab_gap_count ?>건 미흡/확인필요</span><?php endif; ?></span>
                <button class="btn_sm" onclick="run('run_aitab_auto','AI탭 자동감지')">자동 감지 시도</button>
            </div>
            <div class="card_body">
                <p class="muted" style="margin-bottom:14px;">네이버 AI탭 장소 카드 노출은 이 5개 항목의 완성도로 결정됩니다. <b>사이트 설정값 → 플레이스 자동감지 → 확인불가</b> 순으로 자동 판정되며, <b>미흡 항목엔 무엇을 해야 하는지</b>가 함께 표시됩니다. 필요하면 아래에서 직접 수정할 수도 있습니다.</p>
                <?php foreach ($AITAB_ITEMS as $key => $label):
                    $row = $aitab_rows[$key] ?? ['status'=>'확인필요','note'=>''];
                    $cls = $row['status']==='양호' ? 'match' : ($row['status']==='미흡' ? 'mismatch' : 'unknown');
                ?>
                <?php
                  $__st = $row['status'] ?? '확인필요';
                  $__bg = $__st==='양호' ? '#ecfdf5' : ($__st==='미흡' ? '#fef2f2' : '#f8fafc');
                  $__bd = $__st==='양호' ? '#a7f3d0' : ($__st==='미흡' ? '#fecaca' : '#e2e8f0');
                  $__tc = $__st==='양호' ? '#047857' : ($__st==='미흡' ? '#b91c1c' : '#64748b');
                ?>
                <div class="nap_item" style="margin-bottom:10px;background:<?= $__bg ?>;border:1px solid <?= $__bd ?>;border-radius:10px;padding:12px 14px;">
                    <div class="lbl" style="display:flex;align-items:center;gap:8px;">
                        <span style="font-weight:800;color:<?= $__tc ?>;font-size:12px;padding:2px 8px;border-radius:6px;background:#fff;border:1px solid <?= $__bd ?>;"><?= htmlspecialchars($__st) ?></span>
                        <?= htmlspecialchars($label) ?><?php if($key==='booking_link'):?> <span class="muted">— <?= htmlspecialchars($aitab_booking_hint) ?></span><?php endif; ?>
                    </div>
                    <?php if(!empty($row['note'])): ?>
                    <div style="margin-top:7px;font-size:12.5px;color:<?= $__tc ?>;line-height:1.6;font-weight:<?= $__st==='양호'?'400':'600' ?>;">
                        <?= $__st==='양호' ? '✓' : ($__st==='미흡' ? '⚠' : '?') ?> <?= htmlspecialchars($row['note']) ?>
                    </div>
                    <?php endif; ?>
                    <div class="btn_row" style="margin-top:8px;">
                        <select class="form_input" style="width:auto;" id="aitab_status_<?= $key ?>">
                            <?php foreach (['양호','미흡','확인불가','확인필요'] as $opt): ?>
                            <option value="<?= $opt ?>" <?= $row['status']===$opt?'selected':'' ?>><?= $opt ?></option>
                            <?php endforeach; ?>
                        </select>
                        <input class="form_input" style="flex:1;min-width:180px;" id="aitab_note_<?= $key ?>" placeholder="메모 (선택)" value="<?= htmlspecialchars($row['note'] ?? '') ?>">
                        <button class="btn_sm" onclick="saveAitab('<?= $key ?>')">저장</button>
                        <?php if(!empty($row['updated_at'])): ?><span class="muted" id="aitab_updated_<?= $key ?>"><?= htmlspecialchars($row['updated_at']) ?> 갱신</span><?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        </div><!-- /탭:AI탭 -->

        <!-- ===== 탭: 내보내기 ===== -->
        <div class="pm_pane" data-pane="export" style="display:none;">
        <div class="card">
            <div class="card_hd"><span class="card_hd_title"><span class="material-symbols-outlined">rocket_launch</span>멀티대시로 내보내기</span></div>
            <div class="card_body">
                <p class="muted" style="margin-bottom:14px;">이 병원의 GEO 프로파일(병원정보·진료과목·의료진·제공시술·장비·AI탭 상태)을 <b>멀티대시보드로 전송</b>합니다. 버튼 하나로 전체를 긁어 자동 전송됩니다.</p>
                <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:16px;">
                    <button class="btn_primary" id="pushBtn" onclick="pushDash()"><span class="material-symbols-outlined" id="pushIco" style="font-size:15px;">cloud_upload</span>대시보드로 전송</button>
                    <button class="btn_sm" onclick="previewProfile()">전송 전 미리보기</button>
                </div>
                <div id="pushResult" style="font-size:13px;"></div>
                <pre id="profilePreview" style="display:none;background:#0f1420;color:#c9d4e8;padding:16px;border-radius:10px;font-size:12px;overflow:auto;max-height:400px;margin-top:12px;"></pre>
            </div>
        </div>
        </div><!-- /탭:내보내기 -->

    </main>
</div>

<script>
function switchPmTab(name, btn){
  document.querySelectorAll('.pm_tab').forEach(b=>b.classList.remove('on'));
  btn.classList.add('on');
  document.querySelectorAll('.pm_pane').forEach(p=>{ p.style.display = (p.dataset.pane===name)?'':'none'; });
  try{ localStorage.setItem('pm_active_tab', name); }catch(e){}
}
// 새로고침 후에도 보던 탭 유지
(function restorePmTab(){
  var t;
  try{ t = localStorage.getItem('pm_active_tab'); }catch(e){}
  if(!t) return;
  var btn = document.querySelector('.pm_tab[data-tab="'+t+'"]');
  if(btn) switchPmTab(t, btn);
})();
function purgeMentions(){
  if(!confirm('기존 수집 목록을 현재 기준으로 재분류하고, 무관한 글은 삭제합니다. 진행할까요?')) return;
  showRunning('기존 목록 재분류·정리');
  post({action:'purge_mentions'}, function(d){
    hideRunning();
    if(d.success){ showToast(d.message||'정리 완료','ok'); setTimeout(function(){location.reload();},900); }
    else showToast('정리 실패','error');
  });
}

function pushDash(){
  var res=document.getElementById('pushResult');
  showRunning('대시보드로 전송');
  res.innerHTML='';
  post({action:'push_to_dash'}, function(d){
    hideRunning();
    if(d.success){ res.innerHTML='<span style="color:#16a34a;font-weight:700;">✓ '+(d.message||'전송 완료')+(d.site?' ('+d.site+')':'')+'</span>'; }
    else { res.innerHTML='<span style="color:#dc2626;font-weight:700;">✕ '+(d.message||'전송 실패')+'</span>'; }
  });
}
function previewProfile(){
  var pre=document.getElementById('profilePreview');
  showRunning('프로파일 조회');
  post({action:'preview_profile'}, function(d){
    hideRunning();
    pre.style.display='block';
    if(d.success){ pre.textContent=JSON.stringify(d.profile,null,2); }
    else { pre.textContent='미리보기 실패'; }
  });
}
function post(d,cb){var f=new FormData();for(var k in d)f.append(k,d[k]);
  fetch(location.href,{method:'POST',body:f}).then(r=>r.json()).then(cb).catch(function(){showToast('통신 오류','error');});}

function resetReviews(){
  if(!confirm('자동수집된 리뷰를 전부 삭제하고 새로 수집합니다.\n(옛 방식이 사업주 답글까지 리뷰로 저장한 것을 정리)\n수동 붙여넣기한 리뷰는 유지됩니다. 계속할까요?')) return;
  showRunning('리뷰 정리 후 재수집');
  post({action:'reset_reviews'}, function(d){
    hideRunning();
    showToast(d.message || (d.success?'완료':'실패'), d.success?'ok':'error');
    setTimeout(function(){location.reload();},1200);
  });
}

function run(action,label){
  showRunning(label);
  post({action:action}, function(d){
    hideRunning();
    // 리뷰 자동추출은 실패해도 화면에 명확히 표시
    if(action === 'run_reviews'){
      var b = document.getElementById('reviewAutoStatus');
      if(b){
        b.style.display = 'block';
        if(d.success){
          b.style.background = '#ecfdf5'; b.style.color = '#047857';
          b.textContent = '✓ 자동추출 성공 — 신규 ' + (d.new||0) + '건';
        } else {
          b.style.background = '#fef2f2'; b.style.color = '#b91c1c';
          b.textContent = '✕ 자동추출 실패 — ' + (d.message || '네이버 차단/구조 변경. 아래 수동 붙여넣기를 이용하세요.');
        }
      }
      if(!d.success){ showToast('리뷰 자동추출 실패','error'); return; }
    }
    if(!d.success){ showToast(d.message||label+' 실패','error'); return; }
    var extra = (typeof d.new !== 'undefined') ? ' — 신규 '+d.new+'건' : '';
    showToast(label+' 완료'+extra,'ok');
    setTimeout(function(){location.reload();},700);
  });
}

// ── 실행 중 오버레이 ──
function showRunning(label){
  var o = document.getElementById('runOverlay');
  if(!o){
    o = document.createElement('div');
    o.id = 'runOverlay';
    o.style.cssText = 'position:fixed;inset:0;background:rgba(15,20,32,.55);backdrop-filter:blur(3px);z-index:99998;display:flex;align-items:center;justify-content:center;';
    o.innerHTML = '<div style="background:#fff;border-radius:16px;padding:32px 40px;text-align:center;box-shadow:0 20px 60px rgba(0,0,0,.3);min-width:260px;">'
      + '<div style="width:36px;height:36px;margin:0 auto 16px;border:3px solid #e5e7eb;border-top-color:#4f46e5;border-radius:50%;animation:pmspin .7s linear infinite;"></div>'
      + '<div id="runOverlayLabel" style="font-size:15px;font-weight:800;color:#1a1f36;"></div>'
      + '<div style="font-size:12.5px;color:#7a83a0;margin-top:6px;">잠시만 기다려주세요…</div></div>';
    document.body.appendChild(o);
    var st = document.createElement('style');
    st.textContent = '@keyframes pmspin{to{transform:rotate(360deg)}}';
    document.head.appendChild(st);
  }
  document.getElementById('runOverlayLabel').textContent = label + ' 실행 중';
  o.style.display = 'flex';
}
function hideRunning(){
  var o = document.getElementById('runOverlay');
  if(o) o.style.display = 'none';
}

function addReviewsManual(){
  var t = document.getElementById('reviews_text').value.trim();
  if(!t){ showToast('붙여넣을 리뷰가 없습니다.','error'); return; }
  document.getElementById('rvStat').textContent = '분석 중…';
  post({action:'add_reviews_manual', reviews_text:t}, function(d){
    document.getElementById('rvStat').textContent = d.success ? ('✅ 신규 '+d.new+'건, 중복 '+d.dup+'건') : '❌ 실패';
    showToast(d.success?'등록 완료':'등록 실패', d.success?'ok':'error');
    if(d.success)setTimeout(function(){location.reload();},700);
  });
}

function saveAitab(key){
  var status = document.getElementById('aitab_status_'+key).value;
  var note = document.getElementById('aitab_note_'+key).value;
  post({action:'save_aitab', item_key:key, status:status, note:note}, function(d){
    showToast(d.success?'저장 완료':'저장 실패', d.success?'ok':'error');
    if(d.success)setTimeout(function(){location.reload();},500);
  });
}

function mark(type,id){ post({action:'mark',type:type,id:id}, function(d){ if(d.success)location.reload(); }); }
function del(type,id,prefix){ if(!confirm('삭제할까요?'))return; post({action:'del',type:type,id:id}, function(d){ if(d.success){var el=document.getElementById(prefix+'-'+id); if(el)el.remove();} }); }

function runAll(){
  showRunning('전체 점검 (수십 초 소요)');
  post({action:'run_all'}, function(d){
    hideRunning();
    if(!d.success){ showToast('실패','error'); return; }
    var r=d.results;
    // 리뷰 실패 시 배너 표시
    var b = document.getElementById('reviewAutoStatus');
    if(b && r.reviews){
      b.style.display='block';
      if(r.reviews.success){ b.style.background='#ecfdf5'; b.style.color='#047857'; b.textContent='✓ 리뷰 자동추출 성공 — 신규 '+(r.reviews.new||0)+'건'; }
      else { b.style.background='#fef2f2'; b.style.color='#b91c1c'; b.textContent='✕ 리뷰 자동추출 실패 — '+(r.reviews.message||'수동 붙여넣기를 이용하세요'); }
    }
    var msg = '완료 — 리뷰 '+(r.reviews.new||0)+' · 블로그 '+(r.blog.new||0)+' · 지식iN '+(r.kin.new||0)+'건 신규';
    showToast(msg,'ok');
    setTimeout(function(){location.reload();},1200);
  });
}

function filterRv(type, btn){
  document.querySelectorAll('.tabbar .tabbtn').forEach(function(b){b.classList.remove('active');});
  btn.classList.add('active');
  document.querySelectorAll('.rv_card').forEach(function(c){
    var show = true;
    if(type==='악성') show = c.dataset.sent==='악성';
    else if(type==='unread') show = c.dataset.read==='0';
    c.style.display = show ? '' : 'none';
  });
}

function showToast(msg,type){
  var el=document.createElement('div');
  el.className='toast '+(type||'ok');
  el.innerHTML='<span class="material-symbols-outlined" style="font-size:16px;">'+(type==='error'?'error':'check_circle')+'</span>'+msg;
  document.body.appendChild(el);
  setTimeout(function(){el.remove();},3000);
}
</script>
</body>
</html>
