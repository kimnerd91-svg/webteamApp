<?php
// ===================================================================
// multi_dashboard.php — 멀티클리닉 GEO 통합 대시보드
// -------------------------------------------------------------------
// 버려진 호스팅(메디템플릿)의 newadm에 설치. 각 병원 사이트의
// place_manager.php?action=export_profile 을 서버 프록시로 순회 취합.
//
// 구조:
//  - dm_dash_sites 테이블 자동생성 + 18개 병원 초기 시드
//  - 페이지는 즉시 렌더, 각 사이트 카드는 JS가 비동기로 하나씩 채움
//  - CORS 회피: 브라우저가 아니라 이 서버가 대신 curl (action=fetch_site)
//  - export 토큰(kimnerd91)은 서버에서만 사용, 브라우저 노출 안 함
// ===================================================================
include_once('./_common.php');
if (!defined('_GNUBOARD_')) exit;
global $connect_db; $db = $connect_db;

// 프론트 루트 배치 — 관리자 세션 대신 간단 게이트(선택). 필요없으면 아래 3줄 삭제.
// 버려진 사이트를 대시 전용으로 쓰므로 URL 접근 = 허용. 원하면 ?pw= 게이트 추가 가능.

define('DASH_EXPORT_TOKEN', 'kimnerd91');   // 각 병원 export_profile 토큰(전 사이트 공통)
define('DASH_EXPORT_PATH', '/newadm/hospital/place_manager.php?action=export_profile&token=');

// ── 테이블 자동생성 ──
sql_query("CREATE TABLE IF NOT EXISTS `dm_dash_sites` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(150) NOT NULL,
    `domain` VARCHAR(255) NOT NULL,
    `is_active` TINYINT(1) DEFAULT 1,
    `sort` INT(11) DEFAULT 0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `domain` (`domain`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// push로 받은 프로파일 저장 (병원이 밀어넣은 최신 스냅샷)
sql_query("CREATE TABLE IF NOT EXISTS `dm_dash_profiles` (
    `site_name` VARCHAR(150) NOT NULL,
    `profile_json` MEDIUMTEXT,
    `received_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`site_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ── push 수신 (병원 place_manager가 밀어넣음) ──
if (($_GET['action'] ?? '') === 'receive_profile') {
    global $connect_db; $db = $connect_db;
    while (ob_get_level()) ob_end_clean();
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }
    header('Content-Type: application/json; charset=utf-8');

    if (($_GET['token'] ?? '') !== 'kimnerd91') { http_response_code(403); echo json_encode(['ok'=>false,'message'=>'토큰 불일치']); exit; }
    $raw = file_get_contents('php://input');
    $prof = json_decode($raw, true);
    if (!is_array($prof) || empty($prof['identity']['site_name'])) { http_response_code(400); echo json_encode(['ok'=>false,'message'=>'프로파일 형식 오류']); exit; }

    $name = mysqli_real_escape_string($db, $prof['identity']['site_name']);
    $json = mysqli_real_escape_string($db, $raw);
    sql_query("INSERT INTO dm_dash_profiles (site_name, profile_json, received_at) VALUES ('$name','$json',NOW())
               ON DUPLICATE KEY UPDATE profile_json='$json', received_at=NOW()");
    // 목록에 없는 병원이면 자동 등록
    $dom = mysqli_real_escape_string($db, preg_replace('#^https?://#','',rtrim($prof['nap']['naver_booking'] ?? '','/')));
    echo json_encode(['ok'=>true,'message'=>'수신 완료: '.$prof['identity']['site_name']], JSON_UNESCAPED_UNICODE);
    exit;
}

// ── 초기 시드 (최초 1회, 비어있을 때만) ──
$cnt = sql_fetch("SELECT COUNT(*) AS c FROM dm_dash_sites");
if ((int)($cnt['c'] ?? 0) === 0) {
    $seed = [
        ['서울상록수치과', 'seoulevergreen.com'],
        ['다인아트치과', 'dainart002.mycafe24.com'],
        ['청주더좋은치과', 'xn--299a52kmxs3rr59a.com'], // 청주더좋은치과.com (punycode는 실제 등록값으로 교체 필요)
        ['트루치과', 'truedental.kr'],
        ['연세바른치과', 'yonseibrdent.com'],
        ['산본치과', 'xn--vb0b361auxcoxcy0lw9h.com'],
        ['진심을다하는치과', 'xn--vb0b29h3g497c48ex8dsoktro.com'],
        ['서울다온치과2', 'xn--vb0b05i8zny1esua686a.com'],
        ['연세푸르다치과', 'xn--vb0b05i87fg1it6f94nsnk.kr'],
        ['오남플란트치과', 'onamplant.co.kr'],
        ['창원베스트플란트', 'bestplant2.mycafe24.com'],
        ['연세참다운치과', 'yyschamdent.co.kr'],
        ['진심스마트치과', 'jinsimsmart.co.kr'],
        ['케이플란트치과', 'seoulkplant.kr'],
        ['당신의치과', 'yourdent.co.kr'],
        ['키즈앤패밀리치과', 'kidssandfamily2.mycafe24.com'],
        ['365편한일층치과', 'firstfloor3652.mycafe24.com'],
        ['바른턱명인치과', 'baruntuk.co.kr'],
    ];
    $i = 0;
    foreach ($seed as $s) {
        $n = mysqli_real_escape_string($db, $s[0]);
        $d = mysqli_real_escape_string($db, $s[1]);
        sql_query("INSERT IGNORE INTO dm_dash_sites (name, domain, sort) VALUES ('$n', '$d', $i)");
        $i++;
    }
}

// ===================================================================
// AJAX
// ===================================================================
if (isset($_GET['action']) || isset($_POST['action'])) {
    $a = $_POST['action'] ?? $_GET['action'];
    header('Content-Type: application/json; charset=utf-8');

    // ── 사이트 하나의 export 프로파일 프록시 fetch ──
    if ($a === 'fetch_site') {
        $domain = trim($_GET['domain'] ?? '');
        if ($domain === '') { echo json_encode(['ok'=>false,'message'=>'도메인 없음']); exit; }
        // 스킴 보정
        $base = preg_match('#^https?://#i', $domain) ? rtrim($domain,'/') : 'https://'.rtrim($domain,'/');
        $url = $base . DASH_EXPORT_PATH . urlencode(DASH_EXPORT_TOKEN);

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 12,
            CURLOPT_CONNECTTIMEOUT => 6,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 3,
            CURLOPT_USERAGENT => 'MediMultiDash/1.0',
        ]);
        $resp = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);

        if ($resp === false || $err) { echo json_encode(['ok'=>false,'status'=>'unreachable','message'=>'연결 실패: '.$err]); exit; }
        if ($code === 403) { echo json_encode(['ok'=>false,'status'=>'forbidden','message'=>'토큰 거부(403) — 사이트에 새 place_manager 미배포 또는 토큰 불일치']); exit; }
        if ($code !== 200) { echo json_encode(['ok'=>false,'status'=>'http_'.$code,'message'=>'HTTP '.$code.' — export 미배포 가능']); exit; }

        $prof = json_decode($resp, true);
        if (!is_array($prof) || empty($prof['ok'])) { echo json_encode(['ok'=>false,'status'=>'bad_json','message'=>'프로파일 파싱 실패(export 미배포 가능)']); exit; }

        // 대시 표시에 필요한 요약 지표 계산
        $aitab = $prof['pm_status']['aitab_check'] ?? [];
        $aitab_total = count($aitab);
        $aitab_ok = 0; foreach ($aitab as $it) if (($it['status'] ?? '') === '양호') $aitab_ok++;
        $summary = [
            'name'         => $prof['identity']['site_name'] ?? '',
            'specialty'    => $prof['identity']['org_specialty'] ?? '',
            'region'       => trim(($prof['region']['sido'] ?? '').' '.($prof['region']['sigungu'] ?? '').' '.($prof['region']['gu'] ?? '')),
            'tel'          => $prof['nap']['tel'] ?? '',
            'place_url'    => $prof['nap']['place_url'] ?? '',
            'doctors_cnt'  => count($prof['doctors'] ?? []),
            'services_cnt' => count($prof['services'] ?? []),
            'equip_cnt'    => count($prof['equipment'] ?? []),
            'aitab_ok'     => $aitab_ok,
            'aitab_total'  => $aitab_total,
            'has_naver'    => !empty($prof['keys']['has_naver_key']),
            'has_gemini'   => !empty($prof['keys']['has_gemini_key']),
            'last_checked' => $prof['pm_status']['last_checked'] ?? null,
        ];
        echo json_encode(['ok'=>true,'status'=>'ok','summary'=>$summary,'profile'=>$prof], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ── 사이트 추가 ──
    if ($a === 'add_site') {
        $name = trim($_POST['name'] ?? '');
        $domain = trim($_POST['domain'] ?? '');
        $domain = preg_replace('#^https?://#i', '', $domain);
        $domain = rtrim($domain, '/');
        if ($name === '' || $domain === '') { echo json_encode(['ok'=>false,'message'=>'이름/도메인 필수']); exit; }
        $n = mysqli_real_escape_string($db, $name);
        $d = mysqli_real_escape_string($db, $domain);
        $ok = sql_query("INSERT IGNORE INTO dm_dash_sites (name, domain) VALUES ('$n','$d')");
        echo json_encode(['ok'=>(bool)$ok]); exit;
    }

    // ── 사이트 삭제 ──
    if ($a === 'del_site') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id) sql_query("DELETE FROM dm_dash_sites WHERE id=$id");
        echo json_encode(['ok'=>true]); exit;
    }

    // ── 활성 토글 ──
    if ($a === 'toggle_site') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id) sql_query("UPDATE dm_dash_sites SET is_active = 1 - is_active WHERE id=$id");
        echo json_encode(['ok'=>true]); exit;
    }

    echo json_encode(['ok'=>false,'message'=>'unknown action']); exit;
}

// ── 사이트 목록 로드 (화면 렌더용) ──
$sites = [];
$rs = sql_query("SELECT * FROM dm_dash_sites ORDER BY is_active DESC, sort ASC, id ASC");
while ($row = sql_fetch_array($rs)) $sites[] = $row;
$active_cnt = 0; foreach ($sites as $s) if ($s['is_active']) $active_cnt++;
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>멀티클리닉 GEO 대시보드</title>
<link rel="stylesheet" href="<?php echo G5_URL; ?>/css/admin.css?ver=1">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Symbols+Outlined">
<style>
/* multi_dashboard 전용 — admin.css 변수 재사용 */
.dash-stat-row{ display:flex; gap:var(--sp-16); flex-wrap:wrap; margin-bottom:var(--sp-24); }
.dash-stat{ flex:1; min-width:140px; background:var(--bg-color); border:1px solid var(--gray-200); border-radius:12px; padding:var(--sp-18); }
.dash-stat .n{ font-size:26px; font-weight:800; color:var(--main-color); line-height:1; }
.dash-stat .l{ font-size:12px; color:var(--muted-color); margin-top:6px; }

.dash-grid{ display:grid; grid-template-columns:repeat(auto-fill, minmax(300px,1fr)); gap:var(--sp-16); }
.site-card{ background:var(--bg-color); border:1px solid var(--gray-200); border-radius:12px; padding:var(--sp-18); position:relative; transition:box-shadow .2s; }
.site-card:hover{ box-shadow:0 4px 18px rgba(0,0,0,.07); }
.site-card.st-loading{ opacity:.7; }
.site-card.st-ok{ border-left:4px solid var(--accent-color); }
.site-card.st-fail{ border-left:4px solid var(--gray-400); }
.site-card .sc-head{ display:flex; justify-content:space-between; align-items:flex-start; gap:8px; margin-bottom:12px; }
.site-card .sc-name{ font-size:15px; font-weight:800; color:var(--gray-900); }
.site-card .sc-domain{ font-size:11px; color:var(--muted-color); word-break:break-all; margin-top:2px; }
.site-card .sc-body{ font-size:13px; color:var(--gray-700); }
.sc-metrics{ display:flex; flex-wrap:wrap; gap:6px; margin:10px 0; }
.sc-chip{ font-size:11px; font-weight:700; padding:3px 8px; border-radius:999px; background:var(--gray-100); color:var(--gray-600); }
.sc-chip.warn{ background:#fef3c7; color:#92610a; }
.sc-chip.good{ background:#d1fae5; color:#065f46; }
.sc-status{ font-size:11px; font-weight:700; padding:2px 8px; border-radius:999px; white-space:nowrap; }
.sc-status.ok{ background:#d1fae5; color:#065f46; }
.sc-status.fail{ background:var(--gray-100); color:var(--gray-500); }
.sc-status.loading{ background:#e0e7ff; color:var(--main-color); }
.sc-actions{ margin-top:10px; display:flex; gap:6px; flex-wrap:wrap; }
.sc-actions a, .sc-actions button{ font-size:11px; padding:4px 9px; border-radius:6px; border:1px solid var(--gray-200); background:var(--bg-color); color:var(--gray-600); cursor:pointer; text-decoration:none; }
.sc-actions a:hover, .sc-actions button:hover{ border-color:var(--main-color); color:var(--main-color); }
.sc-fail-msg{ font-size:11px; color:var(--gray-500); margin-top:6px; line-height:1.5; }
.aitab-bar{ height:6px; border-radius:3px; background:var(--gray-200); overflow:hidden; margin-top:8px; }
.aitab-bar > i{ display:block; height:100%; background:var(--accent-color); }

.add-row{ display:flex; gap:8px; flex-wrap:wrap; align-items:center; }
.add-row input{ padding:8px 11px; border:1px solid var(--gray-200); border-radius:7px; font-size:13px; }
.spin{ display:inline-block; width:13px; height:13px; border:2px solid var(--gray-300); border-top-color:var(--main-color); border-radius:50%; animation:dashspin .7s linear infinite; vertical-align:middle; }
@keyframes dashspin{ to{ transform:rotate(360deg); } }
</style>
</head>
<body>
<div style="min-height:100vh;background:var(--bg-soft);">
    <main class="content_area" style="max-width:1400px;margin:0 auto;padding:32px 24px;">

        <div class="page_header" style="margin-bottom:24px;">
            <div class="page_title" style="font-size:24px;font-weight:800;color:var(--gray-900);">멀티클리닉 GEO 대시보드</div>
            <div class="page_sub" style="color:var(--muted-color);font-size:13px;margin-top:4px;">
                각 병원 place_manager의 프로파일을 실시간 취합합니다. 사이트별로 비동기 로딩됩니다.
            </div>
        </div>

        <!-- 요약 -->
        <div class="dash-stat-row">
            <div class="dash-stat"><div class="n"><?= count($sites) ?></div><div class="l">등록 사이트</div></div>
            <div class="dash-stat"><div class="n" id="statOk">–</div><div class="l">연결됨</div></div>
            <div class="dash-stat"><div class="n" id="statFail">–</div><div class="l">미배포/실패</div></div>
            <div class="dash-stat"><div class="n" id="statAitab">–</div><div class="l">AI탭 평균 완성도</div></div>
        </div>

        <!-- 사이트 추가 -->
        <div class="admin-card" style="margin-bottom:20px;">
            <div class="admin-card-title" style="margin-bottom:12px;">사이트 관리</div>
            <div class="add-row">
                <input type="text" id="newName" placeholder="병원명">
                <input type="text" id="newDomain" placeholder="도메인 (예: example.com)">
                <button class="btn_major_add" style="padding:8px 16px;background:var(--main-color);color:#fff;border:none;border-radius:7px;font-weight:700;cursor:pointer;" onclick="addSite()">+ 추가</button>
                <button style="padding:8px 16px;background:var(--bg-soft);border:1px solid var(--gray-200);border-radius:7px;cursor:pointer;" onclick="loadAll()">↻ 전체 새로고침</button>
            </div>
        </div>

        <!-- 사이트 카드 그리드 -->
        <div class="dash-grid" id="siteGrid">
            <?php foreach ($sites as $s): ?>
            <div class="site-card st-loading" id="card_<?= (int)$s['id'] ?>" data-domain="<?= htmlspecialchars($s['domain']) ?>" data-id="<?= (int)$s['id'] ?>">
                <div class="sc-head">
                    <div>
                        <div class="sc-name"><?= htmlspecialchars($s['name']) ?><?php if(!$s['is_active']):?> <span style="font-size:10px;color:var(--gray-400);">(비활성)</span><?php endif;?></div>
                        <div class="sc-domain"><?= htmlspecialchars($s['domain']) ?></div>
                    </div>
                    <span class="sc-status loading" id="st_<?= (int)$s['id'] ?>"><span class="spin"></span></span>
                </div>
                <div class="sc-body" id="body_<?= (int)$s['id'] ?>">
                    <span style="color:var(--muted-color);font-size:12px;">불러오는 중…</span>
                </div>
                <div class="sc-actions">
                    <a href="https://<?= htmlspecialchars($s['domain']) ?>" target="_blank">사이트 ↗</a>
                    <button onclick="toggleSite(<?= (int)$s['id'] ?>)">활성토글</button>
                    <button onclick="delSite(<?= (int)$s['id'] ?>, '<?= htmlspecialchars(addslashes($s['name'])) ?>')">삭제</button>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

    </main>
</div>

<script>
const SITES = <?= json_encode(array_map(function($s){ return ['id'=>(int)$s['id'],'domain'=>$s['domain'],'active'=>(int)$s['is_active']]; }, $sites), JSON_UNESCAPED_UNICODE) ?>;

function post(data, cb){
    const body = new URLSearchParams(data);
    fetch(location.pathname, {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body})
        .then(r=>r.json()).then(cb).catch(()=>cb({ok:false}));
}

let doneCount=0, okCount=0, failCount=0, aitabSum=0, aitabN=0;

function loadSite(site){
    const card = document.getElementById('card_'+site.id);
    const stEl = document.getElementById('st_'+site.id);
    const body = document.getElementById('body_'+site.id);
    if(!card) return Promise.resolve();
    if(!site.active){
        card.classList.remove('st-loading'); card.classList.add('st-fail');
        stEl.className='sc-status fail'; stEl.textContent='비활성';
        body.innerHTML='<span style="color:var(--gray-400);font-size:12px;">비활성 사이트</span>';
        return Promise.resolve();
    }
    return fetch(location.pathname+'?action=fetch_site&domain='+encodeURIComponent(site.domain))
        .then(r=>r.json())
        .then(d=>{
            card.classList.remove('st-loading');
            doneCount++;
            if(d.ok && d.summary){
                okCount++;
                const s=d.summary;
                card.classList.add('st-ok');
                stEl.className='sc-status ok'; stEl.textContent='연결됨';
                const pct = s.aitab_total>0 ? Math.round(s.aitab_ok/s.aitab_total*100) : 0;
                if(s.aitab_total>0){ aitabSum+=pct; aitabN++; }
                body.innerHTML =
                    '<div class="sc-metrics">'+
                        '<span class="sc-chip">'+(s.specialty||'–')+'</span>'+
                        (s.region?'<span class="sc-chip">'+s.region+'</span>':'')+
                        '<span class="sc-chip">의료진 '+s.doctors_cnt+'</span>'+
                        '<span class="sc-chip">시술 '+s.services_cnt+'</span>'+
                        '<span class="sc-chip">장비 '+s.equip_cnt+'</span>'+
                        '<span class="sc-chip '+(s.has_naver?'good':'warn')+'">네이버키 '+(s.has_naver?'O':'X')+'</span>'+
                        '<span class="sc-chip '+(s.has_gemini?'good':'warn')+'">제미니 '+(s.has_gemini?'O':'X')+'</span>'+
                    '</div>'+
                    '<div style="font-size:11px;color:var(--gray-500);">AI탭 완성도 '+pct+'% ('+s.aitab_ok+'/'+s.aitab_total+')</div>'+
                    '<div class="aitab-bar"><i style="width:'+pct+'%"></i></div>'+
                    (s.place_url?'<div style="margin-top:8px;"><a href="'+s.place_url+'" target="_blank" style="font-size:11px;color:var(--main-color);">플레이스 ↗</a></div>':'');
            } else {
                failCount++;
                card.classList.add('st-fail');
                stEl.className='sc-status fail'; stEl.textContent=d.status==='forbidden'?'토큰거부':'미배포';
                body.innerHTML='<div class="sc-fail-msg">'+(d.message||'연결 실패')+'</div>';
            }
            updateStats();
        })
        .catch(()=>{
            card.classList.remove('st-loading'); card.classList.add('st-fail');
            doneCount++; failCount++;
            stEl.className='sc-status fail'; stEl.textContent='오류';
            body.innerHTML='<div class="sc-fail-msg">네트워크 오류</div>';
            updateStats();
        });
}

function updateStats(){
    document.getElementById('statOk').textContent = okCount;
    document.getElementById('statFail').textContent = failCount;
    document.getElementById('statAitab').textContent = aitabN>0 ? Math.round(aitabSum/aitabN)+'%' : '–';
}

// 동시성 제한(한 번에 4개씩) — 20개 서버 동시 curl 부하 방지
function loadAll(){
    doneCount=okCount=failCount=aitabSum=aitabN=0; updateStats();
    // 카드 초기화
    SITES.forEach(s=>{
        const c=document.getElementById('card_'+s.id); if(!c)return;
        c.className='site-card st-loading';
        const st=document.getElementById('st_'+s.id); if(st){st.className='sc-status loading';st.innerHTML='<span class="spin"></span>';}
        const b=document.getElementById('body_'+s.id); if(b)b.innerHTML='<span style="color:var(--muted-color);font-size:12px;">불러오는 중…</span>';
    });
    const queue=[...SITES]; const CONC=4;
    function next(){ if(!queue.length)return; const s=queue.shift(); loadSite(s).then(next); }
    for(let i=0;i<CONC;i++) next();
}

function addSite(){
    const name=document.getElementById('newName').value.trim();
    const domain=document.getElementById('newDomain').value.trim();
    if(!name||!domain){ alert('병원명과 도메인을 입력하세요'); return; }
    post({action:'add_site', name, domain}, d=>{ if(d.ok) location.reload(); else alert('추가 실패(중복 도메인일 수 있음)'); });
}
function delSite(id, name){ if(!confirm('['+name+'] 삭제할까요?'))return; post({action:'del_site', id}, ()=>location.reload()); }
function toggleSite(id){ post({action:'toggle_site', id}, ()=>location.reload()); }

// 자동 로드
loadAll();
</script>
</body>
</html>
