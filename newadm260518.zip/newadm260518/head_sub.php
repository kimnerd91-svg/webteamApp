<?php
if (!defined('_GNUBOARD_')) exit;

// ============================================
// dm_config 사이트 설정 조회
// ============================================
$dm_conf = @sql_fetch("SELECT * FROM dm_config WHERE cf_id = 1");
if (!$dm_conf) {
    $dm_conf = [
        // SEO
        'cf_title'               => '',
        'cf_description'         => '',
        'cf_og_image'            => '',
        'cf_favicon'             => '',
        'cf_logo'                => '',
        'cf_site_name'           => '',
        'cf_ga_id'               => '',
        'cf_add_script'          => '',
        'cf_add_body_script'     => '',
        // 회사 정보
        'cf_tel'                 => '',
        'cf_address'             => '',
        'cf_city'                => '',
        'cf_lat'                 => '',
        'cf_lng'                 => '',
        'cf_company_name'        => '',
        'cf_ceo_name'            => '',
        'cf_business_number'     => '',
        // 진료시간
        'cf_open_time'           => '',
        'cf_close_time'          => '',
        'cf_sat_open'            => '',
        'cf_sat_close'           => '',
        'cf_night_days'          => '',
        'cf_night_open'          => '',
        'cf_night_close'         => '',
        'cf_lunch_open'          => '',
        'cf_lunch_close'         => '',
        // SNS
        'cf_blog'                => '',
        'cf_kakao'               => '',
        'cf_naver_booking'       => '',
        'cf_naver_talk'          => '',
        'cf_instagram'           => '',
        'cf_youtube'             => '',
        // 법적
        'cf_privacy_policy'      => '',
        'cf_terms'               => '',
        // 소셜 로그인
        'cf_kakao_rest_key'      => '',
        'cf_kakao_client_secret' => '',
        'cf_naver_client_id'     => '',
        'cf_naver_secret'        => '',
        'cf_google_client_id'    => '',
        'cf_social_login_use'    => 0,
        'cf_langs'               => 'ko',
        // 사이트맵/로봇
        'cf_sitemap_urls'        => '',
        'cf_robots_disallow'     => '',
        'cf_robots_allow'        => '',
        // 주소
        'cf_address_base'        => '',
        'cf_address_detail'      => '',
        'cf_address_add'         => '',
        // 추적/인증
        // [변경] cf_ga4_property_id 제거 — cf_ga_id(G-XXXXXXX)와 중복
        // [변경] cf_gsc_verification / cf_naver_verification: 전체 <meta> 태그 HTML 저장
        'cf_gtm_id'              => '',
        'cf_gsc_verification'    => '',
        'cf_naver_verification'  => '',
        // GEO / 스키마
        'cf_founded_year'        => '',
        'cf_expertise'           => '',
        'cf_global_faq'          => '',
    ];
}

// ============================================
// 전역 변수로 꺼내기 (모든 페이지에서 바로 사용 가능)
// ============================================

// 기본 정보
$cf_site_name        = $dm_conf['cf_site_name']        ?? '';
$cf_title            = $dm_conf['cf_title']            ?? '';
$cf_description      = $dm_conf['cf_description']      ?? '';
$cf_tel              = $dm_conf['cf_tel']              ?? '';
$cf_address          = $dm_conf['cf_address']          ?? '';
$cf_ceo_name         = $dm_conf['cf_ceo_name']         ?? '';
$cf_company_name     = $dm_conf['cf_company_name']     ?? '';
$cf_business_number  = $dm_conf['cf_business_number']  ?? '';

// 진료시간
$cf_open_time        = $dm_conf['cf_open_time']        ?? '';
$cf_close_time       = $dm_conf['cf_close_time']       ?? '';
$cf_sat_open         = $dm_conf['cf_sat_open']         ?? '';
$cf_sat_close        = $dm_conf['cf_sat_close']        ?? '';
$cf_night_days       = $dm_conf['cf_night_days']       ?? '';
$cf_night_open       = $dm_conf['cf_night_open']       ?? '';
$cf_night_close      = $dm_conf['cf_night_close']      ?? '';
$cf_lunch_open       = $dm_conf['cf_lunch_open']       ?? '';
$cf_lunch_close      = $dm_conf['cf_lunch_close']      ?? '';

// 법적
$cf_privacy_policy   = $dm_conf['cf_privacy_policy']   ?? '';
$cf_terms            = $dm_conf['cf_terms']            ?? '';

// 소셜 로그인
$cf_social_login_use = $dm_conf['cf_social_login_use'] ?? 0;

// 이미지 URL (G5_DATA_URL 조합)
$cf_logo    = !empty($dm_conf['cf_logo'])
    ? G5_DATA_URL . '/common/' . $dm_conf['cf_logo']
    : '';
$cf_favicon = !empty($dm_conf['cf_favicon'])
    ? G5_DATA_URL . '/common/' . $dm_conf['cf_favicon']
    : '';
$cf_og      = !empty($dm_conf['cf_og_image'])
    ? G5_DATA_URL . '/common/' . $dm_conf['cf_og_image']
    : '';

// 스크립트
$cf_ga_id            = $dm_conf['cf_ga_id']            ?? '';
$cf_add_script       = $dm_conf['cf_add_script']       ?? '';
$cf_add_body_script  = $dm_conf['cf_add_body_script']  ?? '';

// 외부 링크
$cf_blog             = $dm_conf['cf_blog']             ?? '';
$cf_kakao            = $dm_conf['cf_kakao']            ?? '';
$cf_naver_booking    = $dm_conf['cf_naver_booking']    ?? '';
$cf_naver_talk       = $dm_conf['cf_naver_talk']       ?? '';
$cf_instagram        = $dm_conf['cf_instagram']        ?? '';
$cf_youtube          = $dm_conf['cf_youtube']          ?? '';

// 주소
$cf_address_base     = $dm_conf['cf_address_base']     ?? '';
$cf_address_detail   = $dm_conf['cf_address_detail']   ?? '';
$cf_address_add      = $dm_conf['cf_address_add']      ?? '';

// 추적/인증
// [변경] cf_ga4_property_id 제거 — cf_ga_id 하나로 통합
// [변경] GSC·Naver: DB에 전체 <meta> 태그가 저장되므로 stripslashes만 적용 후 그대로 출력
$cf_gtm_id             = $dm_conf['cf_gtm_id']             ?? '';
$cf_gsc_verification   = stripslashes($dm_conf['cf_gsc_verification']   ?? '');
$cf_naver_verification = stripslashes($dm_conf['cf_naver_verification'] ?? '');

// GEO / 스키마
$cf_founded_year     = $dm_conf['cf_founded_year']     ?? '';
$cf_expertise        = $dm_conf['cf_expertise']        ?? '';
$cf_global_faq       = $dm_conf['cf_global_faq']       ?? '';

// 기타
$cf_city             = $dm_conf['cf_city']             ?? '';
$cf_lat              = $dm_conf['cf_lat']              ?? '';
$cf_lng              = $dm_conf['cf_lng']              ?? '';


// ============================================
// 페이지별 SEO (dm_page_seo)
// ============================================

$page_description = '';
if (!defined('G5_IS_ADMIN')) {
    $_req_path  = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    $_req_qs    = $_SERVER['QUERY_STRING'] ?? '';
    $_full_path = $_req_qs ? $_req_path . '?' . $_req_qs : $_req_path;
    $_page_seo  = @sql_fetch("SELECT * FROM dm_page_seo WHERE path='" . addslashes($_full_path) . "' LIMIT 1");
    if (!$_page_seo && $_req_qs)
        $_page_seo = @sql_fetch("SELECT * FROM dm_page_seo WHERE path='" . addslashes($_req_path) . "' LIMIT 1");
    if (!empty($_page_seo)) {
        if (!empty($_page_seo['seo_desc']))  $page_description = $_page_seo['seo_desc'];
        if (!empty($_page_seo['seo_title'])) {
            $g5['title'] = $_page_seo['seo_title'];
            $g5['_seo_title_set'] = true; // 페이지 SEO 타이틀 직접 지정 플래그
        }
        if (!empty($_page_seo['og_image']))  $cf_og = $_page_seo['og_image'];
    }
}


// ============================================
// 테마 head_sub.php 위임 처리 (그누보드 표준)
// ============================================
if (!defined('G5_IS_ADMIN') && defined('G5_THEME_PATH') && is_file(G5_THEME_PATH . '/head_sub.php')) {
    require_once(G5_THEME_PATH . '/head_sub.php');
    return;
}

$g5_debug['php']['begin_time'] = $begin_time = get_microtime();

if (!isset($g5['title'])) {
    $g5['title']   = $cf_title;
    $g5_head_title = $g5['title'];
} else {
    // seo_title이 직접 지정된 경우 cf_title(사이트명)을 뒤에 붙이지 않음
    if (!empty($g5['_seo_title_set'])) {
        $g5_head_title = $g5['title'];
    } else {
        $g5_head_title = implode(' | ', array_filter([$g5['title'], $cf_title]));
    }
}

$g5['title']   = strip_tags($g5['title']);
$g5_head_title = strip_tags($g5_head_title);

$g5['lo_location'] = addslashes($g5['title']);
if (!$g5['lo_location'])
    $g5['lo_location'] = addslashes(clean_xss_tags($_SERVER['REQUEST_URI']));
$g5['lo_url'] = addslashes(clean_xss_tags($_SERVER['REQUEST_URI']));
if (strstr($g5['lo_url'], '/' . G5_ADMIN_DIR . '/') || $is_admin == 'super') $g5['lo_url'] = '';

// ===== 다국어 버퍼링 시작 =====
$lang = $_GET['lang'] ?? 'ko';
$allowed_langs = ['ko', 'en', 'ja', 'zh'];
if (!in_array($lang, $allowed_langs)) $lang = 'ko';
if ($lang !== 'ko') ob_start();
// ================================
?>
<!doctype html>
<html lang="ko">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="index, follow">

    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">
    <meta property="og:url" content="https://<?php echo $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>">
    <meta property="og:site_name" content="<?php echo htmlspecialchars($dm_conf['cf_site_name'] ?? $cf_title); ?>">

    <?php if (!defined('G5_IS_ADMIN')): ?>
        <meta name="description" content="<?php echo !empty($page_description) ? htmlspecialchars($page_description) : htmlspecialchars($cf_description); ?>">
        <meta property="og:type" content="website">
        <meta property="og:title" content="<?php echo htmlspecialchars($g5_head_title ?: ($dm_conf['cf_site_name'] ?? $cf_title)); ?>">
        <meta property="og:description" content="<?php echo htmlspecialchars($page_description ?: $cf_description); ?>">
        <?php if ($cf_og): ?>
            <meta property="og:image" content="<?php echo $cf_og; ?>">
        <?php endif; ?>
        <?php if ($cf_favicon): ?>
            <link rel="shortcut icon" href="<?php echo $cf_favicon; ?>" type="image/x-icon">
        <?php endif; ?>

        <?php
        /*
         * [변경] GSC / Naver 인증 태그
         * - 이전: content 값만 DB 저장 → 여기서 <meta> 태그 조립
         * - 이후: 관리자에서 <meta ...> 전체 태그를 입력 → 여기서 그대로 echo
         * - 관리자 화면에는 불필요하므로 G5_IS_ADMIN 블록 안에 위치 유지
         */
        ?>
        <?php if (!empty(trim($cf_gsc_verification))): ?>
        <?= trim($cf_gsc_verification) . "\n" ?>
        <?php endif; ?>
        <?php if (!empty(trim($cf_naver_verification))): ?>
        <?= trim($cf_naver_verification) . "\n" ?>
        <?php endif; ?>
    <?php endif; ?>

    <?php if (!empty($cf_gtm_id)): ?>
    <!-- Google Tag Manager -->
    <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','<?= htmlspecialchars($cf_gtm_id) ?>');</script>
    <!-- End Google Tag Manager -->
    <?php endif; ?>

    <?php if (!empty($cf_ga_id)): ?>
        <!-- Google Analytics 4 -->
        <!-- [변경] cf_ga4_property_id 제거 — G-XXXXXXX 형태의 cf_ga_id 하나로 통합 -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo htmlspecialchars($cf_ga_id); ?>"></script>
        <script>
            window.dataLayer = window.dataLayer || [];
            function gtag() { dataLayer.push(arguments); }
            gtag('js', new Date());
            gtag('config', '<?php echo htmlspecialchars($cf_ga_id); ?>');
        </script>
    <?php endif; ?>

    <?php if (trim($cf_add_script) !== ''): ?>
        <?php echo "\n    " . stripslashes($cf_add_script) . "\n"; ?>
    <?php endif; ?>

    <?php
    // 공통 FAQ 스키마 자동 삽입
    $cf_global_faq_raw = $dm_conf['cf_global_faq'] ?? '';
    if (!empty(trim($cf_global_faq_raw))) {
        $faq_items = json_decode($cf_global_faq_raw, true);
        if (is_array($faq_items) && count($faq_items)) {
            $faq_entities = [];
            foreach ($faq_items as $item) {
                $faq_entities[] = [
                    '@type'          => 'Question',
                    'name'           => $item['q'] ?? '',
                    'acceptedAnswer' => [
                        '@type' => 'Answer',
                        'text'  => $item['a'] ?? '',
                    ],
                ];
            }
            echo '<script type="application/ld+json">' . json_encode([
                '@context'   => 'https://schema.org',
                '@type'      => 'FAQPage',
                'mainEntity' => $faq_entities,
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '</script>' . "\n";
        }
    }
    ?>

    <title><?php echo $g5_head_title; ?></title>

    <?php if (!defined('G5_IS_ADMIN')): ?>
        <link rel="canonical" href="<?php
            $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
            $host     = htmlspecialchars($_SERVER['HTTP_HOST'], ENT_QUOTES);
            $path     = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
            echo $protocol . '://' . $host . $path;
        ?>">
    <?php endif; ?>

    <script>
        var g5_url       = "<?php echo G5_URL ?>";
        var g5_bbs_url   = "<?php echo G5_BBS_URL ?>";
        var g5_is_member = "<?php echo isset($is_member) ? $is_member : ''; ?>";
        var g5_is_admin  = "<?php echo isset($is_admin)  ? $is_admin  : ''; ?>";
        var g5_is_mobile = "<?php echo G5_IS_MOBILE ?>";
    </script>

    <!-- ========================================== -->
    <!-- CSS -->
    <!-- ========================================== -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/newadmin.css">
    <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/setting.css?ver=2">
    <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/base_core.css?ver=2">
    <link rel="stylesheet" href="https://unpkg.com/aos@2.3.1/dist/aos.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/dist/web/static/pretendard.css">

    <?php if (defined('G5_IS_ADMIN')): ?>
        <link rel="stylesheet" href="<?php echo G5_ADMIN_URL; ?>/css/admin.css?ver=<?php echo G5_CSS_VER; ?>">
    <?php endif; ?>

    <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/index.css">
    <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/header.css">
    <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/sub.css">
    <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/implant.css">
    <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/natural.css">
    <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/general.css">
    <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/pain.css">
    <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/simmi.css">
    <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/orthodontics.css">
    <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/children.css">
    <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/tail.css">
    <link rel="preload" as="video" href="/images/pcvideo.mp4">

    <!-- ========================================== -->
    <!-- JS -->
    <!-- ========================================== -->
    <script src="<?php echo G5_JS_URL ?>/jquery-1.12.4.min.js"></script>
    <script src="<?php echo G5_JS_URL ?>/jquery-migrate-1.4.1.min.js"></script>
    <script src="/newjs/medi.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollToPlugin.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/Flip.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script src="https://cdn.ckeditor.com/ckeditor5/40.2.0/classic/ckeditor.js"></script>
    <script src="/page/gallery.js"></script>

    <?php
    add_javascript('<script src="' . G5_JS_URL . '/common.js?ver=' . G5_JS_VER . '"></script>', 0);
    add_javascript('<script src="' . G5_JS_URL . '/wrest.js?ver='  . G5_JS_VER . '"></script>', 0);
    ?>

</head>

<body<?php echo isset($g5['body_script']) ? $g5['body_script'] : ''; ?>>
<?php if (!empty($cf_gtm_id)): ?>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=<?= htmlspecialchars($cf_gtm_id) ?>" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<?php endif; ?>