<?php
chdir(dirname(__FILE__) . '/..');
include_once('./_common.php');

global $connect_db;
$db = $connect_db;

$table        = 'g5_column';
$cat_table    = 'g5_column_cat';
$column_path  = '/sub';
$column_label = '임상증례';

$page     = max(1, (int)($_GET['page'] ?? 1));
$per_page = 9;
$offset   = ($page - 1) * $per_page;
$sel_tag  = trim($_GET['tag'] ?? '');
$sel_cat  = (int)($_GET['cat'] ?? 0);

// 카테고리 목록 + 게시물 수
$cats = [];
$cats_r = mysqli_query($db, "SELECT c.*, COUNT(g.id) as post_count
    FROM `{$cat_table}` c
    LEFT JOIN `{$table}` g ON g.cat_id = c.id
    GROUP BY c.id
    ORDER BY c.sort ASC, c.id ASC");
if ($cats_r) while ($c = mysqli_fetch_assoc($cats_r)) $cats[] = $c;

// 전체 수
$total_all = (int)(mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) as cnt FROM `{$table}`"))['cnt'] ?? 0);

// WHERE 조건
$where = '1=1';
if ($sel_tag) {
    $tag_esc = mysqli_real_escape_string($db, $sel_tag);
    $where .= " AND tags LIKE '%{$tag_esc}%'";
}
if ($sel_cat) {
    $where .= " AND cat_id={$sel_cat}";
}

// 총 게시물 수
$r = mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) AS cnt FROM `{$table}` WHERE {$where}"));
$total       = (int)($r['cnt'] ?? 0);
$total_pages = max(1, ceil($total / $per_page));

// 게시물 목록
$posts_r = mysqli_query($db, "SELECT id, title, subtitle, thumbnail, tags, created_at, hit
    FROM `{$table}` WHERE {$where} ORDER BY id DESC LIMIT {$offset},{$per_page}");
$post_list = [];
if ($posts_r) while ($row = mysqli_fetch_assoc($posts_r)) $post_list[] = $row;

// 인기태그 TOP 10
$tag_counts = [];
$tags_r = mysqli_query($db, "SELECT tags FROM `{$table}` WHERE tags != ''");
if ($tags_r) {
    while ($tr = mysqli_fetch_assoc($tags_r)) {
        foreach (explode(',', $tr['tags']) as $t) {
            $t = trim($t);
            if ($t) $tag_counts[$t] = ($tag_counts[$t] ?? 0) + 1;
        }
    }
}
arsort($tag_counts);
$popular_tags = array_slice($tag_counts, 0, 10, true);

// 인기글 TOP 10
$popular_posts = [];
$pop_r = mysqli_query($db, "SELECT id, title FROM `{$table}` ORDER BY hit DESC LIMIT 10");
if ($pop_r) while ($pp = mysqli_fetch_assoc($pop_r)) $popular_posts[] = $pp;

include_once(G5_PATH . '/head_sub.php');
include_once(G5_PATH . '/head.php');
?>

<main class="u-pretendard column-list-page case_list u-bg-white u-py-150">
    <div class="u-fluid-xl u-px-120 u-px-20-sm">
        <div class="d-flex flex-column-reverse flex-lg-row justify-content-between">

            <!-- 사이드바 -->
            <div class="aside col-12 col-lg-4 u-mt-80-sm">
                <h1 class="u-txt-dark c-fs-48 fw-400 u-lh-15 u-ls-15 u-mb-100 u-mb-40-sm"><?= htmlspecialchars($column_label) ?></h1>
                <ul class="u-mb-100 u-mb-40-sm">
                    <li>
                        <button type="button" class="u-bd-n u-bg-transparent u-txt-dark c-fs-14 u-lh-16 u-ls-10 u-mb-20"
                            onclick="location.href='<?= $column_path ?>/column_list.php'"
                            <?= (!$sel_cat && !$sel_tag) ? 'class="active"' : '' ?>>
                            전체 <span><?= $total_all ?></span>
                        </button>
                    </li>
                    <?php foreach ($cats as $cat): ?>
                        <li class="u-mb-20">
                            <button type="button" class="u-bd-n u-bg-transparent u-txt-dark c-fs-14 u-lh-16 u-ls-10 u-gap-16"
                                onclick="location.href='<?= $column_path ?>/column_list.php?cat=<?= (int)$cat['id'] ?>'"
                                <?= ($sel_cat === (int)$cat['id']) ? 'class="active"' : '' ?>>
                                <?= htmlspecialchars($cat['name']) ?> <span class="u-ml-16"><?= (int)$cat['post_count'] ?></span>
                            </button>
                        </li>
                    <?php endforeach; ?>
                </ul>
                <div class="u-mb-100 u-mb-40-sm">
                    <h5 class="u-txt-dark c-fs-20 fw-400 u-lh-16 u-ls-10 u-mb-20">인기태그 TOP 10</h5>
                    <ul class="d-flex u-gap-10 flex-wrap">
                        <?php foreach ($popular_tags as $tag => $cnt): ?>
                            <li>
                                <a class="u-px-20 u-py-10 u-bd-1 u-b-solid u-round-50 u-bc-point c-fs-14 fw-400 u-lh-16 u-ls-10 u-txt-point" href="<?= $column_path ?>/column_list.php?tag=<?= urlencode($tag) ?>">
                                    <?= htmlspecialchars($tag) ?>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>

                <div>
                    <h5 class="u-txt-dark c-fs-20 fw-400 u-lh-16 u-ls-10 u-mb-20">인기글 TOP 10</h5>
                    <ul>
                        <?php foreach ($popular_posts as $i => $pp): ?>
                            <li class="u-mb-4">
                                <span class="u-txt-dark c-fs-14 fw-400 u-lh-16 u-ls-10 u-mr-8"><?= $i + 1 ?>.</span>
                                <a class="u-txt-dark c-fs-14 fw-400 u-lh-16 u-ls-10" href="<?= $column_path ?>/column.php?id=<?= (int)$pp['id'] ?>">
                                    <?= htmlspecialchars($pp['title']) ?>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>

            <!-- 게시물 목록 -->
            <div class="content col-12 col-lg-6">
                <div class="d-flex flex-wrap justify-content-between u-gap-30">

                    <?php if (empty($post_list)): ?>
                        <p>등록된 칼럼이 없습니다.</p>
                    <?php endif; ?>

                    <?php foreach ($post_list as $row):
                        $tags  = array_filter(array_map('trim', explode(',', $row['tags'] ?? '')));
                        $date  = date('Y.m.d', strtotime($row['created_at']));
                        $thumb = !empty($row['thumbnail']) ? $row['thumbnail'] : '/images/no_image.png';
                        $href  = $column_path . '/column.php?id=' . (int)$row['id'];
                    ?>
                        <article class="d-flex flex-column w-100 h-100">
                            <a class="d-block w-100 h-100 u-mb-24 u-ratio-1-1-sm" href="<?= $href ?>">
                                <img class="w-100 h-100 u-obj-cover" src="<?= htmlspecialchars($thumb) ?>" alt="<?= htmlspecialchars($row['title']) ?>">
                            </a>
                            <div class="d-flex flex-column justify-content-start u-gap-16">
                                <h6 class="c-fs-16 fw-400 u-lh-15 u-ls-10 u-txt-dark">
                                    <?php foreach ($tags as $tag): ?>
                                        <a class="u-txt-point c-fs-14 fw-400 u-lh-15 u-ls-10 w-nowrap u-bd-1 u-bc-point u-round-full u-py-4 u-px-16 u-b-solid" href="<?= $column_path ?>/column_list.php?tag=<?= urlencode($tag) ?>">
                                            <?= htmlspecialchars($tag) ?>
                                        </a>
                                    <?php endforeach; ?>
                                </h6>
                                <div>
                                    <a href="<?= $href ?>">
                                        <h2 class="u-txt-dark c-fs-20 fw-400 u-lh-15 u-ls-10"><?= htmlspecialchars($row['title']) ?></h2>
                                    </a>
                                    <h4 class="u-txt-gray-500 c-fs-18 u-lh-15 u-ls-10"><?= htmlspecialchars($row['subtitle']) ?></h4>
                                    <!-- <span><?= $date ?></span> -->
                                </div>
                            </div>
                        </article>
                    <?php endforeach; ?>

                </div>

                <?php if ($total_pages > 1): ?>
                    <nav>
                        <?php if ($page > 1): ?>
                            <a href="?page=<?= $page - 1 ?><?= $sel_tag ? '&tag=' . urlencode($sel_tag) : '' ?>">&lsaquo;</a>
                        <?php endif; ?>
                        <?php for ($p = max(1, $page - 4); $p <= min($total_pages, $page + 4); $p++): ?>
                            <a href="?page=<?= $p ?><?= $sel_tag ? '&tag=' . urlencode($sel_tag) : '' ?>"
                                <?= $p === $page ? 'class="active"' : '' ?>><?= $p ?></a>
                        <?php endfor; ?>
                        <?php if ($page < $total_pages): ?>
                            <a href="?page=<?= $page + 1 ?><?= $sel_tag ? '&tag=' . urlencode($sel_tag) : '' ?>">&rsaquo;</a>
                        <?php endif; ?>
                    </nav>
                <?php endif; ?>
            </div>

        </div>
    </div>
</main>

<?php
// ── JSON-LD 스키마 ────────────────────────────────────────
$protocol  = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$base_url  = $protocol . '://' . $_SERVER['HTTP_HOST'];
$page_url  = $base_url . $_SERVER['REQUEST_URI'];
$site_name = $cf_site_name ?: ($cf_title ?: '');

// BreadcrumbList
$breadcrumb = [
    '@context' => 'https://schema.org',
    '@type'    => 'BreadcrumbList',
    'itemListElement' => [
        ['@type'=>'ListItem','position'=>1,'name'=>$site_name,'item'=>$base_url],
        ['@type'=>'ListItem','position'=>2,'name'=>htmlspecialchars($column_label),'item'=>$base_url.$column_path.'/column_list.php'],
    ],
];

// Blog (칼럼 목록)
$blog_posts = [];
foreach ($post_list as $row) {
    $item_url  = $base_url . $column_path . '/column.php?id=' . (int)$row['id'];
    $thumb_url = !empty($row['thumbnail']) ? (strpos($row['thumbnail'],'http')===0 ? $row['thumbnail'] : $base_url.$row['thumbnail']) : '';
    $entry = [
        '@type'         => 'BlogPosting',
        'headline'      => htmlspecialchars($row['title'] ?? ''),
        'url'           => $item_url,
        'datePublished' => $row['created_at'] ?? '',
        'author'        => ['@type'=>'Person','name'=>$site_name],
    ];
    if ($row['subtitle']) $entry['description'] = htmlspecialchars($row['subtitle']);
    if ($thumb_url)       $entry['image']       = $thumb_url;
    $blog_posts[] = $entry;
}

$blog_schema = [
    '@context'  => 'https://schema.org',
    '@type'     => 'Blog',
    'name'      => htmlspecialchars($column_label) . ' — ' . $site_name,
    'url'       => $page_url,
    'publisher' => [
        '@type' => 'MedicalOrganization',
        'name'  => $site_name,
        'url'   => $base_url,
    ],
    'blogPost'  => $blog_posts,
];

$json_opts = JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT;
?>
<script type="application/ld+json"><?= json_encode($breadcrumb, $json_opts) ?></script>
<script type="application/ld+json"><?= json_encode($blog_schema, $json_opts) ?></script>

<?php include_once(G5_PATH . '/tail.php'); ?>