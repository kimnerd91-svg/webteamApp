<?php
/**
 * search_smart.php  —  통합검색 결과 페이지
 * ---------------------------------------------------------------------------
 * search_index.json을 읽어 검색어와 매칭 → 매크로 답변(타이핑) + 위키 설명
 * + 진료 페이지 링크박스 + FAQ 일부 + 연관진료를 보여준다.
 *
 * 배치 위치: /sub/smartsearch/search_smart.php  (두 단계 위가 루트)
 * 접속:      /sub/smartsearch/search_smart.php?q=스케일링
 * 색인 갱신: /sub/smartsearch/build_index.php (관리자)
 * ---------------------------------------------------------------------------
 */

header('X-Robots-Tag: noindex, nofollow', true); // 검색 결과 페이지는 색인 제외

@chdir(dirname(__FILE__) . '/../..');  // /sub/smartsearch/ → 루트
include_once('./_common.php');

// tail.php 배너 기본값 (다른 진료 페이지와 동일)
$banner_settings = ['effect' => 'slide', 'loop' => 1, 'speed' => 600, 'autoplay_delay' => 3000];

// ── 색인 로드 ──
$INDEX = [];
$index_file = G5_DATA_PATH . '/search_index.json';
if (is_file($index_file)) {
    $j = json_decode(@file_get_contents($index_file), true);
    if (!empty($j['items']) && is_array($j['items'])) $INDEX = $j['items'];
}

// ── 검색어 ──
$q = isset($_GET['q']) ? trim((string) $_GET['q']) : '';

// ── 매칭 ──
function ss_norm($s) { return preg_replace('/\s+/u', '', mb_strtolower($s, 'UTF-8')); }
function ss_find($index, $path) {
    foreach ($index as $it) if ($it['path'] === $path) return $it;
    return null;
}

$nq        = $q !== '' ? ss_norm($q) : '';
$matches   = [];   // 키워드 정확 매칭 결과
$mode      = 'none'; // exact | suggest | none

// 1) 키워드 정확 매칭 (가장 긴 키워드 우선)
if ($nq !== '' && $INDEX) {
    foreach ($INDEX as $item) {
        $score = 0;
        foreach ($item['keywords'] as $kw) {
            $nk = ss_norm($kw);
            if ($nk !== '' && mb_strpos($nq, $nk) !== false) {
                $score = max($score, mb_strlen($nk));
            }
        }
        if ($score > 0) { $item['_score'] = $score; $matches[] = $item; }
    }
    usort($matches, function ($a, $b) { return $b['_score'] <=> $a['_score']; });
}

// 2) 증상 추론 (정확 매칭이 없을 때) — "턱이 아파요" 같은 자연어 문장 대응
$suggest_items = [];   // 추론된 후보 진료들
$suggest_label = '';   // 추론된 증상 분류명
if (!$matches && $nq !== '' && is_file(__DIR__ . '/search_symptoms.php')) {
    $SY = include(__DIR__ . '/search_symptoms.php');
    $pain_words = $SY['_pain_words'] ?? [];
    $has_pain = false;
    foreach ($pain_words as $pw) { if (mb_strpos($nq, ss_norm($pw)) !== false) { $has_pain = true; break; } }

    $rule_scores = []; // path => score
    $labels      = [];
    foreach (($SY['rules'] ?? []) as $rule) {
        $hit = false;
        foreach (($rule['any'] ?? []) as $cue) {
            if (mb_strpos($nq, ss_norm($cue)) !== false) { $hit = true; break; }
        }
        if (!$hit) continue;
        // 'with' 규칙은 통증어가 함께 있어야 강한 가중치
        $weight = 2;
        if (!empty($rule['with'])) $weight = $has_pain ? 3 : 1;
        $rank = 0;
        foreach (($rule['paths'] ?? []) as $p) {
            $add = $weight + (count($rule['paths']) - $rank) * 0.1; // 앞 경로 우대
            $rule_scores[$p] = ($rule_scores[$p] ?? 0) + $add;
            $rank++;
        }
        if (!empty($rule['label'])) $labels[] = $rule['label'];
    }
    arsort($rule_scores);
    foreach (array_keys($rule_scores) as $p) {
        $it = ss_find($INDEX, $p);
        if ($it) { $it['_score'] = $rule_scores[$p]; $suggest_items[] = $it; }
        if (count($suggest_items) >= 4) break;
    }
    $suggest_label = $labels ? $labels[0] : '';
}

// 3) 모드 판정
if ($matches) {
    // 정확 매칭이 있어도, 점수 1위와 2위가 같으면(애매) suggest로 본다
    if (count($matches) >= 2 && $matches[0]['_score'] === $matches[1]['_score']) {
        $mode = 'suggest';
        $suggest_items = array_slice($matches, 0, 4);
    } else {
        $mode = 'exact';
    }
} elseif ($suggest_items) {
    $mode = 'suggest';
}

$primary = ($mode === 'exact') ? $matches[0] : null;

// 연관진료(정확 매칭 모드): 다른 매칭 + supplement related 합쳐 중복 제거(최대 4)
$related_items = [];
if ($primary) {
    $seen = [$primary['path'] => true];
    foreach (array_slice($matches, 1) as $m) {
        if (!isset($seen[$m['path']])) { $related_items[] = $m; $seen[$m['path']] = true; }
    }
    foreach (($primary['related'] ?? []) as $rp) {
        if (isset($seen[$rp])) continue;
        $it = ss_find($INDEX, $rp);
        if ($it) { $related_items[] = $it; $seen[$rp] = true; }
    }
    $related_items = array_slice($related_items, 0, 4);
}

// ── 매크로 문장 (진료명 슬롯) ──
$site = $cf_site_name ?: '저희 치과';  // 그누보드 설정의 사이트명을 사용, 없을 때만 이 기본값
$site_phrase = ($cf_site_name ? '저희 ' . $site : $site);  // 사이트명 있으면 '저희 OO치과', 없으면 '저희 치과'
$templates = [
    '{name}에 관한 정보를 찾고 계시는군요. 아래에서 확인해 보세요.',
    '{name}에 대해 안내해 드릴게요.',
    $site_phrase . '에서는 {name} 진료를 제공하고 있습니다.',
    '{name}, 잘 찾아오셨어요. 핵심만 간단히 정리해 드렸습니다.',
    '{name} 관련 정보를 모아봤어요.',
];
$macro = $primary ? str_replace('{name}', $primary['name'], $templates[array_rand($templates)]) : '';

// 추론(suggest) 모드용 친화적 안내 문장
$suggest_templates = [
    '입력하신 내용으로는 딱 하나로 좁히긴 어렵지만, 이런 진료와 관련이 있어 보여요.',
    '말씀하신 증상은 아래 진료들과 관련 있을 수 있어요. 가까운 항목을 눌러보세요.',
    '정확한 진단은 진료가 필요하지만, 우선 관련 있어 보이는 진료를 모아봤어요.',
];
$suggest_macro = ($mode === 'suggest') ? $suggest_templates[array_rand($suggest_templates)] : '';

// 페이지 타이틀
$g5['title'] = $q !== '' ? "'{$q}' 검색 결과" : '통합검색';

include_once(G5_PATH . '/head_sub.php');
include_once(G5_PATH . '/head.php');

$e = function ($s) { return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8'); };
?>
<main class="u-pretendard" id="smartSearch" style="min-height:60vh">
<style>
  #smartSearch{--ss-pine:#1f5e54;--ss-pine-soft:#e7f0ed;--ss-gold:#b08a3e;--ss-line:#e3ddd0;--ss-paper:#fffdf8;--ss-ink:#1f2a2a;--ss-soft:#52605e}
  .ss-wrap{max-width:720px;margin:0 auto;padding:48px 18px 90px}
  .ss-brand{font-size:12px;letter-spacing:.18em;color:var(--ss-pine);font-weight:700}
  .ss-lead{font-size:26px;font-weight:800;letter-spacing:-.02em;margin:6px 0 22px;color:var(--ss-ink)}
  .ss-form{display:flex;gap:8px;background:var(--ss-paper);border:1px solid var(--ss-line);border-radius:999px;padding:7px 7px 7px 20px;box-shadow:0 12px 30px -18px rgba(31,42,42,.35)}
  .ss-form input{flex:1;border:0;background:transparent;outline:0;font:inherit;font-size:16px;color:var(--ss-ink)}
  .ss-form button{border:0;cursor:pointer;border-radius:999px;background:var(--ss-pine);color:#fff;font:inherit;font-weight:700;padding:11px 22px}
  .ss-form button:hover{background:#19534a}
  .ss-seq{opacity:0;transform:translateY(8px);animation:ssRise .5s ease forwards}
  @keyframes ssRise{to{opacity:1;transform:none}}
  .ss-answer{font-size:20px;font-weight:700;letter-spacing:-.01em;color:var(--ss-ink);min-height:30px;line-height:1.5;margin-top:30px}
  .ss-cursor{display:inline-block;width:2px;height:1.05em;vertical-align:-2px;background:var(--ss-pine);margin-left:2px;animation:ssBlink .9s steps(1) infinite}
  @keyframes ssBlink{50%{opacity:0}}
  .ss-card{background:var(--ss-paper);border:1px solid var(--ss-line);border-radius:18px;box-shadow:0 12px 30px -20px rgba(31,42,42,.3);padding:20px 22px;margin-top:16px}
  .ss-wiki{border-left:3px solid var(--ss-gold)}
  .ss-wiki .ss-tag{display:inline-flex;align-items:center;gap:6px;font-size:11.5px;font-weight:700;letter-spacing:.04em;color:var(--ss-gold);margin-bottom:8px}
  .ss-wiki .ss-tag::before{content:"";width:6px;height:6px;border-radius:50%;background:var(--ss-gold)}
  .ss-wiki p{margin:0;color:var(--ss-soft);font-size:15px}
  .ss-wiki .ss-src{margin-top:12px;font-size:12.5px;color:#9aa4a1}
  .ss-wiki .ss-src a{color:var(--ss-gold);text-decoration:none}
  a.ss-proc{display:flex;align-items:center;gap:16px;text-decoration:none;background:var(--ss-pine);color:#fff;border-radius:18px;padding:20px 22px;margin-top:16px;box-shadow:0 12px 30px -20px rgba(31,94,84,.7);transition:transform .15s ease}
  a.ss-proc:hover{transform:translateY(-2px)}
  a.ss-proc .ss-ic{flex:none;width:46px;height:46px;border-radius:13px;background:rgba(255,255,255,.14);display:grid;place-items:center;font-size:22px}
  a.ss-proc .ss-k{font-size:12px;opacity:.85}
  a.ss-proc .ss-t{font-size:18px;font-weight:800;letter-spacing:-.01em;margin-top:1px;color:#fff}
  a.ss-proc .ss-arrow{margin-left:auto;font-size:20px;transition:transform .15s ease}
  a.ss-proc:hover .ss-arrow{transform:translateX(4px)}
  .ss-summary{color:var(--ss-soft);font-size:14px;margin:10px 4px 0}
  .ss-faqhead{display:flex;align-items:baseline;justify-content:space-between;margin:26px 4px 10px}
  .ss-faqhead h3{margin:0;font-size:15px;font-weight:800;color:var(--ss-ink)}
  .ss-faqhead a{font-size:13px;color:var(--ss-pine);text-decoration:none;font-weight:600}
  .ss-faq{background:var(--ss-paper);border:1px solid var(--ss-line);border-radius:14px;margin-top:10px;overflow:hidden}
  .ss-q{width:100%;text-align:left;border:0;background:transparent;cursor:pointer;font:inherit;font-size:15px;font-weight:700;color:var(--ss-ink);padding:15px 18px;display:flex;justify-content:space-between;align-items:center;gap:12px}
  .ss-q .ss-pm{flex:none;color:var(--ss-pine);font-size:18px;transition:transform .2s ease}
  .ss-faq.open .ss-pm{transform:rotate(45deg)}
  .ss-a{max-height:0;overflow:hidden;transition:max-height .28s ease}
  .ss-a p{margin:0;padding:0 18px 16px;color:var(--ss-soft);font-size:14.5px;white-space:pre-line}
  .ss-related{display:flex;flex-wrap:wrap;gap:8px;margin-top:14px}
  .ss-chip{border:1px solid var(--ss-line);background:var(--ss-paper);color:var(--ss-soft);font-size:13px;border-radius:999px;padding:8px 14px;text-decoration:none}
  .ss-chip:hover{border-color:var(--ss-pine);color:var(--ss-pine)}
  .ss-empty{color:var(--ss-soft);background:var(--ss-paper);border:1px dashed var(--ss-line);border-radius:18px;padding:28px;text-align:center;margin-top:30px}
  .ss-pop{display:flex;flex-wrap:wrap;gap:8px;margin-top:14px}
  .ss-suggest{display:flex;flex-direction:column;gap:10px;margin-top:16px}
  a.ss-sug-card{display:flex;align-items:center;gap:14px;text-decoration:none;background:var(--ss-paper);border:1px solid var(--ss-line);border-radius:16px;padding:16px 18px;box-shadow:0 10px 24px -20px rgba(31,42,42,.3);opacity:0;transform:translateY(8px);animation:ssRise .5s ease forwards;transition:transform .15s ease,border-color .2s ease}
  a.ss-sug-card:hover{transform:translateY(-2px);border-color:var(--ss-pine)}
  a.ss-sug-card .ss-sug-ic{flex:none;width:40px;height:40px;border-radius:11px;background:var(--ss-pine-soft);display:grid;place-items:center;font-size:19px}
  .ss-sug-body{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px}
  .ss-sug-name{font-size:16px;font-weight:800;color:var(--ss-ink);letter-spacing:-.01em}
  .ss-sug-desc{font-size:13px;color:var(--ss-soft);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  a.ss-sug-card .ss-arrow{flex:none;color:var(--ss-pine);font-size:18px;transition:transform .15s ease}
  a.ss-sug-card:hover .ss-arrow{transform:translateX(4px)}
</style>

<div class="ss-wrap">
  <div class="ss-brand"><?= $e($site) ?></div>
  <div class="ss-lead">무엇이 궁금하세요?</div>

  <form class="ss-form" method="get" action="">
    <input type="text" name="q" value="<?= $e($q) ?>" placeholder="예: 스케일링, 또는 '스케일링 받은 지 오래됐어요'" autocomplete="off" autofocus>
    <button type="submit">검색</button>
  </form>

<?php if ($q === ''): ?>
  <div class="ss-pop">
    <?php foreach (['스케일링', '신경치료', '사랑니', '임플란트', '치아미백'] as $pop): ?>
      <a class="ss-chip" href="?q=<?= urlencode($pop) ?>"><?= $e($pop) ?></a>
    <?php endforeach; ?>
  </div>

<?php elseif ($mode === 'suggest'): ?>
  <!-- 추론 제안: 애매한 질문/증상 문장 -->
  <div class="ss-answer ss-seq" id="ssAnswer" data-text="<?= $e($suggest_macro) ?>"><?= $e($suggest_macro) ?></div>

  <?php if ($suggest_label): ?>
  <p class="ss-summary ss-seq" style="animation-delay:.05s">관련 키워드: <b><?= $e($suggest_label) ?></b></p>
  <?php endif; ?>

  <div class="ss-suggest ss-seq" style="animation-delay:.1s">
    <?php foreach ($suggest_items as $i => $s): ?>
      <a class="ss-sug-card" href="<?= $e($s['url']) ?>" style="animation-delay:<?= 0.12 + $i * 0.06 ?>s">
        <span class="ss-sug-ic">🦷</span>
        <span class="ss-sug-body">
          <span class="ss-sug-name"><?= $e($s['name']) ?></span>
          <?php if (!empty($s['summary'])): ?>
            <span class="ss-sug-desc"><?= $e(mb_substr($s['summary'], 0, 60, 'UTF-8')) ?><?= mb_strlen($s['summary'], 'UTF-8') > 60 ? '…' : '' ?></span>
          <?php endif; ?>
        </span>
        <span class="ss-arrow">→</span>
      </a>
    <?php endforeach; ?>
  </div>

  <p style="color:#9aa4a1;font-size:13px;text-align:center;margin-top:22px">
    찾으시는 게 없다면 <b><?= $e($site) ?></b>에 직접 문의해 주세요. 정확한 상태는 진료를 통해 확인하실 수 있습니다.
  </p>

<?php elseif ($mode === 'none'): ?>
  <div class="ss-empty">
    '<b><?= $e($q) ?></b>'에 딱 맞는 진료를 찾지 못했어요.<br>
    아래 검색어로 다시 시도하시거나, 증상을 편하게 적어보세요. (예: 턱이 아파요)
    <div class="ss-pop" style="justify-content:center">
      <?php foreach (['스케일링', '신경치료', '임플란트', '사랑니', '잇몸치료'] as $pop): ?>
        <a class="ss-chip" href="?q=<?= urlencode($pop) ?>"><?= $e($pop) ?></a>
      <?php endforeach; ?>
    </div>
  </div>

<?php else: ?>
  <!-- 1) 매크로 답변 (JS가 타이핑) -->
  <div class="ss-answer ss-seq" id="ssAnswer" data-text="<?= $e($macro) ?>"><?= $e($macro) ?></div>

  <!-- 2) 위키 일반 설명 -->
  <?php if (!empty($primary['wiki']['text'])): ?>
  <div class="ss-card ss-wiki ss-seq" style="animation-delay:.05s">
    <span class="ss-tag">위키백과 · 일반 설명</span>
    <p><?= $e($primary['wiki']['text']) ?></p>
    <?php if (!empty($primary['wiki']['url'])): ?>
      <div class="ss-src">출처: <a href="<?= $e($primary['wiki']['url']) ?>" target="_blank" rel="noopener">위키백과 — <?= $e($primary['wiki']['title'] ?? '문서') ?></a></div>
    <?php endif; ?>
  </div>
  <?php endif; ?>

  <!-- 3) 진료 페이지 링크박스 -->
  <a class="ss-proc ss-seq" style="animation-delay:.12s" href="<?= $e($primary['url']) ?>">
    <span class="ss-ic">🦷</span>
    <span>
      <span class="ss-k"><?= $e($site) ?>의<?= $primary['category'] ? ' · ' . $e($primary['category']) : '' ?></span><br>
      <span class="ss-t"><?= $e($primary['name']) ?></span>
    </span>
    <span class="ss-arrow">→</span>
  </a>
  <?php if (!empty($primary['summary'])): ?>
    <p class="ss-summary"><?= $e($primary['summary']) ?></p>
  <?php endif; ?>

  <!-- 4) FAQ 일부 -->
  <?php if (!empty($primary['faqs'])): ?>
  <div class="ss-faqhead ss-seq" style="animation-delay:.18s">
    <h3>자주 묻는 질문</h3>
    <a href="<?= $e($primary['url']) ?>">전체 FAQ 보기 →</a>
  </div>
  <?php foreach (array_slice($primary['faqs'], 0, 3) as $i => $f): ?>
    <div class="ss-faq ss-seq" style="animation-delay:<?= 0.2 + $i * 0.05 ?>s">
      <button type="button" class="ss-q"><span><?= $e($f['q']) ?></span><span class="ss-pm">+</span></button>
      <div class="ss-a"><p><?= $e($f['a']) ?></p></div>
    </div>
  <?php endforeach; ?>
  <?php endif; ?>

  <!-- 5) 연관진료 -->
  <?php if ($related_items): ?>
  <div class="ss-faqhead ss-seq" style="animation-delay:.3s;margin-top:30px"><h3>이런 진료도 찾으시나요?</h3></div>
  <div class="ss-related ss-seq" style="animation-delay:.32s">
    <?php foreach ($related_items as $r): ?>
      <a class="ss-chip" href="<?= $e($r['url']) ?>"><?= $e($r['name']) ?></a>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

  <p style="color:#9aa4a1;font-size:13px;text-align:center;margin-top:24px">
    더 궁금한 점은 <a href="<?= $e($primary['url']) ?>" style="color:var(--ss-pine)"><?= $e($primary['name']) ?> 페이지</a>에서 전체 내용을 확인하세요.
  </p>
<?php endif; ?>
</div>
</main>

<script>
(function () {
  // 매크로 타이핑 효과 (JS 꺼져 있어도 텍스트는 이미 보임)
  var el = document.getElementById('ssAnswer');
  if (el) {
    var text = el.getAttribute('data-text') || el.textContent;
    el.textContent = '';
    var cur = document.createElement('span'); cur.className = 'ss-cursor';
    el.appendChild(cur);
    var i = 0;
    (function tick() {
      if (i < text.length) { cur.insertAdjacentText('beforebegin', text[i++]); setTimeout(tick, 45); }
      else { setTimeout(function () { cur.remove(); }, 600); }
    })();
  }
  // FAQ 아코디언
  document.querySelectorAll('#smartSearch .ss-faq').forEach(function (item) {
    var q = item.querySelector('.ss-q'), a = item.querySelector('.ss-a');
    q.addEventListener('click', function () {
      var open = item.classList.toggle('open');
      a.style.maxHeight = open ? a.scrollHeight + 'px' : '0';
    });
  });
})();
</script>

<?php include_once(G5_PATH . '/tail.php'); ?>