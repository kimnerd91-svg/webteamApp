<?php
/**
 * _search_box.php  —  전역 검색창 (메인페이지·헤더 등 원하는 곳에 include)
 *   사용:  <?php include_once(G5_PATH . '/sub/smartsearch/_search_box.php'); ?>
 *   동작:  입력 → /sub/smartsearch/search_smart.php?q=... 로 GET 이동
 *   경로가 다르면 action 값만 수정.
 */
?>
<form class="gsearch" method="get" action="/sub/smartsearch/search_smart.php" role="search">
  <input type="text" name="q" placeholder="진료·증상을 검색해 보세요 (예: 스케일링)" autocomplete="off" aria-label="통합검색">
  <button type="submit" aria-label="검색">
    <span class="material-symbols-outlined">search</span>
  </button>
</form>
<style>
  .gsearch{display:flex;align-items:center;gap:6px;background:#fff;border:1px solid #e3ddd0;border-radius:999px;padding:5px 5px 5px 18px;max-width:440px}
  .gsearch input{flex:1;border:0;outline:0;font:inherit;font-size:15px;background:transparent;color:#1f2a2a}
  .gsearch button{flex:none;width:38px;height:38px;border:0;border-radius:50%;background:#1f5e54;color:#fff;display:grid;place-items:center;cursor:pointer}
  .gsearch button:hover{background:#19534a}
  .gsearch .material-symbols-outlined{font-size:20px}
</style>
