<?php
/**
 * search_supplement.php
 * ---------------------------------------------------------------------------
 * 진료 페이지 JSON-LD 스키마에 "없는" 정보만 여기서 보강한다.
 *   - extra_keywords : 검색 동의어 · 흔한 오타 · 환자들이 실제로 칠 법한 단어
 *   - wiki           : 위키백과 일반 설명 (title / text / url)
 *   - related        : 연관 진료 페이지 경로 (결과 하단 "이런 진료도" 카드)
 *
 * key = 진료 페이지 경로 (search_index.json의 path와 동일).
 * 본문·FAQ·진료명·alternateName은 스키마에서 자동 추출되므로 여기 적지 않는다.
 *
 * [위키 텍스트 출처] 모두 한국어 위키백과(CC BY-SA) 실제 문서 기반으로 요약.
 *   공개 의료정보이므로 운영 전 한 번 더 검수 권장.
 *   위키백과에 적합한 단독 문서가 없는 진료는 wiki=null 로 두어 카드를 표시하지 않는다.
 * ---------------------------------------------------------------------------
 */

return [

    // 임플란트
    '/sub/implant/implant_highLevel.php' => [
        'extra_keywords' => ['임플란트', '임플', '인공치아', '치아이식', '인공치근', '임플란트수술', '치아임플란트', '임프란트', '임플란트가격'],
        'wiki' => [
            'title' => '덴탈임플란트',
            'text'  => '덴탈 임플란트는 상실된 치아의 기능을 대신하기 위해 턱뼈에 식립하는 인공 치근으로, 주로 티타늄이 사용된다. 그 위에 인공 치아를 연결해 자연치아에 가까운 저작 기능과 심미를 회복한다.',
            'url'   => 'https://ko.wikipedia.org/wiki/덴탈임플란트',
        ],
        'related' => ['/sub/implant/implant_BA.php', '/sub/implant/implant_navigation.php', '/sub/implant/implant_SL.php'],
    ],
    '/sub/implant/implant_navigation.php' => [
        'extra_keywords' => ['네비게이션', '네비임플란트', '디지털임플란트', '가이드임플란트', '네비게이션임플란트', '디지털가이드', '무절개임플란트', '컴퓨터임플란트'],
        'wiki' => null,
        'related' => ['/sub/implant/implant_highLevel.php', '/sub/implant/implant_SL.php'],
    ],
    '/sub/implant/implant_SL.php' => [
        'extra_keywords' => ['상악동', '거상술', '사이너스', '사이너스리프트', '뼈이식', '상악동거상술', '상악동수술', '윗어금니임플란트', '상악임플란트'],
        'wiki' => [
            'title' => '상악동 거상술',
            'text'  => '상악동 거상술은 윗턱 어금니 부위의 잇몸뼈(치조골)가 얇아 임플란트 식립이 어려울 때, 상악동 점막을 들어 올리고 그 공간에 뼈를 이식해 임플란트에 필요한 골 높이를 확보하는 수술이다.',
            'url'   => 'https://ko.wikipedia.org/wiki/상악동',
        ],
        'related' => ['/sub/implant/implant_BA.php', '/sub/implant/implant_highLevel.php'],
    ],
    '/sub/implant/implant_FA.php' => [
        'extra_keywords' => ['전체임플란트', '무치악', '풀아치', '올온포', 'all-on-4', '올온식스', 'all-on-6', '전악', '전악임플란트', '풀마우스', '무치악임플란트', '전체틀니임플란트'],
        'wiki' => null,
        'related' => ['/sub/implant/implant_SO.php', '/sub/implant/implant_highLevel.php'],
    ],
    '/sub/implant/implant_retreatment.php' => [
        'extra_keywords' => ['재수술', '임플란트재식립', '임플란트제거', '임플란트실패', '임플란트재수술', '임플란트재치료', '임플란트풀림', '임플란트흔들림', '임플란트주위염'],
        'wiki' => [
            'title' => '임플란트 주위염',
            'text'  => '임플란트 주위염은 식립된 임플란트 주위의 잇몸과 뼈에 생기는 염증성 질환으로, 방치하면 임플란트를 지지하는 뼈가 소실되어 임플란트가 흔들리거나 실패할 수 있다. 이 경우 재치료나 재식립이 필요할 수 있다.',
            'url'   => 'https://ko.wikipedia.org/wiki/임플란트_주위염',
        ],
        'related' => ['/sub/implant/implant_highLevel.php', '/sub/implant/implant_BA.php'],
    ],
    '/sub/implant/implant_SO.php' => [
        'extra_keywords' => ['임플란트틀니', '틀니', '오버덴쳐', '오버덴처', '덴쳐', '덴처', '임플란트의치', '틀니임플란트', '버튼틀니', '똑딱이틀니'],
        'wiki' => [
            'title' => '의치 (틀니)',
            'text'  => '틀니(의치)는 상실된 치아와 주변 조직을 대신하는 가철성 보철물이다. 임플란트 틀니는 잇몸에만 얹는 일반 틀니와 달리 식립한 임플란트에 고정해 안정성과 저작력을 크게 높인 방식이다.',
            'url'   => 'https://ko.wikipedia.org/wiki/의치',
        ],
        'related' => ['/sub/implant/implant_FA.php', '/sub/implant/implant_highLevel.php'],
    ],
    '/sub/implant/implant_BA.php' => [
        'extra_keywords' => ['뼈이식', '골이식', '골부족', '잇몸뼈', '뼈이식임플란트', '골이식술', '치조골이식', '잇몸뼈부족', '뼈없는임플란트'],
        'wiki' => [
            'title' => '골이식 임플란트',
            'text'  => '골이식(뼈이식)은 임플란트를 식립할 잇몸뼈가 부족할 때 자가골·동종골·이종골·합성골 등을 이식해 부족한 뼈를 보충·재건하는 시술로, 임플란트가 안정적으로 자리 잡을 기반을 만든다.',
            'url'   => 'https://ko.wikipedia.org/wiki/덴탈임플란트',
        ],
        'related' => ['/sub/implant/implant_SL.php', '/sub/implant/implant_highLevel.php'],
    ],

    // 자연치아 살리기 (충치/잇몸 페이지는 현재 색인 누락 — 스키마 보강 후 추가됨)
    '/sub/natural/natural_cavity.php' => [
        'extra_keywords' => ['충치', '충치치료', '우식', '치아우식', '썩은이', '이가썩', '충치때움', '아말감', '인레이', '치아때우기', '충치치료비용'],
        'wiki' => [
            'title' => '충치 (치아 우식)',
            'text'  => '충치(치아 우식)는 입안 세균이 만든 산이 치아의 단단한 조직을 녹여 구멍을 만드는 질환이다. 진행 정도에 따라 충전(때우기), 신경치료 등으로 치료하며 방치하면 신경까지 감염될 수 있다.',
            'url'   => 'https://ko.wikipedia.org/wiki/충치',
        ],
        'related' => ['/sub/natural/natural_nerve.php', '/sub/simmi/simmi_regin.php'],
    ],
    '/sub/natural/natural_gums.php' => [
        'extra_keywords' => ['잇몸', '잇몸치료', '치주', '치주염', '풍치', '잇몸병', '잇몸피', '잇몸붓', '잇몸염증', '치은염', '잇몸내려앉음', '치주치료', '잇몸시림'],
        'wiki' => [
            'title' => '치주염 (잇몸병)',
            'text'  => '치주염(잇몸병)은 치태·치석 속 세균으로 잇몸과 잇몸뼈에 염증이 생기는 질환이다. 초기 치은염에서는 잇몸이 붓고 피가 나며, 진행되면 치아를 지지하는 뼈가 녹아 치아가 흔들리거나 빠질 수 있다.',
            'url'   => 'https://ko.wikipedia.org/wiki/치주염',
        ],
        'related' => ['/sub/general/general_scale.php', '/sub/natural/natural_nerve.php'],
    ],
    '/sub/natural/natural_nerve.php' => [
        'extra_keywords' => ['신경치료', '근관치료', '근관', '신경', '크라운', '치수염', '신경치료비용', '치아신경', '근관치료비용', '신경치료아픔', '치수치료'],
        'wiki' => [
            'title' => '근관 치료 (신경치료)',
            'text'  => '신경치료(근관치료)는 충치나 외상으로 감염·손상된 치아 내부의 신경과 혈관(치수)을 제거하고 근관을 소독·충전해 자연치아를 보존하는 치료다. 치료 후에는 보통 크라운으로 치아를 보호한다.',
            'url'   => 'https://ko.wikipedia.org/wiki/근관_치료',
        ],
        'related' => ['/sub/natural/natural_cavity.php', '/sub/simmi/simmi_regin.php'],
    ],

    // 심미치료
    '/sub/simmi/simmi_laminate.php' => [
        'extra_keywords' => ['라미네이트', '라미', '앞니성형', '앞니', '앞니라미네이트', '치아성형', '베니어', '포세린', '앞니교정', '앞니모양'],
        'wiki' => [
            'title' => '라미네이트 (치과 보철)',
            'text'  => '라미네이트는 치아 앞면을 얇게 다듬고 그 위에 도자기(포세린) 등 얇은 판을 붙여 치아의 모양·색·배열을 개선하는 심미 보철 치료다. 비교적 적은 치아 삭제로 앞니 심미를 개선할 수 있다.',
            'url'   => 'https://ko.wikipedia.org/wiki/치과_보철학',
        ],
        'related' => ['/sub/simmi/simmi_whitening.php', '/sub/simmi/simmi_regin.php'],
    ],
    '/sub/simmi/simmi_regin.php' => [
        'extra_keywords' => ['레진', '레진치료', '심미수복', '앞니레진', '레진충전', '치아레진', '레진때움', '복합레진', '앞니때우기', '치아색레진'],
        'wiki' => [
            'title' => '복합 레진',
            'text'  => '복합 레진은 치아 색과 비슷한 치과 수복 재료로, 충치를 제거한 부위나 작은 결손을 메우는 데 쓰인다. 금속이 보이지 않아 심미적이며 한 번의 진료로 치아 색에 맞춰 자연스럽게 수복할 수 있다.',
            'url'   => 'https://ko.wikipedia.org/wiki/복합_레진',
        ],
        'related' => ['/sub/natural/natural_cavity.php', '/sub/simmi/simmi_laminate.php'],
    ],
    '/sub/simmi/simmi_gums.php' => [
        'extra_keywords' => ['잇몸성형', '잇몸라인', '거미스마일', '잇몸미백', '거미스마일교정', '치은성형', '잇몸보이는', '웃을때잇몸', '잇몸노출', '치관연장'],
        'wiki' => [
            'title' => '치주조직',
            'text'  => '잇몸성형(치은성형·치관 연장술)은 잇몸 라인을 다듬거나 노출된 치아 길이를 조절해 심미성을 개선하는 시술이다. 웃을 때 잇몸이 과하게 보이는 거미 스마일 등을 개선하는 데 활용된다.',
            'url'   => 'https://ko.wikipedia.org/wiki/치주조직',
        ],
        'related' => ['/sub/simmi/simmi_laminate.php', '/sub/general/general_scale.php'],
    ],
    '/sub/simmi/simmi_whitening.php' => [
        'extra_keywords' => ['미백', '치아미백', '화이트닝', '이미백', '누런이', '치아미백비용', '전문가미백', '치아하얗게', '치아착색', '커피착색', '미백시술'],
        'wiki' => [
            'title' => '치아 미백',
            'text'  => '치아 미백은 치아 법랑질·상아질에 착색된 색소를 분해해 치아를 밝게 하는 시술이다. 치아를 깎거나 손상시키지 않고 약제를 이용해 색을 엷게 하며, 전문가 미백과 자가 미백 방식이 있다.',
            'url'   => 'https://ko.wikipedia.org/wiki/치아_미백',
        ],
        'related' => ['/sub/simmi/simmi_laminate.php', '/sub/simmi/simmi_regin.php'],
    ],

    // 일반진료
    '/sub/general/general_wisdom.php' => [
        'extra_keywords' => ['사랑니', '사랑니발치', '지치', '매복사랑니', '사랑니뽑', '사랑니빼기', '사랑니제거', '누운사랑니', '사랑니통증', '사랑니수술', '매복치'],
        'wiki' => [
            'title' => '사랑니',
            'text'  => '사랑니(지치)는 입안 가장 안쪽에 가장 늦게 나는 세 번째 큰어금니로, 보통 18~20세경 난다. 공간이 부족해 비뚤게 나거나 잇몸에 묻혀(매복) 나는 경우가 많아 통증·충치·염증을 일으켜 발치하는 경우가 많다.',
            'url'   => 'https://ko.wikipedia.org/wiki/사랑니',
        ],
        'related' => [],
    ],
    '/sub/general/general_jaw.php' => [
        'extra_keywords' => ['턱관절', '악관절', '턱소리', '턱딱', '이갈이', '턱통증', '턱관절장애', '입벌릴때소리', '턱딱딱', '턱아픔', '이악물기', '턱관절치료'],
        'wiki' => [
            'title' => '턱관절 장애',
            'text'  => '턱관절 장애(악관절 장애)는 턱을 움직이는 관절과 근육에 통증, 소리(딱딱거림), 입 벌림 제한 등이 나타나는 질환이다. 이갈이, 이 악물기, 스트레스, 교합 문제 등 여러 요인이 복합적으로 작용한다.',
            'url'   => 'https://ko.wikipedia.org/wiki/턱관절_장애',
        ],
        'related' => [],
    ],
    '/sub/general/general_scale.php' => [
        'extra_keywords' => ['스케일링', '스켈링', '스케일', '치석', '치석제거', '치태', '잇몸피', '치석제거술', '스케일링비용', '치아클리닝', '잇몸관리', '플라그', '치석스케일링'],
        'wiki' => [
            'title' => '스케일링 (치석 제거)',
            'text'  => '스케일링(치석 제거)은 칫솔질로 없어지지 않는 치태·치석을 초음파 기구 등으로 제거하는 기본 치과 처치다. 잇몸 염증과 치주질환을 예방하며, 만 19세 이상은 연 1회 건강보험이 적용된다.',
            'url'   => 'https://ko.wikipedia.org/wiki/치주염',
        ],
        'related' => ['/sub/natural/natural_gums.php'],
    ],
    '/sub/general/general_child.php' => [
        'extra_keywords' => ['소아', '소아진료', '어린이치과', '소아치과', '아이충치', '불소', '불소도포', '실란트', '어린이충치', '아이치과', '유치', '아동치과', '어린이', '아이'],
        'wiki' => null,
        'related' => ['/sub/general/general_scale.php'],
    ],

    // 통증 저감
    '/sub/pain/pain_system.php' => [
        'extra_keywords' => ['통증', '무통', '수면치료', '진정', '안아픈', '통증저감', '무통치료', '무통마취', '수면마취', '치과무서움', '치과공포', '안아픈치과', '잠자는치료'],
        'wiki' => null,
        'related' => [],
    ],
];