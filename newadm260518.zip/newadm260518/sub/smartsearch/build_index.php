<?php
/**
 * build_index.php  —  통합검색 색인 생성기
 * ---------------------------------------------------------------------------
 * 각 진료 페이지를 HTTP로 읽어(렌더링 결과) JSON-LD를 추출하고,
 * search_supplement.php의 보강 데이터와 합쳐 search_index.json을 만든다.
 *
 * 실행:  브라우저에서 관리자 로그인 후 /sub/smartsearch/build_index.php 접속
 *        또는 CLI:  php build_index.php
 * 시점:  진료 내용/FAQ를 바꾼 뒤 1회. (검색 1회당 실행되는 게 아님)
 *
 * 배치 위치: /sub/smartsearch/build_index.php  (두 단계 위가 루트)
 *   다른 깊이에 두면 아래 chdir의 '/..' 개수만 맞추면 된다.
 * ---------------------------------------------------------------------------
 */

@chdir(dirname(__FILE__) . '/../..');  // /sub/smartsearch/ → 루트
include_once('./_common.php');

$IS_CLI = (php_sapi_name() === 'cli');

// ── 관리자 확인 (newadm 로그인 체계에 맞춤) ──
// newadm/login.php 는 로그인 성공 시 $_SESSION['adm_mb_id'] 에 관리자 ID를 저장하고,
// 회원 레벨 10 이상만 로그인을 허용한다. 그 세션을 그대로 신뢰하되,
// 안전하게 DB에서 레벨을 한 번 더 확인한다.
$ss_login_id = '';
$ss_level    = 0;

if (!empty($_SESSION['adm_mb_id'])) {
    $ss_login_id = trim($_SESSION['adm_mb_id']);
} elseif (!empty($_SESSION['ss_mb_id'])) {
    $ss_login_id = trim($_SESSION['ss_mb_id']);
} elseif (!empty($member['mb_id'])) {
    $ss_login_id = trim($member['mb_id']);
}

if ($ss_login_id !== '') {
    $row = sql_fetch("SELECT mb_level FROM {$g5['member_table']} WHERE mb_id = '" . addslashes($ss_login_id) . "'");
    if (!empty($row['mb_level'])) $ss_level = (int) $row['mb_level'];
}

$ss_is_admin = ($ss_login_id !== '' && $ss_level >= 10);

if (!$IS_CLI && !$ss_is_admin) {
    // 디버그: 왜 막혔는지 바로 확인 (운영 확인 후 이 블록은 삭제해도 됨)
    header('Content-Type: text/html; charset=utf-8');
    echo '<meta charset="utf-8"><div style="font-family:system-ui;max-width:600px;margin:40px auto;line-height:1.7">';
    echo '<h2>관리자만 실행할 수 있습니다.</h2>';
    echo '<ul>';
    echo '<li>newadm 세션 (<code>$_SESSION[adm_mb_id]</code>): <b>' . htmlspecialchars($_SESSION['adm_mb_id'] ?? '(없음)') . '</b></li>';
    echo '<li>그누보드 세션 (<code>$_SESSION[ss_mb_id]</code>): <b>' . htmlspecialchars($_SESSION['ss_mb_id'] ?? '(없음)') . '</b></li>';
    echo '<li>판정에 쓴 ID: <b>' . htmlspecialchars($ss_login_id ?: '(없음)') . '</b></li>';
    echo '<li>DB 조회 레벨: <b>' . $ss_level . '</b> (10 이상이어야 통과)</li>';
    echo '</ul>';
    echo '<p>모두 (없음)이면 newadm에 로그인되지 않은 브라우저입니다. ';
    echo '<a href="/newadm/auth/login.php">newadm 로그인</a> 후 다시 이 페이지를 열어주세요.<br>';
    echo '(로그인 경로가 다르면 실제 경로로 접속하세요)</p>';
    echo '</div>';
    exit;
}

// ── 베이스 URL (CLI에서는 HTTP_HOST가 없으니 기본값 사용) ──
$BASE = 'https://' . (!empty($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'seoulsangroksu.mycafe24.com');

// ── 크롤 대상: head.php의 $nav_menus에서 추출한 진료 페이지 목록 ──
//    진료 페이지를 추가하면 여기 경로 한 줄만 추가하면 된다.
$CRAWL = [
    '/sub/implant/implant_highLevel.php',
    '/sub/implant/implant_navigation.php',
    '/sub/implant/implant_SL.php',
    '/sub/implant/implant_FA.php',
    '/sub/implant/implant_retreatment.php',
    '/sub/implant/implant_SO.php',
    '/sub/implant/implant_BA.php',
    '/sub/natural/natural_cavity.php',
    '/sub/natural/natural_gums.php',
    '/sub/natural/natural_nerve.php',
    '/sub/simmi/simmi_laminate.php',
    '/sub/simmi/simmi_regin.php',
    '/sub/simmi/simmi_gums.php',
    '/sub/simmi/simmi_whitening.php',
    '/sub/general/general_wisdom.php',
    '/sub/general/general_jaw.php',
    '/sub/general/general_scale.php',
    '/sub/general/general_child.php',
    '/sub/pain/pain_system.php',
];

$SUP = include(__DIR__ . '/search_supplement.php');
if (!is_array($SUP)) $SUP = [];

// ───────────────────────── 헬퍼 ─────────────────────────

function fetch_html($url) {
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT        => 25,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_USERAGENT      => 'SmartSearchIndexer/1.0',
        ]);
        $html = curl_exec($ch);
        $err  = curl_error($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($html === false) return [null, 'cURL 오류: ' . $err];
        if ($code >= 400)    return [null, 'HTTP ' . $code];
        return [$html, null];
    }
    $ctx  = stream_context_create(['http' => ['timeout' => 25], 'ssl' => ['verify_peer' => false, 'verify_peer_name' => false]]);
    $html = @file_get_contents($url, false, $ctx);
    if ($html === false) return [null, 'file_get_contents 실패 (cURL 미사용)'];
    return [$html, null];
}

/** ld+json 블록을 모두 뽑아 노드 단위로 평탄화 */
function extract_ldjson($html) {
    $nodes = [];
    if (preg_match_all('#<script[^>]*type=["\']application/ld\+json["\'][^>]*>(.*?)</script>#is', $html, $m)) {
        foreach ($m[1] as $block) {
            $data = json_decode(trim($block), true);
            if ($data === null) continue;
            foreach (flatten_nodes($data) as $n) {
                if (is_array($n)) $nodes[] = $n;
            }
        }
    }
    return $nodes;
}

function flatten_nodes($data) {
    $out = [];
    if (!is_array($data)) return $out;
    if (isset($data['@graph']) && is_array($data['@graph'])) {
        foreach ($data['@graph'] as $n) $out = array_merge($out, flatten_nodes($n));
        return $out;
    }
    // 순수 리스트(0,1,2…)면 각 원소 평탄화
    $is_list = array_keys($data) === range(0, count($data) - 1);
    if ($is_list) {
        foreach ($data as $n) $out = array_merge($out, flatten_nodes($n));
        return $out;
    }
    $out[] = $data;
    return $out;
}

function has_type($node, $type) {
    if (!isset($node['@type'])) return false;
    $t = $node['@type'];
    return is_array($t) ? in_array($type, $t, true) : ($t === $type);
}

function bc_category($webpage) {
    if (!$webpage || empty($webpage['breadcrumb']['itemListElement'])) return '';
    foreach ($webpage['breadcrumb']['itemListElement'] as $it) {
        if ((int)($it['position'] ?? 0) === 2) return $it['name'] ?? '';
    }
    return '';
}

// breadcrumb의 마지막(가장 깊은) 항목명 = 실제 진료명 (예: '소아진료')
function bc_leaf_name($webpage) {
    if (!$webpage || empty($webpage['breadcrumb']['itemListElement'])) return '';
    $best = ''; $maxpos = -1;
    foreach ($webpage['breadcrumb']['itemListElement'] as $it) {
        $p = (int)($it['position'] ?? 0);
        if ($p > $maxpos) { $maxpos = $p; $best = $it['name'] ?? ''; }
    }
    return $best;
}

// ───────────────────────── 빌드 ─────────────────────────

$index  = [];
$report = [];

foreach ($CRAWL as $path) {
    list($html, $err) = fetch_html($BASE . $path);
    if ($err) { $report[] = ['error', $path, '크롤 실패 — ' . $err]; continue; }

    $nodes = extract_ldjson($html);
    if (!$nodes) { $report[] = ['error', $path, 'JSON-LD 없음']; continue; }

    // 진료/질환 본체 노드: MedicalProcedure(시술) → MedicalCondition(질환) → MedicalWebPage(서비스형) 순.
    // 충치·잇몸병은 MedicalCondition, 소아진료·통증저감처럼 시술/질환으로 묶기 어려운
    // 서비스형 페이지는 MedicalWebPage를 본체로 사용한다.
    $proc = null; $webpage = null; $faq_node = null;
    foreach ($nodes as $n) {
        if (!$proc    && has_type($n, 'MedicalProcedure')) $proc    = $n;
        if (!$webpage && has_type($n, 'MedicalWebPage'))   $webpage = $n;
    }
    if (!$proc) {
        foreach ($nodes as $n) {
            if (has_type($n, 'MedicalCondition')) { $proc = $n; break; }
        }
    }
    if (!$proc && $webpage) {
        $proc = $webpage;  // 서비스형 페이지 폴백
    }
    // FAQPage: 페이지 고유(@id에 #faq)만 채택 — head_sub의 전역 FAQ 혼입 방지
    foreach ($nodes as $n) {
        if (has_type($n, 'FAQPage') && !empty($n['mainEntity'])
            && isset($n['@id']) && strpos($n['@id'], '#faq') !== false) {
            $faq_node = $n; break;
        }
    }

    if (!$proc) {
        $report[] = ['error', $path, 'MedicalProcedure/Condition/WebPage 없음 — 색인 제외(스키마 구조 확인 필요)'];
        continue;
    }

    $faqs = [];
    if ($faq_node) {
        foreach ((array) $faq_node['mainEntity'] as $qa) {
            $qn = $qa['name'] ?? '';
            $an = $qa['acceptedAnswer']['text'] ?? '';
            if ($qn !== '') $faqs[] = ['q' => $qn, 'a' => $an];
        }
    }

    // 진료명: 본체가 WebPage 폴백이면 긴 SEO 제목 대신 breadcrumb 마지막 항목(실제 진료명) 사용
    $is_webpage_body = ($proc === $webpage) || has_type($proc, 'MedicalWebPage');
    if ($is_webpage_body) {
        $name = bc_leaf_name($webpage) ?: ($proc['name'] ?? $path);
    } else {
        $name = $proc['name'] ?? ($webpage['name'] ?? $path);
    }
    $alt  = $proc['alternateName'] ?? [];
    if (is_string($alt)) $alt = [$alt];
    $desc = $proc['description'] ?? ($webpage['description'] ?? '');
    $url  = $webpage['url'] ?? ($proc['url'] ?? ($BASE . $path));

    $sup      = $SUP[$path] ?? [];
    $extra_kw = $sup['extra_keywords'] ?? [];

    $keywords = [];
    foreach (array_merge([$name], $alt, $extra_kw) as $k) {
        $k = trim((string) $k);
        if ($k !== '' && !in_array($k, $keywords, true)) $keywords[] = $k;
    }

    $index[] = [
        'path'         => $path,
        'name'         => $name,
        'category'     => bc_category($webpage),
        'keywords'     => $keywords,
        'summary'      => $desc,
        'howPerformed' => $proc['howPerformed'] ?? '',
        'nodeType'     => (isset($proc['@type']) ? (is_array($proc['@type']) ? implode(',', $proc['@type']) : $proc['@type']) : ''),
        'url'          => $url,
        'faqs'         => $faqs,
        'wiki'         => $sup['wiki']    ?? null,
        'related'      => $sup['related'] ?? [],
    ];

    if (!$faqs)  $report[] = ['warn', $path, '주의 — FAQ 0건 (dm_faq_item group_id 확인)'];
    if (empty($sup)) $report[] = ['warn', $path, '안내 — search_supplement.php에 보강(위키/동의어) 없음'];
}

// ───────────────────────── 저장 ─────────────────────────

$out_path = G5_DATA_PATH . '/search_index.json';
$payload  = [
    'generated_at' => date('c'),
    'base'         => $BASE,
    'count'        => count($index),
    'items'        => $index,
];
$json    = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
$written = @file_put_contents($out_path, $json);

// ───────────────────────── 리포트 ─────────────────────────

$errors = array_filter($report, fn($r) => $r[0] === 'error');
$warns  = array_filter($report, fn($r) => $r[0] === 'warn');

if ($IS_CLI) {
    echo "== 통합검색 색인 빌드 ==\n";
    echo "대상 {$payload['count']} / " . count($CRAWL) . "건 색인\n";
    echo ($written !== false ? "저장 OK: $out_path\n" : "저장 실패: $out_path (data 디렉터리 쓰기권한 확인)\n");
    foreach ($report as $r) echo strtoupper($r[0]) . "  {$r[1]}  —  {$r[2]}\n";
    exit;
}
?><!doctype html>
<meta charset="utf-8">
<title>통합검색 색인 빌드</title>
<style>
  body{font-family:'Pretendard','Apple SD Gothic Neo',system-ui,sans-serif;max-width:760px;margin:40px auto;padding:0 18px;color:#1f2a2a;line-height:1.6}
  h1{font-size:22px}
  .ok{color:#1f5e54;font-weight:700}.bad{color:#b3261e;font-weight:700}
  .box{border:1px solid #e3ddd0;border-radius:12px;padding:16px 18px;margin:14px 0;background:#fffdf8}
  .row{display:flex;gap:10px;padding:6px 0;border-bottom:1px solid #f0ece2;font-size:14px}
  .row:last-child{border-bottom:0}
  .tag{flex:none;font-size:11px;font-weight:700;border-radius:5px;padding:2px 7px;height:fit-content}
  .tag.error{background:#fde8e6;color:#b3261e}.tag.warn{background:#fdf3e0;color:#9a6b12}
  code{background:#f0ece2;padding:1px 6px;border-radius:5px;font-size:13px}
</style>
<h1>통합검색 색인 빌드 결과</h1>
<div class="box">
  대상 <b><?= count($CRAWL) ?></b>건 중 <b class="ok"><?= $payload['count'] ?></b>건 색인,
  실패/제외 <b class="<?= count($errors) ? 'bad' : 'ok' ?>"><?= count($errors) ?></b>건<br>
  저장: <?= $written !== false ? '<span class="ok">성공</span> — <code>' . htmlspecialchars($out_path) . '</code>' : '<span class="bad">실패</span> — data 디렉터리 쓰기권한을 확인하세요.' ?>
</div>

<?php if ($errors): ?>
<div class="box">
  <b class="bad">색인 실패 · 제외 (0.1% 점검 대상)</b>
  <?php foreach ($errors as $r): ?>
    <div class="row"><span class="tag error">제외</span><span><code><?= htmlspecialchars($r[1]) ?></code><br><?= htmlspecialchars($r[2]) ?></span></div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<?php if ($warns): ?>
<div class="box">
  <b>경고 · 안내</b>
  <?php foreach ($warns as $r): ?>
    <div class="row"><span class="tag warn">확인</span><span><code><?= htmlspecialchars($r[1]) ?></code><br><?= htmlspecialchars($r[2]) ?></span></div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<p>진료 내용이나 FAQ를 수정한 뒤 이 페이지를 다시 열면 색인이 갱신됩니다.</p>