<?php
/**
 * search_symptoms.php  —  증상 표현 → 진료 추론 사전
 * ---------------------------------------------------------------------------
 * "턱이 아파요", "어금니가 시려요"처럼 진료명이 직접 안 들어간 자연어 문장을
 * 진료로 연결하기 위한 보조 사전. search_smart.php가 키워드 매칭에 실패하거나
 * 애매할 때 이 사전으로 후보를 추론한다.
 *
 * 구조:
 *   'cues'   => 문장에 이 조각들이 함께(또는 단독) 보이면 해당 증상으로 판단
 *   'paths'  => 그 증상과 관련된 진료 경로들 (가중치 순; 앞쪽이 더 관련 높음)
 *
 * 매칭 방식(search_smart에서):
 *   - 'any'  계열 단어 중 하나라도 문장에 있으면 약한 신호
 *   - 'with' 가 지정된 경우, any 단어 + with 단어가 함께 있어야 강한 신호
 *     (예: "어금니"(부위) + "아파"(증상) 동시 → 충치/사랑니 강하게 제안)
 *
 * 진료를 늘리거나 표현을 더하고 싶으면 항목만 추가하면 된다.
 * ---------------------------------------------------------------------------
 */

return [

    // 통증/시림 같은 증상어 (부위어와 결합해 의미가 강해지는 단어들)
    '_pain_words' => ['아파', '아픔', '아프', '통증', '욱신', '쑤시', '시려', '시린', '시림', '불편'],

    // 증상 → 진료 추론 규칙
    'rules' => [

        // 턱 관련
        [
            'any'   => ['턱', '입벌릴', '입이안', '딱딱거', '턱소리', '이갈이', '이악물'],
            'paths' => ['/sub/general/general_jaw.php'],
            'label' => '턱 통증·턱관절',
        ],

        // 어금니/씹을 때 통증 → 충치 또는 사랑니(가장 흔한 두 원인)
        [
            'any'   => ['어금니', '씹을때', '씹으면', '음식씹', '깨물', '치아가', '이가'],
            'with'  => true, // 통증어와 함께일 때 강하게
            'paths' => ['/sub/natural/natural_cavity.php', '/sub/general/general_wisdom.php', '/sub/natural/natural_nerve.php'],
            'label' => '치아 통증',
        ],

        // 사랑니 부위(맨 안쪽)
        [
            'any'   => ['안쪽이', '맨안쪽', '제일안쪽', '잇몸뒤', '사랑니쪽'],
            'paths' => ['/sub/general/general_wisdom.php', '/sub/natural/natural_cavity.php'],
            'label' => '안쪽 어금니·사랑니',
        ],

        // 잇몸 증상
        [
            'any'   => ['잇몸', '피가나', '피나', '붓고', '부었', '붉게', '내려앉', '시리고'],
            'paths' => ['/sub/natural/natural_gums.php', '/sub/general/general_scale.php'],
            'label' => '잇몸 트러블',
        ],

        // 빠진 치아 / 임플란트  (※ '이가' 통증 규칙보다 먼저 평가되도록 위쪽에 위치)
        [
            'any'   => ['이빠', '치아빠', '이가빠', '치아가빠', '빠졌', '빠진이', '빠진치아', '없는이', '이없', '치아없', '발치했', '발치후', '임플', '인공치아', '치아상실'],
            'paths' => ['/sub/implant/implant_highLevel.php', '/sub/implant/implant_SO.php', '/sub/implant/implant_FA.php'],
            'label' => '치아 상실·임플란트',
        ],

        // 시린 증상 (찬물/단것) → 충치 또는 잇몸  (※ '이가' 통증 규칙보다 먼저)
        [
            'any'   => ['찬물', '시려', '시린', '시림', '시리', '단거', '단것', '뜨거운거', '뜨거운것'],
            'paths' => ['/sub/natural/natural_cavity.php', '/sub/natural/natural_gums.php', '/sub/general/general_scale.php', '/sub/natural/natural_nerve.php'],
            'label' => '이가 시린 증상',
        ],

        // 깊은/심한 통증, 욱신거림 → 신경치료 가능성
        [
            'any'   => ['욱신', '지끈', '밤에아', '진통제', '가만히도', '심하게아'],
            'paths' => ['/sub/natural/natural_nerve.php', '/sub/natural/natural_cavity.php'],
            'label' => '심한 치아 통증',
        ],

        // 심미 고민
        [
            'any'   => ['누렇', '누런', '착색', '하얗게', '미백', '커피', '담배', '변색'],
            'paths' => ['/sub/simmi/simmi_whitening.php', '/sub/simmi/simmi_laminate.php'],
            'label' => '치아 색·심미',
        ],
        [
            'any'   => ['앞니', '벌어진', '틈', '모양', '예쁘게', '웃을때', '잇몸이보'],
            'paths' => ['/sub/simmi/simmi_laminate.php', '/sub/simmi/simmi_gums.php', '/sub/simmi/simmi_regin.php'],
            'label' => '앞니 심미',
        ],



        // 아이 관련
        [
            'any'   => ['아이', '애기', '우리애', '어린이', '아기', '유치', '소아', '아들', '딸'],
            'paths' => ['/sub/general/general_child.php'],
            'label' => '아이 치과',
        ],

        // 무서움/통증 공포
        [
            'any'   => ['무서', '겁나', '아플까', '공포', '떨려', '마취', '수면'],
            'paths' => ['/sub/pain/pain_system.php'],
            'label' => '치과가 무서울 때',
        ],

        // 정기검진/관리
        [
            'any'   => ['검진', '정기', '관리', '깨끗', '스케일', '오래됐', '안간지'],
            'paths' => ['/sub/general/general_scale.php', '/sub/natural/natural_gums.php'],
            'label' => '검진·관리',
        ],
    ],
];
