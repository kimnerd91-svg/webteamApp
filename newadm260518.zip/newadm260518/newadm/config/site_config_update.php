<?php
include_once('../../common.php');
include_once('./_common.php');
include_once('./_auth_check.php');

// ============================================================
// DB 컬럼 자동 점검 및 생성
// ============================================================
$check_cols = array(
    'cf_add_script'          => "TEXT DEFAULT ''",
    'cf_add_body_script'     => "TEXT DEFAULT ''",
    'cf_site_name'           => "varchar(255) DEFAULT ''",
    'cf_title'               => "varchar(255) DEFAULT ''",
    'cf_description'         => "text",
    'cf_ga_id'               => "varchar(255) DEFAULT ''",
    // [변경] cf_ga4_property_id 제거 — cf_ga_id(G-XXXXXXX)와 중복이므로 삭제
    'cf_langs'               => "varchar(255) DEFAULT ''",
    'cf_logo'                => "varchar(255) DEFAULT ''",
    'cf_favicon'             => "varchar(255) DEFAULT ''",
    'cf_og_image'            => "varchar(255) DEFAULT ''",
    'cf_company_name'        => "varchar(255) DEFAULT ''",
    'cf_ceo_name'            => "varchar(100) DEFAULT ''",
    'cf_business_number'     => "varchar(50)  DEFAULT ''",
    'cf_tel'                 => "varchar(50)  DEFAULT ''",
    'cf_address'             => "varchar(500) DEFAULT ''",
    'cf_lat'                 => "varchar(50)  DEFAULT ''",
    'cf_lng'                 => "varchar(50)  DEFAULT ''",
    'cf_naver_booking'       => "varchar(500) DEFAULT ''",
    'cf_naver_talk'          => "varchar(500) DEFAULT ''",
    'cf_kakao'               => "varchar(500) DEFAULT ''",
    'cf_blog'                => "varchar(500) DEFAULT ''",
    'cf_instagram'           => "varchar(500) DEFAULT ''",
    'cf_privacy_policy'      => "longtext",
    'cf_terms'               => "longtext",
    'cf_kakao_rest_key'      => "varchar(255) DEFAULT ''",
    'cf_kakao_client_secret' => "varchar(255) DEFAULT ''",
    'cf_naver_client_id'     => "varchar(255) DEFAULT ''",
    'cf_naver_secret'        => "varchar(255) DEFAULT ''",
    'cf_google_client_id'    => "varchar(255) DEFAULT ''",
    'cf_social_login_use'    => "tinyint(4)   DEFAULT '0'",
    'cf_city'                => "varchar(100) DEFAULT ''",
    'cf_open_time'           => "varchar(10)  DEFAULT '09:00'",
    'cf_close_time'          => "varchar(10)  DEFAULT '18:00'",
    'cf_sat_open'            => "varchar(10)  DEFAULT '09:00'",
    'cf_sat_close'           => "varchar(10)  DEFAULT '13:00'",
    'cf_youtube'             => "varchar(500) DEFAULT ''",
    'cf_night_days'          => "varchar(100) DEFAULT ''",
    'cf_night_open'          => "varchar(10)  DEFAULT ''",
    'cf_night_close'         => "varchar(10)  DEFAULT ''",
    'cf_lunch_open'          => "varchar(10)  DEFAULT '13:00'",
    'cf_lunch_close'         => "varchar(10)  DEFAULT '14:00'",
    'cf_address_detail'      => "varchar(255) DEFAULT ''",
    'cf_address_add'         => "varchar(255) DEFAULT ''",
    'cf_address_base'        => "varchar(255) DEFAULT ''",
    'cf_gtm_id'              => "varchar(50)  DEFAULT ''",
    // [변경] cf_gsc_verification: content 값만 → 전체 <meta> 태그 저장
    //        varchar(255) → text 로 타입 변경 (태그 전체가 들어가므로)
    'cf_gsc_verification'    => "text",
    // [변경] cf_naver_verification: content 값만 → 전체 <meta> 태그 저장
    //        varchar(255) → text 로 타입 변경
    'cf_naver_verification'  => "text",
    'cf_founded_year'        => "varchar(4)   DEFAULT ''",
    'cf_expertise'           => "text",
    'cf_global_faq'          => "longtext",
    'cf_sitemap_urls'        => "longtext",
    'cf_robots_disallow'     => "text",
    'cf_robots_allow'        => "text",
    'cf_canonical_base'      => "varchar(255) DEFAULT ''",
    'cf_google_business' => "varchar(500) DEFAULT ''",
'cf_sns_extra'       => "text",
);

foreach ($check_cols as $col => $type) {
    $c = sql_query("SHOW COLUMNS FROM `dm_config` LIKE '$col'");
    if (sql_num_rows($c) == 0) {
        sql_query("ALTER TABLE `dm_config` ADD `$col` $type");
    }
}

// cf_gsc_verification / cf_naver_verification 컬럼이 varchar(255)로 이미 존재하는 경우
// text 타입으로 변경 (기존 데이터 유지됨)
foreach (['cf_gsc_verification', 'cf_naver_verification'] as $col) {
    $row = sql_fetch("SHOW COLUMNS FROM `dm_config` LIKE '$col'");
    if ($row && stripos($row['Type'], 'varchar') !== false) {
        sql_query("ALTER TABLE `dm_config` MODIFY `$col` text");
    }
}

// ============================================================
// 다국어 설정
// ============================================================
$cf_langs = isset($_POST['cf_langs']) ? implode(',', (array)$_POST['cf_langs']) : 'ko';

// ============================================================
// 기존 설정값 불러오기
// ============================================================
$config      = sql_fetch("SELECT * FROM dm_config WHERE cf_id = 1");
$upload_path = G5_DATA_PATH . '/common';
if (!is_dir($upload_path)) {
    @mkdir($upload_path, G5_DIR_PERMISSION, true);
}

// ============================================================
// 파일 업로드 처리
// ============================================================
function handle_file_upload($file_key, $existing_filename) {
    global $upload_path;
    if (isset($_FILES[$file_key]) && $_FILES[$file_key]['error'] == 0 && $_FILES[$file_key]['name']) {
        $ext      = strtolower(pathinfo($_FILES[$file_key]['name'], PATHINFO_EXTENSION));
        $filename = $file_key . '_' . time() . '.' . $ext;
        if (move_uploaded_file($_FILES[$file_key]['tmp_name'], $upload_path . '/' . $filename)) {
            return $filename;
        }
    }
    return $existing_filename;
}

$cf_favicon  = handle_file_upload('favicon_file', $config['cf_favicon']);
$cf_og_image = handle_file_upload('og_file',      $config['cf_og_image']);

// 로고 별도 처리
$cf_logo = $config['cf_logo'];
if (isset($_FILES['logo_file']['name']) && $_FILES['logo_file']['name']) {
    $logo_ext  = strtolower(pathinfo($_FILES['logo_file']['name'], PATHINFO_EXTENSION));
    $logo_name = 'logo_' . time() . '.' . $logo_ext;
    if (move_uploaded_file($_FILES['logo_file']['tmp_name'], $upload_path . '/' . $logo_name)) {
        $cf_logo = $logo_name;
    }
}

// ============================================================
// SQL 필드 구성
// ============================================================
$sql_fields = array();

// 스크립트 필드 (global $connect_db 사용)
global $connect_db;
foreach (array('cf_add_script', 'cf_add_body_script') as $f) {
    if (isset($_POST[$f])) {
        $val          = mysqli_real_escape_string($connect_db, stripslashes($_POST[$f]));
        $sql_fields[] = " `$f` = '$val' ";
    }
}

// 일반 텍스트 필드
// [변경] cf_ga4_property_id 제거
// [변경] cf_gsc_verification / cf_naver_verification: 전체 <meta> 태그 HTML을 그대로 저장
$fields = array(
    'cf_site_name','cf_title','cf_description','cf_ga_id',
    'cf_company_name','cf_ceo_name','cf_business_number','cf_tel',
    'cf_address','cf_lat','cf_lng','cf_privacy_policy','cf_terms',
    'cf_naver_booking','cf_naver_talk','cf_kakao','cf_blog','cf_instagram',
    'cf_kakao_rest_key','cf_kakao_client_secret',
    'cf_naver_client_id','cf_naver_secret','cf_google_client_id',
    'cf_city','cf_open_time','cf_close_time','cf_sat_open','cf_sat_close',
    'cf_youtube','cf_night_days','cf_night_open','cf_night_close',
    'cf_lunch_open','cf_lunch_close','cf_address_detail','cf_address_add','cf_address_base',
    'cf_gtm_id',
    'cf_gsc_verification',   // 전체 <meta> 태그 HTML
    'cf_naver_verification',  // 전체 <meta> 태그 HTML
    'cf_founded_year','cf_expertise','cf_global_faq',
    'cf_sitemap_urls','cf_robots_disallow','cf_robots_allow',
    'cf_google_business', 'cf_sns_extra',
);
foreach ($fields as $f) {
    if (isset($_POST[$f])) {
        $val          = sql_escape_string(stripslashes($_POST[$f]));
        $sql_fields[] = " `$f` = '$val' ";
    }
}

// 체크박스
$cf_social_login_use = isset($_POST['cf_social_login_use']) ? 1 : 0;
$sql_fields[] = " `cf_social_login_use` = '$cf_social_login_use' ";

// 파일/다국어
$sql_fields[] = " `cf_langs`    = '" . sql_escape_string($cf_langs)    . "' ";
$sql_fields[] = " `cf_favicon`  = '" . sql_escape_string($cf_favicon)  . "' ";
$sql_fields[] = " `cf_og_image` = '" . sql_escape_string($cf_og_image) . "' ";
$sql_fields[] = " `cf_logo`     = '" . sql_escape_string($cf_logo)     . "' ";

// ============================================================
// 저장 (행 없으면 INSERT 후 UPDATE)
// ============================================================
$exist = sql_fetch("SELECT cf_id FROM dm_config WHERE cf_id = 1");
if (!$exist) {
    sql_query("INSERT INTO dm_config (cf_id) VALUES (1)");
}
$sql    = "UPDATE dm_config SET " . implode(',', $sql_fields) . " WHERE cf_id = 1";
$result = sql_query($sql);

if ($result) {
    alert_toast('설정이 저장되었습니다.', '../config/site_config.php', 'success');
} else {
    alert_toast('저장 실패: ' . sql_error(), '../config/site_config.php', 'error');
}