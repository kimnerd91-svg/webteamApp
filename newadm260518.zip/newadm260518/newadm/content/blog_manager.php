<?php
include_once('../_common.php');
include_once('../_auth_check.php');

// ── 이미지 업로드 ───────────────────────────────────────────
if (isset($_FILES['gl_image']['name']) && $_FILES['gl_image']['error'] === UPLOAD_ERR_OK) {
    while (ob_get_level()) ob_end_clean();
    $upload_dir = G5_DATA_PATH . '/gallery/' . date('Ym');
    $upload_url = G5_DATA_URL  . '/gallery/' . date('Ym');
    if (!is_dir($upload_dir)) { @mkdir($upload_dir, G5_DIR_PERMISSION, true); @chmod($upload_dir, G5_DIR_PERMISSION); }
    $ext = strtolower(pathinfo($_FILES['gl_image']['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg','jpeg','png','gif','webp'])) {
        header('Content-Type: application/json');
        echo json_encode(['success'=>0,'message'=>'이미지 파일만 업로드 가능합니다.']);
        exit;
    }
    $new_name = time().'_'.md5(uniqid()).'.'.$ext;
    if (move_uploaded_file($_FILES['gl_image']['tmp_name'], $upload_dir.'/'.$new_name)) {
        header('Content-Type: application/json');
        echo json_encode(['success'=>1,'url'=>$upload_url.'/'.$new_name]);
    } else {
        header('Content-Type: application/json');
        echo json_encode(['success'=>0,'message'=>'업로드 실패. 폴더 권한을 확인하세요.']);
    }
    exit;
}

// ── 테이블 생성 ─────────────────────────────────────────────
sql_query("CREATE TABLE IF NOT EXISTS `dm_gallery` (
    `id`            INT(11) NOT NULL AUTO_INCREMENT,
    `title`         VARCHAR(500) NOT NULL DEFAULT '',
    `description`   TEXT,
    `image`         VARCHAR(500) DEFAULT '',
    `link_url`      VARCHAR(1000) DEFAULT '',
    `display_order` INT(11) DEFAULT 0,
    `is_visible`    TINYINT(1) DEFAULT 1,
    `created_at`    DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ── 삭제 ────────────────────────────────────────────────────
if (isset($_GET['delete_id'])) {
    sql_query("DELETE FROM dm_gallery WHERE id=" . (int)$_GET['delete_id']);
    alert_toast('삭제되었습니다.', './blog_manager.php');
}

// ── 노출 토글 ───────────────────────────────────────────────
if (isset($_GET['toggle_id'])) {
    $tid = (int)$_GET['toggle_id'];
    $cur = sql_fetch("SELECT is_visible FROM dm_gallery WHERE id={$tid}");
    $new = $cur['is_visible'] ? 0 : 1;
    sql_query("UPDATE dm_gallery SET is_visible={$new} WHERE id={$tid}");
    header('Content-Type: application/json');
    echo json_encode(['success'=>1,'is_visible'=>$new]);
    exit;
}

// ── 추가 ────────────────────────────────────────────────────
if (isset($_POST['action']) && $_POST['action'] === 'add_gallery') {
    $title         = sql_real_escape_string(trim($_POST['title']));
    $description   = sql_real_escape_string(trim($_POST['description'] ?? ''));
    $image         = sql_real_escape_string(trim($_POST['image'] ?? ''));
    $link_url      = sql_real_escape_string(trim($_POST['link_url'] ?? ''));
    $display_order = (int)($_POST['display_order'] ?? 0);
    $is_visible    = isset($_POST['is_visible']) ? 1 : 0;
    sql_query("INSERT INTO dm_gallery SET
        title='{$title}', description='{$description}', image='{$image}',
        link_url='{$link_url}', display_order='{$display_order}',
        is_visible='{$is_visible}', created_at=NOW()");
    alert_toast('추가되었습니다.', './blog_manager.php', 'success');
}

// ── 수정 ────────────────────────────────────────────────────
if (isset($_POST['action']) && $_POST['action'] === 'update_gallery') {
    $id            = (int)$_POST['id'];
    $title         = sql_real_escape_string(trim($_POST['title']));
    $description   = sql_real_escape_string(trim($_POST['description'] ?? ''));
    $image         = sql_real_escape_string(trim($_POST['image'] ?? ''));
    $link_url      = sql_real_escape_string(trim($_POST['link_url'] ?? ''));
    $display_order = (int)($_POST['display_order'] ?? 0);
    $is_visible    = isset($_POST['is_visible']) ? 1 : 0;
    sql_query("UPDATE dm_gallery SET
        title='{$title}', description='{$description}', image='{$image}',
        link_url='{$link_url}', display_order='{$display_order}',
        is_visible='{$is_visible}'
        WHERE id={$id}");
    alert_toast('수정되었습니다.', './blog_manager.php', 'success');
}

// ── 목록 조회 ────────────────────────────────────────────────
$result   = sql_query("SELECT * FROM dm_gallery ORDER BY display_order ASC, id DESC");
$galleries = [];
while ($row = sql_fetch_array($result)) $galleries[] = $row;
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>갤러리(블로그) 관리</title>
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Pretendard', 'Apple SD Gothic Neo', sans-serif; background: #f5f6fa; color: #1a1a2e; }
        #admin_wrapper { display: flex; min-height: 100vh; }
        .content_area { flex: 1; padding: 40px; overflow-x: hidden; }

        .page_header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 28px; }
        .page_title  { font-size: 22px; font-weight: 700; }
        .btn_add { padding: 11px 22px; background: #4f46e5; color: #fff; border: none; border-radius: 9px; font-size: 13px; font-weight: 700; cursor: pointer; box-shadow: 0 4px 12px rgba(79,70,229,0.25); transition: all 0.2s; }
        .btn_add:hover { background: #4338ca; }

        .card { background: #fff; border-radius: 12px; box-shadow: 0 2px 12px rgba(0,0,0,0.06); border: 1px solid #e8eaf0; padding: 24px; margin-bottom: 24px; }

        /* 갤러리 그리드 */
        .gl_grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 18px; }
        .gl_card { background: #fff; border-radius: 12px; border: 1px solid #e8eaf0; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.05); transition: all 0.2s; }
        .gl_card:hover { transform: translateY(-3px); box-shadow: 0 8px 24px rgba(0,0,0,0.1); border-color: #c4b5fd; }
        .gl_card.hidden_card { opacity: 0.5; }
        .gl_thumb { width: 100%; aspect-ratio: 4/3; object-fit: cover; display: block; }
        .gl_thumb_ph { width: 100%; aspect-ratio: 4/3; background: #f5f6fa; display: flex; align-items: center; justify-content: center; color: #9999bb; font-size: 13px; }
        .gl_body { padding: 14px 16px; }
        .gl_badge_wrap { display: flex; gap: 6px; margin-bottom: 8px; }
        .gl_badge { display: inline-block; font-size: 11px; font-weight: 700; padding: 3px 10px; border-radius: 20px; }
        .gl_badge.visible   { background: #dcfce7; color: #166534; }
        .gl_badge.invisible { background: #fee2e2; color: #991b1b; }
        .gl_title { font-size: 15px; font-weight: 700; color: #1a1a2e; margin-bottom: 5px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .gl_desc  { font-size: 12px; color: #9999bb; line-height: 1.5; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; margin-bottom: 8px; }
        .gl_link  { font-size: 11px; color: #4f46e5; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-bottom: 12px; display: block; }
        .gl_actions { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 6px; }
        .btn_gl { padding: 7px 4px; border: none; border-radius: 7px; font-size: 11px; font-weight: 700; cursor: pointer; transition: all 0.2s; }
        .btn_edit   { background: #4f46e5; color: #fff; }
        .btn_edit:hover { background: #4338ca; }
        .btn_toggle { background: #fef9c3; color: #854d0e; }
        .btn_toggle:hover { background: #fde68a; }
        .btn_del    { background: #fee2e2; color: #dc2626; }
        .btn_del:hover { background: #fecaca; }
        .empty_state { text-align: center; padding: 60px; color: #9999bb; font-size: 14px; }

        /* 모달 */
        .modal_overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.55); z-index: 10000; align-items: flex-start; justify-content: center; padding: 40px 20px; overflow-y: auto; }
        .modal_overlay.active { display: flex; }
        .modal_box { background: #fff; border-radius: 14px; width: 100%; max-width: 600px; overflow: hidden; animation: modal_in 0.25s ease; margin: auto; }
        @keyframes modal_in { from { transform: translateY(-20px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
        .modal_hd { padding: 20px 24px; border-bottom: 1px solid #e8eaf0; display: flex; align-items: center; justify-content: space-between; }
        .modal_hd h3 { font-size: 16px; font-weight: 700; }
        .modal_close { background: none; border: none; font-size: 20px; cursor: pointer; color: #9999bb; }
        .modal_bd { padding: 24px; display: flex; flex-direction: column; gap: 14px; max-height: 75vh; overflow-y: auto; }
        .form_group label { display: block; font-size: 12px; font-weight: 700; color: #9999bb; margin-bottom: 6px; }
        .form_input { width: 100%; border: 1px solid #e8eaf0; border-radius: 8px; padding: 10px 14px; font-size: 14px; background: #f5f6fa; font-family: inherit; transition: all 0.2s; }
        .form_input:focus { outline: none; border-color: #4f46e5; background: #fff; box-shadow: 0 0 0 3px rgba(79,70,229,0.1); }
        textarea.form_input { resize: vertical; min-height: 80px; }
        .form_grid2 { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
        .check_wrap { display: flex; align-items: center; gap: 8px; font-size: 14px; cursor: pointer; }
        .check_wrap input { width: 16px; height: 16px; cursor: pointer; accent-color: #4f46e5; }

        /* 업로드 존 */
        .upload_zone { border: 2px dashed #e8eaf0; border-radius: 10px; padding: 20px; text-align: center; cursor: pointer; transition: all 0.2s; background: #f5f6fa; position: relative; min-height: 90px; display: flex; flex-direction: column; align-items: center; justify-content: center; }
        .upload_zone:hover, .upload_zone.dragover { border-color: #4f46e5; background: #ede9fe; }
        .upload_zone input[type="file"] { position: absolute; inset: 0; opacity: 0; cursor: pointer; width: 100%; height: 100%; }
        .upload_zone_icon { font-size: 22px; margin-bottom: 4px; pointer-events: none; }
        .upload_zone_text { font-size: 12px; color: #9999bb; pointer-events: none; }
        .upload_zone_text strong { color: #4f46e5; }
        .upload_preview { width: 100%; height: 100px; object-fit: cover; border-radius: 8px; margin-top: 8px; border: 1px solid #e8eaf0; display: none; }
        .upload_loading { display: none; font-size: 12px; color: #9999bb; margin-top: 6px; text-align: center; }

        .modal_ft { padding: 16px 24px; border-top: 1px solid #e8eaf0; display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
        .btn_modal_cancel { padding: 12px; border-radius: 8px; background: #f5f6fa; color: #5c5c7a; border: 1px solid #e8eaf0; font-size: 14px; font-weight: 700; cursor: pointer; }
        .btn_modal_submit { padding: 12px; border-radius: 8px; background: #4f46e5; color: #fff; border: none; font-size: 14px; font-weight: 700; cursor: pointer; }
        .btn_modal_submit:hover { background: #4338ca; }

        .stat_bar { display: flex; gap: 16px; margin-bottom: 20px; flex-wrap: wrap; }
        .stat_chip { background: #fff; border: 1px solid #e8eaf0; border-radius: 10px; padding: 10px 18px; font-size: 13px; font-weight: 600; color: #5c5c7a; }
        .stat_chip span { font-size: 18px; font-weight: 700; color: #4f46e5; margin-right: 4px; }
    </style>
</head>
<body>
<div id="admin_wrapper">
    <?php include_once('../aside.php'); ?>
    <main class="content_area">

        <div class="page_header">
            <h2 class="page_title">📸 갤러리(블로그) 관리</h2>
            <button onclick="openAddModal()" class="btn_add">+ 새 항목 추가</button>
        </div>

        <!-- 통계 -->
        <?php
        $total   = count($galleries);
        $visible = count(array_filter($galleries, fn($g) => $g['is_visible']));
        ?>
        <div class="stat_bar">
            <div class="stat_chip"><span><?= $total ?></span>전체</div>
            <div class="stat_chip"><span><?= $visible ?></span>노출 중</div>
            <div class="stat_chip"><span><?= $total - $visible ?></span>숨김</div>
        </div>

        <div class="card">
            <?php if (!empty($galleries)): ?>
            <div class="gl_grid">
                <?php foreach ($galleries as $gl): ?>
                <div class="gl_card <?= $gl['is_visible'] ? '' : 'hidden_card' ?>">
                    <?php if ($gl['image']): ?>
                        <img class="gl_thumb" src="<?= htmlspecialchars($gl['image']) ?>" alt="<?= htmlspecialchars($gl['title']) ?>">
                    <?php else: ?>
                        <div class="gl_thumb_ph">이미지 없음</div>
                    <?php endif; ?>
                    <div class="gl_body">
                        <div class="gl_badge_wrap">
                            <span class="gl_badge <?= $gl['is_visible'] ? 'visible' : 'invisible' ?>">
                                <?= $gl['is_visible'] ? '노출' : '숨김' ?>
                            </span>
                            <span class="gl_badge" style="background:#f1f5f9;color:#64748b;">순서 <?= (int)$gl['display_order'] ?></span>
                        </div>
                        <div class="gl_title"><?= htmlspecialchars($gl['title']) ?></div>
                        <?php if ($gl['description']): ?>
                        <div class="gl_desc"><?= htmlspecialchars($gl['description']) ?></div>
                        <?php endif; ?>
                        <?php if ($gl['link_url']): ?>
                        <a class="gl_link" href="<?= htmlspecialchars($gl['link_url']) ?>" target="_blank" title="<?= htmlspecialchars($gl['link_url']) ?>">
                            🔗 <?= htmlspecialchars($gl['link_url']) ?>
                        </a>
                        <?php endif; ?>
                        <div class="gl_actions">
                            <button class="btn_gl btn_edit"
                                onclick='openEditModal(<?= json_encode($gl, JSON_HEX_QUOT|JSON_HEX_TAG) ?>)'>수정</button>
                            <button class="btn_gl btn_toggle" id="toggle_btn_<?= $gl['id'] ?>"
                                onclick="toggleVisible(<?= $gl['id'] ?>)">
                                <?= $gl['is_visible'] ? '숨기기' : '노출' ?>
                            </button>
                            <button class="btn_gl btn_del"
                                onclick="if(confirm('정말 삭제하시겠습니까?')) location.href='?delete_id=<?= $gl['id'] ?>'">삭제</button>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <div class="empty_state">등록된 항목이 없습니다.</div>
            <?php endif; ?>
        </div>

    </main>
</div>

<!-- 추가 모달 -->
<div class="modal_overlay" id="addModal">
    <div class="modal_box">
        <div class="modal_hd">
            <h3>새 항목 추가</h3>
            <span></span>
        </div>
        <form method="post" id="addForm">
            <input type="hidden" name="action" value="add_gallery">
            <input type="hidden" name="image" id="add_image_val">
            <div class="modal_bd">
                <div class="form_group">
                    <label>제목 *</label>
                    <input type="text" name="title" class="form_input" placeholder="블로그/갤러리 제목" required>
                </div>
                <div class="form_group">
                    <label>설명</label>
                    <textarea name="description" class="form_input" placeholder="간단한 설명"></textarea>
                </div>
                <div class="form_group">
                    <label>이미지</label>
                    <div class="upload_zone"
                        ondragover="event.preventDefault();this.classList.add('dragover')"
                        ondragleave="this.classList.remove('dragover')"
                        ondrop="handleDrop(event,'add_image_val','add_image_preview','add_image_loading')">
                        <input type="file" accept="image/*"
                            onchange="uploadImage(this.files[0],'add_image_val','add_image_preview','add_image_loading')">
                        <div class="upload_zone_icon">🖼️</div>
                        <div class="upload_zone_text">클릭 또는 <strong>드래그</strong> 업로드</div>
                    </div>
                    <div class="upload_loading" id="add_image_loading">⏳ 업로드 중...</div>
                    <img id="add_image_preview" class="upload_preview">
                </div>
                <div class="form_group">
                    <label>링크 URL</label>
                    <input type="url" name="link_url" class="form_input" placeholder="https://blog.naver.com/...">
                </div>
                <div class="form_grid2">
                    <div class="form_group">
                        <label>표시 순서</label>
                        <input type="number" name="display_order" class="form_input" value="0">
                    </div>
                    <div class="form_group" style="display:flex;align-items:flex-end;padding-bottom:2px;">
                        <label class="check_wrap">
                            <input type="checkbox" name="is_visible" checked>
                            바로 노출하기
                        </label>
                    </div>
                </div>
            </div>
            <div class="modal_ft">
                <button type="button" class="btn_modal_cancel" onclick="closeModal('addModal')">취소</button>
                <button type="submit" class="btn_modal_submit">추가하기</button>
            </div>
        </form>
    </div>
</div>

<!-- 수정 모달 -->
<div class="modal_overlay" id="editModal">
    <div class="modal_box">
        <div class="modal_hd">
            <h3>항목 수정</h3>
            <span></span>
        </div>
        <form method="post" id="editForm">
            <input type="hidden" name="action" value="update_gallery">
            <input type="hidden" name="id" id="edit_id">
            <input type="hidden" name="image" id="edit_image_val">
            <div class="modal_bd">
                <div class="form_group">
                    <label>제목 *</label>
                    <input type="text" name="title" id="edit_title" class="form_input" required>
                </div>
                <div class="form_group">
                    <label>설명</label>
                    <textarea name="description" id="edit_description" class="form_input"></textarea>
                </div>
                <div class="form_group">
                    <label>이미지</label>
                    <div class="upload_zone"
                        ondragover="event.preventDefault();this.classList.add('dragover')"
                        ondragleave="this.classList.remove('dragover')"
                        ondrop="handleDrop(event,'edit_image_val','edit_image_preview','edit_image_loading')">
                        <input type="file" accept="image/*"
                            onchange="uploadImage(this.files[0],'edit_image_val','edit_image_preview','edit_image_loading')">
                        <div class="upload_zone_icon">🖼️</div>
                        <div class="upload_zone_text">클릭 또는 <strong>드래그</strong> 교체</div>
                    </div>
                    <div class="upload_loading" id="edit_image_loading">⏳ 업로드 중...</div>
                    <img id="edit_image_preview" class="upload_preview">
                </div>
                <div class="form_group">
                    <label>링크 URL</label>
                    <input type="url" name="link_url" id="edit_link_url" class="form_input">
                </div>
                <div class="form_grid2">
                    <div class="form_group">
                        <label>표시 순서</label>
                        <input type="number" name="display_order" id="edit_display_order" class="form_input">
                    </div>
                    <div class="form_group" style="display:flex;align-items:flex-end;padding-bottom:2px;">
                        <label class="check_wrap">
                            <input type="checkbox" name="is_visible" id="edit_is_visible">
                            노출하기
                        </label>
                    </div>
                </div>
            </div>
            <div class="modal_ft">
                <button type="button" class="btn_modal_cancel" onclick="closeModal('editModal')">취소</button>
                <button type="submit" class="btn_modal_submit">수정 완료</button>
            </div>
        </form>
    </div>
</div>

<script>
// 모달 닫기 (취소 버튼 전용)
function closeModal(id) { document.getElementById(id).classList.remove('active'); }

// 추가 모달
function openAddModal() {
    document.getElementById('addForm').reset();
    document.getElementById('add_image_val').value = '';
    document.getElementById('add_image_preview').src = '';
    document.getElementById('add_image_preview').style.display = 'none';
    document.getElementById('add_image_loading').style.display = 'none';
    document.getElementById('addModal').classList.add('active');
}

// 수정 모달
function openEditModal(data) {
    document.getElementById('edit_id').value            = data.id;
    document.getElementById('edit_title').value         = data.title;
    document.getElementById('edit_description').value   = data.description || '';
    document.getElementById('edit_link_url').value      = data.link_url || '';
    document.getElementById('edit_display_order').value = data.display_order;
    document.getElementById('edit_is_visible').checked  = data.is_visible == 1;
    document.getElementById('edit_image_val').value     = data.image || '';
    document.getElementById('edit_image_loading').style.display = 'none';

    const preview = document.getElementById('edit_image_preview');
    if (data.image) { preview.src = data.image; preview.style.display = 'block'; }
    else            { preview.src = ''; preview.style.display = 'none'; }

    document.getElementById('editModal').classList.add('active');
}

// 이미지 업로드
function uploadImage(file, hiddenId, previewId, loadingId) {
    if (!file) return;
    document.getElementById(loadingId).style.display = 'block';
    document.getElementById(previewId).style.display = 'none';
    const fd = new FormData();
    fd.append('gl_image', file);
    fetch('./blog_manager.php', { method: 'POST', body: fd })
        .then(r => r.json())
        .then(data => {
            document.getElementById(loadingId).style.display = 'none';
            if (data.success) {
                document.getElementById(hiddenId).value      = data.url;
                document.getElementById(previewId).src       = data.url;
                document.getElementById(previewId).style.display = 'block';
            } else {
                alert(data.message || '업로드 실패');
            }
        })
        .catch(() => { document.getElementById(loadingId).style.display = 'none'; alert('업로드 중 오류'); });
}

function handleDrop(event, hiddenId, previewId, loadingId) {
    event.preventDefault();
    event.currentTarget.classList.remove('dragover');
    const file = event.dataTransfer.files[0];
    if (file && file.type.startsWith('image/')) uploadImage(file, hiddenId, previewId, loadingId);
    else alert('이미지 파일만 업로드 가능합니다.');
}

// 노출/숨김 토글 (페이지 새로고침 없이)
function toggleVisible(id) {
    fetch(`./blog_manager.php?toggle_id=${id}`)
        .then(r => r.json())
        .then(data => {
            if (!data.success) return;
            const card = document.getElementById('toggle_btn_' + id).closest('.gl_card');
            const badge = card.querySelector('.gl_badge.visible, .gl_badge.invisible');
            const btn   = document.getElementById('toggle_btn_' + id);
            if (data.is_visible) {
                card.classList.remove('hidden_card');
                badge.className = 'gl_badge visible';
                badge.textContent = '노출';
                btn.textContent = '숨기기';
            } else {
                card.classList.add('hidden_card');
                badge.className = 'gl_badge invisible';
                badge.textContent = '숨김';
                btn.textContent = '노출';
            }
        });
}
</script>
</body>
</html>