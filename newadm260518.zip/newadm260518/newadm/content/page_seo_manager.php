<?php
include_once('../_common.php');
include_once('./_auth_check.php');

if (!$is_admin) { header('Location: /bbs/login.php?url='.urlencode($_SERVER['REQUEST_URI'])); exit; }

global $connect_db;
$db = $connect_db;

$table = 'dm_page_seo';

// ── 테이블 자동 생성 ─────────────────────────────────────
mysqli_query($db, "CREATE TABLE IF NOT EXISTS `{$table}` (
    `id`          INT(11) NOT NULL AUTO_INCREMENT,
    `path`        VARCHAR(255) NOT NULL DEFAULT '',
    `seo_title`   VARCHAR(255) NOT NULL DEFAULT '',
    `seo_desc`    TEXT,
    `og_image`    VARCHAR(500) DEFAULT '',
    `schema_type` VARCHAR(100) DEFAULT '',
    `updated_at`  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `path` (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// schema_type 컬럼이 짧으면 늘려두기 (여러 타입 합쳐 저장하므로)
$col = mysqli_fetch_assoc(mysqli_query($db, "SHOW COLUMNS FROM `{$table}` LIKE 'schema_type'"));
if ($col && stripos($col['Type'], 'varchar(100)') !== false) {
    mysqli_query($db, "ALTER TABLE `{$table}` MODIFY `schema_type` VARCHAR(255) DEFAULT ''");
}

// ── 저장 (AJAX) ──────────────────────────────────────────
if (isset($_GET['action']) && $_GET['action'] === 'save') {
    while (ob_get_level()) ob_end_clean();
    header('Content-Type: application/json; charset=utf-8');

    $data = json_decode(file_get_contents('php://input'), true) ?? [];

    // ── 스키마만 동기화 (자동 갱신용) — 다른 필드는 절대 건드리지 않음 ──
    if (!empty($data['_sync_only'])) {
        $id          = (int)($data['id'] ?? 0);
        $schema_type = mysqli_real_escape_string($db, trim($data['schema_type'] ?? ''));
        if ($id) {
            mysqli_query($db, "UPDATE `{$table}` SET schema_type='{$schema_type}' WHERE id={$id}");
        }
        echo json_encode(['ok' => true, 'sync' => true]);
        exit;
    }

    // ── 일반 전체 저장 ──
    $id          = (int)($data['id'] ?? 0);
    $path        = mysqli_real_escape_string($db, trim($data['path']        ?? ''));
    $seo_title   = mysqli_real_escape_string($db, trim($data['seo_title']   ?? ''));
    $seo_desc    = mysqli_real_escape_string($db, trim($data['seo_desc']    ?? ''));
    $og_image    = mysqli_real_escape_string($db, trim($data['og_image']    ?? ''));
    $schema_type = mysqli_real_escape_string($db, trim($data['schema_type'] ?? ''));

    if (!$path) { echo json_encode(['ok'=>false,'err'=>'경로 없음']); exit; }

    if ($id) {
        $ok = mysqli_query($db, "UPDATE `{$table}` SET
            path='{$path}', seo_title='{$seo_title}', seo_desc='{$seo_desc}',
            og_image='{$og_image}', schema_type='{$schema_type}', updated_at=NOW()
            WHERE id={$id}");
    } else {
        $ok = mysqli_query($db, "INSERT INTO `{$table}` (path,seo_title,seo_desc,og_image,schema_type,updated_at)
            VALUES('{$path}','{$seo_title}','{$seo_desc}','{$og_image}','{$schema_type}',NOW())
            ON DUPLICATE KEY UPDATE
            seo_title='{$seo_title}', seo_desc='{$seo_desc}', og_image='{$og_image}',
            schema_type='{$schema_type}', updated_at=NOW()");
    }

    echo json_encode(['ok' => (bool)$ok, 'err' => $ok ? '' : mysqli_error($db), 'insert_id' => mysqli_insert_id($db)]);
    exit;
}

// ── 삭제 (AJAX) ──────────────────────────────────────────
if (isset($_GET['action']) && $_GET['action'] === 'delete') {
    while (ob_get_level()) ob_end_clean();
    header('Content-Type: application/json; charset=utf-8');
    $id = (int)($_GET['id'] ?? 0);
    if ($id) mysqli_query($db, "DELETE FROM `{$table}` WHERE id={$id}");
    echo json_encode(['ok' => true]);
    exit;
}

// ── 목록 조회 ────────────────────────────────────────────
$rows = [];
$r = mysqli_query($db, "SELECT * FROM `{$table}` ORDER BY updated_at DESC");
if ($r) while ($row = mysqli_fetch_assoc($r)) $rows[] = $row;
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>SEO 관리</title>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'Pretendard','Apple SD Gothic Neo',sans-serif;background:#f5f6fa;color:#1a1a2e;}
#admin_wrapper{display:flex;min-height:100vh;}
.content_area{flex:1;padding:40px;overflow-x:hidden;display:flex;flex-direction:column;gap:20px;}
.page_header{display:flex;align-items:center;justify-content:space-between;}
.page_title{font-size:22px;font-weight:700;display:flex;align-items:center;gap:10px;}
.card{background:#fff;border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,.06);border:1px solid #e8eaf0;overflow:hidden;}
.card_hd{padding:14px 20px;border-bottom:1px solid #e8eaf0;display:flex;align-items:center;justify-content:space-between;}
.card_hd_title{font-size:14px;font-weight:700;display:flex;align-items:center;gap:6px;}
.card_hd_title .material-symbols-outlined{font-size:16px;color:#4f46e5;}
.card_body{padding:20px;}
.btn_primary{padding:9px 20px;background:#4f46e5;color:#fff;border:none;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer;transition:all .2s;display:inline-flex;align-items:center;gap:5px;font-family:inherit;}
.btn_primary:hover{background:#4338ca;}
.btn_primary:disabled{opacity:.5;cursor:not-allowed;}
.btn_neutral{padding:9px 16px;background:#f5f6fa;color:#5c5c7a;border:1px solid #e8eaf0;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer;transition:all .2s;display:inline-flex;align-items:center;gap:5px;font-family:inherit;}
.btn_neutral:hover{background:#e8eaf0;}
.btn_green{padding:9px 16px;background:#059669;color:#fff;border:none;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer;transition:all .2s;display:inline-flex;align-items:center;gap:5px;font-family:inherit;}
.btn_green:hover{background:#047857;}
.btn_refresh{padding:7px 14px;background:#fff;color:#4f46e5;border:1px solid #c7d2fe;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer;transition:all .2s;display:inline-flex;align-items:center;gap:5px;font-family:inherit;}
.btn_refresh:hover{background:#eef2ff;}
.btn_refresh:disabled{opacity:.5;cursor:not-allowed;}
.btn_refresh .material-symbols-outlined{font-size:14px;}
.spin{animation:spin 1s linear infinite;}
@keyframes spin{to{transform:rotate(360deg);}}
.btn_del{padding:5px 10px;background:#fee2e2;color:#dc2626;border:none;border-radius:6px;font-size:11px;font-weight:700;cursor:pointer;}
.btn_edit{padding:5px 10px;background:#4f46e5;color:#fff;border:none;border-radius:6px;font-size:11px;font-weight:700;cursor:pointer;}
.form_group{margin-bottom:14px;}
.form_group label{display:block;font-size:12px;font-weight:700;color:#9999bb;margin-bottom:5px;}
.form_input{width:100%;padding:9px 12px;border:1px solid #e8eaf0;border-radius:8px;font-size:13px;background:#f5f6fa;color:#1a1a2e;font-family:inherit;transition:all .2s;outline:none;}
.form_input:focus{border-color:#4f46e5;background:#fff;box-shadow:0 0 0 3px rgba(79,70,229,.1);}
textarea.form_input{resize:vertical;min-height:72px;line-height:1.6;}
.url-row{display:flex;gap:8px;margin-bottom:20px;}
.schema-badge{display:inline-flex;align-items:center;gap:4px;padding:3px 10px;border-radius:20px;font-size:11px;font-weight:700;}
.schema-badge.has{background:#f0fdf4;color:#059669;border:1px solid #bbf7d0;}
.schema-badge.none{background:#fef2f2;color:#dc2626;border:1px solid #fecaca;}
.schema-badge.loading{background:#eff6ff;color:#3b82f6;border:1px solid #bfdbfe;}
.schema-cell{display:inline-flex;align-items:center;transition:opacity .2s;}
.og-preview{width:60px;height:40px;object-fit:cover;border-radius:5px;border:1px solid #e8eaf0;background:#f5f6fa;}
.eq_table{width:100%;border-collapse:collapse;}
.eq_table thead tr{background:#fafafa;border-bottom:1px solid #e8eaf0;}
.eq_table th{padding:10px 14px;font-size:11px;font-weight:700;color:#9999bb;text-transform:uppercase;letter-spacing:.05em;text-align:left;}
.eq_table td{padding:11px 14px;border-bottom:1px solid #f5f5f5;font-size:13px;vertical-align:middle;}
.eq_table tbody tr:hover{background:#fafbff;}
.eq_table tbody tr:last-child td{border-bottom:none;}
.path-cell{font-family:monospace;font-size:12px;color:#4f46e5;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.title-cell{max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:600;}
.desc-cell{max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#6b7280;font-size:12px;}
.empty_state{text-align:center;padding:48px;color:#9999bb;font-size:14px;}
/* 모달 */
.seo-modal-backdrop{display:none!important;position:fixed!important;inset:0!important;background:rgba(0,0,0,.5)!important;z-index:999999!important;align-items:center!important;justify-content:center!important;}
.seo-modal-backdrop.show{display:flex!important;}
.seo-modal-box{background:#fff!important;border-radius:14px!important;padding:28px!important;width:100%!important;max-width:560px!important;max-height:90vh!important;overflow-y:auto!important;box-shadow:0 20px 60px rgba(0,0,0,.2)!important;position:relative!important;z-index:1000000!important;}
.modal-title{font-size:16px;font-weight:700;margin-bottom:20px;display:flex;align-items:center;justify-content:space-between;}
.modal-footer{display:flex;gap:8px;justify-content:flex-end;margin-top:20px;}
.crawl-status{font-size:12px;color:#4f46e5;margin-top:8px;min-height:18px;}
.og-thumb{width:100%;max-height:120px;object-fit:cover;border-radius:8px;border:1px solid #e8eaf0;margin-top:6px;display:none;}
.toast{position:fixed;top:20px;right:20px;padding:12px 18px;border-radius:10px;font-size:13px;font-weight:600;display:flex;align-items:center;gap:7px;z-index:1000001!important;box-shadow:0 4px 16px rgba(0,0,0,.12);animation:tin .22s ease;}
.toast.ok{background:#f0fdf4;border:1px solid #bbf7d0;color:#059669;}
.toast.error{background:#fef2f2;border:1px solid #fecaca;color:#dc2626;}
@keyframes tin{from{opacity:0;transform:translateX(12px)}to{opacity:1;transform:none}}
.sync-hint{font-size:11px;color:#9999bb;display:inline-flex;align-items:center;gap:4px;}
</style>
</head>
<body>
<div id="admin_wrapper">
    <?php include_once('../aside.php'); ?>
    <main class="content_area">

        <div class="page_header">
            <h2 class="page_title">
                <span class="material-symbols-outlined" style="font-size:22px;color:#4f46e5;">manage_search</span>
                SEO 관리
            </h2>
            <button class="btn_primary" onclick="openModal()">
                <span class="material-symbols-outlined" style="font-size:14px;">add</span>페이지 추가
            </button>
        </div>

        <!-- 안내 -->
        <div style="background:#ede9fe;border-radius:10px;padding:14px 18px;font-size:13px;color:#4f46e5;line-height:1.7;">
            <strong>💡 사용법</strong> — URL을 입력하면 제목·설명·이미지·스키마를 자동으로 가져옵니다.
            저장하면 해당 페이지 접속 시 <code style="background:#c4b5fd;padding:1px 6px;border-radius:4px;">head_sub.php</code>에서 자동으로 적용됩니다.
            <br>스키마 상태는 <strong>페이지를 열 때마다 실시간으로 다시 확인</strong>되어 최신 상태로 표시됩니다.
        </div>

        <!-- 목록 -->
        <div class="card">
            <div class="card_hd">
                <span class="card_hd_title">
                    <span class="material-symbols-outlined">list</span>등록된 페이지
                </span>
                <span style="display:inline-flex;align-items:center;gap:12px;">
                    <span class="sync-hint" id="syncHint"></span>
                    <button class="btn_refresh" id="refreshBtn" onclick="refreshAllSchemas(true)">
                        <span class="material-symbols-outlined" id="refreshIcon">refresh</span>스키마 새로고침
                    </button>
                    <span style="font-size:12px;color:#9999bb;"><?= count($rows) ?>개</span>
                </span>
            </div>
            <?php if (empty($rows)): ?>
            <div class="empty_state">등록된 페이지가 없습니다.<br>우측 상단 [페이지 추가] 버튼을 눌러 시작하세요.</div>
            <?php else: ?>
            <table class="eq_table">
                <thead>
                    <tr>
                        <th width="50">OG</th>
                        <th>경로</th>
                        <th>타이틀</th>
                        <th>디스크립션</th>
                        <th width="140">스키마</th>
                        <th width="95">수정일</th>
                        <th width="90" style="text-align:center;">관리</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($rows as $row): ?>
                <tr>
                    <td>
                        <?php if (!empty($row['og_image'])): ?>
                        <img src="<?= htmlspecialchars($row['og_image']) ?>" class="og-preview" onerror="this.style.display='none'">
                        <?php else: ?>
                        <div style="width:60px;height:40px;background:#f5f6fa;border-radius:5px;border:1px solid #e8eaf0;display:flex;align-items:center;justify-content:center;">
                            <span class="material-symbols-outlined" style="font-size:14px;color:#9999bb;">image_not_supported</span>
                        </div>
                        <?php endif; ?>
                    </td>
                    <td><span class="path-cell" title="<?= htmlspecialchars($row['path']) ?>"><?= htmlspecialchars($row['path']) ?></span></td>
                    <td><span class="title-cell" title="<?= htmlspecialchars($row['seo_title']) ?>"><?= htmlspecialchars($row['seo_title'] ?: '—') ?></span></td>
                    <td><span class="desc-cell" title="<?= htmlspecialchars($row['seo_desc']) ?>"><?= htmlspecialchars($row['seo_desc'] ?: '—') ?></span></td>
                    <td>
                        <span class="schema-cell"
                              data-id="<?= (int)$row['id'] ?>"
                              data-path="<?= htmlspecialchars($row['path'], ENT_QUOTES) ?>">
                        <?php if (!empty($row['schema_type'])): ?>
                            <span class="schema-badge has"><span class="material-symbols-outlined" style="font-size:12px;">check_circle</span><?= htmlspecialchars($row['schema_type']) ?></span>
                        <?php else: ?>
                            <span class="schema-badge none"><span class="material-symbols-outlined" style="font-size:12px;">warning</span>없음</span>
                        <?php endif; ?>
                        </span>
                    </td>
                    <td style="font-size:12px;color:#9999bb;"><?= date('Y.m.d', strtotime($row['updated_at'])) ?></td>
                    <td style="text-align:center;">
                        <div style="display:flex;gap:5px;justify-content:center;">
                            <button class="btn_edit" onclick='openModal(<?= htmlspecialchars(json_encode($row), ENT_QUOTES) ?>)'>
                                <span class="material-symbols-outlined" style="font-size:11px;">edit</span>수정
                            </button>
                            <button class="btn_del" onclick="deletePage(<?= (int)$row['id'] ?>, '<?= htmlspecialchars($row['path']) ?>')">
                                <span class="material-symbols-outlined" style="font-size:11px;">delete</span>
                            </button>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>

    </main>
</div>

<!-- 모달 -->
<div class="seo-modal-backdrop" id="modalBackdrop">
    <div class="seo-modal-box">
        <div class="modal-title">
            <span id="modalTitle">페이지 SEO 추가</span>
            <button onclick="closeModal()" style="background:none;border:none;cursor:pointer;font-size:20px;color:#9999bb;">×</button>
        </div>

        <input type="hidden" id="editId" value="0">

        <!-- URL 크롤링 -->
        <div class="url-row">
            <input type="text" id="crawlUrl" class="form_input" placeholder="https://example.com/sub/ems_scale.php 또는 /sub/ems_scale.php" style="flex:1;">
            <button class="btn_green" id="crawlBtn" onclick="doCrawl()">
                <span class="material-symbols-outlined" style="font-size:14px;">travel_explore</span>자동 가져오기
            </button>
        </div>
        <div class="crawl-status" id="crawlStatus"></div>

        <hr style="border:none;border-top:1px solid #e8eaf0;margin:16px 0;">

        <!-- 경로 -->
        <div class="form_group">
            <label>경로 *</label>
            <input type="text" id="fPath" class="form_input" placeholder="/sub/ems_scale.php">
        </div>

        <!-- 타이틀 -->
        <div class="form_group">
            <label>SEO 타이틀</label>
            <input type="text" id="fTitle" class="form_input" placeholder="EMS 스케일링 | 베스트플란트치과">
            <div id="titleLen" style="font-size:11px;color:#9999bb;margin-top:3px;text-align:right;"></div>
        </div>

        <!-- 디스크립션 -->
        <div class="form_group">
            <label>메타 디스크립션</label>
            <textarea id="fDesc" class="form_input" rows="3" placeholder="EMS 에어플로우로 통증 없이..."></textarea>
            <div id="descLen" style="font-size:11px;color:#9999bb;margin-top:3px;text-align:right;"></div>
        </div>

        <!-- OG 이미지 -->
        <div class="form_group">
            <label>OG 이미지 URL <span style="font-weight:400;color:#9999bb;">— 자동 감지 또는 직접 입력</span></label>
            <input type="text" id="fOgImage" class="form_input" placeholder="https://..." oninput="previewOg(this.value)">
            <img id="ogThumb" class="og-thumb" src="" alt="OG 이미지 미리보기">
        </div>

        <!-- 스키마 감지 결과 -->
        <div class="form_group">
            <label>스키마 감지 결과 <span style="font-weight:400;color:#9999bb;">— 읽기 전용</span></label>
            <div id="schemaResult" style="padding:9px 12px;background:#f5f6fa;border-radius:8px;font-size:13px;color:#6b7280;border:1px solid #e8eaf0;">
                자동 가져오기 후 표시됩니다
            </div>
            <input type="hidden" id="fSchemaType" value="">
        </div>

        <div class="modal-footer">
            <button class="btn_neutral" onclick="closeModal()">취소</button>
            <button class="btn_primary" id="saveBtn" onclick="savePage()">
                <span class="material-symbols-outlined" style="font-size:14px;">save</span>저장
            </button>
        </div>
    </div>
</div>

<script>
var _toastTimer;
function showToast(msg, type) {
    var el = document.createElement('div');
    el.className = 'toast ' + (type || 'ok');
    el.innerHTML = '<span class="material-symbols-outlined" style="font-size:16px;">' + (type === 'error' ? 'error' : 'check_circle') + '</span>' + msg;
    document.body.appendChild(el);
    setTimeout(function() { el.remove(); }, 3000);
}

// ════════════════════════════════════════════════════════
// 공용: JSON-LD에서 @type 재귀 수집 (객체 / 배열 / @graph 모두 대응)
// ════════════════════════════════════════════════════════
function collectSchemaTypes(doc) {
    var out = [];
    function walk(node) {
        if (!node || typeof node !== 'object') return;
        if (Array.isArray(node)) { node.forEach(walk); return; }
        if (node['@type']) {
            if (Array.isArray(node['@type'])) out.push.apply(out, node['@type']);
            else out.push(node['@type']);
        }
        if (node['@graph']) walk(node['@graph']);
    }
    doc.querySelectorAll('script[type="application/ld+json"]').forEach(function(s) {
        try { walk(JSON.parse(s.textContent)); } catch(e) {}
    });
    return [].concat.apply([], out.map(function(t){ return t; })); // flat
}

// 타입 배열 → 정리된 문자열 (중복 제거, @type 단일/배열 모두 평탄화)
function typesToStr(doc) {
    var types = collectSchemaTypes(doc);
    var flat = [];
    types.forEach(function(t) {
        if (Array.isArray(t)) flat = flat.concat(t);
        else flat.push(t);
    });
    return [...new Set(flat)].join(', ');
}

// ── 모달 ─────────────────────────────────────────────────
function openModal(row) {
    document.getElementById('editId').value    = row ? row.id : 0;
    document.getElementById('modalTitle').textContent = row ? '페이지 SEO 수정' : '페이지 SEO 추가';
    document.getElementById('crawlUrl').value  = row ? (location.origin + row.path) : '';
    document.getElementById('fPath').value     = row ? row.path : '';
    document.getElementById('fTitle').value    = row ? row.seo_title : '';
    document.getElementById('fDesc').value     = row ? row.seo_desc : '';
    document.getElementById('fOgImage').value  = row ? row.og_image : '';
    document.getElementById('fSchemaType').value = row ? row.schema_type : '';
    document.getElementById('crawlStatus').textContent = '';

    updateLens();
    previewOg(row ? row.og_image : '');
    renderSchemaResult(row ? row.schema_type : '', row ? !!row.schema_type : null);

    document.getElementById('modalBackdrop').classList.add('show');
}

function closeModal() {
    document.getElementById('modalBackdrop').classList.remove('show');
}

// 모달 밖(backdrop) 클릭으로는 닫지 않음 — 입력 중 실수 방지
// (닫기는 X 버튼 / 취소 버튼으로만)

// ── 글자수 카운터 ─────────────────────────────────────────
function updateLens() {
    var t = document.getElementById('fTitle').value.length;
    var d = document.getElementById('fDesc').value.length;
    document.getElementById('titleLen').textContent = t + '자' + (t > 60 ? ' ⚠️ 60자 초과' : '');
    document.getElementById('descLen').textContent  = d + '자' + (d > 160 ? ' ⚠️ 160자 초과' : '');
}
document.getElementById('fTitle').addEventListener('input', updateLens);
document.getElementById('fDesc').addEventListener('input', updateLens);

// ── OG 이미지 미리보기 ────────────────────────────────────
function previewOg(url) {
    var thumb = document.getElementById('ogThumb');
    if (url && url.startsWith('http')) {
        thumb.src = url;
        thumb.style.display = 'block';
        thumb.onerror = function() { thumb.style.display = 'none'; };
    } else {
        thumb.style.display = 'none';
    }
}

// ── 모달 내 스키마 결과 렌더링 ────────────────────────────
function renderSchemaResult(typeStr, has) {
    var el = document.getElementById('schemaResult');
    if (has === null) {
        el.textContent = '자동 가져오기 후 표시됩니다';
        el.style.color = '#6b7280';
        return;
    }
    if (has && typeStr) {
        el.innerHTML = '<span style="color:#059669;font-weight:700;">✅ 스키마 있음</span> — ' + typeStr;
    } else {
        el.innerHTML = '<span style="color:#dc2626;font-weight:700;">⚠️ 스키마 없음</span> — head_sub.php 공통 스키마만 적용됩니다';
    }
}

// ── 크롤링 (모달: 자동 가져오기) ──────────────────────────
async function doCrawl() {
    var rawUrl = document.getElementById('crawlUrl').value.trim();
    if (!rawUrl) { showToast('URL을 입력해주세요', 'error'); return; }

    var btn    = document.getElementById('crawlBtn');
    var status = document.getElementById('crawlStatus');
    btn.disabled = true;
    status.style.color = '#4f46e5';
    status.textContent = '페이지 불러오는 중...';

    var url = rawUrl;
    if (url.startsWith('/')) url = location.origin + url;

    try {
        var res = await fetch(url, { credentials: 'same-origin' });
        if (!res.ok) {
            var reason = '';
            if (res.status === 403)      reason = '접근이 거부되었습니다 (403 Forbidden)';
            else if (res.status === 404) reason = '페이지를 찾을 수 없습니다 (404 Not Found)';
            else if (res.status === 500) reason = '서버 오류가 발생했습니다 (500 Internal Server Error)';
            else                         reason = 'HTTP 오류: ' + res.status;
            status.textContent = '❌ 실패 — ' + reason;
            status.style.color = '#dc2626';
            btn.disabled = false;
            return;
        }

        var html   = await res.text();
        var parser = new DOMParser();
        var doc    = parser.parseFromString(html, 'text/html');

        // 제목
        var title = '';
        var ogTitle = doc.querySelector('meta[property="og:title"]');
        if (ogTitle) title = ogTitle.getAttribute('content') || '';
        if (!title) title = doc.title || '';
        title = title.trim();

        // 디스크립션
        var desc = '';
        var ogDesc = doc.querySelector('meta[property="og:description"]');
        if (ogDesc) desc = ogDesc.getAttribute('content') || '';
        if (!desc) {
            var metaDesc = doc.querySelector('meta[name="description"]');
            if (metaDesc) desc = metaDesc.getAttribute('content') || '';
        }
        desc = desc.trim();

        // OG 이미지 → 없으면 첫 번째 img
        var ogImg = '';
        var ogImgEl = doc.querySelector('meta[property="og:image"]');
        if (ogImgEl) ogImg = ogImgEl.getAttribute('content') || '';
        if (!ogImg) {
            var firstImg = doc.querySelector('main img, article img, #content img, img');
            if (firstImg) {
                var src = firstImg.getAttribute('src') || '';
                if (src.startsWith('http')) ogImg = src;
                else if (src.startsWith('/')) ogImg = location.origin + src;
            }
        }

        // 스키마 타입 감지 (객체 / 배열 / @graph 모두 대응)
        var schemaStr = typesToStr(doc);

        // path 추출
        var parsed  = new URL(url);
        var path    = parsed.pathname + (parsed.search || '');

        // 입력 필드 채우기
        document.getElementById('fPath').value       = path;
        document.getElementById('fTitle').value      = title;
        document.getElementById('fDesc').value        = desc;
        document.getElementById('fOgImage').value    = ogImg;
        document.getElementById('fSchemaType').value = schemaStr;

        updateLens();
        previewOg(ogImg);
        renderSchemaResult(schemaStr, !!schemaStr);

        status.textContent = '✓ 자동 완성되었습니다. 내용을 확인하고 저장하세요.';
        status.style.color = '#059669';

    } catch(e) {
        var errMsg = e.message || '알 수 없는 오류';
        if (errMsg.includes('Failed to fetch') || errMsg.includes('NetworkError')) {
            errMsg = 'CORS 오류 — 외부 도메인은 직접 입력 후 저장하세요';
        } else if (errMsg.includes('net::ERR')) {
            errMsg = '네트워크 오류 — 도메인 주소를 확인하세요';
        }
        status.textContent = '❌ 오류 — ' + errMsg;
        status.style.color = '#dc2626';
    } finally {
        btn.disabled = false;
    }
}

// ── 저장 ─────────────────────────────────────────────────
async function savePage() {
    var path = document.getElementById('fPath').value.trim();
    if (!path) { showToast('경로를 입력하거나 자동 가져오기를 실행하세요', 'error'); return; }

    var btn = document.getElementById('saveBtn');
    btn.disabled = true;

    try {
        var res = await fetch('?action=save', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                id:          parseInt(document.getElementById('editId').value),
                path:        path,
                seo_title:   document.getElementById('fTitle').value.trim(),
                seo_desc:    document.getElementById('fDesc').value.trim(),
                og_image:    document.getElementById('fOgImage').value.trim(),
                schema_type: document.getElementById('fSchemaType').value.trim(),
            })
        });
        var data = await res.json();
        if (data.ok) {
            showToast('저장되었습니다', 'ok');
            setTimeout(function() { location.reload(); }, 600);
        } else {
            showToast('저장 실패: ' + data.err, 'error');
        }
    } catch(e) {
        showToast('오류: ' + e.message, 'error');
    } finally {
        btn.disabled = false;
    }
}

// ── 삭제 ─────────────────────────────────────────────────
async function deletePage(id, path) {
    if (!confirm('[' + path + ']\n이 페이지 SEO 설정을 삭제하시겠습니까?')) return;
    try {
        var res  = await fetch('?action=delete&id=' + id);
        var data = await res.json();
        if (data.ok) {
            showToast('삭제되었습니다', 'ok');
            setTimeout(function() { location.reload(); }, 500);
        }
    } catch(e) {
        showToast('오류: ' + e.message, 'error');
    }
}

// ════════════════════════════════════════════════════════
// 실시간 스키마 갱신 — 페이지를 열거나 새로고침할 때 자동 실행
// ════════════════════════════════════════════════════════

// 단일 경로 크롤 → 스키마 타입 문자열 반환 (실패 시 null)
async function fetchSchemaFor(path) {
    var url = path;
    if (url.indexOf('http') !== 0) {
        url = location.origin + (url.charAt(0) === '/' ? url : '/' + url);
    }
    try {
        var res = await fetch(url, { credentials: 'same-origin' });
        if (!res.ok) return null;
        var html = await res.text();
        var doc  = new DOMParser().parseFromString(html, 'text/html');
        return typesToStr(doc);
    } catch (e) {
        return null;
    }
}

// 뱃지 DOM 갱신
function renderSchemaBadge(cell, schemaStr) {
    if (schemaStr) {
        cell.innerHTML = '<span class="schema-badge has">'
            + '<span class="material-symbols-outlined" style="font-size:12px;">check_circle</span>'
            + schemaStr + '</span>';
    } else {
        cell.innerHTML = '<span class="schema-badge none">'
            + '<span class="material-symbols-outlined" style="font-size:12px;">warning</span>없음</span>';
    }
}

function setCellLoading(cell) {
    cell.innerHTML = '<span class="schema-badge loading">'
        + '<span class="material-symbols-outlined spin" style="font-size:12px;">progress_activity</span>확인 중</span>';
}

var _refreshing = false;

// 모든 행 백그라운드 재크롤 → 뱃지 갱신 + DB 동기화
async function refreshAllSchemas(manual) {
    if (_refreshing) return;
    _refreshing = true;

    var cells = [...document.querySelectorAll('.schema-cell')];
    var btn   = document.getElementById('refreshBtn');
    var icon  = document.getElementById('refreshIcon');
    var hint  = document.getElementById('syncHint');

    if (btn)  btn.disabled = true;
    if (icon) icon.classList.add('spin');

    var done = 0, changed = 0, total = cells.length;
    if (hint) hint.textContent = total ? ('0 / ' + total + ' 확인 중…') : '';

    // 로딩 표시
    cells.forEach(setCellLoading);

    for (var i = 0; i < cells.length; i++) {
        var cell = cells[i];
        var path = cell.getAttribute('data-path');
        var id   = cell.getAttribute('data-id');
        var prev = cell.getAttribute('data-prev') || '';

        if (!path) { done++; continue; }

        var schemaStr = await fetchSchemaFor(path);
        done++;
        if (hint) hint.textContent = done + ' / ' + total + ' 확인 중…';

        if (schemaStr === null) {
            // 크롤 실패 → 기존 DB값 복원 (data-prev가 없으니 서버 초기 렌더로 되돌릴 수 없어 '없음' 대신 물음표 처리)
            cell.innerHTML = '<span class="schema-badge none" title="페이지를 불러오지 못했습니다">'
                + '<span class="material-symbols-outlined" style="font-size:12px;">help</span>확인 불가</span>';
            continue;
        }

        renderSchemaBadge(cell, schemaStr);

        // DB에 조용히 동기화 (다른 필드는 건드리지 않음)
        try {
            await fetch('?action=save', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    _sync_only: 1,
                    id: parseInt(id),
                    schema_type: schemaStr
                })
            });
            changed++;
        } catch (e) {}
    }

    if (icon) icon.classList.remove('spin');
    if (btn)  btn.disabled = false;
    if (hint) {
        hint.innerHTML = '<span class="material-symbols-outlined" style="font-size:13px;color:#059669;">check_circle</span>'
            + '최신 상태 (' + total + '개 확인됨)';
        setTimeout(function(){ if (hint) hint.textContent = ''; }, 4000);
    }
    if (manual) showToast('스키마 ' + total + '개 새로고침 완료', 'ok');

    _refreshing = false;
}

// 페이지 로드(새로고침)될 때마다 자동 실행
window.addEventListener('DOMContentLoaded', function() {
    refreshAllSchemas(false);
});
</script>
</body>
</html>