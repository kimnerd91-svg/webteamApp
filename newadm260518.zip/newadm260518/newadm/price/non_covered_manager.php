<?php
include_once('../_common.php');
include_once('../_auth_check.php');

$json_dir  = G5_DATA_PATH . '/content';
if (!is_dir($json_dir)) { @mkdir($json_dir, G5_DIR_PERMISSION); @chmod($json_dir, G5_DIR_PERMISSION); }
$json_file = $json_dir . '/non_covered.json';

if (isset($_POST['mode']) && $_POST['mode'] == 'update') {
    $data = json_decode(stripslashes($_POST['items_json']), true);
    if (!is_array($data)) $data = [];
    if (file_put_contents($json_file, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT))) {
        alert_toast('비급여 수가표가 저장되었습니다.', './non_covered_manager.php', 'success');
    } else {
        alert_toast('파일 저장에 실패했습니다. data 폴더의 쓰기 권한을 확인하세요.', 'error');
    }
}

$data_raw = file_exists($json_file) ? json_decode(file_get_contents($json_file), true) : [];
if (!is_array($data_raw)) $data_raw = [];
if (!empty($data_raw) && isset($data_raw[0]['name'])) $data_raw = [['category'=>'기본','items'=>$data_raw,'subcategories'=>[]]];
if (!empty($data_raw) && isset($data_raw[0]['category']) && !array_key_exists('subcategories', $data_raw[0])) {
    $data_raw = array_map(fn($c) => ['category'=>$c['category'],'items'=>[],'subcategories'=>[['subcategory'=>'기본','items'=>$c['items']??[]]]], $data_raw);
}
foreach ($data_raw as &$d) { if (!array_key_exists('items', $d)) $d['items'] = []; }
unset($d);
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>비급여 수가표 관리</title>
<style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Pretendard', 'Apple SD Gothic Neo', sans-serif; background: #f5f6fa; color: #1a1a2e; }
    #admin_wrapper { display: flex; min-height: 100vh; }
    .content_area { flex: 1; padding: 40px; overflow-x: hidden; }

    .page_header { margin-bottom: 28px; }
    .page_title  { font-size: 22px; font-weight: 700; color: #1a1a2e; }
    .page_sub    { font-size: 13px; color: #9999bb; margin-top: 4px; }

    .card { background: #fff; border-radius: 12px; box-shadow: 0 2px 12px rgba(0,0,0,0.06); border: 1px solid #e8eaf0; padding: 24px; margin-bottom: 20px; }
    .card_hd { display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px; }
    .card_title  { font-size: 15px; font-weight: 700; color: #1a1a2e; }

    .btn_major_add { padding: 9px 18px; background: #4f46e5; color: #fff; border: none; border-radius: 8px; font-size: 13px; font-weight: 700; cursor: pointer; transition: all 0.2s; box-shadow: 0 4px 12px rgba(79,70,229,0.2); }
    .btn_major_add:hover { background: #4338ca; }

    .table_wrap { overflow-x: auto; border: 1px solid #e8eaf0; border-radius: 10px; }
    #priceTable { width: 100%; border-collapse: collapse; min-width: 600px; }
    #priceTable th { background: #f5f6fa; padding: 12px 14px; font-size: 12px; font-weight: 700; color: #9999bb; text-align: center; border-bottom: 2px solid #e8eaf0; }
    #priceTable td { border: 1px solid #f5f6fa; vertical-align: middle; }

    .td-major { background: #ede9fe; font-weight: 800; font-size: 13px; text-align: center; padding: 10px 8px; min-width: 90px; color: #4f46e5; }
    .td-minor { background: #f5f3ff; font-weight: 700; font-size: 12px; text-align: center; padding: 10px 8px; min-width: 90px; color: #7c3aed; }
    .td-item  { padding: 8px 10px; }
    .td-action { background: #fafafa; padding: 7px 10px; }
    .td-center { text-align: center; }

    .inline-input { border: none; background: transparent; font-size: inherit; font-weight: inherit; color: inherit; text-align: center; width: 100%; padding: 2px 4px; border-bottom: 2px dashed #c4b5fd; outline: none; }
    .inline-input:focus { border-bottom-color: #4f46e5; background: #fff; border-radius: 4px; }

    .u-input { border: 1px solid #e8eaf0; border-radius: 7px; padding: 6px 10px; font-size: 13px; background: #f5f6fa; width: 100%; transition: all 0.2s; }
    .u-input:focus { outline: none; border-color: #4f46e5; background: #fff; }

    .btn-add-inline { display: inline-flex; align-items: center; gap: 4px; border: 1px dashed #c4b5fd; background: transparent; color: #7c3aed; font-size: 12px; font-weight: 600; padding: 4px 10px; border-radius: 6px; cursor: pointer; white-space: nowrap; transition: all 0.2s; }
    .btn-add-inline:hover { border-color: #4f46e5; color: #4f46e5; background: #ede9fe; }
    .btn-add-inline.sub { border-color: #d1d5e0; color: #5c5c7a; }
    .btn-add-inline.sub:hover { border-color: #9999bb; background: #f5f6fa; color: #1a1a2e; }

    .btn-del { display: inline-flex; align-items: center; border: 1px solid #fca5a5; background: #fff; color: #ef4444; font-size: 12px; font-weight: 600; padding: 4px 10px; border-radius: 6px; cursor: pointer; white-space: nowrap; transition: all 0.2s; }
    .btn-del:hover { background: #ef4444; color: #fff; }

    .save_bar { display: flex; justify-content: flex-end; }
    .btn_save { padding: 13px 40px; background: #4f46e5; color: #fff; border: none; border-radius: 9px; font-size: 15px; font-weight: 700; cursor: pointer; box-shadow: 0 4px 16px rgba(79,70,229,0.25); transition: all 0.2s; }
    .btn_save:hover { background: #4338ca; transform: translateY(-1px); }
</style>
</head>
<body>
<div id="admin_wrapper">
    <?php include_once('../aside.php'); ?>

    <main class="content_area">
        <div class="page_header">
            <h2 class="page_title">비급여 수가표 관리</h2>
            <p class="page_sub">대분류 필수 / 소분류는 선택 사항입니다.</p>
        </div>

        <form method="post" id="priceForm" onsubmit="return preSave()">
            <input type="hidden" name="mode" value="update">
            <input type="hidden" name="items_json" id="items_json">

            <div class="card">
                <div class="card_hd">
                    <p class="card_title">수가표 항목 관리</p>
                    <button type="button" onclick="addMajor()" class="btn_major_add">+ 대분류 추가</button>
                </div>
                <div class="table_wrap">
                    <table id="priceTable">
                        <thead>
                            <tr>
                                <th style="width:12%;">대분류</th>
                                <th style="width:12%;">소분류</th>
                                <th style="width:28%;">항목명</th>
                                <th style="width:17%;">가격 (원)</th>
                                <th style="width:19%;">비고</th>
                                <th style="width:12%;">삭제</th>
                            </tr>
                        </thead>
                        <tbody id="priceBody"></tbody>
                    </table>
                </div>
            </div>

            <div class="save_bar">
                <button type="submit" class="btn_save">수가표 저장</button>
            </div>
        </form>
    </main>
</div>

<script>
let D = <?= json_encode($data_raw) ?>;

function render() {
    const tbody = document.getElementById('priceBody');
    tbody.innerHTML = '';
    if (!D.length) {
        const tr=mktr(); const td=mktd(); td.colSpan=6; td.style.cssText='text-align:center;padding:48px;color:#9999bb;font-size:13px;';
        td.textContent='우측 상단 "대분류 추가" 버튼으로 시작하세요.'; tr.appendChild(td); tbody.appendChild(tr); return;
    }
    D.forEach((major, mi) => {
        const subs=major.subcategories||[]; const hasSub=subs.length>0; const directItems=major.items||[];
        let majorSpan;
        if (!hasSub) majorSpan=Math.max(directItems.length,1)+1;
        else majorSpan=subs.reduce((acc,s)=>acc+Math.max((s.items||[]).length,1)+1,0)+1;
        let firstMajor=true;
        function getMajorTd() {
            if (!firstMajor) return null; firstMajor=false;
            const td=mktd('td-major'); td.rowSpan=majorSpan;
            td.appendChild(mkInlineInput(major.category,'대분류명',`D[${mi}].category=this.value`)); return td;
        }
        if (!hasSub) {
            if (!directItems.length) {
                const tr=mktr(); appendIf(tr,getMajorTd());
                const tdE=mktd('td-item'); tdE.colSpan=4; tdE.style.cssText='text-align:center;color:#9999bb;font-size:12px;'; tdE.textContent='항목을 추가하세요.';
                tr.appendChild(tdE); tr.appendChild(mktd('td-item')); tbody.appendChild(tr);
            } else {
                directItems.forEach((item,ii)=>{
                    const tr=mktr(); appendIf(tr,getMajorTd());
                    const tdN=mktd('td-item'); tdN.colSpan=2; tdN.appendChild(mkFieldInput(item.name,'예: 임플란트',`D[${mi}].items[${ii}].name=this.value`)); tr.appendChild(tdN);
                    const tdP=mktd('td-item'); tdP.appendChild(mkFieldInput(item.price,'예: 1,500,000',`D[${mi}].items[${ii}].price=this.value`)); tr.appendChild(tdP);
                    const tdNo=mktd('td-item'); tdNo.appendChild(mkFieldInput(item.note,'비고',`D[${mi}].items[${ii}].note=this.value`)); tr.appendChild(tdNo);
                    const tdD=mktd('td-item td-center'); tdD.appendChild(mkDelBtn(`delDirectItem(${mi},${ii})`,'삭제')); tr.appendChild(tdD);
                    tbody.appendChild(tr);
                });
            }
            const trA=mktr(); const tdA=mktd('td-action'); tdA.colSpan=4;
            tdA.appendChild(mkAddBtn(`addDirectItem(${mi})`,'항목 추가'));
            const btnS=mkBtn('btn-add-inline sub',`addFirstSub(${mi})`,'소분류 추가'); btnS.style.marginLeft='8px'; tdA.appendChild(btnS);
            trA.appendChild(tdA);
            const tdDA=mktd('td-action td-center'); tdDA.appendChild(mkDelBtn(`delMajor(${mi})`,'대분류 삭제')); trA.appendChild(tdDA);
            tbody.appendChild(trA);
        } else {
            subs.forEach((sub,si)=>{
                const items=sub.items||[]; const subSpan=Math.max(items.length,1)+1; let firstSub=true;
                function getSubTd() {
                    if (!firstSub) return null; firstSub=false;
                    const td=mktd('td-minor'); td.rowSpan=subSpan;
                    td.appendChild(mkInlineInput(sub.subcategory,'소분류명',`D[${mi}].subcategories[${si}].subcategory=this.value`)); return td;
                }
                if (!items.length) {
                    const tr=mktr(); appendIf(tr,getMajorTd()); appendIf(tr,getSubTd());
                    const tdE=mktd('td-item'); tdE.colSpan=3; tdE.style.cssText='text-align:center;color:#9999bb;font-size:12px;'; tdE.textContent='항목을 추가하세요.';
                    tr.appendChild(tdE);
                    const tdD=mktd('td-item td-center'); tdD.appendChild(mkDelBtn(`delSub(${mi},${si})`,'삭제')); tr.appendChild(tdD);
                    tbody.appendChild(tr);
                } else {
                    items.forEach((item,ii)=>{
                        const tr=mktr(); appendIf(tr,getMajorTd()); appendIf(tr,getSubTd());
                        const tdN=mktd('td-item'); tdN.appendChild(mkFieldInput(item.name,'예: 임플란트',`D[${mi}].subcategories[${si}].items[${ii}].name=this.value`)); tr.appendChild(tdN);
                        const tdP=mktd('td-item'); tdP.appendChild(mkFieldInput(item.price,'예: 1,500,000',`D[${mi}].subcategories[${si}].items[${ii}].price=this.value`)); tr.appendChild(tdP);
                        const tdNo=mktd('td-item'); tdNo.appendChild(mkFieldInput(item.note,'비고',`D[${mi}].subcategories[${si}].items[${ii}].note=this.value`)); tr.appendChild(tdNo);
                        const tdD=mktd('td-item td-center'); tdD.appendChild(mkDelBtn(`delItem(${mi},${si},${ii})`,'삭제')); tr.appendChild(tdD);
                        tbody.appendChild(tr);
                    });
                }
                const trS=mktr(); appendIf(trS,getMajorTd());
                const tdS=mktd('td-action'); tdS.colSpan=4; tdS.appendChild(mkAddBtn(`addItem(${mi},${si})`,'항목 추가'));
                const dB=mkDelBtn(`delSub(${mi},${si})`,'소분류 삭제'); dB.style.marginLeft='8px'; tdS.appendChild(dB);
                trS.appendChild(tdS); trS.appendChild(mktd('td-action')); tbody.appendChild(trS);
            });
            const trA=mktr(); const tdA=mktd('td-action'); tdA.colSpan=5; tdA.appendChild(mkAddBtn(`addSub(${mi})`,'소분류 추가')); trA.appendChild(tdA);
            const tdD=mktd('td-action td-center'); tdD.appendChild(mkDelBtn(`delMajor(${mi})`,'대분류 삭제')); trA.appendChild(tdD);
            tbody.appendChild(trA);
        }
    });
}

function mktr(cls) { const t=document.createElement('tr'); if(cls) t.className=cls; return t; }
function mktd(cls) { const t=document.createElement('td'); if(cls) t.className=cls; return t; }
function appendIf(p,c) { if(c) p.appendChild(c); }
function mkInlineInput(val,ph,onchange) { const i=document.createElement('input'); i.className='inline-input'; i.value=val||''; i.placeholder=ph; i.setAttribute('onchange',onchange); return i; }
function mkFieldInput(val,ph,onchange) { const i=document.createElement('input'); i.className='u-input'; i.value=val||''; i.placeholder=ph; i.setAttribute('onchange',onchange); return i; }
function mkBtn(cls,onclick,html) { const b=document.createElement('button'); b.type='button'; b.className=cls; b.setAttribute('onclick',onclick); b.innerHTML=html; return b; }
function mkAddBtn(onclick,label) { return mkBtn('btn-add-inline',onclick,`<span style="font-size:13px;font-weight:700;">+</span> ${label}`); }
function mkDelBtn(onclick,label) { return mkBtn('btn-del',onclick,label); }

function addMajor() { D.push({category:'',items:[],subcategories:[]}); render(); }
function delMajor(mi) { if(confirm(`"${D[mi].category||'대분류'}" 전체를 삭제?`)) { D.splice(mi,1); render(); } }
function addDirectItem(mi) { D[mi].items.push({name:'',price:'',note:''}); render(); }
function delDirectItem(mi,ii) { if(confirm('항목을 삭제?')) { D[mi].items.splice(ii,1); render(); } }
function addFirstSub(mi) { const e=D[mi].items||[]; D[mi].subcategories.push({subcategory:'',items:e}); D[mi].items=[]; render(); }
function addSub(mi) { D[mi].subcategories.push({subcategory:'',items:[]}); render(); }
function delSub(mi,si) { if(confirm(`"${D[mi].subcategories[si].subcategory||'소분류'}"를 삭제?`)) { D[mi].subcategories.splice(si,1); if(!D[mi].subcategories.length) D[mi].items=[]; render(); } }
function addItem(mi,si) { D[mi].subcategories[si].items.push({name:'',price:'',note:''}); render(); }
function delItem(mi,si,ii) { if(confirm('항목을 삭제?')) { D[mi].subcategories[si].items.splice(ii,1); render(); } }
function preSave() { document.getElementById('items_json').value=JSON.stringify(D); return true; }

window.onload = render;
</script>
</body>
</html>