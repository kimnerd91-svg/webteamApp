<?php
if (!defined('_GNUBOARD_')) exit;

// 데이터 로드
$conf = sql_fetch("SELECT * FROM dm_config WHERE cf_id = 1");
$non_covered_file = G5_DATA_PATH . '/content/non_covered.json';
$non_covered = [];

if (file_exists($non_covered_file)) {
    $decoded_data = json_decode(file_get_contents($non_covered_file), true);
    if (is_array($decoded_data)) {
        $non_covered = $decoded_data;
    }
}
?>

<!-- 푸터 -->
<div class="w-100">

    <div id="daumRoughmapContainer1774424544716" class="root_daum_roughmap root_daum_roughmap_landing"></div>

    <script charset="UTF-8" class="daum_roughmap_loader_script" src="https://ssl.daumcdn.net/dmaps/map_js_init/roughmapLoader.js"></script>

    <script charset="UTF-8">
        new daum.roughmap.Lander({
            "timestamp": "1774424544716",
            "key": "jx8d6i82wux",
            "mapWidth": "100%",
            "mapHeight": "360"
        }).render();
    </script>
</div>
<footer
    class="footer u-bg-dark u-pretendard u-px-0-sm u-pt-60 u-pb-60 u-pb-120-sm"
    id="footer02">


    <!-- Copyright -->
    <div
        class="u-fluid u-fluid-xl-sm ">
        <div class="d-flex flex-column-reverse flex-lg-row justify-content-between align-items-start align-items-lg-center">
            <div>
                <p class="u-txt-gray-700 c-fs-18 fw-400 u-lh-16 u-ls-10">
                    <?= htmlspecialchars($conf['cf_company_name']) ?> | <?= htmlspecialchars($conf['cf_ceo_name']) ?> | 사업자등록번호 <?= htmlspecialchars($conf['cf_business_number']) ?> | 대표전화 <?= htmlspecialchars($conf['cf_tel']) ?>
                </p>
                <p class="u-txt-gray-700 c-fs-18 fw-400 u-lh-16 u-ls-10">Copyright 2026. SEOUL K PLANT DENTAL CLINIC All rights reserved.</p>
                <div
                    class="d-flex justify-content-start align-items-center u-gap-16 u-mt-30 u-txt-gray-700 fw-400 c-fs-14">
                    <a
                        href="#"
                        class="u-txt-gray-700 fw-400 c-fs-14"
                        data-bs-toggle="modal"
                        data-bs-target="#modalPrivacy">개인정보처리방침</a>
                    <!-- |
                    <a
                        href="#"
                        class="u-txt-gray-700 fw-400 c-fs-14"
                        data-bs-toggle="modal"
                        data-bs-target="#modalProvision">이용약관</a> -->

                    <a href="#" class="u-txt-gray-700 fw-400 c-fs-14" data-bs-toggle="modal" data-bs-target="#modalNonCovered">비급여 수가표</a>
                </div>
            </div>
            <div class="u-mb-40-sm">
                <img class="w-50-sm" src="/images/logogray.svg" alt="">
            </div>
        </div>

    </div>
</footer>



<!-- 이용약관 모달 -->
<div class="modal fade" id="modalProvision" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content rounded-24 border-0">
            <div class="modal-header u-p-24 u-bd-b-1">
                <h5 class="modal-title fw-700 t-fs-20">이용약관</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body u-p-32 c-fs-15 u-lh-160 u-txt-body" style="max-height: 60vh; overflow-y: auto;">
                <?php
                echo isset($conf['cf_terms']) && $conf['cf_terms']
                    ? nl2br($conf['cf_terms'])
                    : "등록된 이용약관이 없습니다.";
                ?>
            </div>
        </div>
    </div>
</div>


<!-- 개인정보처리방침 모달 -->
<div class="modal fade" id="modalPrivacy" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content rounded-24 border-0">
            <div class="modal-header u-p-24 u-bd-b-1">
                <h5 class="modal-title fw-700 t-fs-20 u-txt-main">개인정보처리방침</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body u-p-32 c-fs-15 u-lh-160 u-txt-body" style="max-height: 60vh; overflow-y: auto;">
                <?php
                echo isset($conf['cf_privacy_policy']) && $conf['cf_privacy_policy']
                    ? nl2br($conf['cf_privacy_policy'])
                    : "등록된 개인정보처리방침이 없습니다.";
                ?>
            </div>
        </div>
    </div>
</div>

<!-- 비급여 수가표 모달 -->
<div class="modal fade" id="modalNonCovered" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content rounded-16 u-bd-n shadow-soft">
            <div class="modal-header u-bg-soft">
                <h5 class="modal-title fw-700">비급여 수가표</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body u-p-20">
                <table class="u-table" style="width:100%;">
                    <thead class="u-bg-gray-100 u-txt-title">
                        <tr>
                            <th class="u-p-16" style="width:14%;">대분류</th>
                            <th class="u-p-16" style="width:14%;"></th>
                            <th class="u-p-16" style="width:30%;">항목명</th>
                            <th class="u-p-16" style="width:21%;">가격</th>
                            <th class="u-p-16" style="width:21%;">비고</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($non_covered)): ?>
                            <tr>
                                <td colspan="5" class="u-p-40 u-txt-center u-txt-muted">등록된 항목이 없습니다.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($non_covered as $major): ?>
                                <?php
                                $subs      = $major['subcategories'] ?? [];
                                $hasSub    = !empty($subs);
                                $dirItems  = $major['items'] ?? [];

                                // 대분류 rowspan 계산
                                if (!$hasSub) {
                                    $majorSpan = max(count($dirItems), 1);
                                } else {
                                    $majorSpan = 0;
                                    foreach ($subs as $s) $majorSpan += max(count($s['items'] ?? []), 1);
                                    $majorSpan = max($majorSpan, 1);
                                }

                                $firstMajor = true;
                                ?>

                                <?php if (!$hasSub): ?>
                                    <?php /* ── 소분류 없음: 항목명이 소분류+항목명 열(colspan=2) 차지 ── */ ?>
                                    <?php if (empty($dirItems)): ?>
                                        <tr class="u-bd-b-1 u-bc-gray-100">
                                            <td class="u-p-16 fw-700 u-txt-center u-bg-gray-50 bigcate"
                                                rowspan="1"
                                                style="border-right:1px solid #e9ecef;vertical-align:middle;">
                                                <?= htmlspecialchars($major['category']) ?>
                                            </td>
                                            <td colspan="4" class="u-p-16 u-txt-center u-txt-muted">-</td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($dirItems as $item): ?>
                                            <tr class="u-bd-b-1 u-bc-gray-100">
                                                <?php if ($firstMajor): $firstMajor = false; ?>
                                                    <td class="u-p-16 fw-700 u-txt-center u-bg-gray-50 bigcate"
                                                        rowspan="<?= $majorSpan ?>"
                                                        style="border-right:1px solid #e9ecef;vertical-align:middle;">
                                                        <?= htmlspecialchars($major['category']) ?>
                                                    </td>
                                                <?php endif; ?>
                                                <?php /* 소분류 열 없음 → 항목명 colspan=2 */ ?>
                                                <td class="u-p-16 u-txt-center" colspan="2">
                                                    <?= htmlspecialchars($item['name']) ?>
                                                </td>
                                                <td class="u-p-16 u-txt-main u-txt-center">
                                                    <?= htmlspecialchars($item['price']) ?>원
                                                </td>
                                                <td class="u-p-16 u-txt-gray-500 u-txt-center">
                                                    <?= htmlspecialchars($item['note']) ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>

                                <?php else: ?>
                                    <?php /* ── 소분류 있음: 3단 정상 출력 ── */ ?>
                                    <?php foreach ($subs as $sub): ?>
                                        <?php
                                        $items    = $sub['items'] ?? [];
                                        $subSpan  = max(count($items), 1);
                                        $firstSub = true;
                                        ?>
                                        <?php if (empty($items)): ?>
                                            <tr class="u-bd-b-1 u-bc-gray-100">
                                                <?php if ($firstMajor): $firstMajor = false; ?>
                                                    <td class="u-p-16 fw-700 u-txt-center u-bg-gray-50 bigcate"
                                                        rowspan="<?= $majorSpan ?>"
                                                        style="border-right:1px solid #e9ecef;vertical-align:middle;">
                                                        <?= htmlspecialchars($major['category']) ?>
                                                    </td>
                                                <?php endif; ?>
                                                <td class="u-p-16 fw-600 u-txt-center u-bg-soft smallcate"
                                                    rowspan="1"
                                                    style="border-right:1px solid #e9ecef;vertical-align:middle;">
                                                    <?= htmlspecialchars($sub['subcategory']) ?>
                                                </td>
                                                <td colspan="3" class="u-p-16 u-txt-center u-txt-muted">-</td>
                                            </tr>
                                        <?php else: ?>
                                            <?php foreach ($items as $item): ?>
                                                <tr class="u-bd-b-1 u-bc-gray-100">
                                                    <?php if ($firstMajor): $firstMajor = false; ?>
                                                        <td class="u-p-16 fw-700 u-txt-center u-bg-gray-50 bigcate"
                                                            rowspan="<?= $majorSpan ?>"
                                                            style="border-right:1px solid #e9ecef;vertical-align:middle;">
                                                            <?= htmlspecialchars($major['category']) ?>
                                                        </td>
                                                    <?php endif; ?>
                                                    <?php if ($firstSub): $firstSub = false; ?>
                                                        <td class="u-p-16 fw-600 u-txt-center u-bg-soft smallcate"
                                                            rowspan="<?= $subSpan ?>"
                                                            style="border-right:1px solid #e9ecef;vertical-align:middle;">
                                                            <?= htmlspecialchars($sub['subcategory']) ?>
                                                        </td>
                                                    <?php endif; ?>
                                                    <td class="u-p-16 u-txt-center">
                                                        <?= htmlspecialchars($item['name']) ?>
                                                    </td>
                                                    <td class="u-p-16 u-txt-main u-txt-center">
                                                        <?= htmlspecialchars($item['price']) ?>원
                                                    </td>
                                                    <td class="u-p-16 u-txt-gray-500 u-txt-center">
                                                        <?= htmlspecialchars($item['note']) ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                <?php endif; ?>

                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div id="quick_menu_pill" class="u-pretendard d-none">
    <div class="quick_menu_pill-container">
        <div class="quick_menu_pill-items active">
            <ul class="u-gap-8 d-flex flex-column">
                <li>
                    <?php if (!empty($conf['cf_naver_booking'])): ?>
                        <a href="<?= htmlspecialchars($conf['cf_naver_booking']) ?>" target="_blank" class="qm-bar-fixed-item" style="background: #3E9F46;">
                            <img src="/images/q01.svg" alt="" />
                            <div class="qm-bar-fixed-item-text">
                                <p class="fw-500 c-fs-16 u-lh-14 u-ls-10 u-txt-white">네이버 예약</p>
                            </div>
                        </a>
                    <?php endif; ?>

                </li>
                <li>
                    <?php if (!empty($conf['cf_kakao'])): ?>
                        <a href="<?= htmlspecialchars($conf['cf_kakao']) ?>" target="_blank" class="qm-bar-fixed-item" style="background: #E4CF33">
                            <img src="/images/q02.svg" alt="" />
                            <div class="qm-bar-fixed-item-text">
                                <p class="fw-500 c-fs-16 u-lh-14 u-ls-10" style="color: #371c1c">카톡 상담</p>
                            </div>
                        </a>
                    <?php endif; ?>
                </li>
                <li>
                    <?php if (!empty($conf['cf_blog'])): ?>
                        <a href="<?= htmlspecialchars($conf['cf_blog']) ?>" target="_blank" class="qm-bar-fixed-item u-bg-white" style="border-color: #3e9f46">
                            <img src="/images/q03.svg" alt="" />
                            <div class="qm-bar-fixed-item-text">
                                <p class="fw-500 c-fs-16 u-lh-14 u-ls-10 u-txt-dark">블로그</p>
                            </div>
                        </a>
                    <?php endif; ?>
                </li>
                <li>
                    <?php if (!empty($conf['cf_instagram'])): ?>
                        <a href="<?= htmlspecialchars($conf['cf_instagram']) ?>" target="_blank" class="qm-bar-fixed-item" style="
background: linear-gradient(94deg, #5B4593 -8.75%, #D83D53 53.89%, #E2B55A 106.19%), var(--New-group-SUB, #A9957E);">
                            <img src="/images/q04.svg" alt="" />
                            <div class="qm-bar-fixed-item-text">
                                <p class="fw-500 c-fs-16 u-lh-14 u-ls-10 u-txt-white">인스타그램</p>
                            </div>
                        </a>
                    <?php endif; ?>
                </li>
                <!-- <li>
                    <a href="/" target="_blank" class="qm-bar-fixed-item">
                        <img src="/images/q05.svg" alt="" />
                        <div class="qm-bar-fixed-item-text">
                            <p class="fw-500 c-fs-16 u-lh-14 u-ls-10">유튜브</p>
                        </div>
                    </a>
                </li> -->
                <li>
                    <a href="/sub/info.php" target="_blank" class="qm-bar-fixed-item u-bg-sub">
                        <img src="/images/q05.svg" alt="" />
                        <div class="qm-bar-fixed-item-text">
                            <p class="fw-500 c-fs-16 u-lh-14 u-ls-10 u-txt-white">오시는 길</p>
                        </div>
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <button
        type="button"
        id="qm_pill_toggle"
        class="qm-pill-toggle u-bg-sub u-mt-16-sm">
        <img class="w-50-sm" src="/images/quickLogo.svg" alt="" />
    </button>

    <button type="button" class="u-mt-8 u-mt-16-sm u-txt-gray-400  u-op-5 u-bd-n" id="scrollTop" style="background: rgba(68, 44, 24, 0.50);">
        <span class="material-symbols-outlined c-fs-32 c-fs-44-sm u-txt-white">
            North
        </span>
    </button>

</div>
<div id="quick_menu_mobile" class="u-bg-white d-block d-lg-none position-fixed w-100 u-pretendard" style="bottom: 0; left: 0; z-index: 3">
    <ul class="d-flex">
        <li class="flex-1 d-flex align-items-center justify-content-center">
            <a href="tel: 0322012090" class="w-100 h-100 d-flex flex-column justify-content-center align-items-center">
                <img class="w-max u-mb-4-sm" src="/images/tel.svg" alt="">
                <p class="c-fs-14-sm fw-500 u-lh-15 u-txt-dark text-center">
                    전화문의
                </p>
            </a>
        </li>
        <li class="flex-1 u-py-16-sm">
            <?php if (!empty($conf['cf_naver_booking'])): ?>
                <a href="<?= htmlspecialchars($conf['cf_naver_booking']) ?>" target="_blank" class="w-100 h-100 d-flex flex-column justify-content-center align-items-center">
                    <img class="w-max u-mb-4-sm" src="/images/naverMo.svg" alt="" />
                    <div class="qm-bar-fixed-item-text">
                        <p class="c-fs-14-sm fw-500 u-lh-15 u-txt-dark text-center">예약</p>
                    </div>
                </a>
            <?php endif; ?>
        </li>
        <li class="flex-1 u-py-16-sm">
            <?php if (!empty($conf['cf_kakao'])): ?>
                <a href="<?= htmlspecialchars($conf['cf_kakao']) ?>" target="_blank" class="w-100 h-100 d-flex flex-column justify-content-center align-items-center">
                    <img class="w-max u-mb-4-sm" src="/images/kakaomo.svg" alt="" />
                    <div class="qm-bar-fixed-item-text">
                        <p class="c-fs-14-sm fw-500 u-lh-15 u-txt-dark text-center">카카오톡</p>
                    </div>
                </a>
            <?php endif; ?>
        </li>
        <li class="flex-1 u-py-16-sm">
            <?php if (!empty($conf['cf_blog'])): ?>
                <a href="<?= htmlspecialchars($conf['cf_blog']) ?>" target="_blank" class="w-100 h-100 d-flex flex-column justify-content-center align-items-center">
                    <img class="w-max u-mb-4-sm" src="/images/blogmo.svg" alt="" />
                    <div class="qm-bar-fixed-item-text">
                        <p class="c-fs-14-sm fw-500 u-lh-15 u-txt-dark text-center">블로그</p>
                    </div>
                </a>
            <?php endif; ?>
        </li>
        <li class="flex-1 u-py-16-sm">
            <button type="button" class="w-100 h-100 d-flex flex-column justify-content-center align-items-center u-bd-n u-bg-transparent" id="scrollTop2">
                <span class="material-symbols-outlined c-fs-32 c-fs-44-sm u-mb-4-sm u-txt-dark">
                    North
                </span>
                <p class="c-fs-14-sm fw-500 u-lh-15 u-txt-dark text-center">TOP</p>
            </button>
        </li>
    </ul>
</div>


<script>
    const scrollTopBtn = document.getElementById('scrollTop');

    window.addEventListener('scroll', function() {
        scrollTopBtn.style.opacity = window.scrollY > 300 ? '1' : '0';
        scrollTopBtn.style.pointerEvents = window.scrollY > 300 ? 'auto' : 'none';
    });

    scrollTopBtn.addEventListener('click', function() {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
</script>

<script>
    const scrollTopBtn2 = document.getElementById('scrollTop2');

    window.addEventListener('scroll', function() {
        scrollTopBtn2.style.opacity = window.scrollY > 300 ? '1' : '0';
        scrollTopBtn2.style.pointerEvents = window.scrollY > 300 ? 'auto' : 'none';
    });

    scrollTopBtn2.addEventListener('click', function() {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
</script>


<!-- ========================================== -->
<!-- Bootstrap 5 JS (모달 작동을 위해 필수!) -->
<!-- ========================================== -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>


<!-- 다음 지도 스크립트 -->
<script charset="UTF-8" src="https://ssl.daumcdn.net/dmaps/map_js_init/roughmapLoader.js"></script>

<script>
    // ==========================================
    // 토스트 메시지 표시 함수
    // ==========================================
    window.showToast = function(message, type = 'default') {
        const existingToast = document.querySelector('.toast-message');
        if (existingToast) existingToast.remove();

        const toast = document.createElement('div');
        toast.className = 'toast-message';
        if (type === 'success') toast.classList.add('success');
        if (type === 'error') toast.classList.add('error');
        if (type === 'warning') toast.classList.add('warning');
        toast.textContent = message;

        document.body.appendChild(toast);
        setTimeout(() => toast.classList.add('show'), 10);
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 2500);
    };
</script>

<script>
    let scrollTracked = {
        '25': false,
        '50': false,
        '75': false,
        '100': false
    };

    window.addEventListener('scroll', function() {
        const scrollHeight = document.documentElement.scrollHeight - window.innerHeight;
        const scrolled = (window.scrollY / scrollHeight) * 100;

        if (scrolled >= 25 && !scrollTracked['25']) {
            gtag('event', 'scroll_depth', {
                'depth': '25%',
                'page_location': window.location.href
            });
            scrollTracked['25'] = true;
        }

        if (scrolled >= 50 && !scrollTracked['50']) {
            gtag('event', 'scroll_depth', {
                'depth': '50%',
                'page_location': window.location.href
            });
            scrollTracked['50'] = true;
        }

        if (scrolled >= 75 && !scrollTracked['75']) {
            gtag('event', 'scroll_depth', {
                'depth': '75%',
                'page_location': window.location.href
            });
            scrollTracked['75'] = true;
        }

        if (scrolled >= 99 && !scrollTracked['100']) {
            gtag('event', 'scroll_depth', {
                'depth': '100%',
                'page_location': window.location.href
            });
            scrollTracked['100'] = true;
        }
    });
</script>
<script>
    AOS.init();
    const swiperMain = new Swiper("#swiper-main", {
        slidesPerView: 1,
        spaceBetween: 0,
        effect: '<?= htmlspecialchars($banner_settings['effect']) ?>',
        loop: <?= $banner_settings['loop'] ? 'true' : 'false' ?>,
        speed: <?= (int)$banner_settings['speed'] ?>,
        autoplay: {
            delay: <?= (int)$banner_settings['autoplay_delay'] ?>,
            disableOnInteraction: false,
        },
        pagination: {
            el: ".swiper-pagination",
            clickable: true,
        },
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        },
        on: {
            slideChange: function() {
                AOS.refresh();
            },
            // ↓ Swiper 렌더 완료 후 배너 적용
            afterInit: function() {
                applyBanner();
            },
        },
    });

    // ==========================================
    // 배너 웹/모바일 이미지 & 텍스트 전환
    // ==========================================
    function applyBanner() {
        var isMob = window.innerWidth <= 992;
        document.querySelectorAll('#sect01 .swiper-slide[data-bg-web]').forEach(function(slide) {
            // 이미지 교체
            var web = slide.dataset.bgWeb;
            var mob = slide.dataset.bgMobile;
            slide.style.backgroundImage = 'url(' + (isMob && mob ? mob : web) + ')';

            // 텍스트 블록 교체
            var wEl = slide.querySelector('.slide-content-web');
            var mEl = slide.querySelector('.slide-content-mob');
            var hasMobText = mEl && mEl.children.length > 0;

            if (isMob && hasMobText) {
                if (wEl) wEl.style.display = 'none';
                if (mEl) mEl.style.display = 'block';
                slide.className = slide.className.replace(/justify-content-\S+|text-center|text-end/g, '').trim() +
                    ' ' + (slide.dataset.posMob || '');
            } else {
                if (wEl) wEl.style.display = 'block';
                if (mEl) mEl.style.display = 'none';
                slide.className = slide.className.replace(/justify-content-\S+|text-center|text-end/g, '').trim() +
                    ' ' + (slide.dataset.posWeb || '');
            }
        });
    }

    applyBanner();
    window.addEventListener('resize', applyBanner);
</script>

<script>
    // ==========================================
    // 2. 케이스 탭 전환 (tab-btn)
    // ==========================================
    document.addEventListener("DOMContentLoaded", function() {
        const tabButtons = document.querySelectorAll(".tab-btn");
        const tabContents = document.querySelectorAll(".tab-contents");

        tabButtons.forEach((button) => {
            button.addEventListener("click", function() {
                tabButtons.forEach((btn) => btn.classList.remove("active"));
                this.classList.add("active");

                tabContents.forEach((content) => {
                    content.classList.remove("active");
                    content.style.display = "none";
                });

                const tabId = this.getAttribute("data-tab");
                const targetTab = document.getElementById(tabId);
                if (targetTab) {
                    targetTab.classList.add("active");
                    targetTab.style.display = "grid";
                }
            });
        });

        // 초기 상태: 첫 번째 탭만 표시
        tabContents.forEach((content, index) => {
            content.style.display = index === 0 ? "grid" : "none";
        });
    });
</script>

<script>
    // ==========================================
    // 3. 진료 항목 탭 전환 (doc-btn)
    // ==========================================
    document.addEventListener("DOMContentLoaded", function() {
        const tabButtons = document.querySelectorAll(".doc-btn");

        tabButtons.forEach((button) => {
            button.addEventListener("click", function() {
                const targetTab = this.getAttribute("data-tab");

                document.querySelectorAll(".tab-content").forEach((content) => {
                    content.classList.remove("active");
                });
                document.querySelectorAll(".doc-btn").forEach((btn) => {
                    btn.classList.remove("active");
                });

                document.getElementById(targetTab).classList.add("active");
                document.querySelectorAll(`[data-tab="${targetTab}"]`).forEach((btn) => {
                    btn.classList.add("active");
                });
            });
        });
    });
</script>

<script>
    // ==========================================
    // 4. sect06 — 데스크톱 GSAP 스크롤 + 모바일 Swiper
    // ==========================================
    gsap.registerPlugin(ScrollTrigger, ScrollToPlugin);

    if (window.innerWidth >= 769) {
        ScrollTrigger.create({
            trigger: "#sect06 .slide-wrap",
            start: "0% 0%",
            end: "100% 0%",
            scrub: true,
            onUpdate: ({
                progress
            }) => {
                let idx = Math.min(Math.floor(progress * 4), 4);

                document.querySelectorAll("#sect06 .service-list li").forEach((item, i) => {
                    item.classList.toggle("active", i === idx);
                });
                document.querySelectorAll("#sect06 .img-box .img").forEach((item, i) => {
                    item.classList.toggle("show", i === idx);
                });

                const numberEl = document.querySelector("#sect06 .left-text .number");
                if (numberEl) numberEl.textContent = "0" + (idx + 1);

                // 오른쪽 텍스트 데이터 (3개)
                const rightTextData = [{
                        subTitle: "대학병원급 분과별 ",
                        title: "4인 전문의 협진",
                        desc: "대학병원에 가지 않아도 집 근처에서 일반진료 부터<br>고난이도 진료까지 포괄적인 진료가 가능",
                    },
                    {
                        subTitle: "누적 식립 1만 건 이상 ",
                        title: "숫자가 증명하는 차별화된 전문성",
                        desc: "26년 3월 기준 <br>임플란트 누적 식립 개수 1만건",
                    },
                    {
                        subTitle: "치료의 순간은 짧고",
                        title: "편안함의 기억은 오래",
                        desc: "의식하진정치료, 웃음가스치료, 무통마취, <br>에어플로우 스케일러 등 체계적인 통증경감 <br>시스템으로 두려움까지 낮췄습니다.",
                    },
                    {
                        subTitle: "가정동 150평 대형치과,",
                        title: "독립된 집중치료실 구축",
                        desc: "환자 한 분 한 분에게 온전히 집중하고, 편안한 <br>상태에서 최선의 치료 결과를 제공하기 위함",
                    },
                ];

                // 오른쪽 텍스트 업데이트
                const iconEl = document.querySelector("#sect06 .right-text .icon");
                const subTitleEl = document.querySelector(
                    "#sect06 .right-text .sub-title",
                );
                const titleEl = document.querySelector(
                    "#sect06 .right-text .main-title",
                );
                const descEl = document.querySelector(
                    "#sect06 .right-text .description",
                );

                if (titleEl && subTitleEl && descEl && rightTextData[idx]) {
                    titleEl.innerHTML = rightTextData[idx].title;
                    subTitleEl.innerHTML = rightTextData[idx].subTitle;
                    descEl.innerHTML = rightTextData[idx].desc;
                }
            },
        });
    }

    if (window.innerWidth < 769) {
        new Swiper("#sect06 .swiper-service", {
            slidesPerView: 1,
            spaceBetween: 0,
            centeredSlides: true,
            loop: true,
            autoplay: {
                delay: 8000,
                disableOnInteraction: false,
            },
            on: {
                slideChange: function() {
                    updateMobileActiveClass(this.realIndex);
                },
            },
        });
    }
</script>

<script>
    // ==========================================
    // sect03 — 데스크톱 GSAP 스크롤 + 모바일 Swiper
    // ==========================================
    gsap.registerPlugin(ScrollTrigger, ScrollToPlugin);

    const rightTextData = [{
            subTitle: "",
            title: "&lt;Top 100 Implant Doctors in Korea&gt;",
            desc: "Recognized as one of the Top 100 Doctors<br> for clinical excellence and implant expertise.",
        },
        {
            subTitle: "",
            title: "&lt;Thesis&gt;",
            desc: "Experiment of vasopressin receptor <br> agonist to substitute epinephrine <br> Autophagy: a multifaceted intracellular system <br>for bulk and selective recycling",
        },
        {
            subTitle: "",
            title: "&lt;Specialist Certification&gt;",
            desc: "Certified by the Ministry of Health and Welfare,<br> providing comprehensive <br>and systematic treatment planning.",
        },
        {
            subTitle: "",
            title: "&lt;Adjunct Professor&gt;",
            desc: "Actively engaged in clinical education <br>and academic research<br> alongside ongoing patient care.",
        },
    ];

    if (window.innerWidth >= 0) {
        const slideWrap = document.querySelector("main.doctors #sect03 .slide-wrap.d-md-block");
        const listItems = document.querySelectorAll("main.doctors #sect03 .service-list li");
        const imgs = document.querySelectorAll("main.doctors #sect03 .img-box .img");
        const bullets = document.querySelectorAll("main.doctors #sect03 .pc-bullet");
        const subTitleEl = document.querySelector("main.doctors #sect03 .right-text .sub-title");
        const titleEl = document.querySelector("main.doctors #sect03 .right-text .main-title");
        const descEl = document.querySelector("main.doctors #sect03 .right-text .description");

        function updateSlide(idx) {
            idx = Math.max(0, Math.min(idx, 3));
            listItems.forEach((el, i) => el.classList.toggle("active", i === idx));
            imgs.forEach((el, i) => el.classList.toggle("show", i === idx));
            bullets.forEach((el, i) => el.classList.toggle("active", i === idx));
            if (subTitleEl) subTitleEl.innerHTML = rightTextData[idx].subTitle;
            if (titleEl) titleEl.innerHTML = rightTextData[idx].title;
            if (descEl) descEl.innerHTML = rightTextData[idx].desc;
        }

        updateSlide(0);

        ScrollTrigger.create({
            trigger: "main.doctors #sect03 .slide-wrap .sticky",
            start: "top top",
            end: "+=300%",
            pin: true,
            scrub: 1,
            onUpdate: ({
                progress
            }) => {
                const idx = Math.min(Math.floor(progress * 4), 3);
                updateSlide(idx);
            },
        });
    }

    // if (window.innerWidth < 769) {
    //     const swiperEl = document.querySelector("main.doctors #sect03 .swiper-service2");
    //     const paginationEl = document.querySelector("main.doctors #sect03 .swiper-service2 .swiper-pagination");

    //     new Swiper(swiperEl, {
    //         slidesPerView: 1,
    //         spaceBetween: 0,
    //         centeredSlides: true,
    //         loop: true,
    //         pagination: {
    //             el: paginationEl,
    //             clickable: true,
    //         },
    //         autoplay: {
    //             delay: 8000,
    //             disableOnInteraction: false,
    //         },
    //     });
    // }
</script>



<script>
    // ==========================================
    // 5. sect09 탭 + Swiper 초기화
    // ==========================================
    const swipers = {};

    function initSwiper(tabId) {
        if (swipers[tabId]) return;
        swipers[tabId] = new Swiper(`#${tabId} .swiper`, {
            slidesPerView: 1,
            spaceBetween: 0,
            loop: true,
            pagination: {
                el: `#${tabId} .swiper-pagination`,
                clickable: true,
            },
            navigation: {
                prevEl: `#${tabId} .swiper-button-prev`,
                nextEl: `#${tabId} .swiper-button-next`,
            },
        });
    }

    initSwiper("sect09-tab1");

    document.querySelectorAll(".sect09-tab-btn").forEach((btn) => {
        btn.addEventListener("click", function() {
            const target = this.getAttribute("data-tab");

            document.querySelectorAll(".sect09-tab-btn").forEach((b) => b.classList.remove("active"));
            this.classList.add("active");

            document.querySelectorAll(".sect09-tab-content").forEach((c) => c.classList.remove("active"));

            const el = document.getElementById(target);
            if (el) {
                el.classList.add("active");
            }

            requestAnimationFrame(() => {
                if (swipers[target]) {
                    swipers[target].update();
                } else {
                    initSwiper(target);
                }
            });
        });
    });
</script>



<?php
// tail.sub.php는 로드하지 않음 (BS5 중복 방지)
include_once(G5_PATH . '/tail_sub.php');
?>
</body>

</html>