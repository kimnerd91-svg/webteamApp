<?php

/**
 * NEW ADM - 실제 코드 분석 기반 테이블 설치
 * 경로: newadm/install.php
 */

error_reporting(E_ALL);
ini_set('display_errors', '1');

include_once('./_common.php');

if (isset($_POST['mode']) && $_POST['mode'] == 'install') {
    $result = installAllTables();
    if ($result['success']) {
        echo "<script>alert('설치 완료!\\n\\n성공: {$result['success_count']}개'); location.href='./index.php';</script>";
    } else {
        echo "<script>alert('설치 실패\\n{$result['error']}');</script>";
    }
}

function installAllTables()
{
    global $g5;

    $success = 0;
    $fail = 0;
    $error_msg = '';

    // 설치할 테이블 스키마 배열
    $tables = array(
        'dm_config' => "CREATE TABLE IF NOT EXISTS `dm_config` (
            `cf_id` int(11) NOT NULL AUTO_INCREMENT,
            `cf_site_name` varchar(255) DEFAULT '사이트명',
            `cf_title` varchar(255) DEFAULT '',
            `cf_description` text,
            `cf_logo` varchar(255) DEFAULT '',
            `cf_favicon` varchar(255) DEFAULT '',
            `cf_og_image` varchar(255) DEFAULT '',
            `cf_ga_id` varchar(255) DEFAULT '',
            `cf_add_script` text,
            `cf_langs` varchar(255) DEFAULT 'ko',
            `cf_company_name` varchar(255) DEFAULT '',
            `cf_ceo_name` varchar(255) DEFAULT '',
            `cf_business_number` varchar(255) DEFAULT '',
            `cf_tel` varchar(255) DEFAULT '',
            `cf_address` varchar(500) DEFAULT '',
            `cf_lat` varchar(100) DEFAULT '',
            `cf_lng` varchar(100) DEFAULT '',
            `cf_privacy_policy` text,
            `cf_terms` text,
            `cf_naver_booking` varchar(500) DEFAULT '',
            `cf_naver_talk` varchar(500) DEFAULT '',
            `cf_kakao` varchar(500) DEFAULT '',
            `cf_blog` varchar(500) DEFAULT '',
            `cf_instagram` varchar(500) DEFAULT '',
            `cf_kakao_rest_key` varchar(255) DEFAULT '',
            `cf_naver_client_id` varchar(255) DEFAULT '',
            `cf_naver_secret` varchar(255) DEFAULT '',
            `cf_google_client_id` varchar(255) DEFAULT '',
            `cf_social_login_use` tinyint(4) DEFAULT '0',
            `cf_kakao_client_secret` varchar(255) DEFAULT '',
            PRIMARY KEY (`cf_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

        'dm_banner' => "CREATE TABLE IF NOT EXISTS `dm_banner` (
            `bn_id` int(11) NOT NULL AUTO_INCREMENT,
            `bn_position` varchar(50) NOT NULL DEFAULT 'main',
            `bn_title` varchar(255) NOT NULL DEFAULT '',
            `bn_url` varchar(500) DEFAULT '',
            `bn_device` varchar(20) DEFAULT 'both',
            `bn_image" . "` varchar(500) DEFAULT '',
            `bn_alt` varchar(255) DEFAULT '',
            `bn_target` varchar(20) DEFAULT '_blank',
            `bn_order` int(11) DEFAULT '0',
            `bn_begin_time` datetime DEFAULT NULL,
            `bn_end_time` datetime DEFAULT NULL,
            `bn_hit` int(11) DEFAULT '0',
            `bn_time` datetime DEFAULT CURRENT_TIMESTAMP,
            `bn_use` tinyint(1) DEFAULT '1',
            PRIMARY KEY (`bn_id`),
            KEY `bn_position` (`bn_position`),
            KEY `bn_use` (`bn_use`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

        'dm_beforeafter' => "CREATE TABLE IF NOT EXISTS `dm_beforeafter` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `title` varchar(255) NOT NULL,
            `image_before` varchar(255) DEFAULT NULL,
            `image_after` varchar(255) DEFAULT NULL,
            `treatment_category` varchar(100) DEFAULT NULL,
            `patient_age` varchar(50) DEFAULT NULL,
            `patient_gender` varchar(10) DEFAULT NULL,
            `treatment_period` varchar(100) DEFAULT NULL,
            `description` text,
            `is_visible` tinyint(1) DEFAULT '1',
            `display_order` int(11) DEFAULT '0',
            `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8;",

        'dm_board_extra' => "CREATE TABLE IF NOT EXISTS `dm_board_extra` (
            `be_id` int(11) NOT NULL AUTO_INCREMENT,
            `bo_table` varchar(50) NOT NULL,
            `be_thumbnail_width` int(11) DEFAULT '0',
            `be_thumbnail_height` int(11) DEFAULT '0',
            `be_use_list_thumbnail` tinyint(1) DEFAULT '0',
            `be_use_view_thumbnail` tinyint(1) DEFAULT '0',
            `be_custom_css` text,
            `be_custom_js` text,
            PRIMARY KEY (`be_id`),
            UNIQUE KEY `bo_table` (`bo_table`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

        'dm_content' => "CREATE TABLE IF NOT EXISTS `dm_content` (
            `co_id` varchar(50) NOT NULL,
            `co_html` tinyint(1) DEFAULT '0',
            `co_subject` varchar(255) DEFAULT '',
            `co_content` longtext,
            `co_seo_title` varchar(255) DEFAULT '',
            `co_mobile_content` longtext,
            `co_skin` varchar(50) DEFAULT '',
            `co_mobile_skin` varchar(50) DEFAULT '',
            `co_tag_filter_use` tinyint(1) DEFAULT '0',
            `co_hit` int(11) DEFAULT '0',
            `co_include_head` varchar(255) DEFAULT '',
            `co_include_tail` varchar(255) DEFAULT '',
            PRIMARY KEY (`co_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

        'dm_doctors' => "CREATE TABLE IF NOT EXISTS `dm_doctors` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `name` varchar(100) NOT NULL,
            `position` varchar(100) NOT NULL,
            `degree` text,
            `career` text NOT NULL,
            `image` varchar(255) DEFAULT NULL,
            `is_visible` tinyint(1) DEFAULT '1',
            `display_order` int(11) DEFAULT '0',
            `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8;",

        'dm_faq' => "CREATE TABLE IF NOT EXISTS `dm_faq` (
            `fa_id` int(11) NOT NULL AUTO_INCREMENT,
            `fa_subject` text NOT NULL,
            `fa_content` text NOT NULL,
            `fa_category` varchar(100) DEFAULT '',
            `fa_order` int(11) DEFAULT '0',
            `fa_use` tinyint(1) DEFAULT '1',
            `fa_datetime` datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`fa_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

        'dm_menu' => "CREATE TABLE IF NOT EXISTS `dm_menu` (
            `me_id` int(11) NOT NULL AUTO_INCREMENT,
            `me_code` varchar(50) NOT NULL,
            `me_name` varchar(100) NOT NULL,
            `me_link` varchar(500) DEFAULT '',
            `me_target` varchar(20) DEFAULT '_self',
            `me_order" . "` int(11) DEFAULT '0',
            `me_use` tinyint(1) DEFAULT '1',
            `me_mobile_use` tinyint(1) DEFAULT '1',
            `me_parent_code` varchar(50) DEFAULT '',
            PRIMARY KEY (`me_id`),
            UNIQUE KEY `me_code` (`me_code`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

        'dm_non_covered' => "CREATE TABLE IF NOT EXISTS `dm_non_covered` (
            `nc_id` int(11) NOT NULL AUTO_INCREMENT,
            `nc_category` varchar(100) DEFAULT '',
            `nc_name` varchar(255) NOT NULL,
            `nc_unit` varchar(50) DEFAULT '',
            `nc_price` int(11) DEFAULT '0',
            `nc_description` text,
            `nc_order` int(11) DEFAULT '0',
            `nc_use` tinyint(1) DEFAULT '1',
            `nc_datetime` datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`nc_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

        'dm_popup' => "CREATE TABLE IF NOT EXISTS `dm_popup` (
            `nw_id` int(11) NOT NULL AUTO_INCREMENT,
            `nw_subject` varchar(255) DEFAULT '',
            `nw_begin_time` datetime DEFAULT NULL,
            `nw_end_time` datetime DEFAULT NULL,
            `nw_width` int(11) DEFAULT '500',
            `nw_height` int(11) DEFAULT '500',
            `nw_left` int(11) DEFAULT '0',
            `nw_top` int(11) DEFAULT '0',
            `nw_img` varchar(255) DEFAULT '',
            `nw_link` varchar(500) DEFAULT '',
            `nw_target` varchar(20) DEFAULT '_blank',
            `nw_status` tinyint(4) DEFAULT '1',
            `nw_type` varchar(20) DEFAULT 'general',
            `cf_popup_type` varchar(20) DEFAULT 'general',
            PRIMARY KEY (`nw_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

        'dm_review' => "CREATE TABLE IF NOT EXISTS `dm_review` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `category` varchar(50) DEFAULT NULL,
            `rating` tinyint(1) DEFAULT '5',
            `content` text NOT NULL,
            `author_name` varchar(100) NOT NULL,
            `author_initial` varchar(10) DEFAULT NULL,
            `avatar_color` varchar(20) DEFAULT '#007bff',
            `review_date` date DEFAULT NULL,
            `is_visible` tinyint(1) DEFAULT '1',
            `display_order` int(11) DEFAULT '0',
            `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

        'dm_visit' => "CREATE TABLE IF NOT EXISTS `dm_visit` (
            `vi_id` int(11) NOT NULL AUTO_INCREMENT,
            `vi_ip` varchar(50) NOT NULL,
            `vi_date` date NOT NULL,
            `vi_time` time NOT NULL,
            `vi_referer` varchar(500) DEFAULT '',
            `vi_agent` varchar(500) DEFAULT '',
            `vi_browser` varchar(50) DEFAULT '',
            `vi_os` varchar(50) DEFAULT '',
            `vi_device` varchar(20) DEFAULT 'PC',
            PRIMARY KEY (`vi_id`),
            KEY `vi_date` (`vi_date`),
            KEY `vi_ip` (`vi_ip`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

        'dm_visit_sum' => "CREATE TABLE IF NOT EXISTS `dm_visit_sum` (
            `vs_date` date NOT NULL,
            `vs_count` int(11) DEFAULT '0',
            PRIMARY KEY (`vs_date`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

        'mainbanner' => "CREATE TABLE IF NOT EXISTS `mainbanner` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `title` varchar(255) DEFAULT '',
            `is_main` tinyint(1) DEFAULT '0',
            `images` longtext COMMENT 'JSON 배열: [{src, visible, link, text_settings}]',
            `settings` text COMMENT 'JSON: {autoplay_delay, effect, loop, speed}',
            `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `is_main` (`is_main`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

        'dm_slide' => "CREATE TABLE IF NOT EXISTS `dm_slide` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `tab` varchar(100) DEFAULT '' COMMENT '탭 그룹명',
            `title` varchar(255) DEFAULT '',
            `description` text,
            `image_pc` varchar(500) DEFAULT '',
            `image_mobile` varchar(500) DEFAULT '',
            `link` varchar(500) DEFAULT '',
            `link_target` varchar(20) DEFAULT '_self',
            `is_visible` tinyint(1) DEFAULT '1',
            `display_order` int(11) DEFAULT '0',
            `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `tab` (`tab`),
            KEY `is_visible` (`is_visible`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;"
    );

    foreach ($tables as $name => $sql) {
        try {
            if (sql_query($sql)) {
                $success++;
            } else {
                $fail++;
            }
        } catch (Exception $e) {
            $fail++;
            $error_msg .= "$name 설치 오류: " . $e->getMessage() . "\\n";
        }
    }

    return array(
        'success' => ($fail == 0),
        'success_count' => $success,
        'fail_count' => $fail,
        'error' => $error_msg
    );
}

// 현재 상태 확인
$tables_status = [];
$check_tables = ['dm_config', 'dm_popup', 'mainbanner', 'dm_slide', 'dm_doctors', 'dm_review', 'dm_visit'];

foreach ($check_tables as $table) {
    $result = sql_query("SHOW TABLES LIKE '{$table}'");
    $tables_status[$table] = (sql_num_rows($result) > 0);
}
?>
<!DOCTYPE html>
<html lang="ko">

<head>
    <meta charset="UTF-8">
    <title>NEW ADM 설치</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 40px;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
        }

        h1 {
            font-size: 32px;
            margin-bottom: 30px;
            color: #333;
        }

        .table-check {
            margin: 30px 0;
        }

        .table-row {
            padding: 15px;
            border-bottom: 1px solid #eee;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 700;
        }

        .badge-success {
            background: #d4edda;
            color: #155724;
        }

        .badge-danger {
            background: #f8d7da;
            color: #721c24;
        }

        .btn {
            width: 100%;
            padding: 15px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 18px;
            font-weight: 700;
            cursor: pointer;
            margin-top: 20px;
        }

        .btn:hover {
            background: #5568d3;
        }

        .warning {
            background: #fff3cd;
            border: 2px solid #ffc107;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            color: #856404;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>🚀 NEW ADM 설치</h1>

        <div class="warning">
            <strong>⚠️ 경고</strong><br>
            기존 테이블이 있으면 완전히 삭제됩니다!<br>
            반드시 백업 후 진행하세요.
        </div>

        <div class="table-check">
            <h3>현재 상태</h3>
            <?php foreach ($tables_status as $table => $exists): ?>
                <div class="table-row">
                    <span><?php echo $table; ?></span>
                    <span class="badge <?php echo $exists ? 'badge-success' : 'badge-danger'; ?>">
                        <?php echo $exists ? '✅ 존재함' : '❌ 없음'; ?>
                    </span>
                </div>
            <?php endforeach; ?>
        </div>

        <form method="post" onsubmit="return confirm('정말 설치하시겠습니까?\\n기존 데이터가 삭제됩니다!');">
            <input type="hidden" name="mode" value="install">
            <button type="submit" class="btn">설치 시작</button>
        </form>
    </div>
</body>

</html>