<?php
include_once($_SERVER['DOCUMENT_ROOT'].'/common.php');

$check_result = sql_query("SHOW TABLES LIKE 'mainbanner'");
$table_exists = sql_num_rows($check_result) > 0;

if ($table_exists) {
    die('
    <!DOCTYPE html><html lang="ko"><head><meta charset="UTF-8"><title>이미 존재</title>
    <style>body{font-family:sans-serif;background:#f5f6fa;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;}
    .box{background:#fff;border-radius:12px;padding:48px;text-align:center;box-shadow:0 2px 12px rgba(0,0,0,.07);border:1px solid #e8eaf0;max-width:440px;}
    h2{color:#f59e0b;font-size:22px;margin-bottom:12px;}p{color:#5c5c7a;font-size:14px;margin-bottom:24px;}
    a{display:inline-block;padding:12px 28px;background:#4f46e5;color:#fff;border-radius:9px;font-weight:700;text-decoration:none;}</style></head>
    <body><div class="box"><h2>이미 테이블이 존재합니다</h2><p>mainbanner 테이블이 이미 생성되어 있습니다.</p>
    <a href="./banner_manager.php">배너 관리로 이동</a></div></body></html>
    ');
}

$result = sql_query("
CREATE TABLE `mainbanner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `images` longtext DEFAULT NULL,
  `settings` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
", false);
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>배너 테이블 생성</title>
    <style>
        @import url('https://cdn.jsdelivr.net/gh/orioncactus/pretendard/dist/web/static/pretendard.css');
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Pretendard', 'Apple SD Gothic Neo', sans-serif; background: #f5f6fa; display: flex; align-items: center; justify-content: center; min-height: 100vh; }
        .box { background: #fff; border-radius: 14px; padding: 52px 48px; text-align: center; box-shadow: 0 4px 24px rgba(0,0,0,.08); border: 1px solid #e8eaf0; max-width: 520px; width: 90%; }
        .icon { font-size: 64px; margin-bottom: 20px; }
        h1 { font-size: 24px; font-weight: 700; margin-bottom: 12px; }
        h1.success { color: #10b981; }
        h1.error   { color: #ef4444; }
        .info_box { background: #f5f6fa; border-radius: 9px; padding: 20px; margin: 24px 0; text-align: left; }
        .info_row { display: flex; gap: 12px; padding: 8px 0; border-bottom: 1px solid #e8eaf0; font-size: 14px; }
        .info_row:last-child { border-bottom: none; }
        .info_label { color: #9999bb; font-weight: 600; min-width: 80px; }
        .info_val { color: #4f46e5; font-weight: 700; }
        .warning { background: #fef3c7; border: 1px solid #fcd34d; border-radius: 9px; padding: 16px; margin: 20px 0; text-align: left; font-size: 13px; color: #92400e; }
        .warning strong { display: block; margin-bottom: 8px; font-size: 14px; }
        .warning ul { margin-left: 18px; line-height: 1.8; }
        .btn { display: inline-block; padding: 13px 36px; background: #4f46e5; color: #fff; text-decoration: none; border-radius: 9px; font-weight: 700; font-size: 14px; box-shadow: 0 4px 12px rgba(79,70,229,.25); transition: all .2s; margin-top: 8px; }
        .btn:hover { background: #4338ca; transform: translateY(-1px); }
        .error_msg { background: #fee2e2; border: 1px solid #fca5a5; color: #991b1b; padding: 16px; border-radius: 9px; margin: 20px 0; font-family: monospace; font-size: 13px; word-break: break-all; }
    </style>
</head>
<body>
<div class="box">
    <?php if ($result): ?>
    <div class="icon">✅</div>
    <h1 class="success">테이블 생성 완료!</h1>
    <div class="info_box">
        <div class="info_row"><span class="info_label">테이블명</span><span class="info_val">mainbanner</span></div>
        <div class="info_row"><span class="info_label">필드</span><span class="info_val">id, name, images, settings, created_at</span></div>
        <div class="info_row"><span class="info_label">엔진</span><span class="info_val">InnoDB / utf8mb4</span></div>
    </div>
    <div class="warning">
        <strong>⚠️ 주의사항</strong>
        <ul>
            <li>테이블이 정상적으로 생성되었습니다.</li>
            <li>보안을 위해 이 파일을 서버에서 삭제하거나 이름을 변경하세요.</li>
        </ul>
    </div>
    <a href="./banner_manager.php" class="btn">배너 관리로 이동</a>
    <?php else: ?>
    <div class="icon">❌</div>
    <h1 class="error">테이블 생성 실패</h1>
    <p style="color:#5c5c7a; font-size:14px; margin-bottom:16px;">데이터베이스 오류가 발생했습니다.</p>
    <div class="error_msg"><?= sql_error() ?></div>
    <p style="color:#9999bb; font-size:13px;">관리자에게 문의하거나 DB 권한을 확인해주세요.</p>
    <?php endif; ?>
</div>
</body>
</html>