<?php
include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/_common.php');
include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/_auth_check.php');

// 테이블 자동 생성
sql_query("CREATE TABLE IF NOT EXISTS `dm_slide` (
    `id`            INT(11) NOT NULL AUTO_INCREMENT,
    `tab`           VARCHAR(100) DEFAULT '',
    `place_name`    VARCHAR(255) NOT NULL DEFAULT '',
    `image`         VARCHAR(500) NOT NULL DEFAULT '',
    `display_order` INT(11) DEFAULT 0,
    `is_visible`    TINYINT(1) DEFAULT 1,
    `created_at`    DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// 컬럼 자동 보정 — 기존 테이블이 구버전 구조여도 누락 컬럼 자동 추가
$slide_cols = [
    'tab'           => "VARCHAR(100) DEFAULT ''",
    'place_name'    => "VARCHAR(255) NOT NULL DEFAULT ''",
    'image'         => "VARCHAR(500) NOT NULL DEFAULT ''",
    'display_order' => "INT(11) DEFAULT 0",
    'is_visible'    => "TINYINT(1) DEFAULT 1",
    'created_at'    => "DATETIME DEFAULT CURRENT_TIMESTAMP",
];
foreach ($slide_cols as $col => $type) {
    $chk = sql_query("SHOW COLUMNS FROM `dm_slide` LIKE '{$col}'");
    if (!$chk || sql_num_rows($chk) == 0) {
        sql_query("ALTER TABLE `dm_slide` ADD `{$col}` {$type}");
    }
}

// ============================================================
// ★ AJAX 처리 — head_sub.php(화면 HTML) include 전에 모두 처리하고 exit.
//    (head_sub가 출력하는 HTML이 JSON 응답에 섞여 저장이 깨지는 문제 방지)
// ============================================================

// AJAX — 단일 이미지 업로드
if (isset($_FILES['slide_image']) && $_FILES['slide_image']['error'] === UPLOAD_ERR_OK) {
    $upload_dir = $_SERVER['DOCUMENT_ROOT'] . '/data/slide/' . date('Ym');
    $upload_url = '/data/slide/' . date('Ym');
    if (!is_dir($upload_dir)) @mkdir($upload_dir, 0755, true);
    $ext = strtolower(pathinfo($_FILES['slide_image']['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg','jpeg','png','gif','webp'])) {
        echo json_encode(['success'=>0,'message'=>'이미지 파일만 가능합니다.']);
        exit;
    }
    $fn = 'slide_' . time() . '_' . rand(1000,9999) . '.' . $ext;
    if (move_uploaded_file($_FILES['slide_image']['tmp_name'], $upload_dir.'/'.$fn)) {
        echo json_encode(['success'=>1,'url'=>$upload_url.'/'.$fn]);
    } else {
        echo json_encode(['success'=>0,'message'=>'업로드 실패']);
    }
    exit;
}

// AJAX — 일괄 추가
if (isset($_POST['action']) && $_POST['action'] === 'bulk_add') {
    $items = json_decode(stripslashes($_POST['items'] ?? '[]'), true);
    $cnt = 0;
    if (is_array($items)) {
        foreach ($items as $i => $item) {
            $tab        = sql_real_escape_string(trim($item['tab']        ?? ''));
            $place_name = sql_real_escape_string(trim($item['place_name'] ?? ''));
            $image      = sql_real_escape_string(trim($item['url']        ?? ''));
            $order      = (int)($item['display_order'] ?? $i);
            $visible    = !empty($item['is_visible']) ? 1 : 0;
            if (!$image) continue;
            $res = sql_query("INSERT INTO dm_slide SET
                tab='{$tab}', place_name='{$place_name}', image='{$image}',
                display_order='{$order}', is_visible='{$visible}', created_at=NOW()");
            if ($res) $cnt++;
        }
    }
    echo json_encode(['success'=>($cnt>0?1:0),'inserted'=>$cnt], JSON_UNESCAPED_UNICODE);
    exit;
}

// AJAX — 단일 수정
if (isset($_POST['action']) && $_POST['action'] === 'update_slide') {
    $id         = (int)($_POST['id'] ?? 0);
    $tab        = sql_real_escape_string(trim($_POST['tab']        ?? ''));
    $place_name = sql_real_escape_string(trim($_POST['place_name'] ?? ''));
    $image      = sql_real_escape_string(trim($_POST['image']      ?? ''));
    $order      = (int)($_POST['display_order'] ?? 0);
    $visible    = !empty($_POST['is_visible']) ? 1 : 0;
    sql_query("UPDATE dm_slide SET
        tab='{$tab}', place_name='{$place_name}', image='{$image}',
        display_order='{$order}', is_visible='{$visible}'
        WHERE id={$id}");
    echo json_encode(['success'=>1]);
    exit;
}

// AJAX — 탭 목록
if (isset($_GET['get_tabs'])) {
    $r = sql_query("SELECT DISTINCT tab FROM dm_slide WHERE tab!='' AND tab IS NOT NULL ORDER BY tab ASC");
    $tabs = [];
    while ($row = sql_fetch_array($r)) $tabs[] = $row['tab'];
    echo json_encode(['success'=>1,'tabs'=>$tabs]);
    exit;
}

// GET — 삭제
if (isset($_GET['delete_id'])) {
    $id  = (int)$_GET['delete_id'];
    $row = sql_fetch("SELECT image FROM dm_slide WHERE id={$id}");
    if ($row && $row['image']) { $f = $_SERVER['DOCUMENT_ROOT'].$row['image']; if (file_exists($f)) @unlink($f); }
    sql_query("DELETE FROM dm_slide WHERE id={$id}");
    alert_toast('삭제되었습니다.', './slide_manager.php');
    exit;
}

// ============================================================
// 여기부터 화면 출력 — head_sub.php는 이 지점에서 include
// ============================================================
include_once($_SERVER['DOCUMENT_ROOT'] . '/head_sub.php');

// 목록 조회
$tab_filter = isset($_GET['tab']) ? trim($_GET['tab']) : '';
if ($tab_filter === '__none__')  $where = "WHERE (tab='' OR tab IS NULL)";
elseif ($tab_filter)             $where = "WHERE tab='".sql_real_escape_string($tab_filter)."'";
else                             $where = '';

$result = sql_query("SELECT * FROM dm_slide {$where} ORDER BY display_order ASC, id ASC");
$slides = [];
while ($row = sql_fetch_array($result)) $slides[] = $row;

$tab_result = sql_query("SELECT DISTINCT tab FROM dm_slide WHERE tab!='' ORDER BY tab ASC");
$all_tabs   = [];
while ($row = sql_fetch_array($tab_result)) $all_tabs[] = $row['tab'];

$no_tab_cnt = (int)(sql_fetch("SELECT COUNT(*) as cnt FROM dm_slide WHERE tab='' OR tab IS NULL")['cnt'] ?? 0);
?>
<style>
@import url('https://cdn.jsdelivr.net/gh/orioncactus/pretendard/dist/web/static/pretendard.css');
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'Pretendard','Apple SD Gothic Neo',sans-serif;background:#f5f6fa;color:#1a1a2e;}
#admin_wrapper{display:flex;min-height:100vh;}
.content_area{flex:1;padding:40px;overflow-x:hidden;}
.card_custom{background:#fff;border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,0.06);border:1px solid #e8eaf0;padding:24px;margin-bottom:24px;}
.page_header{display:flex;align-items:center;justify-content:space-between;margin-bottom:24px;}
.page_title{font-size:22px;font-weight:700;}
.btn_primary{padding:11px 22px;background:#4f46e5;color:#fff;border:none;border-radius:9px;font-size:13px;font-weight:700;cursor:pointer;box-shadow:0 4px 12px rgba(79,70,229,0.25);transition:all .2s;}
.btn_primary:hover{background:#4338ca;}
.btn_cancel_sm{padding:8px 16px;background:#f5f6fa;color:#5c5c7a;border:1px solid #e8eaf0;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer;transition:all .2s;}
.btn_cancel_sm:hover{background:#e8eaf0;}
.btn_danger_sm{padding:8px 16px;background:#fee2e2;color:#dc2626;border:none;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer;transition:all .2s;}
.btn_danger_sm:hover{background:#fecaca;}
.slide-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:18px;}
.img-card{background:#fff;border:1px solid #e8eaf0;border-radius:12px;overflow:hidden;transition:.2s;position:relative;box-shadow:0 2px 10px rgba(0,0,0,.05);}
.img-card:hover{transform:translateY(-3px);box-shadow:0 8px 24px rgba(0,0,0,.1);border-color:#c4b5fd;}
.img-card-thumb{width:100%;height:160px;object-fit:cover;display:block;}
.img-card .card-body{padding:14px 16px;}
.tab-badge{display:inline-block;background:#ede9fe;color:#4f46e5;font-size:11px;font-weight:700;padding:3px 10px;border-radius:20px;margin-bottom:6px;}
.place-name{font-size:14px;font-weight:700;color:#1a1a2e;margin-bottom:4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.img-badge{position:absolute;top:8px;right:8px;background:#4f46e5;color:#fff;border-radius:20px;padding:3px 10px;font-size:11px;font-weight:700;z-index:5;}
.img-badge.off{background:#9999bb;}
.card-actions{display:grid;grid-template-columns:1fr 1fr;gap:7px;margin-top:12px;}
.tab-filter{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:20px;}
.tab-btn-f{padding:7px 16px;border-radius:20px;border:2px solid #e8eaf0;background:#fff;font-size:12px;font-weight:700;color:#9999bb;cursor:pointer;transition:.2s;text-decoration:none;display:inline-block;}
.tab-btn-f:hover,.tab-btn-f.on{border-color:#4f46e5;background:#ede9fe;color:#4f46e5;}
.bm-modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:9999;align-items:flex-start;justify-content:center;padding:40px 20px;overflow-y:auto;}
.bm-modal.on{display:flex;}
.bm-box{background:#fff;border-radius:14px;padding:28px;width:100%;max-height:92vh;overflow-y:auto;}
.drop-zone{border:2px dashed #e8eaf0;border-radius:10px;padding:28px 20px;text-align:center;cursor:pointer;transition:.2s;background:#f5f6fa;position:relative;}
.drop-zone.dragover,.drop-zone:hover{border-color:#4f46e5;background:#ede9fe;}
.drop-zone input[type=file]{position:absolute;inset:0;opacity:0;cursor:pointer;width:100%;height:100%;}
.upload-slider-wrap{overflow:hidden;border-radius:12px;}
.upload-slider{display:flex;transition:transform .35s ease;}
.upload-item{min-width:100%;box-sizing:border-box;}
.upload-item-inner{border:1px solid #e8eaf0;border-radius:12px;padding:16px;background:#fff;}
.upload-item-inner .item-thumb{width:100%;height:190px;object-fit:cover;border-radius:8px;display:block;margin-bottom:14px;}
.slider-nav{display:flex;align-items:center;justify-content:space-between;margin-top:14px;gap:8px;}
.slider-nav-btn{background:#4f46e5;color:#fff;border:none;border-radius:8px;padding:9px 18px;font-size:13px;font-weight:700;cursor:pointer;transition:.2s;}
.slider-nav-btn:disabled{background:#e8eaf0;color:#9999bb;cursor:default;}
.slider-counter{font-size:13px;font-weight:700;color:#9999bb;white-space:nowrap;}
.slider-dots{display:flex;gap:6px;justify-content:center;margin-top:10px;flex-wrap:wrap;}
.slider-dot{width:8px;height:8px;border-radius:50%;background:#e8eaf0;cursor:pointer;transition:.2s;border:none;padding:0;}
.slider-dot.on{background:#4f46e5;}
.prog-bar{height:6px;background:#e8eaf0;border-radius:10px;overflow:hidden;margin-top:8px;display:none;}
.prog-fill{height:100%;background:#4f46e5;border-radius:10px;transition:width .3s;width:0%;}
.form-label{display:block;font-weight:700;font-size:12px;color:#9999bb;margin-bottom:6px;}
.u-input{width:100%;padding:10px 14px;border:1px solid #e8eaf0;border-radius:8px;font-size:14px;background:#f5f6fa;transition:.2s;box-sizing:border-box;font-family:inherit;color:#1a1a2e;}
.u-input:focus{outline:none;border-color:#4f46e5;background:#fff;box-shadow:0 0 0 3px rgba(79,70,229,.1);}
.form-group{margin-bottom:12px;}
.tab-chip{padding:7px 16px;border-radius:20px;border:2px solid #e8eaf0;background:#ede9fe;color:#4f46e5;font-size:12px;font-weight:700;cursor:pointer;transition:.2s;}
.tab-chip:hover{background:#4f46e5;color:#fff;border-color:#4f46e5;}
.toast-msg{position:fixed;bottom:24px;left:50%;transform:translateX(-50%);color:#fff;padding:13px 28px;border-radius:12px;font-size:14px;font-weight:700;box-shadow:0 8px 24px rgba(0,0,0,.2);z-index:99999;animation:toastIn .3s ease;}
@keyframes toastIn{from{opacity:0;transform:translateX(-50%) translateY(20px)}to{opacity:1;transform:translateX(-50%) translateY(0)}}
.modal-hd{display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;}
.modal-title{font-size:16px;font-weight:700;}
.modal-close{background:none;border:none;font-size:20px;cursor:pointer;color:#9999bb;}
.modal-close:hover{color:#1a1a2e;}
.modal-ft{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:20px;}
</style>

<div id="admin_wrapper">
<?php include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/aside.php'); ?>
<main class="content_area">

<div class="page_header">
  <h2 class="page_title">슬라이드 관리</h2>
  <button onclick="openM('addModal')" class="btn_primary">+ 슬라이드 추가</button>
</div>

<div class="card_custom">
  <div class="tab-filter">
    <a href="./slide_manager.php" class="tab-btn-f <?php echo !$tab_filter?'on':''; ?>">전체</a>
    <?php foreach($all_tabs as $t): ?>
    <a href="./slide_manager.php?tab=<?php echo urlencode($t); ?>" class="tab-btn-f <?php echo $tab_filter===$t?'on':''; ?>"><?php echo htmlspecialchars($t); ?></a>
    <?php endforeach; ?>
    <?php if($no_tab_cnt>0): ?>
    <a href="./slide_manager.php?tab=__none__" class="tab-btn-f <?php echo $tab_filter==='__none__'?'on':''; ?>">미분류 (<?php echo $no_tab_cnt; ?>)</a>
    <?php endif; ?>
  </div>

  <?php if(empty($slides)): ?>
    <p style="text-align:center;color:#9999bb;padding:60px 0;font-size:14px;">슬라이드가 없습니다.</p>
  <?php else: ?>
  <div class="slide-grid">
    <?php foreach($slides as $s): ?>
    <div class="img-card">
      <span class="img-badge <?php echo $s['is_visible']?'':'off'; ?>"><?php echo $s['is_visible']?'노출':'숨김'; ?></span>
      <img class="img-card-thumb" src="<?php echo htmlspecialchars($s['image']); ?>" alt="">
      <div class="card-body">
        <?php if($s['tab']): ?><div class="tab-badge"><?php echo htmlspecialchars($s['tab']); ?></div><?php endif; ?>
        <div class="place-name"><?php echo htmlspecialchars($s['place_name']?:'(이름 없음)'); ?></div>
        <div style="font-size:11px;color:#adb5bd;">순서 <?php echo (int)$s['display_order']; ?></div>
        <div class="card-actions">
          <button onclick='openEdit(<?php echo json_encode(['id'=>$s['id'],'image'=>$s['image'],'tab'=>$s['tab'],'place_name'=>$s['place_name'],'display_order'=>$s['display_order'],'is_visible'=>$s['is_visible']]); ?>)' class="btn_cancel_sm" style="flex:1;">수정</button>
          <button onclick="confirmDelete(<?php echo (int)$s['id']; ?>)" class="btn_danger_sm" style="flex:1;">삭제</button>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>

<!-- 추가 모달 -->
<div id="addModal" class="bm-modal">
  <div class="bm-box" style="max-width:660px;">
    <div class="modal-hd">
      <span class="modal-title">슬라이드 추가</span>
      <button onclick="closeM('addModal')" class="modal-close">✕</button>
    </div>
    <div id="stepUpload">
      <div class="drop-zone" id="dropZone">
        <input type="file" id="multiFileInput" accept="image/*" multiple onchange="handleFiles(this.files)">
        <div style="font-size:36px;">🖼️</div>
        <div style="font-size:15px;font-weight:700;margin-top:10px;">클릭 또는 드래그로 이미지 업로드</div>
        <div style="font-size:12px;color:#adb5bd;margin-top:6px;">여러 장 동시 선택 가능 · jpg, png, webp, gif</div>
      </div>
      <div class="prog-bar" id="progBar"><div class="prog-fill" id="progFill"></div></div>
      <div id="uploadStatus" style="font-size:12px;color:#adb5bd;margin-top:6px;text-align:center;min-height:18px;"></div>
    </div>
    <div id="stepEdit" style="display:none;">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;">
        <span style="font-size:13px;font-weight:700;color:var(--main-color,#4f46e5);" id="editStepLabel"></span>
        <button onclick="resetUpload()" style="background:none;border:none;font-size:12px;color:#adb5bd;cursor:pointer;text-decoration:underline;">다시 업로드</button>
      </div>
      <div class="upload-slider-wrap"><div class="upload-slider" id="uploadSlider"></div></div>
      <div class="slider-nav">
        <button class="slider-nav-btn" id="sliderPrev" onclick="slideMove(-1)">◀ 이전</button>
        <span class="slider-counter"><span id="sliderCur">1</span> / <span id="sliderTotal">1</span></span>
        <button class="slider-nav-btn" id="sliderNext" onclick="slideMove(1)">다음 ▶</button>
      </div>
      <div class="slider-dots" id="sliderDots"></div>
      <div class="modal-ft">
        <button onclick="closeM('addModal')" class="btn_cancel_sm">취소</button>
        <button onclick="bulkSave()" class="btn_primary" id="bulkSaveBtn">💾 전체 저장</button>
      </div>
    </div>
  </div>
</div>

<!-- 수정 모달 -->
<div id="editModal" class="bm-modal">
  <div class="bm-box" style="max-width:500px;">
    <div class="modal-hd">
      <span class="modal-title">슬라이드 수정</span>
      <button onclick="closeM('editModal')" class="modal-close">✕</button>
    </div>
    <input type="hidden" id="e_id"><input type="hidden" id="e_image">
    <div class="form-group">
      <label class="form-label">현재 이미지</label>
      <img id="e_img_preview" style="width:100%;height:180px;object-fit:cover;border-radius:10px;display:block;margin-bottom:10px;" src="">
      <div class="drop-zone" style="padding:14px;">
        <input type="file" accept="image/*" onchange="uploadEditImg(this.files[0])">
        <div style="font-size:12px;color:#adb5bd;">클릭하여 이미지 교체 (선택)</div>
      </div>
      <div id="e_img_loading" style="display:none;font-size:12px;color:#4f46e5;margin-top:4px;">⏳ 업로드 중...</div>
    </div>
    <div class="form-group">
      <label class="form-label">탭 분류 <small style="color:#adb5bd;font-weight:400;">(선택)</small></label>
      <div style="display:flex;gap:8px;">
        <input type="text" id="e_tab" class="u-input" placeholder="예: 임플란트">
        <button type="button" onclick="openTabPicker('e_tab')" class="btn_cancel_sm" style="white-space:nowrap;flex-shrink:0;">기존</button>
      </div>
    </div>
    <div class="form-group">
      <label class="form-label">장소명</label>
      <input type="text" id="e_place_name" class="u-input" placeholder="예: 대기실, 예진실, 상담실">
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
      <div class="form-group">
        <label class="form-label">표시 순서</label>
        <input type="number" id="e_display_order" class="u-input" min="0" value="0">
      </div>
      <div class="form-group" style="display:flex;align-items:flex-end;padding-bottom:4px;">
        <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:13px;font-weight:600;">
          <input type="checkbox" id="e_is_visible" checked style="width:15px;height:15px;">노출 활성화
        </label>
      </div>
    </div>
    <div class="modal-ft">
      <button onclick="closeM('editModal')" class="btn_cancel_sm">취소</button>
      <button onclick="submitEdit()" class="btn_primary">수정 저장</button>
    </div>
  </div>
</div>

<!-- 탭 피커 -->
<div id="tabPickerModal" class="bm-modal">
  <div class="bm-box" style="max-width:360px;">
    <div class="modal-hd">
      <span class="modal-title">탭 선택</span>
      <button onclick="closeM('tabPickerModal')" class="modal-close">✕</button>
    </div>
    <div id="tabPickerList" style="display:flex;flex-wrap:wrap;gap:8px;"></div>
    <p id="tabPickerEmpty" style="display:none;color:#adb5bd;font-size:13px;text-align:center;padding:20px 0;">등록된 탭이 없습니다.</p>
  </div>
</div>

<!-- 삭제 확인 -->
<div id="deleteModal" class="bm-modal">
  <div class="bm-box" style="max-width:320px;text-align:center;">
    <div style="font-size:40px;margin-bottom:12px;">🗑️</div>
    <h4 style="font-size:17px;font-weight:700;margin-bottom:8px;">삭제하시겠습니까?</h4>
    <p style="font-size:13px;color:#9999bb;margin-bottom:20px;">삭제된 슬라이드는 복구할 수 없습니다.</p>
    <div class="modal-ft">
      <button onclick="closeM('deleteModal')" class="btn_cancel_sm">취소</button>
      <button id="deleteConfirmBtn" class="btn_danger_sm">삭제</button>
    </div>
  </div>
</div>

</main>
</div>

<script>
var AJAX='./slide_manager.php';
function openM(id){document.getElementById(id).classList.add('on');}
function closeM(id){document.getElementById(id).classList.remove('on');}

var _items=[],_cur=0;
var dz=document.getElementById('dropZone');
if(dz){
  dz.addEventListener('dragover',function(e){e.preventDefault();dz.classList.add('dragover');});
  dz.addEventListener('dragleave',function(){dz.classList.remove('dragover');});
  dz.addEventListener('drop',function(e){e.preventDefault();dz.classList.remove('dragover');handleFiles(e.dataTransfer.files);});
}
function handleFiles(files){
  if(!files||!files.length)return;
  var arr=Array.from(files).filter(function(f){return f.type.startsWith('image/');});
  if(!arr.length){alert('이미지 파일만 가능합니다.');return;}
  document.getElementById('progBar').style.display='block';
  _items=[];var done=0;
  function up(i){
    if(i>=arr.length){document.getElementById('uploadStatus').textContent=arr.length+'장 완료!';buildSlider();return;}
    document.getElementById('uploadStatus').textContent=(i+1)+'/'+arr.length+' 업로드 중...';
    var fd=new FormData();fd.append('slide_image',arr[i]);
    fetch(AJAX,{method:'POST',body:fd})
      .then(function(r){return r.json();})
      .then(function(d){
        _items.push({url:d.success?d.url:'',place_name:'',tab:'',display_order:i,is_visible:true,error:!d.success});
        done++;document.getElementById('progFill').style.width=Math.round(done/arr.length*100)+'%';up(i+1);
      }).catch(function(){
        _items.push({url:'',place_name:'',tab:'',display_order:i,is_visible:true,error:true});
        done++;document.getElementById('progFill').style.width=Math.round(done/arr.length*100)+'%';up(i+1);
      });
  }
  up(0);
}
function buildSlider(){
  document.getElementById('stepUpload').style.display='none';
  document.getElementById('stepEdit').style.display='block';
  document.getElementById('editStepLabel').textContent='총 '+_items.length+'장 — 정보 입력 후 저장';
  document.getElementById('sliderTotal').textContent=_items.length;
  var sl=document.getElementById('uploadSlider'),dt=document.getElementById('sliderDots');
  sl.innerHTML='';dt.innerHTML='';
  _items.forEach(function(item,i){
    var d=document.createElement('div');d.className='upload-item';
    var img=item.error?'<div style="height:190px;background:#fff3f3;border-radius:8px;display:flex;align-items:center;justify-content:center;color:#ef4444;font-size:13px;margin-bottom:14px;">⚠️ 업로드 실패</div>':'<img class="item-thumb" src="'+item.url+'" alt="">';
    d.innerHTML='<div class="upload-item-inner">'+img+
      '<div class="form-group"><label class="form-label">장소명</label><input type="text" class="u-input item-place" data-idx="'+i+'" placeholder="예: 대기실" value="" oninput="sync(this)"></div>'+
      '<div class="form-group"><label class="form-label">탭 분류 <small style="color:#9999bb;font-weight:400;">(선택)</small></label><div style="display:flex;gap:8px;"><input type="text" class="u-input item-tab" data-idx="'+i+'" placeholder="비워도 됩니다" value="" oninput="sync(this)"><button type="button" onclick="openTabPickerForItem('+i+')" class="btn_cancel_sm" style="white-space:nowrap;flex-shrink:0;">기존</button></div></div>'+
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;"><div class="form-group"><label class="form-label">표시 순서</label><input type="number" class="u-input item-order" data-idx="'+i+'" value="'+i+'" min="0" oninput="sync(this)"></div>'+
      '<div class="form-group" style="display:flex;align-items:flex-end;padding-bottom:4px;"><label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:13px;font-weight:600;"><input type="checkbox" class="item-visible" data-idx="'+i+'" checked onchange="sync(this)" style="width:15px;height:15px;">노출 활성화</label></div></div></div>';
    sl.appendChild(d);
    var dot=document.createElement('button');dot.type='button';dot.className='slider-dot'+(i===0?' on':'');
    dot.setAttribute('data-idx',i);dot.onclick=(function(ii){return function(){goSlide(ii);};})(i);dt.appendChild(dot);
  });
  _cur=0;renderSlide();
}
function sync(el){
  var i=parseInt(el.getAttribute('data-idx'));
  if(el.classList.contains('item-place'))  _items[i].place_name   =el.value;
  if(el.classList.contains('item-tab'))    _items[i].tab          =el.value;
  if(el.classList.contains('item-order'))  _items[i].display_order=parseInt(el.value)||0;
  if(el.classList.contains('item-visible'))_items[i].is_visible   =el.checked;
}
function renderSlide(){
  document.getElementById('uploadSlider').style.transform='translateX(-'+(_cur*100)+'%)';
  document.getElementById('sliderCur').textContent=_cur+1;
  document.getElementById('sliderPrev').disabled=_cur===0;
  document.getElementById('sliderNext').disabled=_cur===_items.length-1;
  document.querySelectorAll('.slider-dot').forEach(function(d,i){d.classList.toggle('on',i===_cur);});
}
function slideMove(dir){_cur=Math.max(0,Math.min(_items.length-1,_cur+dir));renderSlide();}
function goSlide(i){_cur=i;renderSlide();}
function resetUpload(){
  _items=[];_cur=0;
  document.getElementById('stepUpload').style.display='block';
  document.getElementById('stepEdit').style.display='none';
  document.getElementById('progBar').style.display='none';
  document.getElementById('progFill').style.width='0%';
  document.getElementById('uploadStatus').textContent='';
  document.getElementById('multiFileInput').value='';
}
function bulkSave(){
  var valid=_items.filter(function(it){return it.url&&!it.error;});
  if(!valid.length){showToast('저장할 이미지가 없습니다.','error');return;}
  var btn=document.getElementById('bulkSaveBtn');btn.disabled=true;btn.textContent='저장 중...';
  var fd=new FormData();fd.append('action','bulk_add');fd.append('items',JSON.stringify(valid));
  fetch(AJAX,{method:'POST',body:fd})
    .then(function(r){return r.json();})
    .then(function(d){
      if(d.success&&d.inserted>0){showToast(d.inserted+'개 저장 완료!');setTimeout(function(){location.reload();},900);}
      else{showToast('저장 실패','error');btn.disabled=false;btn.textContent='💾 전체 저장';}
    }).catch(function(e){showToast('오류: '+e.message,'error');btn.disabled=false;btn.textContent='💾 전체 저장';});
}
function openEdit(data){
  document.getElementById('e_id').value=data.id;
  document.getElementById('e_image').value=data.image;
  document.getElementById('e_tab').value=data.tab||'';
  document.getElementById('e_place_name').value=data.place_name||'';
  document.getElementById('e_display_order').value=data.display_order||0;
  document.getElementById('e_is_visible').checked=data.is_visible==1;
  document.getElementById('e_img_preview').src=data.image||'';
  document.getElementById('e_img_loading').style.display='none';
  openM('editModal');
}
function uploadEditImg(file){
  if(!file)return;
  document.getElementById('e_img_loading').style.display='block';
  var fd=new FormData();fd.append('slide_image',file);
  fetch(AJAX,{method:'POST',body:fd}).then(function(r){return r.json();}).then(function(d){
    document.getElementById('e_img_loading').style.display='none';
    if(d.success){document.getElementById('e_image').value=d.url;document.getElementById('e_img_preview').src=d.url;}
    else alert(d.message||'업로드 실패');
  });
}
function submitEdit(){
  var fd=new FormData();
  fd.append('action','update_slide');
  fd.append('id',document.getElementById('e_id').value);
  fd.append('image',document.getElementById('e_image').value);
  fd.append('tab',document.getElementById('e_tab').value);
  fd.append('place_name',document.getElementById('e_place_name').value);
  fd.append('display_order',document.getElementById('e_display_order').value);
  if(document.getElementById('e_is_visible').checked)fd.append('is_visible','1');
  fetch(AJAX,{method:'POST',body:fd}).then(function(r){return r.json();}).then(function(d){
    if(d.success){showToast('수정 완료!');setTimeout(function(){location.reload();},800);}
    else showToast('수정 실패','error');
  });
}
var _tabTarget='';
function openTabPicker(id){_tabTarget=id;loadTabPicker();}
function openTabPickerForItem(i){_tabTarget='__item__'+i;loadTabPicker();}
function loadTabPicker(){
  var list=document.getElementById('tabPickerList'),empty=document.getElementById('tabPickerEmpty');
  list.innerHTML='';
  fetch(AJAX+'?get_tabs=1').then(function(r){return r.json();}).then(function(data){
    if(!data.tabs||!data.tabs.length){list.style.display='none';empty.style.display='block';}
    else{
      list.style.display='flex';empty.style.display='none';
      data.tabs.forEach(function(t){
        var btn=document.createElement('button');btn.type='button';btn.textContent=t;btn.className='tab-chip';
        btn.onclick=function(){
          if(_tabTarget.startsWith('__item__')){
            var idx=parseInt(_tabTarget.replace('__item__',''));
            document.querySelectorAll('.item-tab[data-idx="'+idx+'"]').forEach(function(el){el.value=t;});
            if(_items[idx])_items[idx].tab=t;
          }else{var el=document.getElementById(_tabTarget);if(el)el.value=t;}
          closeM('tabPickerModal');
        };
        list.appendChild(btn);
      });
    }
    openM('tabPickerModal');
  });
}
function confirmDelete(id){
  document.getElementById('deleteConfirmBtn').onclick=function(){location.href='./slide_manager.php?delete_id='+id;};
  openM('deleteModal');
}
function showToast(msg,type){
  var old=document.querySelector('.toast-msg');if(old)old.remove();
  var t=document.createElement('div');t.className='toast-msg';
  t.style.background=type==='error'?'#ef4444':'#10b981';t.textContent=msg;
  document.body.appendChild(t);
  setTimeout(function(){t.style.opacity='0';t.style.transition='opacity .3s';setTimeout(function(){t.remove();},300);},2500);
}
</script>