<?php
include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/_common.php');

/* ── 이미지 업로드 (빌더 & CKEditor 공용) ── */
if (isset($_FILES['image']['name']) || isset($_FILES['upload']['name'])) {
    while (ob_get_level()) ob_end_clean();
    $fkey = isset($_FILES['image']) ? 'image' : 'upload';
    $upload_dir = G5_DATA_PATH . '/editor/' . date('Ym');
    $upload_url = G5_DATA_URL . '/editor/' . date('Ym');
    if (!is_dir($upload_dir)) { @mkdir($upload_dir, G5_DIR_PERMISSION, true); @chmod($upload_dir, G5_DIR_PERMISSION); }
    $ext = strtolower(pathinfo($_FILES[$fkey]['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg','jpeg','png','gif','webp'])) {
        header('Content-Type: application/json');
        die(json_encode($fkey==='upload' ? ["uploaded"=>0,"error"=>["message"=>"이미지만 업로드 가능합니다."]] : ["success"=>0]));
    }
    $new_name = time().'_'.md5($_FILES[$fkey]['name']).'.'.$ext;
    $ok = move_uploaded_file($_FILES[$fkey]['tmp_name'], $upload_dir.'/'.$new_name);
    header('Content-Type: application/json');
    echo $ok
        ? json_encode($fkey==='upload'
            ? ["uploaded"=>1,"fileName"=>$new_name,"url"=>$upload_url.'/'.$new_name]
            : ["success"=>1,"url"=>$upload_url.'/'.$new_name])
        : json_encode(["success"=>0,"uploaded"=>0]);
    exit;
}

/* ── DB 저장/수정 ── */
if (isset($_POST['wr_subject']) && !empty($_POST['wr_subject'])) {
    $bo_table    = preg_replace('/[^a-z0-9_]/i','', $_POST['bo_table']);
    $write_table = $g5['write_prefix'] . $bo_table;
    $wr_subject  = sql_real_escape_string($_POST['wr_subject']);
    $wr_content  = sql_real_escape_string($_POST['wr_content']);
    $wr_seo_desc  = sql_real_escape_string($_POST['wr_seo_desc'] ?? '');
    $wr_anchor_map = sql_real_escape_string($_POST['wr_anchor_map'] ?? ''); // 에디터 모드 앵커 맵 JSON
    $editor_type  = in_array($_POST['editor_type']??'', ['builder','editor']) ? $_POST['editor_type'] : 'builder';
    $category_id  = isset($_POST['category_id']) ? (int)$_POST['category_id'] : 0;
    $wr_id        = (int)($_POST['wr_id'] ?? 0);
    $mode         = $_POST['mode'];

    /* wr_1 = editor_type, wr_2 = seo_desc, wr_3 = anchor_map(에디터 모드 앵커 JSON) */
    if ($mode == 'modify' && $wr_id) {
        sql_query("UPDATE $write_table SET wr_subject='$wr_subject',wr_content='$wr_content',wr_1='$editor_type',wr_2='$wr_seo_desc',wr_3='$wr_anchor_map',wr_10='$category_id' WHERE wr_id='$wr_id'");
        alert_toast("수정되었습니다.", ($bo_table=='faq') ? "/newadm/board/faq_manager.php" : "/newadm/board/board_post_list.php?bo_table={$bo_table}", "success");
    } else {
        sql_query("INSERT INTO $write_table SET wr_subject='$wr_subject',wr_content='$wr_content',wr_1='$editor_type',wr_2='$wr_seo_desc',wr_3='$wr_anchor_map',wr_10='$category_id',wr_datetime='".G5_TIME_YMDHIS."',wr_option='html1',wr_num='-1'");
        alert_toast("저장되었습니다.", ($bo_table=='faq') ? "/newadm/board/faq_manager.php" : "/newadm/board/board_post_list.php?bo_table={$bo_table}", "success");
    }
    exit;
}

include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/_auth_check.php');
include_once('./direct_config.php');

$mode        = $_REQUEST['mode'] ?? 'write';
$wr_id       = $_REQUEST['wr_id'] ?? '';
$bo_table    = $_REQUEST['bo_table'] ?? '';
$write       = [];
$editor_type = 'builder'; // 기본값
if ($mode == 'modify' && $wr_id && $bo_table) {
    $write = sql_fetch("SELECT * FROM {$g5['write_prefix']}{$bo_table} WHERE wr_id='$wr_id'");
    $editor_type = ($write['wr_1'] === 'editor') ? 'editor' : 'builder';
}

$board_categories = [];
foreach ($dm_boards as $table => $data) {
    $ct = $g5['write_prefix'].$table.'_category';
    $tc = sql_query("SHOW TABLES LIKE '{$ct}'", false);
    if ($tc && sql_num_rows($tc) > 0) {
        $cr = sql_query("SELECT ca_id,ca_name FROM {$ct} ORDER BY ca_order,ca_id", false);
        if ($cr) { $board_categories[$table]=[]; while($c=sql_fetch_array($cr)) $board_categories[$table][]=['id'=>$c['ca_id'],'name'=>$c['ca_name']]; }
    }
}

$existing_data = '';
if (!empty($write['wr_content']) && $editor_type === 'builder') {
    $d = json_decode(stripslashes($write['wr_content']), true);
    if ($d) $existing_data = json_encode($d);
}
$existing_html       = ($editor_type === 'editor') ? ($write['wr_content'] ?? '') : '';
$existing_anchor_map = ($editor_type === 'editor' && !empty($write['wr_3'])) ? $write['wr_3'] : '{}';
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= ($mode=='modify') ? '콘텐츠 수정' : '새 콘텐츠 작성' ?></title>
<script src="https://cdn.ckeditor.com/ckeditor5/40.0.0/classic/ckeditor.js"></script>
<style>
:root {
  --main:#000136; --sub:#25456B; --sub2:#99B5D7;
  --light:#F0F3F6; --point:#FABE00; --point2:#DD9700; --dark:#2c2c2c;
  --ui-bg:#000b1e; --ui-s1:#001030; --ui-s2:#00194a; --ui-s3:#002060;
  --ui-border:#1a3060; --ui-border2:#25456B;
  --ui-text:#dce8f8; --ui-text2:#7a9cc8; --ui-text3:#3a5a8a;
  --ui-accent:#FABE00; --ui-accent2:#99B5D7; --ui-danger:#ff6b7a;
  --cv-bg:#eef1f6; --cv-surface:#ffffff; --cv-border:#dde3ee; --cv-text:#1a1a2e; --cv-muted:#8090b0;
}
*{box-sizing:border-box;margin:0;padding:0}
html,body{height:100%;font-family:'Pretendard',-apple-system,sans-serif;background:var(--ui-bg);color:var(--ui-text);overflow:hidden}

/* ══ 에디터 타입 토글 ══ */
.mode-toggle{display:flex;align-items:center;background:var(--ui-s2);border:1px solid var(--ui-border2);border-radius:8px;padding:3px;gap:0;flex-shrink:0}
.mode-toggle-btn{padding:4px 12px;border-radius:6px;border:none;background:transparent;color:var(--ui-text3);font-size:11px;font-weight:700;cursor:pointer;font-family:inherit;transition:all .15s;display:flex;align-items:center;gap:5px;white-space:nowrap}
.mode-toggle-btn.active{background:var(--ui-accent);color:#000}
.mode-toggle-btn:not(.active):hover{color:var(--ui-text)}

/* ══ 탑바 ══ */
#topbar{height:52px;background:var(--ui-s1);border-bottom:1px solid var(--ui-border);display:flex;align-items:center;padding:0 14px;gap:8px;flex-shrink:0;position:relative;z-index:100}
.tb-logo{font-size:12px;font-weight:800;display:flex;align-items:center;gap:7px;flex-shrink:0}
.tb-logo-mark{width:28px;height:28px;border-radius:7px;background:linear-gradient(135deg,var(--point),var(--point2));display:flex;align-items:center;justify-content:center;font-size:13px}
.tb-sep{width:1px;height:20px;background:var(--ui-border);flex-shrink:0}
.tb-sel{background:var(--ui-s2);border:1px solid var(--ui-border2);border-radius:7px;color:var(--ui-text);font-size:12px;padding:5px 9px;font-family:inherit;outline:none;cursor:pointer;transition:border-color .15s;flex-shrink:0}
.tb-sel:focus{border-color:var(--ui-accent)}
.tb-sel option{background:var(--ui-s1)}
.tb-inp{background:var(--ui-s2);border:1px solid var(--ui-border2);border-radius:7px;color:var(--ui-text);font-size:13px;font-weight:600;padding:5px 11px;font-family:inherit;outline:none;transition:border-color .15s;flex:1;min-width:0}
.tb-inp:focus{border-color:var(--ui-accent)}
.tb-inp::placeholder{color:var(--ui-text3)}
.tb-btn{display:flex;align-items:center;gap:5px;padding:5px 11px;border-radius:7px;background:var(--ui-s2);border:1px solid var(--ui-border2);color:var(--ui-text2);font-size:11px;font-weight:700;cursor:pointer;font-family:inherit;transition:all .15s;white-space:nowrap;flex-shrink:0}
.tb-btn:hover{border-color:var(--ui-accent2);color:var(--ui-text)}
.tb-btn.accent{background:var(--ui-accent);border-color:var(--ui-accent);color:#000;font-weight:800}
.tb-btn.accent:hover{background:var(--point2);border-color:var(--point2)}
.tb-btn.ghost{border-color:transparent;background:transparent}
.tb-btn.ghost:hover{background:var(--ui-s2);border-color:var(--ui-border)}
.tb-icon{width:30px;height:30px;display:flex;align-items:center;justify-content:center;border-radius:6px;border:1px solid var(--ui-border);background:none;color:var(--ui-text3);cursor:pointer;font-size:14px;transition:all .15s;font-family:inherit;flex-shrink:0}
.tb-icon:hover{background:var(--ui-s2);color:var(--ui-text)}

/* ══ 앱 레이아웃 ══ */
#app{display:flex;height:calc(100vh - 52px)}

/* ══ LEFT PANEL (빌더 전용) ══ */
#left-panel{width:200px;flex-shrink:0;background:var(--ui-s1);border-right:1px solid var(--ui-border);display:flex;flex-direction:column;overflow:hidden;transition:width .2s}
#left-panel.hidden{width:0;overflow:hidden}
.p-tabs{display:flex;border-bottom:1px solid var(--ui-border);flex-shrink:0}
.p-tab{flex:1;padding:9px;text-align:center;font-size:9px;font-weight:700;letter-spacing:.8px;text-transform:uppercase;color:var(--ui-text3);cursor:pointer;border-bottom:2px solid transparent;transition:all .15s}
.p-tab.active{color:var(--ui-accent);border-bottom-color:var(--ui-accent)}
.p-body{flex:1;overflow-y:auto;padding:10px;display:flex;flex-direction:column;gap:3px}
.p-body::-webkit-scrollbar{width:3px}
.p-body::-webkit-scrollbar-thumb{background:var(--ui-border2);border-radius:2px}
.p-sec{font-size:9px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:var(--ui-text3);margin:10px 0 3px 2px}
.pal-item{display:flex;align-items:center;gap:8px;padding:7px 9px;border-radius:7px;cursor:grab;border:1px solid transparent;background:var(--ui-s2);transition:all .15s;user-select:none}
.pal-item:hover{background:var(--ui-s3);border-color:var(--ui-border2);transform:translateX(2px)}
.pal-item:active{cursor:grabbing}
.pal-item.dragging-src{opacity:.35}
.pi-ic{width:26px;height:26px;border-radius:6px;display:flex;align-items:center;justify-content:center;font-size:12px;flex-shrink:0}
.pi-nm{font-size:11px;font-weight:700;color:var(--ui-text)}
.pi-ds{font-size:9px;color:var(--ui-text3);margin-top:1px}
.pi-gp{font-size:11px;color:var(--ui-text3);opacity:0;transition:opacity .15s;margin-left:auto}
.pal-item:hover .pi-gp{opacity:1}
#add-row-btn{margin:8px 10px 10px;padding:10px;border-radius:9px;flex-shrink:0;background:linear-gradient(135deg,var(--sub),var(--main));border:1px solid var(--ui-accent);color:var(--ui-accent);font-size:12px;font-weight:800;cursor:pointer;font-family:inherit;display:flex;align-items:center;justify-content:center;gap:6px;transition:all .15s}
#add-row-btn:hover{background:var(--ui-accent);color:#000;transform:translateY(-1px);box-shadow:0 4px 16px rgba(250,190,0,.3)}

/* ══ CANVAS (빌더) ══ */
#builder-canvas{flex:1;overflow-y:auto;background:var(--cv-bg);padding:20px;display:flex;flex-direction:column;gap:12px;background-image:radial-gradient(circle at 1px 1px,rgba(0,1,54,.06) 1px,transparent 0);background-size:22px 22px}
#builder-canvas::-webkit-scrollbar{width:5px}
#builder-canvas::-webkit-scrollbar-thumb{background:#b0bcd0;border-radius:3px}
#canvas-empty{margin:auto;text-align:center;padding:40px}
.empty-ic{width:64px;height:64px;margin:0 auto 14px;background:linear-gradient(135deg,#dde3f0,#c8d2e8);border-radius:18px;display:flex;align-items:center;justify-content:center;font-size:28px}
#canvas-empty h3{font-size:15px;font-weight:800;color:var(--cv-text);margin-bottom:6px}
#canvas-empty p{font-size:12px;color:var(--cv-muted);line-height:1.6}

/* ══ EDITOR 모드 ══ */
#editor-panel{flex:1;overflow-y:auto;background:var(--cv-bg);padding:24px;display:flex;flex-direction:column;gap:0}
#editor-panel.hidden{display:none}
#builder-area{display:flex;flex:1;overflow:hidden}
#builder-area.hidden{display:none}
.ck-editor__editable{min-height:calc(100vh - 160px) !important;border-radius:0 0 10px 10px !important;font-family:'Pretendard',-apple-system,sans-serif !important;font-size:15px !important;line-height:1.75 !important;color:#1a1a2e !important}
.ck.ck-editor{border-radius:10px;overflow:hidden;box-shadow:0 2px 16px rgba(0,0,0,.08);width:100%;max-width:900px;margin:0 auto}

/* ══ Row ══ */
.builder-row{background:var(--cv-surface);border:2px solid var(--cv-border);border-radius:12px;transition:border-color .15s}
.builder-row:hover{border-color:#b0b8d0}
.builder-row.row-sel{border-color:var(--sub);box-shadow:0 0 0 3px rgba(37,69,107,.12)}
.builder-row.drag-row{border-color:var(--point)!important;box-shadow:0 0 0 3px rgba(250,190,0,.15)!important}
/* 섹션 ID 배지 */
.row-sec-badge{font-size:9px;font-weight:700;padding:2px 6px;border-radius:4px;background:rgba(250,190,0,.12);color:var(--point2);border:1px solid rgba(250,190,0,.3);max-width:100px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.row-hdr{display:flex;align-items:center;gap:5px;padding:7px 12px;background:#f4f6fb;border-bottom:1.5px solid var(--cv-border);border-radius:10px 10px 0 0;cursor:pointer}
.row-hdr:hover{background:#edf0f8}
.rh-grip{color:#b0b8d0;font-size:13px;cursor:grab;flex-shrink:0}
.rh-grip:active{cursor:grabbing}
.rh-lbl{font-size:10px;font-weight:700;color:#8090b0;letter-spacing:.5px;text-transform:uppercase;flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.pre-btns{display:flex;gap:2px}
.pre-btn{padding:2px 7px;border-radius:4px;border:1.5px solid #d8def0;background:#fff;font-size:10px;font-weight:700;color:#8090b0;cursor:pointer;transition:all .12s;font-family:inherit}
.pre-btn:hover{border-color:var(--sub);color:var(--sub)}
.pre-btn.active{background:var(--sub);border-color:var(--sub);color:#fff}
.row-acts{display:flex;gap:2px}
.row-act{width:22px;height:22px;border-radius:4px;border:none;background:transparent;color:#b0b8d0;font-size:11px;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all .12s;font-family:inherit}
.row-act:hover{background:#ffe0e8;color:#c92a2a}
.row-act.mv:hover{background:#e8f0ff;color:var(--sub)}
.row-cols{display:flex;min-height:90px}

/* ══ Column ══ */
.builder-col{flex:1;min-height:90px;border-right:1.5px dashed #dde3f0;position:relative;display:flex;flex-direction:column;gap:6px;padding:10px;transition:background .12s}
.builder-col:last-child{border-right:none}
.builder-col.col-drop{background:rgba(153,181,215,.1);outline:2px dashed rgba(37,69,107,.5);outline-offset:-3px}
.col-hint{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;pointer-events:none}
.col-hint-box{width:32px;height:32px;border:2px dashed #c8d0e8;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:15px;color:#b0bcd8}
.col-hint span{font-size:9px;font-weight:600;color:#b0bcd8}
.col-badge{position:absolute;bottom:4px;right:5px;font-size:8px;font-weight:700;color:#c8d0e8;background:#f0f3f8;border-radius:3px;padding:1px 4px;pointer-events:none}
.col-picker{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);background:var(--ui-s1);border:1px solid var(--ui-border2);border-radius:12px;padding:12px;z-index:300;width:196px;box-shadow:0 8px 32px rgba(0,0,30,.6);animation:popIn .15s ease}
@keyframes popIn{from{opacity:0;transform:translate(-50%,-48%) scale(.95)}to{opacity:1;transform:translate(-50%,-50%) scale(1)}}
.cp-title{font-size:9px;font-weight:700;color:var(--ui-text3);letter-spacing:1px;text-transform:uppercase;margin-bottom:8px;padding-bottom:6px;border-bottom:1px solid var(--ui-border)}
.cp-grid{display:grid;grid-template-columns:1fr 1fr;gap:3px}
.cp-btn{display:flex;flex-direction:column;align-items:center;gap:3px;padding:7px 5px;border-radius:6px;border:1px solid var(--ui-border);background:var(--ui-s2);color:var(--ui-text2);font-size:10px;font-weight:700;cursor:pointer;transition:all .12s;font-family:inherit}
.cp-btn:hover{background:var(--ui-s3);border-color:var(--ui-accent);color:var(--ui-text)}
.cp-btn span:first-child{font-size:14px}

/* ══ Content Block ══ */
.content-block{background:var(--cv-surface);border:1.5px solid var(--cv-border);border-radius:8px;overflow:hidden;position:relative;transition:border-color .15s,box-shadow .15s}
.content-block:hover{border-color:#99b5d7;box-shadow:0 2px 10px rgba(37,69,107,.1)}
.content-block.block-sel{border-color:var(--sub)!important;box-shadow:0 0 0 2px rgba(37,69,107,.2)!important}
.content-block.block-drag{opacity:.3;pointer-events:none}
.content-block.block-drag-over{outline:2px dashed var(--point);outline-offset:2px}
.block-bar{display:flex;align-items:center;gap:5px;padding:4px 8px;cursor:grab;border-bottom:1px solid #f0f3f8;user-select:none}
.block-bar:active{cursor:grabbing}
.bb-dot{width:7px;height:7px;border-radius:50%;flex-shrink:0}
.bb-nm{font-size:9px;font-weight:700;color:#8090b0;letter-spacing:.5px;text-transform:uppercase;flex:1}
.bb-acts{display:flex;gap:1px}
.bb-act{width:18px;height:18px;border:none;background:transparent;color:#c0c8d8;cursor:pointer;border-radius:3px;font-size:10px;line-height:1;padding:0;transition:all .12s;font-family:inherit;display:flex;align-items:center;justify-content:center}
.bb-act:hover{background:#ffe0e8;color:#c92a2a}
.bb-act.mv:hover{background:#e8f0ff;color:var(--sub)}
.block-body{padding:8px 10px}
.block-body [contenteditable]{outline:none;width:100%;line-height:1.65;color:var(--cv-text);font-family:'Pretendard',-apple-system,sans-serif;min-height:20px}
.block-body [contenteditable]:empty::before{content:attr(data-ph);color:#b8c4d8;pointer-events:none}
.bt-paragraph .block-bar{background:#f5f8ff}.bt-paragraph .bb-dot{background:#74c0fc}
.bt-h2 .block-bar{background:#fff5f8}.bt-h2 .bb-dot{background:#f783ac}
.bt-h3 .block-bar{background:#fff5f8}.bt-h3 .bb-dot{background:#faa2c1}
.bt-h4 .block-bar{background:#fff5f8}.bt-h4 .bb-dot{background:#fcc2d7}
.bt-quote .block-bar{background:#fdf5ff}.bt-quote .bb-dot{background:#da77f2}
.bt-list .block-bar{background:#f0fff8}.bt-list .bb-dot{background:#63e6be}
.bt-image .block-bar{background:#fff8f0}.bt-image .bb-dot{background:#ffa94d}
.bt-warning .block-bar{background:#fffdf0}.bt-warning .bb-dot{background:#FABE00}
.bt-delimiter .block-bar{background:#f8fce8}.bt-delimiter .bb-dot{background:#a9e34b}
.bt-table .block-bar{background:#f0f5ff}.bt-table .bb-dot{background:#4dabf7}
.bt-button .block-bar{background:#f3f0ff}.bt-button .bb-dot{background:#9775fa}
.b-quote{border-left:3px solid var(--sub2);background:#f8fbff;border-radius:0 6px 6px 0;padding:8px 12px;font-style:italic;color:var(--sub)}
.b-warning{background:#fffbf0;border:1.5px solid var(--point);border-radius:6px;padding:10px 12px}
.b-warning .w-title{font-weight:800;font-size:13px;color:var(--point2);margin-bottom:4px}
.b-delimiter{text-align:center;padding:8px;color:#b8c8d8;letter-spacing:8px;font-size:16px}
.b-img-drop{border:2px dashed #c8d4e8;border-radius:8px;padding:18px;text-align:center;cursor:pointer;transition:all .15s;color:#8090b0;font-size:12px;display:flex;flex-direction:column;align-items:center;gap:6px}
.b-img-drop:hover{border-color:var(--point);color:var(--point2);background:#fffcf0}
.b-img-preview{max-width:100%;border-radius:6px;display:block}
.b-img-alt{width:100%;margin-top:6px;padding:5px 8px;border:1.5px solid var(--cv-border);border-radius:6px;font-size:11px;font-family:inherit;color:var(--sub);outline:none;transition:border-color .15s}
.b-img-alt:focus{border-color:var(--point)}
.b-list-ul{list-style:disc;padding-left:18px}
.b-list-ul li{margin-bottom:3px}
.b-list-ul li [contenteditable]{font-size:14px;min-width:40px;display:inline-block;width:calc(100% - 8px)}
.b-list-add{display:inline-flex;align-items:center;gap:4px;margin-top:6px;padding:3px 9px;border-radius:5px;border:1.5px dashed #c8d4e8;background:transparent;color:#8090b0;font-size:11px;cursor:pointer;transition:all .12s;font-family:inherit}
.b-list-add:hover{border-color:#63e6be;color:#087f5b}
.b-tbl-wrap{overflow-x:auto}
.b-tbl-wrap table{width:100%;border-collapse:collapse;font-size:12px}
.b-tbl-wrap td{border:1.5px solid var(--cv-border);padding:5px 8px;min-width:50px}
.b-tbl-wrap td [contenteditable]{outline:none;min-height:18px;font-size:12px}
.b-tbl-wrap tr:first-child td{background:#f4f7fc;font-weight:700}
.tbl-btns{display:flex;gap:4px;margin-top:4px}
.tbl-btn{padding:2px 8px;border-radius:4px;border:1.5px dashed #c8d4e8;background:transparent;color:#8090b0;font-size:10px;cursor:pointer;font-family:inherit;transition:all .12s}
.tbl-btn:hover{border-color:var(--sub2);color:var(--sub)}
.b-btn-wrap{padding:4px 0}
.b-btn-el{display:inline-flex;align-items:center;padding:9px 20px;border-radius:8px;background:linear-gradient(135deg,var(--main),var(--sub));color:#fff;font-size:13px;font-weight:700;cursor:text}
.b-btn-el [contenteditable]{color:#fff;min-width:60px}
.b-btn-el [contenteditable]:empty::before{color:rgba(255,255,255,.5)}

/* ══ RIGHT PANEL ══ */
#right-panel{width:224px;flex-shrink:0;background:var(--ui-s1);border-left:1px solid var(--ui-border);display:flex;flex-direction:column;overflow:hidden;transition:width .2s}
#right-panel.hidden{width:0;overflow:hidden}
.rp-hdr{display:flex;align-items:center;justify-content:space-between;padding:10px 12px;border-bottom:1px solid var(--ui-border);flex-shrink:0}
.rp-hdr-title{font-size:10px;font-weight:700;letter-spacing:.8px;text-transform:uppercase;color:var(--ui-text3)}
.rp-hdr-badge{font-size:9px;font-weight:700;padding:2px 7px;border-radius:10px;background:var(--ui-s2);border:1px solid var(--ui-border2);color:var(--ui-text2)}
.rp-body{flex:1;overflow-y:auto;display:flex;flex-direction:column}
.rp-body::-webkit-scrollbar{width:3px}
.rp-body::-webkit-scrollbar-thumb{background:var(--ui-border2);border-radius:2px}
.rp-section{border-bottom:1px solid var(--ui-border);padding:10px 12px}
.rp-sec-title{font-size:9px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:var(--ui-text3);margin-bottom:8px;display:flex;align-items:center;gap:5px}
.rp-sec-title::after{content:'';flex:1;height:1px;background:var(--ui-border)}
.rp-row{display:flex;align-items:center;gap:6px;margin-bottom:6px}
.rp-row:last-child{margin-bottom:0}
.rp-lbl{font-size:10px;color:var(--ui-text2);flex:1;white-space:nowrap}
.rp-num{width:52px;background:var(--ui-s2);border:1px solid var(--ui-border2);border-radius:5px;color:var(--ui-text);font-size:11px;padding:4px 6px;text-align:center;font-family:inherit;outline:none;transition:border-color .15s}
.rp-num:focus{border-color:var(--ui-accent)}
.rp-sel{flex:1;background:var(--ui-s2);border:1px solid var(--ui-border2);border-radius:5px;color:var(--ui-text);font-size:10px;padding:4px 5px;font-family:inherit;outline:none;cursor:pointer;transition:border-color .15s}
.rp-sel:focus{border-color:var(--ui-accent)}
.rp-sel option{background:var(--ui-s1)}
.rp-color-wrap{display:flex;align-items:center;gap:5px}
.rp-color-swatch{width:22px;height:22px;border-radius:5px;border:1.5px solid var(--ui-border2);cursor:pointer;flex-shrink:0;overflow:hidden;position:relative}
.rp-color-swatch input[type=color]{position:absolute;inset:-4px;width:calc(100%+8px);height:calc(100%+8px);border:none;cursor:pointer;opacity:0}
.rp-color-hex{flex:1;background:var(--ui-s2);border:1px solid var(--ui-border2);border-radius:5px;color:var(--ui-text);font-size:10px;padding:4px 6px;font-family:'Courier New',monospace;outline:none;transition:border-color .15s}
.rp-color-hex:focus{border-color:var(--ui-accent)}
.rp-align-group{display:flex;gap:2px;flex:1}
.rp-align-btn{flex:1;height:26px;border-radius:5px;border:1px solid var(--ui-border2);background:var(--ui-s2);color:var(--ui-text3);font-size:12px;cursor:pointer;transition:all .12s;font-family:inherit;display:flex;align-items:center;justify-content:center}
.rp-align-btn:hover{border-color:var(--ui-accent2);color:var(--ui-text)}
.rp-align-btn.active{background:var(--sub);border-color:var(--sub);color:#fff}
.rp-weight-group{display:flex;gap:2px;flex:1}
.rp-w-btn{flex:1;height:24px;border-radius:4px;border:1px solid var(--ui-border2);background:var(--ui-s2);color:var(--ui-text3);font-size:10px;cursor:pointer;transition:all .12s;font-family:inherit;display:flex;align-items:center;justify-content:center;font-weight:600}
.rp-w-btn:hover{border-color:var(--ui-accent2);color:var(--ui-text)}
.rp-w-btn.active{background:var(--sub);border-color:var(--sub);color:#fff}
.rp-empty{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:24px;color:var(--ui-text3)}
.rp-empty-ic{font-size:28px;margin-bottom:10px;opacity:.5}
.rp-empty p{font-size:11px;line-height:1.7}
.rp-act-btn{width:100%;padding:6px;border-radius:6px;border:1px solid var(--ui-border2);background:transparent;color:var(--ui-text2);font-size:11px;cursor:pointer;font-family:inherit;font-weight:600;transition:all .12s;text-align:center;margin-bottom:3px}
.rp-act-btn:hover{background:var(--ui-s2);color:var(--ui-text)}
.rp-act-btn.danger{border-color:rgba(255,107,122,.3);color:var(--ui-danger)}
.rp-act-btn.danger:hover{background:rgba(255,107,122,.1)}

/* 섹션 ID 인풋 */
.rp-text-inp{width:100%;background:var(--ui-s2);border:1px solid var(--ui-border2);border-radius:5px;color:var(--ui-text);font-size:11px;padding:5px 8px;font-family:'Courier New',monospace;outline:none;transition:border-color .15s}
.rp-text-inp:focus{border-color:var(--ui-accent)}
.rp-text-inp::placeholder{color:var(--ui-text3);font-family:inherit}

/* SEO 서랍 */
#seo-drawer{position:fixed;right:0;top:52px;bottom:0;width:264px;background:var(--ui-s1);border-left:1px solid var(--ui-border2);transform:translateX(100%);transition:transform .25s cubic-bezier(.4,0,.2,1);z-index:400;display:flex;flex-direction:column;overflow:hidden}
#seo-drawer.open{transform:translateX(0)}
.sd-hdr{display:flex;align-items:center;justify-content:space-between;padding:13px 14px;border-bottom:1px solid var(--ui-border);flex-shrink:0}
.sd-hdr h3{font-size:12px;font-weight:800;color:var(--ui-text);display:flex;align-items:center;gap:6px}
.sd-close{background:none;border:none;color:var(--ui-text3);font-size:17px;cursor:pointer;font-family:inherit}
.sd-body{flex:1;overflow-y:auto;padding:14px;display:flex;flex-direction:column;gap:14px}
.sd-label{font-size:10px;font-weight:700;color:var(--ui-text2);margin-bottom:4px;display:block}
.sd-ta{width:100%;background:var(--ui-s2);border:1px solid var(--ui-border2);border-radius:7px;color:var(--ui-text);font-size:12px;padding:8px 10px;font-family:inherit;outline:none;resize:vertical;transition:border-color .15s}
.sd-ta:focus{border-color:var(--ui-accent)}
.sd-cnt{font-size:10px;color:var(--ui-text3);text-align:right;margin-top:3px}
.sd-cnt.warn{color:var(--ui-danger)}
.sd-hint{font-size:10px;color:var(--ui-text3);line-height:1.6;background:var(--ui-s2);border-radius:7px;padding:10px}
.seo-check{display:flex;align-items:center;gap:7px;font-size:11px;padding:4px 0}

/* ghost / toast */
#drag-ghost{position:fixed;pointer-events:none;z-index:9999;padding:6px 12px;background:var(--sub);color:#fff;border-radius:7px;font-size:11px;font-weight:700;font-family:inherit;box-shadow:0 4px 18px rgba(0,1,54,.4);display:none;align-items:center;gap:5px;white-space:nowrap;border:1px solid var(--ui-accent)}
#drag-ghost.show{display:flex}
#toast{position:fixed;bottom:18px;left:50%;transform:translateX(-50%) translateY(60px);background:var(--ui-s1);color:var(--ui-text);border:1px solid var(--ui-border2);border-radius:10px;padding:9px 16px;font-size:12px;font-weight:600;font-family:inherit;z-index:9998;transition:transform .3s cubic-bezier(.34,1.56,.64,1);display:flex;align-items:center;gap:6px;pointer-events:none}
#toast.show{transform:translateX(-50%) translateY(0)}

/* 레이아웃 모달 */
#layout-modal{display:none;position:fixed;inset:0;background:rgba(0,4,30,.7);z-index:5000;align-items:center;justify-content:center}
#layout-modal.open{display:flex}
.lm-box{background:var(--ui-s1);border:1px solid var(--ui-border2);border-radius:18px;padding:26px;width:480px;max-height:80vh;overflow-y:auto;animation:popIn .18s ease}
.lm-box h3{font-size:14px;font-weight:800;color:var(--ui-text);margin-bottom:3px}
.lm-box p{font-size:11px;color:var(--ui-text3);margin-bottom:18px}
.lm-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:7px;margin-bottom:18px}
.lm-opt{border:2px solid var(--ui-border2);border-radius:9px;padding:10px 7px;cursor:pointer;text-align:center;transition:all .15s}
.lm-opt:hover,.lm-opt.sel{border-color:var(--ui-accent);background:rgba(250,190,0,.06)}
.lm-prev{display:flex;gap:2px;height:28px;margin-bottom:6px}
.lm-prev span{background:var(--ui-border2);border-radius:3px;flex:1;transition:background .12s}
.lm-opt:hover .lm-prev span,.lm-opt.sel .lm-prev span{background:var(--ui-accent);opacity:.7}
.lm-opt p{font-size:10px;font-weight:700;color:var(--ui-text3)}
.lm-ok{width:100%;padding:11px;border-radius:9px;border:1px solid var(--ui-accent);background:linear-gradient(135deg,var(--sub),var(--main));color:var(--ui-accent);font-size:13px;font-weight:800;cursor:pointer;font-family:inherit}
.lm-ok:hover{background:var(--ui-accent);color:#000}
.struct-item{display:flex;align-items:center;gap:6px;padding:5px 7px;border-radius:5px;background:var(--ui-s2);font-size:11px;color:var(--ui-text2);cursor:pointer;transition:all .12s;margin-bottom:2px}
.struct-item:hover{background:var(--ui-s3);color:var(--ui-text)}
</style>
</head>
<body>

<form id="fwrite" method="post" action="<?= $_SERVER['PHP_SELF'] ?>" style="display:none">
  <input type="hidden" name="mode"         value="<?= $mode ?>">
  <input type="hidden" name="wr_id"        value="<?= $wr_id ?>">
  <input type="hidden" name="bo_table"     id="f_bo_table">
  <input type="hidden" name="category_id"  id="f_category_id">
  <input type="hidden" name="wr_subject"   id="f_wr_subject">
  <input type="hidden" name="wr_seo_desc"  id="f_wr_seo_desc">
  <input type="hidden" name="wr_content"    id="f_wr_content">
  <input type="hidden" name="editor_type"   id="f_editor_type" value="<?= $editor_type ?>">
  <input type="hidden" name="wr_anchor_map" id="f_wr_anchor_map" value="<?= htmlspecialchars($existing_anchor_map) ?>">
</form>

<!-- ══ 탑바 ══ -->
<div id="topbar">
  <div class="tb-logo"><div class="tb-logo-mark">🏗</div>Page Builder</div>
  <div class="tb-sep"></div>

  <!-- 에디터 타입 토글 -->
  <div class="mode-toggle">
    <button class="mode-toggle-btn <?= $editor_type==='builder'?'active':'' ?>" id="toggle-builder" onclick="switchEditorMode('builder')">🏗 빌더</button>
    <button class="mode-toggle-btn <?= $editor_type==='editor'?'active':'' ?>" id="toggle-editor"  onclick="switchEditorMode('editor')">✏️ 에디터</button>
  </div>

  <div class="tb-sep"></div>
  <select id="tb_bo_table" class="tb-sel" onchange="onBoardChange()" <?= ($mode=='modify')?'disabled':'' ?>>
    <option value="">게시판 선택</option>
    <?php foreach ($dm_boards as $table => $data): ?>
      <option value="<?= $table ?>" <?= ($bo_table==$table)?'selected':'' ?>><?= $data['subject'] ?></option>
    <?php endforeach; ?>
  </select>
  <select id="tb_category" class="tb-sel" style="display:none">
    <option value="">카테고리</option>
  </select>
  <input type="text" id="tb_subject" class="tb-inp" placeholder="제목을 입력하세요 *" value="<?= htmlspecialchars($write['wr_subject'] ?? '') ?>">

  <div class="tb-sep"></div>
  <button class="tb-icon" onclick="undoAction()" title="실행취소 Ctrl+Z" id="btn-undo">↩</button>
  <button class="tb-icon" onclick="redoAction()" title="다시실행 Ctrl+Shift+Z" id="btn-redo">↪</button>
  <button class="tb-btn" onclick="toggleSEO()">🔍 SEO</button>
  <button class="tb-btn" id="btn-anchor" onclick="toggleAnchorPanel()" style="display:none">⚓ 목차 ID</button>
  <button class="tb-btn" onclick="previewHTML()">👁 미리보기</button>
  <button class="tb-btn ghost" onclick="goBack()">취소</button>
  <button class="tb-btn accent" onclick="submitForm()"><?= ($mode=='modify') ? '✅ 수정 완료' : '💾 저장' ?></button>
</div>

<!-- ══ 앱 ══ -->
<div id="app">

  <!-- 좌측 (빌더 전용) -->
  <div id="left-panel" class="<?= $editor_type==='editor'?'hidden':'' ?>">
    <div class="p-tabs">
      <div class="p-tab active" onclick="switchTab(this,'blocks')">블록</div>
      <div class="p-tab" onclick="switchTab(this,'structure')">구조</div>
    </div>
    <div class="p-body" id="tab-blocks">
      <div class="p-sec">텍스트</div>
      <div class="pal-item" draggable="true" data-type="paragraph"><div class="pi-ic" style="background:rgba(116,192,252,.12)">📝</div><div><div class="pi-nm">단락</div><div class="pi-ds">본문 텍스트</div></div><span class="pi-gp">⠿</span></div>
      <div class="pal-item" draggable="true" data-type="h2"><div class="pi-ic" style="background:rgba(247,131,172,.12);font-size:11px;font-weight:800;color:#f783ac">H2</div><div><div class="pi-nm">소제목</div><div class="pi-ds">H2 태그</div></div><span class="pi-gp">⠿</span></div>
      <div class="pal-item" draggable="true" data-type="h3"><div class="pi-ic" style="background:rgba(250,162,193,.12);font-size:10px;font-weight:800;color:#faa2c1">H3</div><div><div class="pi-nm">소소제목</div><div class="pi-ds">H3 태그</div></div><span class="pi-gp">⠿</span></div>
      <div class="pal-item" draggable="true" data-type="h4"><div class="pi-ic" style="background:rgba(252,194,215,.12);font-size:10px;font-weight:700;color:#fcc2d7">H4</div><div><div class="pi-nm">작은제목</div><div class="pi-ds">H4 태그</div></div><span class="pi-gp">⠿</span></div>
      <div class="pal-item" draggable="true" data-type="quote"><div class="pi-ic" style="background:rgba(153,181,215,.12)">💬</div><div><div class="pi-nm">인용구</div><div class="pi-ds">Quote</div></div><span class="pi-gp">⠿</span></div>
      <div class="p-sec">미디어 / 구조</div>
      <div class="pal-item" draggable="true" data-type="image"><div class="pi-ic" style="background:rgba(255,169,77,.12)">🖼</div><div><div class="pi-nm">이미지</div><div class="pi-ds">파일 업로드</div></div><span class="pi-gp">⠿</span></div>
      <div class="pal-item" draggable="true" data-type="list"><div class="pi-ic" style="background:rgba(99,230,190,.12)">📋</div><div><div class="pi-nm">목록</div><div class="pi-ds">불릿 리스트</div></div><span class="pi-gp">⠿</span></div>
      <div class="pal-item" draggable="true" data-type="warning"><div class="pi-ic" style="background:rgba(250,190,0,.12)">⚠️</div><div><div class="pi-nm">주의박스</div><div class="pi-ds">강조 메시지</div></div><span class="pi-gp">⠿</span></div>
      <div class="pal-item" draggable="true" data-type="delimiter"><div class="pi-ic" style="background:rgba(169,227,75,.12);font-size:16px;color:#a9e34b">—</div><div><div class="pi-nm">구분선</div><div class="pi-ds">섹션 구분</div></div><span class="pi-gp">⠿</span></div>
      <div class="pal-item" draggable="true" data-type="table"><div class="pi-ic" style="background:rgba(77,171,247,.12)">📊</div><div><div class="pi-nm">표</div><div class="pi-ds">테이블</div></div><span class="pi-gp">⠿</span></div>
      <div class="pal-item" draggable="true" data-type="button"><div class="pi-ic" style="background:rgba(151,117,250,.12)">🔘</div><div><div class="pi-nm">버튼</div><div class="pi-ds">CTA 버튼</div></div><span class="pi-gp">⠿</span></div>
    </div>
    <div class="p-body" id="tab-structure" style="display:none">
      <div class="p-sec">페이지 구조</div>
      <div id="struct-tree"><div style="font-size:11px;color:var(--ui-text3);text-align:center;padding:14px 0">컨테이너를 추가하면<br>여기에 표시됩니다.</div></div>
    </div>
    <button id="add-row-btn" onclick="openLayoutModal()">
      <svg width="13" height="13" viewBox="0 0 13 13" fill="none"><rect x=".75" y=".75" width="11.5" height="11.5" rx="2" stroke="currentColor" stroke-width="1.4"/><path d="M6.5 3.5v6M3.5 6.5h6" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg>
      컨테이너 추가
    </button>
  </div>

  <!-- 빌더 캔버스 -->
  <div id="builder-area" class="<?= $editor_type==='editor'?'hidden':'' ?>">
    <div id="builder-canvas">
      <div id="canvas-empty">
        <div class="empty-ic">🏗️</div>
        <h3>시작해볼까요?</h3>
        <p>왼쪽 하단 <strong>컨테이너 추가</strong>를 클릭하거나<br>블록을 여기로 드래그하세요.</p>
      </div>
    </div>
    <!-- 우측 속성 패널 -->
    <div id="right-panel">
      <div class="rp-hdr">
        <span class="rp-hdr-title">속성 패널</span>
        <span class="rp-hdr-badge" id="rp-badge">—</span>
      </div>
      <div class="rp-body" id="rp-body">
        <div class="rp-empty"><div class="rp-empty-ic">🖱️</div><p>블록이나 컨테이너를<br>클릭하면 속성이<br>표시됩니다.</p></div>
      </div>
    </div>
  </div>

  <!-- CKEditor 패널 -->
  <div id="editor-panel" class="<?= $editor_type!=='editor'?'hidden':'' ?>">
    <div id="editor-wrap">
      <div id="editor"><?= stripslashes($existing_html) ?></div>
    </div>
  </div>
</div>

<!-- ══ 앵커 ID 드로어 (에디터 모드 전용) ══ -->
<div id="anchor-drawer">
  <div class="sd-hdr">
    <h3>⚓ 목차 ID 관리</h3>
    <button class="sd-close" onclick="toggleAnchorPanel()">✕</button>
  </div>
  <div class="sd-body">
    <div class="sd-hint" style="margin-bottom:12px">
      에디터의 H2 제목마다 앵커 ID를 지정하면<br>
      프론트 페이지에서 목차로 표시됩니다.<br>
      <strong>스캔</strong> 버튼으로 현재 H2 목록을 불러오세요.
    </div>
    <button class="lm-ok" style="margin-bottom:14px" onclick="scanH2s()">🔍 H2 스캔</button>
    <div id="anchor-list"></div>
  </div>
</div>

<style>
#anchor-drawer{position:fixed;right:0;top:52px;bottom:0;width:280px;background:var(--ui-s1);border-left:1px solid var(--ui-border2);transform:translateX(100%);transition:transform .25s cubic-bezier(.4,0,.2,1);z-index:401;display:flex;flex-direction:column;overflow:hidden}
#anchor-drawer.open{transform:translateX(0)}
.anchor-item{background:var(--ui-s2);border:1px solid var(--ui-border);border-radius:8px;padding:10px 12px;margin-bottom:8px}
.anchor-h2-label{font-size:11px;font-weight:700;color:var(--ui-text);margin-bottom:6px;word-break:break-all;line-height:1.4}
.anchor-id-row{display:flex;align-items:center;gap:6px}
.anchor-id-prefix{font-size:11px;color:var(--ui-text3);flex-shrink:0}
.anchor-id-inp{flex:1;background:var(--ui-bg);border:1px solid var(--ui-border2);border-radius:5px;color:var(--ui-accent);font-size:11px;padding:4px 8px;font-family:'Courier New',monospace;outline:none;transition:border-color .15s}
.anchor-id-inp:focus{border-color:var(--ui-accent)}
.anchor-id-inp::placeholder{color:var(--ui-text3);font-family:inherit}
.anchor-empty{font-size:11px;color:var(--ui-text3);text-align:center;padding:20px 0;line-height:1.7}
</style>

<!-- SEO 서랍 -->
<div id="seo-drawer">
  <div class="sd-hdr"><h3>🔍 SEO 설정</h3><button class="sd-close" onclick="toggleSEO()">✕</button></div>
  <div class="sd-body">
    <div>
      <label class="sd-label">메타 설명 (검색 결과 요약)</label>
      <textarea id="seo_desc" class="sd-ta" rows="4" maxlength="200" placeholder="이 페이지의 핵심 내용을 2~3문장으로 요약하세요." oninput="updateSeoCount()"><?= htmlspecialchars($write['wr_2'] ?? '') ?></textarea>
      <div class="sd-cnt" id="seo_cnt">0 / 160</div>
      <div class="sd-hint">💡 권장 80~160자.</div>
    </div>
    <div>
      <div class="sd-label">SEO 체크리스트</div>
      <div id="seo-checklist"></div>
    </div>
  </div>
</div>

<div id="drag-ghost"></div>
<div id="toast"><span id="t-msg"></span></div>

<div id="layout-modal">
  <div class="lm-box">
    <h3>📐 컨테이너 레이아웃</h3>
    <p>원하는 컬럼 구조를 선택하세요.</p>
    <div class="lm-grid" id="lm-grid"></div>
    <button class="lm-ok" onclick="confirmLayout()">이 레이아웃으로 추가 →</button>
  </div>
</div>

<script>
/* ════════════════════════════════════════
   PHP DATA
════════════════════════════════════════ */
const PHP_MODE       = "<?= $mode ?>";
const PHP_BO_TABLE   = "<?= $bo_table ?>";
const PHP_UPLOAD_URL = "<?= $_SERVER['PHP_SELF'] ?>";
const PHP_EXISTING   = <?= !empty($existing_data) ? $existing_data : 'null' ?>;
const PHP_BOARD_CATS = <?= json_encode($board_categories) ?>;
const PHP_SAVED_CAT  = "<?= $write['wr_10'] ?? '' ?>";
let   EDITOR_MODE    = "<?= $editor_type ?>"; // 'builder' | 'editor'

/* ════════════════════════════════════════
   CKEditor 초기화
════════════════════════════════════════ */
let ckInstance = null;
function initCKEditor() {
  if (ckInstance) return;
  ClassicEditor.create(document.querySelector('#editor'), {
    language: 'ko',
    ckfinder: { uploadUrl: PHP_UPLOAD_URL },
    toolbar: ['heading','|','bold','italic','link','bulletedList','numberedList','|','imageUpload','blockQuote','insertTable','|','undo','redo']
  }).then(editor => { ckInstance = editor; }).catch(console.error);
}

/* ════════════════════════════════════════
   에디터 모드 전환
════════════════════════════════════════ */
function switchEditorMode(mode) {
  EDITOR_MODE = mode;
  document.getElementById('f_editor_type').value = mode;

  const isBuilder = mode === 'builder';
  document.getElementById('left-panel').classList.toggle('hidden', !isBuilder);
  document.getElementById('builder-area').classList.toggle('hidden', !isBuilder);
  document.getElementById('right-panel').classList.toggle('hidden', !isBuilder);
  document.getElementById('editor-panel').classList.toggle('hidden', isBuilder);
  document.getElementById('btn-undo').style.opacity = isBuilder ? '' : '.35';
  document.getElementById('btn-redo').style.opacity = isBuilder ? '' : '.35';

  document.getElementById('toggle-builder').classList.toggle('active', isBuilder);
  document.getElementById('toggle-editor').classList.toggle('active', !isBuilder);

  document.getElementById('btn-anchor').style.display = isBuilder ? 'none' : '';
  if (!isBuilder) initCKEditor();
  toast(isBuilder ? '🏗 빌더 모드' : '✏️ 에디터 모드');
}

/* ════════════════════════════════════════
   STATE (빌더)
════════════════════════════════════════ */
let pageData = { rows: [] };
let hist = [], redoStack = [];
let idc = 1;
const uid = () => 'i' + (idc++) + '_' + Math.random().toString(36).slice(2,5);
let selectedBlockId = null;

const LAYOUTS = [
  {l:'1컬', c:[12]},{l:'½+½', c:[6,6]},{l:'⅓×3', c:[4,4,4]},{l:'¼×4', c:[3,3,3,3]},
  {l:'⅔+⅓', c:[8,4]},{l:'⅓+⅔', c:[4,8]},{l:'¾+¼', c:[9,3]},{l:'¼+¾', c:[3,9]},
  {l:'2+1+1', c:[6,3,3]},{l:'1+1+2', c:[3,3,6]},{l:'5컬', c:[2,2,3,3,2]},{l:'6컬', c:[2,2,2,2,2,2]},
];
const BM = {
  paragraph:{n:'단락',color:'#74c0fc',icon:'📝',hasStyle:true},
  h2:{n:'H2',color:'#f783ac',icon:'H²',hasStyle:true},
  h3:{n:'H3',color:'#faa2c1',icon:'H³',hasStyle:true},
  h4:{n:'H4',color:'#fcc2d7',icon:'H⁴',hasStyle:true},
  quote:{n:'인용구',color:'#da77f2',icon:'💬',hasStyle:true},
  list:{n:'목록',color:'#63e6be',icon:'📋',hasStyle:true},
  image:{n:'이미지',color:'#ffa94d',icon:'🖼',hasStyle:false},
  warning:{n:'주의',color:'#FABE00',icon:'⚠️',hasStyle:true},
  delimiter:{n:'구분선',color:'#a9e34b',icon:'—',hasStyle:false},
  table:{n:'표',color:'#4dabf7',icon:'📊',hasStyle:true},
  button:{n:'버튼',color:'#9775fa',icon:'🔘',hasStyle:true},
};
const DEFAULT_STYLE = {
  paragraph:{fontSize:15,fontWeight:400,textAlign:'left',color:'#1a1a2e',lineHeight:1.65,letterSpacing:0},
  h2:{fontSize:22,fontWeight:800,textAlign:'left',color:'#1a1a2e',lineHeight:1.3,letterSpacing:-0.5},
  h3:{fontSize:18,fontWeight:700,textAlign:'left',color:'#1a1a2e',lineHeight:1.35,letterSpacing:-0.3},
  h4:{fontSize:15,fontWeight:700,textAlign:'left',color:'#1a1a2e',lineHeight:1.4,letterSpacing:0},
  quote:{fontSize:15,fontWeight:400,textAlign:'left',color:'#25456B',lineHeight:1.7,letterSpacing:0},
  list:{fontSize:14,fontWeight:400,textAlign:'left',color:'#1a1a2e',lineHeight:1.65,letterSpacing:0},
  warning:{fontSize:13,fontWeight:400,textAlign:'left',color:'#1a1a2e',lineHeight:1.6,letterSpacing:0},
  table:{fontSize:13,fontWeight:400,textAlign:'left',color:'#1a1a2e',lineHeight:1.5,letterSpacing:0},
  button:{fontSize:14,fontWeight:700,textAlign:'center',color:'#ffffff',lineHeight:1.4,letterSpacing:0},
};

const saveHist = () => { hist.push(JSON.stringify(pageData)); if(hist.length>60) hist.shift(); redoStack=[]; };
function undoAction(){ if(EDITOR_MODE!=='builder'||!hist.length) return; redoStack.push(JSON.stringify(pageData)); pageData=JSON.parse(hist.pop()); rebuildCanvas(); toast('↩ 실행취소'); }
function redoAction(){ if(EDITOR_MODE!=='builder'||!redoStack.length) return; hist.push(JSON.stringify(pageData)); pageData=JSON.parse(redoStack.pop()); rebuildCanvas(); toast('↪ 다시실행'); }

/* ════════════════════════════════════════
   BOARD / CATEGORY
════════════════════════════════════════ */
function onBoardChange() {
  const tbl = document.getElementById('tb_bo_table').value;
  const cat  = document.getElementById('tb_category');
  cat.innerHTML = '<option value="">카테고리</option>';
  if (tbl && PHP_BOARD_CATS[tbl]?.length > 0) {
    cat.style.display = '';
    PHP_BOARD_CATS[tbl].forEach(c => {
      const o = new Option(c.name, c.id);
      if (String(c.id) === PHP_SAVED_CAT) o.selected = true;
      cat.appendChild(o);
    });
  } else { cat.style.display = 'none'; }
}

/* ════════════════════════════════════════
   SEO
════════════════════════════════════════ */
function toggleSEO(){ document.getElementById('seo-drawer').classList.toggle('open'); updateSeoChecklist(); }
function updateSeoCount(){ const v=document.getElementById('seo_desc').value.length; const el=document.getElementById('seo_cnt'); el.textContent=v+' / 160'; el.classList.toggle('warn',v>160); updateSeoChecklist(); }
function updateSeoChecklist(){
  const title=document.getElementById('tb_subject').value, desc=document.getElementById('seo_desc').value;
  const blks=pageData.rows.reduce((s,r)=>s+r.columns.reduce((ss,c)=>ss+c.blocks.length,0),0);
  const hasH2=pageData.rows.some(r=>r.columns.some(c=>c.blocks.some(b=>b.type==='h2')));
  const hasImg=pageData.rows.some(r=>r.columns.some(c=>c.blocks.some(b=>b.type==='image')));
  const checks=[{ok:title.length>=10,l:`제목 (${title.length}자)`},{ok:desc.length>=80&&desc.length<=160,l:`메타설명 80~160자 (${desc.length}자)`},{ok:blks>=3,l:`블록 3개 이상 (${blks}개)`},{ok:hasH2,l:'H2 소제목 사용'},{ok:hasImg,l:'이미지 포함'}];
  document.getElementById('seo-checklist').innerHTML=checks.map(c=>`<div class="seo-check" style="color:${c.ok?'#63e6be':'var(--ui-text3)'}"><span>${c.ok?'✅':'○'}</span><span>${c.l}</span></div>`).join('');
}

/* ════════════════════════════════════════
   LAYOUT MODAL
════════════════════════════════════════ */
let selLayout = LAYOUTS[0];
function openLayoutModal(){ const g=document.getElementById('lm-grid');g.innerHTML='';LAYOUTS.forEach((lay,i)=>{const el=document.createElement('div');el.className='lm-opt'+(i===0?' sel':'');el.innerHTML=`<div class="lm-prev">${lay.c.map(v=>`<span style="flex:${v}"></span>`).join('')}</div><p>${lay.l}</p>`;el.onclick=()=>{g.querySelectorAll('.lm-opt').forEach(o=>o.classList.remove('sel'));el.classList.add('sel');selLayout=lay;};g.appendChild(el);});selLayout=LAYOUTS[0];document.getElementById('layout-modal').classList.add('open');}
function confirmLayout(){ saveHist(); addRow(selLayout.c); document.getElementById('layout-modal').classList.remove('open'); toast('✅ 컨테이너 추가됨'); }
document.getElementById('layout-modal').addEventListener('click',e=>{if(e.target===document.getElementById('layout-modal'))document.getElementById('layout-modal').classList.remove('open');});

/* ════════════════════════════════════════
   ROW
════════════════════════════════════════ */
function addRow(spans){const row={id:uid(),cols:spans.length,sectionId:'',columns:spans.map(s=>({id:uid(),span:s,blocks:[]}))};pageData.rows.push(row);renderRow(row);updateEmpty();updateStructTree();}

function renderRow(row){
  document.getElementById('canvas-empty')?.remove();
  const canvas=document.getElementById('builder-canvas');
  const el=document.createElement('div');
  el.className='builder-row';el.id='row-'+row.id;el.dataset.rowId=row.id;
  const secBadge=row.sectionId?`<span class="row-sec-badge" id="rbadge-${row.id}">#${row.sectionId}</span>`:'';
  el.innerHTML=`
    <div class="row-hdr" onclick="selectRow('${row.id}')">
      <span class="rh-grip" draggable="true" id="rdh-${row.id}">⠿</span>
      <span class="rh-lbl" id="rhl-${row.id}">컨테이너 · ${row.cols}컬럼</span>
      ${secBadge ? `<span id="rbadge-wrap-${row.id}">${secBadge}</span>` : `<span id="rbadge-wrap-${row.id}"></span>`}
      <div class="pre-btns">${[1,2,3,4,5,6].map(n=>`<button type="button" class="pre-btn${row.cols===n?' active':''}" onclick="event.stopPropagation();changeRowCols('${row.id}',${n})">${n}</button>`).join('')}</div>
      <div class="row-acts">
        <button type="button" class="row-act mv" onclick="event.stopPropagation();moveRow('${row.id}',-1)">↑</button>
        <button type="button" class="row-act mv" onclick="event.stopPropagation();moveRow('${row.id}',1)">↓</button>
        <button type="button" class="row-act" onclick="event.stopPropagation();dupRow('${row.id}')" title="복제">⧉</button>
        <button type="button" class="row-act" onclick="event.stopPropagation();delRow('${row.id}')">✕</button>
      </div>
    </div>
    <div class="row-cols" id="rcols-${row.id}"></div>
  `;
  canvas.appendChild(el);
  const rdh=el.querySelector('#rdh-'+row.id);
  rdh.addEventListener('dragstart',e=>{dragState={source:'row',rowId:row.id};e.dataTransfer.effectAllowed='move';setTimeout(()=>el.style.opacity='.4',0);});
  rdh.addEventListener('dragend',()=>{el.style.opacity='';dragState=null;});
  el.addEventListener('dragover',e=>{if(dragState?.source==='row'&&dragState.rowId!==row.id){e.preventDefault();el.classList.add('drag-row');}});
  el.addEventListener('dragleave',e=>{if(!el.contains(e.relatedTarget))el.classList.remove('drag-row');});
  el.addEventListener('drop',e=>{el.classList.remove('drag-row');if(dragState?.source==='row'&&dragState.rowId!==row.id){e.preventDefault();saveHist();const fi=pageData.rows.findIndex(r=>r.id===dragState.rowId),ti=pageData.rows.findIndex(r=>r.id===row.id);const [m]=pageData.rows.splice(fi,1);pageData.rows.splice(ti,0,m);rebuildCanvas();}});
  row.columns.forEach(col=>renderCol(col,row.id));
}

function changeRowCols(rowId,n){saveHist();const row=pageData.rows.find(r=>r.id===rowId);if(!row)return;const all=row.columns.flatMap(c=>c.blocks),sp=Math.floor(12/n);row.columns=Array.from({length:n},(_,i)=>({id:uid(),span:sp,blocks:i===0?all:[]}));row.cols=n;document.getElementById('rcols-'+rowId).innerHTML='';const hl=document.getElementById('rhl-'+rowId);if(hl)hl.textContent=`컨테이너 · ${n}컬럼`;document.getElementById('row-'+rowId)?.querySelectorAll('.pre-btn').forEach(b=>b.classList.toggle('active',parseInt(b.textContent)===n));row.columns.forEach(c=>renderCol(c,rowId));updateStructTree();}
function delRow(rowId){saveHist();pageData.rows=pageData.rows.filter(r=>r.id!==rowId);document.getElementById('row-'+rowId)?.remove();updateEmpty();updateStructTree();toast('🗑 삭제됨');}
function dupRow(rowId){saveHist();const row=pageData.rows.find(r=>r.id===rowId);if(!row)return;const cl=JSON.parse(JSON.stringify(row));cl.id=uid();cl.sectionId='';cl.columns=cl.columns.map(c=>({...c,id:uid(),blocks:c.blocks.map(b=>({...b,id:uid()}))}));pageData.rows.splice(pageData.rows.findIndex(r=>r.id===rowId)+1,0,cl);rebuildCanvas();toast('⧉ 복제됨');}
function moveRow(rowId,dir){const i=pageData.rows.findIndex(r=>r.id===rowId),ni=i+dir;if(ni<0||ni>=pageData.rows.length)return;saveHist();[pageData.rows[i],pageData.rows[ni]]=[pageData.rows[ni],pageData.rows[i]];rebuildCanvas();}
function selectRow(rowId){
  document.querySelectorAll('.builder-row').forEach(r=>r.classList.remove('row-sel'));
  document.querySelectorAll('.content-block').forEach(b=>b.classList.remove('block-sel'));
  document.getElementById('row-'+rowId)?.classList.add('row-sel');
  selectedBlockId=null;showRowProps(rowId);
}

/* ════════════════════════════════════════
   COLUMN
════════════════════════════════════════ */
function renderCol(col,rowId){
  const c=document.getElementById('rcols-'+rowId);
  const el=document.createElement('div');el.className='builder-col';el.id='col-'+col.id;el.dataset.colId=col.id;el.dataset.rowId=rowId;el.style.flex=col.span;
  el.innerHTML=`<div class="col-hint" id="hint-${col.id}"><div class="col-hint-box">+</div><span>드래그 또는 클릭</span></div><div class="col-badge">${col.span}/12</div>`;
  c.appendChild(el);
  el.addEventListener('click',e=>{if(e.target.closest('.content-block'))return;togglePicker(col.id,rowId,el);});
  el.addEventListener('dragover',e=>{if(dragState&&dragState.source!=='row'){e.preventDefault();el.classList.add('col-drop');}});
  el.addEventListener('dragleave',e=>{if(!el.contains(e.relatedTarget))el.classList.remove('col-drop');});
  el.addEventListener('drop',e=>{
    e.preventDefault();el.classList.remove('col-drop');closeAllPickers();
    if(!dragState||dragState.source==='row')return;saveHist();
    if(dragState.source==='palette'){const b={id:uid(),type:dragState.type,data:{style:{...DEFAULT_STYLE[dragState.type]||{}}}};const cd=getCol(col.id);if(cd){cd.blocks.push(b);renderBlock(b,el,col.id,rowId);}}
    else if(dragState.source==='block'&&dragState.fromColId!==col.id){const b=findBlock(dragState.blockId);if(!b)return;const fc=getCol(dragState.fromColId);if(fc)fc.blocks=fc.blocks.filter(x=>x.id!==b.id);document.querySelector(`[data-block-id="${dragState.blockId}"]`)?.remove();const fce=document.getElementById('col-'+dragState.fromColId);if(fce)updHint(fce);const tc=getCol(col.id);if(tc){tc.blocks.push(b);renderBlock(b,el,col.id,rowId);}}
    updateStructTree();
  });
  col.blocks.forEach(b=>renderBlock(b,el,col.id,rowId));
}
function togglePicker(colId,rowId,colEl){const ex=colEl.querySelector('.col-picker');if(ex){closeAllPickers();return;}closeAllPickers();const p=document.createElement('div');p.className='col-picker';p.innerHTML=`<div class="cp-title">블록 추가</div><div class="cp-grid">${Object.entries(BM).map(([t,m])=>`<button type="button" class="cp-btn" onclick="addBlockToCol('${t}','${colId}','${rowId}')"><span>${m.icon}</span><span>${m.n}</span></button>`).join('')}</div>`;colEl.appendChild(p);setTimeout(()=>document.addEventListener('click',closeAllPickers,{once:true}),10);}
function closeAllPickers(){document.querySelectorAll('.col-picker').forEach(p=>p.remove());}
function addBlockToCol(type,colId,rowId){saveHist();const b={id:uid(),type,data:{style:{...DEFAULT_STYLE[type]||{}}}};const cd=getCol(colId);if(!cd)return;cd.blocks.push(b);const ce=document.getElementById('col-'+colId);if(!ce)return;renderBlock(b,ce,colId,rowId);closeAllPickers();updateStructTree();toast(`✅ ${BM[type]?.n||type} 추가됨`);}
function getCol(id){for(const r of pageData.rows)for(const c of r.columns)if(c.id===id)return c;return null;}
function updHint(colEl){const h=colEl.querySelector('.col-hint');if(h)h.style.display=colEl.querySelectorAll('.content-block').length>0?'none':'flex';}

/* ════════════════════════════════════════
   BLOCK RENDER
════════════════════════════════════════ */
function renderBlock(block,colEl,colId,rowId){
  const hint=colEl.querySelector('.col-hint');if(hint)hint.style.display='none';
  if(!block.data)block.data={};if(!block.data.style)block.data.style={...DEFAULT_STYLE[block.type]||{}};
  const m=BM[block.type]||{n:block.type,color:'#ccc',icon:'□'};
  const el=document.createElement('div');el.className=`content-block bt-${block.type}`;el.id='block-'+block.id;el.dataset.blockId=block.id;el.dataset.colId=colId;el.dataset.rowId=rowId;el.draggable=true;
  el.innerHTML=`<div class="block-bar"><span class="bb-dot" style="background:${m.color}"></span><span class="bb-nm">${m.icon} ${m.n}</span><div class="bb-acts"><button type="button" class="bb-act mv" onclick="moveBlockInCol('${block.id}','${colId}','${rowId}',-1)">↑</button><button type="button" class="bb-act mv" onclick="moveBlockInCol('${block.id}','${colId}','${rowId}',1)">↓</button><button type="button" class="bb-act" onclick="dupBlock('${block.id}','${colId}','${rowId}')">⧉</button><button type="button" class="bb-act" onclick="delBlock('${block.id}','${colId}','${rowId}')">✕</button></div></div><div class="block-body b-${block.type}">${buildBody(block)}</div>`;
  colEl.appendChild(el);applyBlockStyle(el,block);
  el.querySelector('.block-bar').addEventListener('mousedown',()=>el.draggable=true);
  el.addEventListener('dragstart',e=>{dragState={source:'block',blockId:block.id,fromColId:colId,fromRowId:rowId};e.dataTransfer.effectAllowed='move';setTimeout(()=>el.classList.add('block-drag'),0);showGhost(m.icon+' '+m.n);e.stopPropagation();});
  el.addEventListener('dragend',()=>{el.classList.remove('block-drag');hideGhost();dragState=null;});
  el.addEventListener('dragover',e=>{if(dragState?.source==='block'&&dragState.blockId!==block.id){e.preventDefault();el.classList.add('block-drag-over');}});
  el.addEventListener('dragleave',()=>el.classList.remove('block-drag-over'));
  el.addEventListener('drop',e=>{e.preventDefault();e.stopPropagation();el.classList.remove('block-drag-over');if(!dragState||dragState.source!=='block'||dragState.blockId===block.id)return;saveHist();if(dragState.fromColId===colId){const cd=getCol(colId);if(!cd)return;const fi=cd.blocks.findIndex(b=>b.id===dragState.blockId),ti=cd.blocks.findIndex(b=>b.id===block.id);const [mv]=cd.blocks.splice(fi,1);cd.blocks.splice(ti,0,mv);rebuildCol(colId,rowId);}else{const mb=findBlock(dragState.blockId);if(!mb)return;const fc=getCol(dragState.fromColId);if(fc)fc.blocks=fc.blocks.filter(b=>b.id!==mb.id);const fce=document.getElementById('col-'+dragState.fromColId);document.querySelector(`[data-block-id="${dragState.blockId}"]`)?.remove();if(fce)updHint(fce);const tc=getCol(colId);if(!tc)return;const ti=tc.blocks.findIndex(b=>b.id===block.id);tc.blocks.splice(ti,0,mb);rebuildCol(colId,rowId);}updateStructTree();});
  el.addEventListener('click',e=>{e.stopPropagation();closeAllPickers();document.querySelectorAll('.content-block').forEach(b=>{b.classList.remove('block-sel');b.style.outline='';});document.querySelectorAll('.builder-row').forEach(r=>r.classList.remove('row-sel'));el.classList.add('block-sel');selectedBlockId=block.id;showBlockProps(block,colId,rowId);});
  bindInputs(el,block);
}

function applyBlockStyle(el,block){const s=block.data?.style;if(!s)return;el.querySelectorAll('[contenteditable]').forEach(c=>{c.style.fontSize=s.fontSize?s.fontSize+'px':'';c.style.fontWeight=s.fontWeight?s.fontWeight:'';c.style.textAlign=s.textAlign||'';c.style.color=s.color||'';c.style.lineHeight=s.lineHeight||'';c.style.letterSpacing=s.letterSpacing!==undefined?s.letterSpacing+'px':'';});}

function buildBody(block){const d=block.data||{};switch(block.type){
  case 'paragraph':return`<div contenteditable="true" data-ph="단락 텍스트...">${d.text||''}</div>`;
  case 'h2':return`<div contenteditable="true" data-ph="소제목 (H2)">${d.text||''}</div>`;
  case 'h3':return`<div contenteditable="true" data-ph="소소제목 (H3)">${d.text||''}</div>`;
  case 'h4':return`<div contenteditable="true" data-ph="작은제목 (H4)">${d.text||''}</div>`;
  case 'quote':return`<blockquote class="b-quote"><div contenteditable="true" data-ph="인용 문구...">${d.text||''}</div></blockquote>`;
  case 'warning':return`<div class="b-warning"><div class="w-title" contenteditable="true" data-ph="주의 제목">${d.title||''}</div><div contenteditable="true" data-ph="내용...">${d.text||''}</div></div>`;
  case 'image':return`<div>${d.url?`<img src="${d.url}" class="b-img-preview" alt="${d.alt||''}" style="border-radius:${d.borderRadius||6}px">`:`<div class="b-img-drop" onclick="pickImg('${block.id}')"><div style="font-size:26px">🖼</div><span>클릭하여 이미지 선택</span></div>`}<input type="text" class="b-img-alt" placeholder="alt 텍스트 (SEO 필수)" value="${d.alt||''}" oninput="updData('${block.id}','alt',this.value)"><input type="file" id="imgf-${block.id}" style="display:none" accept="image/*" onchange="handleImg('${block.id}',this)"></div>`;
  case 'list':{const items=d.items||[''];return`<div><ul class="b-list-ul" id="bl-${block.id}">${items.map(it=>`<li><span contenteditable="true" data-list="${block.id}">${it}</span></li>`).join('')}</ul><button type="button" class="b-list-add" onclick="addListItem('${block.id}')">+ 항목 추가</button></div>`;}
  case 'delimiter':return`<div class="b-delimiter">• • •</div>`;
  case 'table':{const rows=d.rows||[['헤더1','헤더2'],['','']];return`<div><div class="b-tbl-wrap"><table id="bt-${block.id}">${rows.map((r,ri)=>`<tr>${r.map((c,ci)=>`<td><div contenteditable="true" data-tbl="${block.id}" data-r="${ri}" data-c="${ci}">${c}</div></td>`).join('')}</tr>`).join('')}</table></div><div class="tbl-btns"><button type="button" class="tbl-btn" onclick="addTblRow('${block.id}')">+ 행</button><button type="button" class="tbl-btn" onclick="addTblCol('${block.id}')">+ 열</button></div></div>`;}
  case 'button':return`<div class="b-btn-wrap"><div class="b-btn-el"><span contenteditable="true" data-ph="버튼 텍스트">${d.text||''}</span></div></div>`;
  default:return`<div contenteditable="true" data-ph="내용...">${d.text||''}</div>`;
}}

function bindInputs(el,block){el.querySelectorAll('[contenteditable],[data-tbl]').forEach(ce=>ce.addEventListener('input',()=>syncBlock(block)));}
function syncBlock(block){const el=document.getElementById('block-'+block.id);if(!el)return;const body=el.querySelector('.block-body');switch(block.type){case 'paragraph':case 'h2':case 'h3':case 'h4':case 'quote':case 'button':block.data.text=body.querySelector('[contenteditable]')?.innerHTML||'';break;case 'warning':{const es=body.querySelectorAll('[contenteditable]');block.data.title=es[0]?.innerHTML||'';block.data.text=es[1]?.innerHTML||'';break;}case 'list':block.data.items=[...body.querySelectorAll('[data-list]')].map(e=>e.innerHTML);break;case 'table':{const t=body.querySelector('table');if(t)block.data.rows=[...t.querySelectorAll('tr')].map(tr=>[...tr.querySelectorAll('[contenteditable]')].map(td=>td.innerHTML));break;}}updateSeoChecklist();}
function delBlock(blockId,colId,rowId){saveHist();const col=getCol(colId);if(col)col.blocks=col.blocks.filter(b=>b.id!==blockId);const el=document.getElementById('block-'+blockId);const ce=el?.closest('.builder-col');el?.remove();if(ce)updHint(ce);updateStructTree();if(selectedBlockId===blockId){selectedBlockId=null;clearRightPanel();}}
function dupBlock(blockId,colId,rowId){saveHist();const block=findBlock(blockId);if(!block)return;const cl=JSON.parse(JSON.stringify(block));cl.id=uid();const col=getCol(colId);if(!col)return;const idx=col.blocks.findIndex(b=>b.id===blockId);col.blocks.splice(idx+1,0,cl);rebuildCol(colId,rowId);toast('⧉ 블록 복제됨');}
function moveBlockInCol(blockId,colId,rowId,dir){const col=getCol(colId);if(!col)return;const i=col.blocks.findIndex(b=>b.id===blockId),ni=i+dir;if(ni<0||ni>=col.blocks.length)return;saveHist();[col.blocks[i],col.blocks[ni]]=[col.blocks[ni],col.blocks[i]];rebuildCol(colId,rowId);}
function findBlock(id){for(const r of pageData.rows)for(const c of r.columns)for(const b of c.blocks)if(b.id===id)return b;return null;}
function updData(id,k,v){const b=findBlock(id);if(b){b.data=b.data||{};b.data[k]=v;}}
function pickImg(id){document.getElementById('imgf-'+id)?.click();}
function handleImg(id,input){const f=input.files[0];if(!f)return;const fd=new FormData();fd.append('image',f);fetch(PHP_UPLOAD_URL,{method:'POST',body:fd}).then(r=>r.json()).then(data=>{if(!data.success)return;const b=findBlock(id);if(b){b.data=b.data||{};b.data.url=data.url;}const drop=document.querySelector(`#block-${id} .b-img-drop`);if(drop){const img=document.createElement('img');img.src=data.url;img.className='b-img-preview';drop.replaceWith(img);}else{const img=document.querySelector(`#block-${id} .b-img-preview`);if(img)img.src=data.url;}}).catch(()=>{const reader=new FileReader();reader.onload=e=>{const url=e.target.result;const b=findBlock(id);if(b){b.data=b.data||{};b.data.url=url;}const drop=document.querySelector(`#block-${id} .b-img-drop`);if(drop){const img=document.createElement('img');img.src=url;img.className='b-img-preview';drop.replaceWith(img);}};reader.readAsDataURL(f);});}
function addListItem(id){const b=findBlock(id);if(!b)return;b.data=b.data||{};b.data.items=b.data.items||[];b.data.items.push('');const ul=document.getElementById('bl-'+id);if(!ul)return;const li=document.createElement('li');li.innerHTML=`<span contenteditable="true" data-list="${id}"></span>`;ul.appendChild(li);const span=li.querySelector('[contenteditable]');span.addEventListener('input',()=>syncBlock(b));span.focus();}
function addTblRow(id){const b=findBlock(id);if(!b||!b.data?.rows?.length)return;const cols=b.data.rows[0].length;b.data.rows.push(Array(cols).fill(''));const tbl=document.querySelector(`#bt-${id}`);if(!tbl)return;const ri=tbl.querySelectorAll('tr').length;const tr=document.createElement('tr');for(let c=0;c<cols;c++){const td=document.createElement('td');td.innerHTML=`<div contenteditable="true" data-tbl="${id}" data-r="${ri}" data-c="${c}"></div>`;tr.appendChild(td);}tbl.appendChild(tr);tr.querySelectorAll('[contenteditable]').forEach(e=>e.addEventListener('input',()=>syncBlock(b)));}
function addTblCol(id){const b=findBlock(id);if(!b||!b.data?.rows)return;b.data.rows.forEach(r=>r.push(''));const tbl=document.querySelector(`#bt-${id}`);if(!tbl)return;tbl.querySelectorAll('tr').forEach((tr,ri)=>{const ci=tr.querySelectorAll('td').length;const td=document.createElement('td');td.innerHTML=`<div contenteditable="true" data-tbl="${id}" data-r="${ri}" data-c="${ci}"></div>`;tr.appendChild(td);td.querySelector('[contenteditable]').addEventListener('input',()=>syncBlock(b));});}

/* ════════════════════════════════════════
   RIGHT PANEL
════════════════════════════════════════ */
function clearRightPanel(){document.getElementById('rp-badge').textContent='—';document.getElementById('rp-body').innerHTML=`<div class="rp-empty"><div class="rp-empty-ic">🖱️</div><p>블록이나 컨테이너를<br>클릭하면 속성이<br>표시됩니다.</p></div>`;}

function showBlockProps(block,colId,rowId){
  const m=BM[block.type]||{};document.getElementById('rp-badge').textContent=m.n||block.type;
  const s=block.data?.style||{};
  let html='';
  if(m.hasStyle&&block.type!=='delimiter'&&block.type!=='image'){html+=`<div class="rp-section"><div class="rp-sec-title">타이포그래피</div>
    <div class="rp-row"><span class="rp-lbl">크기</span><input type="number" class="rp-num" id="rp-fs" value="${s.fontSize||14}" min="8" max="80" oninput="applyStyle('${block.id}','fontSize',parseInt(this.value)||14)"><span style="font-size:9px;color:var(--ui-text3)">px</span></div>
    <div class="rp-row"><span class="rp-lbl">굵기</span><div class="rp-weight-group">${[300,400,500,600,700,800].map(w=>`<button class="rp-w-btn${(s.fontWeight||400)==w?' active':''}" onclick="applyStyle('${block.id}','fontWeight',${w});document.querySelectorAll('.rp-weight-group .rp-w-btn').forEach(b=>b.classList.remove('active'));this.classList.add('active')">${w===300?'L':w===400?'R':w===500?'M':w===600?'SB':w===700?'B':'EB'}</button>`).join('')}</div></div>
    <div class="rp-row"><span class="rp-lbl">정렬</span><div class="rp-align-group">${[['left','◀'],['center','▐'],['right','▶'],['justify','≡']].map(([v,ic])=>`<button class="rp-align-btn${s.textAlign===v?' active':''}" title="${v}" onclick="applyStyle('${block.id}','textAlign','${v}');document.querySelectorAll('.rp-align-group .rp-align-btn').forEach(b=>b.classList.remove('active'));this.classList.add('active')">${ic}</button>`).join('')}</div></div>
    <div class="rp-row"><span class="rp-lbl">색상</span><div class="rp-color-wrap" style="flex:1"><div class="rp-color-swatch" style="background:${s.color||'#1a1a2e'}"><input type="color" id="rp-color" value="${s.color||'#1a1a2e'}" oninput="applyStyle('${block.id}','color',this.value);document.getElementById('rp-colorhex').value=this.value;document.querySelector('.rp-color-swatch').style.background=this.value"></div><input type="text" class="rp-color-hex" id="rp-colorhex" value="${s.color||'#1a1a2e'}" maxlength="7" oninput="if(/^#[0-9a-fA-F]{6}$/.test(this.value)){applyStyle('${block.id}','color',this.value);document.getElementById('rp-color').value=this.value;document.querySelector('.rp-color-swatch').style.background=this.value}"></div></div>
    <div class="rp-row"><span class="rp-lbl">줄간격</span><select class="rp-sel" onchange="applyStyle('${block.id}','lineHeight',parseFloat(this.value))">${[1.0,1.2,1.3,1.4,1.5,1.6,1.7,1.8,2.0,2.2].map(v=>`<option value="${v}"${(s.lineHeight||1.65)==v?' selected':''}>${v}</option>`).join('')}</select></div>
    <div class="rp-row"><span class="rp-lbl">자간</span><select class="rp-sel" onchange="applyStyle('${block.id}','letterSpacing',parseFloat(this.value))">${[[-2,'좁게 -2'],[-1,'좁게 -1'],[0,'기본 0'],[1,'넓게 1'],[2,'넓게 2'],[4,'넓게 4']].map(([v,l])=>`<option value="${v}"${(s.letterSpacing||0)==v?' selected':''}>${l}</option>`).join('')}</select></div>
  </div>`;}
  if(block.type==='image'){const br=block.data?.borderRadius??6;html+=`<div class="rp-section"><div class="rp-sec-title">이미지 설정</div><div class="rp-row"><span class="rp-lbl">모서리 반경</span><input type="number" class="rp-num" value="${br}" min="0" max="50" oninput="updData('${block.id}','borderRadius',parseInt(this.value)||0);const img=document.querySelector('#block-${block.id} .b-img-preview');if(img)img.style.borderRadius=this.value+'px'"><span style="font-size:9px;color:var(--ui-text3)">px</span></div>${!block.data?.url?`<button class="rp-act-btn" onclick="pickImg('${block.id}')">🖼 이미지 업로드</button>`:`<button class="rp-act-btn" onclick="pickImg('${block.id}')">🔄 이미지 교체</button>`}</div>`;}
  const bgColor=block.data?.bgColor||'';
  html+=`<div class="rp-section"><div class="rp-sec-title">블록 배경</div><div class="rp-row"><span class="rp-lbl">배경색</span><div class="rp-color-wrap" style="flex:1"><div class="rp-color-swatch" style="background:${bgColor||'#ffffff'}"><input type="color" value="${bgColor||'#ffffff'}" oninput="applyBgColor('${block.id}',this.value)"></div><input type="text" class="rp-color-hex" value="${bgColor}" placeholder="투명" oninput="if(!this.value||/^#[0-9a-fA-F]{6}$/.test(this.value)){applyBgColor('${block.id}',this.value)}">${bgColor?`<button style="border:none;background:none;color:var(--ui-text3);cursor:pointer;font-size:11px" onclick="applyBgColor('${block.id}','')">✕</button>`:''}</div></div></div>`;
  const pad=block.data?.padding||'default';
  html+=`<div class="rp-section"><div class="rp-sec-title">여백 (패딩)</div><div class="rp-row"><div style="display:flex;gap:2px;flex:1">${[['default','기본'],['sm','좁게'],['md','보통'],['lg','넓게'],['xl','아주넓게']].map(([v,l])=>`<button class="rp-w-btn${pad===v?' active':''}" style="flex:1" onclick="applyPadding('${block.id}','${v}')">${l}</button>`).join('')}</div></div></div>`;
  html+=`<div class="rp-section"><div class="rp-sec-title">작업</div><button class="rp-act-btn" onclick="dupBlock('${block.id}','${colId}','${rowId}')">⧉ 복제</button><button class="rp-act-btn danger" onclick="delBlock('${block.id}','${colId}','${rowId}')">🗑 삭제</button></div>`;
  document.getElementById('rp-body').innerHTML=html;
}

function showRowProps(rowId){
  const row=pageData.rows.find(r=>r.id===rowId);if(!row)return;
  document.getElementById('rp-badge').textContent='컨테이너';
  const blkCount=row.columns.reduce((s,c)=>s+c.blocks.length,0);
  document.getElementById('rp-body').innerHTML=`
    <div class="rp-section">
      <div class="rp-sec-title">섹션 ID <span style="font-size:8px;opacity:.6">(목차 앵커)</span></div>
      <div class="rp-row">
        <span class="rp-lbl">#</span>
        <input type="text" class="rp-text-inp" id="rp-section-id"
          value="${row.sectionId||''}"
          placeholder="예: dental-implant"
          style="flex:1"
          oninput="updateRowSectionId('${rowId}',this.value)">
      </div>
      <div style="font-size:9px;color:var(--ui-text3);margin-top:4px;line-height:1.6">
        설정하면 프론트 목차에서<br>이 컨테이너로 바로 이동합니다.<br>
        H2 블록이 있으면 자동으로 제목을 사용합니다.
      </div>
    </div>
    <div class="rp-section">
      <div class="rp-sec-title">컨테이너 정보</div>
      <div style="background:var(--ui-s2);border-radius:7px;padding:10px;font-size:11px;color:var(--ui-text2);line-height:1.9">
        <div>컬럼 수: <strong style="color:var(--ui-text)">${row.cols}개</strong></div>
        <div>블록 수: <strong style="color:var(--ui-text)">${blkCount}개</strong></div>
      </div>
    </div>
    <div class="rp-section">
      <div class="rp-sec-title">컬럼 레이아웃</div>
      <div style="display:flex;gap:2px">${[1,2,3,4,5,6].map(n=>`<div class="rp-w-btn${row.cols===n?' active':''}" style="flex:1;height:28px;cursor:pointer;display:flex;align-items:center;justify-content:center;border-radius:5px;border:1px solid var(--ui-border2);background:${row.cols===n?'var(--sub)':'var(--ui-s2)'};color:${row.cols===n?'#fff':'var(--ui-text3)'};font-size:11px;font-weight:700" onclick="changeRowCols('${rowId}',${n})">${n}</div>`).join('')}</div>
    </div>
    <div class="rp-section">
      <div class="rp-sec-title">작업</div>
      <button class="rp-act-btn" onclick="dupRow('${rowId}')">⧉ 복제</button>
      <button class="rp-act-btn danger" onclick="delRow('${rowId}')">🗑 삭제</button>
    </div>
  `;
}

/* 섹션 ID 업데이트 */
function updateRowSectionId(rowId, value) {
  const row = pageData.rows.find(r=>r.id===rowId); if(!row) return;
  // 영문/숫자/하이픈만 허용
  const clean = value.replace(/[^a-z0-9\-_가-힣]/gi,'').toLowerCase();
  row.sectionId = clean;
  const wrap = document.getElementById('rbadge-wrap-'+rowId);
  if(wrap) wrap.innerHTML = clean ? `<span class="row-sec-badge">#${clean}</span>` : '';
  // 인풋 값도 정리
  const inp = document.getElementById('rp-section-id');
  if(inp && inp.value !== clean) inp.value = clean;
}

function applyStyle(blockId,prop,value){const block=findBlock(blockId);if(!block)return;block.data=block.data||{};block.data.style=block.data.style||{};block.data.style[prop]=value;const el=document.getElementById('block-'+blockId);if(!el)return;applyBlockStyle(el,block);}
function applyBgColor(blockId,color){const block=findBlock(blockId);if(!block)return;block.data=block.data||{};block.data.bgColor=color;const el=document.getElementById('block-'+blockId);if(!el)return;el.style.background=color||'';}
const PAD_MAP={default:'8px 10px',sm:'4px 8px',md:'12px 16px',lg:'20px 24px',xl:'32px 36px'};
function applyPadding(blockId,pad){const block=findBlock(blockId);if(!block)return;block.data=block.data||{};block.data.padding=pad;const el=document.getElementById('block-'+blockId);if(!el)return;el.querySelector('.block-body').style.padding=PAD_MAP[pad]||'';}

/* ════════════════════════════════════════
   DRAG STATE
════════════════════════════════════════ */
let dragState=null;
document.querySelectorAll('.pal-item').forEach(el=>{el.addEventListener('dragstart',e=>{dragState={source:'palette',type:el.dataset.type};e.dataTransfer.effectAllowed='copy';el.classList.add('dragging-src');const m=BM[el.dataset.type]||{};showGhost((m.icon||'')+' '+(m.n||el.dataset.type));});el.addEventListener('dragend',()=>{el.classList.remove('dragging-src');hideGhost();dragState=null;});});
function showGhost(t){const g=document.getElementById('drag-ghost');g.textContent=t;g.classList.add('show');}
function hideGhost(){document.getElementById('drag-ghost').classList.remove('show');}
document.addEventListener('dragover',e=>{const g=document.getElementById('drag-ghost');g.style.left=(e.clientX+14)+'px';g.style.top=(e.clientY-12)+'px';});

/* ════════════════════════════════════════
   REBUILD
════════════════════════════════════════ */
function rebuildCanvas(){const c=document.getElementById('builder-canvas');c.innerHTML='';pageData.rows.forEach(r=>renderRow(r));updateEmpty();updateStructTree();}
function rebuildCol(colId,rowId){const ce=document.getElementById('col-'+colId);if(!ce)return;const cd=getCol(colId);if(!cd)return;ce.querySelectorAll('.content-block').forEach(b=>b.remove());const h=ce.querySelector('.col-hint');if(h)h.style.display=cd.blocks.length>0?'none':'flex';cd.blocks.forEach(b=>renderBlock(b,ce,colId,rowId));}
function updateEmpty(){const c=document.getElementById('builder-canvas');if(!pageData.rows.length&&!document.getElementById('canvas-empty'))c.innerHTML='<div id="canvas-empty"><div class="empty-ic">🏗️</div><h3>시작해볼까요?</h3><p>왼쪽 하단 <strong>컨테이너 추가</strong>를 클릭하거나<br>블록을 여기로 드래그하세요.</p></div>';}
function updateStructTree(){
  const t=document.getElementById('struct-tree');if(!t)return;
  if(!pageData.rows.length){t.innerHTML='<div style="font-size:11px;color:var(--ui-text3);text-align:center;padding:14px 0">컨테이너를 추가하면<br>여기에 표시됩니다.</div>';return;}
  t.innerHTML=pageData.rows.map((r,i)=>{
    const h2=r.columns.flatMap(c=>c.blocks).find(b=>b.type==='h2');
    const label=r.sectionId?`#${r.sectionId}`:(h2?(h2.data?.text?.replace(/<[^>]+>/g,'')||`컨테이너 ${i+1}`):`컨테이너 ${i+1}`);
    return`<div class="struct-item" onclick="selectRow('${r.id}')"><span>▣</span><span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${label}</span><span style="font-size:9px;color:var(--ui-text3)">${r.columns.reduce((s,c)=>s+c.blocks.length,0)}</span></div>`;
  }).join('');
}

/* ════════════════════════════════════════
   SUBMIT / PREVIEW
════════════════════════════════════════ */
function submitForm(){
  const bo=document.getElementById('tb_bo_table').value, subj=document.getElementById('tb_subject').value.trim();
  if(!bo){toast('⚠️ 게시판을 선택해주세요');return;}
  if(!subj){toast('⚠️ 제목을 입력해주세요');document.getElementById('tb_subject').focus();return;}

  if(EDITOR_MODE==='builder'){
    if(!pageData.rows.length){toast('⚠️ 콘텐츠를 추가해주세요');return;}
    pageData.rows.forEach(r=>r.columns.forEach(c=>c.blocks.forEach(b=>syncBlock(b))));
    document.getElementById('f_wr_content').value=JSON.stringify(pageData);
  } else {
    if(!ckInstance){toast('⚠️ 에디터가 아직 로드 중입니다');return;}
    document.getElementById('f_wr_content').value=ckInstance.getData();
    // 앵커 맵 수집
    const anchorMap={};
    document.querySelectorAll('.anchor-item').forEach(item=>{
      const label=item.dataset.label;
      const id=item.querySelector('.anchor-id-inp').value.trim();
      if(label&&id) anchorMap[label]=id;
    });
    document.getElementById('f_wr_anchor_map').value=JSON.stringify(anchorMap);
  }

  document.getElementById('f_bo_table').value=bo;
  document.getElementById('f_category_id').value=document.getElementById('tb_category').value||'';
  document.getElementById('f_wr_subject').value=subj;
  document.getElementById('f_wr_seo_desc').value=document.getElementById('seo_desc').value;
  document.getElementById('fwrite').submit();
}

function previewHTML(){
  if(EDITOR_MODE==='editor'){if(!ckInstance)return;const w=window.open('','_blank');w.document.write(`<!DOCTYPE html><html><head><meta charset="UTF-8"></head><body style="max-width:900px;margin:40px auto;padding:0 24px;font-family:sans-serif">${ckInstance.getData()}</body></html>`);w.document.close();return;}
  pageData.rows.forEach(r=>r.columns.forEach(c=>c.blocks.forEach(b=>syncBlock(b))));
  // TOC 생성 (미리보기용)
  const tocItems=[];pageData.rows.forEach((row,i)=>{const h2=row.columns.flatMap(c=>c.blocks).find(b=>b.type==='h2');const secId=row.sectionId||(h2?'sec-'+i:'');if(secId){const label=h2?(h2.data?.text?.replace(/<[^>]+>/g,'')||'섹션'):'섹션';tocItems.push({id:secId,label});}});
  let html=`<!DOCTYPE html><html><head><meta charset="UTF-8"><title>미리보기</title><style>*{box-sizing:border-box;margin:0;padding:0}body{font-family:sans-serif;color:#1a1a2e;background:#f8f9fa}.layout{display:flex;max-width:1100px;margin:0 auto;padding:40px 24px;gap:40px}aside{width:220px;flex-shrink:0;position:sticky;top:24px;align-self:flex-start;background:#fff;border-radius:10px;padding:16px;border:1px solid #dde3ee}aside h4{font-size:12px;font-weight:700;color:#25456b;letter-spacing:.8px;text-transform:uppercase;margin-bottom:12px;padding-bottom:8px;border-bottom:1px solid #eef1f6}aside ul{list-style:none;display:flex;flex-direction:column;gap:4px}aside li a{display:block;font-size:13px;color:#25456b;text-decoration:none;padding:5px 8px;border-radius:5px;transition:all .15s;border-left:2px solid transparent}aside li a:hover,aside li a.active{background:#f0f3f6;color:#000136;border-left-color:#FABE00}article{flex:1;min-width:0}.pb-row{display:flex;flex-wrap:wrap;gap:20px;margin-bottom:28px}.pb-col{flex:1;min-width:0}${[1,2,3,4,5,6,7,8,9,10,11,12].map(n=>`.pb-col-${n}{flex:${n}}`).join('')}h2{font-size:22px;font-weight:800;margin-bottom:10px}h3{font-size:18px;font-weight:700;margin-bottom:8px}h4{font-size:15px;font-weight:700;margin-bottom:6px}p{font-size:15px;line-height:1.75;margin-bottom:8px}blockquote{border-left:4px solid #99b5d7;background:#f8fbff;padding:12px 16px;border-radius:0 8px 8px 0;margin-bottom:8px;font-style:italic}.warning{background:#fffbf0;border:1.5px solid #FABE00;border-radius:8px;padding:12px;margin-bottom:8px}ul{padding-left:20px;margin-bottom:8px}li{margin-bottom:4px}table{width:100%;border-collapse:collapse;margin-bottom:8px}td,th{border:1.5px solid #dde3ee;padding:6px 10px}th{background:#f4f7fc;font-weight:700}img{max-width:100%;border-radius:6px;margin-bottom:8px}hr{border:none;border-top:2px solid #dde3ee;margin:16px 0}.btn{display:inline-flex;padding:10px 22px;border-radius:8px;background:linear-gradient(135deg,#000136,#25456b);color:white;font-weight:700;text-decoration:none;font-size:14px}@media(max-width:768px){.layout{flex-direction:column}aside{width:100%;position:static}[class*=pb-col-]{flex:0 0 100%!important}}</style></head><body>`;
  html+=`<div class="layout">`;
  if(tocItems.length){html+=`<aside><h4>목차</h4><ul>${tocItems.map(item=>`<li><a href="#${item.id}">${item.label}</a></li>`).join('')}</ul></aside>`;}
  html+=`<article>`;
  pageData.rows.forEach((row,ri)=>{
    const h2=row.columns.flatMap(c=>c.blocks).find(b=>b.type==='h2');
    const secId=row.sectionId||(h2?'sec-'+ri:'');
    const idAttr=secId?` id="${secId}"`:'';
    html+=`<div class="pb-row"${idAttr}>`;
    row.columns.forEach(col=>{html+=`<div class="pb-col pb-col-${col.span}">`;col.blocks.forEach(b=>{const d=b.data||{},s=d.style||{};const si=`style="${s.fontSize?'font-size:'+s.fontSize+'px;':''}${s.fontWeight?'font-weight:'+s.fontWeight+';':''}${s.textAlign?'text-align:'+s.textAlign+';':''}${s.color?'color:'+s.color+';':''}${s.lineHeight?'line-height:'+s.lineHeight+';':''}${d.bgColor?'background:'+d.bgColor+';':''}${d.padding&&PAD_MAP[d.padding]?'padding:'+PAD_MAP[d.padding]+';':''}"`;switch(b.type){case 'paragraph':html+=`<p ${si}>${d.text||''}</p>`;break;case 'h2':html+=`<h2 ${si}>${d.text||''}</h2>`;break;case 'h3':html+=`<h3 ${si}>${d.text||''}</h3>`;break;case 'h4':html+=`<h4 ${si}>${d.text||''}</h4>`;break;case 'quote':html+=`<blockquote ${si}>${d.text||''}</blockquote>`;break;case 'warning':html+=`<div class="warning" ${si}><strong>${d.title||''}</strong><p style="margin-top:4px">${d.text||''}</p></div>`;break;case 'image':if(d.url)html+=`<img src="${d.url}" alt="${d.alt||''}" style="border-radius:${d.borderRadius||6}px;max-width:100%">`;break;case 'list':html+=`<ul ${si}>${(d.items||[]).map(it=>`<li>${it}</li>`).join('')}</ul>`;break;case 'delimiter':html+=`<hr>`;break;case 'table':if(d.rows)html+=`<table ${si}>${d.rows.map((r,ri2)=>`<tr>${r.map(c=>ri2===0?`<th>${c}</th>`:`<td>${c}</td>`).join('')}</tr>`).join('')}</table>`;break;case 'button':html+=`<a class="btn" href="#" ${si}>${d.text||'버튼'}</a>`;break;}});html+=`</div>`;});html+=`</div>`;
  });
  html+=`</article></div>`;
  html+=`<script>const links=document.querySelectorAll('aside a');const obs=new IntersectionObserver(entries=>{entries.forEach(e=>{if(e.isIntersecting){links.forEach(l=>l.classList.remove('active'));const a=document.querySelector('aside a[href="#'+e.target.id+'"]');if(a)a.classList.add('active');}});},{threshold:.3});document.querySelectorAll('[id]').forEach(el=>{if([...links].some(l=>l.getAttribute('href')==='#'+el.id))obs.observe(el);});<\/script>`;
  html+=`</body></html>`;
  const w=window.open('','_blank');w.document.write(html);w.document.close();
}

/* ════════════════════════════════════════
   ANCHOR PANEL (에디터 모드)
════════════════════════════════════════ */
// 저장된 앵커 맵 (수정 모드 복원용)
let savedAnchorMap = {};
try { savedAnchorMap = JSON.parse(<?= json_encode($existing_anchor_map) ?>) || {}; } catch(e){}

function toggleAnchorPanel(){
  const d=document.getElementById('anchor-drawer');
  const isOpen=d.classList.toggle('open');
  if(isOpen&&!document.querySelector('.anchor-item')) scanH2s();
}

function scanH2s(){
  if(!ckInstance){toast('⚠️ 에디터 로딩 중');return;}

  // CKEditor 5는 .ck-editor__editable 안에 실제 DOM을 렌더링함
  const editable = document.querySelector('.ck-editor__editable');
  let h2s = editable ? [...editable.querySelectorAll('h2')] : [];

  // 폴백: getData() HTML 파싱
  if (!h2s.length) {
    const tmp = document.createElement('div');
    tmp.innerHTML = ckInstance.getData();
    h2s = [...tmp.querySelectorAll('h2')];
  }
  const list=document.getElementById('anchor-list');

  if(!h2s.length){
    list.innerHTML='<div class="anchor-empty">H2 제목이 없습니다.<br>에디터에서 제목(Heading 2)을 추가하세요.</div>';
    return;
  }

  list.innerHTML='';
  h2s.forEach((h2,i)=>{
    const label=h2.textContent.trim();
    // 기존 저장값 우선, 없으면 자동 슬러그
    const savedId=savedAnchorMap[label]||'';
    const autoSlug=label.toLowerCase().replace(/\s+/g,'-').replace(/[^a-z0-9가-힣\-_]/g,'').replace(/^-+|-+$/g,'')||('section-'+(i+1));

    const item=document.createElement('div');
    item.className='anchor-item'; item.dataset.label=label;
    item.innerHTML=`
      <div class="anchor-h2-label">H2 · ${label||'(빈 제목)'}</div>
      <div class="anchor-id-row">
        <span class="anchor-id-prefix">#</span>
        <input type="text" class="anchor-id-inp"
          value="${savedId}"
          placeholder="${autoSlug}"
          oninput="this.value=this.value.replace(/[^a-z0-9가-힣\\-_]/g,'').toLowerCase()">
      </div>`;
    list.appendChild(item);
  });
  toast('✅ H2 '+h2s.length+'개 스캔됨');
}

function goBack(){PHP_BO_TABLE==='faq'?location.href='/newadm/board/faq_manager.php':history.back();}

/* ════════════════════════════════════════
   TABS / TOAST / KEYBOARD
════════════════════════════════════════ */
function switchTab(el,tab){document.querySelectorAll('.p-tab').forEach(t=>t.classList.remove('active'));el.classList.add('active');document.getElementById('tab-blocks').style.display=tab==='blocks'?'flex':'none';document.getElementById('tab-structure').style.display=tab==='structure'?'flex':'none';}
let tTimer;
function toast(msg){const t=document.getElementById('toast');document.getElementById('t-msg').textContent=msg;t.classList.add('show');clearTimeout(tTimer);tTimer=setTimeout(()=>t.classList.remove('show'),2200);}
document.addEventListener('keydown',e=>{if((e.metaKey||e.ctrlKey)&&e.key==='z'){e.preventDefault();e.shiftKey?redoAction():undoAction();}if(e.key==='Escape'){closeAllPickers();document.getElementById('seo-drawer').classList.remove('open');document.getElementById('anchor-drawer').classList.remove('open');}});

/* ════════════════════════════════════════
   INIT
════════════════════════════════════════ */
window.addEventListener('load',()=>{
  onBoardChange(); updateSeoCount();
  if(EDITOR_MODE==='editor') { initCKEditor(); document.getElementById('btn-anchor').style.display=''; }
  if(PHP_EXISTING?.rows){
    pageData=PHP_EXISTING;
    pageData.rows.forEach(r=>{if(!r.sectionId)r.sectionId='';r.columns.forEach(c=>{c.blocks.forEach(b=>{if(!b.data)b.data={};if(!b.data.style)b.data.style={...DEFAULT_STYLE[b.type]||{}};});});});
    pageData.rows.forEach(r=>renderRow(r));updateEmpty();updateStructTree();
  }
});
</script>
</body>
</html>