<?php
/**
 * DB 데이터 정리 스크립트
 * 테이블 구조는 유지하고 데이터만 삭제 (TRUNCATE)
 */

include_once('../_common.php');
include_once('../_auth_check.php');

// 백업 디렉토리 설정
$backup_dir = G5_DATA_PATH . '/db_backups';
if (!is_dir($backup_dir)) {
    @mkdir($backup_dir, G5_DIR_PERMISSION, true);
    @chmod($backup_dir, G5_DIR_PERMISSION);
}

// 로그 파일
$log_file = $backup_dir . '/cleanup_log_' . date('Y-m-d_H-i-s') . '.txt';

// 로그 기록 함수
function writeLog($message) {
    global $log_file;
    $timestamp = date('Y-m-d H:i:s');
    file_put_contents($log_file, "[{$timestamp}] {$message}\n", FILE_APPEND);
    echo "<p>[{$timestamp}] {$message}</p>";
    flush();
}

// 테이블 목록 가져오기
function getTableList() {
    $tables = [];
    $result = sql_query("SHOW TABLES");
    
    while ($row = sql_fetch_array($result)) {
        $table_name = reset($row);
        
        // 테이블 행 수
        $count_result = sql_query("SELECT COUNT(*) as cnt FROM `{$table_name}`");
        $count_row = sql_fetch_array($count_result);
        
        // 테이블 크기
        $size_result = sql_query("
            SELECT 
                ROUND(((data_length + index_length) / 1024 / 1024), 2) AS size_mb
            FROM information_schema.TABLES 
            WHERE table_schema = '" . G5_MYSQL_DB . "' 
            AND table_name = '{$table_name}'
        ");
        $size_row = sql_fetch_array($size_result);
        
        $tables[] = [
            'name' => $table_name,
            'rows' => $count_row['cnt'] ?? 0,
            'size' => $size_row['size_mb'] ?? 0
        ];
    }
    
    return $tables;
}

// 백업 생성
function createBackup($tables) {
    global $backup_dir;
    
    writeLog("=== 백업 시작 ===");
    writeLog("백업 테이블 수: " . count($tables) . "개");
    
    $timestamp = date('Y-m-d_H-i-s');
    $filename = "before_cleanup_{$timestamp}.sql";
    $filepath = $backup_dir . '/' . $filename;
    
    $tables_str = implode(' ', array_map('escapeshellarg', $tables));
    
    $command = sprintf(
        'mysqldump -h%s -u%s -p%s %s %s > %s 2>&1',
        escapeshellarg(G5_MYSQL_HOST),
        escapeshellarg(G5_MYSQL_USER),
        escapeshellarg(G5_MYSQL_PASSWORD),
        escapeshellarg(G5_MYSQL_DB),
        $tables_str,
        escapeshellarg($filepath)
    );
    
    exec($command, $output, $result);
    
    if ($result === 0 && file_exists($filepath) && filesize($filepath) > 0) {
        $filesize = filesize($filepath);
        writeLog("✓ 백업 성공: {$filename} (" . number_format($filesize/1024, 2) . " KB)");
        
        // ZIP 압축
        $zip = new ZipArchive();
        $zipfile = $backup_dir . '/' . "before_cleanup_{$timestamp}.zip";
        
        if ($zip->open($zipfile, ZipArchive::CREATE) === TRUE) {
            $zip->addFile($filepath, $filename);
            
            // 메타 정보 추가
            $meta = [
                'timestamp' => $timestamp,
                'tables' => $tables,
                'table_count' => count($tables),
                'filesize' => $filesize,
                'type' => 'cleanup_backup'
            ];
            $zip->addFromString($filename . '.meta', json_encode($meta, JSON_PRETTY_PRINT));
            $zip->close();
            
            @unlink($filepath);
            writeLog("✓ 압축 완료: before_cleanup_{$timestamp}.zip");
            
            return [
                'success' => true,
                'zipfile' => $zipfile,
                'filename' => "before_cleanup_{$timestamp}.zip"
            ];
        } else {
            writeLog("! 압축 실패, SQL 파일은 유지됨: {$filename}");
            return [
                'success' => true,
                'filepath' => $filepath,
                'filename' => $filename
            ];
        }
    } else {
        writeLog("✗ 백업 실패");
        if (!empty($output)) {
            writeLog("오류: " . implode("\n", $output));
        }
        return ['success' => false];
    }
}

// 데이터 삭제 (TRUNCATE)
function truncateTables($tables) {
    writeLog("\n=== 데이터 삭제 시작 (TRUNCATE) ===");
    
    $truncated_count = 0;
    $failed_tables = [];
    $total_rows_deleted = 0;
    
    // 외래키 체크 비활성화
    sql_query("SET FOREIGN_KEY_CHECKS = 0");
    
    foreach ($tables as $table) {
        // 삭제 전 행 수 확인
        $count_result = sql_query("SELECT COUNT(*) as cnt FROM `{$table}`");
        $count_row = sql_fetch_array($count_result);
        $before_count = $count_row['cnt'];
        
        writeLog("처리 중: {$table} ({$before_count} rows)");
        
        // TRUNCATE 실행
        $result = sql_query("TRUNCATE TABLE `{$table}`", false);
        
        if ($result) {
            // 삭제 후 확인
            $after_result = sql_query("SELECT COUNT(*) as cnt FROM `{$table}`");
            $after_row = sql_fetch_array($after_result);
            $after_count = $after_row['cnt'];
            
            if ($after_count == 0) {
                writeLog("✓ 삭제 완료: {$table} ({$before_count} rows 삭제)");
                $truncated_count++;
                $total_rows_deleted += $before_count;
            } else {
                writeLog("✗ 삭제 불완전: {$table} (남은 행: {$after_count})");
                $failed_tables[] = $table;
            }
        } else {
            $error = @sql_error();
            writeLog("✗ 삭제 실패: {$table} - {$error}");
            $failed_tables[] = $table;
        }
    }
    
    // 외래키 체크 재활성화
    sql_query("SET FOREIGN_KEY_CHECKS = 1");
    
    writeLog("\n=== 삭제 완료 ===");
    writeLog("성공: {$truncated_count}개 / " . count($tables) . "개");
    writeLog("총 삭제된 행 수: " . number_format($total_rows_deleted) . " rows");
    
    if (!empty($failed_tables)) {
        writeLog("실패한 테이블 (" . count($failed_tables) . "개): " . implode(', ', $failed_tables));
    }
    
    return [
        'success' => empty($failed_tables),
        'truncated' => $truncated_count,
        'failed' => $failed_tables,
        'total_rows' => $total_rows_deleted
    ];
}

// === 메인 실행 ===
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DB 데이터 정리</title>
    <style>
        body {
            font-family: 'Noto Sans KR', sans-serif;
            max-width: 1200px;
            margin: 40px auto;
            padding: 20px;
            background: #f5f5f5;
        }
        .container {
            background: white;
            border-radius: 12px;
            padding: 30px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        h1 {
            color: #e65100;
            border-bottom: 3px solid #e65100;
            padding-bottom: 10px;
        }
        .info-box {
            background: #e3f2fd;
            border-left: 4px solid #2196f3;
            padding: 20px;
            margin: 20px 0;
            border-radius: 4px;
        }
        .warning {
            background: #fff3cd;
            border: 2px solid #ffc107;
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
        }
        .warning strong {
            color: #d32f2f;
            font-size: 18px;
        }
        .table-list {
            max-height: 400px;
            overflow-y: auto;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 10px;
            background: #fafafa;
        }
        .table-item {
            display: flex;
            align-items: center;
            padding: 12px;
            margin: 5px 0;
            background: white;
            border-radius: 6px;
            border: 1px solid #e0e0e0;
            cursor: pointer;
            transition: all 0.2s;
        }
        .table-item:hover {
            background: #f5f5f5;
            border-color: #2196f3;
        }
        .table-item input[type="checkbox"] {
            margin-right: 12px;
            width: 18px;
            height: 18px;
        }
        .table-info {
            flex: 1;
        }
        .table-name {
            font-weight: 700;
            color: #333;
            margin-bottom: 4px;
        }
        .table-stats {
            font-size: 12px;
            color: #666;
        }
        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
        }
        .btn-danger {
            background: #e65100;
            color: white;
        }
        .btn-danger:hover {
            background: #d84315;
        }
        .btn-secondary {
            background: #9e9e9e;
            color: white;
        }
        .btn-secondary:hover {
            background: #757575;
        }
        .log-output {
            background: #263238;
            color: #00ff00;
            padding: 20px;
            border-radius: 8px;
            font-family: 'Courier New', monospace;
            margin-top: 20px;
            max-height: 500px;
            overflow-y: auto;
            font-size: 13px;
        }
        .log-output p {
            margin: 3px 0;
            line-height: 1.5;
        }
        .summary-box {
            background: #f5f5f5;
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
        }
        .summary-item {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid #ddd;
        }
        .summary-item:last-child {
            border-bottom: none;
        }
        .checkbox-group {
            margin: 15px 0;
            padding: 15px;
            background: #fff8e1;
            border-radius: 8px;
            border: 1px solid #ffc107;
        }
        .action-buttons {
            display: flex;
            gap: 12px;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🧹 데이터베이스 데이터 정리</h1>
        
        <div class="info-box">
            <h3 style="margin-top: 0;">📌 이 기능의 동작</h3>
            <ul style="margin: 10px 0; padding-left: 20px;">
                <li><strong>테이블 구조 유지</strong> - 테이블은 그대로 남아있습니다</li>
                <li><strong>데이터만 삭제</strong> - TRUNCATE로 모든 데이터 제거</li>
                <li><strong>AUTO_INCREMENT 초기화</strong> - ID가 1부터 다시 시작</li>
                <li><strong>자동 백업</strong> - 삭제 전 선택한 테이블 백업</li>
            </ul>
        </div>

        <?php if (!isset($_POST['execute_cleanup'])): ?>
            <?php
            $tables = getTableList();
            $total_rows = array_sum(array_column($tables, 'rows'));
            $total_size = array_sum(array_column($tables, 'size'));
            ?>
            
            <div class="summary-box">
                <h3 style="margin-top: 0;">📊 현재 데이터베이스 현황</h3>
                <div class="summary-item">
                    <span>총 테이블 수</span>
                    <strong><?= count($tables) ?>개</strong>
                </div>
                <div class="summary-item">
                    <span>총 데이터 행 수</span>
                    <strong><?= number_format($total_rows) ?> rows</strong>
                </div>
                <div class="summary-item">
                    <span>총 데이터 크기</span>
                    <strong><?= number_format($total_size, 2) ?> MB</strong>
                </div>
            </div>

            <div class="warning">
                <strong>⚠️ 주의사항</strong><br>
                • 선택한 테이블의 <strong>모든 데이터가 영구적으로 삭제</strong>됩니다<br>
                • <strong>테이블 구조는 유지</strong>되며, 데이터만 비워집니다<br>
                • 삭제 전 <strong>자동으로 백업</strong>이 생성됩니다<br>
                • 중요한 테이블(회원, 설정 등)은 신중히 선택하세요
            </div>

            <form method="post" id="cleanupForm">
                <input type="hidden" name="execute_cleanup" value="1">
                
                <h3>🎯 정리할 테이블 선택</h3>
                
                <div style="margin: 15px 0;">
                    <label style="cursor: pointer; display: inline-flex; align-items: center; gap: 8px; padding: 8px 12px; background: #e3f2fd; border-radius: 6px;">
                        <input type="checkbox" id="selectAll" onclick="toggleSelectAll()">
                        <strong>전체 선택/해제</strong>
                    </label>
                </div>
                
                <div class="table-list">
                    <?php foreach ($tables as $table): ?>
                        <label class="table-item">
                            <input type="checkbox" name="tables[]" value="<?= htmlspecialchars($table['name']) ?>" class="table-checkbox">
                            <div class="table-info">
                                <div class="table-name"><?= htmlspecialchars($table['name']) ?></div>
                                <div class="table-stats">
                                    <?= number_format($table['rows']) ?> rows · 
                                    <?= $table['size'] ?> MB
                                    <?php if ($table['rows'] > 0): ?>
                                        · <span style="color: #d32f2f;">삭제 시 <?= number_format($table['rows']) ?>개 데이터 제거</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </label>
                    <?php endforeach; ?>
                </div>
                
                <div class="checkbox-group">
                    <label style="display: flex; align-items: start; gap: 10px; cursor: pointer;">
                        <input type="checkbox" name="confirm_backup" required style="margin-top: 3px;">
                        <span>
                            <strong>백업 생성 확인</strong><br>
                            <small>삭제 전 선택한 테이블의 전체 백업이 자동으로 생성됩니다</small>
                        </span>
                    </label>
                </div>
                
                <div class="checkbox-group">
                    <label style="display: flex; align-items: start; gap: 10px; cursor: pointer;">
                        <input type="checkbox" name="confirm_delete" required style="margin-top: 3px;">
                        <span>
                            <strong style="color: #d32f2f;">데이터 삭제 확인</strong><br>
                            <small>선택한 테이블의 모든 데이터가 영구적으로 삭제됨을 이해했습니다</small>
                        </span>
                    </label>
                </div>
                
                <div class="action-buttons">
                    <button type="submit" class="btn btn-danger">
                        🗑️ 선택한 테이블 데이터 삭제
                    </button>
                    <button type="button" class="btn btn-secondary" onclick="window.history.back()">
                        취소
                    </button>
                </div>
            </form>

        <?php else: ?>
            <div class="log-output">
                <?php
                $selected_tables = isset($_POST['tables']) ? $_POST['tables'] : [];
                
                if (empty($selected_tables)) {
                    echo "<p style='color: #ff0000;'>오류: 테이블을 선택하지 않았습니다.</p>";
                } else {
                    writeLog("========================================");
                    writeLog("데이터베이스 데이터 정리 시작");
                    writeLog("선택된 테이블 수: " . count($selected_tables) . "개");
                    writeLog("테이블: " . implode(', ', $selected_tables));
                    writeLog("========================================");
                    
                    // 1단계: 백업
                    $backup_result = createBackup($selected_tables);
                    
                    if ($backup_result['success']) {
                        writeLog("백업 파일: " . $backup_result['filename']);
                        
                        // 2단계: 데이터 삭제
                        $cleanup_result = truncateTables($selected_tables);
                        
                        if ($cleanup_result['success']) {
                            writeLog("\n========================================");
                            writeLog("✓✓✓ 데이터 정리 완료 ✓✓✓");
                            writeLog("백업 파일: " . $backup_result['filename']);
                            writeLog("삭제된 총 행 수: " . number_format($cleanup_result['total_rows']));
                            writeLog("========================================");
                        } else {
                            writeLog("\n========================================");
                            writeLog("⚠ 일부 테이블 정리 실패");
                            writeLog("백업 파일: " . $backup_result['filename']);
                            writeLog("========================================");
                        }
                    } else {
                        writeLog("\n========================================");
                        writeLog("✗ 백업 실패 - 안전을 위해 데이터 삭제를 중단합니다");
                        writeLog("========================================");
                    }
                    
                    writeLog("\n로그 파일: " . basename($log_file));
                }
                ?>
            </div>
            
            <div style="margin-top: 20px;">
                <a href="<?= $_SERVER['PHP_SELF'] ?>" class="btn btn-secondary" style="display: inline-block; text-decoration: none;">
                    ← 돌아가기
                </a>
            </div>
        <?php endif; ?>
    </div>

    <script>
        function toggleSelectAll() {
            const selectAll = document.getElementById('selectAll');
            const checkboxes = document.querySelectorAll('.table-checkbox');
            checkboxes.forEach(cb => cb.checked = selectAll.checked);
        }
        
        // 폼 제출 전 최종 확인
        document.getElementById('cleanupForm')?.addEventListener('submit', function(e) {
            const checkedBoxes = document.querySelectorAll('.table-checkbox:checked');
            if (checkedBoxes.length === 0) {
                e.preventDefault();
                alert('정리할 테이블을 선택해주세요.');
                return false;
            }
            
            const tableNames = Array.from(checkedBoxes).map(cb => cb.value);
            const confirmMsg = `정말로 다음 ${tableNames.length}개 테이블의 데이터를 삭제하시겠습니까?\n\n${tableNames.join('\n')}\n\n이 작업은 되돌릴 수 없습니다!`;
            
            if (!confirm(confirmMsg)) {
                e.preventDefault();
                return false;
            }
        });
    </script>
</body>
</html>