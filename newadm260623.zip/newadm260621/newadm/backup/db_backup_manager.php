<?php
include_once('../_common.php');
include_once('../_auth_check.php');

$backup_dir = G5_DATA_PATH . '/db_backups';
if (!is_dir($backup_dir)) {
    @mkdir($backup_dir, G5_DIR_PERMISSION, true);
    @chmod($backup_dir, G5_DIR_PERMISSION);
}

// 현재 DB의 모든 테이블 목록 가져오기
function getAllTables() {
    $tables = [];
    $result = sql_query("SHOW TABLES");
    
    while ($row = sql_fetch_array($result)) {
        // SHOW TABLES는 'Tables_in_데이터베이스명' 형태로 컬럼명이 생성됨
        $table_name = reset($row); // 첫 번째 값 가져오기
        
        // 테이블 행 수
        $count_result = sql_query("SELECT COUNT(*) as cnt FROM `{$table_name}`");
        $count_row = sql_fetch_array($count_result);
        
        // 테이블 크기
        $size_result = sql_query("
            SELECT 
                ROUND(((data_length + index_length) / 1024 / 1024), 2) AS size_mb
            FROM information_schema.TABLES 
            WHERE table_schema = '" . G5_MYSQL_DB . "' 
            AND table_name = '{$table_name}'
        ");
        $size_row = sql_fetch_array($size_result);
        
        $tables[] = [
            'name' => $table_name,
            'rows' => $count_row['cnt'] ?? 0,
            'size' => $size_row['size_mb'] ?? 0
        ];
    }
    
    return $tables;
}

// [1] 선택 테이블 백업
if (isset($_POST['mode']) && $_POST['mode'] == 'backup') {
    $selected_tables = isset($_POST['tables']) ? $_POST['tables'] : [];
    
    if (empty($selected_tables)) {
        alert_toast('테이블을 선택해주세요.');
        exit;
    }
    
    $timestamp = date('Y-m-d_H-i-s');
    $filename = $timestamp . '_backup.sql';
    $filepath = $backup_dir . '/' . $filename;

    // 선택된 테이블만 백업
    $tables_str = implode(' ', array_map('escapeshellarg', $selected_tables));
    
    $command = sprintf(
        'mysqldump -h%s -u%s -p%s %s %s > %s',
        escapeshellarg(G5_MYSQL_HOST),
        escapeshellarg(G5_MYSQL_USER),
        escapeshellarg(G5_MYSQL_PASSWORD),
        escapeshellarg(G5_MYSQL_DB),
        $tables_str,
        escapeshellarg($filepath)
    );

    exec($command, $output, $result);

    if ($result === 0 && file_exists($filepath)) {
        // 메타 정보 저장
        $meta = [
            'timestamp' => $timestamp,
            'tables' => $selected_tables,
            'table_count' => count($selected_tables)
        ];
        file_put_contents($filepath . '.meta', json_encode($meta, JSON_PRETTY_PRINT));
        
        // ZIP 압축
        $zip = new ZipArchive();
        $zipfile = $backup_dir . '/' . $timestamp . '_backup.zip';

        if ($zip->open($zipfile, ZipArchive::CREATE) === TRUE) {
            $zip->addFile($filepath, $filename);
            $zip->addFile($filepath . '.meta', $filename . '.meta');
            $zip->close();
            @unlink($filepath);
            @unlink($filepath . '.meta');
            alert_toast('백업이 완료되었습니다.', './db_backup_manager.php', 'success');
        } else {
            alert_toast('압축 파일 생성에 실패했습니다.', 'error');
        }
    } else {
        alert_toast('백업에 실패했습니다. 서버의 mysqldump 권한을 확인하세요.', 'error');
    }
}

// [2] SQL 파일 생성 (install.php용)
if (isset($_POST['mode']) && $_POST['mode'] == 'generate_install_sql') {
    $selected_tables = isset($_POST['tables']) ? $_POST['tables'] : [];
    
    if (empty($selected_tables)) {
        echo json_encode(['success' => false, 'error' => '테이블을 선택해주세요.']);
        exit;
    }
    
    $timestamp = date('Y-m-d_H-i-s');
    $filename = 'install_' . $timestamp . '.sql';
    $filepath = $backup_dir . '/' . $filename;
    
    $tables_str = implode(' ', array_map('escapeshellarg', $selected_tables));
    
    $command = sprintf(
        'mysqldump -h%s -u%s -p%s --no-data %s %s > %s',
        escapeshellarg(G5_MYSQL_HOST),
        escapeshellarg(G5_MYSQL_USER),
        escapeshellarg(G5_MYSQL_PASSWORD),
        escapeshellarg(G5_MYSQL_DB),
        $tables_str,
        escapeshellarg($filepath)
    );
    
    exec($command, $output, $result);
    
    if ($result === 0 && file_exists($filepath)) {
        echo json_encode([
            'success' => true, 
            'filename' => $filename,
            'download_url' => './db_backup_manager.php?download=' . urlencode($filename)
        ]);
    } else {
        echo json_encode(['success' => false, 'error' => 'SQL 파일 생성 실패']);
    }
    exit;
}

// [3] 백업 파일 다운로드
if (isset($_GET['download'])) {
    $file = basename($_GET['download']);
    $filepath = $backup_dir . '/' . $file;

    if (file_exists($filepath)) {
        if (ob_get_level()) ob_end_clean();
        
        $ext = pathinfo($file, PATHINFO_EXTENSION);
        $content_type = $ext === 'sql' ? 'application/sql' : 'application/zip';
        
        header('Content-Type: ' . $content_type);
        header('Content-Disposition: attachment; filename="' . $file . '"');
        header('Content-Transfer-Encoding: binary');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($filepath));

        readfile($filepath);
        exit;
    }
}

// [4] 백업 파일 삭제
if (isset($_POST['mode']) && $_POST['mode'] == 'delete') {
    $file = basename($_POST['file']);
    $filepath = $backup_dir . '/' . $file;

    if (file_exists($filepath)) {
        unlink($filepath);
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => '파일을 찾을 수 없습니다.']);
    }
    exit;
}

// [5] 백업 복원
if (isset($_FILES['restore_file'])) {
    $uploadfile = $_FILES['restore_file'];

    if ($uploadfile['error'] === UPLOAD_ERR_OK) {
        $zip = new ZipArchive;
        if ($zip->open($uploadfile['tmp_name']) === TRUE) {
            $sqlfile = $zip->getNameIndex(0);
            $zip->extractTo($backup_dir);
            $zip->close();

            $sqlpath = $backup_dir . '/' . $sqlfile;

            $command = sprintf(
                'mysql -h%s -u%s -p%s %s < %s',
                escapeshellarg(G5_MYSQL_HOST),
                escapeshellarg(G5_MYSQL_USER),
                escapeshellarg(G5_MYSQL_PASSWORD),
                escapeshellarg(G5_MYSQL_DB),
                escapeshellarg($sqlpath)
            );

            exec($command, $output, $result);
            @unlink($sqlpath);

            if ($result === 0) {
                echo json_encode(['success' => true, 'message' => '복원이 완료되었습니다.']);
            } else {
                echo json_encode(['success' => false, 'error' => '복원 실행 중 오류가 발생했습니다.']);
            }
        } else {
            echo json_encode(['success' => false, 'error' => 'ZIP 파일을 열 수 없습니다.']);
        }
    } else {
        echo json_encode(['success' => false, 'error' => '파일 업로드 실패']);
    }
    exit;
}

// 현재 테이블 목록
$tables = getAllTables();

// 백업 파일 목록
$backups = [];
if (is_dir($backup_dir) && $handle = opendir($backup_dir)) {
    while (false !== ($file = readdir($handle))) {
        $ext = pathinfo($file, PATHINFO_EXTENSION);
        if ($ext === 'zip' || $ext === 'sql') {
            $meta_file = $backup_dir . '/' . $file . '.meta';
            $meta = [];
            if (file_exists($meta_file)) {
                $meta = json_decode(file_get_contents($meta_file), true);
            }
            
            $backups[] = [
                'filename' => $file,
                'size' => filesize($backup_dir . '/' . $file),
                'date' => filemtime($backup_dir . '/' . $file),
                'meta' => $meta
            ];
        }
    }
    closedir($handle);
}
usort($backups, function ($a, $b) {
    return $b['date'] - $a['date'];
});
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>데이터베이스 백업/복원 - NEW ADM</title>
    <link rel="stylesheet" href="/css/setting.css">
    <link rel="stylesheet" href="/css/newadmin.css">
    <link rel="stylesheet" href="/css/base_core.css">
    <style>
        .table-list {
            max-height: 400px;
            overflow-y: auto;
            border: 1px solid #dee2e6;
            border-radius: 8px;
        }
        .table-item {
            padding: 12px 16px;
            border-bottom: 1px solid #f0f0f0;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .table-item:last-child {
            border-bottom: none;
        }
        .table-item:hover {
            background: #f8f9fa;
        }
        .dropzone {
            border: 3px dashed #dee2e6;
            background: #f8f9fa;
            transition: all 0.3s;
        }
        .dropzone.dragover {
            border-color: var(--main-color);
            background: rgba(0, 123, 255, 0.05);
        }
    </style>
</head>
<body>
    <div id="admin_wrapper">
        <?php include_once('../aside.php'); ?>

        <main class="content_area">
            <h2 class="admin-card-title u-mb-32">💾 데이터베이스 백업/복원</h2>

            <!-- 테이블 선택 -->
            <section class="card_custom u-mb-24">
                <h3 class="t-fs-20 fw-800 u-mb-20">백업할 테이블 선택 (<?= count($tables) ?>개)</h3>
                
                <div class="u-mb-16">
                    <label style="display: inline-flex; align-items: center; gap: 8px;">
                        <input type="checkbox" id="selectAll" onclick="toggleSelectAll()">
                        <strong>전체 선택/해제</strong>
                    </label>
                </div>
                
                <form method="post" id="backupForm">
                    <input type="hidden" name="mode" value="backup">
                    <div class="table-list">
                        <?php foreach ($tables as $table): ?>
                            <label class="table-item">
                                <input type="checkbox" name="tables[]" value="<?= $table['name'] ?>" class="table-checkbox">
                                <div style="flex: 1;">
                                    <strong><?= $table['name'] ?></strong>
                                    <div style="font-size: 12px; color: #666;">
                                        <?= number_format($table['rows']) ?> rows · <?= $table['size'] ?> MB
                                    </div>
                                </div>
                            </label>
                        <?php endforeach; ?>
                    </div>
                    
                    <div class="g-cols-fit-12 u-gap-12 u-mt-20">
                        <button type="submit" class="u-btn u-btn-main rounded-8">
                            선택한 테이블 백업 (.zip)
                        </button>
                        <button type="button" onclick="generateInstallSQL()" class="u-btn u-btn-gray rounded-8">
                            설치용 SQL 생성 (구조만)
                        </button>
                    </div>
                </form>
            </section>

            <!-- 백업 복원 -->
            <section class="card_custom u-mb-24">
                <h3 class="t-fs-20 fw-800 u-mb-20">백업 복원</h3>
                <div id="dropZone" class="dropzone rounded-12 u-p-40" style="text-align: center; cursor: pointer;">
                    <span class="material-symbols-outlined u-txt-muted" style="font-size: 48px;">cloud_upload</span>
                    <p class="t-fs-16 fw-700 u-mt-12">백업 파일(.zip)을 드래그하거나 클릭</p>
                    <input type="file" id="fileInput" accept=".zip" style="display: none;">
                </div>
            </section>

            <!-- 백업 이력 -->
            <section class="card_custom">
                <h3 class="t-fs-20 fw-800 u-mb-24">백업 이력 (<?= count($backups) ?>)</h3>
                <div class="u-bd-1 u-bc-gray-200 rounded-12" style="overflow: hidden;">
                    <?php if (empty($backups)): ?>
                        <div class="u-p-40 text-center u-txt-muted">백업 내역이 없습니다.</div>
                    <?php else: ?>
                        <?php foreach ($backups as $index => $backup): ?>
                            <div class="backup_item u-py-16 u-px-20 <?= $index < count($backups) - 1 ? 'u-bd-b-1 u-bc-gray-200' : '' ?>">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <p class="fw-700"><?= $backup['filename'] ?></p>
                                        <p class="c-fs-12 u-txt-muted">
                                            <?= date('Y-m-d H:i:s', $backup['date']) ?> · 
                                            <?= number_format($backup['size'] / 1024, 1) ?> KB
                                            <?php if (!empty($backup['meta']['table_count'])): ?>
                                                · <?= $backup['meta']['table_count'] ?>개 테이블
                                            <?php endif; ?>
                                        </p>
                                        <?php if (!empty($backup['meta']['tables'])): ?>
                                            <p class="c-fs-11 u-txt-muted u-mt-4">
                                                <?= implode(', ', array_slice($backup['meta']['tables'], 0, 5)) ?>
                                                <?php if (count($backup['meta']['tables']) > 5): ?>
                                                    외 <?= count($backup['meta']['tables']) - 5 ?>개
                                                <?php endif; ?>
                                            </p>
                                        <?php endif; ?>
                                    </div>
                                    <div class="d-flex u-gap-8">
                                        <a href="?download=<?= urlencode($backup['filename']) ?>" class="u-btn u-btn-main rounded-8 u-px-12 u-py-8">다운로드</a>
                                        <button onclick="deleteBackup('<?= $backup['filename'] ?>')" class="u-btn u-btn-gray rounded-8 u-px-12 u-py-8">삭제</button>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </section>
        </main>
    </div>

    <script>
        function toggleSelectAll() {
            const selectAll = document.getElementById('selectAll');
            const checkboxes = document.querySelectorAll('.table-checkbox');
            checkboxes.forEach(cb => cb.checked = selectAll.checked);
        }

        function generateInstallSQL() {
            const checkboxes = document.querySelectorAll('.table-checkbox:checked');
            if (checkboxes.length === 0) {
                alert_toast('테이블을 선택해주세요.');
                return;
            }

            const formData = new FormData();
            formData.append('mode', 'generate_install_sql');
            checkboxes.forEach(cb => formData.append('tables[]', cb.value));

            fetch('', { method: 'POST', body: formData })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        alert_toast('SQL 파일이 생성되었습니다.', 'success');
                        window.location.href = data.download_url;
                    } else {
                        alert_toast('실패: ' + data.error, 'error');
                    }
                });
        }

        // Drag & Drop
        const dropZone = document.getElementById('dropZone');
        const fileInput = document.getElementById('fileInput');

        dropZone.onclick = () => fileInput.click();
        dropZone.ondragover = (e) => {
            e.preventDefault();
            dropZone.classList.add('dragover');
        };
        dropZone.ondragleave = () => dropZone.classList.remove('dragover');
        dropZone.ondrop = (e) => {
            e.preventDefault();
            dropZone.classList.remove('dragover');
            const file = e.dataTransfer.files[0];
            if (file && file.name.endsWith('.zip')) uploadFile(file);
        };

        fileInput.onchange = (e) => {
            if (e.target.files[0]) uploadFile(e.target.files[0]);
        };

        function uploadFile(file) {
            if (!confirm('정말 복원하시겠습니까? 현재 데이터가 모두 대체됩니다.')) return;
            const formData = new FormData();
            formData.append('restore_file', file);
            fetch('', { method: 'POST', body: formData })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        alert_toast(data.message);
                        location.reload();
                    } else alert_toast('실패: ' + data.error);
                });
        }

        function deleteBackup(filename) {
            if (!confirm('삭제하시겠습니까?')) return;
            const formData = new FormData();
            formData.append('mode', 'delete');
            formData.append('file', filename);
            fetch('', { method: 'POST', body: formData })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        alert_toast('삭제되었습니다.');
                        location.reload();
                    } else {
                        alert_toast('실패: ' + (data.error || '알 수 없는 오류'));
                    }
                });
        }
    </script>
</body>
</html>