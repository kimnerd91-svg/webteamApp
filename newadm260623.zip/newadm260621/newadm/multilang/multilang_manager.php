<?php
// ============================================================
// 다국어 관리자 v2
// ============================================================

// ============ 병원별 설정 (여기만 수정) ============
$PAGES_ROOT      = $_SERVER['DOCUMENT_ROOT'];
$PAGES_DIR       = '/sub';
$LANG_DIR        = $_SERVER['DOCUMENT_ROOT'] . '/lang';
$DEFAULT_API_KEY = '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';
// ===================================================

if (!is_dir($LANG_DIR)) @mkdir($LANG_DIR, 0755, true);

// ──────────────────────────────────────────────────
// AJAX — _common.php include 전에 먼저 처리
// ──────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['action'])) {
    header('Content-Type: application/json; charset=UTF-8');

    switch ($_POST['action']) {

        case 'list_pages':
            $dir   = $PAGES_ROOT . $PAGES_DIR;
            $files = [];
            if (is_dir($dir)) {
                $iter = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS));
                foreach ($iter as $f) {
                    if ($f->getExtension() === 'php') {
                        $files[] = str_replace($PAGES_ROOT, '', $f->getPathname());
                    }
                }
                sort($files);
            }
            echo json_encode(['pages' => $files]);
            exit;

        case 'extract':
            $page     = $_POST['page'] ?? '';
            $filepath = $PAGES_ROOT . $page;
            if (!$page || !file_exists($filepath)) {
                echo json_encode(['error' => '파일 없음: ' . $page]); exit;
            }
            echo json_encode(['texts' => extractKorean($filepath)]);
            exit;

        case 'translate':
            $apiKey = trim($_POST['api_key'] ?? '');
            $raw    = $_POST['texts'] ?? '';
            $texts  = json_decode($raw, true);
            $lang   = $_POST['lang'] ?? 'en';

            if (!$apiKey)        { echo json_encode(['error' => 'API 키 없음']); exit; }
            if (!is_array($texts) || empty($texts)) {
                echo json_encode(['error' => 'texts 오류: raw=' . substr($raw, 0, 80)]); exit;
            }

            $langMap  = ['en' => '영어', 'ja' => '일본어', 'zh' => '중국어(간체)'];
            $langName = $langMap[$lang] ?? '영어';
            $list     = '';
            foreach ($texts as $i => $t) $list .= ($i+1).'. '.str_replace("\n",' ',$t)."\n";

            $prompt = "아래 한국어 치과 텍스트를 {$langName}로 번역하세요.\n"
                    . "JSON 배열로만 응답하세요. 예: [\"번역1\",\"번역2\"]\n설명 없이 JSON만.\n\n" . $list;

            echo json_encode(callClaude($apiKey, $prompt));
            exit;

        case 'save':
            $page     = preg_replace('/[^a-zA-Z0-9_\-\/]/', '_', $_POST['page'] ?? '');
            $data     = json_decode($_POST['data'] ?? '{}', true);
            $filename = $LANG_DIR . '/' . str_replace('/', '__', ltrim($page, '/')) . '.json';
            file_put_contents($filename, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
            echo json_encode(['ok' => true]);
            exit;

        case 'load':
            $page     = preg_replace('/[^a-zA-Z0-9_\-\/]/', '_', $_POST['page'] ?? '');
            $filename = $LANG_DIR . '/' . str_replace('/', '__', ltrim($page, '/')) . '.json';
            $data     = file_exists($filename) ? json_decode(file_get_contents($filename), true) : [];
            echo json_encode(['data' => $data ?: new stdClass()]);
            exit;
    }

    echo json_encode(['error' => '알 수 없는 액션']);
    exit;
}

// ──────────────────────────────────────────────────
// 페이지 렌더링용 include
// ──────────────────────────────────────────────────
chdir(dirname(__FILE__) . '/../..');
include_once('./_common.php');

// ──────────────────────────────────────────────────
// 함수
// ──────────────────────────────────────────────────
function extractKorean($filepath) {
    $raw = file_get_contents($filepath);
    $raw = preg_replace('/<\?(?:php|=).*?\?>/s', ' ', $raw);
    $raw = preg_replace('/<script\b[^>]*>.*?<\/script>/si', '', $raw);
    $raw = preg_replace('/<style\b[^>]*>.*?<\/style>/si', '', $raw);
    $raw = preg_replace('/<!--.*?-->/s', '', $raw);

    $doc = new DOMDocument('1.0', 'UTF-8');
    libxml_use_internal_errors(true);
    $doc->loadHTML('<?xml encoding="UTF-8">' . $raw, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
    libxml_clear_errors();

    $results = [];
    foreach ((new DOMXPath($doc))->query('//text()') as $node) {
        $text = trim(preg_replace('/\s+/', ' ', $node->textContent));
        if (preg_match('/[\x{AC00}-\x{D7A3}]/u', $text) && mb_strlen($text, 'UTF-8') >= 2) {
            $results[] = $text;
        }
    }
    return array_values(array_unique($results));
}

function callClaude($apiKey, $prompt) {
    $body = json_encode([
        'model'      => 'claude-sonnet-4-20250514',
        'max_tokens' => 4096,
        'messages'   => [['role' => 'user', 'content' => $prompt]],
    ]);
    $ch = curl_init('https://api.anthropic.com/v1/messages');
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 60,
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'x-api-key: ' . $apiKey,
            'anthropic-version: 2023-06-01',
        ],
        CURLOPT_POSTFIELDS => $body,
    ]);
    $res  = curl_exec($ch);
    $err  = curl_error($ch);
    $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($err)         return ['error' => 'cURL 오류: ' . $err];
    if ($http !== 200) return ['error' => 'API HTTP ' . $http . ': ' . substr($res, 0, 300)];

    $data = json_decode($res, true);
    $text = $data['content'][0]['text'] ?? '';
    $text = preg_replace('/^```json\s*|\s*```$/m', '', trim($text));
    $arr  = json_decode($text, true);
    if (is_array($arr)) return ['translations' => $arr];
    return ['error' => '파싱 실패: ' . substr($text, 0, 200)];
}
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>다국어 텍스트 관리</title>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet">
<style>
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: 'Pretendard', 'Apple SD Gothic Neo', sans-serif; background: #f5f6fa; color: #1a1a2e; }
#admin_wrapper { display: flex; min-height: 100vh; }
.content_area { flex: 1; padding: 40px; overflow-x: hidden; display: flex; flex-direction: column; gap: 20px; }
.page_title { font-size: 22px; font-weight: 700; display: flex; align-items: center; gap: 10px; margin-bottom: 4px; }
.page_title .material-symbols-outlined { font-size: 24px; color: #4f46e5; }
.card { background: #fff; border-radius: 12px; box-shadow: 0 2px 12px rgba(0,0,0,.06); border: 1px solid #e8eaf0; overflow: hidden; }
.card_hd { padding: 14px 20px; border-bottom: 1px solid #e8eaf0; display: flex; align-items: center; justify-content: space-between; gap: 12px; flex-wrap: wrap; }
.card_hd_title { font-size: 14px; font-weight: 700; display: flex; align-items: center; gap: 6px; }
.card_hd_title .material-symbols-outlined { font-size: 16px; color: #4f46e5; }
.card_body { padding: 20px; display: flex; flex-direction: column; gap: 14px; }
.ctrl_bar { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
.ctrl_select { height: 38px; padding: 0 12px; border: 1px solid #e8eaf0; border-radius: 8px; font-size: 13px; font-family: inherit; background: #f5f6fa; color: #1a1a2e; outline: none; cursor: pointer; min-width: 280px; }
.ctrl_select:focus { border-color: #4f46e5; }
.btn { display: inline-flex; align-items: center; gap: 5px; padding: 8px 16px; border: none; border-radius: 8px; font-size: 13px; font-weight: 700; cursor: pointer; font-family: inherit; transition: all .2s; }
.btn_primary { background: #4f46e5; color: #fff; }
.btn_primary:hover { background: #4338ca; }
.btn_success { background: #059669; color: #fff; }
.btn_success:hover { background: #047857; }
.btn_neutral { background: #f5f6fa; color: #5c5c7a; border: 1px solid #e8eaf0; }
.btn_neutral:hover { background: #e8eaf0; }
.btn_sm { padding: 5px 10px; font-size: 12px; border-radius: 6px; }
.btn .material-symbols-outlined { font-size: 15px; }
.api_row { display: flex; align-items: center; gap: 8px; }
.api_input { flex: 1; height: 38px; padding: 0 12px; border: 1px solid #e8eaf0; border-radius: 8px; font-size: 13px; font-family: inherit; background: #f5f6fa; outline: none; }
.api_input:focus { border-color: #4f46e5; background: #fff; }
.label { font-size: 11px; font-weight: 700; color: #9999bb; display: block; margin-bottom: 6px; }
.lang_tabs { display: flex; gap: 6px; }
.lang_tab { padding: 6px 16px; border: 1px solid #e8eaf0; border-radius: 20px; font-size: 12px; font-weight: 700; cursor: pointer; background: #f5f6fa; color: #9999bb; transition: all .15s; }
.lang_tab.active { background: #4f46e5; border-color: #4f46e5; color: #fff; }
.trans_table { width: 100%; border-collapse: collapse; font-size: 13px; }
.trans_table thead tr { background: #fafafa; }
.trans_table th { padding: 10px 12px; text-align: left; font-size: 11px; font-weight: 700; color: #9999bb; text-transform: uppercase; border-bottom: 1px solid #e8eaf0; }
.trans_table td { padding: 8px 12px; border-bottom: 1px solid #f5f5f5; vertical-align: top; }
.trans_table tbody tr:hover { background: #fafbff; }
.ko_cell { color: #1a1a2e; font-weight: 500; line-height: 1.6; max-width: 320px; }
.trans_input { width: 100%; padding: 8px 10px; border: 1px solid #e8eaf0; border-radius: 6px; font-size: 13px; font-family: inherit; background: #f5f6fa; color: #1a1a2e; resize: vertical; min-height: 60px; outline: none; line-height: 1.6; transition: all .2s; }
.trans_input:focus { border-color: #4f46e5; background: #fff; }
.trans_input.filled { background: #f0fdf4; border-color: #bbf7d0; }
.stats_row { display: flex; gap: 12px; flex-wrap: wrap; }
.stat_box { background: #f5f6fa; border-radius: 8px; padding: 10px 16px; font-size: 12px; color: #9999bb; }
.stat_box strong { font-size: 20px; font-weight: 700; color: #1a1a2e; display: block; }
.empty_state { text-align: center; padding: 60px; color: #9999bb; }
.empty_state .material-symbols-outlined { font-size: 48px; display: block; margin-bottom: 12px; }
.loading_overlay { position: fixed; inset: 0; background: rgba(255,255,255,.8); align-items: center; justify-content: center; z-index: 9999; display: none; }
.spinner { width: 36px; height: 36px; border: 3px solid #e8eaf0; border-top-color: #4f46e5; border-radius: 50%; animation: spin .8s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }
.toast { position: fixed; top: 20px; right: 20px; padding: 12px 18px; border-radius: 10px; font-size: 13px; font-weight: 600; display: flex; align-items: center; gap: 7px; z-index: 9999; box-shadow: 0 4px 16px rgba(0,0,0,.12); animation: tin .22s ease; }
.toast.ok { background: #f0fdf4; border: 1px solid #bbf7d0; color: #059669; }
.toast.error { background: #fef2f2; border: 1px solid #fecaca; color: #dc2626; }
@keyframes tin { from { opacity:0; transform:translateX(12px); } to { opacity:1; transform:none; } }
</style>
</head>
<body>

<div class="loading_overlay" id="loading" style="display:none;flex;">
    <div style="display:flex;flex-direction:column;align-items:center;gap:12px;">
        <div class="spinner"></div>
        <span id="loading_msg" style="font-size:13px;color:#5c5c7a;">처리 중...</span>
    </div>
</div>

<div id="admin_wrapper">
    <?php include_once('./adm/aside.php'); ?>

    <main class="content_area">

        <h2 class="page_title">
            <span class="material-symbols-outlined">translate</span>다국어 텍스트 관리
        </h2>

        <!-- 설정 카드 -->
        <div class="card">
            <div class="card_hd">
                <span class="card_hd_title"><span class="material-symbols-outlined">settings</span>설정</span>
            </div>
            <div class="card_body">
                <div>
                    <label class="label">Claude API 키</label>
                    <div class="api_row">
                        <input type="password" id="api_key" class="api_input" placeholder="sk-ant-api03-..." autocomplete="off">
                        <button class="btn btn_neutral btn_sm" onclick="toggleApiKey()">
                            <span class="material-symbols-outlined" style="font-size:14px">visibility</span>
                        </button>
                        <span id="api_status" style="font-size:12px;color:#9999bb;">미입력</span>
                    </div>
                </div>
                <div>
                    <label class="label">페이지 선택</label>
                    <div class="ctrl_bar">
                        <select id="page_select" class="ctrl_select" onchange="onPageChange()">
                            <option value="">-- 페이지를 선택하세요 --</option>
                        </select>
                        <button class="btn btn_primary" onclick="extractTexts()">
                            <span class="material-symbols-outlined">search</span>텍스트 추출
                        </button>
                        <button class="btn btn_neutral" onclick="loadSaved()">
                            <span class="material-symbols-outlined">download</span>저장된 번역 불러오기
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- 번역 카드 -->
        <div class="card" id="trans_card" style="display:none;">
            <div class="card_hd">
                <span class="card_hd_title">
                    <span class="material-symbols-outlined">edit_note</span>
                    번역 편집
                    <span id="page_badge" style="font-size:11px;font-weight:400;color:#9999bb;"></span>
                </span>
                <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
                    <div class="lang_tabs">
                        <button class="lang_tab active" onclick="switchLang('en',this)">🇺🇸 EN</button>
                        <button class="lang_tab" onclick="switchLang('ja',this)">🇯🇵 JA</button>
                        <button class="lang_tab" onclick="switchLang('zh',this)">🇨🇳 ZH</button>
                    </div>
                    <button class="btn btn_primary btn_sm" onclick="autoTranslate()">
                        <span class="material-symbols-outlined">auto_fix_high</span>AI 초벌번역
                    </button>
                    <button class="btn btn_success btn_sm" onclick="saveTranslations()">
                        <span class="material-symbols-outlined">save</span>저장
                    </button>
                </div>
            </div>
            <div class="card_body">
                <div class="stats_row" id="stats_row"></div>
                <div style="overflow-x:auto;">
                    <table class="trans_table">
                        <thead>
                            <tr>
                                <th style="width:40px;">#</th>
                                <th style="width:40%;">원문 (한국어)</th>
                                <th id="lang_col_label">번역 (EN)</th>
                            </tr>
                        </thead>
                        <tbody id="trans_tbody"></tbody>
                    </table>
                </div>
            </div>
        </div>

    </main>
</div>

<script>
var DEFAULT_API_KEY = '<?= $DEFAULT_API_KEY ?>';

var state = { page:'', texts:[], trans:{}, lang:'en' };

window.onload = function() {
    var saved = localStorage.getItem('claude_api_key') || DEFAULT_API_KEY;
    document.getElementById('api_key').value = saved;
    updateApiStatus(saved);
    loadPages();
};

document.getElementById('api_key').addEventListener('input', function() {
    localStorage.setItem('claude_api_key', this.value);
    updateApiStatus(this.value);
});

function updateApiStatus(k) {
    var el = document.getElementById('api_status');
    if (k && k.startsWith('sk-ant')) { el.textContent = '✅ 입력됨'; el.style.color = '#059669'; }
    else { el.textContent = '미입력'; el.style.color = '#9999bb'; }
}
function toggleApiKey() {
    var i = document.getElementById('api_key');
    i.type = i.type === 'password' ? 'text' : 'password';
}

function loadPages() {
    post({ action: 'list_pages' }, function(res) {
        var sel = document.getElementById('page_select');
        (res.pages || []).forEach(function(p) {
            var o = document.createElement('option');
            o.value = p; o.textContent = p;
            sel.appendChild(o);
        });
    });
}

function onPageChange() {
    state.page = document.getElementById('page_select').value;
    state.texts = []; state.trans = {};
    document.getElementById('trans_card').style.display = 'none';
}

function extractTexts() {
    if (!state.page) { toast('페이지를 선택해주세요.', 'error'); return; }
    showLoading('텍스트 추출 중...');
    post({ action: 'extract', page: state.page }, function(res) {
        hideLoading();
        if (res.error) { toast(res.error, 'error'); return; }
        state.texts = res.texts || [];
        if (!state.texts.length) { toast('추출된 한국어 텍스트가 없습니다.', 'error'); return; }
        state.texts.forEach(function(t) { if (!state.trans[t]) state.trans[t] = {en:'',ja:'',zh:''}; });
        renderTable();
        document.getElementById('trans_card').style.display = 'block';
        document.getElementById('page_badge').textContent = '— ' + state.page;
        toast(state.texts.length + '개 텍스트 추출 완료', 'ok');
    });
}

function loadSaved() {
    if (!state.page) { toast('페이지를 선택해주세요.', 'error'); return; }
    showLoading('불러오는 중...');
    post({ action: 'load', page: state.page }, function(res) {
        hideLoading();
        if (res.data && typeof res.data === 'object' && Object.keys(res.data).length) {
            Object.keys(res.data).forEach(function(k) {
                if (!state.trans[k]) state.trans[k] = {en:'',ja:'',zh:''};
                Object.assign(state.trans[k], res.data[k]);
                if (state.texts.indexOf(k) === -1) state.texts.push(k);
            });
            renderTable();
            document.getElementById('trans_card').style.display = 'block';
            document.getElementById('page_badge').textContent = '— ' + state.page;
            toast('저장된 번역을 불러왔습니다.', 'ok');
        } else { toast('저장된 번역이 없습니다.', 'error'); }
    });
}

function switchLang(lang, btn) {
    syncFromTable();
    state.lang = lang;
    document.querySelectorAll('.lang_tab').forEach(function(b) { b.classList.remove('active'); });
    btn.classList.add('active');
    document.getElementById('lang_col_label').textContent = '번역 (' + lang.toUpperCase() + ')';
    renderTable();
}

function renderTable() {
    var tbody = document.getElementById('trans_tbody');
    tbody.innerHTML = '';
    if (!state.texts.length) {
        tbody.innerHTML = '<tr><td colspan="3"><div class="empty_state"><span class="material-symbols-outlined">translate</span>텍스트를 추출하거나 저장된 번역을 불러오세요.</div></td></tr>';
        updateStats(); return;
    }
    state.texts.forEach(function(text, i) {
        var val = (state.trans[text] && state.trans[text][state.lang]) || '';
        var tr = document.createElement('tr');
        tr.innerHTML =
            '<td style="color:#9999bb;font-size:12px;text-align:center;">' + (i+1) + '</td>' +
            '<td><div class="ko_cell">' + esc(text) + '</div></td>' +
            '<td><textarea class="trans_input' + (val?' filled':'') + '" data-key="' + esc(text) + '" rows="3" oninput="onInput(this)">' + esc(val) + '</textarea></td>';
        tbody.appendChild(tr);
    });
    updateStats();
}

function onInput(el) {
    var key = el.getAttribute('data-key');
    if (!state.trans[key]) state.trans[key] = {en:'',ja:'',zh:''};
    state.trans[key][state.lang] = el.value;
    el.classList.toggle('filled', !!el.value);
    updateStats();
}

function syncFromTable() {
    document.querySelectorAll('#trans_tbody textarea').forEach(function(el) {
        var key = el.getAttribute('data-key');
        if (key) {
            if (!state.trans[key]) state.trans[key] = {en:'',ja:'',zh:''};
            state.trans[key][state.lang] = el.value;
        }
    });
}

function updateStats() {
    var total = state.texts.length;
    var filled = state.texts.filter(function(t) { return state.trans[t] && state.trans[t][state.lang]; }).length;
    var pct = total ? Math.round(filled/total*100) : 0;
    document.getElementById('stats_row').innerHTML =
        '<div class="stat_box"><strong>' + total + '</strong>전체</div>' +
        '<div class="stat_box"><strong>' + filled + '</strong>번역 완료</div>' +
        '<div class="stat_box"><strong>' + (total-filled) + '</strong>미번역</div>' +
        '<div class="stat_box"><strong>' + pct + '%</strong>진행률</div>';
}

function autoTranslate() {
    var apiKey = document.getElementById('api_key').value.trim();
    if (!apiKey) { toast('Claude API 키를 입력해주세요.', 'error'); return; }
    if (!state.texts.length) { toast('먼저 텍스트를 추출해주세요.', 'error'); return; }

    var toTranslate = state.texts.filter(function(t) {
        return !(state.trans[t] && state.trans[t][state.lang]);
    });
    if (!toTranslate.length) { toast('번역할 항목이 없습니다. (모두 완료됨)', 'ok'); return; }
    if (!confirm(toTranslate.length + '개 미번역 항목을 Claude로 초벌번역합니다.')) return;

    showLoading('Claude가 번역 중... (' + toTranslate.length + '개)');

    var fd = new FormData();
    fd.append('action', 'translate');
    fd.append('api_key', apiKey);
    fd.append('lang', state.lang);
    fd.append('texts', JSON.stringify(toTranslate));

    fetch(location.pathname, { method:'POST', body:fd })
        .then(function(r) { return r.json(); })
        .then(function(res) {
            hideLoading();
            if (res.error) { toast('번역 오류: ' + res.error, 'error'); return; }
            var arr = res.translations || [];
            arr.forEach(function(translated, i) {
                var key = toTranslate[i];
                if (key && translated) {
                    if (!state.trans[key]) state.trans[key] = {en:'',ja:'',zh:''};
                    state.trans[key][state.lang] = translated;
                }
            });
            renderTable();
            toast(arr.length + '개 초벌번역 완료. 수정 후 저장해주세요.', 'ok');
        })
        .catch(function(e) { hideLoading(); toast('통신 오류: ' + e.message, 'error'); });
}

function saveTranslations() {
    syncFromTable();
    if (!state.page) { toast('페이지를 선택해주세요.', 'error'); return; }
    showLoading('저장 중...');
    post({ action:'save', page:state.page, data:JSON.stringify(state.trans) }, function(res) {
        hideLoading();
        res.ok ? toast('저장되었습니다.', 'ok') : toast('저장 실패', 'error');
    });
}

function post(params, cb) {
    var fd = new FormData();
    Object.keys(params).forEach(function(k) { fd.append(k, params[k]); });
    fetch(location.pathname, { method:'POST', body:fd })
        .then(function(r) { return r.json(); })
        .then(cb)
        .catch(function(e) { hideLoading(); toast('통신 오류: ' + e.message, 'error'); });
}

function esc(str) {
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function showLoading(msg) {
    document.getElementById('loading_msg').textContent = msg || '처리 중...';
    document.getElementById('loading').style.display = 'flex';
}
function hideLoading() { document.getElementById('loading').style.display = 'none'; }
function toast(msg, type) {
    var el = document.createElement('div');
    el.className = 'toast ' + (type||'ok');
    el.innerHTML = '<span class="material-symbols-outlined" style="font-size:16px">' + (type==='error'?'error':'check_circle') + '</span>' + msg;
    document.body.appendChild(el);
    setTimeout(function() { el.style.transition='opacity .3s'; el.style.opacity='0'; setTimeout(function(){el.remove();},300); }, 3000);
}
</script>
</body>
</html>