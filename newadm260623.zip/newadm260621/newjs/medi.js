// ==========================================
// 토스트 메시지 (전역 — DOMContentLoaded 밖)
// ==========================================
window.showToast = function (message, type) {
    type = type || 'default';
    var existingToast = document.querySelector('.toast-message');
    if (existingToast) existingToast.remove();

    var toast = document.createElement('div');
    toast.className = 'toast-message';
    if (type === 'success') toast.classList.add('success');
    if (type === 'error')   toast.classList.add('error');
    if (type === 'warning') toast.classList.add('warning');
    toast.textContent = message;

    document.body.appendChild(toast);
    setTimeout(function () { toast.classList.add('show'); }, 10);
    setTimeout(function () {
        toast.classList.remove('show');
        setTimeout(function () { toast.remove(); }, 300);
    }, 2500);
};


// ==========================================
// 스크롤 깊이 트래킹 (전역 — DOMContentLoaded 밖)
// ==========================================
var scrollTracked = { '25': false, '50': false, '75': false, '100': false };

window.addEventListener('scroll', function () {
    var scrollHeight = document.documentElement.scrollHeight - window.innerHeight;
    if (scrollHeight <= 0) return;
    var scrolled = (window.scrollY / scrollHeight) * 100;

    [25, 50, 75, 100].forEach(function (depth) {
        var key = String(depth);
        if (scrolled >= (depth === 100 ? 99 : depth) && !scrollTracked[key]) {
            scrollTracked[key] = true;
            if (typeof gtag !== 'undefined') {
                gtag('event', 'scroll_depth', {
                    depth: depth + '%',
                    page_location: window.location.href
                });
            }
        }
    });
});


document.addEventListener('DOMContentLoaded', function () {

    // ==========================================
    // 1. 스크롤 탑 버튼
    // ==========================================
    var scrollTopBtn  = document.getElementById('scrollTop');
    var scrollTopBtn2 = document.getElementById('scrollTop2');

    function handleScrollTop() {
        var show = window.scrollY > 300;
        if (scrollTopBtn) {
            scrollTopBtn.style.opacity       = show ? '1' : '0';
            scrollTopBtn.style.pointerEvents = show ? 'auto' : 'none';
        }
        if (scrollTopBtn2) {
            scrollTopBtn2.style.opacity       = show ? '1' : '0';
            scrollTopBtn2.style.pointerEvents = show ? 'auto' : 'none';
        }
    }
    window.addEventListener('scroll', handleScrollTop);

    if (scrollTopBtn)  scrollTopBtn.addEventListener('click',  function () { window.scrollTo({ top: 0, behavior: 'smooth' }); });
    if (scrollTopBtn2) scrollTopBtn2.addEventListener('click', function () { window.scrollTo({ top: 0, behavior: 'smooth' }); });


    // ==========================================
    // 2. 케이스 탭 전환 (tab-btn)
    // ==========================================
    var tabButtons  = document.querySelectorAll('.tab-btn');
    var tabContents = document.querySelectorAll('.tab-contents');

    tabButtons.forEach(function (button) {
        button.addEventListener('click', function () {
            tabButtons.forEach(function (btn) { btn.classList.remove('active'); });
            this.classList.add('active');

            tabContents.forEach(function (content) {
                content.classList.remove('active');
                content.style.display = 'none';
            });

            var tabId = this.getAttribute('data-tab');
            var targetTab = document.getElementById(tabId);
            if (targetTab) {
                targetTab.classList.add('active');
                targetTab.style.display = 'grid';
            }
        });
    });

    tabContents.forEach(function (content, index) {
        content.style.display = index === 0 ? 'grid' : 'none';
    });


    // ==========================================
    // 3. 진료 항목 탭 전환 (doc-btn)
    // ==========================================
    var docButtons = document.querySelectorAll('.doc-btn');

    docButtons.forEach(function (button) {
        button.addEventListener('click', function () {
            var targetTab = this.getAttribute('data-tab');

            document.querySelectorAll('.tab-content').forEach(function (content) {
                content.classList.remove('active');
            });
            document.querySelectorAll('.doc-btn').forEach(function (btn) {
                btn.classList.remove('active');
            });

            var targetEl = document.getElementById(targetTab);
            if (targetEl) targetEl.classList.add('active');
            document.querySelectorAll('[data-tab="' + targetTab + '"]').forEach(function (btn) {
                btn.classList.add('active');
            });
        });
    });


    // ==========================================
    // 4. sect06 — 데스크톱 GSAP 스크롤 + 모바일 Swiper
    // ==========================================
    if (typeof gsap !== 'undefined' && typeof ScrollTrigger !== 'undefined') {
        gsap.registerPlugin(ScrollTrigger, ScrollToPlugin);

        if (window.innerWidth >= 769) {
            ScrollTrigger.create({
                trigger: '#sect06 .slide-wrap',
                start: '0% 0%',
                end: '100% 0%',
                scrub: true,
                onUpdate: function (self) {
                    var idx = Math.min(Math.floor(self.progress * 4), 4);

                    document.querySelectorAll('#sect06 .service-list li').forEach(function (item, i) {
                        item.classList.toggle('active', i === idx);
                    });
                    document.querySelectorAll('#sect06 .img-box .img').forEach(function (item, i) {
                        item.classList.toggle('show', i === idx);
                    });

                    var numberEl = document.querySelector('#sect06 .left-text .number');
                    if (numberEl) numberEl.textContent = '0' + (idx + 1);

                    var rightTextData = [
                        { subTitle: '대학병원급 분과별 ',      title: '4인 전문의 협진',              desc: '대학병원에 가지 않아도 집 근처에서 일반진료 부터<br>고난이도 진료까지 포괄적인 진료가 가능' },
                        { subTitle: '누적 식립 1만 건 이상 ',  title: '숫자가 증명하는 차별화된 전문성', desc: '26년 3월 기준 <br>임플란트 누적 식립 개수 1만건' },
                        { subTitle: '치료의 순간은 짧고',       title: '편안함의 기억은 오래',           desc: '의식하진정치료, 웃음가스치료, 무통마취, <br>에어플로우 스케일러 등 체계적인 통증경감 <br>시스템으로 두려움까지 낮췄습니다.' },
                        { subTitle: '가정동 150평 대형치과,',   title: '독립된 집중치료실 구축',          desc: '환자 한 분 한 분에게 온전히 집중하고, 편안한 <br>상태에서 최선의 치료 결과를 제공하기 위함' },
                    ];

                    var subTitleEl = document.querySelector('#sect06 .right-text .sub-title');
                    var titleEl    = document.querySelector('#sect06 .right-text .main-title');
                    var descEl     = document.querySelector('#sect06 .right-text .description');

                    if (rightTextData[idx]) {
                        if (subTitleEl) subTitleEl.innerHTML = rightTextData[idx].subTitle;
                        if (titleEl)    titleEl.innerHTML    = rightTextData[idx].title;
                        if (descEl)     descEl.innerHTML     = rightTextData[idx].desc;
                    }
                },
            });
        }

        if (window.innerWidth < 769) {
            new Swiper('#sect06 .swiper-service', {
                slidesPerView: 1,
                spaceBetween: 0,
                centeredSlides: true,
                loop: true,
                autoplay: { delay: 8000, disableOnInteraction: false },
                on: {
                    slideChange: function () {
                        if (typeof updateMobileActiveClass === 'function') {
                            updateMobileActiveClass(this.realIndex);
                        }
                    },
                },
            });
        }


        // ==========================================
        // sect03 — 데스크톱 GSAP 스크롤
        // ==========================================
        var sect03RightTextData = [
            { subTitle: '', title: '&lt;Top 100 Implant Doctors in Korea&gt;', desc: 'Recognized as one of the Top 100 Doctors<br> for clinical excellence and implant expertise.' },
            { subTitle: '', title: '&lt;Thesis&gt;',                           desc: 'Experiment of vasopressin receptor <br> agonist to substitute epinephrine <br> Autophagy: a multifaceted intracellular system <br>for bulk and selective recycling' },
            { subTitle: '', title: '&lt;Specialist Certification&gt;',          desc: 'Certified by the Ministry of Health and Welfare,<br> providing comprehensive <br>and systematic treatment planning.' },
            { subTitle: '', title: '&lt;Adjunct Professor&gt;',                 desc: 'Actively engaged in clinical education <br>and academic research<br> alongside ongoing patient care.' },
        ];

        var listItems  = document.querySelectorAll('main.doctors #sect03 .service-list li');
        var sect03imgs = document.querySelectorAll('main.doctors #sect03 .img-box .img');
        var bullets    = document.querySelectorAll('main.doctors #sect03 .pc-bullet');
        var s03sub     = document.querySelector('main.doctors #sect03 .right-text .sub-title');
        var s03title   = document.querySelector('main.doctors #sect03 .right-text .main-title');
        var s03desc    = document.querySelector('main.doctors #sect03 .right-text .description');

        function updateSlide(idx) {
            idx = Math.max(0, Math.min(idx, 3));
            listItems.forEach(function (el, i)  { el.classList.toggle('active', i === idx); });
            sect03imgs.forEach(function (el, i) { el.classList.toggle('show',   i === idx); });
            bullets.forEach(function (el, i)    { el.classList.toggle('active', i === idx); });
            if (s03sub)   s03sub.innerHTML   = sect03RightTextData[idx].subTitle;
            if (s03title) s03title.innerHTML = sect03RightTextData[idx].title;
            if (s03desc)  s03desc.innerHTML  = sect03RightTextData[idx].desc;
        }

        if (listItems.length > 0) {
            updateSlide(0);
            ScrollTrigger.create({
                trigger: 'main.doctors #sect03 .slide-wrap .sticky',
                start: 'top top',
                end: '+=300%',
                pin: true,
                scrub: 1,
                onUpdate: function (self) {
                    updateSlide(Math.min(Math.floor(self.progress * 4), 3));
                },
            });
        }
    }


    // ==========================================
    // 5. sect09 탭 + Swiper 초기화
    // ==========================================
    var swipers = {};

    function initSwiper(tabId) {
        if (swipers[tabId]) return;
        swipers[tabId] = new Swiper('#' + tabId + ' .swiper', {
            slidesPerView: 1,
            spaceBetween: 0,
            loop: true,
            pagination: {
                el: '#' + tabId + ' .swiper-pagination',
                clickable: true,
            },
            navigation: {
                prevEl: '#' + tabId + ' .swiper-button-prev',
                nextEl: '#' + tabId + ' .swiper-button-next',
            },
        });
    }

    if (document.getElementById('sect09-tab1')) initSwiper('sect09-tab1');

    document.querySelectorAll('.sect09-tab-btn').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var target = this.getAttribute('data-tab');

            document.querySelectorAll('.sect09-tab-btn').forEach(function (b) { b.classList.remove('active'); });
            this.classList.add('active');

            document.querySelectorAll('.sect09-tab-content').forEach(function (c) { c.classList.remove('active'); });

            var el = document.getElementById(target);
            if (el) el.classList.add('active');

            requestAnimationFrame(function () {
                if (swipers[target]) {
                    swipers[target].update();
                } else {
                    initSwiper(target);
                }
            });
        });
    });


    // ==========================================
    // 7. 퀵메뉴 (필형 토글 + 외부 클릭 닫기)
    // ==========================================
    (function () {
        var pillItems  = document.querySelector('.quick_menu_pill-items');
        var pillToggle = document.getElementById('qm_pill_toggle');
        var pillTop    = document.getElementById('qm_pill_top');

        if (pillToggle) {
            pillToggle.onclick = function () {
                pillItems.classList.toggle('active');
                pillToggle.classList.toggle('active');
                if (typeof gtag !== 'undefined') gtag('event', 'click_quick_menu', { event_category: 'engagement', event_label: 'pill_toggle' });
            };
        }

        if (pillTop) {
            pillTop.onclick = function () {
                window.scrollTo({ top: 0, behavior: 'smooth' });
                if (typeof gtag !== 'undefined') gtag('event', 'click_quick_menu', { event_category: 'engagement', event_label: 'pill_top' });
            };
        }

        var allLinks = document.querySelectorAll('.qm-circle-item, .qm-bar-item, .qm-bar-fixed-item');
        for (var i = 0; i < allLinks.length; i++) {
            allLinks[i].onclick = function (e) {
                var has = this.getAttribute('data-has');
                if (has === '0' && this.href && this.href.indexOf('#') !== -1) {
                    e.preventDefault();
                    alert('링크가 설정되지 않았습니다.');
                    return false;
                }
            };
        }

        document.addEventListener('click', function (e) {
            var pillMenu = document.getElementById('quick_menu_pill');
            if (pillMenu && !pillMenu.contains(e.target) && pillItems && pillItems.classList.contains('active')) {
                pillItems.classList.remove('active');
                if (pillToggle) pillToggle.classList.remove('active');
            }
        });
    })();


    // ==========================================
    // 8. SD 팝업 + 백드랍
    // ==========================================
    var sdBtn    = document.getElementById('SD');
    var sdPopup  = document.getElementById('SD-popup');
    var sdCancel = document.getElementById('SD-cancel');

    var sdBackdrop = document.createElement('div');
    sdBackdrop.id = 'sd-backdrop';
    Object.assign(sdBackdrop.style, { display: 'none', position: 'fixed', inset: '0', backgroundColor: 'rgba(0,0,0,0.5)', zIndex: '998' });
    document.body.appendChild(sdBackdrop);

    window.openSdPopup = function () {
        if (sdPopup) sdPopup.style.display = 'block';
        if (window.innerWidth <= 640) sdBackdrop.style.display = 'block';
    };
    window.closeSdPopup = function () {
        if (sdPopup) sdPopup.style.display = 'none';
        sdBackdrop.style.display = 'none';
    };

    if (sdBtn)    sdBtn.addEventListener('click', function (e) { e.stopPropagation(); sdPopup.style.display === 'block' ? closeSdPopup() : openSdPopup(); });
    if (sdCancel) sdCancel.addEventListener('click', function () { closeSdPopup(); });
    sdBackdrop.addEventListener('click', function () { closeSdPopup(); });
    document.addEventListener('click', function (e) {
        if (sdPopup && sdBtn && !sdPopup.contains(e.target) && !sdBtn.contains(e.target)) closeSdPopup();
    });


    // ==========================================
    // 9. 문의 드롭다운 + AJAX 폼 제출
    // ==========================================
    document.querySelectorAll('.custom-select-wrap').forEach(function (wrap) {
        var trigger = wrap.querySelector('.custom-select-trigger');
        var options = wrap.querySelector('.custom-select-options');
        var label   = wrap.querySelector('.custom-select-label');
        var arrow   = wrap.querySelector('.custom-select-arrow');
        var hidden  = document.getElementById('inquiry_type_value');

        if (!trigger) return;

        trigger.addEventListener('click', function (e) {
            e.stopPropagation();
            var isOpen = options.style.display === 'block';
            options.style.display = isOpen ? 'none' : 'block';
            arrow.style.transform = isOpen ? 'rotate(0deg)' : 'rotate(180deg)';
        });

        options.querySelectorAll('.custom-option').forEach(function (option) {
            option.addEventListener('click', function (e) {
                e.stopPropagation();
                if (hidden) hidden.value = option.dataset.value;
                label.textContent = option.textContent.trim();
                label.classList.remove('u-txt-gray-500');
                options.querySelectorAll('.custom-option').forEach(function (o) { o.classList.remove('selected'); });
                option.classList.add('selected');
                options.style.display = 'none';
                arrow.style.transform = 'rotate(0deg)';
            });
        });
    });

    document.addEventListener('click', function () {
        document.querySelectorAll('.custom-select-options').forEach(function (opt) { opt.style.display = 'none'; });
        document.querySelectorAll('.custom-select-arrow').forEach(function (a)   { a.style.transform  = 'rotate(0deg)'; });
    });

    window.submitInquiry = function (f) {
        var inquiryType = f.elements['inquiry_type'];
        if (!inquiryType || !inquiryType.value) { window.showToast('문의 분야를 선택해주세요.', 'warning'); return false; }
        if (!f.wr_name.value.trim())             { window.showToast('성함을 입력해주세요.', 'warning');    return false; }
        if (!f.wr_1.value.trim())                { window.showToast('연락처를 입력해주세요.', 'warning');  return false; }

        var submitBtn = f.querySelector('button[type="submit"]');
        submitBtn.disabled = true;
        submitBtn.innerText = '전송 중...';

        fetch('/ajax.inquiry_update.php', { method: 'POST', body: new FormData(f) })
            .then(function (res) {
                return res.text().then(function (text) {
                    try { return JSON.parse(text); } catch (e) { throw new Error('서버 내부 오류가 발생했습니다.'); }
                });
            })
            .then(function (data) {
                if (data.res === 'success') {
                    if (typeof gtag !== 'undefined') gtag('event', 'generate_lead', { event_category: 'conversion', event_label: 'inquiry_submit', inquiry_type: inquiryType.value, value: 1 });
                    var modal = document.getElementById('inquiryModal');
                    if (modal && typeof bootstrap !== 'undefined') bootstrap.Modal.getInstance(modal)?.hide();
                    f.reset();
                    window.showToast('문의가 정상적으로 접수되었습니다. 🎉', 'success');
                    setTimeout(function () { closeSdPopup(); }, 300);
                } else {
                    if (typeof gtag !== 'undefined') gtag('event', 'form_error', { event_category: 'error', event_label: 'inquiry_submit_fail' });
                    window.showToast(data.msg || '문의 접수에 실패했습니다.', 'error');
                }
            })
            .catch(function (error) {
                if (typeof gtag !== 'undefined') gtag('event', 'form_error', { event_category: 'error', event_label: 'inquiry_submit_error' });
                window.showToast(error.message || '오류가 발생했습니다.', 'error');
            })
            .finally(function () {
                submitBtn.disabled = false;
                submitBtn.innerText = '문의하기';
            });

        return false;
    };


    // ==========================================
    // 10. swiper-service2 (모바일 카드 슬라이더)
    // ==========================================
    if (document.querySelector('.swiper-service2')) {
        new Swiper('.swiper-service2', {
            loop: true,
            speed: 500,
            autoplay: { delay: 5000 },
            slidesPerView: 1,
            spaceBetween: 0,
            centeredSlides: false,
            pagination: {
                el: '.swiper-service2 .swiper-pagination',
                clickable: true,
            },
        });
    }

});