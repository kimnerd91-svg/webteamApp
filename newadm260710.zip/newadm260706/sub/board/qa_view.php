<?php
/*
 * ============================================
 * /sub/board/qa_view.php — 상담 문의 상세 (프론트, post_view.php 대체)
 * dm_consult 문의 1건을 조회. 개인정보(문의내용/답변)는
 * 접수 시 입력한 연락처(phone)를 비밀번호로 확인해야 열람 가능.
 * 확인 성공 시 세션에 기록해 같은 접속 동안 재입력 없이 열람.
 * ============================================
 */

chdir(dirname(__FILE__, 3));
include_once('./_common.php');

$id = (int)($_GET['id'] ?? 0);
$post = $id ? sql_fetch("SELECT * FROM dm_consult WHERE id = '{$id}'") : null;

if (!isset($_SESSION['consult_verified']) || !is_array($_SESSION['consult_verified'])) {
    $_SESSION['consult_verified'] = [];
}

$error = '';

/* 전화번호 확인 (숫자만 비교) */
if ($post && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['phone_pw'])) {
    $input_digits = preg_replace('/[^0-9]/', '', (string)$_POST['phone_pw']);
    $stored_digits = preg_replace('/[^0-9]/', '', (string)$post['phone']);
    if ($input_digits !== '' && $input_digits === $stored_digits) {
        $_SESSION['consult_verified'][$id] = true;
    } else {
        $error = '연락처가 일치하지 않습니다. 다시 확인해 주세요.';
    }
}

$verified = $post && !empty($_SESSION['consult_verified'][$id]);

/* 이름 마스킹 (미확인 상태에서 노출용) */
function consult_mask_name($name) {
    $name = trim((string)$name);
    if ($name === '') return '익명';
    $len = mb_strlen($name, 'utf-8');
    if ($len <= 1) return $name;
    return mb_substr($name, 0, 1, 'utf-8') . str_repeat('*', $len - 1);
}

include_once(G5_PATH . '/head_sub.php');
include_once(G5_PATH . '/head.php');
$g5['title'] = $post ? '문의 상세' : '문의 상세';
?>

<main class="u-pretendard post_view_page u-py-80 u-py-40-md">
    <div class="container" style="max-width:840px;">

        <?php if (!$post): ?>
        <div class="text-center u-py-80 c-fs-16 u-txt-gray-500">문의 내역을 찾을 수 없습니다.</div>
        <a href="./qa_list.php" class="u-btn u-btn-outline u-btn-sm">← 목록으로</a>

        <?php else: ?>

        <div class="pv_header u-mb-24">
            <p class="pv_board_name">문의 내역</p>
            <h1 class="pv_title"><?= htmlspecialchars($post['interest'] ?: '문의') ?> 문의</h1>
            <div class="pv_meta">
                <span><?= htmlspecialchars($verified ? $post['name'] : consult_mask_name($post['name'])) ?></span>
                <span><?= substr($post['created_at'], 0, 16) ?></span>
                <span><?= (trim((string)$post['reply_content']) !== '') ? '답변완료' : '답변대기' ?></span>
            </div>
        </div>

        <?php if (!$verified): ?>

        <div class="qa_lock">
            <p class="qa_lock_txt">개인정보 보호를 위해 문의 접수 시 입력하신 <strong>연락처</strong>를 확인해야 내용을 볼 수 있습니다.</p>
            <form method="post" class="qa_lock_form">
                <input type="text" name="phone_pw" placeholder="연락처 입력 ('-' 없이 입력 가능)" required>
                <button type="submit" class="u-btn u-btn-main">확인</button>
            </form>
            <?php if ($error): ?>
            <p class="qa_lock_err"><?= htmlspecialchars($error) ?></p>
            <?php endif; ?>
        </div>

        <?php else: ?>

        <div class="cm_grid">
            <div class="cm_row"><label>관심진료</label><div class="val"><?= htmlspecialchars($post['interest'] ?: '-') ?></div></div>
            <div class="cm_row"><label>희망 연락시간</label><div class="val"><?= htmlspecialchars($post['call_time'] ?: '-') ?></div></div>
        </div>

        <div class="pv_body">
            <h3 class="qa_sub_title">문의 내용</h3>
            <div class="qa_content"><?= nl2br(htmlspecialchars((string)$post['content'])) ?></div>
        </div>

        <div class="pv_body qa_reply_block">
            <h3 class="qa_sub_title">답변</h3>
            <?php if (trim((string)$post['reply_content']) !== ''): ?>
            <div class="qa_content"><?= nl2br(htmlspecialchars((string)$post['reply_content'])) ?></div>
            <p class="qa_reply_date"><?= $post['reply_at'] ? substr($post['reply_at'], 0, 16) : '' ?></p>
            <?php else: ?>
            <p class="qa_no_reply">아직 등록된 답변이 없습니다. 확인 후 순차적으로 답변드리겠습니다.</p>
            <?php endif; ?>
        </div>

        <?php endif; ?>

        <div class="u-mt-40">
            <a href="./qa_list.php" class="u-btn u-btn-outline">← 목록으로</a>
        </div>

        <?php endif; ?>
    </div>
</main>

<style>
    .post_view_page {
        min-height: 80vh;
    }
    .pv_header { border-bottom:2px solid var(--main-color, #304F4E); padding-bottom:20px; }
    .pv_board_name { font-size:13px; font-weight:700; color: var(--main-color, #304F4E); margin-bottom:8px; }
    .pv_title { font-size:26px; font-weight:700; color:#1a1a2e; margin-bottom:14px; line-height:1.4; }
    .pv_meta { font-size:13px; color:#9999bb; display:flex; gap:14px; flex-wrap:wrap; }
    .pv_body { padding:32px 0; font-size:15px; line-height:1.8; word-break:break-word; color:#333; }
    .pv_body img { max-width:100%; height:auto; }

    .qa_lock { text-align:center; padding:60px 20px; }
    .qa_lock_txt { font-size:15px; color:#555; margin-bottom:20px; }
    .qa_lock_form { display:flex; gap:8px; justify-content:center; max-width:360px; margin:0 auto; }
    .qa_lock_form input { flex:1; padding:10px 14px; border:1px solid #ddd; border-radius:6px; font-size:14px; }
    .qa_lock_err { color:#e04b4b; font-size:13px; margin-top:14px; }

    .cm_grid { display:flex; gap:24px; padding:20px 0; border-bottom:1px solid #f0f0f0; flex-wrap:wrap; }
    .cm_row label { display:block; font-size:12px; color:#999; margin-bottom:4px; }
    .cm_row .val { font-size:14px; color:#333; font-weight:600; }

    .qa_sub_title { font-size:15px; font-weight:700; color:#1a1a2e; margin-bottom:12px; }
    .qa_content { font-size:15px; line-height:1.8; color:#333; white-space:pre-line; }
    .qa_reply_block { border-top:1px dashed #e5e5e5; }
    .qa_reply_date { font-size:12px; color:#999; margin-top:10px; }
    .qa_no_reply { font-size:14px; color:#999; }
</style>
<?php include_once(G5_PATH . '/tail.php'); ?>
<?php include_once(G5_PATH . '/tail_sub.php'); ?>
