<?php
/* ============================================================
 *  /sub/board/consult_board_view.php — 상담 문의 상세 (프론트, 비밀글)
 *  - 전화번호 입력 → dm_consult.phone 일치 확인 후 열람 (숫자만 비교, 하이픈 무관)
 *  - qa_manager.php에서 남긴 reply_content(고객 노출용 답변)도 함께 표시
 *  - head/tail은 그누보드 공통 레이아웃(head_sub/head, tail/tail_sub) 그대로 사용
 * ============================================================ */
chdir(__DIR__ . '/../..'); // 웹루트로 이동 (_common.php 내부의 './common.php' 상대경로 때문)
include_once('./_common.php');
if (session_status() === PHP_SESSION_NONE) session_start();

$id = (int)(isset($_GET['id']) ? $_GET['id'] : 0);
if (!$id) { alert_toast('잘못된 접근입니다.', './consult_board_list.php'); }

$STATUS = array('new'=>'신규','contacted'=>'연락완료','booked'=>'예약전환','hold'=>'보류','closed'=>'종결');

/* ── AJAX: 전화번호 확인 ───────────────────────── */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'check_phone') {
    header('Content-Type: application/json; charset=utf-8');
    $input_digits = preg_replace('/[^0-9]/', '', isset($_POST['phone']) ? $_POST['phone'] : '');
    $row = sql_fetch("SELECT phone FROM dm_consult WHERE id='$id'");
    $stored_digits = $row ? preg_replace('/[^0-9]/', '', $row['phone']) : '';
    if ($row && $input_digits !== '' && $input_digits === $stored_digits) {
        $_SESSION['dm_consult_unlock_' . $id] = true;
        echo json_encode(array('ok' => true), JSON_UNESCAPED_UNICODE);
    } else {
        echo json_encode(array('ok' => false, 'msg' => '연락처가 일치하지 않습니다.'), JSON_UNESCAPED_UNICODE);
    }
    exit;
}

$post = sql_fetch("SELECT * FROM dm_consult WHERE id='$id'");
if (!$post) { alert_toast('존재하지 않는 글입니다.', './consult_board_list.php'); }

$unlocked = !empty($_SESSION['dm_consult_unlock_' . $id]);

$g5['title'] = '상담 문의 상세';
include_once(G5_PATH . '/head_sub.php');
include_once(G5_PATH . '/head.php');
?>

<main class="u-pretendard u-fluid u-py-80 u-py-40-sm" style="max-width:640px;margin-left:auto;margin-right:auto;">

    <?php if (!$unlocked): ?>
    <!-- 전화번호 확인 화면 -->
    <div class="u-bd-1 u-b-solid u-bc-gray-200 u-round-16 u-p-40 text-center">
        <div class="t-fs-22 fw-700 u-txt-dark u-mb-16">🔒 비밀글입니다</div>
        <p class="c-fs-15 u-txt-gray-600 u-mb-24">신청 시 입력한 연락처를 입력해주세요.</p>
        <div class="d-flex justify-content-center u-gap-8">
            <input type="tel" id="phone_input" class="u-bd-1 u-b-solid u-bc-gray-300 u-round-8 u-px-16 u-py-8 c-fs-14" style="max-width:220px;" placeholder="010-0000-0000">
            <button type="button" class="u-btn u-btn-main u-round-8 u-px-24 u-py-8" onclick="checkPhone()">확인</button>
        </div>
        <div id="phone_error" class="c-fs-13 u-mt-10" style="color:#e5484d;"></div>
        <div class="u-mt-24"><a href="./consult_board_list.php" class="c-fs-14 u-txt-gray-500">목록으로</a></div>
    </div>
    <script>
    function checkPhone(){
        const phone = document.getElementById('phone_input').value;
        if (!phone) return;
        const fd = new FormData();
        fd.append('action', 'check_phone');
        fd.append('phone', phone);
        fetch('./consult_board_view.php?id=<?= $id ?>', { method:'POST', body: fd })
            .then(r => r.json())
            .then(j => {
                if (j.ok) location.reload();
                else document.getElementById('phone_error').textContent = j.msg;
            })
            .catch(() => document.getElementById('phone_error').textContent = '통신 오류');
    }
    document.getElementById('phone_input').addEventListener('keydown', function(e){
        if (e.key === 'Enter') checkPhone();
    });
    </script>

    <?php else: ?>
    <!-- 열람 화면 -->
    <div class="u-bd-1 u-b-solid u-bc-gray-200 u-round-16 u-p-24">
        <div class="d-flex justify-content-between align-items-center u-mb-16">
            <h2 class="t-fs-22 fw-700 u-txt-dark"><?= htmlspecialchars($post['interest'] ?: '문의') ?></h2>
            <span class="c-fs-13 u-txt-gray-500"><?= $STATUS[$post['status']] ?></span>
        </div>
        <div class="c-fs-14 u-txt-gray-500 u-mb-16">
            <?= htmlspecialchars($post['name']) ?> · <?= substr($post['created_at'], 0, 16) ?>
        </div>
        <div class="c-fs-15 u-txt-dark u-mb-24" style="white-space:pre-wrap;line-height:1.7;"><?= htmlspecialchars($post['content']) ?></div>

        <?php if (!empty($post['reply_content'])): ?>
        <div class="u-round-12 u-p-16" style="background:var(--gray-100,#f7f8fa);">
            <div class="c-fs-13 fw-700 u-txt-dark u-mb-8">💬 답변 (<?= substr($post['reply_at'], 0, 16) ?>)</div>
            <div class="c-fs-14" style="white-space:pre-wrap;line-height:1.7;"><?= htmlspecialchars($post['reply_content']) ?></div>
        </div>
        <?php endif; ?>
    </div>
    <div class="u-mt-24"><a href="./consult_board_list.php" class="c-fs-14 u-txt-gray-500">목록으로</a></div>
    <?php endif; ?>

</main>

<?php
include_once(G5_PATH . '/tail.php');
include_once(G5_PATH . '/tail_sub.php');