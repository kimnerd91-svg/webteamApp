<?php
/*
 * ============================================
 * /sub/board/qa_list.php — 온라인 상담(문의) 목록 (프론트)
 * dm_consult(newadm/board/qa_manager.php와 동일 테이블)를 게시판 형태
 * (번호/유형/제목/작성자/등록일/진행상태)로 출력.
 * - 제목(subject) 컬럼이 없는 스키마이므로, 없을 경우 "관심진료 + 문의"로 대체 표기.
 * - 문의 내용/답변은 qa_view.php에서 전화번호 확인 후에만 볼 수 있음.
 * - 하단 "상담하기" 버튼은 같은 폴더의 consult_modal.php(#inquiryModal, 부트스트랩 모달)를
 *   그대로 include해서 사용. 버튼은 data-bs-toggle/data-bs-target으로 부트스트랩 모달을 직접 연다.
 * ============================================
 */

// _common.php 내부가 문서 루트 기준 상대경로를 쓰기 때문에, sub/board 하위 폴더에서
// 바로 include하면 내부 include가 깨진다. 문서 루트로 cwd를 옮겨준다. (notice.php와 동일 이슈)
chdir(dirname(__FILE__, 3));
include_once('./_common.php');

/* ── dm_consult 보장 (없으면 생성, newadm/board/qa_manager.php와 동일 스키마) ───────────────────────── */
sql_query("CREATE TABLE IF NOT EXISTS `dm_consult` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(60) NOT NULL DEFAULT '',
  `phone` VARCHAR(40) NOT NULL DEFAULT '',
  `interest` VARCHAR(80) NOT NULL DEFAULT '',
  `call_time` VARCHAR(80) NOT NULL DEFAULT '',
  `inflow` VARCHAR(80) NOT NULL DEFAULT '',
  `content` TEXT NULL,
  `agree_privacy` TINYINT(1) NOT NULL DEFAULT 0,
  `agree_at` DATETIME NULL,
  `agree_marketing` TINYINT(1) NOT NULL DEFAULT 0,
  `status` VARCHAR(20) NOT NULL DEFAULT 'new',
  `memo` TEXT NULL,
  `handler` VARCHAR(60) NULL,
  `handled_at` DATETIME NULL,
  `is_read` TINYINT(1) NOT NULL DEFAULT 0,
  `reg_ip` VARCHAR(50) NULL,
  `created_at` DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", false);

$col_chk = sql_fetch("SHOW COLUMNS FROM dm_consult LIKE 'reply_content'");
if (!$col_chk) {
    sql_query("ALTER TABLE dm_consult ADD COLUMN `reply_content` TEXT NULL AFTER `memo`", false);
    sql_query("ALTER TABLE dm_consult ADD COLUMN `reply_at` DATETIME NULL AFTER `reply_content`", false);
}

// ── 페이지네이션 ──
$per_page = 15;
$page     = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$offset   = ($page - 1) * $per_page;

$total_row   = sql_fetch("SELECT COUNT(*) AS cnt FROM dm_consult");
$total_count = (int)($total_row['cnt'] ?? 0);
$total_pages = max(1, (int)ceil($total_count / $per_page));

$result = sql_query("SELECT * FROM dm_consult ORDER BY id DESC LIMIT {$offset}, {$per_page}");
$rows = [];
if ($result) {
    while ($row = sql_fetch_array($result)) $rows[] = $row;
}

/* consult_modal.php가 같은 폴더에 있으면 그대로 include (부트스트랩 모달 #inquiryModal 자체 포함) */
$consult_modal_path = __DIR__ . '/consult_modal.php';
$has_consult_modal   = file_exists($consult_modal_path);

// ============================================
// HEAD
// ============================================
include_once(G5_PATH . '/head_sub.php');
include_once(G5_PATH . '/head.php');
$g5['title'] = '온라인 상담';
?>

<!-- ============================================ -->
<!-- 온라인 상담 목록 -->
<!-- ============================================ -->
<main class="u-pretendard notice_page u-py-80 u-py-40-md">
    <div class="container">

        <div class="text-center u-mb-40 u-mb-24-md">
            <h1 class="t-fs-40 t-fs-28-md fw-700 u-txt-dark">온라인 상담</h1>
        </div>

        <div class="notice_table_wrap">
            <table class="notice_table">
                <thead>
                    <tr>
                        <th class="col_no">번호</th>
                        <th class="col_type">유형</th>
                        <th class="col_subject">제목</th>
                        <th class="col_writer">작성자</th>
                        <th class="col_date">등록일</th>
                        <th class="col_status">진행상태</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($rows)): ?>
                    <tr><td colspan="6" class="empty_row">등록된 상담 내역이 없습니다.</td></tr>
                    <?php else: ?>
                        <?php foreach ($rows as $i => $r):
                            $no       = $total_count - $offset - $i;
                            $answered = trim((string)($r['reply_content'] ?? '')) !== '';
                            $type     = trim((string)($r['interest'] ?? '')) !== '' ? $r['interest'] : '문의';
                            $subject  = trim((string)($r['subject'] ?? '')) !== ''
                                        ? $r['subject']
                                        : (trim((string)($r['interest'] ?? '')) !== '' ? $r['interest'] . ' 문의' : '문의');
                            $view_url = './qa_view.php?id=' . (int)$r['id'];
                        ?>
                        <tr class="qa_row" onclick="location.href='<?= $view_url ?>'">
                            <td class="col_no"><?= $no ?></td>
                            <td class="col_type"><?= htmlspecialchars($type) ?></td>
                            <td class="col_subject">
                                <a href="<?= $view_url ?>"><?= htmlspecialchars($subject) ?></a>
                            </td>
                            <td class="col_writer"><?= htmlspecialchars($r['name']) ?></td>
                            <td class="col_date"><?= substr($r['created_at'], 0, 10) ?></td>
                            <td class="col_status">
                                <span class="qa_badge <?= $answered ? 'is_done' : 'is_wait' ?>"><?= $answered ? '답변완료' : '답변전' ?></span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="qa_bottom_bar">
            <?php if ($total_pages > 1): ?>
            <div class="d-flex u-gap-6">
                <?php for ($p = 1; $p <= $total_pages; $p++): ?>
                <a href="./qa_list.php?page=<?= $p ?>" class="u-btn u-btn-sm <?= $p === $page ? 'u-btn-main' : 'u-btn-outline' ?>"><?= $p ?></a>
                <?php endfor; ?>
            </div>
            <?php else: ?>
            <span></span>
            <?php endif; ?>

            <?php if ($has_consult_modal): ?>
            <button type="button" class="u-btn u-btn-main" data-bs-toggle="modal" data-bs-target="#inquiryModal">상담하기</button>
            <?php else: ?>
            <button type="button" class="u-btn u-btn-main" disabled title="consult_modal.php가 이 폴더에 없습니다">상담하기</button>
            <?php endif; ?>
        </div>

    </div>
</main>

<?php if ($has_consult_modal): ?>
<!-- ============================================ -->
<!-- 상담하기 모달 (consult_modal.php의 #inquiryModal 그대로 사용) -->
<!-- ============================================ -->
<?php include $consult_modal_path; ?>
<?php endif; ?>

<style>
    .notice_page {
        min-height: 80vh;
    }
    .notice_table_wrap { overflow-x:auto; }
    .notice_table { width:100%; border-collapse:collapse; min-width:620px; }
    .notice_table thead th {
        border-top:2px solid var(--main-color, #304F4E);
        border-bottom:1px solid #e5e5e5;
        padding:14px 12px; font-size:14px; font-weight:700; color:#333; background:#fafafa;
        text-align:center;
    }
    .notice_table tbody td {
        padding:14px 12px; font-size:14px; color:#444; border-bottom:1px solid #f0f0f0; text-align:center;
    }
    .notice_table .col_subject a { color:#1a1a2e; text-decoration:none; }
    .notice_table .col_subject a:hover { color: var(--main-color, #304F4E); text-decoration:underline; }
    .notice_table .empty_row { text-align:center; padding:60px 0; color:#999; }
    .qa_row { cursor:pointer; }
    .qa_row:hover td { background:#fafcfb; }
    .qa_badge { display:inline-block; padding:4px 10px; border-radius:20px; font-size:12px; font-weight:700; }
    .qa_badge.is_wait { background:#fff3e0; color:#e07b00; }
    .qa_badge.is_done { background:#e8f3f0; color: var(--main-color, #304F4E); }

    .qa_bottom_bar { display:flex; align-items:center; justify-content:space-between; margin-top:24px; }
</style>

<?php include_once(G5_PATH . '/tail.php'); ?>
<?php include_once(G5_PATH . '/tail_sub.php'); ?>
