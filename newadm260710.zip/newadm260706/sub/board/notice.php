<?php
/*
 * ============================================
 * /sub/board/notice.php — 공지사항 목록 (프론트)
 * dm_posts에서 bo_table='notice' 인 글만 게시판 형태(번호/제목/작성자/작성일/조회)로 출력.
 * 글 클릭 시 post_view.php(프론트)로 이동.
 * ============================================
 */

// _common.php 내부가 문서 루트 기준 상대경로를 쓰기 때문에, sub/board 하위 폴더에서
// 바로 include하면 내부 include가 깨진다. 문서 루트로 cwd를 옮겨준다. (media.php와 동일 이슈)
chdir(dirname(__FILE__, 3));
include_once('./_common.php');

const BO_TABLE = 'notice';

// ── 테이블 없을 경우 대비 ──
sql_query("CREATE TABLE IF NOT EXISTS `dm_posts` (
    `id`           INT(11) NOT NULL AUTO_INCREMENT,
    `bo_table`     VARCHAR(50) NOT NULL,
    `category_id`  INT(11) DEFAULT 0,
    `subject`      VARCHAR(255) NOT NULL DEFAULT '',
    `content`      TEXT,
    `thumbnail`    VARCHAR(500) DEFAULT '',
    `writer_name`  VARCHAR(100) DEFAULT '',
    `hit`          INT(11) DEFAULT 0,
    `is_visible`   TINYINT(1) DEFAULT 1,
    `created_at`   DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at`   DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_bo_table` (`bo_table`),
    KEY `idx_bo_cat` (`bo_table`, `category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ── 페이지네이션 ──
$per_page = 15;
$page     = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$offset   = ($page - 1) * $per_page;

$total_row   = sql_fetch("SELECT COUNT(*) AS cnt FROM dm_posts WHERE bo_table = '" . BO_TABLE . "' AND is_visible = 1");
$total_count = (int)($total_row['cnt'] ?? 0);
$total_pages = max(1, (int)ceil($total_count / $per_page));

$result = sql_query("SELECT * FROM dm_posts WHERE bo_table = '" . BO_TABLE . "' AND is_visible = 1 ORDER BY id DESC LIMIT {$offset}, {$per_page}");
$posts = [];
if ($result) {
    while ($row = sql_fetch_array($result)) $posts[] = $row;
}

// ============================================
// HEAD
// ============================================
include_once(G5_PATH . '/head_sub.php');
include_once(G5_PATH . '/head.php');
$g5['title'] = '공지사항';
?>

<!-- ============================================ -->
<!-- 공지사항 목록 -->
<!-- ============================================ -->
<main class="u-pretendard notice_page u-py-80 u-py-40-md">
    <div class="container">

        <div class="text-center u-mb-40 u-mb-24-md">
            <h1 class="t-fs-40 t-fs-28-md fw-700 u-txt-dark">공지사항</h1>
        </div>

        <div class="notice_table_wrap">
            <table class="notice_table">
                <thead>
                    <tr>
                        <th class="col_no">번호</th>
                        <th class="col_subject">제목</th>
                        <th class="col_writer">작성자</th>
                        <th class="col_date">작성일</th>
                        <th class="col_hit">조회</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($posts)): ?>
                    <tr><td colspan="5" class="empty_row">등록된 공지사항이 없습니다.</td></tr>
                    <?php else: ?>
                        <?php foreach ($posts as $i => $p):
                            $no = $total_count - $offset - $i;
                        ?>
                        <tr>
                            <td class="col_no"><?= $no ?></td>
                            <td class="col_subject">
                                <a href="./post_view.php?bo_table=<?= BO_TABLE ?>&id=<?= $p['id'] ?>"><?= htmlspecialchars($p['subject']) ?></a>
                            </td>
                            <td class="col_writer"><?= htmlspecialchars($p['writer_name'] ?: '관리자') ?></td>
                            <td class="col_date"><?= substr($p['created_at'], 0, 10) ?></td>
                            <td class="col_hit"><?= number_format($p['hit']) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if ($total_pages > 1): ?>
        <div class="d-flex justify-content-center u-gap-6 u-mt-32">
            <?php for ($p = 1; $p <= $total_pages; $p++): ?>
            <a href="./notice.php?page=<?= $p ?>" class="u-btn u-btn-sm <?= $p === $page ? 'u-btn-main' : 'u-btn-outline' ?>"><?= $p ?></a>
            <?php endfor; ?>
        </div>
        <?php endif; ?>

    </div>
</main>

<style>
    .notice_page {
        min-height: 80vh;
    }
    .notice_table_wrap { overflow-x:auto; }
    .notice_table { width:100%; border-collapse:collapse; min-width:520px; }
    .notice_table thead th {
        border-top:2px solid var(--main-color, #304F4E);
        border-bottom:1px solid #e5e5e5;
        padding:14px 12px; font-size:14px; font-weight:700; color:#333; background:#fafafa;
    }
    .notice_table tbody td {
        padding:14px 12px; font-size:14px; color:#444; border-bottom:1px solid #f0f0f0; text-align:center;
    }
    .notice_table .col_subject { text-align:left; }
    .notice_table .col_subject a { color:#1a1a2e; text-decoration:none; }
    .notice_table .col_subject a:hover { color: var(--main-color, #304F4E); text-decoration:underline; }
    .notice_table .empty_row { text-align:center; padding:60px 0; color:#999; }
</style>
<?php include_once(G5_PATH . '/tail.php'); ?>
<?php include_once(G5_PATH . '/tail_sub.php'); ?>
