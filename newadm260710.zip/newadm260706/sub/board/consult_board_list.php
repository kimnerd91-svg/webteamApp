<?php
/* ============================================================
 *  /sub/board/consult_board_list.php — 상담 문의 게시판 목록 (프론트)
 *  - DB: dm_consult (consult_submit.php 저장 / qa_manager.php 관리, 동일 테이블)
 *  - 상단 탭 = 관심진료(interest) 카테고리 필터
 *  - 배지: 미답변(status=new)은 "신규" 강조, 그 외는 카테고리 표시
 *  - 비밀글: 목록엔 마스킹된 이름만, 클릭 시 consult_board_view.php(연락처 확인)로 이동
 *  - head/tail은 그누보드 공통 레이아웃(head_sub/head, tail/tail_sub) 그대로 사용
 * ============================================================ */
chdir(__DIR__ . '/../..'); // 웹루트로 이동 (_common.php 내부의 './common.php' 상대경로 때문)
include_once('./_common.php');

/* 카테고리 = consult_modal.php의 interest select 옵션과 동일하게 유지 */
$CATS = array('임플란트','교정','충치·신경','보철','심미','검진·예방','기타');

$cat    = isset($_GET['cat']) ? $_GET['cat'] : '';
$search = trim(isset($_GET['search']) ? $_GET['search'] : '');

$where = " WHERE 1=1 ";
if ($cat !== '' && in_array($cat, $CATS, true)) $where .= " AND interest = '".sql_real_escape_string($cat)."' ";
if ($search !== '') {
    $s = sql_real_escape_string($search);
    $where .= " AND (name LIKE '%$s%' OR content LIKE '%$s%') ";
}

$page     = max(1, (int)(isset($_GET['page']) ? $_GET['page'] : 1));
$per_page = 15;
$offset   = ($page - 1) * $per_page;

$total = (int)sql_fetch("SELECT COUNT(*) AS cnt FROM dm_consult $where")['cnt'];
$total_page = max(1, ceil($total / $per_page));

$list = sql_query("SELECT id, name, interest, status, created_at
                    FROM dm_consult
                    $where
                    ORDER BY id DESC
                    LIMIT $offset, $per_page");

function board_qs($override = array()) {
    $base = array(
        'cat'    => isset($_GET['cat'])    ? $_GET['cat']    : '',
        'search' => isset($_GET['search']) ? $_GET['search'] : '',
    );
    $q = array_merge($base, $override);
    $q = array_filter($q, function($v){ return $v !== ''; });
    return $q ? '?'.http_build_query($q) : '?';
}

function mask_name($name) {
    $len = mb_strlen($name, 'UTF-8');
    if ($len <= 1) return $name;
    if ($len == 2) return mb_substr($name, 0, 1, 'UTF-8') . '*';
    $first = mb_substr($name, 0, 1, 'UTF-8');
    $last  = mb_substr($name, -1, 1, 'UTF-8');
    return $first . str_repeat('*', $len - 2) . $last;
}

function is_recent($created_at) {
    return (strtotime($created_at) >= strtotime('-3 days'));
}

function page_numbers($current, $total) {
    if ($total <= 7) return range(1, $total);
    $nums = array(1);
    $start = max(2, $current - 2);
    $end   = min($total - 1, $current + 2);
    if ($start > 2) $nums[] = '...';
    for ($p = $start; $p <= $end; $p++) $nums[] = $p;
    if ($end < $total - 1) $nums[] = '...';
    $nums[] = $total;
    return $nums;
}

$g5['title'] = '온라인 상담 게시판';
include_once(G5_PATH . '/head_sub.php');
include_once(G5_PATH . '/head.php');
?>

<main class="u-pretendard u-fluid u-py-80 u-py-40-sm" style="max-width:900px;margin-left:auto;margin-right:auto;">

    <h2 class="t-fs-32 t-fs-24-sm fw-800 u-txt-dark text-center u-mb-40">온라인 상담 게시판</h2>

    <!-- 카테고리 탭 -->
    <div class="d-flex flex-wrap align-items-center u-gap-24 u-mb-24 u-pb-16 u-bd-1 u-b-solid u-bc-gray-200" style="border-top:none;border-left:none;border-right:none;">
        <a href="./consult_board_list.php<?= board_qs(array('cat'=>'')) ?>"
           class="c-fs-15 <?= $cat===''?'fw-800 u-txt-dark':'u-txt-gray-500' ?>">전체</a>
        <?php foreach ($CATS as $c): ?>
        <a href="./consult_board_list.php<?= board_qs(array('cat'=>$c)) ?>"
           class="c-fs-15 <?= $cat===$c?'fw-800 u-txt-dark':'u-txt-gray-500' ?>"><?= htmlspecialchars($c) ?></a>
        <?php endforeach; ?>
        <form method="get" class="d-flex u-gap-8" style="margin-left:auto;">
            <?php if ($cat): ?><input type="hidden" name="cat" value="<?= htmlspecialchars($cat) ?>"><?php endif; ?>
            <input type="text" name="search" placeholder="검색"
                   value="<?= htmlspecialchars($search) ?>"
                   class="u-bd-1 u-b-solid u-bc-gray-300 u-round-8 u-px-12 u-py-6 c-fs-13" style="width:160px;">
        </form>
    </div>

    <!-- 목록 -->
    <table class="w-100 cb-table">
        <tbody>
            <?php if ($total === 0): ?>
            <tr><td class="text-center u-py-80 c-fs-15 u-txt-gray-500">등록된 문의가 없습니다.</td></tr>
            <?php else: while ($row = sql_fetch_array($list)):
                $is_new = ($row['status'] === 'new');
            ?>
            <tr class="cb-tr">
                <td class="u-py-16" style="width:100px;">
                    <span class="cb-pill <?= $is_new ? 'cb-pill-main' : 'cb-pill-outline' ?>">
                        <?= $is_new ? '신규' : htmlspecialchars($row['interest'] ?: '문의') ?>
                    </span>
                </td>
                <td class="u-py-16">
                    <a href="./consult_board_view.php?id=<?= (int)$row['id'] ?>" class="d-flex align-items-center u-gap-4">
                        <span class="c-fs-15 <?= $is_new ? 'fw-700 u-txt-dark' : 'fw-500 u-txt-gray-800' ?>">
                            🔒 <?= htmlspecialchars(mask_name($row['name'])) ?> 님의 상담 신청
                        </span>
                        <?php if (is_recent($row['created_at'])): ?><sup class="cb-new">N</sup><?php endif; ?>
                    </a>
                </td>
                <td class="text-end u-py-16 c-fs-13 u-txt-gray-500" style="width:110px;"><?= substr($row['created_at'], 0, 10) ?></td>
            </tr>
            <?php endwhile; endif; ?>
        </tbody>
    </table>

    <!-- 페이지네이션 -->
    <?php if ($total_page > 1): ?>
    <div class="d-flex justify-content-center align-items-center u-gap-4 u-mt-40">
        <?php if ($page > 1): ?>
        <a href="?<?= http_build_query(array_filter(array('cat'=>$cat,'search'=>$search,'page'=>$page-1))) ?>" class="cb-page">&lt;</a>
        <?php endif; ?>
        <?php foreach (page_numbers($page, $total_page) as $p): ?>
            <?php if ($p === '...'): ?>
            <span class="cb-page" style="color:var(--gray-400,#bbb);">···</span>
            <?php else: ?>
            <a href="?<?= http_build_query(array_filter(array('cat'=>$cat,'search'=>$search,'page'=>$p))) ?>"
               class="cb-page <?= $p===$page?'on':'' ?>"><?= $p ?></a>
            <?php endif; ?>
        <?php endforeach; ?>
        <?php if ($page < $total_page): ?>
        <a href="?<?= http_build_query(array_filter(array('cat'=>$cat,'search'=>$search,'page'=>$page+1))) ?>" class="cb-page">&gt;</a>
        <?php endif; ?>
    </div>
    <?php endif; ?>

</main>

<style>
/* consult_board_list.php 전용 (setting.css/Bootstrap에 없는 부분만) */
.cb-tr td { border-bottom: 1px solid var(--gray-200, #eee); }
.cb-tr:hover td { background: var(--gray-100, #f8f8f8); }
.cb-tr a { color: inherit; text-decoration: none; }
.cb-tr a:hover { color: var(--main-color, #304F4E); }

.cb-pill {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 64px;
    padding: 4px 10px;
    border-radius: 999px;
    font-size: 12px;
    font-weight: 700;
    white-space: nowrap;
}
.cb-pill-main { background: var(--main-color, #304F4E); color: var(--white, #fff); }
.cb-pill-outline { background: transparent; border: 1px solid var(--gray-300, #ccc); color: var(--gray-600, #666); font-weight: 500; }

.cb-new { color: var(--point, #D7AC7A); font-size: 11px; font-weight: 800; margin-left: 3px; }

.cb-page {
    display: inline-flex; align-items: center; justify-content: center;
    width: 30px; height: 30px; border-radius: 50%; font-size: 14px; color: var(--gray-500, #888);
}
.cb-page.on { background: var(--main-color, #304F4E); color: var(--white, #fff); font-weight: 700; }
</style>

<?php
include_once(G5_PATH . '/tail.php');
include_once(G5_PATH . '/tail_sub.php');