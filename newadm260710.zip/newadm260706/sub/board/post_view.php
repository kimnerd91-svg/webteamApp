<?php
/*
 * ============================================
 * /sub/board/post_view.php — 게시글 보기 (프론트, 그누보드 view_direct.php 대체)
 * dm_posts 공용 테이블 아무 bo_table이나 지원. 조회할 때마다 hit(조회수) +1.
 * 제목 / 내용(CKEditor로 작성된 HTML 그대로 출력) / 작성자 / 작성시간 / 조회수 표시.
 * ============================================
 */

chdir(dirname(__FILE__, 3));
include_once('./_common.php');

$bo_table = preg_replace('/[^a-z0-9_]/i', '', $_GET['bo_table'] ?? '');
$id       = (int)($_GET['id'] ?? 0);

$board = $bo_table ? sql_fetch("SELECT * FROM dm_boards WHERE bo_table = '{$bo_table}'") : null;
$post  = ($board && $id) ? sql_fetch("SELECT * FROM dm_posts WHERE id = '{$id}' AND bo_table = '{$bo_table}' AND is_visible = 1") : null;

if ($post) {
    sql_query("UPDATE dm_posts SET hit = hit + 1 WHERE id = '{$id}'");
}

include_once(G5_PATH . '/head_sub.php');
include_once(G5_PATH . '/head.php');
$g5['title'] = $post['subject'] ?? '게시글';
?>

<main class="u-pretendard post_view_page u-py-80 u-py-40-md">
    <div class="container" style="max-width:840px;">

        <?php if (!$post): ?>
        <div class="text-center u-py-80 c-fs-16 u-txt-gray-500">게시글을 찾을 수 없습니다.</div>
        <a href="./<?= htmlspecialchars($bo_table ?: 'notice') ?>.php" class="u-btn u-btn-outline u-btn-sm">← 목록으로</a>
        <?php else: ?>

        <div class="pv_header u-mb-24">
            <p class="pv_board_name"><?= htmlspecialchars($board['bo_subject']) ?></p>
            <h1 class="pv_title"><?= htmlspecialchars($post['subject']) ?></h1>
            <div class="pv_meta">
                <span><?= htmlspecialchars($post['writer_name'] ?: '관리자') ?></span>
                <span><?= substr($post['created_at'], 0, 16) ?></span>
                <span>조회 <?= number_format($post['hit'] + 1) ?></span>
            </div>
        </div>

        <div class="pv_body"><?= $post['content'] ?></div>

        <div class="u-mt-40">
            <a href="./<?= htmlspecialchars($bo_table) ?>.php" class="u-btn u-btn-outline">← 목록으로</a>
        </div>

        <?php endif; ?>
    </div>
</main>

<style>
    .post_view_page {
        min-height: 80vh;
    }
    .pv_header { border-bottom:2px solid var(--main-color, #304F4E); padding-bottom:20px; }
    .pv_board_name { font-size:13px; font-weight:700; color: var(--main-color, #304F4E); margin-bottom:8px; }
    .pv_title { font-size:26px; font-weight:700; color:#1a1a2e; margin-bottom:14px; line-height:1.4; }
    .pv_meta { font-size:13px; color:#9999bb; display:flex; gap:14px; flex-wrap:wrap; }
    .pv_body { padding:32px 0; font-size:15px; line-height:1.8; word-break:break-word; color:#333; }
    .pv_body img { max-width:100%; height:auto; }
</style>
<?php include_once(G5_PATH . '/tail.php'); ?>
<?php include_once(G5_PATH . '/tail_sub.php'); ?>
