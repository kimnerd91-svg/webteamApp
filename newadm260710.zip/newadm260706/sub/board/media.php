<?php
/*
 * ============================================
 * 보도자료 목록 페이지 media.php
 * - /newadm/media/media_manager.php(dm_media) 데이터 프론트 출력
 * - index.php와 동일한 부트스트랩(공통 include / head_sub / tail_sub) 사용
 * ============================================
 */

// ── [임시 디버그] 원인 파악되면 이 블록은 삭제할 것 ──
error_reporting(E_ALL);
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');

// _common.php 내부가 './common.php' 처럼 문서 루트 기준 상대경로를 쓰기 때문에
// 서브폴더(sub/board)에서 바로 include하면 내부 include가 깨진다. 문서 루트로 cwd를 옮겨준다.
chdir(dirname(__FILE__, 3));
include_once('./_common.php');

// ── 테이블 없을 경우 대비 (관리자 media_manager.php와 동일 스키마) ──
sql_query("CREATE TABLE IF NOT EXISTS `dm_media` (
    `id`            INT(11) NOT NULL AUTO_INCREMENT,
    `title`         VARCHAR(500) NOT NULL DEFAULT '',
    `category`      VARCHAR(100) DEFAULT '',
    `image`         VARCHAR(500) DEFAULT '',
    `thumbnail`     VARCHAR(500) DEFAULT '',
    `link_url`      VARCHAR(1000) DEFAULT '',
    `display_order` INT(11) DEFAULT 0,
    `is_visible`    TINYINT(1) DEFAULT 1,
    `created_at`    DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ============================================
// 카테고리 목록 (노출중인 데이터 기준)
// ============================================
$cat_result = sql_query("SELECT DISTINCT category FROM dm_media WHERE is_visible = 1 AND category <> '' ORDER BY category ASC");
$categories = [];
if ($cat_result) {
    while ($c = sql_fetch_array($cat_result)) $categories[] = $c['category'];
}

$cur_cat = isset($_GET['cat']) ? trim($_GET['cat']) : '';

// ============================================
// 페이지네이션
// ============================================
$per_page = 12;
$page     = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$offset   = ($page - 1) * $per_page;

$where = "WHERE is_visible = 1";
if ($cur_cat !== '') {
    $where .= " AND category = '" . sql_real_escape_string($cur_cat) . "'";
}

$total_row   = sql_fetch("SELECT COUNT(*) AS cnt FROM dm_media {$where}");
$total_count = (int)($total_row['cnt'] ?? 0);
$total_pages = max(1, (int)ceil($total_count / $per_page));

$result = sql_query("SELECT * FROM dm_media {$where} ORDER BY display_order ASC, id DESC LIMIT {$offset}, {$per_page}");
$medias = [];
if ($result) {
    while ($row = sql_fetch_array($result)) $medias[] = $row;
}

// ============================================
// HEAD (head_sub이 cf_* 직접변수 + 전역 스키마 공급)
// ============================================
include_once(G5_PATH . '/head_sub.php');
include_once(G5_PATH . '/head.php');

$g5['title'] = '보도자료';
?>

<!-- ============================================ -->
<!-- 보도자료 목록 -->
<!-- ============================================ -->
<main class="u-pretendard media_page u-py-80 u-py-40-md">
    <div class="container">

        <div class="text-center u-mb-40 u-mb-24-md">
            <h1 class="t-fs-40 t-fs-28-md fw-700 u-txt-dark">보도자료</h1>
        </div>

        <?php if (!empty($categories)): ?>
        <div class="d-flex justify-content-center flex-wrap u-gap-8 u-mb-32 u-mb-20-md">
            <a href="./media.php" class="u-btn u-btn-sm <?= $cur_cat === '' ? 'u-btn-main' : 'u-btn-outline' ?>">전체</a>
            <?php foreach ($categories as $c): ?>
            <a href="./media.php?cat=<?= urlencode($c) ?>" class="u-btn u-btn-sm <?= $cur_cat === $c ? 'u-btn-main' : 'u-btn-outline' ?>"><?= htmlspecialchars($c) ?></a>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <?php if (empty($medias)): ?>
        <div class="text-center u-py-80 c-fs-16 u-txt-gray-500">등록된 보도자료가 없습니다.</div>
        <?php else: ?>
        <div class="row u-gap-24-md">
            <?php foreach ($medias as $m):
                $thumb_src = $m['thumbnail'] ?: $m['image'];
                $link = $m['link_url'] ?: '#';
            ?>
            <div class="col-6 col-md-4 col-lg-3 u-mb-32">
                <a class="d-block u-round-12 u-bd-1 u-b-solid u-bc-gray-200 shadow-soft no-drag media_card" href="<?= htmlspecialchars($link) ?>" <?= $m['link_url'] ? 'target="_blank" rel="noopener"' : '' ?>>
                    <div class="u-ratio-4-3 w-100 u-round-12" style="overflow:hidden;">
                        <?php if ($thumb_src): ?>
                        <img class="w-100 h-100" style="object-fit: none;" src="<?= htmlspecialchars($thumb_src) ?>" alt="<?= htmlspecialchars($m['title']) ?>">
                        <?php else: ?>
                        <div class="w-100 h-100 d-flex align-items-center justify-content-center u-txt-gray-400 c-fs-13">이미지 없음</div>
                        <?php endif; ?>
                    </div>
                    <div class="u-p-16">
                        <?php if ($m['category']): ?>
                        <span class="c-fs-11 fw-700 u-txt-main u-mb-6 d-block"><?= htmlspecialchars($m['category']) ?></span>
                        <?php endif; ?>
                        <div class="c-fs-15 fw-700 u-txt-dark dot-dot"><?= htmlspecialchars($m['title']) ?></div>
                    </div>
                </a>
            </div>
            <?php endforeach; ?>
        </div>

        <?php if ($total_pages > 1): ?>
        <div class="d-flex justify-content-center u-gap-6 u-mt-24">
            <?php for ($p = 1; $p <= $total_pages; $p++):
                $qs = $cur_cat !== '' ? '&cat=' . urlencode($cur_cat) : '';
            ?>
            <a href="./media.php?page=<?= $p ?><?= $qs ?>" class="u-btn u-btn-sm <?= $p === $page ? 'u-btn-main' : 'u-btn-outline' ?>"><?= $p ?></a>
            <?php endfor; ?>
        </div>
        <?php endif; ?>

        <?php endif; ?>

    </div>
</main>

<style>
    .media_card { transition: transform .2s, box-shadow .2s; }
    .media_card:hover { transform: translateY(-4px); }
</style>

<?php include_once(G5_PATH . '/tail.php'); ?>