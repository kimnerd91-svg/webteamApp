<?php
/**
 * search_box.php  —  전역 검색창 (자동완성 미리보기 포함)
 *   사용:  <?php include_once(G5_PATH . '/sub/smartsearch/search_box.php'); ?>
 *   동작:  입력 → 미리보기 드롭다운(키워드·증상단서 매칭) → 선택 시 진료 이동
 *          또는 엔터/검색버튼 → /sub/smartsearch/search_smart.php?q=... 이동
 *   데이터: /data/search_suggest.json (인덱스 빌드 시 생성)
 */
?>
<div class="gsearch-wrap">
  <form class="gsearch" method="get" action="/sub/smartsearch/search_smart.php" role="search" autocomplete="off">
    <input type="text" id="gsearchInput" name="q" placeholder="증상을 문장으로 적어보세요 (예: 치아가 빠졌어요)" autocomplete="off" aria-label="통합검색" aria-expanded="false" aria-controls="gsearchPreview">
    <button type="submit" aria-label="검색"><span class="material-symbols-outlined">search</span></button>
  </form>
  <div class="gsearch-preview" id="gsearchPreview" role="listbox" hidden></div>
</div>
<style>
  .gsearch-wrap{position:relative;max-width:440px}
  .gsearch{display:flex;align-items:center;gap:6px;background:#fff;border:1px solid var(--gray-300);border-radius:999px;padding:5px 5px 5px 18px}
  .gsearch input{flex:1;border:0;outline:0;font:inherit;font-size:15px;background:transparent;color:var(--dark)}
  .gsearch button{flex:none;width:38px;height:38px;border:0;border-radius:50%;background:var(--main-color);color:#fff;display:grid;place-items:center;cursor:pointer}
  .gsearch button:hover{background:color-mix(in srgb, var(--main-color) 85%, #000)}
  .gsearch .material-symbols-outlined{font-size:20px}
  .gsearch-preview{position:absolute;top:calc(100% + 6px);left:0;right:0;background:#fff;border:1px solid var(--gray-300);border-radius:16px;box-shadow:0 12px 28px rgba(0,0,0,.10);padding:6px;z-index:50;max-height:340px;overflow-y:auto}
  .gsp-item{display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:10px;text-decoration:none;color:var(--dark);cursor:pointer}
  .gsp-item:hover,.gsp-item.active{background:var(--light2)}
  .gsp-ic{flex:none;width:26px;height:26px;border-radius:50%;display:grid;place-items:center;font-size:14px;background:var(--light2)}
  .gsp-body{flex:1;min-width:0}
  .gsp-term{font-size:14.5px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .gsp-term mark{background:var(--point);color:inherit;padding:0 1px;border-radius:2px}
  .gsp-name{font-size:12px;color:var(--gray-500);margin-top:1px}
  .gsp-tag{flex:none;font-size:10.5px;font-weight:700;padding:2px 7px;border-radius:999px}
  .gsp-tag.kw{background:var(--light2);color:var(--main-color)}
  .gsp-tag.sy{background:color-mix(in srgb, var(--point) 30%, #fff);color:var(--point)}
  .gsp-empty{padding:14px 12px;color:var(--gray-500);font-size:13px;text-align:center}
</style>
<script>
(function(){
  var input = document.getElementById('gsearchInput');
  var box   = document.getElementById('gsearchPreview');
  if(!input||!box) return;
  var DATA=null, loaded=false, activeIdx=-1, items=[];

  function norm(s){ return (s||'').toLowerCase().replace(/\s+/g,''); }
  // 통증/감각어 어간 통일 (부위어는 SYN_GROUPS에서 처리 — search_smart의 ss_canon과 동일 기조)
  function canon(s){
    s=norm(s);
    var map={'아파요':'아파','아픕니다':'아파','아픔':'아파','아프':'아파','쑤셔':'아파','쑤시':'아파',
      '욱신거려':'욱신','욱신거':'욱신','찌릿':'욱신','시려요':'시려','시린':'시려','시림':'시려','시리':'시려'};
    for(var k in map){ s=s.split(k).join(map[k]); }
    return s;
  }
  // 부위어 동의어 그룹 (search_smart의 SS_SYN_GROUPS와 동일)
  var SYN_GROUPS=[['이','이빨','치아','어금니','앞니','윗니','아랫니','잇빨']];
  // 양방향 매칭 + 동의어 환원 + 원본 2글자 기준 과매칭 방지
  function smatch(nq, term){
    var a=canon(nq), b=canon(term); var ol=a.length;
    for(var g=0;g<SYN_GROUPS.length;g++){ var grp=SYN_GROUPS[g], rep=grp[0];
      for(var i=1;i<grp.length;i++){ a=a.split(grp[i]).join(rep); b=b.split(grp[i]).join(rep); } }
    if(b && a.indexOf(b)>=0) return true;
    if(ol>=2 && b.indexOf(a)>=0) return true;
    return false;
  }
  async function load(){
    if(loaded) return;
    loaded=true;
    try{
      var r=await fetch('/data/search_suggest.json',{cache:'no-cache'});
      var j=await r.json();
      DATA = (j&&j.items)?j.items:[];
    }catch(e){ DATA=[]; }
  }
  function render(q){
    var nqRaw=norm(q);
    items=[];
    if(nqRaw.length>=2 && DATA){
      var seen={};
      for(var i=0;i<DATA.length;i++){
        var it=DATA[i];
        if(smatch(q, it.term)){
          var key=it.name+'|'+it.term;
          if(seen[key])continue; seen[key]=1;
          items.push(it);
          if(items.length>=8)break;
        }
      }
    }
    activeIdx=-1;
    if(items.length===0){
      var len=norm(q).length;
      if(len===1){
        box.innerHTML='<div class="gsp-empty">한 글자만으로는 찾기 어려워요. 증상을 문장으로 적어보세요 (예: 치아가 빠졌어요)</div>';
        box.hidden=false; input.setAttribute('aria-expanded','true');
      }else if(len>=2){
        box.innerHTML='<div class="gsp-empty">엔터를 눌러 \''+escapeHtml(q)+'\' 통합검색</div>';
        box.hidden=false; input.setAttribute('aria-expanded','true');
      }else{ hide(); }
      return;
    }
    var html='';
    items.forEach(function(it,idx){
      var tag = it.type==='symptom' ? '<span class="gsp-tag sy">증상</span>' : '<span class="gsp-tag kw">진료</span>';
      var ic  = it.icon || (it.type==='symptom' ? '💬' : '🦷');
      html+='<a class="gsp-item" data-idx="'+idx+'" href="'+escapeHtml(it.url)+'">'
          + '<span class="gsp-ic">'+ic+'</span>'
          + '<span class="gsp-body"><span class="gsp-term">'+highlight(it.term,q)+'</span>'
          + '<span class="gsp-name">'+escapeHtml(it.name)+'</span></span>'
          + tag + '</a>';
    });
    box.innerHTML=html;
    box.hidden=false; input.setAttribute('aria-expanded','true');
  }
  function highlight(term,q){
    var nq=norm(q); var nt=norm(term);
    var pos=nt.indexOf(nq);
    if(nq===''||pos<0) return escapeHtml(term);
    // 원문 기준 하이라이트는 근사치(정규화 좌표라 단순 표시)
    return escapeHtml(term).replace(new RegExp('('+escapeReg(q.trim())+')','i'),'<mark>$1</mark>');
  }
  function escapeHtml(s){return (s||'').replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
  function escapeReg(s){return s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');}
  function hide(){ box.hidden=true; box.innerHTML=''; activeIdx=-1; input.setAttribute('aria-expanded','false'); }
  function setActive(n){
    var els=box.querySelectorAll('.gsp-item');
    if(!els.length)return;
    if(n<0)n=els.length-1; if(n>=els.length)n=0;
    els.forEach(function(e){e.classList.remove('active');});
    els[n].classList.add('active'); activeIdx=n;
    els[n].scrollIntoView({block:'nearest'});
  }

  var t=null;
  input.addEventListener('input',function(){
    var q=this.value;
    clearTimeout(t);
    t=setTimeout(function(){ load().then(function(){ render(q); }); },80);
  });
  input.addEventListener('focus',function(){ if(this.value.trim()){ load().then(function(){ render(input.value); }); } });
  input.addEventListener('keydown',function(e){
    var els=box.querySelectorAll('.gsp-item');
    if(box.hidden||!els.length) return;
    if(e.key==='ArrowDown'){ e.preventDefault(); setActive(activeIdx+1); }
    else if(e.key==='ArrowUp'){ e.preventDefault(); setActive(activeIdx-1); }
    else if(e.key==='Enter'){
      if(activeIdx>=0 && els[activeIdx]){ e.preventDefault(); location.href=els[activeIdx].getAttribute('href'); }
    } else if(e.key==='Escape'){ hide(); }
  });
  document.addEventListener('click',function(e){
    if(!e.target.closest('.gsearch-wrap')) hide();
  });
})();
</script>
