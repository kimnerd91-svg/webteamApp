<?php
/**
 * quickmenu_modal.php — 단일 버튼 타입 (누르면 항상 consult_modal.php의 #inquiryModal이 뜸)
 * quickmenu_minimal.php과 달리 전화 fallback 없이 항상 상담 모달을 연다.
 * 전제: layout/tail.php가 $use_consult_modal=true일 때 layout/consult_modal.php를 이미 include해둔 상태.
 */
?>
<div id="quick_menu_modal" class="u-pretendard" style="position:fixed; right:20px; bottom:20px; z-index:99; display:flex; flex-direction:column; align-items:flex-end; gap:10px;">
    <button type="button" id="qmModalScrollTop" style="width:44px;height:44px;border-radius:50%;border:1px solid #eee;background:#fff;box-shadow:0 4px 16px rgba(0,0,0,.12);display:flex;align-items:center;justify-content:center;opacity:0;visibility:hidden;transition:opacity .3s, visibility .3s;">
        <span class="material-symbols-outlined c-fs-22 u-txt-dark">North</span>
    </button>

    <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#inquiryModal"
       class="u-bg-main u-txt-white d-flex align-items-center u-gap-8 u-px-22 u-py-16 rounded-full fw-700 c-fs-15"
       style="box-shadow:0 8px 24px rgba(0,0,0,.2);">
        <span class="material-symbols-outlined c-fs-22">chat_bubble</span>
        빠른상담 신청
    </a>
</div>

<script>
    (function () {
        var btn = document.getElementById('qmModalScrollTop');
        if (!btn) return;
        window.addEventListener('scroll', function () {
            if (window.scrollY > 200) {
                btn.style.opacity = '1';
                btn.style.visibility = 'visible';
            } else {
                btn.style.opacity = '0';
                btn.style.visibility = 'hidden';
            }
        });
        btn.addEventListener('click', function () {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    })();
</script>
