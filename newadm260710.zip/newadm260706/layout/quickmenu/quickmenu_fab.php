<?php
/**
 * quickmenu_fab.php — 토글 확장형(FAB) 타입
 * 평소엔 원형 버튼 하나만 떠 있다가, 누르면 버튼이 X로 바뀌면서
 * 알약 모양 메뉴들이 위쪽으로 순서대로 펼쳐진다(스피드다이얼 패턴).
 * 전제: $cf_naver_booking, $cf_kakao, $cf_blog, $cf_tel이 head_sub.php를 통해 채워진 상태에서 include됨.
 */

$fab_items = [];
if (!empty($cf_blog))          $fab_items[] = ['label' => '공식블로그', 'icon' => 'edit_note', 'href' => $cf_blog];
if (!empty($cf_kakao))         $fab_items[] = ['label' => '카톡 상담',  'icon' => 'chat',       'href' => $cf_kakao];
if (!empty($cf_naver_booking)) $fab_items[] = ['label' => '네이버예약', 'icon' => 'event',      'href' => $cf_naver_booking];
$fab_items[] = ['label' => '오시는길', 'icon' => 'location_on', 'href' => '/#location'];
?>
<div id="quick_menu_fab" class="u-pretendard" style="position:fixed; right:20px; bottom:24px; z-index:99; display:flex; flex-direction:column-reverse; align-items:flex-end; gap:12px;">
    <button type="button" id="fabToggle" aria-expanded="false" aria-label="퀵메뉴 열기"
        style="width:56px;height:56px;border-radius:50%;border:none;background:var(--main-color,#4f46e5);box-shadow:0 8px 24px rgba(0,0,0,.25);display:flex;align-items:center;justify-content:center;cursor:pointer;transition:transform .25s ease;">
        <span class="material-symbols-outlined c-fs-28 u-txt-white" id="fabToggleIcon">add</span>
    </button>

    <span id="fabHint" style="font-size:11px; font-weight:700; color:#666; text-align:center; align-self:center; transition:opacity .2s;">↑ 메뉴 열기</span>

    <div id="fabItems" style="display:flex; flex-direction:column; align-items:flex-end; gap:10px;">
        <?php foreach (array_reverse($fab_items) as $i => $item): ?>
            <a href="<?= htmlspecialchars($item['href']) ?>" target="_blank" class="fab-pill"
               style="text-decoration:none; display:flex; align-items:center; gap:8px; background:#fff; color:#1a1a2e; padding:11px 20px; border-radius:999px; box-shadow:0 6px 18px rgba(0,0,0,.16); font-size:13.5px; font-weight:700; white-space:nowrap; opacity:0; transform:translateY(12px); transition:opacity .25s ease, transform .25s ease; transition-delay:<?= $i * 0.04 ?>s;">
                <span class="material-symbols-outlined c-fs-18 u-txt-main"><?= $item['icon'] ?></span>
                <?= htmlspecialchars($item['label']) ?>
            </a>
        <?php endforeach; ?>
    </div>
</div>

<script>
    (function () {
        var toggle = document.getElementById('fabToggle');
        var icon = document.getElementById('fabToggleIcon');
        var hint = document.getElementById('fabHint');
        var itemsWrap = document.getElementById('fabItems');
        var pills = itemsWrap ? itemsWrap.querySelectorAll('.fab-pill') : [];
        var open = false;

        function setOpen(v) {
            open = v;
            toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
            toggle.style.transform = open ? 'rotate(45deg)' : 'rotate(0deg)';
            icon.textContent = open ? 'close' : 'add';
            hint.style.opacity = open ? '0' : '1';
            pills.forEach(function (p) {
                p.style.opacity = open ? '1' : '0';
                p.style.transform = open ? 'translateY(0)' : 'translateY(12px)';
                p.style.pointerEvents = open ? 'auto' : 'none';
            });
        }

        if (toggle) {
            setOpen(false);
            toggle.addEventListener('click', function () { setOpen(!open); });
        }
    })();
</script>
