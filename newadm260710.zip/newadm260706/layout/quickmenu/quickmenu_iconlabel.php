<?php
/**
 * quickmenu_iconlabel.php — 아이콘+텍스트 라벨 세로 목록 타입
 * 원형 아이콘 버튼 아래에 짧은 라벨이 붙는 형태로 세로로 쌓인다. (참고: 원형 아이콘형 퀵메뉴)
 * 전제: $cf_naver_booking, $cf_kakao, $cf_blog, $cf_instagram, $cf_tel이 head_sub.php를 통해 채워진 상태에서 include됨.
 */

$ql_items = [];
if (!empty($cf_naver_booking)) $ql_items[] = ['label' => '네이버 예약', 'icon' => 'event', 'href' => $cf_naver_booking, 'bg' => '#03c75a'];
if (!empty($cf_kakao))         $ql_items[] = ['label' => '카톡 상담',   'icon' => 'chat',  'href' => $cf_kakao, 'bg' => '#FEE500', 'dark' => true];
if (!empty($cf_blog))          $ql_items[] = ['label' => '공식 블로그', 'icon' => 'edit_note', 'href' => $cf_blog, 'bg' => '#03c75a'];
if (!empty($cf_instagram))     $ql_items[] = ['label' => '인스타그램', 'icon' => 'photo_camera', 'href' => $cf_instagram, 'bg' => '#d6249f'];
$ql_items[] = ['label' => '원클릭 전화상담', 'icon' => 'call', 'href' => 'tel:' . preg_replace('/[^0-9]/', '', $cf_tel ?? ''), 'bg' => 'var(--main-color, #333)'];
?>
<div id="quick_menu_iconlabel" class="u-pretendard" style="position:fixed; right:20px; bottom:30%; z-index:99; display:flex; flex-direction:column; align-items:center; gap:14px;">
    <?php foreach ($ql_items as $item): ?>
        <a href="<?= htmlspecialchars($item['href']) ?>" target="_blank" class="qil-item" style="text-decoration:none; display:flex; flex-direction:column; align-items:center; gap:4px;">
            <span class="qil-ic" style="width:50px; height:50px; border-radius:50%; background:<?= htmlspecialchars($item['bg']) ?>; display:flex; align-items:center; justify-content:center; box-shadow:0 4px 14px rgba(0,0,0,.18);">
                <span class="material-symbols-outlined c-fs-24" style="color:<?= !empty($item['dark']) ? '#191919' : '#fff' ?>;"><?= $item['icon'] ?></span>
            </span>
            <span class="qil-label" style="font-size:11px; font-weight:700; color:#fff; background:rgba(0,0,0,.55); padding:2px 8px; border-radius:999px; white-space:nowrap;">
                <?= htmlspecialchars($item['label']) ?>
            </span>
        </a>
    <?php endforeach; ?>
</div>

<style>
    .qil-item { transition: transform .15s ease; }
    .qil-item:hover { transform: translateY(-3px); }
    @media (max-width: 560px) {
        #quick_menu_iconlabel { right: 10px; gap: 10px; }
        #quick_menu_iconlabel .qil-ic { width: 42px; height: 42px; }
    }
</style>
