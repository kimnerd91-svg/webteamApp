<?php
/**
 * quickmenu_icontop.php — 아이콘+라벨 세로 목록 + 맨 위로(TOP) 버튼 포함 타입
 * quickmenu_iconlabel.php과 같은 아이콘 목록이되, 카드형 박스 안에 담기고
 * 맨 아래에 스크롤-탑 버튼이 이어붙는다. (참고: 카드형 아이콘+TOP 퀵메뉴)
 * 전제: $cf_naver_booking, $cf_kakao, $cf_blog, $cf_instagram, $cf_tel이 head_sub.php를 통해 채워진 상태에서 include됨.
 */

$qt_items = [];
if (!empty($cf_naver_booking)) $qt_items[] = ['label' => '네이버 예약', 'icon' => 'event', 'href' => $cf_naver_booking];
if (!empty($cf_kakao))         $qt_items[] = ['label' => '카톡 상담',   'icon' => 'chat',  'href' => $cf_kakao];
if (!empty($cf_blog))          $qt_items[] = ['label' => '공식 블로그', 'icon' => 'edit_note', 'href' => $cf_blog];
if (!empty($cf_instagram))     $qt_items[] = ['label' => '인스타그램', 'icon' => 'photo_camera', 'href' => $cf_instagram];
$qt_items[] = ['label' => '전화상담', 'icon' => 'call', 'href' => 'tel:' . preg_replace('/[^0-9]/', '', $cf_tel ?? '')];
?>
<div id="quick_menu_icontop" class="u-pretendard" style="position:fixed; right:20px; bottom:24px; z-index:99; display:flex; flex-direction:column; align-items:center; gap:10px;">
    <div style="background:#fff; border-radius:20px; box-shadow:0 10px 30px rgba(0,0,0,.16); padding:14px 10px; display:flex; flex-direction:column; gap:14px;">
        <?php foreach ($qt_items as $item): ?>
            <a href="<?= htmlspecialchars($item['href']) ?>" target="_blank" class="qit-item" style="text-decoration:none; display:flex; flex-direction:column; align-items:center; gap:5px; width:64px;">
                <span class="qit-ic" style="width:44px; height:44px; border-radius:12px; background:#f5f6fa; display:flex; align-items:center; justify-content:center;">
                    <span class="material-symbols-outlined c-fs-22 u-txt-main"><?= $item['icon'] ?></span>
                </span>
                <span style="font-size:11px; font-weight:600; color:#444; text-align:center; line-height:1.3;"><?= htmlspecialchars($item['label']) ?></span>
            </a>
        <?php endforeach; ?>
    </div>

    <button type="button" id="qitScrollTop" class="u-bg-main" style="width:48px;height:48px;border-radius:50%;border:none;box-shadow:0 6px 18px rgba(0,0,0,.2);display:flex;align-items:center;justify-content:center;cursor:pointer;">
        <span class="material-symbols-outlined c-fs-24 u-txt-white">North</span>
    </button>
</div>

<style>
    .qit-item { transition: background .15s; border-radius: 10px; padding: 2px; }
    .qit-item:hover .qit-ic { background: var(--accent-soft, #ede9fe); }
</style>

<script>
    (function () {
        var btn = document.getElementById('qitScrollTop');
        if (!btn) return;
        btn.addEventListener('click', function () {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    })();
</script>
