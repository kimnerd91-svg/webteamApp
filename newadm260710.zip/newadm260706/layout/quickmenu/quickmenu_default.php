<?php
/**
 * quickmenu_default.php — 기본 퀵메뉴 (PC 알약형/박스형 + 모바일 하단바 + 통합검색 모달)
 * 전제: $dm_conf, $cf_naver_booking, $cf_kakao, $cf_blog, $cf_instagram, $cf_tel,
 *       $use_consult_modal 이 이미 채워진 상태에서 include됨 (layout/tail.php가 준비)
 */
?>
<!-- 퀵메뉴 (PC) -->
<div id="quick_menu_pill" class="u-pretendard d-none d-lg-none">
    <div class="quick_menu_pill-container">
        <div class="quick_menu_pill-items active">
            <ul class="u-gap-8 d-flex flex-column ">
                <li>
                    <?php if (!empty($cf_naver_booking)): ?>
                        <a href="<?= htmlspecialchars($cf_naver_booking) ?>" target="_blank" class="qm-bar-fixed-item u-bg-main">
                            <img src="/images/q01.svg" alt="네이버 예약 아이콘" />
                            <div class="qm-bar-fixed-item-text">
                                <p class="fw-500 c-fs-16 u-lh-14 u-ls-10 u-txt-white">네이버 예약</p>
                            </div>
                        </a>
                    <?php endif; ?>
                </li>
                <li>
                    <?php if (!empty($cf_kakao)): ?>
                        <a href="<?= htmlspecialchars($cf_kakao) ?>" target="_blank" class="qm-bar-fixed-item u-bg-main">
                            <img src="/images/q02.svg" alt="카카오톡 아이콘" />
                            <div class="qm-bar-fixed-item-text">
                                <p class="fw-500 c-fs-16 u-lh-14 u-ls-10">카톡 상담</p>
                            </div>
                        </a>
                    <?php endif; ?>
                </li>
                <li>
                    <?php if (!empty($cf_blog)): ?>
                        <a href="<?= htmlspecialchars($cf_blog) ?>" target="_blank" class="qm-bar-fixed-item u-bg-main">
                            <img src="/images/q03.svg" alt="네이버 블로그 아이콘" />
                            <div class="qm-bar-fixed-item-text">
                                <p class="fw-500 c-fs-16 u-lh-14 u-ls-10 u-txt-dark">블로그</p>
                            </div>
                        </a>
                    <?php endif; ?>
                </li>
                <li>
                    <?php if (!empty($cf_instagram)): ?>
                        <a href="<?= htmlspecialchars($cf_instagram) ?>" target="_blank" class="qm-bar-fixed-item u-bg-main">
                            <img src="/images/q04.svg" alt="인스타그램 아이콘" />
                            <div class="qm-bar-fixed-item-text">
                                <p class="fw-500 c-fs-16 u-lh-14 u-ls-10 u-txt-white">인스타그램</p>
                            </div>
                        </a>
                    <?php endif; ?>
                </li>
                <li>
                    <a href="/sub/info.php" target="_blank" class="qm-bar-fixed-item u-bg-main">
                        <img src="/images/q05.svg" alt="맵 핀모양 아이콘" />
                        <div class="qm-bar-fixed-item-text">
                            <p class="fw-500 c-fs-16 u-lh-14 u-ls-10 u-txt-white">오시는 길</p>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="javascript:void(0)" onclick="openSmartSearch()" class="qm-bar-fixed-item u-bg-main">
                        <span class="qm-search-ico" aria-hidden="true">
                            <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round">
                                <circle cx="11" cy="11" r="7"></circle>
                                <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                            </svg>
                        </span>
                        <div class="qm-bar-fixed-item-text">
                            <p class="fw-500 c-fs-16 u-lh-14 u-ls-10 u-txt-white">스마트서치</p>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#inquiryModal" class="qm-bar-fixed-item u-bg-main">
                        <span class="qm-search-ico" aria-hidden="true">
                            <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round">
                                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                            </svg>
                        </span>
                        <div class="qm-bar-fixed-item-text">
                            <p class="fw-500 c-fs-16 u-lh-14 u-ls-10 u-txt-white">빠른상담</p>
                        </div>
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <button type="button" id="qm_pill_toggle" class="qm-pill-toggle u-bg-sub u-mt-16-sm">
        <img class="w-100 w-50-sm" src="/images/quickLogo.svg" alt="치과로고" />
    </button>

    <button type="button" class="u-mt-8 u-mt-16-sm u-txt-gray-400 u-op-5 u-bd-n u-bg-sub" id="scrollTop">
        <span class="material-symbols-outlined c-fs-32 c-fs-44-sm u-txt-white">North</span>
    </button>
</div>

<!-- 퀵메뉴 (PC 2) -->
<div id="quick_menu_box" class="u-pretendard d-none d-lg-flex flex-column " style="z-index: 99;">
    <ul class="qm-box-list d-flex flex-column u-bg-white  u-py-20 u-pt-28 shadow-hard u-round-full">

        <?php if (!empty($cf_naver_booking)): ?>
            <li class="qm-box-item u-py-10 u-px-14">
                <a href="<?= htmlspecialchars($cf_naver_booking) ?>" target="_blank" class="qm-box-link">
                    <span class="qm-box-icon">
                        <img src="/images/qb01.svg" alt="네이버 예약 아이콘">
                    </span>
                    <span class="qm-box-label u-txt-dark c-fs-16 fw-500 u-lh-14 u-ls-20 text-center">네이버 예약</span>
                </a>
            </li>
        <?php endif; ?>

        <?php if (!empty($cf_kakao)): ?>
            <li class="qm-box-item u-py-10 u-px-14">
                <a href="<?= htmlspecialchars($cf_kakao) ?>" target="_blank" class="qm-box-link">
                    <span class="qm-box-icon">
                        <img src="/images/qb02.svg" alt="카카오톡 아이콘">
                    </span>
                    <span class="qm-box-label u-txt-dark c-fs-16 fw-500 u-lh-14 u-ls-20 text-center">카톡 상담</span>
                </a>
            </li>
        <?php endif; ?>

        <?php if (!empty($cf_blog)): ?>
            <li class="qm-box-item u-py-10 u-px-14">
                <a href="<?= htmlspecialchars($cf_blog) ?>" target="_blank" class="qm-box-link">
                    <span class="qm-box-icon">
                        <img src="/images/qb03.svg" alt="공식 블로그 아이콘">
                    </span>
                    <span class="qm-box-label u-txt-dark c-fs-16 fw-500 u-lh-14 u-ls-20 text-center">공식 블로그</span>
                </a>
            </li>
        <?php endif; ?>

        <?php if (!empty($cf_instagram)): ?>
            <li class="qm-box-item u-py-10 u-px-14">
                <a href="<?= htmlspecialchars($cf_instagram) ?>" target="_blank" class="qm-box-link">
                    <span class="qm-box-icon">
                        <img src="/images/qb05.svg" alt="인스타그램 아이콘">
                    </span>
                    <span class="qm-box-label u-txt-dark c-fs-16 fw-500 u-lh-14 u-ls-20 text-center">인스타그램</span>
                </a>
            </li>
        <?php endif; ?>

        <li class="qm-box-item u-py-10 u-px-14">
            <a href="/#location" class="qm-box-link">
                <span class="qm-box-icon">
                    <img src="/images/qb_location.svg" alt="오시는 길">
                </span>
                <span class="qm-box-label u-txt-dark c-fs-16 fw-500 u-lh-14 u-ls-20 text-center">오시는 길</span>
            </a>
        </li>

        <li class="qm-box-item u-py-10 u-px-14">
            <a href="javascript:void(0)" onclick="openSmartSearch()" class="qm-box-link">
                <span class="qm-box-icon">
                    <svg viewBox="0 0 24 24" width="40" height="40" fill="none" stroke="var(--main-color)" stroke-width="2" stroke-linecap="round" aria-hidden="true">
                        <circle cx="11" cy="11" r="7"></circle>
                        <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                    </svg>
                </span>
                <span class="qm-box-label u-txt-dark c-fs-16 fw-500 u-lh-14 u-ls-20 text-center">스마트서치</span>
            </a>
        </li>

        <?php if (!empty($cf_tel)): ?>
            <li class="qm-box-item u-py-20 u-px-14 u-pb-28">
                <a href="tel:<?= preg_replace('/[^0-9]/', '', $cf_tel) ?>" class="qm-box-link">
                    <span class="qm-box-icon">
                        <img src="/images/qb06.svg" alt="전화 아이콘">
                    </span>
                    <span class="qm-box-label u-txt-dark c-fs-16 fw-500 u-lh-14 u-ls-20 text-center">전화상담<br><?= htmlspecialchars($cf_tel) ?></span>
                </a>
            </li>
        <?php endif; ?>

    </ul>
    <button type="button" class="u-mt-8 u-mt-16-sm u-txt-gray-400 u-bd-n u-bg-point" id="scrollUp">
        <span class="c-fs-32 c-fs-44-sm u-txt-white w-100 u-p-24">
            <img class="w-100" src="/images/top.svg" alt="">
        </span>
    </button>
</div>

<script>
    (function() {
        const btn = document.getElementById('scrollUp');
        const box = document.getElementById('quick_menu_box');
        if (!btn || !box) return;

        btn.style.opacity = '0';
        btn.style.visibility = 'hidden';
        btn.style.transform = 'translateY(20px)';
        btn.style.transition = 'opacity 0.35s ease, transform 0.35s ease, visibility 0.35s ease';
        box.style.gap = '0px';
        box.style.transition = 'gap 0.35s ease';

        window.addEventListener('scroll', function() {
            if (window.scrollY > 100) {
                btn.style.opacity = '1';
                btn.style.visibility = 'visible';
                btn.style.transform = 'translateY(0)';
                box.style.gap = 'var(--sp-15, 24px)';
            } else {
                btn.style.opacity = '0';
                btn.style.visibility = 'hidden';
                btn.style.transform = 'translateY(20px)';
                box.style.gap = '0px';
            }
        });

        btn.addEventListener('click', function() {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    })();
</script>

<style>
    #quick_menu_box {
        position: fixed;
        bottom: var(--sp-40);
        max-width: 105px;
        width: 100%;
        right: var(--sp-20);
        min-height: 450px;
    }
    #quick_menu_box .qm-box-item { border-bottom: 1px solid var(--gray-300); }
    #quick_menu_box .qm-box-item:last-child { border: none; }
    #quick_menu_box .qm-box-item a {
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        gap: var(--sp-8);
    }
    #quick_menu_box #scrollUp {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 100%;
        max-width: 90px;
        aspect-ratio: 1 / 1;
        border-radius: 50%;
        border: none;
        cursor: pointer;
        margin: 8px auto 0;
        transition: opacity 0.2s, transform 0.2s;
    }
    #quick_menu_box #scrollUp:hover { opacity: 0.85; transform: translateY(-2px); }
    #quick_menu_box #scrollUp .material-symbols-outlined { font-size: 22px; line-height: 1; }
    .qm-box-icon img { width: 100%; max-width: 40px; }
</style>

<!-- 퀵메뉴 (모바일) -->
<div id="quick_menu_mobile" class="u-bg-white d-block d-lg-none position-fixed w-100 u-pretendard" style="bottom: 0; left: 0; z-index: 3">
    <button type="button" onclick="openSmartSearch()" id="qm_mo_search" class="u-bg-main u-bd-n position-absolute d-flex align-items-center justify-content-center" aria-label="통합검색">
        <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" aria-hidden="true">
            <circle cx="11" cy="11" r="7"></circle>
            <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
        </svg>
    </button>
    <ul class="d-flex">
        <?php if (!empty($use_consult_modal)): ?>
            <li class="flex-1 d-flex align-items-center justify-content-center">
                <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#inquiryModal" class="w-100 h-100 d-flex flex-column justify-content-center align-items-center">
                    <span class="material-symbols-outlined c-fs-32 u-mb-4-sm u-txt-dark">chat_bubble</span>
                    <p class="c-fs-14-sm fw-500 u-lh-15 u-txt-dark text-center">빠른상담</p>
                </a>
            </li>
        <?php else: ?>
            <li class="flex-1 d-flex align-items-center justify-content-center">
                <a href="tel:<?= preg_replace('/[^0-9]/', '', $cf_tel ?? '') ?>" class="w-100 h-100 d-flex flex-column justify-content-center align-items-center">
                    <img style="filter: hue-rotate(0deg);" class="w-max u-mb-4-sm" src="/images/tel.svg" alt="전화 아이콘">
                    <p class="c-fs-14-sm fw-500 u-lh-15 u-txt-dark text-center">전화문의</p>
                </a>
            </li>
        <?php endif; ?>
        <li class="flex-1 u-py-16-sm">
            <?php if (!empty($cf_naver_booking)): ?>
                <a href="<?= htmlspecialchars($cf_naver_booking) ?>" target="_blank" class="w-100 h-100 d-flex flex-column justify-content-center align-items-center">
                    <img class="w-max u-mb-4-sm" src="/images/naverMo.svg" alt="예약 아이콘" />
                    <div class="qm-bar-fixed-item-text">
                        <p class="c-fs-14-sm fw-500 u-lh-15 u-txt-dark text-center">예약</p>
                    </div>
                </a>
            <?php endif; ?>
        </li>
        <li class="flex-1 u-py-16-sm">
            <?php if (!empty($cf_kakao)): ?>
                <a href="<?= htmlspecialchars($cf_kakao) ?>" target="_blank" class="w-100 h-100 d-flex flex-column justify-content-center align-items-center">
                    <img class="w-max u-mb-4-sm" src="/images/kakaomo.svg" alt="카카오톡 아이콘" />
                    <div class="qm-bar-fixed-item-text">
                        <p class="c-fs-14-sm fw-500 u-lh-15 u-txt-dark text-center">카카오톡</p>
                    </div>
                </a>
            <?php endif; ?>
        </li>
        <li class="flex-1 u-py-16-sm">
            <?php if (!empty($cf_blog)): ?>
                <a href="<?= htmlspecialchars($cf_blog) ?>" target="_blank" class="w-100 h-100 d-flex flex-column justify-content-center align-items-center">
                    <img class="w-max u-mb-4-sm" src="/images/blogmo.svg" alt="네이버 블로그 아이콘" />
                    <div class="qm-bar-fixed-item-text">
                        <p class="c-fs-14-sm fw-500 u-lh-15 u-txt-dark text-center">블로그</p>
                    </div>
                </a>
            <?php endif; ?>
        </li>
        <li class="flex-1 u-py-16-sm">
            <button type="button" class="w-100 h-100 d-flex flex-column justify-content-center align-items-center u-bd-n u-bg-transparent" id="scrollTop2">
                <span class="material-symbols-outlined c-fs-32 c-fs-44-sm u-mb-4-sm u-txt-dark">North</span>
                <p class="c-fs-14-sm fw-500 u-lh-15 u-txt-dark text-center">TOP</p>
            </button>
        </li>
    </ul>
</div>

<!-- 통합검색(스마트서치) 모달 -->
<div id="ssModal" class="ss-modal" role="dialog" aria-modal="true" aria-label="통합검색" hidden>
    <div class="ss-modal-dim" onclick="closeSmartSearch()"></div>
    <div class="ss-modal-panel u-pretendard">
        <button type="button" class="ss-modal-close" onclick="closeSmartSearch()" aria-label="닫기">
            <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
                <line x1="6" y1="6" x2="18" y2="18"></line>
                <line x1="18" y1="6" x2="6" y2="18"></line>
            </svg>
        </button>
        <p class="ss-modal-lead">무엇이든 검색해보세요</p>
        <div class="ss-modal-searchwrap">
            <form class="ss-modal-form" method="get" action="/search" role="search" autocomplete="off">
                <span class="ss-modal-ico" aria-hidden="true">
                    <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
                        <circle cx="11" cy="11" r="7"></circle>
                        <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                    </svg>
                </span>
                <input type="text" id="ssModalInput" name="q" placeholder="증상을 문장으로 적어보세요 (예: 치아가 빠졌어요)" autocomplete="off" aria-label="통합검색" aria-expanded="false" aria-controls="ssModalPreview">
                <button type="submit" aria-label="검색">검색</button>
            </form>
            <div class="ss-modal-preview" id="ssModalPreview" role="listbox" hidden></div>
        </div>
        <p class="ss-modal-hint">예: 임플란트, 잇몸이 부었어요, 치아미백</p>
    </div>
</div>

<style>
    .ss-modal { position: fixed; inset: 0; z-index: var(--z-modal, 1050); display: flex; align-items: flex-start; justify-content: center; padding: 14vh 16px 16px }
    .ss-modal[hidden] { display: none }
    .ss-modal-dim { position: absolute; inset: 0; background: rgba(20, 24, 28, .5); backdrop-filter: blur(3px); -webkit-backdrop-filter: blur(3px) }
    .ss-modal-panel { position: relative; width: 100%; max-width: 560px; background: var(--white); border-radius: 24px; box-shadow: 0 30px 80px rgba(0, 0, 0, .28); padding: 34px 30px 28px; animation: ssPop .22s ease }
    @keyframes ssPop { from { transform: translateY(-12px); opacity: 0 } to { transform: translateY(0); opacity: 1 } }
    .ss-modal-close { position: absolute; top: 16px; right: 16px; width: 38px; height: 38px; border: 0; background: var(--gray-100); color: var(--gray-700); border-radius: 50%; display: grid; place-items: center; cursor: pointer; transition: .15s }
    .ss-modal-close:hover { background: var(--gray-200); color: var(--dark) }
    .ss-modal-lead { font-size: 22px; font-weight: 800; letter-spacing: -.02em; color: var(--dark); margin: 0 0 18px }
    .ss-modal-searchwrap { position: relative }
    .ss-modal-form { display: flex; align-items: center; gap: 8px; background: var(--light); border: 1px solid var(--gray-300); border-radius: 999px; padding: 6px 6px 6px 16px }
    .ss-modal-ico { flex: none; color: var(--main-color); display: grid; place-items: center }
    .ss-modal-form input { flex: 1; border: 0; outline: 0; background: transparent; font: inherit; font-size: 16px; color: var(--dark) }
    .ss-modal-form button { flex: none; border: 0; cursor: pointer; border-radius: 999px; background: var(--main-color); color: var(--white); font: inherit; font-weight: 700; padding: 11px 22px }
    .ss-modal-form button:hover { background: color-mix(in srgb, var(--main-color) 85%, #000) }
    .ss-modal-hint { margin: 14px 4px 0; font-size: 13px; color: var(--gray-500) }
    .ss-modal-preview { position: absolute; top: calc(100% + 8px); left: 0; right: 0; background: var(--white); border: 1px solid var(--gray-300); border-radius: 16px; box-shadow: 0 12px 28px rgba(0, 0, 0, .10); padding: 6px; z-index: 5; max-height: 340px; overflow-y: auto }
    .ss-modal-preview .gsp-item { display: flex; align-items: center; gap: 10px; padding: 10px 12px; border-radius: 10px; text-decoration: none; color: var(--dark); cursor: pointer }
    .ss-modal-preview .gsp-item:hover, .ss-modal-preview .gsp-item.active { background: var(--light2) }
    .ss-modal-preview .gsp-ic { flex: none; width: 26px; height: 26px; border-radius: 50%; display: grid; place-items: center; font-size: 14px; background: var(--light2) }
    .ss-modal-preview .gsp-body { flex: 1; min-width: 0 }
    .ss-modal-preview .gsp-term { font-size: 14.5px; font-weight: 700; white-space: nowrap; overflow: hidden; text-overflow: ellipsis }
    .ss-modal-preview .gsp-term mark { background: var(--point); color: inherit; padding: 0 1px; border-radius: 2px }
    .ss-modal-preview .gsp-name { font-size: 12px; color: var(--gray-500); margin-top: 1px }
    .ss-modal-preview .gsp-tag { flex: none; font-size: 10.5px; font-weight: 700; padding: 2px 7px; border-radius: 999px }
    .ss-modal-preview .gsp-tag.kw { background: var(--light2); color: var(--main-color) }
    .ss-modal-preview .gsp-tag.sy { background: color-mix(in srgb, var(--point) 30%, #fff); color: var(--point) }
    .ss-modal-preview .gsp-empty { padding: 14px 12px; color: var(--gray-500); font-size: 13px; text-align: center }
    #qm_mo_search { width: 52px; height: 52px; border-radius: 50%; right: 16px; top: -26px; box-shadow: 0 8px 20px rgba(0, 0, 0, .22); z-index: 5; }
    #qm_mo_search svg { display: block }
    #qm_mo_search:active { transform: scale(.95) }
</style>

<script>
    (function() {
        var modal = document.getElementById('ssModal');
        var input = document.getElementById('ssModalInput');
        var box = document.getElementById('ssModalPreview');
        if (!modal || !input || !box) return;
        var DATA = null, loaded = false, activeIdx = -1, items = [];

        function norm(s) { return (s || '').toLowerCase().replace(/\s+/g, ''); }

        function canon(s) {
            s = norm(s);
            var map = {
                '아파요': '아파', '아픕니다': '아파', '아픔': '아파', '아프': '아파', '쑤셔': '아파', '쑤시': '아파',
                '욱신거려': '욱신', '욱신거': '욱신', '찌릿': '욱신',
                '시려요': '시려', '시린': '시려', '시림': '시려', '시리': '시려'
            };
            for (var k in map) { s = s.split(k).join(map[k]); }
            return s;
        }
        var SYN_GROUPS = [['이', '이빨', '치아', '어금니', '앞니', '윗니', '아랫니', '잇빨']];

        function smatch(nq, term) {
            var a = canon(nq), b = canon(term);
            var ol = a.length;
            for (var g = 0; g < SYN_GROUPS.length; g++) {
                var grp = SYN_GROUPS[g], rep = grp[0];
                for (var i = 1; i < grp.length; i++) {
                    a = a.split(grp[i]).join(rep);
                    b = b.split(grp[i]).join(rep);
                }
            }
            if (b && a.indexOf(b) >= 0) return true;
            if (ol >= 2 && b.indexOf(a) >= 0) return true;
            return false;
        }
        async function load() {
            if (loaded) return;
            loaded = true;
            try {
                var r = await fetch('/data/search_suggest.json', { cache: 'no-cache' });
                var j = await r.json();
                DATA = (j && j.items) ? j.items : [];
            } catch (e) { DATA = []; }
        }

        function escapeHtml(s) {
            return (s || '').replace(/[&<>"]/g, function(c) {
                return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
            });
        }
        function escapeReg(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }

        function highlight(term, q) {
            var nq = norm(q), nt = norm(term), pos = nt.indexOf(nq);
            if (nq === '' || pos < 0) return escapeHtml(term);
            return escapeHtml(term).replace(new RegExp('(' + escapeReg(q.trim()) + ')', 'i'), '<mark>$1</mark>');
        }

        function hide() {
            box.hidden = true;
            box.innerHTML = '';
            activeIdx = -1;
            input.setAttribute('aria-expanded', 'false');
        }

        function setActive(n) {
            var els = box.querySelectorAll('.gsp-item');
            if (!els.length) return;
            if (n < 0) n = els.length - 1;
            if (n >= els.length) n = 0;
            els.forEach(function(e) { e.classList.remove('active'); });
            els[n].classList.add('active');
            activeIdx = n;
            els[n].scrollIntoView({ block: 'nearest' });
        }

        function render(q) {
            var nqRaw = norm(q);
            items = [];
            if (nqRaw.length >= 2 && DATA) {
                var seen = {};
                for (var i = 0; i < DATA.length; i++) {
                    var it = DATA[i];
                    if (smatch(q, it.term)) {
                        var key = it.name + '|' + it.term;
                        if (seen[key]) continue;
                        seen[key] = 1;
                        items.push(it);
                        if (items.length >= 8) break;
                    }
                }
            }
            activeIdx = -1;
            if (items.length === 0) {
                var len = norm(q).length;
                if (len === 1) {
                    box.innerHTML = '<div class="gsp-empty">한 글자만으로는 찾기 어려워요. 증상을 문장으로 적어보세요</div>';
                    box.hidden = false;
                    input.setAttribute('aria-expanded', 'true');
                } else if (len >= 2) {
                    box.innerHTML = '<div class="gsp-empty">엔터를 눌러 \'' + escapeHtml(q) + '\' 통합검색</div>';
                    box.hidden = false;
                    input.setAttribute('aria-expanded', 'true');
                } else { hide(); }
                return;
            }
            var html = '';
            items.forEach(function(it, idx) {
                var tag = it.type === 'symptom' ? '<span class="gsp-tag sy">증상</span>' : '<span class="gsp-tag kw">진료</span>';
                var ic = it.type === 'symptom' ? '💬' : '🦷';
                html += '<a class="gsp-item" data-idx="' + idx + '" href="' + escapeHtml(it.url) + '">' +
                    '<span class="gsp-ic">' + ic + '</span>' +
                    '<span class="gsp-body"><span class="gsp-term">' + highlight(it.term, q) + '</span>' +
                    '<span class="gsp-name">' + escapeHtml(it.name) + '</span></span>' + tag + '</a>';
            });
            box.innerHTML = html;
            box.hidden = false;
            input.setAttribute('aria-expanded', 'true');
        }

        var t = null;
        input.addEventListener('input', function() {
            var q = this.value;
            clearTimeout(t);
            t = setTimeout(function() { load().then(function() { render(q); }); }, 80);
        });
        input.addEventListener('keydown', function(e) {
            var els = box.querySelectorAll('.gsp-item');
            if (e.key === 'Escape') { closeSmartSearch(); return; }
            if (box.hidden || !els.length) return;
            if (e.key === 'ArrowDown') { e.preventDefault(); setActive(activeIdx + 1); }
            else if (e.key === 'ArrowUp') { e.preventDefault(); setActive(activeIdx - 1); }
            else if (e.key === 'Enter') {
                if (activeIdx >= 0 && els[activeIdx]) {
                    e.preventDefault();
                    location.href = els[activeIdx].getAttribute('href');
                }
            }
        });

        window.openSmartSearch = function() {
            modal.hidden = false;
            document.body.style.overflow = 'hidden';
            load();
            setTimeout(function() { input.focus(); }, 50);
        };
        window.closeSmartSearch = function() {
            modal.hidden = true;
            document.body.style.overflow = '';
            hide();
        };
    })();
</script>
