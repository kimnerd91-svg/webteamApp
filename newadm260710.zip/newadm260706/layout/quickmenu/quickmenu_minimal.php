<?php
/**
 * quickmenu_minimal.php — 미니멀 퀵메뉴 (단일 플로팅 버튼: 상담하기 + 맨위로)
 * 전제: $cf_tel, $use_consult_modal이 이미 채워진 상태에서 include됨 (layout/tail.php가 준비)
 */
?>
<div id="quick_menu_minimal" class="u-pretendard" style="position:fixed; right:20px; bottom:20px; z-index:99; display:flex; flex-direction:column; gap:10px; align-items:flex-end;">
    <button type="button" id="qmMinScrollTop" style="width:44px;height:44px;border-radius:50%;border:1px solid #eee;background:#fff;box-shadow:0 4px 16px rgba(0,0,0,.12);display:flex;align-items:center;justify-content:center;opacity:0;visibility:hidden;transition:opacity .3s, visibility .3s;">
        <span class="material-symbols-outlined c-fs-22 u-txt-dark">North</span>
    </button>

    <?php if (!empty($use_consult_modal)): ?>
        <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#inquiryModal"
           class="u-bg-main u-txt-white d-flex align-items-center u-gap-8 u-px-20 u-py-14 rounded-full fw-700 c-fs-15" style="box-shadow:0 6px 20px rgba(0,0,0,.18);">
            <span class="material-symbols-outlined c-fs-20">chat_bubble</span>
            상담하기
        </a>
    <?php elseif (!empty($cf_tel)): ?>
        <a href="tel:<?= preg_replace('/[^0-9]/', '', $cf_tel) ?>"
           class="u-bg-main u-txt-white d-flex align-items-center u-gap-8 u-px-20 u-py-14 rounded-full fw-700 c-fs-15" style="box-shadow:0 6px 20px rgba(0,0,0,.18);">
            <span class="material-symbols-outlined c-fs-20">call</span>
            전화상담
        </a>
    <?php endif; ?>
</div>

<script>
    (function() {
        var btn = document.getElementById('qmMinScrollTop');
        if (!btn) return;
        window.addEventListener('scroll', function() {
            if (window.scrollY > 200) {
                btn.style.opacity = '1';
                btn.style.visibility = 'visible';
            } else {
                btn.style.opacity = '0';
                btn.style.visibility = 'hidden';
            }
        });
        btn.addEventListener('click', function() {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    })();
</script>
