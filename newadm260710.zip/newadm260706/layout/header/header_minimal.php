<?php
/**
 * header_minimal.php — 미니멀 헤더 (로고 + 전화번호 + 심플 메뉴, 메가메뉴/프로모 슬라이더 없음)
 * nav 기본 폭 50vw, 그 안에서 li.flex-1로 항목들이 균등하게 퍼지고 각 a는 w-100 +
 * justify-content-center로 li 폭 전체에서 가운데 정렬된다. 호버/현재 페이지는
 * 배경색이 아니라 하단 보더로 표시.
 * 전제: 루트 head.php가 이 파일을 include하기 전에 $dm_conf, $cf_tel 등을
 *       head_sub.php를 통해 이미 채워둔 상태여야 한다.
 */

$nav_menus_min = [
    ['label' => '홈',         'href' => '/'],
    ['label' => '진료안내',   'href' => '/sub/info.php'],
    ['label' => '임상케이스', 'href' => '/case'],
    ['label' => '닥터 칼럼',  'href' => '/column'],
];

$current_path = strtok($_SERVER['REQUEST_URI'], '?');
?>

<header class="u-pretendard position-fixed u-bg-white z-header w-100" id="site-header">
    <div class="d-flex align-items-stretch justify-content-between u-px-24" style="height:68px; border-bottom:1px solid #eee;">
        <a href="/" class="d-flex align-items-center" style="align-self:center;">
            <?php if (!empty($dm_conf['cf_logo'])): ?>
                <img src="<?= G5_DATA_URL ?>/common/<?= $dm_conf['cf_logo'] ?>" alt="<?= htmlspecialchars($dm_conf['cf_site_name']) ?>" style="max-height:36px; display:block;">
            <?php else: ?>
                <span class="fw-700 c-fs-20 u-txt-dark"><?= htmlspecialchars($dm_conf['cf_site_name'] ?? '') ?></span>
            <?php endif; ?>
        </a>

        <!-- nav는 이 줄의 height:68px를 h-100으로 그대로 이어받아 li/a까지 끝까지 늘어나므로
             .minimal-link의 border-bottom이 헤더 맨 밑에 정확히 닿는다 -->
        <nav class="minimal-nav d-none d-lg-flex align-items-stretch h-100">
            <ul class="d-flex align-items-stretch h-100 w-100" style="list-style:none;margin:0;padding:0;">
                <?php foreach ($nav_menus_min as $menu): ?>
                    <li class="flex-1 d-flex h-100">
                        <a href="<?= htmlspecialchars($menu['href']) ?>"
                           class="minimal-link w-100 d-flex align-items-center justify-content-center c-fs-15 fw-500 u-txt-dark<?= $current_path === $menu['href'] ? ' is-active' : '' ?>">
                            <?= htmlspecialchars($menu['label']) ?>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        </nav>

        <div class="d-flex align-items-center u-gap-16" style="align-self:center;">
            <div class="d-none d-md-block">
                <?php
                $promo_id       = 'promoMinimal';
                $promo_width    = '200px';
                $promo_height   = '34px';
                $promo_bg       = 'var(--main-color, #333)';
                $promo_messages = [
                    '📞 ' . htmlspecialchars($cf_tel ?? '02-0000-0000'),
                    '💬 카톡 상담 환영',
                ];
                include __DIR__ . '/_promo_pill.php';
                ?>
            </div>
            <button class="u-bd-n u-bg-white d-flex d-lg-none align-items-center justify-content-center u-txt-dark"
                data-bs-toggle="offcanvas" data-bs-target="#mobileMenuHeader" style="width:36px;height:36px;">
                <span class="material-symbols-outlined c-fs-28">menu</span>
            </button>
        </div>
    </div>

    <!-- 모바일 Offcanvas -->
    <div class="offcanvas offcanvas-end u-bg-white" id="mobileMenuHeader">
        <div class="offcanvas-header justify-content-end u-py-24 u-px-20">
            <button type="button" class="u-bd-n d-flex align-items-center justify-content-center"
                style="width:32px;height:32px;" data-bs-dismiss="offcanvas">
                <span class="material-symbols-outlined c-fs-22">close</span>
            </button>
        </div>
        <div class="offcanvas-body u-p-0">
            <ul style="list-style:none;margin:0;padding:0;">
                <?php foreach ($nav_menus_min as $menu): ?>
                    <li>
                        <a href="<?= htmlspecialchars($menu['href']) ?>"
                           class="d-block u-px-24 u-py-16 c-fs-18 fw-500 u-txt-dark" style="border-bottom:1px solid #f0f0f0;">
                            <?= htmlspecialchars($menu['label']) ?>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</header>

<style>
    /* nav 기본 폭: 50vw (flyout과 동일 기준) */
    .minimal-nav { width:50vw; }

    /* 호버/현재 페이지: 배경색이 아니라 하단 보더로 표시. transparent도 두께를 항상
       차지해서 hover 시 높이가 밀리지 않는다 */
    .minimal-link {
        border-bottom:2px solid transparent;
        transition:border-color .15s, color .15s;
        box-sizing:border-box;
        text-decoration:none;
    }
    .minimal-link:hover,
    .minimal-link.is-active {
        border-color: var(--main-color, #333);
        color: var(--main-color, #333);
    }
</style>

<script>
    const header = document.getElementById('site-header');
    const updateMargin = () => {
        document.documentElement.style.setProperty('--header-height', `${header.offsetHeight}px`);
    };
    updateMargin();
    window.addEventListener('resize', updateMargin);
</script>