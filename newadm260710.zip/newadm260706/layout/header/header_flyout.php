<?php
/**
 * header_flyout.php — 플라이아웃 타입 (항목 바로 아래, 좁은 컬러 박스)
 * 상단 nav 항목에 마우스오버하면 해당 항목 바로 아래에 좁은 드롭다운이 뜨고,
 * mega와 동일하게 var(--main-color) 배경의 컬러 박스로 서브메뉴가 표시된다.
 * 상단 nav 자체는 호버 전/후로 크기(높이·폰트)가 그대로 유지되고, 아래 박스만 열렸다 닫힌다.
 * 우측엔 진료 예약용 긴 알약 CTA 버튼 1개.
 * (참고: 연세바로치과류 헤더)
 * 전제: $dm_conf, $cf_tel, $cf_naver_booking 등이 head_sub.php를 통해 채워진 상태에서 include됨.
 */

$nav_menus = [
    ['label' => '병원소개', 'href' => '/sub/about.php', 'children' => [
        ['label' => '병원 소개', 'href' => '/sub/about.php'],
        ['label' => '의료진 소개', 'href' => '/sub/doctor.php'],
        ['label' => '진료 안내/오시는길', 'href' => '/sub/location.php'],
    ]],
    ['label' => '임플란트', 'href' => '/sub/implant.php', 'children' => [
        ['label' => '임플란트', 'href' => '/sub/implant.php'],
    ]],
    ['label' => '사랑니 발치', 'href' => '/sub/wisdom.php', 'children' => [
        ['label' => '사랑니 발치', 'href' => '/sub/wisdom.php'],
        ['label' => '소수술', 'href' => '/sub/minor_surgery.php'],
    ]],
    ['label' => '일반진료', 'href' => '/sub/general.php', 'children' => [
        ['label' => '충치치료', 'href' => '/sub/cavity.php'],
        ['label' => '보철치료', 'href' => '/sub/prosthetic.php'],
        ['label' => '신경치료', 'href' => '/sub/nerve.php'],
        ['label' => '심미치료', 'href' => '/sub/esthetic.php'],
    ]],
    ['label' => '턱관절·외상', 'href' => '/sub/tmj.php', 'children' => [
        ['label' => '턱관절', 'href' => '/sub/tmj.php'],
        ['label' => '외상진료', 'href' => '/sub/trauma.php'],
    ]],
    ['label' => '온라인 상담', 'href' => '/sub/board/consult.php', 'children' => [
        ['label' => '온라인 상담', 'href' => '/sub/board/consult.php'],
        ['label' => '공지사항', 'href' => '/sub/board/notice.php'],
        ['label' => '비급여 안내', 'href' => '/sub/board/nonpayment.php'],
    ]],
    ['label' => '임상증례', 'href' => '/sub/case.php', 'children' => []],
];
$current_path = strtok($_SERVER['REQUEST_URI'], '?');
?>

<header class="u-pretendard position-fixed w-100 z-header" id="site-header" style="background:#fff; border-bottom:1px solid #eee;">
    <div class="d-flex align-items-center justify-content-between u-px-32" style="height:76px;">
        <a href="/" class="d-flex align-items-center u-gap-8" style="text-decoration:none;">
            <?php if (!empty($dm_conf['cf_logo'])): ?>
                <img src="<?= G5_DATA_URL ?>/common/<?= $dm_conf['cf_logo'] ?>" alt="<?= htmlspecialchars($dm_conf['cf_site_name']) ?>" style="max-height:34px; display:block;">
            <?php else: ?>
                <span class="fw-800 c-fs-18 u-txt-dark"><?= htmlspecialchars($dm_conf['cf_site_name'] ?? '') ?></span>
            <?php endif; ?>
        </a>

        <nav class="flyout-nav d-none d-xl-flex align-items-stretch h-100">
            <ul class="mega-gnb d-flex align-items-stretch justify-content-between h-100 w-100" style="list-style:none;margin:0;padding:0;">
                <?php foreach ($nav_menus as $i => $menu): ?>
                    <?php $children = array_filter($menu['children'] ?? [], fn($c) => !empty($c['label'])); ?>
                    <li class="mega-item h-100 d-flex align-items-center<?= $current_path === $menu['href'] ? ' is-active' : '' ?>">
                        <a href="<?= htmlspecialchars($menu['href']) ?>" class="mega-link c-fs-15 fw-600 u-txt-dark u-px-16">
                            <?= htmlspecialchars($menu['label']) ?>
                        </a>
                        <?php if ($children): ?>
                        <!-- 세로 플라이아웃: 헤더 전체 폭이 아니라 이 li(.mega-item) 바로 아래,
                             내용 폭만큼만 좁게 펼쳐진다. .mega-item에 position:relative를 준 게 핵심.
                             상단 nav(.mega-link)는 이 박스가 열리든 말든 크기가 절대 안 바뀐다 -->
                        <div class="mega-panel" aria-hidden="true">
                            <div class="mega-panel-inner">
                                <div class="mega-panel-grid">
                                    <?php foreach ($children as $child):
                                        $is_active_child = $current_path === ($child['href'] ?? null);
                                    ?>
                                        <a href="<?= htmlspecialchars($child['href'] ?? '#') ?>" class="mega-panel-link<?= $is_active_child ? ' is-active' : '' ?>"><?= htmlspecialchars($child['label']) ?></a>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </nav>

        <!-- 우측 긴 알약 배너 — 세로(아래→위) Swiper -->
        <div class="d-none d-xl-block">
            <?php
            $promo_id       = 'promoMega';
            $promo_width    = '280px';
            $promo_height   = '40px';
            $promo_bg       = 'var(--sub-color, #6b4a2f)';
            $promo_messages = [
                '📞 ' . htmlspecialchars($cf_tel ?? '02-0000-0000'),
                '🎗 신환 첫 상담 무료 이벤트',
                '🅿️ 건물 내 주차 공간 완비',
            ];
            include __DIR__ . '/_promo_pill.php';
            ?>
        </div>

        <button class="u-bd-n u-bg-white d-flex d-xl-none align-items-center justify-content-center" data-bs-toggle="offcanvas" data-bs-target="#mobileMenuHeader" style="width:36px;height:36px;">
            <span class="material-symbols-outlined c-fs-28">menu</span>
        </button>
    </div>

    <!-- 모바일 Offcanvas -->
    <div class="offcanvas offcanvas-end u-bg-white" id="mobileMenuHeader">
        <div class="offcanvas-header justify-content-end u-py-24 u-px-20">
            <button type="button" class="u-bd-n d-flex align-items-center justify-content-center" style="width:32px;height:32px;" data-bs-dismiss="offcanvas">
                <span class="material-symbols-outlined c-fs-22">close</span>
            </button>
        </div>
        <div class="offcanvas-body u-p-0">
            <ul style="list-style:none;margin:0;padding:0;">
                <?php foreach ($nav_menus as $menu): ?>
                    <li><a href="<?= htmlspecialchars($menu['href']) ?>" class="d-block u-px-24 u-py-16 c-fs-17 fw-600 u-txt-dark" style="border-bottom:1px solid #f0f0f0;"><?= htmlspecialchars($menu['label']) ?></a></li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</header>

<style>
    #site-header { top: 0; position: fixed; }
    body { padding-top: 76px; }

    /* nav 기본 폭: 50vw, 그 안에서 항목들이 justify-content-between으로 양끝까지 퍼짐 */
    .flyout-nav { width:50vw; }

    /* ── 상단 nav: 호버 전/후 크기가 절대 안 바뀐다 (높이 100%·고정 폰트, transform/scale 없음).
       보더로 표시하던 걸 배경색+글자색 전환으로 교체 ── */
    .mega-item .mega-link {
        display:flex; align-items:center; height:100%; text-decoration:none;
        color: var(--dark, #1a1a2e);
        transition: background-color .15s, color .15s;
        box-sizing:border-box;
        width: 100%;
        justify-content: center;
    }
    .mega-item:hover .mega-link, .mega-item.is-active .mega-link {
        background: var(--main-color, #6b4a2f);
        color:#fff;
    }

    /* 이 li 자체를 기준점으로 삼아야 패널이 헤더 전체가 아니라 항목 바로 아래에 좁게 뜬다 */
    .mega-item { position: relative; flex: 1;}

    /* ── 서브메뉴 박스: mega와 동일하게 var(--main-color) 배경의 컬러 박스. 항목 바로 아래보다
       조금 더 내려서(margin-top) 여백을 준다 ── */
    .mega-panel {
        position:absolute; top:100%; left:50%; margin-top:10px;
        width:max-content; min-width:150px;
        background: var(--main-color, #16215c);
        border-radius:12px;
        box-shadow:0 14px 30px rgba(0,0,0,.2);
        opacity:0; visibility:hidden; pointer-events:none;
        transform: translateX(-50%) translateY(-8px);
        transition: opacity .18s ease, transform .18s ease, visibility .18s;
        z-index: 20;
    }
    /* 순수 :hover는 대각선으로 움직이다 살짝만 벗어나도 바로 닫혀버려서
       is-open 클래스(JS가 mouseenter/mouseleave+지연타이머로 토글)로 바꿈. */
    .mega-item.is-open .mega-panel { opacity:1; visibility:visible; pointer-events:auto; transform:translateX(-50%) translateY(0); }

    .mega-panel-inner { padding:14px 10px; }
    .mega-panel-grid { display:flex; flex-direction:column; gap:6px; }
    .mega-panel-grid a {
        display:block; text-align:center; padding:10px 22px; border-radius:8px;
        color:#fff; text-decoration:none; font-size:14.5px; font-weight:600; opacity:.9;
        white-space:nowrap;
    }
    .mega-panel-grid a:hover { opacity:1; background:rgba(255,255,255,.1); }
    .mega-panel-grid a.is-active { background:#fff; color:var(--main-color, #16215c); opacity:1; font-weight:700; }
</style>

<script>
    new Swiper('.megaPromoSwiper', {
        direction: 'vertical', slidesPerView: 1, loop: true,
        autoplay: { delay: 2400, disableOnInteraction: false }, speed: 600,
    });
</script>

<script>
    (function() {
        const items = document.querySelectorAll('.mega-item');
        let closeTimer = null;

        function open(item) {
            clearTimeout(closeTimer);
            if (!item.querySelector('.mega-panel')) return;
            items.forEach(el => el.classList.remove('is-open'));
            item.classList.add('is-open');
        }
        function close() {
            closeTimer = setTimeout(() => {
                items.forEach(el => el.classList.remove('is-open'));
            }, 150);
        }

        items.forEach(item => {
            const panel = item.querySelector('.mega-panel');
            if (!panel) return;
            item.addEventListener('mouseenter', () => open(item));
            item.addEventListener('mouseleave', close);
            panel.addEventListener('mouseenter', () => clearTimeout(closeTimer));
            panel.addEventListener('mouseleave', close);
        });
    })();
</script>