<?php
/**
 * _promo_pill.php — 헤더 우측 회전 알약 배너 (Swiper 세로 방향, 한 번에 하나씩 아래→위로 넘어감)
 * 모든 header_*.php가 공통으로 쓰는 조각.
 *
 * 사용법: include하기 전에 아래 변수를 원하는 값으로 채워두면 된다 (안 채우면 기본값 사용).
 *   $promo_id       — 페이지에 헤더 스와이퍼가 여러 개 겹칠 일은 없지만, 혹시 몰라 고유 클래스명 지정용
 *   $promo_messages — 회전시킬 메시지 배열 (HTML 허용, 각자 이스케이프해서 넣을 것)
 *   $promo_width, $promo_height, $promo_bg — 알약 크기/배경색
 */
$promo_id       = $promo_id ?? ('promoPill' . substr(md5(uniqid()), 0, 6));
$promo_messages = $promo_messages ?? [
    '📞 ' . htmlspecialchars($cf_tel ?? '02-0000-0000'),
];
$promo_width  = $promo_width  ?? '260px';
$promo_height = $promo_height ?? '38px';
$promo_bg     = $promo_bg     ?? 'var(--sub-color, #333)';
?>
<div class="promo-pill-wrap" style="width:<?= htmlspecialchars($promo_width) ?>; height:<?= htmlspecialchars($promo_height) ?>; border-radius:999px; overflow:hidden; background:<?= htmlspecialchars($promo_bg) ?>; flex-shrink:0;">
    <div class="swiper <?= htmlspecialchars($promo_id) ?> h-100">
        <div class="swiper-wrapper">
            <?php foreach ($promo_messages as $__promo_msg): ?>
                <div class="swiper-slide d-flex align-items-center justify-content-center u-txt-white c-fs-13 fw-700" style="gap:6px;"><?= $__promo_msg ?></div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<script>
    new Swiper('.<?= htmlspecialchars($promo_id) ?>', {
        direction: 'vertical',
        slidesPerView: 1,
        loop: true,
        allowTouchMove: false,
        speed: 600,
        autoplay: { delay: 2200, disableOnInteraction: false },
        observer: true,
        observeParents: true,
    });
</script>
