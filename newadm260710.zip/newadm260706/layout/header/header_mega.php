<?php
/**
 * header_mega.php — 메가메뉴 타입
 *
 * 구조 원칙: nav(gnb)와 메가패널 컬럼은 로고/프로모 배너 폭이 얼마든 상관없이
 * 항상 헤더 정중앙에 와야 한다. 그래서 둘 다 flex 흐름(1fr 배분)에 끼워 넣지 않고
 * position:absolute; left:50%; transform:translateX(-50%)로 뽑아내서 독립적으로 중앙 고정한다.
 * 폭은 --mega-nav-w 변수 하나를 nav/패널 컬럼이 같이 참조하므로 항상 같은 폭·같은 중심점 →
 * 로고나 배너를 나중에 아무리 늘리거나 줄여도 정렬이 절대 깨지지 않는다.
 * (이전 버전의 "로고 폭 placeholder 복제" / "padding-right로 배너 자리 비우기"는
 *  전부 로고·배너 폭에 종속되는 임시방편이라 폐기하고 이 방식으로 교체함)
 * 전제: $dm_conf, $cf_tel 등이 head_sub.php를 통해 이미 채워진 상태에서 include됨.
 */


$nav_menus = [
    ['label' => '병원소개', 'href' => '/sub/about.php', 'children' => [
        ['label' => '병원 소개', 'href' => '/sub/about.php'],
        ['label' => '의료진 소개', 'href' => '/sub/doctor.php'],
        ['label' => '진료 안내/오시는길', 'href' => '/sub/location.php'],
    ]],
    ['label' => '임플란트', 'href' => '/sub/implant.php', 'children' => [
        ['label' => '임플란트', 'href' => '/sub/implant.php'],
    ]],
    ['label' => '사랑니 발치', 'href' => '/sub/wisdom.php', 'children' => [
        ['label' => '사랑니 발치', 'href' => '/sub/wisdom.php'],
        ['label' => '소수술', 'href' => '/sub/minor_surgery.php'],
    ]],
    ['label' => '일반진료', 'href' => '/sub/general.php', 'children' => [
        ['label' => '충치치료', 'href' => '/sub/cavity.php'],
        ['label' => '보철치료', 'href' => '/sub/prosthetic.php'],
        ['label' => '신경치료', 'href' => '/sub/nerve.php'],
        ['label' => '심미치료', 'href' => '/sub/esthetic.php'],
    ]],
    ['label' => '턱관절·외상', 'href' => '/sub/tmj.php', 'children' => [
        ['label' => '턱관절', 'href' => '/sub/tmj.php'],
        ['label' => '외상진료', 'href' => '/sub/trauma.php'],
    ]],
    ['label' => '온라인 상담', 'href' => '/sub/board/consult.php', 'children' => [
        ['label' => '온라인 상담', 'href' => '/sub/board/consult.php'],
        ['label' => '공지사항', 'href' => '/sub/board/notice.php'],
        ['label' => '비급여 안내', 'href' => '/sub/board/nonpayment.php'],
    ]],
    ['label' => '임상증례', 'href' => '/sub/case.php', 'children' => []],
];
$current_path = strtok($_SERVER['REQUEST_URI'], '?');
?>

<header class="u-pretendard position-fixed w-100 z-header u-bg-white" id="site-header">
    <div class="hd-bar d-flex align-items-center justify-content-between position-relative u-bg-white u-px-32">
        <!-- 로고: flex 흐름에 남아 좌측에 고정. 폭이 얼마든 가운데 nav엔 영향 없음 -->
        <div class="hd-side d-flex align-items-center u-gap-20">
            <a href="/" style="text-decoration:none;">
                <?php if (!empty($dm_conf['cf_logo'])): ?>
                    <img src="<?= G5_DATA_URL ?>/common/<?= $dm_conf['cf_logo'] ?>" alt="<?= htmlspecialchars($dm_conf['cf_site_name']) ?>" style="max-height:30px; display:block;">
                <?php else: ?>
                    <span class="fw-800 c-fs-18 u-txt-dark"><?= htmlspecialchars($dm_conf['cf_site_name'] ?? '') ?></span>
                <?php endif; ?>
            </a>
        </div>

        <!-- nav: flex 흐름에서 완전히 빠져서 hd-bar 정중앙에 절대 고정 -->
        <nav class="hd-nav" id="megaNav">
            <ul class="gnb d-flex align-items-stretch h-100" style="list-style:none;margin:0;padding:0;">
                <?php foreach ($nav_menus as $i => $menu): ?>
                    <li class="gnb-item<?= $current_path === $menu['href'] ? ' is-page-active' : '' ?>" data-idx="<?= $i ?>">
                        <a href="<?= htmlspecialchars($menu['href']) ?>" class="gnb-link c-fs-16 fw-500 u-ls-10"><?= htmlspecialchars($menu['label']) ?></a>
                    </li>
                <?php endforeach; ?>
            </ul>
        </nav>

        <!-- 우측: 알약 배너 + 모바일 버튼. flex 흐름에 남아 우측 고정. 폭이 얼마든 가운데 nav엔 영향 없음 -->
        <div class="d-flex align-items-center u-gap-16">
            <div class="hd-promo d-none d-xl-flex align-items-center justify-content-center">
                <?php
                $promo_id       = 'promoMega';
                $promo_width    = '260px';
                $promo_height   = '36px';
                $promo_bg       = 'var(--sub-color, #6b4a2f)';
                $promo_messages = [
                    '📞 ' . htmlspecialchars($cf_tel ?? '02-0000-0000'),
                    '🎗 신환 첫 상담 무료 이벤트',
                    '🅿️ 건물 내 주차 공간 완비',
                ];
                include __DIR__ . '/_promo_pill.php';
                ?>
            </div>

            <button class="u-bd-n u-bg-transparent d-flex d-xl-none align-items-center justify-content-center u-txt-dark" data-bs-toggle="offcanvas" data-bs-target="#mobileMenuHeader" style="width:36px;height:36px;">
                <span class="material-symbols-outlined c-fs-28">menu</span>
            </button>
        </div>
    </div>

    <!-- 공용 메가패널: 헤더 폭 100%, nav 줄 바로 아래. 컬럼(mega-inner)도 hd-nav와 같은
         --mega-nav-w / 중앙고정 방식이라 로고·배너 폭과 무관하게 nav 바로 아래에 정확히 겹친다 -->
    <div class="mega-menu position-absolute w-100 u-bg-white" id="megaMenu">
        <div class="mega-inner">
            <?php foreach ($nav_menus as $i => $menu):
                $children = array_filter($menu['children'] ?? [], fn($c) => !empty($c['label']));
            ?>
            <div class="mega-col" data-idx="<?= $i ?>">
                <?php foreach ($children as $child):
                    $is_active_child = $current_path === ($child['href'] ?? null);
                ?>
                <a href="<?= htmlspecialchars($child['href'] ?? '#') ?>" class="mega-sub-link<?= $is_active_child ? ' is-active' : '' ?>"><?= htmlspecialchars($child['label']) ?></a>
                <?php endforeach; ?>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- 모바일 Offcanvas -->
    <div class="offcanvas offcanvas-end u-bg-white" id="mobileMenuHeader">
        <div class="offcanvas-header justify-content-end u-py-24 u-px-20">
            <button type="button" class="u-bd-n d-flex align-items-center justify-content-center" style="width:32px;height:32px;" data-bs-dismiss="offcanvas">
                <span class="material-symbols-outlined c-fs-22">close</span>
            </button>
        </div>
        <div class="offcanvas-body u-p-0">
            <ul style="list-style:none;margin:0;padding:0;">
                <?php foreach ($nav_menus as $menu): ?>
                    <li><a href="<?= htmlspecialchars($menu['href']) ?>" class="d-block u-px-24 u-py-16 c-fs-17 fw-600 u-txt-dark" style="border-bottom:1px solid #f0f0f0;"><?= htmlspecialchars($menu['label']) ?></a></li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</header>

<style>
    :root { --mega-nav-w: 900px; } /* nav와 메가패널 컬럼이 공유하는 평소 폭 */
    /* 호버로 메가메뉴가 열리면(is-mega-open) nav/패널이 공유하는 폭 자체를 넓힘.
       hd-nav, mega-inner 둘 다 이 변수 하나만 보고 있어서 같이, 같은 폭으로 넓어진다 */
    #site-header.is-mega-open { --mega-nav-w: 70vw; }

    body { padding-top: 72px; }
    .hd-bar { height:72px; }

    /* ── nav: 흐름에서 빠져서 hd-bar 정중앙에 절대 고정. 로고/배너 폭과 완전히 무관 ── */
    .hd-nav {
        position:absolute; left:50%; top:0; height:100%;
        width:var(--mega-nav-w); max-width:calc(100% - 40px);
        transform:translateX(-50%);
        transition: width .25s ease;
    }
    .gnb { width:100%; height:100%; display:flex; align-items:stretch; justify-content:center; }
    .gnb-item { flex:1 1 0; display:flex; }
    .gnb-link {
        flex:1 1 0; display:flex; align-items:center; justify-content:center;
        text-decoration:none; white-space:nowrap; color:var(--dark, #2c2c2c);
        transition: background .25s, color .25s; padding:0 12px;
    }
    .gnb-item.is-hover .gnb-link,
    .gnb-item.is-page-active .gnb-link {
        background: var(--main-color); color:#fff; font-weight:700;
    }

    .hd-promo { width:260px; flex-shrink:0; }

    /* ── 메가패널: nav 줄 바로 아래, 헤더 폭 100% ── */
    .mega-menu {
        top:72px; left:0; z-index:999;
        box-shadow:0 8px 24px rgba(0,0,0,.1);
        border-top:1px solid var(--gray-200, #eee);
        opacity:0; visibility:hidden; transform:translateY(-6px); pointer-events:none;
        transition: opacity .2s, transform .2s, visibility .2s;
    }
    .mega-menu.is-open { opacity:1; visibility:visible; transform:translateY(0); pointer-events:auto; }

    /* mega-inner: hd-nav와 똑같은 폭·똑같은 중앙고정 계산식 → 위아래가 항상 정확히 겹침 */
    .mega-inner {
        position:relative; left:50%;
        width:var(--mega-nav-w); max-width:calc(100% - 40px);
        transform:translateX(-50%);
        transition: width .25s ease;
        display:flex;
    }
    .mega-col {
        flex:1 1 0; min-width:0; padding:28px 0;
        border-right:1px solid var(--gray-100, #f5f5f5);
        transition: background .2s; text-align:center;
    }
    .mega-col:last-child { border-right:none; }
    .mega-col.is-active { background: var(--main-color); }

    .mega-sub-link {
        display:block; padding:10px 24px; font-size:15px; font-weight:400;
        color:var(--gray-700, #707070); letter-spacing:var(--ls-10, .1em);
        white-space:nowrap; text-decoration:none; transition:color .15s;
    }
    .mega-sub-link:hover { color: var(--sub-color, #6b4a2f); font-weight:600; }
    .mega-col.is-active .mega-sub-link { color:rgba(255,255,255,.7); }
    .mega-col.is-active .mega-sub-link:hover,
    .mega-col.is-active .mega-sub-link.is-active { color:#fff; font-weight:700; }
</style>

<script>
    (function() {
        const header   = document.getElementById('site-header');
        const nav      = document.getElementById('megaNav');
        const menu     = document.getElementById('megaMenu');
        const items    = nav.querySelectorAll('.gnb-item');
        const cols     = menu.querySelectorAll('.mega-col');
        let closeTimer = null;

        function openAt(idx) {
            clearTimeout(closeTimer);
            header.classList.add('is-mega-open');
            menu.classList.add('is-open');
            items.forEach(li => li.classList.toggle('is-hover', li.dataset.idx === idx));
            cols.forEach(col => col.classList.toggle('is-active', col.dataset.idx === idx));
        }
        function scheduleClose() {
            closeTimer = setTimeout(() => {
                header.classList.remove('is-mega-open');
                menu.classList.remove('is-open');
                items.forEach(li => li.classList.remove('is-hover'));
                cols.forEach(col => col.classList.remove('is-active'));
            }, 150);
        }

        items.forEach(li => li.addEventListener('mouseenter', () => openAt(li.dataset.idx)));
        nav.addEventListener('mouseleave', scheduleClose);
        menu.addEventListener('mouseenter', () => clearTimeout(closeTimer));
        menu.addEventListener('mouseleave', scheduleClose);
    })();
</script>