<?php
/**
 * header_bestplant.php — bestplantdental.com 실제 헤더를 Claude in Chrome으로 열어
 * DOM/CSS를 직접 추출해서 그대로 재현함. 이전 header_swiper.php(실제로는
 * header_old.php로 저장됨)는 마크업만 있고 실제 사이트의 CSS(.hd-bar/.gnb/.gnb-submenu 등)가
 * 없어서 색/배치가 다 깨져 있었음 — 이번엔 실사이트에서 뽑은 값 그대로 <style>에 포함시켰다.
 *
 * 실사이트 확인 내용:
 * - 상단 gnb 항목 호버/현재페이지: 배경 없이 글자색만 var(--point)(#FF7E4D, 오렌지)로 바뀜.
 * - 서브메뉴(.gnb-submenu): 항목 바로 아래 center 정렬로 뜨는 좁은 오렌지(var(--point)) 박스,
 *   라운드 10px, 내부 패딩 8px. 링크는 흰 글자, hover 시 옅은 회색(--gray-100) 배경 + 오렌지 글자.
 * - 로고 영역(.hd-side)은 28vw 고정폭(호버로 줄어드는 애니메이션은 이 사이트엔 없음).
 * 전제: $dm_conf, $cf_tel 등이 head_sub.php를 통해 이미 채워진 상태에서 include됨.
 */

$nav_menus = [
    ['label' => '베스트플란트치과', 'href' => '/', 'children' => []],
    ['label' => '임플란트', 'href' => '/sub/implant/implant_highLevel.php', 'children' => [
        ['label' => '베스트플란트 임플란트', 'href' => '/sub/implant/implant_highLevel.php'],
        ['label' => '앞니 임플란트', 'href' => '/sub/implant/implant_FT.php'],
        ['label' => '상악동 거상술 & 뼈이식 임플란트', 'href' => '/sub/implant/implant_SL_BA.php'],
        ['label' => '임플란트 재수술', 'href' => '/sub/implant/implant_retreatment.php'],
        ['label' => '전체 임플란트', 'href' => '/sub/implant/implant_FA.php'],
    ]],
    ['label' => '충치치료', 'href' => '/sub/inlay.php', 'children' => []],
    ['label' => 'EMS 스케일링', 'href' => '/sub/ems_scale.php', 'children' => []],
    ['label' => '퍼스널 미백', 'href' => '/sub/whitening.php', 'children' => []],
    ['label' => '통증 경감 시스템', 'href' => '/sub/painless_system.php', 'children' => []],
    ['label' => '임상케이스', 'href' => '/sub/board/case_list.php', 'children' => []],
    ['label' => '닥터 칼럼', 'href' => '/sub/column_list.php', 'children' => []],
];

$current_path = strtok($_SERVER['REQUEST_URI'], '?');
?>

<header class="u-pretendard position-fixed u-bg-white z-header w-100" id="site-header">

    <!-- ── PC 헤더 ── -->
    <div class="d-none d-xxl-flex w-100">

        <!-- 헤더 바 -->
        <div class="hd-bar d-flex align-items-stretch position-relative z-two u-bg-white w-100">

            <!-- 로고: 좌측 고정 공백 -->
            <div class="hd-side d-flex align-items-center u-px-32">
                <a href="/">
                    <?php if (!empty($dm_conf['cf_logo'])): ?>
                        <img src="<?= G5_DATA_URL ?>/common/<?= $dm_conf['cf_logo'] ?>" alt="<?= htmlspecialchars($dm_conf['cf_site_name']) ?>" style="max-height:40px; display:block;">
                    <?php else: ?>
                        <!-- 로고 삽입 위치 -->
                    <?php endif; ?>
                </a>
            </div>

            <!-- GNB: flex:1 채움 -->
            <nav class="hd-nav d-flex align-items-center justify-content-center u-bc-gray-200">
                <ul class="gnb d-flex align-items-stretch">
                    <?php foreach ($nav_menus as $i => $menu): ?>
                        <?php
                        $children = array_filter($menu['children'] ?? [], fn($c) => !empty($c['label']));
                        $has_children = !empty($children);
                        ?>
                        <li class="gnb-item flex-1 position-relative<?= $current_path === $menu['href'] ? ' is-page-active' : '' ?>"
                            data-index="<?= $i ?>">
                            <a href="<?= htmlspecialchars($menu['href']) ?>"
                                class="gnb-link c-fs-16 fw-500 u-ls-10">
                                <?= htmlspecialchars($menu['label']) ?>
                            </a>
                            <?php if ($has_children): ?>
                            <div class="gnb-submenu" aria-hidden="true">
                                <?php foreach ($children as $child): ?>
                                    <a href="<?= htmlspecialchars($child['href']) ?>"
                                        class="gnb-submenu-link<?= $current_path === $child['href'] ? ' is-active' : '' ?>">
                                        <?= htmlspecialchars($child['label']) ?>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </nav>

            <!-- 슬라이더 -->
            <div class="hd-side d-flex align-items-center justify-content-end u-px-32 u-bc-gray-200">
                <div class="promo-slider">
                    <div class="swiper promo-swiper">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide promo-item">
                                <img src="/images/call.svg" alt="" />
                                <span class="u-txt-white fw-bold"><a href="tel:<?= htmlspecialchars($cf_tel) ?>" class="u-txt-white fw-bold"><?= htmlspecialchars($cf_tel) ?></a></span>
                            </div>
                            <div class="swiper-slide promo-item">
                                <img src="/images/dk.svg" alt="" /> 단국대학교 치과병원
                                <span class="u-txt-white fw-bold">외래교수</span>
                            </div>
                            <div class="swiper-slide promo-item">
                                <img src="/images/medal_1.svg" alt="" />
                                <span class="u-txt-white fw-bold"> 대표원장 책임진료</span>
                            </div>
                            <div class="swiper-slide promo-item">
                                <img src="/images/imp.svg" alt="" />
                                <span class="u-txt-white fw-bold"> 편안한 무주수 임플란트</span>
                            </div>
                            <div class="swiper-slide promo-item">
                                <img src="/images/heart.svg" alt="" /> 치과 공포증
                                <span class="u-txt-white fw-bold"> 통증 경감 시스템</span>
                            </div>
                            <div class="swiper-slide promo-item">
                                <img class="u-mr-4" src="/images/park.svg" alt="" />
                                <span class="u-txt-white fw-bold"> <a href="/#location" class="u-txt-white fw-bold">건물 내 넓은 주차 공간</a></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- 오버레이 -->
        <!-- <div class="header-overlay" id="headerOverlay"></div> -->
    </div>

    <!-- ── 모바일 헤더 ── -->
    <div class="d-flex d-xxl-none justify-content-between u-bg-white align-items-center u-p-20">
        <a href="<?= G5_URL ?>">
            <?php if (!empty($dm_conf['cf_logo'])): ?>
                <img src="<?= G5_DATA_URL ?>/common/<?= $dm_conf['cf_logo'] ?>" alt="<?= htmlspecialchars($dm_conf['cf_site_name']) ?>" style="max-height:40px; display:block;">
            <?php endif; ?>
        </a>
        <button class="u-bd-n u-bg-white d-flex align-items-center justify-content-center u-txt-dark"
            data-bs-toggle="offcanvas" data-bs-target="#mobileMenuHeader" style="width:36px;height:36px;">
            <span class="material-symbols-outlined c-fs-28">menu</span>
        </button>
    </div>

    <!-- 모바일 Offcanvas -->
    <div class="offcanvas offcanvas-end u-bg-main" id="mobileMenuHeader">
        <div class="offcanvas-header justify-content-end u-py-24 u-px-20">
            <button type="button" class="u-bg-sub u-bd-n d-flex align-items-center justify-content-center"
                style="width:32px;height:32px;" data-bs-dismiss="offcanvas">
                <span class="material-symbols-outlined u-txt-white c-fs-22">close</span>
            </button>
        </div>
        <div class="offcanvas-body u-p-0">
            <ul style="list-style:none;margin:0;padding:0;">
                <?php foreach ($nav_menus as $idx => $menu): ?>
                    <?php $has_children = !empty(array_filter($menu['children'] ?? [], fn($c) => isset($c['label']))); ?>
                    <li>
                        <a href="<?= htmlspecialchars($menu['href']) ?>"
                            class="d-flex justify-content-between align-items-center u-px-30 u-py-14 t-fs-20 fw-400 u-ls-10 u-txt-white"
                            <?= $has_children ? 'data-bs-toggle="collapse" data-bs-target="#mob-sub-' . $idx . '"' : '' ?>>
                            <span><?= htmlspecialchars($menu['label']) ?></span>
                            <?php if ($has_children): ?>
                                <i class="bi bi-chevron-down c-fs-14"></i>
                            <?php endif; ?>
                        </a>
                        <?php if ($has_children): ?>
                            <ul class="collapse" id="mob-sub-<?= $idx ?>"
                                style="list-style:none;margin:0;padding:0;background:var(--sub-color);">
                                <?php foreach ($menu['children'] as $child): ?>
                                    <?php if (!isset($child['label'])) continue; ?>
                                    <li>
                                        <a href="<?= htmlspecialchars($child['href']) ?>"
                                            class="d-flex align-items-center u-px-30 u-py-10 c-fs-18 u-ls-10 u-txt-gray-300">
                                            <?= htmlspecialchars($child['label']) ?>
                                        </a>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>

</header>

<style>
    :root {
        --point: #FF7E4D;
        --gray-200: #e9e9e9;
        --gray-100: #f8f8f8;
        --sub-color: #2B6CD0;
        --main-color: #012D70;
    }

    body { padding-top: 72px; }
    .hd-bar { height:72px; overflow:visible; }
    .hd-side { width:28vw; flex-shrink:0; overflow:hidden; }
    .hd-nav { flex:1 1 0; min-width:0; overflow:visible; }

    .gnb { list-style:none; margin:0; padding:0; width:100%; height:100%; display:flex; align-items:stretch; justify-content:center; }
    .gnb-item { flex:1 1 0; display:flex; position:relative; }
    .gnb-link {
        flex:1 1 0; display:flex; align-items:center; justify-content:center;
        text-decoration:none; white-space:nowrap; color:var(--dark, #2c2c2c);
        transition: background .25s, color .25s; padding:0 12px;
    }
    .gnb-link:hover { background:#fff; color: var(--point); }
    .gnb-item.is-hover .gnb-link,
    .gnb-item.is-page-active .gnb-link { background:#fff; color: var(--point); font-weight:700; }

    /* 서브메뉴: 항목 바로 아래 중앙 정렬로 뜨는 좁은 오렌지 박스 */
    .gnb-submenu {
        position:absolute; top:100%; left:50%; transform:translateX(-50%) translateY(6px);
        min-width:220px; z-index:1000;
        opacity:0; visibility:hidden; pointer-events:none;
        transition: opacity .2s, transform .2s, visibility .2s;
        border:1px solid var(--gray-200);
        padding:8px;
        background: var(--point);
        border-radius:10px;
    }
    .gnb-item.is-open .gnb-submenu { opacity:1; visibility:visible; transform:translateX(-50%) translateY(0); pointer-events:auto; }

    .gnb-submenu-link {
        display:block; text-decoration:none; transition:color .15s, background .15s;
        white-space:nowrap; text-align:center; color:#fff; border-radius:4px;
        padding:9px 21px; font-size:14px;
    }
    .gnb-submenu-link:hover { background: #fff; font-weight:600; color: var(--point) !important; }
    .gnb-submenu-link.is-active { font-weight:700; }

    /* ===== 우측 알약 Swiper ===== */
    .promo-slider {
        width: max-content;
        height: 2.5vw;
        background: var(--sub-color);
        border-radius: 999px;
        overflow: hidden;
    }
    .promo-swiper { height:100%; overflow:hidden; }
    .promo-swiper .swiper-wrapper { height:100%; }
    .promo-swiper .swiper-slide {
        height: 2.5vw;
        padding: 0 1.0417vw;
        display:flex; align-items:center; justify-content:center;
        color:#fff; background-color: var(--sub-color);
        box-sizing:border-box; gap:8px;
    }
    @media (max-width: 992px) {
        .promo-slider, .promo-swiper .swiper-slide { height:36px; }
    }
</style>

<script>
    new Swiper('.promo-swiper', {
        direction: 'vertical',
        slidesPerView: 1,
        loop: true,
        allowTouchMove: false,
        speed: 600,
        autoplay: { delay: 2000, disableOnInteraction: false },
        observer: true,
        observeParents: true,
    });
</script>

<script>
    window.addEventListener('scroll', function() {
        var bar = document.querySelector('.hd-bar');
        if (!bar) return;
        if (window.scrollY > 0) {
            bar.classList.remove('u-bg-transparent');
            bar.classList.add('u-bg-main');
        } else {
            bar.classList.remove('u-bg-main');
            bar.classList.add('u-bg-transparent');
        }
    });
</script>
<script>
    (function() {
        const gnbItems = document.querySelectorAll('.gnb-item');
        let closeTimer = null;

        function openSubmenu(item) {
            clearTimeout(closeTimer);
            const submenu = item.querySelector('.gnb-submenu');
            if (!submenu) return;

            gnbItems.forEach(el => {
                el.classList.remove('is-open', 'is-hover');
                el.querySelector('.gnb-submenu')?.setAttribute('aria-hidden', 'true');
            });

            item.classList.add('is-open', 'is-hover');
            submenu.setAttribute('aria-hidden', 'false');
        }

        function closeSubmenu() {
            closeTimer = setTimeout(() => {
                gnbItems.forEach(el => {
                    el.classList.remove('is-open', 'is-hover');
                    el.querySelector('.gnb-submenu')?.setAttribute('aria-hidden', 'true');
                });
            }, 120);
        }

        gnbItems.forEach(item => {
            const submenu = item.querySelector('.gnb-submenu');
            if (!submenu) return;

            item.addEventListener('mouseenter', () => openSubmenu(item));
            item.addEventListener('mouseleave', closeSubmenu);
            submenu.addEventListener('mouseenter', () => clearTimeout(closeTimer));
            submenu.addEventListener('mouseleave', closeSubmenu);
        });
    })();
</script>
<script>
    const header = document.getElementById('site-header');

    const updateMargin = () => {
        const height = header.offsetHeight;
        document.documentElement.style.setProperty('--header-height', `${height}px`);
    };

    updateMargin();
    window.addEventListener('resize', updateMargin);
</script>