<?php
/**
 * header_single.php — 싱글 타입 (드롭다운 없는 완전한 한 줄 헤더)
 * 로고 + 평평한 메뉴(하위메뉴 없음) + CTA 버튼 1개로 끝나는 가장 단순한 형태.
 * (참고: 오름플란트치과류 헤더)
 * 전제: $dm_conf, $cf_tel 등이 head_sub.php를 통해 채워진 상태에서 include됨.
 */

$nav_menus = [
    ['label' => '병원소개', 'href' => '/sub/about.php'],
    ['label' => '진료안내', 'href' => '/sub/info.php'],
    ['label' => '임상케이스', 'href' => '/case'],
    ['label' => '이벤트', 'href' => '/sub/event.php'],
    ['label' => '오시는길', 'href' => '/sub/location.php'],
];
$current_path = strtok($_SERVER['REQUEST_URI'], '?');
?>

<header class="u-pretendard position-fixed w-100 z-header" id="site-header" style="background:#fff; border-bottom:1px solid #eee;">
    <div class="d-flex align-items-center justify-content-between u-px-32" style="height:64px;">
        <a href="/" class="d-flex align-items-center u-gap-8" style="text-decoration:none;">
            <?php if (!empty($dm_conf['cf_logo'])): ?>
                <img src="<?= G5_DATA_URL ?>/common/<?= $dm_conf['cf_logo'] ?>" alt="<?= htmlspecialchars($dm_conf['cf_site_name']) ?>" style="max-height:28px; display:block;">
            <?php else: ?>
                <span class="fw-800 c-fs-16 u-txt-dark"><?= htmlspecialchars($dm_conf['cf_site_name'] ?? '') ?></span>
            <?php endif; ?>
        </a>

        <nav class="d-none d-md-flex align-items-center u-gap-28">
            <?php foreach ($nav_menus as $menu): ?>
                <a href="<?= htmlspecialchars($menu['href']) ?>"
                   class="c-fs-14.5 fw-600 u-txt-dark<?= $current_path === $menu['href'] ? ' u-txt-main' : '' ?>" style="text-decoration:none;">
                    <?= htmlspecialchars($menu['label']) ?>
                </a>
            <?php endforeach; ?>
        </nav>

        <div class="d-flex align-items-center u-gap-10">
            <div class="d-none d-lg-block">
                <?php
                $promo_id       = 'promoSingle';
                $promo_width    = '190px';
                $promo_height   = '32px';
                $promo_bg       = 'var(--sub-color, #555)';
                $promo_messages = [
                    '📞 ' . htmlspecialchars($cf_tel ?? '02-0000-0000'),
                    '🎉 이달의 이벤트 진행중',
                ];
                include __DIR__ . '/_promo_pill.php';
                ?>
            </div>
            <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#inquiryModal"
               class="d-flex align-items-center u-gap-6 u-txt-white fw-700 c-fs-13.5" style="background:var(--main-color,#2f7a5f); padding:9px 18px; border-radius:8px; text-decoration:none;">
                빠른상담
            </a>
            <button class="u-bd-n u-bg-white d-flex d-md-none align-items-center justify-content-center" data-bs-toggle="offcanvas" data-bs-target="#mobileMenuHeader" style="width:32px;height:32px;">
                <span class="material-symbols-outlined c-fs-24">menu</span>
            </button>
        </div>
    </div>

    <div class="offcanvas offcanvas-end u-bg-white" id="mobileMenuHeader">
        <div class="offcanvas-header justify-content-end u-py-20 u-px-20">
            <button type="button" class="u-bd-n d-flex align-items-center justify-content-center" style="width:30px;height:30px;" data-bs-dismiss="offcanvas">
                <span class="material-symbols-outlined c-fs-20">close</span>
            </button>
        </div>
        <div class="offcanvas-body u-p-0">
            <ul style="list-style:none;margin:0;padding:0;">
                <?php foreach ($nav_menus as $menu): ?>
                    <li><a href="<?= htmlspecialchars($menu['href']) ?>" class="d-block u-px-22 u-py-14 c-fs-16 fw-600 u-txt-dark" style="border-bottom:1px solid #f0f0f0;"><?= htmlspecialchars($menu['label']) ?></a></li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</header>

<style>
    #site-header { top: 0; }
    body { padding-top: 64px; }
</style>
