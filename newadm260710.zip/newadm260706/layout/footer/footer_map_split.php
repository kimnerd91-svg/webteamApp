<?php
/**
 * footer_map_split.php — 지도 + 오시는 길 정보 분할형 다크 푸터
 * 좌측엔 지도, 우측엔 주소·진료시간·전화번호 같은 "오시는 길" 정보를 나란히 배치하고
 * 그 아래 회사정보 + 소셜 아이콘 줄이 이어진다. (참고: 모아빌딩/서울인치과류 푸터)
 * 전제: $dm_conf, $cf_address, $cf_open_time, $cf_close_time, $cf_sat_open, $cf_sat_close,
 *       $cf_tel, $cf_kakao, $cf_blog, $cf_instagram, $cf_naver_talk가
 *       head_sub.php를 통해 이미 채워진 상태에서 include됨.
 */
?>
<footer class="footer u-bg-black u-pretendard u-pt-40 u-pb-40" id="footer02" style="background-color:#14171c;">
    <div class="u-fluid u-fluid-xl-sm">
        <div class="d-flex flex-column flex-lg-row u-gap-32" style="align-items:stretch;">

            <!-- 지도 -->
            <div style="flex:1; min-width:280px; height:220px; border-radius:14px; overflow:hidden;">
                <script charset="UTF-8" src="https://ssl.daumcdn.net/dmaps/map_js_init/roughmapLoader.js"></script>
                <script charset="UTF-8">
                    new daum.roughmap.Lander({
                        "timestamp": "1780535837766",
                        "key": "2d4rav4thj74",
                        "mapWidth": "100%",
                        "mapHeight": "220"
                    }).render();
                </script>
            </div>

            <!-- 오시는 길 -->
            <div style="flex:1; min-width:260px; color:#cdd2d8;">
                <h3 class="u-txt-white fw-800 c-fs-20 u-mb-14">오시는 길</h3>
                <p class="c-fs-14 u-lh-16 u-mb-16"><?= htmlspecialchars($cf_address ?? ($dm_conf['cf_address'] ?? '')) ?></p>

                <div class="c-fs-14 fw-700 u-txt-white u-mb-16"><?= htmlspecialchars($cf_tel ?? ($dm_conf['cf_tel'] ?? '')) ?></div>

                <table style="width:100%; font-size:13px; border-collapse:collapse;">
                    <tbody>
                        <?php if (!empty($cf_open_time) || !empty($cf_close_time)): ?>
                        <tr>
                            <td style="padding:6px 0; color:#8b93a0;">평 일</td>
                            <td style="padding:6px 0; text-align:right;"><?= htmlspecialchars($cf_open_time ?? '') ?> ~ <?= htmlspecialchars($cf_close_time ?? '') ?></td>
                        </tr>
                        <?php endif; ?>
                        <?php if (!empty($cf_sat_open) || !empty($cf_sat_close)): ?>
                        <tr>
                            <td style="padding:6px 0; color:#8b93a0;">토요일</td>
                            <td style="padding:6px 0; text-align:right;"><?= htmlspecialchars($cf_sat_open ?? '') ?> ~ <?= htmlspecialchars($cf_sat_close ?? '') ?></td>
                        </tr>
                        <?php endif; ?>
                        <?php if (!empty($cf_lunch_open) || !empty($cf_lunch_close)): ?>
                        <tr>
                            <td style="padding:6px 0; color:#8b93a0;">점심시간</td>
                            <td style="padding:6px 0; text-align:right;"><?= htmlspecialchars($cf_lunch_open ?? '') ?> ~ <?= htmlspecialchars($cf_lunch_close ?? '') ?></td>
                        </tr>
                        <?php endif; ?>
                        <tr>
                            <td style="padding:6px 0; color:#8b93a0;">일요일/공휴일</td>
                            <td style="padding:6px 0; text-align:right;">휴진</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <hr style="border-color:rgba(255,255,255,.1); margin:26px 0 20px;">

        <div class="d-flex flex-column-reverse flex-lg-row justify-content-between align-items-start align-items-lg-center u-gap-16">
            <div>
                <p class="c-fs-13" style="color:#8b93a0;">
                    <?= htmlspecialchars($dm_conf['cf_company_name'] ?? '') ?> |
                    <?= htmlspecialchars($dm_conf['cf_ceo_name'] ?? '') ?> |
                    사업자등록번호 <?= htmlspecialchars($dm_conf['cf_business_number'] ?? '') ?>
                </p>
                <p class="c-fs-12" style="color:#666; margin-top:4px;">Copyright <?= date('Y') ?>. <?= htmlspecialchars($dm_conf['cf_company_name'] ?? '') ?> All rights reserved.</p>
                <div class="d-flex u-gap-14 u-mt-10 c-fs-13">
                    <a href="#" style="color:#8b93a0; text-decoration:none;" data-bs-toggle="modal" data-bs-target="#modalPrivacy">개인정보처리방침</a>
                    <a href="#" style="color:#8b93a0; text-decoration:none;" data-bs-toggle="modal" data-bs-target="#modalNonCovered">비급여 수가표</a>
                </div>
            </div>

            <div class="d-flex u-gap-10">
                <?php if (!empty($cf_naver_talk)): ?><a href="<?= htmlspecialchars($cf_naver_talk) ?>" target="_blank" style="width:34px;height:34px;border-radius:50%;background:rgba(255,255,255,.08);display:flex;align-items:center;justify-content:center;text-decoration:none;">📅</a><?php endif; ?>
                <?php if (!empty($cf_kakao)): ?><a href="<?= htmlspecialchars($cf_kakao) ?>" target="_blank" style="width:34px;height:34px;border-radius:50%;background:rgba(255,255,255,.08);display:flex;align-items:center;justify-content:center;text-decoration:none;">💬</a><?php endif; ?>
                <?php if (!empty($cf_blog)): ?><a href="<?= htmlspecialchars($cf_blog) ?>" target="_blank" style="width:34px;height:34px;border-radius:50%;background:rgba(255,255,255,.08);display:flex;align-items:center;justify-content:center;text-decoration:none;">📝</a><?php endif; ?>
                <?php if (!empty($cf_instagram)): ?><a href="<?= htmlspecialchars($cf_instagram) ?>" target="_blank" style="width:34px;height:34px;border-radius:50%;background:rgba(255,255,255,.08);display:flex;align-items:center;justify-content:center;text-decoration:none;">📷</a><?php endif; ?>
            </div>
        </div>
    </div>
</footer>

<!-- 개인정보처리방침 모달 -->
<div class="modal fade" id="modalPrivacy" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content rounded-24 border-0">
            <div class="modal-header u-p-24 u-bd-b-1">
                <p class="modal-title fw-700 t-fs-20 u-txt-main">개인정보처리방침</p>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body u-p-32 c-fs-15 u-lh-160 u-txt-body" style="max-height: 60vh; overflow-y: auto;">
                <?php echo !empty($dm_conf['cf_privacy_policy']) ? nl2br($dm_conf['cf_privacy_policy']) : "등록된 개인정보처리방침이 없습니다."; ?>
            </div>
        </div>
    </div>
</div>

<!-- 비급여 수가표 모달 -->
<div class="modal fade" id="modalNonCovered" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-16 u-bd-n shadow-soft">
            <div class="modal-header u-bg-soft">
                <p class="modal-title fw-700">비급여 수가표</p>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body u-p-20 c-fs-14 u-txt-body">
                자세한 비급여 항목은 전화 문의 부탁드립니다<?= !empty($dm_conf['cf_tel']) ? ' (' . htmlspecialchars($dm_conf['cf_tel']) . ')' : '' ?>.
            </div>
        </div>
    </div>
</div>
