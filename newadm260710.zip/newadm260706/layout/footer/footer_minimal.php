<?php
/**
 * footer_minimal.php — 미니멀 푸터 (한 줄 카피라이트 + 약관 링크만)
 * 전제: $dm_conf가 이미 채워진 상태에서 include됨 (layout/tail.php가 준비)
 */
?>
<footer class="footer u-pretendard u-py-32" id="footer02" style="background:#111;">
    <div class="u-fluid u-fluid-xl-sm d-flex flex-column flex-md-row justify-content-between align-items-center u-gap-12">
        <p class="u-txt-white c-fs-13 fw-400" style="opacity:.7;">
            Copyright <?= date('Y') ?>. <?= htmlspecialchars($dm_conf['cf_company_name'] ?? '') ?> All rights reserved.
        </p>
        <div class="d-flex align-items-center u-gap-16">
            <a href="#" class="u-txt-white c-fs-13" data-bs-toggle="modal" data-bs-target="#modalPrivacy" style="opacity:.7;">개인정보처리방침</a>
            <a href="#" class="u-txt-white c-fs-13" data-bs-toggle="modal" data-bs-target="#modalNonCovered" style="opacity:.7;">비급여 수가표</a>
        </div>
    </div>
</footer>

<!-- 개인정보처리방침 모달 -->
<div class="modal fade" id="modalPrivacy" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content rounded-24 border-0">
            <div class="modal-header u-p-24 u-bd-b-1">
                <p class="modal-title fw-700 t-fs-20 u-txt-main">개인정보처리방침</p>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body u-p-32 c-fs-15 u-lh-160 u-txt-body" style="max-height: 60vh; overflow-y: auto;">
                <?php echo !empty($dm_conf['cf_privacy_policy'])
                    ? nl2br($dm_conf['cf_privacy_policy'])
                    : "등록된 개인정보처리방침이 없습니다."; ?>
            </div>
        </div>
    </div>
</div>

<!-- 비급여 수가표 모달 (미니멀 — 표는 default와 동일 로직, 필요 시 요약만) -->
<div class="modal fade" id="modalNonCovered" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-16 u-bd-n shadow-soft">
            <div class="modal-header u-bg-soft">
                <p class="modal-title fw-700">비급여 수가표</p>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body u-p-20 c-fs-14 u-txt-body">
                자세한 비급여 항목은 전화 문의 부탁드립니다<?= !empty($dm_conf['cf_tel']) ? ' (' . htmlspecialchars($dm_conf['cf_tel']) . ')' : '' ?>.
            </div>
        </div>
    </div>
</div>
