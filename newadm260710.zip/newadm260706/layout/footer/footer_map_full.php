<?php
/**
 * footer_map_full.php — 전체폭 지도 + 다크 푸터 타입
 * 지도가 상단 전체 너비로 깔리고, 그 아래 다크 톤 회사정보 푸터가 이어진다.
 * (참고: 연세바른치과류 푸터)
 * 전제: $dm_conf가 이미 채워진 상태에서 include됨 (layout/tail.php가 준비)
 *
 * 다음(Daum) 로드맵 임베드 코드는 다음 지도 "지도 표시하기"에서 발급받은
 * timestamp/key를 그대로 쓴다 — 사이트마다 실제 위치에 맞는 값으로 교체해야 한다.
 */
?>
<div class="footer-map-full" style="width:100%; height:280px; overflow:hidden;">
    <script charset="UTF-8" src="https://ssl.daumcdn.net/dmaps/map_js_init/roughmapLoader.js"></script>
    <script charset="UTF-8">
        new daum.roughmap.Lander({
            "timestamp": "1780535837766",
            "key": "2d4rav4thj74",
            "mapWidth": "100%",
            "mapHeight": "280"
        }).render();
    </script>
</div>

<footer class="footer u-bg-black u-pretendard u-px-0-sm u-pt-40 u-pb-40 u-bt-1 u-bc-gray-700" id="footer02" style="background-color:#111;">
    <div class="u-fluid u-fluid-xl-sm">
        <div class="d-flex flex-column-reverse flex-lg-row justify-content-between align-items-start align-items-lg-center">
            <div>
                <p class="u-txt-white c-fs-16 fw-400 u-lh-16 u-ls-10">
                    <?= htmlspecialchars($dm_conf['cf_company_name'] ?? '') ?> |
                    <?= htmlspecialchars($dm_conf['cf_ceo_name'] ?? '') ?> |
                    사업자등록번호 <?= htmlspecialchars($dm_conf['cf_business_number'] ?? '') ?> |
                    대표전화 <?= htmlspecialchars($dm_conf['cf_tel'] ?? '') ?>
                </p>
                <p class="u-txt-white c-fs-14 fw-400 u-lh-16 u-ls-10" style="opacity:.6;">Copyright <?= date('Y') ?>. <?= htmlspecialchars($dm_conf['cf_company_name'] ?? '') ?> All rights reserved.</p>
                <div class="d-flex justify-content-start align-items-center u-gap-16 u-mt-20 u-txt-white fw-400 c-fs-13" style="opacity:.75;">
                    <a href="#" class="u-txt-white fw-400 c-fs-13" data-bs-toggle="modal" data-bs-target="#modalPrivacy">개인정보처리방침</a>
                    <a href="#" class="u-txt-white fw-400 c-fs-13" data-bs-toggle="modal" data-bs-target="#modalNonCovered">비급여 수가표</a>
                </div>
            </div>
            <div class="u-mb-30-sm">
                <?php if (!empty($dm_conf['cf_logo'])): ?>
                    <img class="w-50-sm" src="<?= G5_DATA_URL ?>/common/<?= $dm_conf['cf_logo'] ?>" alt="" style="max-height:36px;">
                <?php else: ?>
                    <span class="u-txt-white fw-800 c-fs-16"><?= htmlspecialchars($dm_conf['cf_site_name'] ?? '') ?></span>
                <?php endif; ?>
            </div>
        </div>
    </div>
</footer>

<!-- 개인정보처리방침 모달 -->
<div class="modal fade" id="modalPrivacy" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content rounded-24 border-0">
            <div class="modal-header u-p-24 u-bd-b-1">
                <p class="modal-title fw-700 t-fs-20 u-txt-main">개인정보처리방침</p>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body u-p-32 c-fs-15 u-lh-160 u-txt-body" style="max-height: 60vh; overflow-y: auto;">
                <?php echo !empty($dm_conf['cf_privacy_policy']) ? nl2br($dm_conf['cf_privacy_policy']) : "등록된 개인정보처리방침이 없습니다."; ?>
            </div>
        </div>
    </div>
</div>

<!-- 비급여 수가표 모달 -->
<div class="modal fade" id="modalNonCovered" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-16 u-bd-n shadow-soft">
            <div class="modal-header u-bg-soft">
                <p class="modal-title fw-700">비급여 수가표</p>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body u-p-20 c-fs-14 u-txt-body">
                자세한 비급여 항목은 전화 문의 부탁드립니다<?= !empty($dm_conf['cf_tel']) ? ' (' . htmlspecialchars($dm_conf['cf_tel']) . ')' : '' ?>.
            </div>
        </div>
    </div>
</div>
