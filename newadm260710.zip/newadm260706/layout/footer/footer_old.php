<?php
/**
 * footer_old.php — 기존에 실사용하던 푸터 백업 (원래 파일명 footer_default.php)
 * 전제: $dm_conf, $non_covered 배열이 이미 채워진 상태에서 include됨 (layout/tail.php가 준비)
 */
?>
<footer class="footer u-bg-black u-pretendard u-px-0-sm u-pt-60 u-pb-60 u-pb-120-sm u-bt-1 u-bc-gray-700" id="footer02" style="background-color: #000;">
    <div class="u-fluid u-fluid-xl-sm">
        <div class="d-flex flex-column-reverse flex-lg-row justify-content-between align-items-start align-items-lg-center">
            <div>
                <p class="u-txt-white c-fs-18 fw-400 u-lh-16 u-ls-10">
                    <?= htmlspecialchars($dm_conf['cf_company_name'] ?? '') ?> |
                    <?= htmlspecialchars($dm_conf['cf_ceo_name'] ?? '') ?> |
                    <?= htmlspecialchars($dm_conf['cf_business_number'] ?? '') ?> |
                    대표전화 : <?= htmlspecialchars($dm_conf['cf_tel'] ?? '') ?> |
                </p>
                <p class="u-txt-white c-fs-18 fw-400 u-lh-16 u-ls-10">Copyright 2026. <?= htmlspecialchars($dm_conf['cf_company_name'] ?? '') ?> All rights reserved.</p>
                <div class="d-flex justify-content-start align-items-center u-gap-16 u-mt-30 u-txt-white fw-400 c-fs-14">
                    <a href="#" class="u-txt-white fw-400 c-fs-14" data-bs-toggle="modal" data-bs-target="#modalPrivacy">개인정보처리방침</a>
                    <a href="#" class="u-txt-white fw-400 c-fs-14" data-bs-toggle="modal" data-bs-target="#modalNonCovered">비급여 수가표</a>
                </div>
            </div>
            <div class="u-mb-40-sm">
                <img class="w-50-sm" src="/images/logogray.svg" alt="">
            </div>
        </div>
    </div>
</footer>

<!-- 이용약관 모달 -->
<div class="modal fade" id="modalProvision" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content rounded-24 border-0">
            <div class="modal-header u-p-24 u-bd-b-1">
                <p class="modal-title fw-700 t-fs-20">이용약관</p>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body u-p-32 c-fs-15 u-lh-160 u-txt-body" style="max-height: 60vh; overflow-y: auto;">
                <?php echo !empty($dm_conf['cf_terms'])
                    ? nl2br($dm_conf['cf_terms'])
                    : "등록된 이용약관이 없습니다."; ?>
            </div>
        </div>
    </div>
</div>

<!-- 개인정보처리방침 모달 -->
<div class="modal fade" id="modalPrivacy" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content rounded-24 border-0">
            <div class="modal-header u-p-24 u-bd-b-1">
                <p class="modal-title fw-700 t-fs-20 u-txt-main">개인정보처리방침</p>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body u-p-32 c-fs-15 u-lh-160 u-txt-body" style="max-height: 60vh; overflow-y: auto;">
                <?php echo !empty($dm_conf['cf_privacy_policy'])
                    ? nl2br($dm_conf['cf_privacy_policy'])
                    : "등록된 개인정보처리방침이 없습니다."; ?>
            </div>
        </div>
    </div>
</div>

<!-- 비급여 수가표 모달 -->
<div class="modal fade" id="modalNonCovered" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content rounded-16 u-bd-n shadow-soft">
            <div class="modal-header u-bg-soft">
                <p class="modal-title fw-700">비급여 수가표</p>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body u-p-20">
                <table class="u-table" style="width:100%;">
                    <thead class="u-bg-gray-100 u-txt-title">
                        <tr>
                            <th class="u-p-16" style="width:14%;">대분류</th>
                            <th class="u-p-16" style="width:14%;"></th>
                            <th class="u-p-16" style="width:30%;">항목명</th>
                            <th class="u-p-16" style="width:21%;">가격</th>
                            <th class="u-p-16" style="width:21%;">비고</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($non_covered)): ?>
                            <tr>
                                <td colspan="5" class="u-p-40 u-txt-center u-txt-muted">등록된 항목이 없습니다.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($non_covered as $major): ?>
                                <?php
                                $subs     = $major['subcategories'] ?? [];
                                $hasSub   = !empty($subs);
                                $dirItems = $major['items'] ?? [];

                                if (!$hasSub) {
                                    $majorSpan = max(count($dirItems), 1);
                                } else {
                                    $majorSpan = 0;
                                    foreach ($subs as $s) $majorSpan += max(count($s['items'] ?? []), 1);
                                    $majorSpan = max($majorSpan, 1);
                                }
                                $firstMajor = true;
                                ?>

                                <?php if (!$hasSub): ?>
                                    <?php if (empty($dirItems)): ?>
                                        <tr class="u-bd-b-1 u-bc-gray-100">
                                            <td class="u-p-16 fw-700 u-txt-center u-bg-gray-50 bigcate" rowspan="1" style="border-right:1px solid #e9ecef;vertical-align:middle;">
                                                <?= htmlspecialchars($major['category']) ?>
                                            </td>
                                            <td colspan="4" class="u-p-16 u-txt-center u-txt-muted">-</td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($dirItems as $item): ?>
                                            <tr class="u-bd-b-1 u-bc-gray-100">
                                                <?php if ($firstMajor): $firstMajor = false; ?>
                                                    <td class="u-p-16 fw-700 u-txt-center u-bg-gray-50 bigcate" rowspan="<?= $majorSpan ?>" style="border-right:1px solid #e9ecef;vertical-align:middle;">
                                                        <?= htmlspecialchars($major['category']) ?>
                                                    </td>
                                                <?php endif; ?>
                                                <td class="u-p-16 u-txt-center" colspan="2"><?= htmlspecialchars($item['name']) ?></td>
                                                <td class="u-p-16 u-txt-main u-txt-center"><?= htmlspecialchars($item['price']) ?>원</td>
                                                <td class="u-p-16 u-txt-gray-500 u-txt-center"><?= htmlspecialchars($item['note']) ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>

                                <?php else: ?>
                                    <?php foreach ($subs as $sub): ?>
                                        <?php
                                        $items   = $sub['items'] ?? [];
                                        $subSpan = max(count($items), 1);
                                        $firstSub = true;
                                        ?>
                                        <?php if (empty($items)): ?>
                                            <tr class="u-bd-b-1 u-bc-gray-100">
                                                <?php if ($firstMajor): $firstMajor = false; ?>
                                                    <td class="u-p-16 fw-700 u-txt-center u-bg-gray-50 bigcate" rowspan="<?= $majorSpan ?>" style="border-right:1px solid #e9ecef;vertical-align:middle;">
                                                        <?= htmlspecialchars($major['category']) ?>
                                                    </td>
                                                <?php endif; ?>
                                                <td class="u-p-16 fw-600 u-txt-center u-bg-soft smallcate" rowspan="1" style="border-right:1px solid #e9ecef;vertical-align:middle;">
                                                    <?= htmlspecialchars($sub['subcategory']) ?>
                                                </td>
                                                <td colspan="3" class="u-p-16 u-txt-center u-txt-muted">-</td>
                                            </tr>
                                        <?php else: ?>
                                            <?php foreach ($items as $item): ?>
                                                <tr class="u-bd-b-1 u-bc-gray-100">
                                                    <?php if ($firstMajor): $firstMajor = false; ?>
                                                        <td class="u-p-16 fw-700 u-txt-center u-bg-gray-50 bigcate" rowspan="<?= $majorSpan ?>" style="border-right:1px solid #e9ecef;vertical-align:middle;">
                                                            <?= htmlspecialchars($major['category']) ?>
                                                        </td>
                                                    <?php endif; ?>
                                                    <?php if ($firstSub): $firstSub = false; ?>
                                                        <td class="u-p-16 fw-600 u-txt-center u-bg-soft smallcate" rowspan="<?= $subSpan ?>" style="border-right:1px solid #e9ecef;vertical-align:middle;">
                                                            <?= htmlspecialchars($sub['subcategory']) ?>
                                                        </td>
                                                    <?php endif; ?>
                                                    <td class="u-p-16 u-txt-center"><?= htmlspecialchars($item['name']) ?></td>
                                                    <td class="u-p-16 u-txt-main u-txt-center"><?= htmlspecialchars($item['price']) ?>원</td>
                                                    <td class="u-p-16 u-txt-gray-500 u-txt-center"><?= htmlspecialchars($item['note']) ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                <?php endif; ?>

                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
