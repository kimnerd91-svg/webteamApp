<?php
/**
 * layout/demo.php — 헤더/푸터/퀵메뉴 컴포넌트 미리보기
 * 사용법: /layout/demo.php?header=minimal&footer=minimal&quickmenu=minimal
 *        파라미터를 안 주면 헤더/푸터는 'old'(기존 실사용 디자인), 퀵메뉴는 'default'로 보임.
 * 선택기 본체(head.php/tail.php)는 루트로 옮겨졌고, 타입 파일들만 layout/ 밑에 남아있다.
 */
include_once('./_common.php');

// 실제 존재하는 타입 파일만 스캔해서 화이트리스트로 사용 (임의 파일 include 방지)
function demo_scan_types($dir, $prefix, $exclude = []) {
    $types = [];
    foreach (glob(__DIR__ . "/$dir/{$prefix}_*.php") as $f) {
        $type = preg_replace(['#^.*' . preg_quote($prefix, '#') . '_#', '#\.php$#'], '', $f);
        if (in_array($type, $exclude, true)) continue;
        $types[] = $type;
    }
    sort($types);
    return $types ?: ['default'];
}
// pillstack은 데모 목록만 제외 (혼란스럽다는 피드백 — 실제 파일/헤더 타입 자체는 유지)
$header_types    = demo_scan_types('header', 'header', ['pillstack']);
$footer_types    = demo_scan_types('footer', 'footer');
$quickmenu_types = demo_scan_types('quickmenu', 'quickmenu');

$header_type    = in_array($_GET['header'] ?? '', $header_types, true) ? $_GET['header'] : 'old';
$footer_type    = in_array($_GET['footer'] ?? '', $footer_types, true) ? $_GET['footer'] : 'old';
$quickmenu_type = in_array($_GET['quickmenu'] ?? '', $quickmenu_types, true) ? $_GET['quickmenu'] : 'default';

include G5_PATH . '/head.php';

function demo_qs($override) {
    global $header_type, $footer_type, $quickmenu_type;
    $q = array_merge(['header' => $header_type, 'footer' => $footer_type, 'quickmenu' => $quickmenu_type], $override);
    return '?' . http_build_query($q);
}
?>

<div style="margin-top:var(--header-height, 80px); padding:24px; max-width:960px; margin-left:auto; margin-right:auto;">
    <div style="background:#f5f6fa; border:1px solid #e8eaf0; border-radius:16px; padding:24px; margin-bottom:32px;">
        <h1 style="font-size:20px; font-weight:800; margin-bottom:16px;">컴포넌트 미리보기</h1>

        <div style="margin-bottom:14px;">
            <strong style="display:block; font-size:13px; color:#888; margin-bottom:6px;">헤더 (header_type = <?= htmlspecialchars($header_type) ?>)</strong>
            <div style="display:flex; gap:8px; flex-wrap:wrap;">
                <?php foreach ($header_types as $t): ?>
                    <a href="<?= demo_qs(['header' => $t]) ?>"
                       style="padding:8px 16px; border-radius:8px; text-decoration:none; font-size:13px; font-weight:700;
                              background:<?= $t === $header_type ? '#4f46e5' : '#fff' ?>; color:<?= $t === $header_type ? '#fff' : '#333' ?>; border:1px solid #ddd;">
                        <?= htmlspecialchars($t) ?>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>

        <div style="margin-bottom:14px;">
            <strong style="display:block; font-size:13px; color:#888; margin-bottom:6px;">푸터 (footer_type = <?= htmlspecialchars($footer_type) ?>)</strong>
            <div style="display:flex; gap:8px; flex-wrap:wrap;">
                <?php foreach ($footer_types as $t): ?>
                    <a href="<?= demo_qs(['footer' => $t]) ?>"
                       style="padding:8px 16px; border-radius:8px; text-decoration:none; font-size:13px; font-weight:700;
                              background:<?= $t === $footer_type ? '#4f46e5' : '#fff' ?>; color:<?= $t === $footer_type ? '#fff' : '#333' ?>; border:1px solid #ddd;">
                        <?= htmlspecialchars($t) ?>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>

        <div>
            <strong style="display:block; font-size:13px; color:#888; margin-bottom:6px;">퀵메뉴 (quickmenu_type = <?= htmlspecialchars($quickmenu_type) ?>)</strong>
            <div style="display:flex; gap:8px; flex-wrap:wrap;">
                <?php foreach ($quickmenu_types as $t): ?>
                    <a href="<?= demo_qs(['quickmenu' => $t]) ?>"
                       style="padding:8px 16px; border-radius:8px; text-decoration:none; font-size:13px; font-weight:700;
                              background:<?= $t === $quickmenu_type ? '#4f46e5' : '#fff' ?>; color:<?= $t === $quickmenu_type ? '#fff' : '#333' ?>; border:1px solid #ddd;">
                        <?= htmlspecialchars($t) ?>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <div style="background:#fff; border:1px solid #eee; border-radius:16px; padding:24px; margin-bottom:24px;">
        <h2 style="font-size:16px; font-weight:700; margin-bottom:12px;">실제 페이지에서 쓰는 법</h2>
        <pre style="background:#1c1d21; color:#e6edf3; padding:16px; border-radius:10px; overflow-x:auto; font-size:13px; line-height:1.6;">&lt;?php
$header_type    = '<?= htmlspecialchars($header_type) ?>';   // 안 쓰면 'old'(기존 실사용 디자인)
$footer_type    = '<?= htmlspecialchars($footer_type) ?>';
$quickmenu_type = '<?= htmlspecialchars($quickmenu_type) ?>';   // 안 쓰면 'default'
include G5_PATH . '/head.php';
?&gt;

... 본문 ...

&lt;?php include G5_PATH . '/tail.php'; ?&gt;</pre>
    </div>

    <!-- 스크롤 확인용 더미 콘텐츠 -->
    <?php for ($i = 1; $i <= 6; $i++): ?>
    <div style="background:#fafafa; border:1px solid #eee; border-radius:12px; padding:40px; margin-bottom:16px; text-align:center; color:#999;">
        더미 섹션 <?= $i ?> — 스크롤 시 헤더/퀵메뉴 동작 확인용
    </div>
    <?php endfor; ?>
</div>

<?php include G5_PATH . '/tail.php'; ?>
