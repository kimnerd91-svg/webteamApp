<?php
/**
 * layout/ 공통 부트스트랩 — 루트 common.php를 그대로 로드한다.
 * layout/demo.php가 './_common.php'로 include한다 (head.php/tail.php는 루트로 이동됨).
 */
include_once(__DIR__ . '/../common.php');
