<?php
/* ============================================================
   i18n_boot.php v2 — 다국어 정적 캐시 서빙 (초경량)
   설치: 문서루트(/)에 업로드 후 head.php "최상단"(어떤 출력보다 먼저)에
         include_once($_SERVER['DOCUMENT_ROOT'].'/i18n_boot.php');
   동작: ?lang=en|ja|zh 요청 시 /data/i18n_cache/{lang}/{md5(경로)}.html
         정적 파일이 있으면 그대로 출력하고 종료. 없으면 한국어 폴백.
   생성: 캐시 파일은 관리자(다국어 관리 v5)에서 생성. 이 파일은 읽기 전용.
   v4(출력버퍼 실시간 치환)와 달리 DB 조회·치환 연산이 전혀 없음 → LCP 무부담.
   ============================================================ */
if (!defined('I18N_BOOT_V2')) {
    define('I18N_BOOT_V2', 1);

    $__i18n_lang = isset($_GET['lang']) ? preg_replace('/[^a-z]/', '', strtolower($_GET['lang'])) : '';
    if ($__i18n_lang && in_array($__i18n_lang, ['en','ja','zh'], true)) {
        $__i18n_path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
        if ($__i18n_path === '/index.php') $__i18n_path = '/'; // index.php와 / 동일 취급
        $__i18n_file = $_SERVER['DOCUMENT_ROOT'] . '/data/i18n_cache/' . $__i18n_lang . '/' . md5($__i18n_path) . '.html';
        if (is_file($__i18n_file)) {
            header('Content-Type: text/html; charset=utf-8');
            header('X-I18n-Cache: hit');
            readfile($__i18n_file);
            exit;
        }
        // 캐시 없으면 한국어 원문으로 폴백 (계속 진행)
    }
    unset($__i18n_lang, $__i18n_path, $__i18n_file);
}
