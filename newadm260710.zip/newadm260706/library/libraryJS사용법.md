# yido-ui.js / yido-ui.css 사용법 치트시트

이 라이브러리는 HTML에 `data-*` 속성이나 클래스만 붙이면 동작하는 방식이라, JS·CSS 코드를 직접 건드릴 필요는 거의 없습니다. 아래 예시를 그대로 복사해서 쓰면 됩니다.

## 설치 (한 번만)

```html
<head>
  <!-- ① FOUC 방지용 게이트 — head 맨 위에 인라인으로 -->
  <script>document.documentElement.classList.add('js')</script>
  <link rel="stylesheet" href="yido-ui.css">
</head>
<body>
  ...
  <script defer src="yido-ui.js"></script>
</body>
```

---

## ① 스크롤 리빌 (요소가 스크롤하면 서서히 나타남)

```html
<div data-reveal>아래에서 위로(기본) 나타남</div>
<div data-reveal="left">왼쪽에서 나타남</div>
<div data-reveal="right">오른쪽에서 나타남</div>
<div data-reveal="up">아래에서 더 크게 나타남</div>
<div data-reveal="zoom">확대되며 나타남</div>
```

**여러 개를 순차적으로(딜레이 주며)** 나타내고 싶으면 부모에 `data-stagger`:

```html
<div data-stagger data-stagger-step="80">
  <div>카드1</div>
  <div>카드2</div>
  <div>카드3</div>
</div>
```
→ 자식 요소가 80ms씩 순서대로 나타남 (개별로 data-reveal 안 붙여도 자동 적용됨)

---

## ② 숫자 카운트업

```html
<span data-count="1200" data-count-suffix="+명" data-count-dur="1400">0</span>
```
화면에 보이는 순간 0 → 1200까지 애니메이션. 소수점도 지원 (`data-count="4.5"`).

---

## ③ 패럴랙스 & 스크롤 진행바

```html
<img data-parallax="24" src="...">  <!-- 숫자가 클수록 더 많이 움직임 -->

<div class="scroll-progress"></div>  <!-- 페이지 아무데나 한 번만 넣으면 상단에 진행바 표시 -->
```

---

## ④ 영상 자동재생 (보이는 것만)

```html
<video data-autovideo muted loop playsinline preload="none" poster="thumb.jpg">
  <source src="clip.mp4" type="video/mp4">
</video>
```
화면에 잘 보이는 영상만(모바일 2개 / PC 4개) 자동재생하고 나머지는 멈춤. 카톡/인스타 인앱 브라우저처럼 영상이 안 뜨는 환경에서도 `poster` 이미지가 배경으로 깔려 최소한 사진은 보임.

---

## ⑤ Before / After 비교 슬라이더

```html
<figure class="ba">
  <img class="ba__after"  src="after.webp"  alt="치료 후">
  <img class="ba__before" src="before.webp" alt="치료 전">
  <input class="ba__range" type="range" min="0" max="100" value="50"
         aria-label="치료 전후 비교 슬라이더">
  <span class="ba__divider" aria-hidden="true"></span>
</figure>
```
드래그(또는 키보드 화살표)로 전/후 사진 비교. 순서 고정: after → before → range → divider.

---

## ⑥ 필름 그레인 질감 (선택 효과)

```html
<div class="has-grain">...</div>
```
은은한 노이즈 텍스처가 위에 한 겹 깔림 (이미지 파일 없이 SVG로 생성).

---

## 자동으로 신경 안 써도 되는 것

- 사용자가 "모션 줄이기(prefers-reduced-motion)" 설정 → 모든 애니메이션 즉시 종료 상태로 표시
- 데이터 절약 모드 / 2G 환경 → 영상 자동재생 생략, poster만 표시
- JS가 아예 꺼진 브라우저·크롤러 → `html.js`가 안 붙어서 전부 그냥 다 보임 (숨겨진 채로 안 남음)

## 자주 헷갈리는 포인트

| 헷갈리는 것 | 정리 |
|---|---|
| `data-reveal` vs `data-stagger` | reveal = 개별 요소 하나. stagger = 여러 자식을 순서대로. 같이 안 써도 됨 |
| `.ba` 안 이미지 순서 | **after가 먼저, before가 나중** (반대로 넣으면 슬라이더 반전됨) |
| 효과가 안 보일 때 | `data-count`/`data-reveal` 오타 확인 → 클래스가 아니라 **속성**임 |
| 영상이 여러 개인데 하나만 재생 | 정상 동작(성능 보호용 상한, PC 4개/모바일 2개) |
