<?php
/**
 * 병원용 관리자(/clinic) 공통 사이드바
 * - 각 clinic 매니저의 #clinic_wrap 맨 앞에서 include:  include_once('./aside.php');
 * - _auth_check.php 가 먼저 include 되어 있어야 함 ($member, $CLINIC_IS_SUPER, sql_* 사용)
 * - 6개 메뉴만 노출 (스키마·병원정보는 newadm 전용 → 제외)
 */
if (!isset($member))          { $member = ['mb_name' => '관리자']; }
if (!isset($CLINIC_IS_SUPER)) { $CLINIC_IS_SUPER = false; }

$clinic_cur = basename($_SERVER['SCRIPT_NAME']);
$clinic_menus = array(
    array('file' => 'qa_manager.php',          'emo' => '💬', 'label' => '문의 관리'),
    array('file' => 'board_manager.php',       'emo' => '📢', 'label' => '공지사항 관리', 'group' => array('board_manager.php', 'board_post_list.php')),
    array('file' => 'column_admin.php',        'emo' => '📝', 'label' => '칼럼 관리'),
    array('file' => 'before_after_manager.php','emo' => '🦷', 'label' => '임상증례'),
    array('file' => 'non_covered_manager.php', 'emo' => '💰', 'label' => '비급여 수가표'),
    array('file' => 'popup_manager.php',       'emo' => '🔔', 'label' => '팝업 관리'),
);

// 미확인 문의 수 (테이블 있을 때만 — 없으면 0)
$clinic_unread = 0;
$_ct = sql_fetch("SHOW TABLES LIKE 'dm_consult'");
if (!empty($_ct)) {
    $_u = sql_fetch("SELECT COUNT(*) AS cnt FROM dm_consult WHERE is_read = 0");
    $clinic_unread = (int)(isset($_u['cnt']) ? $_u['cnt'] : 0);
}
?>
<aside class="clinic_aside">
    <div class="ca_brand">
        <div class="logo">CLINIC ADMIN</div>
        <div class="who"><?= htmlspecialchars($member['mb_name']) ?></div>
        <span class="role"><?= $CLINIC_IS_SUPER ? '최고관리자' : '병원 계정' ?></span>
    </div>
    <nav class="ca_nav">
        <?php foreach ($clinic_menus as $m):
            $files = isset($m['group']) ? $m['group'] : array($m['file']);
            $on    = in_array($clinic_cur, $files, true);
        ?>
        <a href="./<?= $m['file'] ?>" class="<?= $on ? 'on' : '' ?>">
            <span class="emo"><?= $m['emo'] ?></span>
            <span><?= $m['label'] ?></span>
            <?php if ($m['file'] === 'qa_manager.php' && $clinic_unread > 0): ?>
            <span class="nbadge"><?= $clinic_unread > 99 ? '99+' : $clinic_unread ?></span>
            <?php endif; ?>
        </a>
        <?php endforeach; ?>
    </nav>
    <div class="ca_foot">
        <a href="/" target="_blank">🌐 사이트 보기</a>
        <a href="/clinic/logout.php">↩ 로그아웃</a>
    </div>
</aside>
