<?php
/**
 * /clinic/board_manager.php — 병원용 게시판 관리
 * - 그누보드 DB(g5_board / g5_write_XXX)에서 분리 — dm_boards(등록부) + dm_posts(공용 글 테이블) 사용
 * - 게이트: clinic/_auth_check.php (newadm 것 아님)
 * - 디자인: clinic 그린 톤 (_theme.php) — aside.php/공통 컴포넌트(c-card, c-tbl, c-btn 등) 그대로 재사용
 */
include_once('./_auth_check.php');
$is_admin = true; // 게이트 통과 = 관리 권한

// ── 테이블 준비 (없으면 생성) ─────────────────────────────
sql_query("CREATE TABLE IF NOT EXISTS `dm_boards` (
    `id`         INT(11) NOT NULL AUTO_INCREMENT,
    `bo_table`   VARCHAR(50) NOT NULL,
    `bo_subject` VARCHAR(255) NOT NULL DEFAULT '',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_bo_table` (`bo_table`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

sql_query("CREATE TABLE IF NOT EXISTS `dm_board_categories` (
    `id`         INT(11) NOT NULL AUTO_INCREMENT,
    `bo_table`   VARCHAR(50) NOT NULL,
    `ca_name`    VARCHAR(255) NOT NULL,
    `ca_order`   INT(11) DEFAULT 0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_bo_table` (`bo_table`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

sql_query("CREATE TABLE IF NOT EXISTS `dm_posts` (
    `id`           INT(11) NOT NULL AUTO_INCREMENT,
    `bo_table`     VARCHAR(50) NOT NULL,
    `category_id`  INT(11) DEFAULT 0,
    `subject`      VARCHAR(255) NOT NULL DEFAULT '',
    `content`      TEXT,
    `thumbnail`    VARCHAR(500) DEFAULT '',
    `writer_name`  VARCHAR(100) DEFAULT '',
    `hit`          INT(11) DEFAULT 0,
    `is_visible`   TINYINT(1) DEFAULT 1,
    `created_at`   DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at`   DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_bo_table` (`bo_table`),
    KEY `idx_bo_cat` (`bo_table`, `category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ── 게시판 삭제 로직 (테이블 DROP 없음 — dm_posts/dm_board_categories에서 해당 bo_table 행만 삭제) ──
if (isset($_GET['delete_bo'])) {
    $bo_table = preg_replace('/[^a-z0-9_]/i', '', $_GET['delete_bo']);
    sql_query("DELETE FROM dm_posts WHERE bo_table = '{$bo_table}'");
    sql_query("DELETE FROM dm_board_categories WHERE bo_table = '{$bo_table}'");
    sql_query("DELETE FROM dm_boards WHERE bo_table = '{$bo_table}'");
    alert_toast('게시판이 완전히 삭제되었습니다.', './board_manager.php');
}

// ── 생성된 게시판 목록 가져오기 ──────────────────────────
$total_row   = sql_fetch("SELECT COUNT(*) AS cnt FROM dm_boards");
$total_count = (int)($total_row['cnt'] ?? 0);
$result      = sql_query("SELECT * FROM dm_boards ORDER BY bo_table ASC");
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>게시판 관리</title>
    <?php include_once('./_theme.php'); ?>
    <style>
        /* board_manager 전용 보조 스타일 (clinic 그린 테마 변수 재사용) */
        .create_form{display:flex;gap:14px;align-items:flex-end;flex-wrap:wrap;}
        .form_group{display:flex;flex-direction:column;gap:6px;flex:1;min-width:160px;}
        .form_group label{font-size:12px;font-weight:700;color:var(--muted);}
        .form_group input{height:44px;border:1px solid var(--border);border-radius:10px;padding:0 14px;font-size:14px;color:var(--strong);background:var(--bg);font-family:inherit;transition:all .2s;}
        .form_group input:focus{outline:none;border-color:var(--c-main);background:#fff;box-shadow:0 0 0 3px rgba(22,163,74,.12);}
        .board_form_card{padding:24px;margin-bottom:24px;}
        .card_title{font-size:15px;font-weight:800;color:var(--strong);margin-bottom:16px;}
        .td_code{font-family:monospace;font-size:13px;background:var(--bg);padding:3px 8px;border-radius:5px;color:var(--text);}
        .td_count_badge{display:inline-block;background:var(--c-main-l);color:var(--c-main-d);padding:3px 12px;border-radius:20px;font-size:12px;font-weight:800;}
    </style>
</head>
<body>
<div id="clinic_wrap">
    <?php include_once('./aside.php'); ?>

    <main class="content_area">
        <div class="page_header">
            <h2 class="page_title">게시판 관리<small>게시판 생성 · 게시글 관리로 이동</small></h2>
        </div>

        <!-- 새 게시판 생성 -->
        <div class="c-card board_form_card">
            <p class="card_title">새 게시판 생성</p>
            <form action="./board_create_update.php" method="post" class="create_form">
                <div class="form_group">
                    <label>테이블명 (영문/숫자만)</label>
                    <input type="text" name="bo_table" placeholder="예: notice, free" required>
                </div>
                <div class="form_group" style="flex:2">
                    <label>게시판 제목 (한글 가능)</label>
                    <input type="text" name="bo_subject" placeholder="예: 공지사항, 자유게시판" required>
                </div>
                <button type="submit" class="c-btn c-btn-pri">생성하기</button>
            </form>
        </div>

        <!-- 게시판 목록 -->
        <div class="c-card">
            <div class="card_meta"><span>관리중인 게시판 <strong><?= $total_count ?></strong>개</span></div>
            <div class="table_wrap">
                <table class="c-tbl">
                    <thead>
                        <tr>
                            <th>게시판 제목</th>
                            <th>테이블 ID</th>
                            <th style="text-align:center;">총 게시물</th>
                            <th style="text-align:center;">관리</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i = 0;
                        while ($row = sql_fetch_array($result)) {
                            $i++;
                            $count_row   = sql_fetch("SELECT COUNT(*) AS cnt FROM dm_posts WHERE bo_table = '{$row['bo_table']}'");
                            $post_total  = (int)($count_row['cnt'] ?? 0);
                        ?>
                        <tr>
                            <td class="td_name"><?= htmlspecialchars($row['bo_subject']) ?></td>
                            <td><span class="td_code"><?= htmlspecialchars($row['bo_table']) ?></span></td>
                            <td style="text-align:center;"><span class="td_count_badge"><?= number_format($post_total) ?></span></td>
                            <td>
                                <div class="td_actions">
                                    <a href="./board_post_list.php?bo_table=<?= urlencode($row['bo_table']) ?>" class="c-btn c-btn-pri c-btn-sm">관리</a>
                                    <button type="button" onclick="if(confirm('이 게시판의 모든 데이터가 삭제됩니다. 계속하시겠습니까?')) location.href='?delete_bo=<?= urlencode($row['bo_table']) ?>'" class="c-btn c-btn-danger c-btn-sm">삭제</button>
                                </div>
                            </td>
                        </tr>
                        <?php } ?>
                        <?php if ($i === 0): ?>
                        <tr class="empty_row"><td colspan="4">생성된 게시판이 없습니다.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</div>
</body>
</html>
