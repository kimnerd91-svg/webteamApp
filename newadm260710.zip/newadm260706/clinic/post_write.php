<?php
/**
 * /clinic/post_write.php — dm_posts 저장 처리 전용 AJAX 엔드포인트 (페이지 이동 없음)
 * - 게이트: clinic/_auth_check.php (newadm 것 아님)
 * board_post_list.php의 글쓰기/수정 모달에서 fetch(POST)로 호출된다.
 * id가 있으면 수정, 없으면 새 글 등록. 응답은 JSON.
 */
include_once('./_auth_check.php');
$is_admin = true; // 게이트 통과 = 관리 권한

header('Content-Type: application/json; charset=utf-8');

if (!$is_admin) {
    echo json_encode(['success' => 0, 'message' => '권한이 없습니다.']);
    exit;
}

$bo_table = preg_replace('/[^a-z0-9_]/i', '', $_POST['bo_table'] ?? '');
$id       = (int)($_POST['id'] ?? 0);
$mode     = $id ? 'modify' : 'write';

$board = sql_fetch("SELECT * FROM dm_boards WHERE bo_table = '{$bo_table}'");
if (!$board['bo_table']) {
    echo json_encode(['success' => 0, 'message' => '게시판이 없습니다.']);
    exit;
}

$subject     = sql_real_escape_string(trim($_POST['subject'] ?? ''));
$content     = sql_real_escape_string($_POST['content'] ?? '');       // CKEditor에서 넘어온 HTML
$writer_name = sql_real_escape_string(trim($_POST['writer_name'] ?? ''));
$thumbnail   = sql_real_escape_string(trim($_POST['thumbnail'] ?? ''));
$category_id = (int)($_POST['category_id'] ?? 0);

if (!$subject) {
    echo json_encode(['success' => 0, 'message' => '제목을 입력해주세요.']);
    exit;
}

if ($mode === 'modify') {
    sql_query("UPDATE dm_posts SET
        subject='{$subject}', content='{$content}', writer_name='{$writer_name}',
        thumbnail='{$thumbnail}', category_id='{$category_id}', updated_at=NOW()
        WHERE id='{$id}' AND bo_table='{$bo_table}'");
} else {
    sql_query("INSERT INTO dm_posts SET
        bo_table='{$bo_table}', subject='{$subject}', content='{$content}',
        writer_name='{$writer_name}', thumbnail='{$thumbnail}', category_id='{$category_id}',
        hit=0, is_visible=1, created_at=NOW(), updated_at=NOW()");
}

echo json_encode(['success' => 1]);
