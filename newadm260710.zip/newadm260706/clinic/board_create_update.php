<?php
/**
 * /clinic/board_create_update.php — 게시판 생성 처리
 * - 게이트: clinic/_auth_check.php (newadm 것 아님)
 * - 게시판 "등록부"만 dm_boards에 남기고, 실제 글은 게시판마다 테이블을 새로 만들지 않고
 *   dm_posts 공용 테이블에 bo_table 컬럼으로 구분해서 저장한다.
 */
include_once('./_auth_check.php');

// ── 테이블 준비 (없으면 생성) ─────────────────────────────
sql_query("CREATE TABLE IF NOT EXISTS `dm_boards` (
    `id`         INT(11) NOT NULL AUTO_INCREMENT,
    `bo_table`   VARCHAR(50) NOT NULL,
    `bo_subject` VARCHAR(255) NOT NULL DEFAULT '',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_bo_table` (`bo_table`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

sql_query("CREATE TABLE IF NOT EXISTS `dm_board_categories` (
    `id`         INT(11) NOT NULL AUTO_INCREMENT,
    `bo_table`   VARCHAR(50) NOT NULL,
    `ca_name`    VARCHAR(255) NOT NULL,
    `ca_order`   INT(11) DEFAULT 0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_bo_table` (`bo_table`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

sql_query("CREATE TABLE IF NOT EXISTS `dm_posts` (
    `id`           INT(11) NOT NULL AUTO_INCREMENT,
    `bo_table`     VARCHAR(50) NOT NULL,
    `category_id`  INT(11) DEFAULT 0,
    `subject`      VARCHAR(255) NOT NULL DEFAULT '',
    `content`      TEXT,
    `thumbnail`    VARCHAR(500) DEFAULT '',
    `writer_name`  VARCHAR(100) DEFAULT '',
    `hit`          INT(11) DEFAULT 0,
    `is_visible`   TINYINT(1) DEFAULT 1,
    `created_at`   DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at`   DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_bo_table` (`bo_table`),
    KEY `idx_bo_cat` (`bo_table`, `category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// 영문 숫자가 아닌 경우 bo_table 필터링
$bo_table   = preg_replace('/[^a-z0-9_]/i', '', $_POST['bo_table'] ?? '');
$bo_subject = sql_real_escape_string(trim($_POST['bo_subject'] ?? ''));

if (!$bo_table || !$bo_subject) {
    alert_toast('게시판 ID와 제목을 정확히 입력해주세요.', './board_manager.php');
}

// 1. 중복 확인
$row = sql_fetch("SELECT COUNT(*) AS cnt FROM dm_boards WHERE bo_table = '{$bo_table}'");
if ($row['cnt']) {
    alert_toast('이미 사용 중인 게시판 ID입니다.', './board_manager.php');
}

// 2. 게시판 등록 (실제 글 테이블은 따로 만들지 않음 — dm_posts를 bo_table로 나눠 씀)
sql_query("INSERT INTO dm_boards SET
    bo_table = '{$bo_table}',
    bo_subject = '{$bo_subject}',
    created_at = NOW()");

alert_toast($bo_subject . ' 게시판이 성공적으로 생성되었습니다.', './board_manager.php', 'success');
