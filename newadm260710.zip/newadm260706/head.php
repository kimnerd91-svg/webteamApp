<?php
/**
 * /head.php (루트) — 페이지 상단 부트스트랩 + 헤더 컴포넌트 선택기
 * (예전엔 layout/head.php에 있었으나 루트로 이동함. 헤더 타입 파일들은 그대로 layout/header/ 안에 있음)
 *
 * 사용법: 이 파일을 include하기 전에 원하는 헤더 타입을 지정할 수 있다.
 *   $header_type = 'mega';   // 지정 안 하면 'old'(기존 실사용 헤더) 사용
 *   include G5_PATH . '/head.php';
 *
 * 사용 가능한 타입(layout/header/ 안의 파일명 기준): old, minimal, mega, flyout, single, pillstack
 * 새 타입을 추가하려면 layout/header/header_{타입명}.php 파일만 만들면 된다.
 */
include_once($_SERVER['DOCUMENT_ROOT'].'/i18n_boot.php');
include_once('./_common.php');
$dm_conf = sql_fetch("SELECT * FROM dm_config WHERE cf_id = 1");
include_once(G5_PATH . '/head_sub.php');

$header_type   = $header_type ?? 'old';
$__header_file = G5_PATH . '/layout/header/header_' . preg_replace('/[^a-z0-9_]/i', '', $header_type) . '.php';
if (!is_file($__header_file)) $__header_file = G5_PATH . '/layout/header/header_old.php';
include $__header_file;
