<?php
/**
 * smartsearch_manager.php — 스마트서치 통합 관리자 (공용)
 * ---------------------------------------------------------------------------
 * 기존 3개 파일(search_supplement.php · search_symptoms.php · build_index.php)을
 * 하나의 newadm 관리자로 흡수. 데이터는 PHP 배열 → DB 3테이블로 이전.
 *
 *   탭1 진료경로  : [전체 크롤링] → 사이트 메뉴 링크 발견 → 체크박스로 취사선택
 *                   → 선택 경로만 dm_ss_path 등록 + 경로별 유의어/wiki/related 편집
 *   탭2 증상규칙  : 증상문장→진료 추론 규칙 카드 편집 (+ pain_words)
 *   탭3 인덱스빌드: 선택 경로 크롤 → JSON-LD 추출 → DB 머지 → search_index.json
 *
 * 공용성: 경로 하드코딩 0. 크롤은 현재 접속 도메인(HTTP_HOST) 기준.
 *         어느 병원 newadm에 심어도 그 사이트 메뉴를 긁어 고른다.
 * ---------------------------------------------------------------------------
 */

include_once('../_common.php');
include_once('./_auth_check.php');

if (!$is_admin) { header('Location: /bbs/login.php?url='.urlencode($_SERVER['REQUEST_URI'])); exit; }

global $connect_db;
$db = $connect_db;

// ── 테이블 ───────────────────────────────────────────────
$T_PATH = 'dm_ss_path';     // 선택된 진료 경로
$T_KW   = 'dm_ss_keyword';  // 경로별 유의어·wiki·related (supplement)
$T_SYM  = 'dm_ss_symptom';  // 증상규칙 (symptoms) + pain_words(특수행)

mysqli_query($db, "CREATE TABLE IF NOT EXISTS `{$T_PATH}` (
    `id`         INT(11) NOT NULL AUTO_INCREMENT,
    `path`       VARCHAR(255) NOT NULL DEFAULT '',
    `name`       VARCHAR(255) NOT NULL DEFAULT '',
    `in_crawl`   TINYINT(1) NOT NULL DEFAULT 1,
    `sort`       INT(11) NOT NULL DEFAULT 0,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`), UNIQUE KEY `path` (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

mysqli_query($db, "CREATE TABLE IF NOT EXISTS `{$T_KW}` (
    `id`             INT(11) NOT NULL AUTO_INCREMENT,
    `path`           VARCHAR(255) NOT NULL DEFAULT '',
    `extra_keywords` TEXT,          -- JSON 배열
    `wiki_title`     VARCHAR(255) DEFAULT '',
    `wiki_text`      TEXT,
    `wiki_url`       VARCHAR(500) DEFAULT '',
    `related`        TEXT,          -- JSON 배열(경로)
    `icon`           VARCHAR(16) NOT NULL DEFAULT '',   -- 검색카드 이모지
    `updated_at`     DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`), UNIQUE KEY `path` (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

mysqli_query($db, "CREATE TABLE IF NOT EXISTS `{$T_SYM}` (
    `id`        INT(11) NOT NULL AUTO_INCREMENT,
    `kind`      VARCHAR(20) NOT NULL DEFAULT 'rule',  -- 'rule' | 'painwords'
    `cue_any`   TEXT,          -- JSON 배열
    `with_pain` TINYINT(1) NOT NULL DEFAULT 0,
    `paths`     TEXT,          -- JSON 배열(경로, 가중치순)
    `label`     VARCHAR(255) DEFAULT '',
    `sort`      INT(11) NOT NULL DEFAULT 0,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// icon 컬럼 보강 (기존 설치 업그레이드)
$__col = mysqli_query($db, "SHOW COLUMNS FROM `{$T_KW}` LIKE 'icon'");
if ($__col && mysqli_num_rows($__col) === 0) {
    mysqli_query($db, "ALTER TABLE `{$T_KW}` ADD COLUMN `icon` VARCHAR(16) NOT NULL DEFAULT '' AFTER `related`");
}

// ── 공용 헬퍼 ────────────────────────────────────────────
function ss_json($v) { return json_encode($v, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); }
function ss_arr($s)  { $d = json_decode($s ?? '', true); return is_array($d) ? $d : []; }
function ss_out($v)  { while (ob_get_level()) ob_end_clean(); header('Content-Type: application/json; charset=utf-8'); echo json_encode($v, JSON_UNESCAPED_UNICODE); exit; }

$BASE = 'https://' . (!empty($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : $_SERVER['SERVER_NAME']);

// fetch_html (build_index에서 가져온 cURL 우선 로직)
function ss_fetch($url) {
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT => 25, CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => 0, CURLOPT_USERAGENT => 'SmartSearchIndexer/2.0',
        ]);
        $html = curl_exec($ch);
        $err  = curl_error($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($html === false) return [null, 'cURL: ' . $err];
        if ($code >= 400)    return [null, 'HTTP ' . $code];
        return [$html, null];
    }
    $ctx = stream_context_create(['http'=>['timeout'=>25],'ssl'=>['verify_peer'=>false,'verify_peer_name'=>false]]);
    $html = @file_get_contents($url, false, $ctx);
    return $html === false ? [null, 'file_get_contents 실패'] : [$html, null];
}

// ════════════════════════════════════════════════════════
// AJAX 라우팅
// ════════════════════════════════════════════════════════
$action = $_GET['action'] ?? '';

// ── 0) hover 비디오 업로드/삭제 (search_smart 카드용) ──
//     저장 규칙: /data/smartsearch/video/{경로슬러그}.mp4 (+ 동명 포스터 jpg/webp/png)
//     search_smart.php의 ss_video_src()와 동일 슬러그 규칙.
function ss_slug($path) {
    return str_replace('/', '_', preg_replace('/\.php$/i', '', ltrim((string)$path, '/')));
}
function ss_video_dir() {
    $dir = G5_DATA_PATH . '/smartsearch/video';
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    return $dir;
}
function ss_video_state($path) {
    $slug = ss_slug($path); $dir = ss_video_dir();
    $st = ['slug'=>$slug, 'video'=>'', 'poster'=>''];
    if (is_file($dir.'/'.$slug.'.mp4')) $st['video'] = G5_DATA_URL.'/smartsearch/video/'.$slug.'.mp4';
    foreach (['.jpg','.webp','.png'] as $ext) {
        if (is_file($dir.'/'.$slug.$ext)) { $st['poster'] = G5_DATA_URL.'/smartsearch/video/'.$slug.$ext; break; }
    }
    return $st;
}

if ($action === 'video_upload') {
    $path = trim($_POST['path'] ?? '');
    if ($path === '') ss_out(['ok'=>false, 'err'=>'경로 없음']);
    $slug = ss_slug($path); $dir = ss_video_dir();
    $done = [];

    if (!empty($_FILES['video']['tmp_name']) && is_uploaded_file($_FILES['video']['tmp_name'])) {
        $ext = strtolower(pathinfo($_FILES['video']['name'], PATHINFO_EXTENSION));
        if ($ext !== 'mp4') ss_out(['ok'=>false, 'err'=>'영상은 mp4만 가능']);
        if (!@move_uploaded_file($_FILES['video']['tmp_name'], $dir.'/'.$slug.'.mp4'))
            ss_out(['ok'=>false, 'err'=>'영상 저장 실패 (data 폴더 권한 확인)']);
        $done[] = '영상';
    }
    if (!empty($_FILES['poster']['tmp_name']) && is_uploaded_file($_FILES['poster']['tmp_name'])) {
        $ext = strtolower(pathinfo($_FILES['poster']['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['jpg','jpeg','png','webp'], true)) ss_out(['ok'=>false, 'err'=>'포스터는 jpg/png/webp만 가능']);
        if ($ext === 'jpeg') $ext = 'jpg';
        foreach (['.jpg','.webp','.png'] as $old) @unlink($dir.'/'.$slug.$old); // 기존 포스터 정리
        if (!@move_uploaded_file($_FILES['poster']['tmp_name'], $dir.'/'.$slug.'.'.$ext))
            ss_out(['ok'=>false, 'err'=>'포스터 저장 실패']);
        $done[] = '포스터';
    }
    if (!$done) ss_out(['ok'=>false, 'err'=>'업로드할 파일을 선택하세요']);
    ss_out(['ok'=>true, 'done'=>implode('·',$done), 'state'=>ss_video_state($path)]);
}
if ($action === 'video_delete') {
    $path = trim($_GET['path'] ?? '');
    $kind = $_GET['kind'] ?? 'video';
    if ($path === '') ss_out(['ok'=>false, 'err'=>'경로 없음']);
    $slug = ss_slug($path); $dir = ss_video_dir();
    if ($kind === 'video') @unlink($dir.'/'.$slug.'.mp4');
    else foreach (['.jpg','.webp','.png'] as $ext) @unlink($dir.'/'.$slug.$ext);
    ss_out(['ok'=>true]);
}

// ── 1) 사이트 메뉴 크롤 → 발견된 링크 목록 반환 ──
//    헤더 영역의 메뉴 a[href]를 추출. /index_one.php/#앵커·외부·#·javascript: 는 selectable=false 로 표시.
if ($action === 'crawl_menu') {
    // head.php의 $nav_menus 배열을 직접 읽어 메뉴를 수집한다.
    // (사이트가 메뉴를 PHP 배열로 관리하고 링크 상당수가 주석 처리돼 있어,
    //  렌더된 HTML 파싱으로는 주석 항목이 잡히지 않는다. 배열을 소스로 삼으면
    //  주석 처리된 항목은 자연히 제외되고, 실제 활성 링크만 정확히 수집된다.)
    $header_file = G5_PATH . '/head.php';
    if (!is_file($header_file)) {
        ss_out(['ok'=>false, 'err'=>'head.php를 루트에서 찾지 못했습니다: '.$header_file]);
    }

    // header.php 전체를 실행하면 head_sub include·DB조회·HTML출력까지 딸려오므로,
    // 파일 소스에서 $nav_menus 배열 리터럴만 안전하게 잘라내 eval 한다.
    $src = file_get_contents($header_file);
    if ($src === false) ss_out(['ok'=>false, 'err'=>'head.php 읽기 실패']);

    if (!preg_match('/\$nav_menus\s*=\s*\[/', $src, $mm, PREG_OFFSET_CAPTURE)) {
        ss_out(['ok'=>false, 'err'=>'head.php에서 $nav_menus 배열을 찾지 못했습니다.']);
    }
    // 배열 시작 '[' 위치부터 대괄호 균형을 맞춰 끝 ']' 까지 추출 (문자열/주석 내부 대괄호 무시)
    $start = strpos($src, '[', $mm[0][1]);
    $i = $start; $depth = 0; $len = strlen($src); $end = -1;
    $inStr = false; $q = ''; $line = false; $block = false;
    for (; $i < $len; $i++) {
        $c = $src[$i]; $n = $i+1 < $len ? $src[$i+1] : '';
        if ($line) { if ($c === "\n") $line = false; continue; }
        if ($block) { if ($c === '*' && $n === '/') { $block = false; $i++; } continue; }
        if ($inStr) {
            if ($c === '\\') { $i++; continue; }
            if ($c === $q) $inStr = false;
            continue;
        }
        if ($c === '/' && $n === '/') { $line = true; $i++; continue; }
        if ($c === '#') { $line = true; continue; }
        if ($c === '/' && $n === '*') { $block = true; $i++; continue; }
        if ($c === '"' || $c === "'") { $inStr = true; $q = $c; continue; }
        if ($c === '[') $depth++;
        elseif ($c === ']') { $depth--; if ($depth === 0) { $end = $i; break; } }
    }
    if ($end < 0) ss_out(['ok'=>false, 'err'=>'$nav_menus 배열 끝을 파싱하지 못했습니다.']);

    $literal = substr($src, $start, $end - $start + 1);
    $nav_menus = null;
    try {
        $nav_menus = eval('return ' . $literal . ';');
    } catch (\Throwable $e) {
        ss_out(['ok'=>false, 'err'=>'$nav_menus 파싱 오류: '.$e->getMessage()]);
    }
    if (!is_array($nav_menus)) ss_out(['ok'=>false, 'err'=>'$nav_menus가 배열이 아닙니다.']);

    // 배열 → 평탄화. 부모/자식 모두 수집하되 label 없는(주석) 항목은 eval 단계에서 이미 빠짐.
    $found = []; $seen = [];
    $add = function($label, $href, $isChild) use (&$found, &$seen) {
        $href  = trim((string)$href);
        $label = trim(preg_replace('/\s+/', ' ', (string)$label));
        if ($href === '' || $href === '#' || $label === '') return;

        $path = $href;
        if (preg_match('#^https?://#i', $href)) {
            $pp = parse_url($href);
            if (($pp['host'] ?? '') !== ($_SERVER['HTTP_HOST'] ?? '')) return; // 외부링크 제외
            $path = ($pp['path'] ?? '/') . (isset($pp['query']) ? '?'.$pp['query'] : '') . (isset($pp['fragment']) ? '#'.$pp['fragment'] : '');
        }

        $bare       = preg_replace('/#.*$/', '', $path);   // 앵커 제거한 순수 경로
        $isAnchor   = (strpos($path, '#') !== false);
        $isJs       = (stripos($path, 'javascript:') === 0);
        $isRealPage = (bool) preg_match('#\.php($|\?)#i', $bare);
        // index 계열(index.php / index_one.php 등)은 메인/원페이지라 진료 페이지가 아님 → 비활성
        $isIndex    = (bool) preg_match('#/index[^/]*\.php$#i', $bare);
        $selectable = $isRealPage && !$isJs && !$isAnchor && !$isIndex;

        $key = $bare;
        if ($key === '') return;
        if (isset($seen[$key])) return;
        $seen[$key] = 1;

        $reason = '';
        if (!$selectable) {
            if ($isJs)          $reason = 'JS 링크';
            elseif ($isAnchor)  $reason = '앵커 링크(독립 URL 아님)';
            elseif ($isIndex)   $reason = '메인/원페이지';
            else                $reason = '페이지 아님';
        }
        $found[] = [
            'label'      => $label ?: $path,
            'path'       => $selectable ? $key : $path,
            'selectable' => $selectable,
            'reason'     => $reason,
        ];
    };

    foreach ($nav_menus as $menu) {
        if (!is_array($menu)) continue;
        $add($menu['label'] ?? '', $menu['href'] ?? '', false);
        foreach (($menu['children'] ?? []) as $child) {
            if (!is_array($child)) continue;
            if (!isset($child['label'])) continue; // 주석 처리로 label 없는 자식 방어
            $add($child['label'], $child['href'] ?? '', true);
        }
    }

    if (!$found) ss_out(['ok'=>false, 'err'=>'header.php의 $nav_menus에서 유효한 메뉴 링크를 찾지 못했습니다. (모두 주석 처리됐거나 배열이 비어있음)']);

    // 이미 등록된 경로 표시용
    $registered = [];
    $rq = mysqli_query($db, "SELECT path FROM `{$T_PATH}`");
    if ($rq) while ($r = mysqli_fetch_assoc($rq)) $registered[$r['path']] = 1;

    ss_out(['ok'=>true, 'base'=>$BASE, 'source'=>'header.php $nav_menus', 'found'=>$found, 'registered'=>$registered]);
}

// ── 2) 선택한 경로들 등록 (체크박스 모달 [선택 적용]) ──
if ($action === 'register_paths') {
    $data = json_decode(file_get_contents('php://input'), true) ?? [];
    $items = $data['items'] ?? [];   // [{path,name}]
    $n = 0;
    foreach ($items as $it) {
        $p = mysqli_real_escape_string($db, trim($it['path'] ?? ''));
        $nm = mysqli_real_escape_string($db, trim($it['name'] ?? ''));
        if ($p === '') continue;
        mysqli_query($db, "INSERT INTO `{$T_PATH}` (path,name,in_crawl) VALUES('{$p}','{$nm}',1)
            ON DUPLICATE KEY UPDATE name='{$nm}', in_crawl=1");
        // keyword 행도 보장
        mysqli_query($db, "INSERT IGNORE INTO `{$T_KW}` (path) VALUES('{$p}')");
        $n++;
    }
    ss_out(['ok'=>true, 'count'=>$n]);
}

// ── 3) 경로 삭제 / 크롤토글 ──
if ($action === 'path_delete') {
    $id = (int)($_GET['id'] ?? 0);
    $row = mysqli_fetch_assoc(mysqli_query($db, "SELECT path FROM `{$T_PATH}` WHERE id={$id}"));
    if ($row) {
        $p = mysqli_real_escape_string($db, $row['path']);
        mysqli_query($db, "DELETE FROM `{$T_PATH}` WHERE id={$id}");
        mysqli_query($db, "DELETE FROM `{$T_KW}` WHERE path='{$p}'");
    }
    ss_out(['ok'=>true]);
}
if ($action === 'path_toggle') {
    $id = (int)($_GET['id'] ?? 0);
    mysqli_query($db, "UPDATE `{$T_PATH}` SET in_crawl = 1 - in_crawl WHERE id={$id}");
    ss_out(['ok'=>true]);
}

// ── 4) 키워드(유의어·wiki·related) 저장 ──
if ($action === 'kw_save') {
    $d = json_decode(file_get_contents('php://input'), true) ?? [];
    $p  = mysqli_real_escape_string($db, trim($d['path'] ?? ''));
    if ($p === '') ss_out(['ok'=>false, 'err'=>'경로 없음']);
    $kw = mysqli_real_escape_string($db, ss_json(array_values(array_filter(array_map('trim', $d['extra_keywords'] ?? [])))));
    $wt = mysqli_real_escape_string($db, trim($d['wiki_title'] ?? ''));
    $wx = mysqli_real_escape_string($db, trim($d['wiki_text'] ?? ''));
    $wu = mysqli_real_escape_string($db, trim($d['wiki_url'] ?? ''));
    $rl = mysqli_real_escape_string($db, ss_json(array_values(array_filter(array_map('trim', $d['related'] ?? [])))));
    $ic = mysqli_real_escape_string($db, mb_substr(trim($d['icon'] ?? ''), 0, 8, 'UTF-8'));
    mysqli_query($db, "INSERT INTO `{$T_KW}` (path,extra_keywords,wiki_title,wiki_text,wiki_url,related,icon)
        VALUES('{$p}','{$kw}','{$wt}','{$wx}','{$wu}','{$rl}','{$ic}')
        ON DUPLICATE KEY UPDATE extra_keywords='{$kw}', wiki_title='{$wt}', wiki_text='{$wx}', wiki_url='{$wu}', related='{$rl}', icon='{$ic}'");

    // ── 증상 단서(cue) 동반 저장: 이 경로를 paths로 하는 증상규칙을 upsert ──
    // 카드의 증상칸에서 온 cue가 있으면, 이 경로 1개를 가리키는 rule을 갱신/생성.
    // (증상규칙은 path 종속이 아니므로, paths에 이 경로만 든 자동생성 rule을 path로 식별)
    $cue_arr = array_values(array_filter(array_map('trim', $d['cue_any'] ?? [])));
    $rawpath = trim($d['path'] ?? '');
    if ($rawpath !== '') {
        // 이 경로를 단독으로 가리키는 기존 자동 rule 탐색
        $pjson = ss_json([$rawpath]);
        $pjson_esc = mysqli_real_escape_string($db, $pjson);
        $ex = mysqli_fetch_assoc(mysqli_query($db,
            "SELECT id FROM `{$T_SYM}` WHERE kind='rule' AND paths='{$pjson_esc}' LIMIT 1"));
        if ($cue_arr) {
            $cue = mysqli_real_escape_string($db, ss_json($cue_arr));
            $lb  = $wt !== '' ? $wt : mysqli_real_escape_string($db, $rawpath);
            if ($ex) {
                mysqli_query($db, "UPDATE `{$T_SYM}` SET cue_any='{$cue}', label='{$lb}' WHERE id={$ex['id']}");
            } else {
                mysqli_query($db, "INSERT INTO `{$T_SYM}` (kind,cue_any,with_pain,paths,label,sort)
                    VALUES('rule','{$cue}',0,'{$pjson_esc}','{$lb}',0)");
            }
        } elseif ($ex) {
            // 단서를 비웠으면 자동 rule 제거
            mysqli_query($db, "DELETE FROM `{$T_SYM}` WHERE id={$ex['id']}");
        }
    }

    ss_out(['ok'=>true]);
}

// ── 5) 증상규칙 저장/삭제 + pain_words ──
if ($action === 'sym_save') {
    $d = json_decode(file_get_contents('php://input'), true) ?? [];
    $id = (int)($d['id'] ?? 0);
    $cue = mysqli_real_escape_string($db, ss_json(array_values(array_filter(array_map('trim', $d['cue_any'] ?? [])))));
    $wp  = !empty($d['with_pain']) ? 1 : 0;
    $pa  = mysqli_real_escape_string($db, ss_json(array_values(array_filter(array_map('trim', $d['paths'] ?? [])))));
    $lb  = mysqli_real_escape_string($db, trim($d['label'] ?? ''));
    $so  = (int)($d['sort'] ?? 0);
    if ($id) {
        mysqli_query($db, "UPDATE `{$T_SYM}` SET cue_any='{$cue}', with_pain={$wp}, paths='{$pa}', label='{$lb}', sort={$so} WHERE id={$id}");
    } else {
        mysqli_query($db, "INSERT INTO `{$T_SYM}` (kind,cue_any,with_pain,paths,label,sort) VALUES('rule','{$cue}',{$wp},'{$pa}','{$lb}',{$so})");
        $id = mysqli_insert_id($db);
    }
    ss_out(['ok'=>true, 'id'=>$id]);
}
if ($action === 'sym_delete') {
    $id = (int)($_GET['id'] ?? 0);
    mysqli_query($db, "DELETE FROM `{$T_SYM}` WHERE id={$id} AND kind='rule'");
    ss_out(['ok'=>true]);
}
if ($action === 'painwords_save') {
    $d = json_decode(file_get_contents('php://input'), true) ?? [];
    $words = mysqli_real_escape_string($db, ss_json(array_values(array_filter(array_map('trim', $d['words'] ?? [])))));
    $ex = mysqli_fetch_assoc(mysqli_query($db, "SELECT id FROM `{$T_SYM}` WHERE kind='painwords' LIMIT 1"));
    if ($ex) mysqli_query($db, "UPDATE `{$T_SYM}` SET cue_any='{$words}' WHERE id={$ex['id']}");
    else     mysqli_query($db, "INSERT INTO `{$T_SYM}` (kind,cue_any) VALUES('painwords','{$words}')");
    ss_out(['ok'=>true]);
}

// ── 6) 마이그레이션: 기존 supplement.php / symptoms.php → DB (1회) ──
if ($action === 'migrate') {
    $sup_file = $_GET['sup'] ?? '/sub/smartsearch/search_supplement.php';
    $sym_file = $_GET['sym'] ?? '/sub/smartsearch/search_symptoms.php';
    $docroot  = $_SERVER['DOCUMENT_ROOT'] ?? '';
    $rep = ['sup'=>0, 'sym'=>0, 'err'=>[]];

    // supplement → path/keyword
    $supPath = $docroot . $sup_file;
    if (is_file($supPath)) {
        $SUP = include($supPath);
        if (is_array($SUP)) {
            foreach ($SUP as $path => $v) {
                $p = mysqli_real_escape_string($db, $path);
                mysqli_query($db, "INSERT INTO `{$T_PATH}` (path,name,in_crawl) VALUES('{$p}','',1)
                    ON DUPLICATE KEY UPDATE in_crawl=1");
                $kw = mysqli_real_escape_string($db, ss_json($v['extra_keywords'] ?? []));
                $wt = mysqli_real_escape_string($db, $v['wiki']['title'] ?? '');
                $wx = mysqli_real_escape_string($db, $v['wiki']['text'] ?? '');
                $wu = mysqli_real_escape_string($db, $v['wiki']['url'] ?? '');
                $rl = mysqli_real_escape_string($db, ss_json($v['related'] ?? []));
                mysqli_query($db, "INSERT INTO `{$T_KW}` (path,extra_keywords,wiki_title,wiki_text,wiki_url,related)
                    VALUES('{$p}','{$kw}','{$wt}','{$wx}','{$wu}','{$rl}')
                    ON DUPLICATE KEY UPDATE extra_keywords='{$kw}', wiki_title='{$wt}', wiki_text='{$wx}', wiki_url='{$wu}', related='{$rl}'");
                $rep['sup']++;
            }
        } else $rep['err'][] = 'supplement 배열 아님';
    } else $rep['err'][] = 'supplement 파일 없음: ' . $sup_file;

    // symptoms → symptom/painwords
    $symPath = $docroot . $sym_file;
    if (is_file($symPath)) {
        $SY = include($symPath);
        if (is_array($SY)) {
            if (!empty($SY['_pain_words'])) {
                $words = mysqli_real_escape_string($db, ss_json($SY['_pain_words']));
                $ex = mysqli_fetch_assoc(mysqli_query($db, "SELECT id FROM `{$T_SYM}` WHERE kind='painwords' LIMIT 1"));
                if ($ex) mysqli_query($db, "UPDATE `{$T_SYM}` SET cue_any='{$words}' WHERE id={$ex['id']}");
                else     mysqli_query($db, "INSERT INTO `{$T_SYM}` (kind,cue_any) VALUES('painwords','{$words}')");
            }
            $so = 0;
            foreach (($SY['rules'] ?? []) as $rule) {
                $cue = mysqli_real_escape_string($db, ss_json($rule['any'] ?? []));
                $wp  = !empty($rule['with']) ? 1 : 0;
                $pa  = mysqli_real_escape_string($db, ss_json($rule['paths'] ?? []));
                $lb  = mysqli_real_escape_string($db, $rule['label'] ?? '');
                mysqli_query($db, "INSERT INTO `{$T_SYM}` (kind,cue_any,with_pain,paths,label,sort)
                    VALUES('rule','{$cue}',{$wp},'{$pa}','{$lb}',{$so})");
                $so++; $rep['sym']++;
            }
        } else $rep['err'][] = 'symptoms 배열 아님';
    } else $rep['err'][] = 'symptoms 파일 없음: ' . $sym_file;

    ss_out(['ok'=>true, 'report'=>$rep]);
}

// ── 7) 인덱스 빌드 (build_index 로직 흡수 — DB 경로/키워드 기준) ──
if ($action === 'build') {
    @set_time_limit(120);

    // 크롤 대상 = in_crawl=1 경로
    $paths = [];
    $pr = mysqli_query($db, "SELECT path,name FROM `{$T_PATH}` WHERE in_crawl=1 ORDER BY sort,id");
    if ($pr) while ($r = mysqli_fetch_assoc($pr)) $paths[$r['path']] = $r['name'];

    // 키워드/wiki/related 룩업
    $KW = [];
    $kr = mysqli_query($db, "SELECT * FROM `{$T_KW}`");
    if ($kr) while ($r = mysqli_fetch_assoc($kr)) $KW[$r['path']] = $r;

    // ── 의학용어사전(dm_dict) 연동 ──
    // dm_dict.related(JSON 경로배열)를 기준으로 경로별 역인덱스 구성.
    // 각 경로에 매칭되는 용어의 term/synonyms → keywords 확장, definition → 용어풀이 노출.
    $DICT = [];  // path => [ ['term'=>, 'definition'=>, 'synonyms'=>[...] ], ... ]
    if ($dr = mysqli_query($db, "SELECT term, definition, synonyms, related FROM `dm_dict`")) {
        while ($row = mysqli_fetch_assoc($dr)) {
            $rel = json_decode($row['related'] ?? '', true);
            if (!is_array($rel) || !$rel) continue;            // related 경로 없으면 스킵
            $syn = json_decode($row['synonyms'] ?? '', true);
            if (!is_array($syn)) $syn = [];
            $entry = [
                'term'       => $row['term'],
                'definition' => trim((string)($row['definition'] ?? '')),
                'synonyms'   => array_values(array_filter(array_map('trim', $syn))),
            ];
            foreach ($rel as $rpath) {
                $rpath = trim((string)$rpath);
                if ($rpath === '') continue;
                $DICT[$rpath][] = $entry;
            }
        }
    }

    $index = []; $report = [];

    foreach ($paths as $path => $pname) {
        list($html, $err) = ss_fetch($BASE . $path);
        if ($err) { $report[] = ['error', $path, '크롤 실패 — '.$err]; continue; }

        // JSON-LD 추출(평탄화)
        $nodes = [];
        if (preg_match_all('#<script[^>]*type=["\']application/ld\+json["\'][^>]*>(.*?)</script>#is', $html, $m)) {
            foreach ($m[1] as $block) {
                $dataj = json_decode(trim($block), true);
                if ($dataj === null) continue;
                $nodes = array_merge($nodes, ss_flatten($dataj));
            }
        }
        if (!$nodes) { $report[] = ['error', $path, 'JSON-LD 없음']; continue; }

        $proc=null; $webpage=null; $faq=null;
        foreach ($nodes as $n) {
            if (!$proc    && ss_hastype($n,'MedicalProcedure')) $proc=$n;
            if (!$webpage && ss_hastype($n,'MedicalWebPage'))   $webpage=$n;
        }
        if (!$proc) foreach ($nodes as $n) if (ss_hastype($n,'MedicalCondition')) { $proc=$n; break; }
        if (!$proc && $webpage) $proc=$webpage;
        foreach ($nodes as $n) {
            if (ss_hastype($n,'FAQPage') && !empty($n['mainEntity']) && isset($n['@id']) && strpos($n['@id'],'#faq')!==false) { $faq=$n; break; }
        }
        if (!$proc) { $report[] = ['error',$path,'MedicalProcedure/Condition/WebPage 없음']; continue; }

        $faqs=[];
        if ($faq) foreach ((array)$faq['mainEntity'] as $qa) {
            $qn=$qa['name']??''; $an=$qa['acceptedAnswer']['text']??'';
            if ($qn!=='') $faqs[]=['q'=>$qn,'a'=>$an];
        }

        $is_wp = ($proc===$webpage) || ss_hastype($proc,'MedicalWebPage');
        $name  = $is_wp ? (ss_bcleaf($webpage) ?: ($proc['name']??$path)) : ($proc['name'] ?? ($webpage['name']??$path));
        if ($pname) $name = $pname ?: $name;  // 어드민에서 지정한 이름 우선
        $alt = $proc['alternateName'] ?? []; if (is_string($alt)) $alt=[$alt];
        $desc = $proc['description'] ?? ($webpage['description'] ?? '');
        $url  = $webpage['url'] ?? ($proc['url'] ?? ($BASE.$path));

        $kwrow = $KW[$path] ?? [];
        $extra = ss_arr($kwrow['extra_keywords'] ?? '');
        $keywords=[];
        foreach (array_merge([$name],$alt,$extra) as $k) { $k=trim((string)$k); if ($k!=='' && !in_array($k,$keywords,true)) $keywords[]=$k; }

        // ── 기본 진료어 자동 보강 ──
        // 진료명·유의어에서 핵심 진료 명사(교정/임플란트/미백…)를 뽑아 keywords에 추가.
        // "소아교정"만으로는 "교정" 검색이 안 잡히므로, 대표 진료어 단독형을 넣어준다.
        // (search_smart는 양방향 매칭을 하지만, 자동완성 suggest에도 노출되도록 인덱스에 실어둔다)
        $CORE_TERMS = ['교정','임플란트','임플','라미네이트','레진','미백','신경치료','충치','잇몸','스케일링',
                       '틀니','보철','발치','사랑니','턱관절','크라운','인레이','브릿지','치주','보존','심미'];
        $scan = implode(' ', array_merge([$name], $extra));
        foreach ($CORE_TERMS as $ct) {
            if (mb_strpos($scan, $ct) !== false && !in_array($ct, $keywords, true)) {
                $keywords[] = $ct;
            }
        }

        // ── dm_dict 연동: 이 경로에 매칭되는 용어/유의어를 keywords에 머지, 정의는 dict_terms로 ──
        $dict_terms = [];
        if (!empty($DICT[$path])) {
            foreach ($DICT[$path] as $de) {
                // term + synonyms → 검색 매칭 키워드 확장
                foreach (array_merge([$de['term']], $de['synonyms']) as $k) {
                    $k = trim((string)$k);
                    if ($k !== '' && !in_array($k, $keywords, true)) $keywords[] = $k;
                }
                // 정의가 있으면 용어풀이로 노출(검색결과 표시용)
                if ($de['definition'] !== '') {
                    $dict_terms[] = ['term'=>$de['term'], 'definition'=>$de['definition']];
                }
            }
        }

        $wiki = null;
        if (!empty($kwrow['wiki_title']) || !empty($kwrow['wiki_text'])) {
            $wiki = ['title'=>$kwrow['wiki_title']??'', 'text'=>$kwrow['wiki_text']??'', 'url'=>$kwrow['wiki_url']??''];
        }

        $index[] = [
            'path'=>$path, 'name'=>$name, 'category'=>ss_bccat($webpage),
            'keywords'=>$keywords, 'summary'=>$desc,
            'howPerformed'=>$proc['howPerformed'] ?? '',
            'nodeType'=> isset($proc['@type']) ? (is_array($proc['@type'])?implode(',',$proc['@type']):$proc['@type']) : '',
            'url'=>$url, 'faqs'=>$faqs,
            'wiki'=>$wiki, 'related'=> ss_arr($kwrow['related'] ?? ''),
            'dict_terms'=>$dict_terms,
            'icon'=> trim((string)($kwrow['icon'] ?? '')),
        ];
        if (!$faqs) $report[]=['warn',$path,'FAQ 0건'];
        if ($dict_terms) $report[]=['info',$path,'사전 용어 '.count($dict_terms).'건 연동'];
    }

    // dm_dict 중 related 경로가 크롤 대상에 없어 매칭 안 된 경로 안내
    $dict_unmatched = array_diff(array_keys($DICT), array_keys($paths));
    if ($dict_unmatched) {
        $report[] = ['warn', '(dict)', 'related 경로 미매칭 '.count($dict_unmatched).'건: '.implode(', ', array_slice($dict_unmatched,0,5)).(count($dict_unmatched)>5?' …':'')];
    }

    $out = G5_DATA_PATH . '/search_index.json';
    $payload = ['generated_at'=>date('c'), 'base'=>$BASE, 'count'=>count($index), 'items'=>$index];
    $written = @file_put_contents($out, json_encode($payload, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT));

    // ── 자동완성 경량 인덱스(search_suggest.json) ──
    // 검색창 미리보기용. {term: 표시어, name: 진료명, url, type: keyword|symptom} 목록.
    // search_index.json은 본문·FAQ까지 담아 무거우므로, 매칭에 필요한 것만 추려 별도 경량 파일로.
    $sg = [];
    $seen_term = [];
    foreach ($index as $it) {
        // 진료명 + 키워드(유의어 포함)
        foreach ((array)($it['keywords'] ?? []) as $kw) {
            $kw = trim((string)$kw); if ($kw==='') continue;
            $k = mb_strtolower($kw,'UTF-8');
            if (isset($seen_term[$k])) continue; $seen_term[$k]=1;
            $sg[] = ['term'=>$kw, 'name'=>$it['name'], 'url'=>$it['url'], 'type'=>'keyword', 'icon'=>$it['icon'] ?? ''];
        }
    }
    // 증상 단서(dm_ss_symptom rule) → 대표 진료명 매핑
    $path_name = []; foreach ($index as $it) $path_name[$it['path']] = ['name'=>$it['name'],'url'=>$it['url'],'icon'=>$it['icon'] ?? ''];
    if ($syq = mysqli_query($db, "SELECT cue_any, paths, label FROM `{$T_SYM}` WHERE kind='rule'")) {
        while ($sr = mysqli_fetch_assoc($syq)) {
            $cues = json_decode($sr['cue_any'] ?? '', true); if (!is_array($cues)) continue;
            $pths = json_decode($sr['paths'] ?? '', true);   if (!is_array($pths) || !$pths) continue;
            $first = $pths[0];
            $nm = $path_name[$first]['name'] ?? ($sr['label'] ?: $first);
            $ur = $path_name[$first]['url']  ?? $first;
            foreach ($cues as $cue) {
                $cue = trim((string)$cue); if ($cue==='') continue;
                $k = mb_strtolower($cue,'UTF-8');
                if (isset($seen_term[$k])) continue; $seen_term[$k]=1;
                $sg[] = ['term'=>$cue, 'name'=>$nm, 'url'=>$ur, 'type'=>'symptom', 'icon'=>$path_name[$first]['icon'] ?? ''];
            }
        }
    }
    $out_sg = G5_DATA_PATH . '/search_suggest.json';
    @file_put_contents($out_sg, json_encode(['generated_at'=>date('c'),'count'=>count($sg),'items'=>$sg], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));

    ss_out(['ok'=>($written!==false), 'count'=>count($index), 'target'=>count($paths),
            'path'=>$out, 'written'=>($written!==false), 'suggest_count'=>count($sg), 'report'=>$report]);
}

// build 헬퍼들
function ss_flatten($data) {
    $out=[]; if (!is_array($data)) return $out;
    if (isset($data['@graph']) && is_array($data['@graph'])) { foreach ($data['@graph'] as $n) $out=array_merge($out,ss_flatten($n)); return $out; }
    $is_list = array_keys($data)===range(0,count($data)-1);
    if ($is_list) { foreach ($data as $n) $out=array_merge($out,ss_flatten($n)); return $out; }
    $out[]=$data; return $out;
}
function ss_hastype($n,$t){ if(!isset($n['@type']))return false; $x=$n['@type']; return is_array($x)?in_array($t,$x,true):($x===$t); }
function ss_bccat($wp){ if(!$wp||empty($wp['breadcrumb']['itemListElement']))return ''; foreach($wp['breadcrumb']['itemListElement'] as $it) if((int)($it['position']??0)===2) return $it['name']??''; return ''; }
function ss_bcleaf($wp){ if(!$wp||empty($wp['breadcrumb']['itemListElement']))return ''; $b='';$mx=-1; foreach($wp['breadcrumb']['itemListElement'] as $it){$p=(int)($it['position']??0); if($p>$mx){$mx=$p;$b=$it['name']??'';}} return $b; }

// ── 화면 렌더용 데이터 로드 ──
$rows_path = [];
$r = mysqli_query($db, "SELECT * FROM `{$T_PATH}` ORDER BY sort,id");
if ($r) while ($x=mysqli_fetch_assoc($r)) $rows_path[]=$x;

$kw_map = [];
$r = mysqli_query($db, "SELECT * FROM `{$T_KW}`");
if ($r) while ($x=mysqli_fetch_assoc($r)) $kw_map[$x['path']]=$x;

$rows_sym = [];
$r = mysqli_query($db, "SELECT * FROM `{$T_SYM}` WHERE kind='rule' ORDER BY sort,id");
if ($r) while ($x=mysqli_fetch_assoc($r)) $rows_sym[]=$x;

$painwords = [];
$pw = mysqli_fetch_assoc(mysqli_query($db, "SELECT cue_any FROM `{$T_SYM}` WHERE kind='painwords' LIMIT 1"));
if ($pw) $painwords = ss_arr($pw['cue_any']);

$has_data = count($rows_path) > 0 || count($rows_sym) > 0;
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>스마트서치 관리</title>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'Pretendard','Apple SD Gothic Neo',sans-serif;background:#f5f6fa;color:#1a1a2e;}
#admin_wrapper{display:flex;min-height:100vh;}
.content_area{flex:1;padding:40px;overflow-x:hidden;display:flex;flex-direction:column;gap:20px;}
.page_header{display:flex;align-items:center;justify-content:space-between;}
.page_title{font-size:22px;font-weight:700;display:flex;align-items:center;gap:10px;}
.card{background:#fff;border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,.06);border:1px solid #e8eaf0;overflow:hidden;}
.card_hd{padding:14px 20px;border-bottom:1px solid #e8eaf0;display:flex;align-items:center;justify-content:space-between;}
.card_hd_title{font-size:14px;font-weight:700;display:flex;align-items:center;gap:6px;}
.card_hd_title .material-symbols-outlined{font-size:16px;color:#4f46e5;}
.card_body{padding:20px;}
.btn_primary{padding:9px 20px;background:#4f46e5;color:#fff;border:none;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer;transition:.2s;display:inline-flex;align-items:center;gap:5px;font-family:inherit;}
.btn_primary:hover{background:#4338ca;} .btn_primary:disabled{opacity:.5;cursor:not-allowed;}
.btn_green{padding:9px 16px;background:#059669;color:#fff;border:none;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer;transition:.2s;display:inline-flex;align-items:center;gap:5px;font-family:inherit;}
.btn_green:hover{background:#047857;} .btn_green:disabled{opacity:.5;cursor:not-allowed;}
.btn_neutral{padding:9px 16px;background:#f5f6fa;color:#5c5c7a;border:1px solid #e8eaf0;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer;transition:.2s;display:inline-flex;align-items:center;gap:5px;font-family:inherit;}
.btn_neutral:hover{background:#e8eaf0;}
.btn_del{padding:5px 10px;background:#fee2e2;color:#dc2626;border:none;border-radius:6px;font-size:11px;font-weight:700;cursor:pointer;}
.btn_sm{padding:6px 12px;font-size:12px;border-radius:7px;border:none;cursor:pointer;font-weight:700;font-family:inherit;display:inline-flex;align-items:center;gap:4px;}
.spin{animation:spin 1s linear infinite;} @keyframes spin{to{transform:rotate(360deg);}}
/* 탭 */
.tabs{display:flex;gap:4px;border-bottom:2px solid #e8eaf0;margin-bottom:4px;}
.tab{padding:11px 20px;font-size:14px;font-weight:700;color:#9999bb;border:none;background:none;cursor:pointer;border-bottom:3px solid transparent;margin-bottom:-2px;font-family:inherit;display:inline-flex;align-items:center;gap:6px;}
.tab.active{color:#4f46e5;border-bottom-color:#4f46e5;}
.tab .material-symbols-outlined{font-size:17px;}
.tabpane{display:none;} .tabpane.active{display:block;}
/* 입력 */
.form_input{width:100%;padding:9px 12px;border:1px solid #e8eaf0;border-radius:8px;font-size:13px;background:#f5f6fa;color:#1a1a2e;font-family:inherit;outline:none;transition:.2s;}
.form_input:focus{border-color:#4f46e5;background:#fff;box-shadow:0 0 0 3px rgba(79,70,229,.1);}
textarea.form_input{resize:vertical;min-height:60px;line-height:1.6;}
label.lab{display:block;font-size:11px;font-weight:700;color:#9999bb;margin-bottom:4px;}
/* 경로 카드 */
.path-card{border:1px solid #e8eaf0;border-radius:10px;padding:16px;margin-bottom:12px;background:#fff;}
.path-card.off{opacity:.55;background:#fafafa;}
.path-card .pc-head{display:flex;justify-content:space-between;align-items:flex-start;gap:10px;margin-bottom:12px;}
.path-card .pc-path{font-family:monospace;font-size:12px;color:#4f46e5;word-break:break-all;}
.path-card .pc-name{font-size:14px;font-weight:700;margin-top:2px;}
.pc-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;}
@media(max-width:720px){.pc-grid{grid-template-columns:1fr;}}
.chip{display:inline-flex;align-items:center;gap:4px;background:#eef2ff;color:#4f46e5;border-radius:20px;padding:3px 10px;font-size:12px;margin:2px;}
.chip button{background:none;border:none;color:#4f46e5;cursor:pointer;font-size:13px;line-height:1;padding:0;}
.badge{display:inline-flex;align-items:center;gap:3px;font-size:11px;font-weight:700;border-radius:20px;padding:2px 9px;}
.badge.on{background:#f0fdf4;color:#059669;border:1px solid #bbf7d0;}
.badge.off{background:#fef2f2;color:#dc2626;border:1px solid #fecaca;}
/* 모달 */
.modal-bd{display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:99999;align-items:center;justify-content:center;}
.modal-bd.show{display:flex;}
.modal-bx{background:#fff;border-radius:14px;padding:24px;width:100%;max-width:680px;max-height:88vh;overflow-y:auto;box-shadow:0 20px 60px rgba(0,0,0,.2);}
.modal-tt{font-size:16px;font-weight:700;margin-bottom:16px;display:flex;align-items:center;justify-content:space-between;}
.crawl-row{display:flex;align-items:center;gap:10px;padding:10px 12px;border:1px solid #e8eaf0;border-radius:8px;margin-bottom:6px;}
.crawl-row.disabled{opacity:.5;background:#fafafa;}
.crawl-row input[type=checkbox]{width:17px;height:17px;accent-color:#4f46e5;flex:none;}
.crawl-row .cr-label{font-weight:700;font-size:13px;}
.crawl-row .cr-path{font-family:monospace;font-size:11px;color:#6b7280;word-break:break-all;}
.crawl-row .cr-reason{font-size:11px;color:#dc2626;flex:none;}
.crawl-row .cr-reg{font-size:10px;color:#059669;flex:none;font-weight:700;}
/* 토스트 */
.toast{position:fixed;top:20px;right:20px;padding:12px 18px;border-radius:10px;font-size:13px;font-weight:600;display:flex;align-items:center;gap:7px;z-index:100001;box-shadow:0 4px 16px rgba(0,0,0,.12);animation:tin .22s ease;}
.toast.ok{background:#f0fdf4;border:1px solid #bbf7d0;color:#059669;} .toast.error{background:#fef2f2;border:1px solid #fecaca;color:#dc2626;}
@keyframes tin{from{opacity:0;transform:translateX(12px)}to{opacity:1;transform:none}}
.empty{text-align:center;padding:40px;color:#9999bb;font-size:14px;}
.hint{background:#ede9fe;border-radius:10px;padding:13px 16px;font-size:13px;color:#4f46e5;line-height:1.7;}
.report-row{display:flex;gap:8px;padding:6px 0;border-bottom:1px solid #f0ece2;font-size:13px;}
.report-row .rt{flex:none;font-size:11px;font-weight:700;border-radius:5px;padding:2px 7px;height:fit-content;}
.rt.error{background:#fde8e6;color:#b3261e;} .rt.warn{background:#fdf3e0;color:#9a6b12;}
.global-bar{margin-top:14px;background:#fff;border:1px solid #e9d5ff;border-radius:12px;padding:14px 18px;box-shadow:0 4px 14px rgba(124,58,237,.06);}
.global-bar-info{display:flex;align-items:center;gap:8px;font-size:13px;color:#6b21a8;margin-bottom:12px;line-height:1.5;}
.global-bar-btns{display:flex;gap:10px;flex-wrap:wrap;}
.global-bar-btns .btn_primary{font-size:13.5px;padding:11px 18px;}
.global-prog{margin-top:14px;}
.global-prog-bar{height:8px;background:#f1eafe;border-radius:99px;overflow:hidden;}
.global-prog-bar i{display:block;height:100%;width:0;background:linear-gradient(90deg,#7c3aed,#4f46e5);border-radius:99px;transition:width .3s;}
.global-prog-txt{margin-top:7px;font-size:12.5px;color:#7c3aed;font-weight:600;}
</style>
</head>
<body>
<div id="admin_wrapper">
    <?php include_once('../aside.php'); ?>
    <main class="content_area">

        <div class="page_header">
            <h2 class="page_title">
                <span class="material-symbols-outlined" style="font-size:22px;color:#4f46e5;">search_check</span>
                스마트서치 관리
            </h2>
            <?php if (!$has_data): ?>
            <button class="btn_neutral" onclick="runMigrate()">
                <span class="material-symbols-outlined" style="font-size:14px;">database</span>기존 데이터 가져오기
            </button>
            <?php endif; ?>
        </div>

        <div class="hint">
            <strong>💡 동작</strong> — [전체 크롤링]으로 사이트 메뉴 링크를 가져와 체크박스로 골라 등록합니다.
            등록한 페이지에 유의어·위키·연관진료를 붙이고, 증상규칙을 만든 뒤, [인덱스 빌드]로 <code style="background:#c4b5fd;padding:1px 6px;border-radius:4px;">search_index.json</code>을 생성합니다.
            검색 결과는 <code style="background:#c4b5fd;padding:1px 6px;border-radius:4px;">search_smart.php</code>가 이 인덱스를 읽어 보여줍니다.
        </div>

        <!-- ═══ 글로벌 원버튼 액션바 ═══ -->
        <div class="global-bar">
            <div class="global-bar-info">
                <span class="material-symbols-outlined" style="font-size:18px;color:#7c3aed;">bolt</span>
                <span><b>한 번에 처리</b> — 여러 카드를 일일이 저장·빌드할 필요 없이 아래 버튼 하나로 끝냅니다.</span>
            </div>
            <div class="global-bar-btns">
                <button class="btn_primary" id="btnSaveBuildAll" onclick="saveAndBuildAll()" style="background:#4f46e5;">
                    <span class="material-symbols-outlined" style="font-size:15px;">save</span>모두 저장 + 빌드
                </button>
                <button class="btn_primary" id="btnAiAll" onclick="aiAllAndBuild()" style="background:linear-gradient(135deg,#7c3aed,#4f46e5);">
                    <span class="material-symbols-outlined" style="font-size:15px;">auto_awesome</span>전체 AI 자동완성 + 저장 + 빌드
                </button>
            </div>
            <div id="globalProg" class="global-prog" style="display:none;">
                <div class="global-prog-bar"><i id="globalProgFill"></i></div>
                <div id="globalProgTxt" class="global-prog-txt"></div>
            </div>
        </div>

        <div class="tabs">
            <button class="tab active" data-tab="paths" onclick="switchTab('paths')"><span class="material-symbols-outlined">format_list_bulleted</span>진료 경로 · 유의어</button>
            <button class="tab" data-tab="sym" onclick="switchTab('sym')"><span class="material-symbols-outlined">healing</span>증상 규칙</button>
            <button class="tab" data-tab="build" onclick="switchTab('build')"><span class="material-symbols-outlined">build</span>인덱스 빌드</button>
        </div>

        <!-- ═══ 탭1: 경로·유의어 ═══ -->
        <div class="tabpane active" id="pane-paths">
            <div class="card">
                <div class="card_hd">
                    <span class="card_hd_title"><span class="material-symbols-outlined">format_list_bulleted</span>등록된 진료 경로 <span style="color:#9999bb;font-weight:400;">(<?= count($rows_path) ?>)</span></span>
                    <div style="display:flex;gap:8px;align-items:center;">
                        <input type="password" id="ssApiKey" class="form_input" placeholder="Gemini API 키 (AIzaSy…) — 로컬 저장" style="width:260px;">
                        <button class="btn_green" onclick="openCrawl()"><span class="material-symbols-outlined" style="font-size:14px;">travel_explore</span>전체 크롤링</button>
                    </div>
                </div>
                <div class="card_body">
                    <?php if (empty($rows_path)): ?>
                    <div class="empty">등록된 경로가 없습니다.<br>[전체 크롤링]으로 사이트 메뉴를 가져와 선택하세요.</div>
                    <?php else: foreach ($rows_path as $p):
                        $kw = $kw_map[$p['path']] ?? [];
                        $ekw = ss_arr($kw['extra_keywords'] ?? '');
                        $rel = ss_arr($kw['related'] ?? '');
                        // 이 경로를 단독으로 가리키는 자동 증상규칙의 단서 로드
                        $cue_self = [];
                        $pjson_self = ss_json([$p['path']]);
                        if ($sres = mysqli_query($db, "SELECT cue_any FROM `{$T_SYM}` WHERE kind='rule' AND paths='".mysqli_real_escape_string($db,$pjson_self)."' LIMIT 1")) {
                            if ($srow = mysqli_fetch_assoc($sres)) $cue_self = ss_arr($srow['cue_any'] ?? '');
                        }
                    ?>
                    <div class="path-card <?= $p['in_crawl'] ? '' : 'off' ?>" data-path="<?= htmlspecialchars($p['path'],ENT_QUOTES) ?>" data-id="<?= (int)$p['id'] ?>">
                        <div class="pc-head">
                            <div>
                                <div class="pc-path"><?= htmlspecialchars($p['path']) ?></div>
                                <div style="display:flex;gap:6px;margin-top:6px;">
                                    <input class="form_input pc-icon" style="width:64px;text-align:center;font-size:16px;" value="<?= htmlspecialchars($kw['icon'] ?? '') ?>" placeholder="🦷" title="검색카드 아이콘(이모지)">
                                    <input class="form_input pc-name-input" style="max-width:300px;" value="<?= htmlspecialchars($p['name']) ?>" placeholder="진료명(비우면 스키마에서 자동)">
                                </div>
                            </div>
                            <div style="display:flex;gap:6px;align-items:center;flex:none;">
                                <span class="badge <?= $p['in_crawl'] ? 'on':'off' ?>" onclick="togglePath(<?= (int)$p['id'] ?>)" style="cursor:pointer;">
                                    <span class="material-symbols-outlined" style="font-size:12px;"><?= $p['in_crawl']?'check_circle':'cancel' ?></span><?= $p['in_crawl']?'색인 ON':'OFF' ?>
                                </span>
                                <button class="btn_del" onclick="delPath(<?= (int)$p['id'] ?>)"><span class="material-symbols-outlined" style="font-size:12px;">delete</span></button>
                            </div>
                        </div>
                        <div class="pc-grid">
                            <div>
                                <label class="lab">유의어·오타 (extra_keywords) — 쉼표/엔터로 추가</label>
                                <input class="form_input kw-input" placeholder="단어 입력 후 Enter" onkeydown="kwAdd(event,this)">
                                <div class="kw-chips" style="margin-top:6px;"><?php foreach ($ekw as $k): ?><span class="chip"><?= htmlspecialchars($k) ?><button onclick="kwDel(this)">×</button></span><?php endforeach; ?></div>
                            </div>
                            <div>
                                <label class="lab">연관 진료 경로 (related) — 쉼표/엔터</label>
                                <input class="form_input rel-input" placeholder="/sub/...php 입력 후 Enter" onkeydown="kwAdd(event,this)">
                                <div class="rel-chips" style="margin-top:6px;"><?php foreach ($rel as $k): ?><span class="chip"><?= htmlspecialchars($k) ?><button onclick="kwDel(this)">×</button></span><?php endforeach; ?></div>
                            </div>
                        </div>
                        <div style="margin-top:12px;">
                            <label class="lab">위키 설명 (선택) — 제목 / 본문 / URL</label>
                            <div style="display:flex;gap:8px;margin-bottom:6px;">
                                <input class="form_input wiki-title" style="flex:1;" placeholder="위키 제목" value="<?= htmlspecialchars($kw['wiki_title'] ?? '') ?>">
                                <input class="form_input wiki-url" style="flex:1.5;" placeholder="https://ko.wikipedia.org/..." value="<?= htmlspecialchars($kw['wiki_url'] ?? '') ?>">
                            </div>
                            <textarea class="form_input wiki-text" placeholder="위키 본문 요약 (CC BY-SA, 운영 전 검수 권장)"><?= htmlspecialchars($kw['wiki_text'] ?? '') ?></textarea>
                        </div>
                        <div style="margin-top:12px;">
                            <label class="lab">증상 단서 (cue) — 이 증상으로 검색하면 이 진료 추천. 쉼표/엔터</label>
                            <input class="form_input cue-input" placeholder="예: 시리다, 욱신, 신경치료 후 아픔 — 입력 후 Enter" onkeydown="kwAdd(event,this)">
                            <div class="cue-chips" style="margin-top:6px;"><?php foreach ($cue_self as $c): ?><span class="chip"><?= htmlspecialchars($c) ?><button onclick="kwDel(this)">×</button></span><?php endforeach; ?></div>
                        </div>
                        <?php $vst = ss_video_state($p['path']); ?>
                        <div style="margin-top:12px;padding:12px 14px;background:#fafbff;border:1px solid #e8eaf0;border-radius:8px;">
                            <label class="lab">hover 비디오 (검색카드) — 카드에 마우스 올리면 재생되는 mp4 + 포스터(선택)</label>
                            <div class="vid-zone" style="display:flex;gap:12px;align-items:center;flex-wrap:wrap;">
                                <?php if ($vst['video']): ?>
                                    <video src="<?= htmlspecialchars($vst['video']) ?>" muted loop preload="metadata"
                                        <?= $vst['poster'] ? 'poster="'.htmlspecialchars($vst['poster']).'"' : '' ?>
                                        style="width:130px;border-radius:8px;background:#000;"
                                        onmouseenter="this.play()" onmouseleave="this.pause();this.currentTime=0;"></video>
                                    <span class="badge on">영상 있음</span>
                                    <button class="btn_del" onclick="videoDel(this,'video')">영상 삭제</button>
                                    <?php if ($vst['poster']): ?><button class="btn_del" onclick="videoDel(this,'poster')">포스터 삭제</button><?php endif; ?>
                                <?php else: ?>
                                    <span class="badge off">영상 없음</span>
                                <?php endif; ?>
                            </div>
                            <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:8px;">
                                <label style="font-size:11px;color:#9999bb;font-weight:700;">mp4</label>
                                <input type="file" accept="video/mp4" class="vid-file" style="font-size:12px;max-width:200px;">
                                <label style="font-size:11px;color:#9999bb;font-weight:700;">포스터</label>
                                <input type="file" accept=".jpg,.jpeg,.png,.webp" class="poster-file" style="font-size:12px;max-width:200px;">
                                <button class="btn_sm" style="background:#059669;color:#fff;" onclick="videoUpload(this)"><span class="material-symbols-outlined" style="font-size:13px;">upload</span>업로드</button>
                            </div>
                            <div style="font-size:11px;color:#9999bb;margin-top:6px;">저장 위치: /data/smartsearch/video/<?= htmlspecialchars($vst['slug']) ?>.mp4 — 파일명은 자동. 인덱스 재빌드 불필요.</div>
                        </div>
                        <div style="margin-top:12px;text-align:right;">
                            <button class="btn_sm" style="background:#0ea5e9;color:#fff;margin-right:6px;" onclick="aiFillPath(this)"><span class="material-symbols-outlined" style="font-size:13px;">auto_awesome</span>AI 자동 채우기</button>
                            <button class="btn_sm" style="background:#4f46e5;color:#fff;" onclick="saveKw(this)"><span class="material-symbols-outlined" style="font-size:13px;">save</span>이 경로 저장</button>
                        </div>
                    </div>
                    <?php endforeach; endif; ?>
                </div>
            </div>
        </div>

        <!-- ═══ 탭2: 증상 규칙 ═══ -->
        <div class="tabpane" id="pane-sym">
            <div class="card">
                <div class="card_hd">
                    <span class="card_hd_title"><span class="material-symbols-outlined">healing</span>증상 → 진료 추론 규칙 <span style="color:#9999bb;font-weight:400;">(<?= count($rows_sym) ?>)</span></span>
                    <div style="display:flex;gap:8px;">
                        <button class="btn_sm" style="background:linear-gradient(135deg,#6d28d9,#4f46e5);color:#fff;" onclick="aiGenRules(this)" title="등록된 진료 전체를 보고 증상→진료 규칙을 AI가 한번에 만듭니다">
                            <span class="material-symbols-outlined" style="font-size:14px;">auto_awesome</span>AI 규칙 자동생성
                        </button>
                        <button class="btn_green" onclick="addSymRow()"><span class="material-symbols-outlined" style="font-size:14px;">add</span>규칙 추가</button>
                    </div>
                </div>
                <div class="card_body">
                    <div style="margin-bottom:14px;padding:11px 14px;background:linear-gradient(135deg,#faf5ff,#f5f3ff);border:1px solid #e9d5ff;border-radius:8px;font-size:12.5px;color:#6b21a8;line-height:1.6;">
                        <b>AI 규칙 자동생성</b>은 탭1에 등록된 진료들을 분석해 "이런 증상이면 → 이 진료" 규칙을 자동으로 만들어 아래에 채워줍니다. 생성 후 각 규칙의 <b>[규칙 저장]</b>을 눌러야 반영됩니다. (Gemini API 키 필요)
                    </div>
                    <div style="margin-bottom:16px;padding:12px 14px;background:#fafbff;border:1px solid #e8eaf0;border-radius:8px;">
                        <label class="lab">통증어 (pain_words) — "with 통증" 규칙 강화에 쓰임. 쉼표/엔터</label>
                        <input class="form_input" id="pw-input" placeholder="단어 입력 후 Enter" onkeydown="pwAdd(event)">
                        <div class="kw-chips" id="pw-chips" style="margin-top:6px;"><?php foreach ($painwords as $w): ?><span class="chip"><?= htmlspecialchars($w) ?><button onclick="pwDel(this)">×</button></span><?php endforeach; ?></div>
                        <div style="display:flex;gap:8px;margin-top:8px;">
                            <button class="btn_sm" style="background:#4f46e5;color:#fff;" onclick="savePainwords()"><span class="material-symbols-outlined" style="font-size:13px;">save</span>통증어 저장</button>
                            <button class="btn_sm" style="background:#7c3aed;color:#fff;" onclick="aiExpandPainwords(this)"><span class="material-symbols-outlined" style="font-size:13px;">auto_awesome</span>AI로 통증어 확장</button>
                        </div>
                    </div>
                    <div id="sym-list">
                        <?php foreach ($rows_sym as $s):
                            $cue = ss_arr($s['cue_any']); $pa = ss_arr($s['paths']); ?>
                        <div class="path-card" data-id="<?= (int)$s['id'] ?>">
                            <div class="pc-head">
                                <input class="form_input sym-label" style="max-width:280px;font-weight:700;" value="<?= htmlspecialchars($s['label']) ?>" placeholder="규칙 이름 (예: 턱 통증)">
                                <div style="display:flex;gap:6px;align-items:center;flex:none;">
                                    <label style="font-size:12px;display:flex;align-items:center;gap:4px;cursor:pointer;"><input type="checkbox" class="sym-with" <?= $s['with_pain']?'checked':'' ?>>통증어 필요</label>
                                    <button class="btn_del" onclick="delSym(<?= (int)$s['id'] ?>,this)"><span class="material-symbols-outlined" style="font-size:12px;">delete</span></button>
                                </div>
                            </div>
                            <div class="pc-grid">
                                <div>
                                    <label class="lab">신호어 (any) — 하나라도 문장에 있으면 매칭. 쉼표/엔터</label>
                                    <input class="form_input cue-input" placeholder="단어 입력 후 Enter" onkeydown="kwAdd(event,this)">
                                    <div class="cue-chips" style="margin-top:6px;"><?php foreach ($cue as $c): ?><span class="chip"><?= htmlspecialchars($c) ?><button onclick="kwDel(this)">×</button></span><?php endforeach; ?></div>
                                </div>
                                <div>
                                    <label class="lab">연결 진료 경로 (paths) — 앞쪽이 우선. 쉼표/엔터</label>
                                    <input class="form_input symp-input" placeholder="/sub/...php 입력 후 Enter" onkeydown="kwAdd(event,this)">
                                    <div class="symp-chips" style="margin-top:6px;"><?php foreach ($pa as $c): ?><span class="chip"><?= htmlspecialchars($c) ?><button onclick="kwDel(this)">×</button></span><?php endforeach; ?></div>
                                </div>
                            </div>
                            <div style="margin-top:12px;display:flex;justify-content:flex-end;gap:8px;">
                                <button class="btn_sm" style="background:#7c3aed;color:#fff;" onclick="aiFillSym(this)" title="규칙 이름·진료 기준으로 신호어를 AI가 채웁니다"><span class="material-symbols-outlined" style="font-size:13px;">auto_awesome</span>AI 신호어</button>
                                <button class="btn_sm" style="background:#4f46e5;color:#fff;" onclick="saveSym(this)"><span class="material-symbols-outlined" style="font-size:13px;">save</span>규칙 저장</button>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php if (empty($rows_sym)): ?><div class="empty" id="sym-empty">증상 규칙이 없습니다. [규칙 추가]로 시작하세요.</div><?php endif; ?>
                </div>
            </div>
        </div>

        <!-- ═══ 탭3: 빌드 ═══ -->
        <div class="tabpane" id="pane-build">
            <div class="card">
                <div class="card_hd"><span class="card_hd_title"><span class="material-symbols-outlined">build</span>인덱스 빌드</span></div>
                <div class="card_body">
                    <p style="font-size:13px;color:#6b7280;line-height:1.7;margin-bottom:16px;">
                        색인 ON인 경로들을 크롤해 JSON-LD를 추출하고, 위 유의어·위키·연관진료를 합쳐
                        <code>search_index.json</code>을 생성합니다. 진료 내용이나 FAQ를 바꾼 뒤 1회 실행하세요.
                    </p>
                    <button class="btn_primary" id="buildBtn" onclick="runBuild()"><span class="material-symbols-outlined" style="font-size:14px;">play_arrow</span>인덱스 빌드 실행</button>
                    <div id="buildResult" style="margin-top:18px;"></div>
                </div>
            </div>
        </div>

    </main>
</div>

<!-- 크롤 모달 -->
<div class="modal-bd" id="crawlModal">
    <div class="modal-bx">
        <div class="modal-tt"><span>사이트 메뉴에서 진료 페이지 선택</span><button onclick="closeCrawl()" style="background:none;border:none;font-size:20px;color:#9999bb;cursor:pointer;">×</button></div>
        <div id="crawlStatus" style="font-size:13px;color:#4f46e5;margin-bottom:12px;"></div>
        <div id="crawlList"></div>
        <div class="modal-tt" style="margin-top:16px;margin-bottom:0;justify-content:flex-end;gap:8px;">
            <button class="btn_neutral" onclick="closeCrawl()">취소</button>
            <button class="btn_primary" id="applyCrawlBtn" onclick="applyCrawl()" disabled><span class="material-symbols-outlined" style="font-size:14px;">check</span>선택 적용</button>
        </div>
    </div>
</div>

<script>
function toast(m,t){var e=document.createElement('div');e.className='toast '+(t||'ok');e.innerHTML='<span class="material-symbols-outlined" style="font-size:16px;">'+(t==='error'?'error':'check_circle')+'</span>'+m;document.body.appendChild(e);setTimeout(function(){e.remove();},3000);}
function switchTab(t){document.querySelectorAll('.tab').forEach(function(b){b.classList.toggle('active',b.dataset.tab===t);});document.querySelectorAll('.tabpane').forEach(function(p){p.classList.toggle('active',p.id==='pane-'+t);});}

// ── 칩 입력 공용 (쉼표/엔터로 추가) ──
function kwAdd(ev,input){
    if(ev.key!=='Enter'&&ev.key!==','){return;}
    ev.preventDefault();
    var v=input.value.trim().replace(/,$/,'');
    if(!v)return;
    var box=input.parentElement.querySelector('.kw-chips,.rel-chips,.cue-chips,.symp-chips');
    var chip=document.createElement('span');chip.className='chip';
    chip.innerHTML=escapeHtml(v)+'<button onclick="kwDel(this)">×</button>';
    box.appendChild(chip);input.value='';
}
function kwDel(btn){btn.parentElement.remove();}
function chipsOf(card,sel){return [...card.querySelectorAll(sel+' .chip')].map(function(c){return c.firstChild.textContent.trim();});}
function escapeHtml(s){return s.replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}

// ── pain_words ──
function pwAdd(ev){if(ev.key!=='Enter'&&ev.key!==','){return;}ev.preventDefault();var i=document.getElementById('pw-input');var v=i.value.trim().replace(/,$/,'');if(!v)return;var c=document.createElement('span');c.className='chip';c.innerHTML=escapeHtml(v)+'<button onclick="pwDel(this)">×</button>';document.getElementById('pw-chips').appendChild(c);i.value='';}
function pwDel(b){b.parentElement.remove();}
async function savePainwords(){
    var words=[...document.querySelectorAll('#pw-chips .chip')].map(function(c){return c.firstChild.textContent.trim();});
    var r=await fetch('?action=painwords_save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({words:words})});
    var d=await r.json();toast(d.ok?'통증어 저장됨':'실패',d.ok?'ok':'error');
}

// ── 경로 카드: 유의어/위키/연관 저장 ──
async function saveKw(btn){
    var card=btn.closest('.path-card');
    var body={
        path:card.dataset.path,
        extra_keywords:chipsOf(card,'.kw-chips'),
        related:chipsOf(card,'.rel-chips'),
        wiki_title:card.querySelector('.wiki-title').value.trim(),
        wiki_url:card.querySelector('.wiki-url').value.trim(),
        wiki_text:card.querySelector('.wiki-text').value.trim(),
        cue_any:chipsOf(card,'.cue-chips'),
        icon:(card.querySelector('.pc-icon')||{value:''}).value.trim(),
    };
    var r=await fetch('?action=kw_save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    var d=await r.json();toast(d.ok?'저장됨':'실패: '+(d.err||''),d.ok?'ok':'error');
}

async function videoUpload(btn){
    var card=btn.closest('.path-card');
    var vf=card.querySelector('.vid-file'), pf=card.querySelector('.poster-file');
    if((!vf.files||!vf.files.length)&&(!pf.files||!pf.files.length)){toast('업로드할 파일을 선택하세요','error');return;}
    var fd=new FormData();
    fd.append('path',card.dataset.path);
    if(vf.files&&vf.files.length)fd.append('video',vf.files[0]);
    if(pf.files&&pf.files.length)fd.append('poster',pf.files[0]);
    btn.disabled=true;
    try{
        var r=await fetch('?action=video_upload',{method:'POST',body:fd});
        var d=await r.json();
        toast(d.ok?(d.done+' 업로드 완료'):('실패: '+(d.err||'')),d.ok?'ok':'error');
        if(d.ok)setTimeout(function(){location.reload();},700);
    }catch(e){toast('업로드 오류: '+e.message,'error');}
    btn.disabled=false;
}
async function videoDel(btn,kind){
    if(!confirm(kind==='video'?'이 진료의 hover 영상을 삭제할까요?':'포스터를 삭제할까요?'))return;
    var card=btn.closest('.path-card');
    var r=await fetch('?action=video_delete&kind='+kind+'&path='+encodeURIComponent(card.dataset.path));
    var d=await r.json();
    toast(d.ok?'삭제됨':'실패',d.ok?'ok':'error');
    if(d.ok)setTimeout(function(){location.reload();},600);
}

// ── Gemini AI 자동 채우기 (dict_manager 패턴 재활용) ──
var GEMINI_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=';
(function(){
    var k = localStorage.getItem('ss_gemini_key');
    var el = document.getElementById('ssApiKey');
    if(el){
        if(k) el.value = k;
        el.addEventListener('change',function(){ localStorage.setItem('ss_gemini_key', this.value.trim()); });
    }
})();
function ssGetKey(){ var el=document.getElementById('ssApiKey'); var k=el?el.value.trim():''; if(!k){toast('Gemini API 키를 입력하세요','error');} return k; }

async function ssCallGemini(sys, userText){
    var key=ssGetKey(); if(!key) throw new Error('no key');
    var res = await fetch(GEMINI_URL+key,{
        method:'POST', headers:{'Content-Type':'application/json'},
        body:JSON.stringify({
            system_instruction:{parts:[{text:sys}]},
            contents:[{role:'user',parts:[{text:userText}]}],
            generationConfig:{maxOutputTokens:8192, temperature:0.2, responseMimeType:'application/json'}
        })
    });
    var data=await res.json();
    if(data.error) throw new Error(data.error.message);
    var txt=data.candidates?.[0]?.content?.parts?.[0]?.text || '';
    return txt.replace(/^```json?\n?/i,'').replace(/\n?```$/,'').trim();
}

// 스마트서치 경로 보강용 SYS — 진료명을 보고 검색 보조 데이터 생성
var SS_FILL_SYS = `당신은 대한민국 치과 홈페이지 검색엔진의 색인 편집자입니다. 주어진 진료 페이지에 대해, 환자가 검색창에 입력할 법한 보조 검색어와 짧은 설명, 그리고 이 진료를 찾게 되는 증상 단서를 생성합니다.
## 규칙
- synonyms: 환자가 실제 칠 법한 유의어·구어·줄임말·흔한 오타 8~15개. (예: "임플란트" → "임플, 인공치아, 임플란트가격, 어금니임플란트, 임플란뜨")
- cue_any: 환자가 이 증상을 호소하면 이 진료가 후보가 될 만한 "증상 표현"을 **넉넉하게 12~20개**. 다음을 모두 포함:
  · 같은 뜻의 부위어 변형: 이/이빨/치아/어금니/앞니 등 (예: "이가 아파요"와 "이빨이 아파요"를 둘 다)
  · 통증/감각 표현 변형: 아파요/아픔/쑤셔요/욱신거려요/시려요/찌릿/불편해요
  · 부위+증상 조합 구어체: "씹을때 아파요", "찬물 시려요", "밤에 쑤셔요"
  · **너무 좁히지 말 것**: 이 진료만의 확정 증상이 아니라, 이 진료가 후보로 떠오를 만한 넓은 증상까지. (예: 신경치료면 "이가아파요"처럼 충치·신경치료 공통 증상도 포함)
- wiki_title: 이 진료를 대표하는 표준 용어 1개.
- wiki_text: 이 진료가 무엇인지 환자용 2~3문장 설명. 첫 문장은 "OOO은(는) ~이다" 정의형.
- 의료광고법(제56조) 준수: 최고/유일/완벽/100%/무통/완치/부작용없음 등 단정·과장 표현 금지. "통증을 줄이기 위한", "개선을 기대할 수 있는", "정밀한" 등 중립표현 사용.
- 특정 병원·가격·후기 언급 금지. 치과 맥락 우선.
## 출력 JSON만 (설명·코드펜스 금지)
{"synonyms":["..."],"cue_any":["증상표현 12~20개..."],"wiki_title":"표준용어","wiki_text":"정의 2~3문장"}`;

async function aiFillPath(btn){
    if(!ssGetKey())return;
    var card=btn.closest('.path-card');
    var path=card.dataset.path||'';
    var name=(card.querySelector('.pc-name-input')?.value||'').trim();
    var hint=name||path;
    if(!hint){toast('진료명이 비어있습니다','error');return;}
    var orig=btn.innerHTML; btn.disabled=true;
    btn.innerHTML='<span class="material-symbols-outlined spin" style="font-size:13px;">progress_activity</span>생성중';
    try{
        var txt=await ssCallGemini(SS_FILL_SYS, '진료 페이지: '+hint+'\n경로: '+path);
        var j=JSON.parse(txt);
        // 유의어 → kw-chips (중복 제외 추가)
        if(Array.isArray(j.synonyms)){
            var box=card.querySelector('.kw-chips');
            var existing=[...box.querySelectorAll('.chip')].map(function(c){return c.firstChild.textContent.trim();});
            j.synonyms.forEach(function(s){
                s=(s||'').trim(); if(!s||existing.indexOf(s)>=0)return;
                existing.push(s);
                var c=document.createElement('span');c.className='chip';
                c.innerHTML=escapeHtml(s)+'<button onclick="kwDel(this)">×</button>';
                box.appendChild(c);
            });
        }
        // 위키 제목/본문 (비어있을 때만 채움 — 기존 입력 보호)
        var wt=card.querySelector('.wiki-title'), wx=card.querySelector('.wiki-text');
        if(wt && j.wiki_title && !wt.value.trim()) wt.value=j.wiki_title;
        if(wx && j.wiki_text  && !wx.value.trim()) wx.value=j.wiki_text;
        // 증상 단서 → cue-chips (중복 제외 추가)
        if(Array.isArray(j.cue_any)){
            var cbox=card.querySelector('.cue-chips');
            var cexist=[...cbox.querySelectorAll('.chip')].map(function(c){return c.firstChild.textContent.trim();});
            j.cue_any.forEach(function(s){
                s=(s||'').trim(); if(!s||cexist.indexOf(s)>=0)return;
                cexist.push(s);
                var c=document.createElement('span');c.className='chip';
                c.innerHTML=escapeHtml(s)+'<button onclick="kwDel(this)">×</button>';
                cbox.appendChild(c);
            });
        }
        toast('AI 자동 채움 완료 (저장 눌러 반영)','ok');
    }catch(e){toast('생성 실패: '+e.message,'error');}
    finally{btn.disabled=false;btn.innerHTML=orig;}
}
async function togglePath(id){await fetch('?action=path_toggle&id='+id);location.reload();}
async function delPath(id){if(!confirm('이 경로를 삭제할까요? (유의어·위키도 함께 삭제)'))return;await fetch('?action=path_delete&id='+id);location.reload();}

// ── 탭2 AI 자동화 ─────────────────────────────────────────
// 탭1에 등록된 진료 목록을 [{path,name}] 형태로 수집 (AI 입력 재료)
function ssCollectProcedures(){
    var out=[];
    document.querySelectorAll('#pane-paths .path-card').forEach(function(card){
        var path=card.dataset.path||'';
        var name=(card.querySelector('.pc-name-input')?.value||'').trim();
        if(path) out.push({path:path, name:name||path});
    });
    return out;
}

var SS_RULES_SYS = `당신은 대한민국 치과 홈페이지 검색엔진의 "증상 → 진료 추론 규칙" 편집자입니다.
주어진 진료 페이지 목록을 보고, 환자가 증상을 문장으로 검색했을 때 어떤 진료를 후보로 띄울지 규칙을 만듭니다.

## 입력
진료 목록: [{path, name}] 형태.

## 규칙 생성 지침
- 각 규칙은 하나의 "증상 상황"을 대표합니다. (예: "이가 시릴 때", "잇몸에서 피가 날 때", "치아가 삐뚤 때")
- any: 그 증상을 나타내는 환자 구어 표현 6~14개. 부위어 변형(이/이빨/치아/어금니/앞니)과 감각 표현(아파요/시려요/쑤셔요/피나요/흔들려요) 조합을 넉넉히.
- paths: 그 증상에 해당하는 진료 경로를 입력 목록에서 골라 **우선순위 순서로** 배열. 앞이 가장 관련 높음. 1~3개.
- label: 규칙 이름 (예: "시린 증상", "잇몸 출혈", "치열 문제").
- with_pain: 통증이 반드시 동반돼야 하는 규칙이면 true, 아니면 false. (대부분 false)
- 입력 진료 목록에 없는 경로는 절대 만들지 마세요. paths는 반드시 입력의 path 중에서만.
- 교정 계열(인비절라인/성인·소아교정)은 "삐뚤다/튀어나왔다/벌어졌다/부정교합" 증상과 연결.
- 의료광고법(제56조): 규칙 label·표현에 최고/완치 등 과장 금지.
- 진료 6개 기준 규칙 5~9개 정도가 적당. 증상이 겹치면 여러 진료를 paths에 함께.

## 출력 JSON만 (설명·코드펜스 금지)
{"rules":[{"label":"...","any":["..."],"paths":["/sub/...php"],"with_pain":false}]}`;

async function aiGenRules(btn){
    if(!ssGetKey())return;
    var procs=ssCollectProcedures();
    if(!procs.length){toast('먼저 탭1에서 진료를 등록하세요','error');return;}
    var orig=btn.innerHTML; btn.disabled=true;
    btn.innerHTML='<span class="material-symbols-outlined spin" style="font-size:14px;">progress_activity</span>생성중';
    try{
        var txt=await ssCallGemini(SS_RULES_SYS, '진료 목록:\n'+JSON.stringify(procs,null,2));
        var j=JSON.parse(txt);
        if(!Array.isArray(j.rules)||!j.rules.length) throw new Error('규칙을 생성하지 못했습니다');
        var validPaths=procs.map(function(p){return p.path;});
        var added=0;
        j.rules.forEach(function(r){
            var paths=(r.paths||[]).filter(function(p){return validPaths.indexOf(p)>=0;});
            if(!paths.length) return; // 유효 경로 없는 규칙 스킵
            addSymRow({label:r.label||'', any:r.any||[], paths:paths, with_pain:!!r.with_pain});
            added++;
        });
        var em=document.getElementById('sym-empty'); if(em) em.remove();
        toast('AI가 규칙 '+added+'개 생성 — 확인 후 각 [규칙 저장] 클릭','ok');
    }catch(e){toast('생성 실패: '+e.message,'error');}
    finally{btn.disabled=false;btn.innerHTML=orig;}
}

// 개별 규칙 카드: 신호어를 AI로 보강 (paths·label 기준)
async function aiFillSym(btn){
    if(!ssGetKey())return;
    var card=btn.closest('.path-card');
    var label=(card.querySelector('.sym-label')?.value||'').trim();
    var paths=chipsOf(card,'.symp-chips');
    if(!label&&!paths.length){toast('규칙 이름이나 연결 진료를 먼저 입력하세요','error');return;}
    var orig=btn.innerHTML; btn.disabled=true;
    btn.innerHTML='<span class="material-symbols-outlined spin" style="font-size:13px;">progress_activity</span>';
    try{
        var sys='치과 검색 규칙의 "신호어(any)"를 생성합니다. 규칙 이름과 연결 진료를 보고, 환자가 그 증상을 검색창에 칠 법한 구어 표현 8~16개를 만드세요. 부위어 변형(이/이빨/치아/어금니/앞니)과 감각어(아파요/시려요/쑤셔요/피나요/흔들려요) 조합. 의료광고법 준수. 출력 JSON만: {"any":["..."]}';
        var txt=await ssCallGemini(sys, '규칙 이름: '+(label||'(없음)')+'\n연결 진료: '+paths.join(', '));
        var j=JSON.parse(txt);
        if(Array.isArray(j.any)){
            var box=card.querySelector('.cue-chips');
            var exist=[...box.querySelectorAll('.chip')].map(function(c){return c.firstChild.textContent.trim();});
            j.any.forEach(function(s){
                s=(s||'').trim(); if(!s||exist.indexOf(s)>=0)return; exist.push(s);
                var c=document.createElement('span');c.className='chip';
                c.innerHTML=escapeHtml(s)+'<button onclick="kwDel(this)">×</button>';
                box.appendChild(c);
            });
        }
        toast('신호어 채움 완료 (저장 눌러 반영)','ok');
    }catch(e){toast('생성 실패: '+e.message,'error');}
    finally{btn.disabled=false;btn.innerHTML=orig;}
}

async function aiExpandPainwords(btn){
    if(!ssGetKey())return;
    var box=document.getElementById('pw-chips');
    var cur=[...box.querySelectorAll('.chip')].map(function(c){return c.firstChild.textContent.trim();});
    var orig=btn.innerHTML; btn.disabled=true;
    btn.innerHTML='<span class="material-symbols-outlined spin" style="font-size:13px;">progress_activity</span>확장중';
    try{
        var sys='치과 검색엔진의 "통증어(pain_words)" 사전을 확장합니다. 환자가 통증·불편을 호소할 때 쓰는 한국어 구어 표현을 생성하세요. 예: 아파요, 쑤셔요, 욱신거려요, 시려요, 찌릿, 불편해요, 붓다, 얼얼하다. 기존 목록과 겹치지 않는 새 표현 위주로 15~25개. 출력 JSON만: {"words":["..."]}';
        var txt=await ssCallGemini(sys, '기존 통증어: '+(cur.join(', ')||'(없음)'));
        var j=JSON.parse(txt);
        if(Array.isArray(j.words)){
            var added=0;
            j.words.forEach(function(s){
                s=(s||'').trim(); if(!s||cur.indexOf(s)>=0)return; cur.push(s); added++;
                var c=document.createElement('span');c.className='chip';
                c.innerHTML=escapeHtml(s)+'<button onclick="kwDel(this)">×</button>';
                box.appendChild(c);
            });
            toast('통증어 '+added+'개 추가 — [통증어 저장] 클릭','ok');
        }
    }catch(e){toast('확장 실패: '+e.message,'error');}
    finally{btn.disabled=false;btn.innerHTML=orig;}
}

// ── 증상 규칙 ──
function ssChipHtml(v){return '<span class="chip">'+escapeHtml(v)+'<button onclick="kwDel(this)">×</button></span>';}
function addSymRow(prefill){
    prefill=prefill||{};
    var e=document.getElementById('sym-empty');if(e)e.remove();
    var label=prefill.label||'';
    var withPain=prefill.with_pain?'checked':'';
    var anyChips=(prefill.any||[]).map(ssChipHtml).join('');
    var pathChips=(prefill.paths||[]).map(ssChipHtml).join('');
    var html='<div class="path-card" data-id="0">'
      +'<div class="pc-head"><input class="form_input sym-label" style="max-width:280px;font-weight:700;" value="'+escapeHtml(label)+'" placeholder="규칙 이름 (예: 턱 통증)">'
      +'<div style="display:flex;gap:6px;align-items:center;flex:none;"><label style="font-size:12px;display:flex;align-items:center;gap:4px;cursor:pointer;"><input type="checkbox" class="sym-with" '+withPain+'>통증어 필요</label>'
      +'<button class="btn_del" onclick="this.closest(\'.path-card\').remove()"><span class="material-symbols-outlined" style="font-size:12px;">delete</span></button></div></div>'
      +'<div class="pc-grid"><div><label class="lab">신호어 (any) — 쉼표/엔터</label><input class="form_input cue-input" placeholder="단어 Enter" onkeydown="kwAdd(event,this)"><div class="cue-chips" style="margin-top:6px;">'+anyChips+'</div></div>'
      +'<div><label class="lab">연결 진료 경로 (paths) — 쉼표/엔터</label><input class="form_input symp-input" placeholder="/sub/...php Enter" onkeydown="kwAdd(event,this)"><div class="symp-chips" style="margin-top:6px;">'+pathChips+'</div></div></div>'
      +'<div style="margin-top:12px;display:flex;justify-content:flex-end;gap:8px;">'
      +'<button class="btn_sm" style="background:#7c3aed;color:#fff;" onclick="aiFillSym(this)" title="규칙 이름·진료 기준으로 신호어를 AI가 채웁니다"><span class="material-symbols-outlined" style="font-size:13px;">auto_awesome</span>AI 신호어</button>'
      +'<button class="btn_sm" style="background:#4f46e5;color:#fff;" onclick="saveSym(this)"><span class="material-symbols-outlined" style="font-size:13px;">save</span>규칙 저장</button></div></div>';
    document.getElementById('sym-list').insertAdjacentHTML('beforeend',html);
}
async function saveSym(btn){
    var card=btn.closest('.path-card');
    var body={
        id:parseInt(card.dataset.id)||0,
        label:card.querySelector('.sym-label').value.trim(),
        with_pain:card.querySelector('.sym-with').checked?1:0,
        cue_any:chipsOf(card,'.cue-chips'),
        paths:chipsOf(card,'.symp-chips'),
        sort:0,
    };
    if(!body.cue_any.length){toast('신호어를 1개 이상 입력하세요','error');return;}
    var r=await fetch('?action=sym_save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    var d=await r.json();
    if(d.ok){card.dataset.id=d.id;toast('규칙 저장됨','ok');}else toast('실패','error');
}
async function delSym(id,btn){
    if(id&&!confirm('이 규칙을 삭제할까요?'))return;
    if(id)await fetch('?action=sym_delete&id='+id);
    btn.closest('.path-card').remove();
}

// ── 크롤 모달 ──
async function openCrawl(){
    document.getElementById('crawlModal').classList.add('show');
    var st=document.getElementById('crawlStatus'),list=document.getElementById('crawlList');
    st.innerHTML='<span class="material-symbols-outlined spin" style="font-size:14px;vertical-align:-2px;">progress_activity</span> 사이트 메뉴 크롤링 중...';
    list.innerHTML='';document.getElementById('applyCrawlBtn').disabled=true;
    try{
        var r=await fetch('?action=crawl_menu');var d=await r.json();
        if(!d.ok){st.innerHTML='❌ '+d.err;return;}
        var sel=d.found.filter(function(f){return f.selectable;});
        st.innerHTML='발견 '+d.found.length+'개 링크 · 선택 가능 '+sel.length+'개 (체크해서 등록)';
        var html='';
        d.found.forEach(function(f,i){
            var reg=d.registered[f.path]?'<span class="cr-reg">등록됨</span>':'';
            html+='<div class="crawl-row '+(f.selectable?'':'disabled')+'">'
              +'<input type="checkbox" data-path="'+escapeHtml(f.path)+'" data-label="'+escapeHtml(f.label)+'" '+(f.selectable?'':'disabled')+(f.selectable&&!d.registered[f.path]?' checked':'')+' onchange="updApply()">'
              +'<div style="flex:1;min-width:0;"><div class="cr-label">'+escapeHtml(f.label)+'</div><div class="cr-path">'+escapeHtml(f.path)+'</div></div>'
              +reg+(f.reason?'<span class="cr-reason">'+escapeHtml(f.reason)+'</span>':'')+'</div>';
        });
        list.innerHTML=html||'<div class="empty">메뉴 링크를 찾지 못했습니다.</div>';
        updApply();
    }catch(e){st.innerHTML='❌ 오류: '+e.message;}
}
function closeCrawl(){document.getElementById('crawlModal').classList.remove('show');}
function updApply(){
    var n=document.querySelectorAll('#crawlList input[type=checkbox]:checked').length;
    document.getElementById('applyCrawlBtn').disabled=(n===0);
    document.getElementById('applyCrawlBtn').innerHTML='<span class="material-symbols-outlined" style="font-size:14px;">check</span>선택 적용 ('+n+')';
}
async function applyCrawl(){
    var items=[...document.querySelectorAll('#crawlList input[type=checkbox]:checked')].map(function(c){return {path:c.dataset.path,name:c.dataset.label};});
    if(!items.length)return;
    var r=await fetch('?action=register_paths',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({items:items})});
    var d=await r.json();
    if(d.ok){toast(d.count+'개 경로 등록됨','ok');setTimeout(function(){location.reload();},700);}else toast('실패','error');
}

// ── 마이그레이션 ──
async function runMigrate(){
    if(!confirm('기존 search_supplement.php · search_symptoms.php 데이터를 DB로 가져옵니다.\n(원본 파일은 삭제되지 않습니다)'))return;
    toast('가져오는 중...','ok');
    var r=await fetch('?action=migrate');var d=await r.json();
    if(d.ok){var rp=d.report;toast('유의어 '+rp.sup+'건 · 증상 '+rp.sym+'건 가져옴'+(rp.err.length?' (일부 경고)':''),'ok');setTimeout(function(){location.reload();},1000);}
    else toast('실패','error');
}

// ── 글로벌 원버튼: 모두 저장 + 빌드 / 전체 AI + 저장 + 빌드 ──
function gProg(pct, txt){
    var box=document.getElementById('globalProg');
    box.style.display='block';
    document.getElementById('globalProgFill').style.width=(pct*100).toFixed(0)+'%';
    document.getElementById('globalProgTxt').textContent=txt;
}
function gDone(txt){
    setTimeout(function(){ document.getElementById('globalProg').style.display='none'; }, 2500);
    document.getElementById('globalProgTxt').textContent=txt;
}
function gLockBtns(lock){
    ['btnSaveBuildAll','btnAiAll'].forEach(function(id){ var b=document.getElementById(id); if(b) b.disabled=lock; });
}

// 카드 1개를 저장 (saveKw의 순회용 버전 — 토스트 없이 결과만 반환)
async function gSaveCard(card){
    var body={
        path:card.dataset.path,
        extra_keywords:chipsOf(card,'.kw-chips'),
        related:chipsOf(card,'.rel-chips'),
        wiki_title:(card.querySelector('.wiki-title')||{value:''}).value.trim(),
        wiki_url:(card.querySelector('.wiki-url')||{value:''}).value.trim(),
        wiki_text:(card.querySelector('.wiki-text')||{value:''}).value.trim(),
        cue_any:chipsOf(card,'.cue-chips'),
        icon:(card.querySelector('.pc-icon')||{value:''}).value.trim(),
    };
    var r=await fetch('?action=kw_save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    var d=await r.json();
    return d.ok;
}

async function saveAndBuildAll(){
    var cards=[...document.querySelectorAll('#pane-paths .path-card')];
    if(!cards.length){toast('등록된 진료가 없습니다','error');return;}
    if(!confirm('등록된 진료 '+cards.length+'개를 모두 저장하고 인덱스를 다시 빌드합니다. 진행할까요?'))return;
    gLockBtns(true);
    try{
        for(var i=0;i<cards.length;i++){
            gProg(i/(cards.length+1), '저장 중... '+(i+1)+'/'+cards.length);
            await gSaveCard(cards[i]);
        }
        gProg(cards.length/(cards.length+1), '인덱스 빌드 중...');
        var r=await fetch('?action=build'); var d=await r.json();
        if(d.ok){ gProg(1,'✅ 완료 — 진료 '+cards.length+'개 저장 + 색인 '+(d.count||0)+'개'); toast('모두 저장 + 빌드 완료','ok'); }
        else { gDone('❌ 빌드 실패: '+(d.err||'')); toast('빌드 실패','error'); gLockBtns(false); return; }
        gDone('✅ 모두 저장 + 빌드 완료');
    }catch(e){ gDone('❌ 오류: '+e.message); toast('오류: '+e.message,'error'); }
    gLockBtns(false);
}

async function aiAllAndBuild(){
    if(!ssGetKey())return;
    var cards=[...document.querySelectorAll('#pane-paths .path-card')];
    if(!cards.length){toast('등록된 진료가 없습니다','error');return;}
    if(!confirm('진료 '+cards.length+'개를 AI로 자동완성한 뒤 모두 저장하고 빌드합니다.\n(기존에 입력된 내용은 유지되고 빈 곳 위주로 채워집니다)\n\nAI 호출이 진료 수만큼 발생합니다. 진행할까요?'))return;
    gLockBtns(true);
    var steps=cards.length*2+1; var done=0;
    try{
        // 1) 각 카드 AI 자동완성
        for(var i=0;i<cards.length;i++){
            var card=cards[i];
            var nm=(card.querySelector('.pc-name-input')?.value||'').trim()||card.dataset.path;
            gProg(done/steps, 'AI 자동완성... '+(i+1)+'/'+cards.length+' ('+nm+')'); done++;
            try{ await gAiFillCard(card); }catch(e){ /* 개별 실패는 건너뜀 */ }
        }
        // 2) 모두 저장
        for(var j=0;j<cards.length;j++){
            gProg(done/steps, '저장 중... '+(j+1)+'/'+cards.length); done++;
            await gSaveCard(cards[j]);
        }
        // 3) 빌드
        gProg(done/steps, '인덱스 빌드 중...');
        var r=await fetch('?action=build'); var d=await r.json();
        if(d.ok){ gProg(1,'✅ 완료 — AI 자동완성 + 저장 + 색인 '+(d.count||0)+'개'); toast('전체 AI + 저장 + 빌드 완료','ok'); }
        else { gDone('❌ 빌드 실패: '+(d.err||'')); toast('빌드 실패','error'); gLockBtns(false); return; }
        gDone('✅ 전체 AI 자동완성 + 저장 + 빌드 완료 (새로고침하면 채워진 내용이 보입니다)');
    }catch(e){ gDone('❌ 오류: '+e.message); toast('오류: '+e.message,'error'); }
    gLockBtns(false);
}

// aiFillPath의 순회용 버전 (버튼 애니메이션 없이 카드에 직접 채움)
async function gAiFillCard(card){
    var path=card.dataset.path||'';
    var name=(card.querySelector('.pc-name-input')?.value||'').trim();
    var hint=name||path;
    if(!hint) return;
    var txt=await ssCallGemini(SS_FILL_SYS, '진료 페이지: '+hint+'\n경로: '+path);
    var j=JSON.parse(txt);
    // 유의어
    if(Array.isArray(j.synonyms)){
        var box=card.querySelector('.kw-chips');
        var ex=[...box.querySelectorAll('.chip')].map(function(c){return c.firstChild.textContent.trim();});
        j.synonyms.forEach(function(s){ s=(s||'').trim(); if(!s||ex.indexOf(s)>=0)return; ex.push(s);
            var c=document.createElement('span');c.className='chip';c.innerHTML=escapeHtml(s)+'<button onclick="kwDel(this)">×</button>';box.appendChild(c); });
    }
    // 위키(빈 곳만)
    var wt=card.querySelector('.wiki-title'), wx=card.querySelector('.wiki-text');
    if(wt && j.wiki_title && !wt.value.trim()) wt.value=j.wiki_title;
    if(wx && j.wiki_text  && !wx.value.trim()) wx.value=j.wiki_text;
    // 증상단서
    if(Array.isArray(j.cue_any)){
        var cbox=card.querySelector('.cue-chips');
        var cex=[...cbox.querySelectorAll('.chip')].map(function(c){return c.firstChild.textContent.trim();});
        j.cue_any.forEach(function(s){ s=(s||'').trim(); if(!s||cex.indexOf(s)>=0)return; cex.push(s);
            var c=document.createElement('span');c.className='chip';c.innerHTML=escapeHtml(s)+'<button onclick="kwDel(this)">×</button>';cbox.appendChild(c); });
    }
}

// ── 빌드 ──
async function runBuild(){
    var btn=document.getElementById('buildBtn');btn.disabled=true;
    btn.innerHTML='<span class="material-symbols-outlined spin" style="font-size:14px;">progress_activity</span> 빌드 중...';
    var res=document.getElementById('buildResult');res.innerHTML='';
    try{
        var r=await fetch('?action=build');var d=await r.json();
        var html='<div class="card" style="border-color:'+(d.ok?'#bbf7d0':'#fecaca')+';"><div class="card_body">';
        html+='<b style="color:'+(d.ok?'#059669':'#dc2626')+';">'+(d.ok?'✅ 빌드 성공':'❌ 빌드 실패')+'</b><br>';
        html+='대상 '+d.target+'개 중 <b>'+d.count+'</b>개 색인 · 저장: '+(d.written?'<span style="color:#059669;">성공</span>':'<span style="color:#dc2626;">실패(쓰기권한 확인)</span>')+'<br>';
        html+='<code style="font-size:12px;color:#6b7280;">'+escapeHtml(d.path||'')+'</code>';
        if(d.report&&d.report.length){html+='<div style="margin-top:12px;">';d.report.forEach(function(rw){html+='<div class="report-row"><span class="rt '+rw[0]+'">'+(rw[0]==='error'?'제외':'경고')+'</span><span><code>'+escapeHtml(rw[1])+'</code> — '+escapeHtml(rw[2])+'</span></div>';});html+='</div>';}
        html+='</div></div>';
        res.innerHTML=html;
        toast(d.ok?'빌드 완료':'빌드 실패',d.ok?'ok':'error');
    }catch(e){res.innerHTML='<div class="empty">오류: '+e.message+'</div>';}
    finally{btn.disabled=false;btn.innerHTML='<span class="material-symbols-outlined" style="font-size:14px;">play_arrow</span>인덱스 빌드 실행';}
}
</script>
</body>
</html>
