<?php
/**
 * /newadm/board/qa_manager.php — 상담 문의 관리
 * - DB: dm_consult (clinic/qa_manager.php와 100% 공유, 분기 없음)
 * - 레이아웃/CSS: clinic/qa_manager.php와 동일 (clinic/_theme.php 컴포넌트 스타일 그대로 사용)
 * - 사이드바/인증: newadm 공용(../aside.php, ../_auth_check.php) 유지
 */
include_once('../_common.php');
include_once('../_auth_check.php');

/* ── dm_consult 보장 (없으면 생성) ───────────────────────── */
sql_query("CREATE TABLE IF NOT EXISTS `dm_consult` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(60) NOT NULL DEFAULT '',
  `phone` VARCHAR(40) NOT NULL DEFAULT '',
  `interest` VARCHAR(80) NOT NULL DEFAULT '',
  `call_time` VARCHAR(80) NOT NULL DEFAULT '',
  `inflow` VARCHAR(80) NOT NULL DEFAULT '',
  `content` TEXT NULL,
  `agree_privacy` TINYINT(1) NOT NULL DEFAULT 0,
  `agree_at` DATETIME NULL,
  `agree_marketing` TINYINT(1) NOT NULL DEFAULT 0,
  `status` VARCHAR(20) NOT NULL DEFAULT 'new',
  `memo` TEXT NULL,
  `handler` VARCHAR(60) NULL,
  `handled_at` DATETIME NULL,
  `is_read` TINYINT(1) NOT NULL DEFAULT 0,
  `reg_ip` VARCHAR(50) NULL,
  `created_at` DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", false);

/* ── reply_content 컬럼 보장 (고객 노출용 답변, memo와 별도) ───────────────────────── */
$col_chk = sql_fetch("SHOW COLUMNS FROM dm_consult LIKE 'reply_content'");
if (!$col_chk) {
    sql_query("ALTER TABLE dm_consult ADD COLUMN `reply_content` TEXT NULL AFTER `memo`", false);
    sql_query("ALTER TABLE dm_consult ADD COLUMN `reply_at` DATETIME NULL AFTER `reply_content`", false);
}

$STATUS = array('new'=>'신규','contacted'=>'연락완료','booked'=>'예약전환','hold'=>'보류','closed'=>'종결');
$adm_id = $_SESSION['adm_mb_id'];

/* ── AJAX: 상태/메모 저장 ───────────────────────── */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && (isset($_POST['action']) && $_POST['action'] === 'save_status')) {
    header('Content-Type: application/json; charset=utf-8');
    $id     = (int)(isset($_POST['id']) ? $_POST['id'] : 0);
    $status = isset($_POST['status']) ? $_POST['status'] : '';
    $memo   = trim(isset($_POST['memo']) ? $_POST['memo'] : '');
    $reply  = trim(isset($_POST['reply']) ? $_POST['reply'] : '');
    if (!$id || !isset($STATUS[$status])) {
        echo json_encode(array('ok'=>false,'msg'=>'잘못된 요청입니다.'), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        exit;
    }
    $memo_e  = sql_real_escape_string($memo);
    $hand_e  = sql_real_escape_string($adm_id);
    $reply_e = sql_real_escape_string($reply);
    $now     = G5_TIME_YMDHIS;

    $reply_sql = '';
    if ($reply !== '') $reply_sql = ", reply_content='$reply_e', reply_at='$now'";

    sql_query("UPDATE dm_consult SET status='".sql_real_escape_string($status)."', memo='$memo_e', handler='$hand_e', handled_at='$now', is_read=1 $reply_sql WHERE id='$id'");
    echo json_encode(array('ok'=>true,'status'=>$status,'status_label'=>$STATUS[$status],'handler'=>$adm_id,'handled_at'=>$now), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    exit;
}

/* ── AJAX: 읽음 처리 ───────────────────────── */
if (isset($_GET['action']) && $_GET['action'] === 'mark_read') {
    header('Content-Type: application/json; charset=utf-8');
    $id = (int)(isset($_GET['id']) ? $_GET['id'] : 0);
    if ($id) sql_query("UPDATE dm_consult SET is_read=1 WHERE id='$id'");
    echo json_encode(array('ok'=>true), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    exit;
}

/* ── 삭제 ───────────────────────── */
if (isset($_GET['del_id'])) {
    $del = (int)$_GET['del_id'];
    sql_query("DELETE FROM dm_consult WHERE id='$del'");
    alert_toast('문의가 삭제되었습니다.', './qa_manager.php');
}

/* ── 필터 (status 제외 = base) ───────────────────────── */
$st     = isset($_GET['st']) ? $_GET['st'] : '';
$iv     = trim(isset($_GET['iv']) ? $_GET['iv'] : '');
$search = trim(isset($_GET['search']) ? $_GET['search'] : '');
$from   = (isset($_GET['from']) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['from'])) ? $_GET['from'] : '';
$to     = (isset($_GET['to'])   && preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['to']))   ? $_GET['to']   : '';

$where_base = " WHERE 1=1 ";
if ($iv !== '') $where_base .= " AND interest = '".sql_real_escape_string($iv)."' ";
if ($from)      $where_base .= " AND created_at >= '".sql_real_escape_string($from)." 00:00:00' ";
if ($to)        $where_base .= " AND created_at <= '".sql_real_escape_string($to)." 23:59:59' ";
if ($search) {
    $s = sql_real_escape_string($search);
    $where_base .= " AND (name LIKE '%$s%' OR phone LIKE '%$s%' OR content LIKE '%$s%') ";
}
$where = $where_base;
if (isset($STATUS[$st])) $where .= " AND status = '".sql_real_escape_string($st)."' ";

/* ── CSV 내보내기 ───────────────────────── */
if (isset($_GET['action']) && $_GET['action'] === 'export') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=consult_'.date('Ymd_His').'.csv');
    echo "\xEF\xBB\xBF"; // UTF-8 BOM (엑셀 한글)
    $out = fopen('php://output', 'w');
    fputcsv($out, array('ID','상태','이름','연락처','관심진료','희망시간','유입','내용','마케팅동의','담당자','처리일시','접수일시'));
    $rs = sql_query("SELECT * FROM dm_consult $where ORDER BY created_at DESC");
    while ($r = sql_fetch_array($rs)) {
        $stl = isset($STATUS[$r['status']]) ? $STATUS[$r['status']] : $r['status'];
        fputcsv($out, array(
            $r['id'], $stl, $r['name'], $r['phone'], $r['interest'], $r['call_time'],
            $r['inflow'], $r['content'], ($r['agree_marketing'] ? 'Y' : 'N'),
            $r['handler'], $r['handled_at'], $r['created_at'],
        ));
    }
    fclose($out);
    exit;
}

/* ── 통계 (status 무관 base 기준) ───────────────────────── */
$cnt = array('new'=>0,'contacted'=>0,'booked'=>0,'hold'=>0,'closed'=>0);
$rs = sql_query("SELECT status, COUNT(*) AS c FROM dm_consult $where_base GROUP BY status");
while ($r = sql_fetch_array($rs)) { if (isset($cnt[$r['status']])) $cnt[$r['status']] = (int)$r['c']; }
$total_all = array_sum($cnt);
$u = sql_fetch("SELECT COUNT(*) AS cnt FROM dm_consult $where_base AND is_read = 0");
$unread = (int)(isset($u['cnt']) ? $u['cnt'] : 0);

/* 관심진료 목록 (필터 드롭다운) */
$interests = array();
$ri = sql_query("SELECT DISTINCT interest FROM dm_consult WHERE interest <> '' ORDER BY interest");
while ($r = sql_fetch_array($ri)) $interests[] = $r['interest'];

/* ── 목록 ───────────────────────── */
$list = sql_query("SELECT * FROM dm_consult $where ORDER BY created_at DESC LIMIT 0, 200");
$list_count = sql_num_rows($list);

/* 현재 필터 유지용 쿼리스트링 */
function clinic_qs($override = array()) {
    $base = array(
        'st'     => isset($_GET['st'])     ? $_GET['st']     : '',
        'iv'     => isset($_GET['iv'])     ? $_GET['iv']     : '',
        'from'   => isset($_GET['from'])   ? $_GET['from']   : '',
        'to'     => isset($_GET['to'])     ? $_GET['to']     : '',
        'search' => isset($_GET['search']) ? $_GET['search'] : '',
    );
    $q = array_merge($base, $override);
    $q = array_filter($q, function($v){ return $v !== ''; });
    return $q ? '?'.http_build_query($q) : '?';
}
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>상담 문의 관리</title>
    <?php include_once(__DIR__ . '/../../clinic/_theme.php'); ?>
</head>
<body>
<div id="admin_wrapper">
    <?php include_once('../aside.php'); ?>

    <main class="content_area">
        <div class="page_header">
            <h2 class="page_title">문의 관리<small>상담 접수 확인 · 상태 변경 · 담당 메모</small></h2>
            <a class="c-btn" href="./qa_manager.php<?= clinic_qs(array('action'=>'export')) ?>">⬇ CSV 내보내기</a>
        </div>

        <!-- 통계 -->
        <div class="stat_row">
            <div class="stat hl"><div class="n"><?= $unread ?></div><div class="l">미확인</div></div>
            <div class="stat"><div class="n"><?= $cnt['new'] ?></div><div class="l">신규</div></div>
            <div class="stat"><div class="n"><?= $cnt['contacted'] ?></div><div class="l">연락완료</div></div>
            <div class="stat"><div class="n"><?= $cnt['booked'] ?></div><div class="l">예약전환</div></div>
            <div class="stat"><div class="n"><?= $total_all ?></div><div class="l">전체</div></div>
        </div>

        <!-- 상태 칩 -->
        <div class="chips">
            <a class="chip <?= $st===''?'on':'' ?>" href="./qa_manager.php<?= clinic_qs(array('st'=>'')) ?>">전체</a>
            <?php foreach ($STATUS as $k=>$label): ?>
            <a class="chip <?= $st===$k?'on':'' ?>" href="./qa_manager.php<?= clinic_qs(array('st'=>$k)) ?>"><?= $label ?> <?= $cnt[$k] ?></a>
            <?php endforeach; ?>
        </div>

        <!-- 검색/필터 -->
        <form method="get" class="filter_bar">
            <input type="hidden" name="st" value="<?= htmlspecialchars($st) ?>">
            <input type="text" name="search" class="search_input" placeholder="이름·연락처·내용 검색…" value="<?= htmlspecialchars($search) ?>">
            <select name="iv" class="f_sel">
                <option value="">관심진료 전체</option>
                <?php foreach ($interests as $it): ?>
                <option value="<?= htmlspecialchars($it) ?>" <?= $iv===$it?'selected':'' ?>><?= htmlspecialchars($it) ?></option>
                <?php endforeach; ?>
            </select>
            <input type="date" name="from" class="f_date" value="<?= htmlspecialchars($from) ?>">
            <span style="color:var(--muted);">~</span>
            <input type="date" name="to" class="f_date" value="<?= htmlspecialchars($to) ?>">
            <button type="submit" class="c-btn c-btn-pri">적용</button>
            <a href="./qa_manager.php" class="c-btn">초기화</a>
        </form>

        <!-- 목록 -->
        <div class="c-card">
            <div class="card_meta"><span>조회 <strong><?= $list_count ?></strong>건 <?= $list_count>=200?'(최근 200건)':'' ?></span></div>
            <div class="table_wrap">
                <table class="c-tbl">
                    <thead>
                        <tr>
                            <th>상태</th>
                            <th>관심진료</th>
                            <th>문의자 / 연락처</th>
                            <th>문의 내용</th>
                            <th>접수일시</th>
                            <th style="text-align:center;">관리</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i = 0;
                        while ($row = sql_fetch_array($list)) {
                            $i++;
                            $stk     = isset($STATUS[$row['status']]) ? $row['status'] : 'new';
                            $summary = mb_strimwidth(strip_tags((string)$row['content']), 0, 50, '…', 'utf-8');
                            $safe    = htmlspecialchars(json_encode($row, JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8');
                        ?>
                        <tr class="<?= $row['is_read'] ? '' : 'unread' ?>">
                            <td><span class="st st-<?= $stk ?>"><?= $STATUS[$stk] ?></span></td>
                            <td><span class="cat_badge"><?= htmlspecialchars($row['interest'] ?: '문의') ?></span></td>
                            <td>
                                <div class="td_name"><?= $row['is_read'] ? '' : '<span class="dot_new"></span>' ?><?= htmlspecialchars($row['name']) ?></div>
                                <div class="td_phone"><?= htmlspecialchars($row['phone']) ?></div>
                            </td>
                            <td><div class="preview"><?= htmlspecialchars($summary) ?></div></td>
                            <td class="td_date"><?= substr($row['created_at'], 0, 16) ?></td>
                            <td>
                                <div class="td_actions">
                                    <button type="button" onclick='viewInquiry(<?= $safe ?>)' class="c-btn c-btn-pri c-btn-sm">상세</button>
                                    <a href="?del_id=<?= $row['id'] ?>" onclick="return confirm('정말 삭제하시겠습니까?')" class="c-btn c-btn-danger c-btn-sm">삭제</a>
                                </div>
                            </td>
                        </tr>
                        <?php } ?>
                        <?php if ($i === 0): ?>
                        <tr class="empty_row"><td colspan="6">문의 내역이 없습니다.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</div>

<!-- 상세 모달 -->
<div class="c-modal-overlay" id="viewModal">
    <div class="c-modal-box">
        <div class="cm_hd">
            <h3>문의 상세</h3>
            <button class="cm_close" onclick="closeModal()">✕</button>
        </div>
        <div class="cm_bd">
            <div class="cm_grid">
                <div class="cm_row"><label>이름</label><div class="val" id="v_name"></div></div>
                <div class="cm_row"><label>관심진료</label><div class="val" id="v_interest"></div></div>
            </div>
            <div class="cm_grid">
                <div class="cm_row"><label>연락처</label><div class="val" id="v_phone"></div></div>
                <div class="cm_row"><label>희망 연락시간</label><div class="val" id="v_calltime"></div></div>
            </div>
            <div class="cm_grid">
                <div class="cm_row"><label>유입경로</label><div class="val" id="v_inflow"></div></div>
                <div class="cm_row"><label>마케팅 수신</label><div class="val" id="v_mkt"></div></div>
            </div>
            <div class="cm_row">
                <label>문의 내용</label>
                <div class="cm_content" id="v_content"></div>
            </div>
            <div class="cm_grid">
                <div class="cm_row">
                    <label>처리 상태</label>
                    <select class="cm_sel" id="m_status">
                        <?php foreach ($STATUS as $k=>$label): ?>
                        <option value="<?= $k ?>"><?= $label ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="cm_row">
                    <label>최근 처리</label>
                    <div class="val" id="v_handled" style="font-size:13px;color:var(--muted);font-weight:600;">-</div>
                </div>
            </div>
            <div class="cm_row">
                <label>담당 메모 <span style="font-weight:400;color:var(--muted);">(내부 전용, 고객 비노출)</span></label>
                <textarea class="cm_ta" id="m_memo" placeholder="상담 내용·다음 액션 등 메모…"></textarea>
            </div>
            <div class="cm_row">
                <label>고객 답변 <span style="font-weight:400;color:var(--muted);">(조회 페이지에 그대로 노출됨)</span></label>
                <textarea class="cm_ta" id="m_reply" placeholder="고객이 조회 페이지에서 볼 답변을 입력하세요…"></textarea>
                <div class="val" id="v_reply_meta" style="font-size:12px;color:var(--muted);margin-top:4px;"></div>
            </div>
        </div>
        <div class="cm_ft">
            <button class="c-btn" onclick="copyPhone()">📱 번호 복사</button>
            <span class="grow"></span>
            <button class="c-btn c-btn-pri" onclick="saveStatus()">저장</button>
        </div>
    </div>
</div>

<div class="toast_msg" id="toast"></div>

<script>
let currentData = null;
const STATUS_LABEL = <?= json_encode($STATUS, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>;

function showToast(msg){
    const t = document.getElementById('toast');
    t.textContent = msg; t.classList.add('show');
    setTimeout(()=>t.classList.remove('show'), 2200);
}

window.viewInquiry = function(data){
    currentData = data;
    document.getElementById('v_name').textContent     = data.name || '';
    document.getElementById('v_interest').textContent = data.interest || '-';
    document.getElementById('v_phone').textContent    = data.phone || '';
    document.getElementById('v_calltime').textContent = data.call_time || '-';
    document.getElementById('v_inflow').textContent   = data.inflow || '-';
    document.getElementById('v_mkt').textContent      = (data.agree_marketing == 1 ? '동의' : '미동의');
    document.getElementById('v_content').textContent  = data.content || '';
    document.getElementById('m_status').value         = data.status || 'new';
    document.getElementById('m_memo').value           = data.memo || '';
    document.getElementById('m_reply').value          = data.reply_content || '';
    document.getElementById('v_reply_meta').textContent = data.reply_at ? ('마지막 답변: ' + data.reply_at) : '아직 답변 없음';
    document.getElementById('v_handled').textContent  = data.handled_at ? (data.handled_at + ' / ' + (data.handler||'')) : '미처리';
    document.getElementById('viewModal').classList.add('active');

    // 읽음 처리 (badge 즉시 반영은 새로고침 시)
    if (data.is_read != 1) {
        fetch('./qa_manager.php?action=mark_read&id=' + data.id).catch(()=>{});
    }
};

function saveStatus(){
    if (!currentData) return;
    const fd = new FormData();
    fd.append('action','save_status');
    fd.append('id', currentData.id);
    fd.append('status', document.getElementById('m_status').value);
    fd.append('memo', document.getElementById('m_memo').value);
    fd.append('reply', document.getElementById('m_reply').value);
    fetch('./qa_manager.php', { method:'POST', body:fd })
        .then(r=>r.json())
        .then(j=>{
            if (j.ok) { showToast('저장되었습니다.'); setTimeout(()=>location.reload(), 650); }
            else showToast(j.msg || '저장 실패');
        })
        .catch(()=>showToast('통신 오류'));
}

function copyPhone(){
    if (!currentData) return;
    const num = (currentData.phone || '').replace(/[^0-9]/g,'');
    navigator.clipboard.writeText(num)
        .then(()=>showToast('전화번호가 복사되었습니다.'))
        .catch(()=>showToast('복사 실패'));
}

function closeModal(){ document.getElementById('viewModal').classList.remove('active'); }
document.getElementById('viewModal').addEventListener('click', function(e){ if (e.target === this) closeModal(); });
document.addEventListener('keydown', function(e){ if (e.key === 'Escape') closeModal(); });
</script>
</body>
</html>
