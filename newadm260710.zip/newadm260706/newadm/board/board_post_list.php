<?php
// newadm/board/board_post_list.php
// 그누보드 DB(g5_write_XXX / {bo_table}_category / board_new_table / board_file_table)에서 분리.
// dm_posts(공용 글 테이블, bo_table로 구분) + dm_board_categories(공용 카테고리 테이블) 사용.
//
// 글쓰기/수정: 페이지 이동 없이 이 화면의 모달(CKEditor)에서 처리하고, 저장은
//              같은 newadm 안의 post_write.php로 fetch(POST)만 보낸다(취소 버튼으로만 닫힘).
// 보기: 관리자용이 아니라 실사용자가 보는 프론트 페이지 /sub/board/post_view.php로 새 탭에서 이동.

include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/_common.php');
include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/_auth_check.php');

// 카테고리 추가 처리
if (isset($_POST['add_category']) && $_POST['bo_table'] && $is_admin) {
    $bo_table      = preg_replace('/[^a-z0-9_]/i', '', $_POST['bo_table']);
    $category_name = sql_real_escape_string(trim($_POST['category_name']));
    if ($category_name) {
        sql_query("INSERT INTO dm_board_categories (bo_table, ca_name, ca_order, created_at) VALUES ('{$bo_table}', '{$category_name}', 0, NOW())");
        alert_toast('카테고리가 추가되었습니다.', "./board_post_list.php?bo_table=$bo_table");
        exit;
    }
}

// 카테고리 삭제 처리
if (isset($_GET['delete_category']) && $_GET['bo_table'] && $is_admin) {
    $bo_table = preg_replace('/[^a-z0-9_]/i', '', $_GET['bo_table']);
    $ca_id    = (int)$_GET['delete_category'];
    sql_query("DELETE FROM dm_board_categories WHERE id = '{$ca_id}' AND bo_table = '{$bo_table}'");
    // 이 카테고리를 쓰던 글들은 미분류(0)로 되돌림
    sql_query("UPDATE dm_posts SET category_id = 0 WHERE bo_table = '{$bo_table}' AND category_id = '{$ca_id}'");
    alert_toast('카테고리가 삭제되었습니다.', "./board_post_list.php?bo_table=$bo_table");
    exit;
}

// 게시글 삭제 처리
if (isset($_GET['delete_wr_id']) && $_GET['bo_table']) {
    $delete_id = (int)$_GET['delete_wr_id'];
    $bo_table  = preg_replace('/[^a-z0-9_]/i', '', $_GET['bo_table']);
    if ($is_admin) {
        sql_query("DELETE FROM dm_posts WHERE id = '{$delete_id}' AND bo_table = '{$bo_table}'");
        alert_toast('삭제가 완료되었습니다.', "./board_post_list.php?bo_table=$bo_table");
        exit;
    }
}

$bo_table = preg_replace('/[^a-z0-9_]/i', '', $_GET['bo_table']);

$board = sql_fetch("SELECT * FROM dm_boards WHERE bo_table = '{$bo_table}'");
if (!$board['bo_table']) alert_toast('게시판이 없습니다.');

// 카테고리 목록
$categories      = [];
$category_result = sql_query("SELECT * FROM dm_board_categories WHERE bo_table = '{$bo_table}' ORDER BY ca_order ASC, id ASC");
if ($category_result) while ($cat = sql_fetch_array($category_result)) $categories[] = $cat;

$selected_category = isset($_GET['category']) ? (int)$_GET['category'] : 0;

// 게시글 목록
$where = "WHERE bo_table = '{$bo_table}'";
if ($selected_category > 0) $where .= " AND category_id = '{$selected_category}'";
$result = sql_query("SELECT * FROM dm_posts {$where} ORDER BY id DESC LIMIT 0, 12");
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($board['bo_subject']) ?> 관리</title>
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Pretendard', 'Apple SD Gothic Neo', sans-serif; background: #f5f6fa; color: #1a1a2e; }
        #admin_wrapper { display: flex; min-height: 100vh; }
        .content_area { flex: 1; padding: 40px; overflow-x: hidden; }

        /* 상단 헤더 */
        .page_header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 28px; }
        .page_title { font-size: 22px; font-weight: 700; color: #1a1a2e; }
        .btn_write {
            padding: 10px 20px; background: #4f46e5; color: #fff; border-radius: 8px;
            font-size: 13px; font-weight: 700; text-decoration: none; border: none; cursor: pointer;
            box-shadow: 0 4px 12px rgba(79,70,229,0.25); transition: all 0.2s;
        }
        .btn_write:hover { background: #4338ca; transform: translateY(-1px); }

        /* 카드 */
        .card { background: #fff; border-radius: 12px; box-shadow: 0 2px 12px rgba(0,0,0,0.07); border: 1px solid #e8eaf0; padding: 24px; margin-bottom: 24px; }
        .card_title { font-size: 15px; font-weight: 700; color: #1a1a2e; margin-bottom: 16px; }

        /* 카테고리 탭 */
        .category_tabs { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 16px; }
        .cat_tab {
            padding: 7px 16px; border-radius: 20px; font-size: 13px; font-weight: 600;
            text-decoration: none; background: #f5f6fa; color: #5c5c7a;
            border: 1px solid #e8eaf0; transition: all 0.2s; display: flex; align-items: center; gap: 6px;
        }
        .cat_tab:hover { background: #ede9fe; color: #4f46e5; border-color: #c4b5fd; }
        .cat_tab.active { background: #4f46e5; color: #fff; border-color: #4f46e5; }
        .cat_tab.active .del_cat { background: rgba(255,255,255,0.25); }
        .del_cat {
            width: 16px; height: 16px; border-radius: 50%; background: rgba(0,0,0,0.1);
            display: flex; align-items: center; justify-content: center;
            font-size: 10px; font-weight: 900; cursor: pointer; transition: all 0.2s;
        }
        .del_cat:hover { background: #ef4444; color: #fff; }

        /* 카테고리 추가 폼 */
        .cat_add_form { display: flex; gap: 10px; padding-top: 16px; border-top: 1px solid #e8eaf0; margin-top: 4px; }
        .cat_input {
            flex: 1; height: 40px; border: 1px solid #e8eaf0; border-radius: 8px;
            padding: 0 14px; font-size: 13px; background: #f5f6fa; transition: all 0.2s;
        }
        .cat_input:focus { outline: none; border-color: #4f46e5; background: #fff; box-shadow: 0 0 0 3px rgba(79,70,229,0.1); }
        .btn_cat_add {
            height: 40px; padding: 0 18px; background: #4f46e5; color: #fff;
            border: none; border-radius: 8px; font-size: 13px; font-weight: 700; cursor: pointer; transition: all 0.2s;
        }
        .btn_cat_add:hover { background: #4338ca; }

        /* 게시글 목록 테이블 (이미지 없이) */
        .table_wrap { overflow-x: auto; }
        .post_table { width: 100%; border-collapse: collapse; min-width: 720px; }
        .post_table thead th {
            background: #f5f6fa; padding: 12px 14px; font-size: 12px; font-weight: 700;
            color: #9999bb; text-align: left; border-bottom: 2px solid #e8eaf0; white-space: nowrap;
        }
        .post_table tbody td {
            padding: 13px 14px; font-size: 14px; color: #444466;
            border-bottom: 1px solid #f5f6fa; vertical-align: middle;
        }
        .post_table tbody tr:last-child td { border-bottom: none; }
        .post_table tbody tr:hover td { background: #fafafa; }
        .td_subject { font-weight: 700; color: #1a1a2e; }

        .post_cat_badge {
            display: inline-block; padding: 3px 10px; background: #ede9fe;
            color: #4f46e5; border-radius: 20px; font-size: 11px; font-weight: 700;
        }

        .td_actions { display: flex; gap: 6px; justify-content: flex-end; }
        .btn_view, .btn_edit {
            display: inline-block; padding: 6px 14px; border-radius: 7px;
            font-size: 13px; font-weight: 700; text-decoration: none; transition: all 0.2s;
            border: none; cursor: pointer;
        }
        .btn_view { background: #4f46e5; color: #fff; }
        .btn_view:hover { background: #4338ca; }
        .btn_edit { background: #f5f6fa; color: #5c5c7a; border: 1px solid #e8eaf0; }
        .btn_edit:hover { background: #e8eaf0; color: #1a1a2e; }
        .btn_del_post {
            width: 30px; padding: 6px 0; border-radius: 7px; background: #fee2e2; color: #dc2626;
            border: 1px solid #fecaca; cursor: pointer; font-size: 13px; transition: all 0.2s;
        }
        .btn_del_post:hover { background: #fecaca; }

        .empty_state { text-align: center; padding: 48px 20px; color: #9999bb; font-size: 14px; }
    </style>
</head>
<body>
<div id="admin_wrapper">
    <?php include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/aside.php'); ?>

    <main class="content_area">

        <div class="page_header">
            <h2 class="page_title"><?= htmlspecialchars($board['bo_subject']) ?> 목록</h2>
            <button type="button" class="btn_write" onclick="openAddModal()">+ 새 글쓰기</button>
        </div>

        <!-- 카테고리 관리 -->
        <div class="card">
            <p class="card_title">카테고리 관리</p>
            <div class="category_tabs">
                <a href="?bo_table=<?= $bo_table ?>" class="cat_tab <?= $selected_category == 0 ? 'active' : '' ?>">전체</a>
                <?php foreach ($categories as $cat): ?>
                <a href="?bo_table=<?= $bo_table ?>&category=<?= $cat['id'] ?>"
                   class="cat_tab <?= $selected_category == $cat['id'] ? 'active' : '' ?>">
                    <?= htmlspecialchars($cat['ca_name']) ?>
                    <span class="del_cat" onclick="event.preventDefault(); delete_category(<?= $cat['id'] ?>)">✕</span>
                </a>
                <?php endforeach; ?>
            </div>

            <form method="post" class="cat_add_form">
                <input type="hidden" name="bo_table" value="<?= $bo_table ?>">
                <input type="text" name="category_name" placeholder="새 카테고리 이름" required class="cat_input">
                <button type="submit" name="add_category" class="btn_cat_add">+ 추가</button>
            </form>
        </div>

        <!-- 게시글 목록: 이미지 없이 테이블 형태 -->
        <div class="card">
            <p class="card_title">게시글 목록</p>
            <div class="table_wrap">
                <table class="post_table">
                    <thead>
                        <tr>
                            <th style="width:70px;">번호</th>
                            <th>제목</th>
                            <th style="width:120px;">카테고리</th>
                            <th style="width:110px;">작성자</th>
                            <th style="width:110px;">작성일</th>
                            <th style="width:70px; text-align:center;">조회</th>
                            <th style="width:150px; text-align:right;">관리</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $post_count = 0;
                        while ($row = sql_fetch_array($result)) {
                            $post_count++;

                            $cat_name = '';
                            if (!empty($row['category_id'])) {
                                $cat = sql_fetch("SELECT ca_name FROM dm_board_categories WHERE id = '{$row['category_id']}'");
                                if ($cat) $cat_name = $cat['ca_name'];
                            }
                            // 수정 모달을 채울 때 쓸 데이터 (media_manager.php와 동일한 패턴)
                            $row_json = htmlspecialchars(json_encode($row, JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8');
                        ?>
                        <tr>
                            <td><?= (int)$row['id'] ?></td>
                            <td class="td_subject"><?= htmlspecialchars(mb_strimwidth(strip_tags($row['subject']), 0, 60, '...')) ?></td>
                            <td><?php if ($cat_name): ?><span class="post_cat_badge"><?= htmlspecialchars($cat_name) ?></span><?php endif; ?></td>
                            <td><?= htmlspecialchars($row['writer_name']) ?></td>
                            <td><?= substr($row['created_at'], 0, 10) ?></td>
                            <td style="text-align:center;"><?= number_format($row['hit']) ?></td>
                            <td>
                                <div class="td_actions">
                                    <!-- 프론트(실사용자용) 보기 페이지: /sub/board/post_view.php -->
                                    <a href="/sub/board/post_view.php?bo_table=<?= $bo_table ?>&id=<?= $row['id'] ?>" target="_blank" class="btn_view">보기</a>
                                    <button type="button" class="btn_edit" onclick='openEditModal(<?= $row_json ?>)'>수정</button>
                                    <button type="button" class="btn_del_post" onclick="delete_post('<?= $row['id'] ?>')" title="삭제">✕</button>
                                </div>
                            </td>
                        </tr>
                        <?php } ?>
                        <?php if ($post_count === 0): ?>
                        <tr><td colspan="7" class="empty_state">등록된 게시글이 없습니다.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </main>
</div>

<!-- 글쓰기/수정 모달: 취소 버튼으로만 닫힘. 바깥(오버레이) 클릭으로는 절대 안 닫힘 -->
<div class="modal_overlay" id="postModal">
    <div class="modal_box">
        <div class="modal_hd">
            <h3 id="postModalTitle">새 글쓰기</h3>
        </div>
        <div class="modal_bd">
            <input type="hidden" id="post_id" value="">
            <input type="hidden" id="post_bo_table" value="<?= htmlspecialchars($bo_table) ?>">

            <div class="form_group">
                <label>제목</label>
                <input type="text" id="post_subject" class="form_input" required>
            </div>

            <div class="form_grid2">
                <div class="form_group">
                    <label>작성자</label>
                    <input type="text" id="post_writer_name" class="form_input">
                </div>
                <div class="form_group">
                    <label>카테고리</label>
                    <select id="post_category_id" class="form_input">
                        <option value="0">미분류</option>
                        <?php foreach ($categories as $cat): ?>
                        <option value="<?= $cat['id'] ?>"><?= htmlspecialchars($cat['ca_name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="form_group">
                <label>썸네일 이미지 URL (선택, 비워두면 본문 첫 이미지를 자동으로 씀)</label>
                <input type="text" id="post_thumbnail" class="form_input" placeholder="https://">
            </div>

            <div class="form_group">
                <label>내용</label>
                <textarea id="post_content_editor"></textarea>
            </div>
        </div>
        <div class="modal_ft">
            <button type="button" class="btn_modal_cancel" onclick="closePostModal()">취소</button>
            <button type="button" class="btn_modal_submit" onclick="submitPostModal()">저장</button>
        </div>
    </div>
</div>

<style>
    /* ── 모달 ── */
    .modal_overlay { display:none; position:fixed; inset:0; background:rgba(0,0,0,0.55); z-index:10000; align-items:flex-start; justify-content:center; padding:40px 20px; overflow-y:auto; }
    .modal_overlay.active { display:flex; }
    .modal_box { background:#fff; border-radius:14px; width:100%; max-width:720px; overflow:hidden; margin:auto; }
    .modal_hd { padding:20px 24px; border-bottom:1px solid #e8eaf0; }
    .modal_hd h3 { font-size:16px; font-weight:700; }
    .modal_bd { padding:24px; display:flex; flex-direction:column; gap:14px; max-height:75vh; overflow-y:auto; }
    .form_group label { display:block; font-size:12px; font-weight:700; color:#9999bb; margin-bottom:6px; }
    .form_input { width:100%; border:1px solid #e8eaf0; border-radius:8px; padding:10px 14px; font-size:14px; background:#f5f6fa; font-family:inherit; transition:all .2s; }
    .form_input:focus { outline:none; border-color:#4f46e5; background:#fff; box-shadow:0 0 0 3px rgba(79,70,229,0.1); }
    .form_grid2 { display:grid; grid-template-columns:1fr 1fr; gap:14px; }
    .modal_ft { padding:16px 24px; border-top:1px solid #e8eaf0; display:grid; grid-template-columns:1fr 1fr; gap:10px; }
    .btn_modal_cancel { padding:12px; border-radius:8px; background:#f5f6fa; color:#5c5c7a; border:1px solid #e8eaf0; font-size:14px; font-weight:700; cursor:pointer; }
    .btn_modal_submit { padding:12px; border-radius:8px; background:#4f46e5; color:#fff; border:none; font-size:14px; font-weight:700; cursor:pointer; }
    .btn_modal_submit:hover { background:#4338ca; }
</style>

<!-- CKEditor (내용 작성용) -->
<script src="https://cdn.ckeditor.com/ckeditor5/41.3.1/classic/ckeditor.js"></script>

<script>
let postEditor = null;
ClassicEditor.create(document.getElementById('post_content_editor'))
    .then(editor => { postEditor = editor; })
    .catch(err => console.error(err));

function openAddModal() {
    document.getElementById('postModalTitle').textContent = '새 글쓰기';
    document.getElementById('post_id').value = '';
    document.getElementById('post_subject').value = '';
    document.getElementById('post_writer_name').value = '';
    document.getElementById('post_category_id').value = '0';
    document.getElementById('post_thumbnail').value = '';
    if (postEditor) postEditor.setData('');
    document.getElementById('postModal').classList.add('active');
}

function openEditModal(data) {
    document.getElementById('postModalTitle').textContent = '글 수정';
    document.getElementById('post_id').value = data.id;
    document.getElementById('post_subject').value = data.subject || '';
    document.getElementById('post_writer_name').value = data.writer_name || '';
    document.getElementById('post_category_id').value = data.category_id || '0';
    document.getElementById('post_thumbnail').value = data.thumbnail || '';
    if (postEditor) postEditor.setData(data.content || '');
    document.getElementById('postModal').classList.add('active');
}

// 취소 버튼을 눌러야만 닫힌다 — 오버레이 바깥 클릭으로 닫히는 핸들러는 일부러 넣지 않음
function closePostModal() {
    document.getElementById('postModal').classList.remove('active');
}

function submitPostModal() {
    const subject = document.getElementById('post_subject').value.trim();
    if (!subject) { alert('제목을 입력해주세요.'); return; }

    const fd = new FormData();
    fd.append('id', document.getElementById('post_id').value);
    fd.append('bo_table', document.getElementById('post_bo_table').value);
    fd.append('subject', subject);
    fd.append('writer_name', document.getElementById('post_writer_name').value);
    fd.append('category_id', document.getElementById('post_category_id').value);
    fd.append('thumbnail', document.getElementById('post_thumbnail').value);
    fd.append('content', postEditor ? postEditor.getData() : '');

    fetch('./post_write.php', { method: 'POST', body: fd })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert(data.message || '저장에 실패했습니다.');
            }
        })
        .catch(() => alert('저장 중 오류가 발생했습니다.'));
}

function delete_post(id) {
    if (confirm('정말 이 게시글을 삭제하시겠습니까?\n삭제된 데이터는 복구할 수 없습니다.')) {
        location.href = "?bo_table=<?= $bo_table ?>&delete_wr_id=" + id;
    }
}
function delete_category(ca_id) {
    if (confirm('이 카테고리를 삭제하시겠습니까?\n카테고리만 삭제되며 게시글은 유지됩니다.')) {
        location.href = "?bo_table=<?= $bo_table ?>&delete_category=" + ca_id;
    }
}
</script>
</body>
</html>
