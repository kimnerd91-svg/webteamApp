<?php
// newadm/board/board_manager.php
// 그누보드 DB(g5_board / g5_write_XXX)에서 분리 — dm_boards(등록부) + dm_posts(공용 글 테이블) 사용

include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/_common.php');
include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/_auth_check.php');
include_once($_SERVER['DOCUMENT_ROOT'] . 'head_sub.php');

// ── 테이블 준비 (없으면 생성) ─────────────────────────────
sql_query("CREATE TABLE IF NOT EXISTS `dm_boards` (
    `id`         INT(11) NOT NULL AUTO_INCREMENT,
    `bo_table`   VARCHAR(50) NOT NULL,
    `bo_subject` VARCHAR(255) NOT NULL DEFAULT '',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_bo_table` (`bo_table`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

sql_query("CREATE TABLE IF NOT EXISTS `dm_board_categories` (
    `id`         INT(11) NOT NULL AUTO_INCREMENT,
    `bo_table`   VARCHAR(50) NOT NULL,
    `ca_name`    VARCHAR(255) NOT NULL,
    `ca_order`   INT(11) DEFAULT 0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_bo_table` (`bo_table`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

sql_query("CREATE TABLE IF NOT EXISTS `dm_posts` (
    `id`           INT(11) NOT NULL AUTO_INCREMENT,
    `bo_table`     VARCHAR(50) NOT NULL,
    `category_id`  INT(11) DEFAULT 0,
    `subject`      VARCHAR(255) NOT NULL DEFAULT '',
    `content`      TEXT,
    `thumbnail`    VARCHAR(500) DEFAULT '',
    `writer_name`  VARCHAR(100) DEFAULT '',
    `hit`          INT(11) DEFAULT 0,
    `is_visible`   TINYINT(1) DEFAULT 1,
    `created_at`   DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at`   DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_bo_table` (`bo_table`),
    KEY `idx_bo_cat` (`bo_table`, `category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ── 게시판 삭제 로직 (테이블 DROP 없음 — dm_posts/dm_board_categories에서 해당 bo_table 행만 삭제) ──
if (isset($_GET['delete_bo'])) {
    $bo_table = preg_replace('/[^a-z0-9_]/i', '', $_GET['delete_bo']);
    sql_query("DELETE FROM dm_posts WHERE bo_table = '{$bo_table}'");
    sql_query("DELETE FROM dm_board_categories WHERE bo_table = '{$bo_table}'");
    sql_query("DELETE FROM dm_boards WHERE bo_table = '{$bo_table}'");
    alert_toast('게시판이 완전히 삭제되었습니다.', './board_manager.php');
}

// ── 생성된 게시판 목록 가져오기 ──────────────────────────
$result = sql_query("SELECT * FROM dm_boards ORDER BY bo_table ASC");
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>게시판 관리</title>
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Pretendard', 'Apple SD Gothic Neo', sans-serif; background: #f5f6fa; color: #1a1a2e; }

        #admin_wrapper { display: flex; min-height: 100vh; }

        /* 사이드바는 aside.php가 담당 */
        .content_area { flex: 1; padding: 40px; overflow-x: hidden; }

        .page_title { font-size: 22px; font-weight: 700; color: #1a1a2e; margin-bottom: 28px; }

        .card {
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 2px 12px rgba(0,0,0,0.07);
            border: 1px solid #e8eaf0;
            padding: 28px;
            margin-bottom: 24px;
        }
        .card_title { font-size: 16px; font-weight: 700; color: #1a1a2e; margin-bottom: 20px; }

        /* 생성 폼 */
        .create_form { display: flex; gap: 14px; align-items: flex-end; flex-wrap: wrap; }
        .form_group { display: flex; flex-direction: column; gap: 6px; flex: 1; min-width: 160px; }
        .form_group label { font-size: 12px; font-weight: 700; color: #9999bb; }
        .form_group input {
            height: 44px;
            border: 1px solid #e8eaf0;
            border-radius: 8px;
            padding: 0 14px;
            font-size: 14px;
            color: #1a1a2e;
            background: #f5f6fa;
            transition: all 0.2s;
        }
        .form_group input:focus { outline: none; border-color: #4f46e5; background: #fff; box-shadow: 0 0 0 3px rgba(79,70,229,0.1); }

        .btn_create {
            height: 44px;
            padding: 0 24px;
            background: #4f46e5;
            color: #fff;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 700;
            cursor: pointer;
            white-space: nowrap;
            transition: all 0.2s;
            box-shadow: 0 4px 12px rgba(79,70,229,0.25);
        }
        .btn_create:hover { background: #4338ca; transform: translateY(-1px); }

        /* 테이블 */
        .table_wrap { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; min-width: 480px; }
        thead th {
            background: #f5f6fa;
            padding: 12px 18px;
            font-size: 12px;
            font-weight: 700;
            color: #9999bb;
            text-align: left;
            border-bottom: 2px solid #e8eaf0;
        }
        tbody td {
            padding: 14px 18px;
            font-size: 14px;
            color: #444466;
            border-bottom: 1px solid #f5f6fa;
            vertical-align: middle;
        }
        tbody tr:last-child td { border-bottom: none; }
        tbody tr:hover td { background: #fafafa; }

        .td_name { font-weight: 700; color: #1a1a2e; font-size: 15px; }
        .td_code { font-family: monospace; font-size: 13px; background: #f5f6fa; padding: 3px 8px; border-radius: 5px; color: #5c5c7a; }
        .td_count {
            display: inline-block;
            background: #ede9fe;
            color: #4f46e5;
            padding: 3px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 700;
        }

        .btn_manage {
            display: inline-block; padding: 6px 14px; background: #4f46e5; color: #fff;
            border-radius: 7px; font-size: 13px; font-weight: 700; text-decoration: none;
            transition: all 0.2s;
        }
        .btn_manage:hover { background: #4338ca; }

        .btn_delete {
            display: inline-block; padding: 6px 14px; background: #f5f6fa; color: #5c5c7a;
            border-radius: 7px; font-size: 13px; font-weight: 700; text-decoration: none;
            border: 1px solid #e8eaf0; cursor: pointer; transition: all 0.2s;
        }
        .btn_delete:hover { background: #fee2e2; color: #dc2626; border-color: #fca5a5; }

        .td_actions { display: flex; gap: 8px; justify-content: flex-end; }

        .empty_row td { text-align: center; padding: 48px; color: #9999bb; font-size: 14px; }
    </style>
</head>
<body>
<div id="admin_wrapper">
    <?php include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/aside.php'); ?>

    <main class="content_area">
        <h2 class="page_title">게시판 관리</h2>

        <!-- 새 게시판 생성 -->
        <div class="card">
            <p class="card_title">새 게시판 생성</p>
            <form action="board_create_update.php" method="post" class="create_form">
                <div class="form_group">
                    <label>테이블명 (영문/숫자만)</label>
                    <input type="text" name="bo_table" placeholder="예: notice, free" required>
                </div>
                <div class="form_group" style="flex:2">
                    <label>게시판 제목 (한글 가능)</label>
                    <input type="text" name="bo_subject" placeholder="예: 공지사항, 자유게시판" required>
                </div>
                <button type="submit" class="btn_create">생성하기</button>
            </form>
        </div>

        <!-- 게시판 목록 -->
        <div class="card">
            <p class="card_title">관리중인 게시판</p>
            <div class="table_wrap">
                <table>
                    <thead>
                        <tr>
                            <th>게시판 제목</th>
                            <th>테이블 ID</th>
                            <th style="text-align:center;">총 게시물</th>
                            <th style="text-align:right;">관리</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i = 0;
                        while ($row = sql_fetch_array($result)) {
                            $i++;
                            $count_row   = sql_fetch("SELECT COUNT(*) AS cnt FROM dm_posts WHERE bo_table = '{$row['bo_table']}'");
                            $total_count = (int)($count_row['cnt'] ?? 0);
                        ?>
                        <tr>
                            <td class="td_name"><?= htmlspecialchars($row['bo_subject']) ?></td>
                            <td><span class="td_code"><?= htmlspecialchars($row['bo_table']) ?></span></td>
                            <td style="text-align:center;"><span class="td_count"><?= number_format($total_count) ?></span></td>
                            <td>
                                <div class="td_actions">
                                    <a href="./board_post_list.php?bo_table=<?= $row['bo_table'] ?>" class="btn_manage">관리</a>
                                    <button onclick="if(confirm('이 게시판의 모든 데이터가 삭제됩니다. 계속하시겠습니까?')) location.href='?delete_bo=<?= $row['bo_table'] ?>'" class="btn_delete">삭제</button>
                                </div>
                            </td>
                        </tr>
                        <?php } ?>
                        <?php if ($i === 0): ?>
                        <tr class="empty_row"><td colspan="4">생성된 게시판이 없습니다.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</div>
</body>
</html>
