<?php
include_once('../_common.php');
include_once('../_auth_check.php');
if (!$is_admin) { header('Location: /bbs/login.php?url='.urlencode($_SERVER['REQUEST_URI'])); exit; }
global $connect_db; $db = $connect_db;
set_time_limit(120);

/* ============================================================
   다국어 매니저 v5 — 페이지 통번역 · 정적 생성
   - URL(또는 sitemap.xml 자동)로 페이지를 등록하고, 페이지 전체를
     Gemini 1콜로 통번역 → 완성된 HTML을 /data/i18n_cache/{lang}/에 정적 저장.
   - 프론트는 i18n_boot.php(v2)가 ?lang=en 요청 시 정적 파일을 그대로 출력 (DB조회 0).
   - hreflang/canonical/lang 속성 자동 삽입, 내부링크에 ?lang 자동 부착.
   - 세그먼트 맵(dm_i18n_page.seg_map)에 번역 저장 → 검수·수정 후 재생성 시 재번역 없이 재사용.
   - 원문 해시로 변경 감지 → 바뀐 페이지만 재생성.
   ============================================================ */

// ── 설정 로드 ──
$__gk = mysqli_fetch_assoc(mysqli_query($db, "SELECT cf_gemini_key, cf_langs FROM dm_config WHERE cf_id = 1")) ?: [];
$GEMINI_KEY = trim($__gk['cf_gemini_key'] ?? '');
$SITE_LANGS = array_values(array_filter(array_map('trim', explode(',', strtolower($__gk['cf_langs'] ?? ''))), function($l){ return in_array($l, ['en','ja','zh']); }));
$LANG_LABEL = ['en'=>'영어','ja'=>'일본어','zh'=>'중국어'];
$LANG_NAME  = ['en'=>'English','ja'=>'Japanese','zh'=>'Simplified Chinese'];

sql_query("CREATE TABLE IF NOT EXISTS `dm_i18n_page` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `path` VARCHAR(255) NOT NULL,
    `lang` VARCHAR(5) NOT NULL,
    `src_hash` CHAR(32) DEFAULT '',
    `seg_map` MEDIUMTEXT,
    `seg_total` INT DEFAULT 0,
    `status` VARCHAR(12) DEFAULT 'none',   /* ok(최신) | stale(원문변경) | edited(검수수정-재생성필요) */
    `scope` VARCHAR(100) DEFAULT '',
    `generated_at` DATETIME DEFAULT NULL,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uq_path_lang` (`path`, `lang`)
) DEFAULT CHARSET=utf8mb4");
@mysqli_query($db, "ALTER TABLE dm_i18n_page ADD COLUMN scope VARCHAR(100) DEFAULT ''");

$BOOT_OK = file_exists($_SERVER['DOCUMENT_ROOT'].'/i18n_boot.php');
$CACHE_ROOT = $_SERVER['DOCUMENT_ROOT'].'/data/i18n_cache';
$BASE = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off' ? 'https' : 'http').'://'.($_SERVER['HTTP_HOST'] ?? 'localhost');

// ── 유틸 ──
function ml_norm_path($url_or_path) {
    $p = preg_match('#^https?://#i', $url_or_path) ? (parse_url($url_or_path, PHP_URL_PATH) ?: '/') : $url_or_path;
    if ($p === '' ) $p = '/';
    if ($p === '/index.php') $p = '/';
    return $p;
}
function ml_fetch($url) {
    $ua = 'Mozilla/5.0 (i18n-generator)';
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_FOLLOWLOCATION=>true, CURLOPT_TIMEOUT=>20, CURLOPT_USERAGENT=>$ua, CURLOPT_SSL_VERIFYPEER=>false]);
    $body = curl_exec($ch); $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    return ($code>=200 && $code<400) ? $body : false;
}
function ml_has_ko($s) { return (bool)preg_match('/[가-힣]/u', $s); }
function ml_norm_ko($s) { return trim(preg_replace('/\s+/u', ' ', $s)); }

/* HTML 주석 보존: 파싱 전 토큰으로 치환 → 저장 후 원문 그대로 복원 (주석 내용 100% 무손상) */
function ml_protect_comments($html, &$store) {
    $store = [];
    return preg_replace_callback('/<!--.*?-->/s', function($m) use (&$store) {
        $k = count($store);
        $store[$k] = $m[0];
        return '<!--I18NC'.$k.'-->';
    }, $html);
}
function ml_restore_comments($html, $store) {
    return preg_replace_callback('/<!--I18NC(\d+)-->/', function($m) use ($store) {
        return $store[(int)$m[1]] ?? '';
    }, $html);
}

/* 스코프 입력(#id 또는 태그명)을 XPath 프리픽스로 변환 — 빈 값이면 전체 */
function ml_scope_xpath($scope) {
    $scope = trim($scope);
    if ($scope === '') return '';
    if ($scope[0] === '#') {
        $id = preg_replace('/[^A-Za-z0-9_\-]/', '', substr($scope, 1));
        return $id ? "//*[@id='".$id."']" : '';
    }
    $tag = preg_replace('/[^a-z0-9]/', '', strtolower($scope));
    return $tag ? "//".$tag : '';
}

/* 페이지에서 번역 대상 수집: 텍스트 노드 + 주요 속성(alt/placeholder/title/meta)
   $scopeXp가 있으면 본문 텍스트·속성은 그 하위만 수집. title/meta는 스코프와 무관하게 항상 포함(SEO 필수). */
function ml_collect(DOMDocument $dom, $scopeXp = '') {
    $xp = new DOMXPath($dom);
    $units = []; // [ ['kind'=>'text'|'attr', 'node'=>DOMNode, 'attr'=>?, 'ko'=>str, 'hash'=>md5] ]
    $base = $scopeXp !== '' ? $scopeXp : '';
    foreach ($xp->query($base.'//text()[not(ancestor::script) and not(ancestor::style) and not(ancestor::noscript) and not(ancestor::*[@data-no-i18n])]') as $n) {
        $ko = ml_norm_ko($n->nodeValue);
        if ($ko === '' || !ml_has_ko($ko)) continue;
        $units[] = ['kind'=>'text','node'=>$n,'attr'=>null,'ko'=>$ko,'hash'=>md5($ko)];
    }
    $attrTargets = [
        [$base.'//img[@alt]','alt'], [$base.'//input[@placeholder]','placeholder'], [$base.'//textarea[@placeholder]','placeholder'],
        [$base.'//*[@title]','title'],
        /* 아래는 스코프 무관 상시 번역 (head 영역) */
        ["//head/title",'__text'],
        ["//meta[@name='description']",'content'],
        ["//meta[@property='og:title']",'content'], ["//meta[@property='og:description']",'content'],
    ];
    foreach ($attrTargets as $t) {
        foreach ($xp->query($t[0]) as $el) {
            if ($t[1] === '__text') {
                $ko = ml_norm_ko($el->textContent);
                if ($ko === '' || !ml_has_ko($ko)) continue;
                foreach ($el->childNodes as $cn) {
                    if ($cn->nodeType === XML_TEXT_NODE) $units[] = ['kind'=>'text','node'=>$cn,'attr'=>null,'ko'=>$ko,'hash'=>md5($ko)];
                }
                continue;
            }
            $ko = ml_norm_ko($el->getAttribute($t[1]));
            if ($ko === '' || !ml_has_ko($ko)) continue;
            $units[] = ['kind'=>'attr','node'=>$el,'attr'=>$t[1],'ko'=>$ko,'hash'=>md5($ko)];
        }
    }
    /* 중복 노드 제거 (스코프+상시 대상이 겹칠 수 있음) */
    $seen = []; $dedup = [];
    foreach ($units as $u) {
        $key = spl_object_id($u['node']).'|'.($u['attr'] ?? 'txt');
        if (isset($seen[$key])) continue;
        $seen[$key] = 1; $dedup[] = $u;
    }
    return $dedup;
}

/* Gemini 통번역 (청크 100개) — 의료광고법 게이트 포함 */
function ml_translate_batch($key, $langName, $items) {  // items: [hash=>ko]
    if (!$items) return [];
    $out = [];
    foreach (array_chunk($items, 100, true) as $chunk) {
        $arr = [];
        foreach ($chunk as $h=>$ko) $arr[] = ['k'=>$h,'ko'=>$ko];
        $sys = <<<SYS
당신은 치과/병원 웹사이트 전문 번역가입니다. 같은 페이지에서 추출된 한국어 문구 배열을 {$langName}로 번역하세요. 배열 전체가 한 페이지의 문맥이므로 용어·톤을 일관되게 유지하세요.

[규칙]
1. UI 라벨은 웹사이트 관례 표현으로, 문장은 자연스럽고 정확하게.
2. 병원명·인명은 로마자(또는 해당 언어 관례) 표기. 숫자·전화번호·단위·이메일은 보존.
3. 의료광고법 취지: "best/No.1/perfect/100%/painless/guarantee" 류 단정·과장·보장 표현을 새로 만들지 말 것. 원문에 없는 효능 표현 추가 금지.
4. 출력은 아래 JSON 배열 하나만. 설명·코드블록 금지.
[{"k":"해시","tr":"번역문"}, ...]
SYS;
        $payload = [
            'system_instruction' => ['parts'=>[['text'=>$sys]]],
            'contents' => [['role'=>'user','parts'=>[['text'=>json_encode($arr, JSON_UNESCAPED_UNICODE)]]]],
            'generationConfig' => ['temperature'=>0.2, 'maxOutputTokens'=>16384],
        ];
        $resp=''; $code=0;
        foreach ([0,1,2,4] as $wait) {
            if ($wait) sleep($wait);
            $ch = curl_init("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=".$key);
            curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_POST=>true,
                CURLOPT_HTTPHEADER=>['Content-Type: application/json'],
                CURLOPT_POSTFIELDS=>json_encode($payload, JSON_UNESCAPED_UNICODE),
                CURLOPT_TIMEOUT=>90, CURLOPT_SSL_VERIFYPEER=>true]);
            $resp = curl_exec($ch); $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
            if ($code === 200) break;
            if ($code !== 503 && $code !== 429 && $code !== 0) break;
        }
        if ($code !== 200) return false;
        $j = json_decode($resp, true);
        $txt = trim(preg_replace('/```json|```/', '', $j['candidates'][0]['content']['parts'][0]['text'] ?? ''));
        $parsed = json_decode($txt, true);
        if (!is_array($parsed)) return false;
        foreach ($parsed as $it) {
            $h = $it['k'] ?? ''; $tr = trim($it['tr'] ?? '');
            if ($h && $tr !== '' && isset($chunk[$h])) $out[$h] = $tr;
        }
    }
    return $out;
}

/* 페이지 생성 핵심: 크롤→수집→(맵 재사용+미번역만 번역)→주입→SEO태그→링크재작성→정적 저장 */
function ml_generate($path, $lang, $db, $GEMINI_KEY, $LANG_NAME, $SITE_LANGS, $BASE, $CACHE_ROOT, $scope = '') {
    $url = $BASE . $path;
    $html = ml_fetch($url);
    if ($html === false) return ['success'=>false,'message'=>"크롤 실패: $path"];

    /* 주석 보존: 파싱 전 토큰화 */
    $cmts = [];
    $html = ml_protect_comments($html, $cmts);

    $dom = new DOMDocument();
    libxml_use_internal_errors(true);
    $dom->loadHTML('<?xml encoding="utf-8" ?>'.$html, LIBXML_NOERROR);
    libxml_clear_errors();

    $scopeXp = ml_scope_xpath($scope);
    $units = ml_collect($dom, $scopeXp);
    if (!$units) return ['success'=>false,'message'=>"한글 콘텐츠 없음: $path".($scope ? " (스코프 '$scope' 확인)" : '')];

    // 원문 해시 (변경감지용) — 고유 ko 해시 정렬 결합
    $hashes = array_values(array_unique(array_column($units, 'hash')));
    sort($hashes);
    $src_hash = md5(implode('', $hashes));

    // 기존 맵 로드 (번역 재사용)
    $pE = mysqli_real_escape_string($db, $path);
    $row = mysqli_fetch_assoc(mysqli_query($db, "SELECT id, seg_map FROM dm_i18n_page WHERE path='$pE' AND lang='$lang'"));
    $map = $row && $row['seg_map'] ? (json_decode($row['seg_map'], true) ?: []) : [];

    // 미번역만 추출
    $need = [];
    foreach ($units as $u) {
        if (!isset($map[$u['hash']]['tr']) || $map[$u['hash']]['tr'] === '') $need[$u['hash']] = $u['ko'];
    }
    $newly = 0;
    if ($need) {
        if (!$GEMINI_KEY) return ['success'=>false,'message'=>'Gemini 키가 없습니다 (SEO·스키마 관리에서 등록).'];
        $tr = ml_translate_batch($GEMINI_KEY, $LANG_NAME[$lang], $need);
        if ($tr === false) return ['success'=>false,'message'=>"번역 API 오류: $path"];
        foreach ($need as $h=>$ko) {
            $map[$h] = ['ko'=>$ko, 'tr'=>($tr[$h] ?? '')];
            if (!empty($tr[$h])) $newly++;
        }
    }

    // 번역 주입 (미번역은 한국어 유지)
    foreach ($units as $u) {
        $tr = $map[$u['hash']]['tr'] ?? '';
        if ($tr === '') continue;
        if ($u['kind'] === 'text') {
            // 원문 노드의 앞뒤 공백 보존
            $orig = $u['node']->nodeValue;
            $lead = preg_match('/^\s*/u', $orig, $m1) ? $m1[0] : '';
            $tail = preg_match('/\s*$/u', $orig, $m2) ? $m2[0] : '';
            $u['node']->nodeValue = $lead.$tr.$tail;
        } else {
            $u['node']->setAttribute($u['attr'], $tr);
        }
    }

    $xp = new DOMXPath($dom);
    // <html lang="">
    foreach ($xp->query('//html') as $h) $h->setAttribute('lang', $lang);
    // 기존 canonical/hreflang 제거 후 재삽입
    foreach ($xp->query("//link[@rel='canonical' or @rel='alternate'][@hreflang or @rel='canonical']") as $l) $l->parentNode->removeChild($l);
    $head = $xp->query('//head')->item(0);
    if ($head) {
        $mk = function($rel,$href,$hreflang=null) use ($dom) {
            $l = $dom->createElement('link');
            $l->setAttribute('rel',$rel);
            if ($hreflang) $l->setAttribute('hreflang',$hreflang);
            $l->setAttribute('href',$href);
            return $l;
        };
        $koUrl = $BASE.$path;
        $head->appendChild($mk('canonical', $koUrl.'?lang='.$lang));
        $head->appendChild($mk('alternate', $koUrl, 'ko'));
        foreach ($SITE_LANGS as $sl) $head->appendChild($mk('alternate', $koUrl.'?lang='.$sl, $sl));
        $head->appendChild($mk('alternate', $koUrl, 'x-default'));
    }
    // 내부 링크에 ?lang 부착
    $host = parse_url($BASE, PHP_URL_HOST);
    foreach ($xp->query('//a[@href]') as $a) {
        $href = $a->getAttribute('href');
        if ($href === '' || $href[0] === '#') continue;
        if (preg_match('/^(mailto:|tel:|javascript:)/i', $href)) continue;
        if (preg_match('/\.(jpe?g|png|gif|webp|pdf|zip|mp4|hwp|docx?)($|\?)/i', $href)) continue;
        $hHost = parse_url($href, PHP_URL_HOST);
        if ($hHost && $hHost !== $host) continue;         // 외부링크 제외
        if (strpos($href, 'lang=') !== false) continue;   // 이미 부착됨
        $a->setAttribute('href', $href . (strpos($href,'?')!==false ? '&' : '?') . 'lang='.$lang);
    }

    // 저장
    $dir = $CACHE_ROOT.'/'.$lang;
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    if (!is_dir($dir)) return ['success'=>false,'message'=>'캐시 폴더 생성 실패: /data/i18n_cache — 퍼미션 확인'];
    $out = $dom->saveHTML();
    $out = preg_replace('/^<\?xml[^>]*\?>\s*/', '', $out); // 인코딩 힌트 제거
    $out = ml_restore_comments($out, $cmts);               // 주석 원문 복원
    file_put_contents($dir.'/'.md5($path).'.html', $out);

    // DB upsert
    $scopeE = mysqli_real_escape_string($db, $scope);
    $mapE = mysqli_real_escape_string($db, json_encode($map, JSON_UNESCAPED_UNICODE));
    $segTotal = count($hashes);
    mysqli_query($db, "INSERT INTO dm_i18n_page (path, lang, src_hash, seg_map, seg_total, status, scope, generated_at)
        VALUES ('$pE','$lang','$src_hash','$mapE',$segTotal,'ok','$scopeE',NOW())
        ON DUPLICATE KEY UPDATE src_hash='$src_hash', seg_map='$mapE', seg_total=$segTotal, status='ok', scope='$scopeE', generated_at=NOW()");

    return ['success'=>true,'segments'=>$segTotal,'translated_new'=>$newly];
}

/* ============================================================
   AJAX
   ============================================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['action'])) {
    header('Content-Type: application/json; charset=utf-8');
    $action = $_POST['action'];

    // sitemap.xml에서 페이지 목록
    if ($action === 'load_sitemap') {
        $xml = ml_fetch($BASE.'/sitemap.xml');
        if ($xml === false) { echo json_encode(['success'=>false,'message'=>'/sitemap.xml 을 불러오지 못했습니다.']); exit; }
        preg_match_all('#<loc>\s*(.*?)\s*</loc>#i', $xml, $mm);
        $paths = [];
        foreach (($mm[1] ?? []) as $loc) {
            $p = ml_norm_path(html_entity_decode($loc));
            if (strpos($p, '/bbs/') === 0 || strpos($p, '/newadm') === 0) continue; // 게시판/관리자는 제외
            $paths[] = $p;
        }
        $paths = array_values(array_unique($paths));
        echo json_encode(['success'=>true,'paths'=>$paths]); exit;
    }

    // 페이지 1건 생성 (JS가 순차 호출)
    if ($action === 'generate') {
        $path = ml_norm_path(trim($_POST['path'] ?? ''));
        $lang = preg_replace('/[^a-z]/','', $_POST['lang'] ?? '');
        if (!$path || !in_array($lang, ['en','ja','zh'], true)) { echo json_encode(['success'=>false,'message'=>'잘못된 요청']); exit; }
        $scope = trim($_POST['scope'] ?? '');
        if ($scope === '' ) { // 재생성 시 저장된 스코프 재사용
            $pE0 = mysqli_real_escape_string($db, $path);
            $prev = mysqli_fetch_assoc(mysqli_query($db, "SELECT scope FROM dm_i18n_page WHERE path='$pE0' AND lang='$lang'"));
            if ($prev && $prev['scope'] !== null) $scope = $prev['scope'];
        }
        echo json_encode(ml_generate($path, $lang, $db, $GEMINI_KEY, $LANG_NAME, $SITE_LANGS ?: [$lang], $BASE, $CACHE_ROOT, $scope)); exit;
    }

    // 변경 감지: 등록된 path들 재크롤 → 해시 비교
    if ($action === 'detect') {
        $paths = [];
        $r = mysqli_query($db, "SELECT path, MAX(scope) AS scope FROM dm_i18n_page GROUP BY path");
        while ($row = mysqli_fetch_assoc($r)) $paths[] = $row;
        $stale = 0; $checked = 0;
        foreach ($paths as $pr) {
            $p = $pr['path'];
            $html = ml_fetch($BASE.$p);
            if ($html === false) continue;
            $checked++;
            $cmts0 = [];
            $html = ml_protect_comments($html, $cmts0);
            $dom = new DOMDocument();
            libxml_use_internal_errors(true);
            $dom->loadHTML('<?xml encoding="utf-8" ?>'.$html, LIBXML_NOERROR);
            libxml_clear_errors();
            $hashes = array_values(array_unique(array_column(ml_collect($dom, ml_scope_xpath($pr['scope'] ?? '')), 'hash')));
            sort($hashes);
            $h = md5(implode('', $hashes));
            $pE = mysqli_real_escape_string($db, $p);
            mysqli_query($db, "UPDATE dm_i18n_page SET status='stale' WHERE path='$pE' AND src_hash<>'$h' AND status='ok'");
            $stale += mysqli_affected_rows($db);
        }
        echo json_encode(['success'=>true,'checked'=>$checked,'stale'=>$stale]); exit;
    }

    // 목록
    if ($action === 'list') {
        $rows = [];
        $r = mysqli_query($db, "SELECT id, path, lang, seg_total, status, generated_at FROM dm_i18n_page ORDER BY path ASC, lang ASC");
        while ($row = mysqli_fetch_assoc($r)) $rows[] = $row;
        echo json_encode(['success'=>true,'rows'=>$rows,'langs'=>$SITE_LANGS]); exit;
    }

    // 검수: 세그먼트 목록
    if ($action === 'segments') {
        $id = (int)($_POST['id'] ?? 0);
        $row = mysqli_fetch_assoc(mysqli_query($db, "SELECT * FROM dm_i18n_page WHERE id=$id"));
        if (!$row) { echo json_encode(['success'=>false]); exit; }
        $map = json_decode($row['seg_map'], true) ?: [];
        $segs = [];
        foreach ($map as $h=>$m) $segs[] = ['hash'=>$h,'ko'=>$m['ko'],'tr'=>$m['tr']];
        echo json_encode(['success'=>true,'path'=>$row['path'],'lang'=>$row['lang'],'segs'=>$segs]); exit;
    }

    // 검수: 세그먼트 저장 (재생성 필요 표시)
    if ($action === 'save_seg') {
        $id = (int)($_POST['id'] ?? 0);
        $hash = preg_replace('/[^a-f0-9]/','', $_POST['hash'] ?? '');
        $val = trim($_POST['value'] ?? '');
        $row = mysqli_fetch_assoc(mysqli_query($db, "SELECT seg_map FROM dm_i18n_page WHERE id=$id"));
        if (!$row) { echo json_encode(['success'=>false]); exit; }
        $map = json_decode($row['seg_map'], true) ?: [];
        if (!isset($map[$hash])) { echo json_encode(['success'=>false]); exit; }
        $map[$hash]['tr'] = $val;
        $mapE = mysqli_real_escape_string($db, json_encode($map, JSON_UNESCAPED_UNICODE));
        mysqli_query($db, "UPDATE dm_i18n_page SET seg_map='$mapE', status='edited' WHERE id=$id");
        echo json_encode(['success'=>true]); exit;
    }

    // 삭제 (정적 파일 + DB)
    if ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        $row = mysqli_fetch_assoc(mysqli_query($db, "SELECT path, lang FROM dm_i18n_page WHERE id=$id"));
        if ($row) {
            @unlink($CACHE_ROOT.'/'.$row['lang'].'/'.md5($row['path']).'.html');
            mysqli_query($db, "DELETE FROM dm_i18n_page WHERE id=$id");
        }
        echo json_encode(['success'=>true]); exit;
    }

    echo json_encode(['success'=>false,'message'=>'알 수 없는 action']); exit;
}
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>다국어 관리 v5</title>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'Pretendard','Apple SD Gothic Neo',sans-serif;background:#f5f6fa;color:#1a1a2e;}
#admin_wrapper{display:flex;min-height:100vh;}
.content_area{flex:1;padding:40px;overflow-x:hidden;display:flex;flex-direction:column;gap:20px;}
.page_header{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;}
.page_title{font-size:22px;font-weight:700;display:flex;align-items:center;gap:10px;}
.card{background:#fff;border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,.06);border:1px solid #e8eaf0;overflow:hidden;}
.card_hd{padding:14px 20px;border-bottom:1px solid #e8eaf0;display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;}
.card_hd_title{font-size:14px;font-weight:700;display:flex;align-items:center;gap:6px;}
.card_hd_title .material-symbols-outlined{font-size:16px;color:#4f46e5;}
.card_body{padding:20px;}
.btn_primary{padding:9px 20px;background:#4f46e5;color:#fff;border:none;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer;display:inline-flex;align-items:center;gap:5px;font-family:inherit;transition:all .2s;}
.btn_primary:hover{background:#4338ca;}
.btn_primary:disabled{opacity:.5;cursor:not-allowed;}
.btn_neutral{padding:9px 16px;background:#f5f6fa;color:#5c5c7a;border:1px solid #e8eaf0;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer;display:inline-flex;align-items:center;gap:5px;font-family:inherit;}
.btn_neutral:hover{background:#e8eaf0;}
.btn_sm{padding:5px 12px;background:#eef2ff;color:#4f46e5;border:none;border-radius:6px;font-size:11px;font-weight:700;cursor:pointer;}
.btn_sm:hover{background:#4f46e5;color:#fff;}
.btn_del{padding:5px 12px;background:#fee2e2;color:#dc2626;border:none;border-radius:6px;font-size:11px;font-weight:700;cursor:pointer;}
.btn_del:hover{background:#dc2626;color:#fff;}
.form_group{margin-bottom:14px;}
.form_group label{display:block;font-size:12px;font-weight:700;color:#9999bb;margin-bottom:5px;}
.form_input{width:100%;padding:9px 12px;border:1px solid #e8eaf0;border-radius:8px;font-size:13px;background:#f5f6fa;color:#1a1a2e;font-family:inherit;outline:none;}
.form_input:focus{border-color:#4f46e5;background:#fff;box-shadow:0 0 0 3px rgba(79,70,229,.1);}
textarea.form_input{resize:vertical;line-height:1.6;}
.btn_row{display:flex;align-items:center;gap:10px;margin-top:6px;flex-wrap:wrap;}
.muted{color:#9999bb;font-size:12.5px;}

/* ── 설명 박스 (시인성 강조) ── */
.guide{background:linear-gradient(135deg,#eef2ff,#f5f3ff);border:1px solid #d6d0fb;border-radius:14px;padding:22px 24px;}
.guide h3{font-size:15px;font-weight:800;color:#4338ca;display:flex;align-items:center;gap:7px;margin-bottom:14px;}
.guide ol{margin:0 0 0 4px;padding:0;list-style:none;counter-reset:step;}
.guide ol li{counter-increment:step;position:relative;padding:0 0 14px 40px;font-size:13.5px;line-height:1.7;color:#3a3a55;}
.guide ol li:last-child{padding-bottom:0;}
.guide ol li::before{content:counter(step);position:absolute;left:0;top:0;width:26px;height:26px;border-radius:50%;background:#4f46e5;color:#fff;font-size:13px;font-weight:800;display:grid;place-items:center;}
.guide ol li b{color:#1a1a2e;}
.guide code{background:#fff;border:1px solid #d6d0fb;padding:1px 7px;border-radius:5px;font-size:12px;color:#4f46e5;}
.guide .tip{margin-top:14px;padding-top:12px;border-top:1px dashed #c7bffb;font-size:12.5px;color:#6d6a8f;line-height:1.7;}
.warn_box{background:#fffbeb;border-radius:10px;padding:12px 16px;font-size:12.5px;color:#92400e;line-height:1.6;border:1px solid #fde68a;}

.lang_check{display:inline-flex;align-items:center;gap:6px;padding:8px 14px;border:1.5px solid #e8eaf0;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer;user-select:none;}
.lang_check input{accent-color:#4f46e5;}
.lang_check:has(input:checked){border-color:#4f46e5;background:#eef2ff;color:#4f46e5;}
.page_pick{max-height:260px;overflow-y:auto;border:1px solid #e8eaf0;border-radius:10px;padding:6px;}
.page_pick label{display:flex;align-items:center;gap:8px;padding:7px 10px;border-radius:7px;font-size:13px;cursor:pointer;}
.page_pick label:hover{background:#f5f6fa;}
.page_pick input{accent-color:#4f46e5;}
.prog_wrap{flex:1;min-width:180px;height:9px;background:#eef0f6;border-radius:6px;overflow:hidden;}
.prog_bar{height:100%;background:#4f46e5;border-radius:6px;transition:width .3s;width:0;}

.pg_table{width:100%;border-collapse:collapse;font-size:13px;}
.pg_table th{padding:10px 14px;font-size:11px;font-weight:700;color:#9999bb;text-transform:uppercase;text-align:left;background:#fafafa;border-bottom:1px solid #e8eaf0;}
.pg_table td{padding:11px 14px;border-bottom:1px solid #f5f5f5;vertical-align:middle;}
.pg_table td.path_cell{font-weight:700;color:#3a3a55;word-break:break-all;}
.st_chip{display:inline-flex;align-items:center;gap:4px;padding:3px 11px;border-radius:20px;font-size:11px;font-weight:800;}
.st_chip.ok{background:#f0fdf4;color:#059669;}
.st_chip.stale{background:#fffbeb;color:#d97706;}
.st_chip.edited{background:#fef2f2;color:#dc2626;}
.lang_tag{display:inline-block;padding:2px 9px;border-radius:6px;background:#eef2ff;color:#4f46e5;font-size:11px;font-weight:800;margin-right:4px;}
.empty_state{text-align:center;padding:48px;color:#9999bb;font-size:14px;}

/* 검수 모달 */
.modal_bg{position:fixed;inset:0;background:rgba(20,20,40,.45);z-index:100000;display:none;align-items:center;justify-content:center;padding:24px;}
.modal_bg.show{display:flex;}
.modal{background:#fff;border-radius:14px;width:min(880px,100%);max-height:86vh;display:flex;flex-direction:column;overflow:hidden;box-shadow:0 20px 60px rgba(0,0,0,.25);}
.modal_hd{padding:16px 22px;border-bottom:1px solid #e8eaf0;display:flex;align-items:center;justify-content:space-between;}
.modal_hd b{font-size:14px;}
.modal_body{padding:16px 22px;overflow-y:auto;}
.seg_row{display:grid;grid-template-columns:1fr 1fr;gap:10px;padding:10px 0;border-bottom:1px solid #f5f5f5;}
@media(max-width:680px){.seg_row{grid-template-columns:1fr;}}
.seg_ko{font-size:12.5px;color:#3a3a55;line-height:1.55;word-break:break-all;}
.seg_tr{width:100%;padding:7px 10px;border:1px solid #e8eaf0;border-radius:7px;font-size:12.5px;background:#fbfbfe;font-family:inherit;outline:none;}
.seg_tr:focus{border-color:#4f46e5;background:#fff;}
.seg_tr.empty{background:#fff7ed;border-color:#fed7aa;}
.toast{position:fixed;top:20px;right:20px;padding:12px 18px;border-radius:10px;font-size:13px;font-weight:600;display:flex;align-items:center;gap:7px;z-index:1000001!important;box-shadow:0 4px 16px rgba(0,0,0,.12);animation:tin .22s ease;}
.toast.ok{background:#f0fdf4;border:1px solid #bbf7d0;color:#059669;}
.toast.error{background:#fef2f2;border:1px solid #fecaca;color:#dc2626;}
@keyframes tin{from{opacity:0;transform:translateX(12px)}to{opacity:1;transform:none}}
.spin{animation:spin 1s linear infinite;}
@keyframes spin{to{transform:rotate(360deg);}}
</style>
</head>
<body>
<div id="admin_wrapper">
    <?php include_once('../aside.php'); ?>
    <main class="content_area">

        <div class="page_header">
            <h2 class="page_title">
                <span class="material-symbols-outlined" style="font-size:22px;color:#4f46e5;">translate</span>
                다국어 관리 <span class="muted" style="font-size:13px;font-weight:600;">v5 · 페이지 통번역 정적 생성</span>
            </h2>
            <button class="btn_neutral" onclick="runDetect()"><span class="material-symbols-outlined" style="font-size:15px;">radar</span>원문 변경 감지</button>
        </div>

        <!-- ── 사용 설명 ── -->
        <div class="guide">
            <h3><span class="material-symbols-outlined">menu_book</span>작동 방식 — 3분 안에 이해하기</h3>
            <ol>
                <li><b>페이지 등록</b> — 아래에 URL을 붙여넣거나 <code>사이트맵에서 불러오기</code>를 누르면 번역할 페이지 목록이 만들어집니다. (게시판·관리자 경로는 자동 제외)</li>
                <li><b>번역 생성</b> — 언어를 체크하고 <code>선택 페이지 번역 생성</code>을 누르면, 페이지를 통째로 크롤해서 <b>페이지 전체를 Gemini 1회 호출로 통번역</b>합니다. 문맥이 유지되어 조각 번역보다 품질이 높고, 의료광고법 필터(과장·보장 표현 생성 금지)가 프롬프트에 내장되어 있습니다.</li>
                <li><b>정적 파일 저장</b> — 번역된 완성 HTML이 <code>/data/i18n_cache/언어/</code>에 저장됩니다. hreflang·canonical·<code>&lt;html lang&gt;</code>이 자동 삽입되고, 페이지 안의 내부 링크에는 <code>?lang=</code>이 자동으로 붙어 언어가 유지됩니다.</li>
                <li><b>프론트 서빙</b> — 방문자가 <code>?lang=en</code>으로 접속하면 <code>i18n_boot.php</code>가 저장된 정적 파일을 그대로 출력합니다. DB 조회·치환 연산이 전혀 없어 속도 부담이 0입니다. 파일이 없는 페이지는 한국어로 자연스럽게 폴백됩니다.</li>
                <li><b>검수·수정</b> — 목록에서 <code>검수</code>를 열어 문구를 고치면 상태가 <b style="color:#dc2626;">수정됨</b>으로 바뀝니다. <code>재생성</code>을 누르면 <b>재번역 없이</b> 수정된 문구로 파일만 다시 만들어집니다.</li>
                <li><b>원문이 바뀌었을 때</b> — 우측 상단 <code>원문 변경 감지</code>를 누르면 한국어 원문이 바뀐 페이지가 <b style="color:#d97706;">원문변경</b>으로 표시됩니다. 해당 페이지만 <code>재생성</code>하면 기존 번역은 재사용하고 <b>바뀐 문장만 새로 번역</b>됩니다.</li>
            </ol>
            <div class="tip">
                ⚙ <b>설치(사이트당 1회)</b> : 문서루트에 <code>/i18n_boot.php</code> 업로드 → <code>head.php</code> 최상단에 <code>include_once($_SERVER['DOCUMENT_ROOT'].'/i18n_boot.php');</code> 한 줄 추가 · 번역 제외는 <code>data-no-i18n</code> 속성, 특정 영역만 번역하려면 <b>번역 범위</b>에 <code>#아이디</code>/태그 입력 · HTML 주석은 토큰 보존 방식이라 내용이 절대 변형되지 않음 ·
                게시판 등 동적 페이지는 생성 시점 스냅샷이므로 대상이 아닙니다(시술·의료진·오시는길 등 정적 페이지용) · 생성 후 게시 전 <b>의료광고법 검수 권장</b>
            </div>
        </div>

        <?php if (!$BOOT_OK): ?>
        <div class="warn_box">⚠ <b>/i18n_boot.php 미설치</b> — 문서루트에 업로드해야 번역 페이지가 방문자에게 서빙됩니다. (생성 자체는 가능)</div>
        <?php endif; ?>
        <?php if (!$SITE_LANGS): ?>
        <div class="warn_box">⚠ 사이트 설정 <code>cf_langs</code>에 대상 언어가 없습니다 (예: ko,en,ja). — 아래에서 생성은 가능하지만 사이트 설정에도 등록해 두세요.</div>
        <?php endif; ?>
        <?php if (!$GEMINI_KEY): ?>
        <div class="warn_box">⚠ Gemini 키 미설정 — SEO·스키마 관리에서 등록하면 공유됩니다.</div>
        <?php endif; ?>

        <!-- ── 페이지 등록 + 생성 ── -->
        <div class="card">
            <div class="card_hd">
                <span class="card_hd_title"><span class="material-symbols-outlined">post_add</span>페이지 등록 · 번역 생성</span>
                <button class="btn_neutral" onclick="loadSitemap()" style="padding:6px 12px;font-size:12px;"><span class="material-symbols-outlined" style="font-size:14px;">map</span>사이트맵에서 불러오기</button>
            </div>
            <div class="card_body">
                <div class="form_group">
                    <label>URL 또는 경로 (한 줄에 하나 — 예: /implant.php 또는 전체 URL)</label>
                    <textarea id="urlInput" class="form_input" rows="4" placeholder="/&#10;/implant.php&#10;/doctor.php"></textarea>
                </div>
                <div id="pickWrap" style="display:none;" class="form_group">
                    <label>사이트맵 페이지 선택 <button class="btn_sm" onclick="toggleAll(true)" style="margin-left:6px;">전체선택</button> <button class="btn_sm" onclick="toggleAll(false)">해제</button></label>
                    <div class="page_pick" id="pagePick"></div>
                </div>
                <div class="form_group">
                    <label>번역 범위 (선택 — 비우면 페이지 전체 · 예: <code>#container</code> 또는 <code>main</code> — 해당 요소 하위만 번역, 제목·메타는 항상 포함)</label>
                    <input type="text" id="scopeInput" class="form_input" placeholder="#container" style="max-width:280px;">
                </div>
                <div class="form_group">
                    <label>대상 언어</label>
                    <div class="btn_row" style="margin-top:0;">
                        <?php foreach (['en','ja','zh'] as $l): ?>
                        <label class="lang_check"><input type="checkbox" class="langCk" value="<?= $l ?>" <?= in_array($l,$SITE_LANGS)?'checked':'' ?>><?= $LANG_LABEL[$l] ?></label>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="btn_row">
                    <button class="btn_primary" id="genBtn" onclick="runGenerate()"><span class="material-symbols-outlined" id="genIco" style="font-size:15px;">bolt</span>선택 페이지 번역 생성</button>
                    <div class="prog_wrap" id="genProgWrap" style="display:none;"><div class="prog_bar" id="genProg"></div></div>
                    <span id="genStat" class="muted"></span>
                </div>
            </div>
        </div>

        <!-- ── 생성된 페이지 목록 ── -->
        <div class="card">
            <div class="card_hd"><span class="card_hd_title"><span class="material-symbols-outlined">fact_check</span>생성된 번역 페이지</span></div>
            <div class="card_body" style="padding:0;">
                <div style="overflow-x:auto;">
                <table class="pg_table">
                    <thead><tr><th>경로</th><th>언어</th><th>문구 수</th><th>상태</th><th>생성일</th><th style="width:230px;"></th></tr></thead>
                    <tbody id="listBody"><tr><td colspan="6"><div class="empty_state">불러오는 중…</div></td></tr></tbody>
                </table>
                </div>
            </div>
        </div>

    </main>
</div>

<!-- 검수 모달 -->
<div class="modal_bg" id="segModalBg" onclick="if(event.target===this)closeSeg()">
    <div class="modal">
        <div class="modal_hd">
            <b id="segTitle">검수</b>
            <div style="display:flex;gap:8px;">
                <button class="btn_primary" id="segRegenBtn" onclick="regenFromModal()" style="padding:6px 14px;font-size:12px;"><span class="material-symbols-outlined" style="font-size:14px;">refresh</span>저장분으로 재생성</button>
                <button class="btn_neutral" onclick="closeSeg()" style="padding:6px 14px;font-size:12px;">닫기</button>
            </div>
        </div>
        <div class="modal_body" id="segBody"></div>
    </div>
</div>

<script>
var LANG_LABEL = {en:'영어', ja:'일본어', zh:'중국어'};
function post(d,cb){var f=new FormData();for(var k in d)f.append(k,d[k]);
  fetch(location.href,{method:'POST',body:f}).then(r=>r.json()).then(cb).catch(function(){showToast('통신 오류','error');});}
function esc(s){var d=document.createElement('div');d.textContent=s==null?'':s;return d.innerHTML;}

/* 사이트맵 */
function loadSitemap(){
  showToast('사이트맵 불러오는 중…','ok');
  post({action:'load_sitemap'},function(d){
    if(!d.success){showToast(d.message||'실패','error');return;}
    var el=document.getElementById('pagePick'),html='';
    d.paths.forEach(function(p){html+='<label><input type="checkbox" class="pickCk" value="'+esc(p)+'" checked>'+esc(p)+'</label>';});
    el.innerHTML=html||'<div class="empty_state">페이지가 없습니다.</div>';
    document.getElementById('pickWrap').style.display='block';
    showToast(d.paths.length+'개 페이지 발견','ok');
  });
}
function toggleAll(v){document.querySelectorAll('.pickCk').forEach(function(c){c.checked=v;});}

/* 생성 대상 수집: 사이트맵 체크 + 수동 입력 합치기 */
function collectTargets(){
  var paths=[];
  document.querySelectorAll('.pickCk:checked').forEach(function(c){paths.push(c.value);});
  document.getElementById('urlInput').value.split('\n').forEach(function(u){
    u=u.trim(); if(!u)return;
    paths.push(u);
  });
  paths=[...new Set(paths)];
  var langs=[];
  document.querySelectorAll('.langCk:checked').forEach(function(c){langs.push(c.value);});
  return {paths:paths, langs:langs};
}

/* 순차 생성 */
var genRunning=false;
function runGenerate(){
  if(genRunning){showToast('이미 실행 중입니다.','error');return;}
  var t=collectTargets();
  if(!t.paths.length){showToast('페이지를 입력하거나 선택하세요.','error');return;}
  if(!t.langs.length){showToast('언어를 선택하세요.','error');return;}
  var jobs=[];
  t.paths.forEach(function(p){t.langs.forEach(function(l){jobs.push({path:p,lang:l});});});
  genRunning=true;
  var btn=document.getElementById('genBtn'),ico=document.getElementById('genIco');
  btn.disabled=true;ico.classList.add('spin');
  document.getElementById('genProgWrap').style.display='block';
  var done=0,ok=0,fail=0,failMsgs=[];
  function step(){
    if(done>=jobs.length){
      genRunning=false;btn.disabled=false;ico.classList.remove('spin');
      var msg='완료 — 성공 '+ok+' · 실패 '+fail;
      document.getElementById('genStat').textContent=(fail?'⚠ ':'✅ ')+msg+(failMsgs.length?' / '+failMsgs[0]:'');
      showToast(msg, fail?'error':'ok');
      loadList();
      return;
    }
    var j=jobs[done];
    document.getElementById('genStat').textContent='('+(done+1)+'/'+jobs.length+') '+j.path+' → '+LANG_LABEL[j.lang]+' 번역 중…';
    post({action:'generate',path:j.path,lang:j.lang,scope:document.getElementById('scopeInput').value.trim()},function(d){
      done++;
      if(d.success){ok++;}else{fail++;if(d.message)failMsgs.push(d.message);}
      document.getElementById('genProg').style.width=Math.round(done/jobs.length*100)+'%';
      setTimeout(step,300);
    });
  }
  step();
}

/* 변경 감지 */
function runDetect(){
  showToast('원문 변경 감지 중… (페이지 수만큼 소요)','ok');
  post({action:'detect'},function(d){
    if(!d.success){showToast('실패','error');return;}
    showToast('점검 '+d.checked+'페이지 — 변경 '+d.stale+'건','ok');
    loadList();
  });
}

/* 목록 */
function loadList(){
  post({action:'list'},function(d){
    if(!d.success)return;
    var tb=document.getElementById('listBody');
    if(!d.rows.length){tb.innerHTML='<tr><td colspan="6"><div class="empty_state">아직 생성된 번역 페이지가 없습니다.</div></td></tr>';return;}
    var stLabel={ok:'최신',stale:'원문변경',edited:'수정됨·재생성필요'};
    var html='';
    d.rows.forEach(function(r){
      html+='<tr>'
        +'<td class="path_cell">'+esc(r.path)+'</td>'
        +'<td><span class="lang_tag">'+esc(r.lang.toUpperCase())+'</span></td>'
        +'<td>'+r.seg_total+'</td>'
        +'<td><span class="st_chip '+esc(r.status)+'">'+(stLabel[r.status]||r.status)+'</span></td>'
        +'<td class="muted">'+esc(r.generated_at||'')+'</td>'
        +'<td>'
          +'<a class="btn_sm" style="text-decoration:none;margin-right:4px;" href="'+esc(r.path)+'?lang='+esc(r.lang)+'" target="_blank">보기</a>'
          +'<button class="btn_sm" style="margin-right:4px;" onclick="openSeg('+r.id+')">검수</button>'
          +'<button class="btn_sm" style="margin-right:4px;" onclick="regen(\''+esc(r.path)+'\',\''+esc(r.lang)+'\')">재생성</button>'
          +'<button class="btn_del" onclick="delPage('+r.id+')">삭제</button>'
        +'</td></tr>';
    });
    tb.innerHTML=html;
  });
}
function regen(path,lang){
  showToast('재생성 중… (변경분만 번역)','ok');
  post({action:'generate',path:path,lang:lang},function(d){
    showToast(d.success?'재생성 완료 — 신규 번역 '+d.translated_new+'건':(d.message||'실패'),d.success?'ok':'error');
    loadList();
  });
}
function delPage(id){
  if(!confirm('이 번역 페이지를 삭제할까요? (정적 파일도 함께 삭제되어 한국어로 폴백됩니다)'))return;
  post({action:'delete',id:id},function(d){if(d.success){showToast('삭제됨','ok');loadList();}});
}

/* 검수 모달 */
var curSeg={id:0,path:'',lang:''};
function openSeg(id){
  post({action:'segments',id:id},function(d){
    if(!d.success){showToast('불러오기 실패','error');return;}
    curSeg={id:id,path:d.path,lang:d.lang};
    document.getElementById('segTitle').textContent='검수 — '+d.path+' ('+LANG_LABEL[d.lang]+')';
    var html='';
    d.segs.forEach(function(s){
      html+='<div class="seg_row">'
        +'<div class="seg_ko">'+esc(s.ko)+'</div>'
        +'<div><input class="seg_tr'+(s.tr?'':' empty')+'" value="'+esc(s.tr).replace(/"/g,'&quot;')+'" onchange="saveSeg(\''+s.hash+'\',this)"></div>'
        +'</div>';
    });
    document.getElementById('segBody').innerHTML=html||'<div class="empty_state">문구가 없습니다.</div>';
    document.getElementById('segModalBg').classList.add('show');
  });
}
function saveSeg(hash,el){
  post({action:'save_seg',id:curSeg.id,hash:hash,value:el.value},function(d){
    if(d.success){el.classList.toggle('empty',!el.value.trim());showToast('저장됨 — 반영하려면 재생성','ok');}
    else showToast('저장 실패','error');
  });
}
function regenFromModal(){ closeSeg(); regen(curSeg.path,curSeg.lang); }
function closeSeg(){document.getElementById('segModalBg').classList.remove('show');loadList();}

function showToast(msg,type){
  var el=document.createElement('div');
  el.className='toast '+(type||'ok');
  el.innerHTML='<span class="material-symbols-outlined" style="font-size:16px;">'+(type==='error'?'error':'check_circle')+'</span>'+msg;
  document.body.appendChild(el);
  setTimeout(function(){el.remove();},3000);
}

loadList();
</script>
</body>
</html>
