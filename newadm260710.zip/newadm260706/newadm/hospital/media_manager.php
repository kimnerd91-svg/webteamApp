<?php
/* ============================================================
 *  /newadm/media/media_manager.php — 보도자료 관리
 *  - blog_manager.php(dm_gallery) 구조 참조, dm_media 테이블 사용
 *  - 필드: title(제목), category(카테고리), image(대표이미지),
 *          thumbnail(썸네일), link_url(연결 URL), display_order, is_visible
 * ============================================================ */
include_once('../_common.php');
include_once('../_auth_check.php');

// ── 이미지 업로드 (대표이미지/썸네일 공용, field로 폴더만 구분) ──
if (isset($_FILES['dm_image']['name']) && $_FILES['dm_image']['error'] === UPLOAD_ERR_OK) {
    while (ob_get_level()) ob_end_clean();
    $upload_dir = G5_DATA_PATH . '/media/' . date('Ym');
    $upload_url = G5_DATA_URL  . '/media/' . date('Ym');
    if (!is_dir($upload_dir)) { @mkdir($upload_dir, G5_DIR_PERMISSION, true); @chmod($upload_dir, G5_DIR_PERMISSION); }
    $ext = strtolower(pathinfo($_FILES['dm_image']['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg','jpeg','png','gif','webp'])) {
        header('Content-Type: application/json');
        echo json_encode(['success'=>0,'message'=>'이미지 파일만 업로드 가능합니다.']);
        exit;
    }
    $new_name = time().'_'.md5(uniqid()).'.'.$ext;
    if (move_uploaded_file($_FILES['dm_image']['tmp_name'], $upload_dir.'/'.$new_name)) {
        header('Content-Type: application/json');
        echo json_encode(['success'=>1,'url'=>$upload_url.'/'.$new_name]);
    } else {
        header('Content-Type: application/json');
        echo json_encode(['success'=>0,'message'=>'업로드 실패. 폴더 권한을 확인하세요.']);
    }
    exit;
}

// ── 테이블 생성 ─────────────────────────────────────────────
sql_query("CREATE TABLE IF NOT EXISTS `dm_media` (
    `id`            INT(11) NOT NULL AUTO_INCREMENT,
    `title`         VARCHAR(500) NOT NULL DEFAULT '',
    `category`      VARCHAR(100) DEFAULT '',
    `image`         VARCHAR(500) DEFAULT '',
    `thumbnail`     VARCHAR(500) DEFAULT '',
    `link_url`      VARCHAR(1000) DEFAULT '',
    `display_order` INT(11) DEFAULT 0,
    `is_visible`    TINYINT(1) DEFAULT 1,
    `created_at`    DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ── 삭제 ────────────────────────────────────────────────────
if (isset($_GET['delete_id'])) {
    sql_query("DELETE FROM dm_media WHERE id=" . (int)$_GET['delete_id']);
    alert_toast('삭제되었습니다.', './media_manager.php');
}

// ── 노출 토글 ───────────────────────────────────────────────
if (isset($_GET['toggle_id'])) {
    $tid = (int)$_GET['toggle_id'];
    $cur = sql_fetch("SELECT is_visible FROM dm_media WHERE id={$tid}");
    $new = $cur['is_visible'] ? 0 : 1;
    sql_query("UPDATE dm_media SET is_visible={$new} WHERE id={$tid}");
    header('Content-Type: application/json');
    echo json_encode(['success'=>1,'is_visible'=>$new]);
    exit;
}

// ── 추가 ────────────────────────────────────────────────────
if (isset($_POST['action']) && $_POST['action'] === 'add_media') {
    $title         = sql_real_escape_string(trim($_POST['title']));
    $category      = sql_real_escape_string(trim($_POST['category'] ?? ''));
    $image         = sql_real_escape_string(trim($_POST['image'] ?? ''));
    $thumbnail     = sql_real_escape_string(trim($_POST['thumbnail'] ?? ''));
    $link_url      = sql_real_escape_string(trim($_POST['link_url'] ?? ''));
    $display_order = (int)($_POST['display_order'] ?? 0);
    $is_visible    = isset($_POST['is_visible']) ? 1 : 0;
    sql_query("INSERT INTO dm_media SET
        title='{$title}', category='{$category}', image='{$image}', thumbnail='{$thumbnail}',
        link_url='{$link_url}', display_order='{$display_order}',
        is_visible='{$is_visible}', created_at=NOW()");
    alert_toast('추가되었습니다.', './media_manager.php', 'success');
}

// ── 수정 ────────────────────────────────────────────────────
if (isset($_POST['action']) && $_POST['action'] === 'update_media') {
    $id            = (int)$_POST['id'];
    $title         = sql_real_escape_string(trim($_POST['title']));
    $category      = sql_real_escape_string(trim($_POST['category'] ?? ''));
    $image         = sql_real_escape_string(trim($_POST['image'] ?? ''));
    $thumbnail     = sql_real_escape_string(trim($_POST['thumbnail'] ?? ''));
    $link_url      = sql_real_escape_string(trim($_POST['link_url'] ?? ''));
    $display_order = (int)($_POST['display_order'] ?? 0);
    $is_visible    = isset($_POST['is_visible']) ? 1 : 0;
    sql_query("UPDATE dm_media SET
        title='{$title}', category='{$category}', image='{$image}', thumbnail='{$thumbnail}',
        link_url='{$link_url}', display_order='{$display_order}',
        is_visible='{$is_visible}'
        WHERE id={$id}");
    alert_toast('수정되었습니다.', './media_manager.php', 'success');
}

// ── 카테고리 목록 (필터용, 기존 등록된 값 기준) ───────────────
$cat_result = sql_query("SELECT DISTINCT category FROM dm_media WHERE category<>'' ORDER BY category ASC");
$categories = [];
while ($c = sql_fetch_array($cat_result)) $categories[] = $c['category'];

// ── 목록 조회 ────────────────────────────────────────────────
$result = sql_query("SELECT * FROM dm_media ORDER BY display_order ASC, id DESC");
$medias = [];
while ($row = sql_fetch_array($result)) $medias[] = $row;
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>보도자료 관리</title>
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Pretendard', 'Apple SD Gothic Neo', sans-serif; background: #f5f6fa; color: #1a1a2e; }
        #admin_wrapper { display: flex; min-height: 100vh; }
        .content_area { flex: 1; padding: 40px; overflow-x: hidden; }

        .page_header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 28px; flex-wrap: wrap; gap: 12px; }
        .page_title  { font-size: 22px; font-weight: 700; }
        .btn_add { padding: 11px 22px; background: #4f46e5; color: #fff; border: none; border-radius: 9px; font-size: 13px; font-weight: 700; cursor: pointer; box-shadow: 0 4px 12px rgba(79,70,229,0.25); transition: all 0.2s; }
        .btn_add:hover { background: #4338ca; }

        .stat_bar { display: flex; gap: 16px; margin-bottom: 20px; flex-wrap: wrap; }
        .stat_chip { background: #fff; border: 1px solid #e8eaf0; border-radius: 10px; padding: 10px 18px; font-size: 13px; font-weight: 600; color: #5c5c7a; }
        .stat_chip span { font-size: 18px; font-weight: 700; color: #4f46e5; margin-right: 4px; }

        .filter_chips { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 20px; }
        .filter_chip { padding: 7px 16px; border-radius: 20px; font-size: 12px; font-weight: 700; background: #fff; border: 1px solid #e8eaf0; color: #5c5c7a; cursor: pointer; text-decoration: none; }
        .filter_chip.on { background: #4f46e5; color: #fff; border-color: #4f46e5; }

        /* 그리드 */
        .gl_grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 18px; }
        .gl_card { background: #fff; border-radius: 12px; border: 1px solid #e8eaf0; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.05); transition: all 0.2s; }
        .gl_card:hover { transform: translateY(-3px); box-shadow: 0 8px 24px rgba(0,0,0,0.1); border-color: #c4b5fd; }
        .gl_card.hidden_card { opacity: 0.5; }
        .gl_thumb { width: 100%; aspect-ratio: 4/3; object-fit: cover; display: block; background:#f5f6fa; }
        .gl_thumb_ph { width: 100%; aspect-ratio: 4/3; background: #f5f6fa; display: flex; align-items: center; justify-content: center; color: #9999bb; font-size: 13px; }
        .gl_body { padding: 14px 16px; }
        .gl_badge_wrap { display: flex; gap: 6px; margin-bottom: 8px; flex-wrap: wrap; }
        .gl_badge { display: inline-block; font-size: 11px; font-weight: 700; padding: 3px 10px; border-radius: 20px; }
        .gl_badge.visible   { background: #dcfce7; color: #166534; }
        .gl_badge.invisible { background: #fee2e2; color: #991b1b; }
        .gl_badge.cat       { background: #ede9fe; color: #5b21b6; }
        .gl_title { font-size: 15px; font-weight: 700; color: #1a1a2e; margin-bottom: 5px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .gl_link  { font-size: 11px; color: #4f46e5; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-bottom: 12px; display: block; }
        .gl_actions { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 6px; }
        .btn_gl { padding: 7px 4px; border: none; border-radius: 7px; font-size: 11px; font-weight: 700; cursor: pointer; transition: all 0.2s; }
        .btn_edit   { background: #4f46e5; color: #fff; }
        .btn_edit:hover { background: #4338ca; }
        .btn_toggle { background: #fef9c3; color: #854d0e; }
        .btn_toggle:hover { background: #fde68a; }
        .btn_del    { background: #fee2e2; color: #dc2626; }
        .btn_del:hover { background: #fecaca; }
        .empty_state { text-align: center; padding: 60px; color: #9999bb; font-size: 14px; }

        /* 모달 */
        .modal_overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.55); z-index: 10000; align-items: flex-start; justify-content: center; padding: 40px 20px; overflow-y: auto; }
        .modal_overlay.active { display: flex; }
        .modal_box { background: #fff; border-radius: 14px; width: 100%; max-width: 600px; overflow: hidden; animation: modal_in 0.25s ease; margin: auto; }
        @keyframes modal_in { from { transform: translateY(-20px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
        .modal_hd { padding: 20px 24px; border-bottom: 1px solid #e8eaf0; display: flex; align-items: center; justify-content: space-between; }
        .modal_hd h3 { font-size: 16px; font-weight: 700; }
        .modal_close { background: none; border: none; font-size: 20px; cursor: pointer; color: #9999bb; }
        .modal_bd { padding: 24px; display: flex; flex-direction: column; gap: 14px; max-height: 75vh; overflow-y: auto; }
        .form_group label { display: block; font-size: 12px; font-weight: 700; color: #9999bb; margin-bottom: 6px; }
        .form_input { width: 100%; border: 1px solid #e8eaf0; border-radius: 8px; padding: 10px 14px; font-size: 14px; background: #f5f6fa; font-family: inherit; transition: all 0.2s; }
        .form_input:focus { outline: none; border-color: #4f46e5; background: #fff; box-shadow: 0 0 0 3px rgba(79,70,229,0.1); }
        .form_grid2 { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
        .check_wrap { display: flex; align-items: center; gap: 8px; font-size: 14px; cursor: pointer; }
        .check_wrap input { width: 16px; height: 16px; cursor: pointer; accent-color: #4f46e5; }

        /* 업로드 존 */
        .upload_zone { border: 2px dashed #e8eaf0; border-radius: 10px; padding: 20px; text-align: center; cursor: pointer; transition: all 0.2s; background: #f5f6fa; position: relative; min-height: 90px; display: flex; flex-direction: column; align-items: center; justify-content: center; }
        .upload_zone:hover, .upload_zone.dragover { border-color: #4f46e5; background: #ede9fe; }
        .upload_zone input[type="file"] { position: absolute; inset: 0; opacity: 0; cursor: pointer; width: 100%; height: 100%; }
        .upload_zone_icon { font-size: 22px; margin-bottom: 4px; pointer-events: none; }
        .upload_zone_text { font-size: 12px; color: #9999bb; pointer-events: none; }
        .upload_zone_text strong { color: #4f46e5; }
        .upload_preview { width: 100%; height: 100px; object-fit: cover; border-radius: 8px; margin-top: 8px; border: 1px solid #e8eaf0; display: none; }
        .upload_loading { display: none; font-size: 12px; color: #9999bb; margin-top: 6px; text-align: center; }

        .modal_ft { padding: 16px 24px; border-top: 1px solid #e8eaf0; display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
        .btn_modal_cancel { padding: 12px; border-radius: 8px; background: #f5f6fa; color: #5c5c7a; border: 1px solid #e8eaf0; font-size: 14px; font-weight: 700; cursor: pointer; }
        .btn_modal_submit { padding: 12px; border-radius: 8px; background: #4f46e5; color: #fff; border: none; font-size: 14px; font-weight: 700; cursor: pointer; }
        .btn_modal_submit:hover { background: #4338ca; }
    </style>
</head>
<body>
<div id="admin_wrapper">
    <?php include_once('../aside.php'); ?>
    <main class="content_area">

        <div class="page_header">
            <h2 class="page_title">📰 보도자료 관리</h2>
            <button class="btn_add" onclick="openAddModal()">+ 보도자료 추가</button>
        </div>

        <div class="stat_bar">
            <div class="stat_chip"><span><?= count($medias) ?></span>전체</div>
            <div class="stat_chip"><span><?= count(array_filter($medias, fn($m)=>$m['is_visible'])) ?></span>노출중</div>
        </div>

        <?php if (!empty($categories)): ?>
        <div class="filter_chips">
            <a href="./media_manager.php" class="filter_chip <?= !isset($_GET['cat']) ? 'on' : '' ?>">전체</a>
            <?php foreach ($categories as $c): ?>
            <a href="./media_manager.php?cat=<?= urlencode($c) ?>" class="filter_chip <?= (isset($_GET['cat']) && $_GET['cat']===$c) ? 'on' : '' ?>"><?= htmlspecialchars($c) ?></a>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <?php
        $filtered = $medias;
        if (!empty($_GET['cat'])) {
            $filtered = array_values(array_filter($medias, fn($m) => $m['category'] === $_GET['cat']));
        }
        ?>

        <?php if (empty($filtered)): ?>
        <div class="empty_state">등록된 보도자료가 없습니다.</div>
        <?php else: ?>
        <div class="gl_grid">
            <?php foreach ($filtered as $m):
                $thumb_src = $m['thumbnail'] ?: $m['image'];
                $safe = htmlspecialchars(json_encode($m, JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8');
            ?>
            <div class="gl_card <?= $m['is_visible'] ? '' : 'hidden_card' ?>" id="card_<?= $m['id'] ?>">
                <?php if ($thumb_src): ?>
                <img class="gl_thumb" src="<?= htmlspecialchars($thumb_src) ?>" alt="<?= htmlspecialchars($m['title']) ?>">
                <?php else: ?>
                <div class="gl_thumb_ph">썸네일 없음</div>
                <?php endif; ?>
                <div class="gl_body">
                    <div class="gl_badge_wrap">
                        <span class="gl_badge <?= $m['is_visible'] ? 'visible' : 'invisible' ?>" id="badge_<?= $m['id'] ?>"><?= $m['is_visible'] ? '노출' : '숨김' ?></span>
                        <?php if ($m['category']): ?><span class="gl_badge cat"><?= htmlspecialchars($m['category']) ?></span><?php endif; ?>
                    </div>
                    <div class="gl_title"><?= htmlspecialchars($m['title']) ?></div>
                    <?php if ($m['link_url']): ?><a class="gl_link" href="<?= htmlspecialchars($m['link_url']) ?>" target="_blank"><?= htmlspecialchars($m['link_url']) ?></a><?php endif; ?>
                    <div class="gl_actions">
                        <button class="btn_gl btn_edit" onclick='openEditModal(<?= $safe ?>)'>수정</button>
                        <button class="btn_gl btn_toggle" id="toggle_btn_<?= $m['id'] ?>" onclick="toggleVisible(<?= $m['id'] ?>)"><?= $m['is_visible'] ? '숨기기' : '노출' ?></button>
                        <a class="btn_gl btn_del" href="?delete_id=<?= $m['id'] ?>" onclick="return confirm('정말 삭제하시겠습니까?')" style="text-align:center;text-decoration:none;">삭제</a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

    </main>
</div>

<!-- 추가 모달 -->
<div class="modal_overlay" id="addModal">
    <div class="modal_box">
        <form method="post" enctype="multipart/form-data">
            <input type="hidden" name="action" value="add_media">
            <div class="modal_hd"><h3>보도자료 추가</h3><button type="button" class="modal_close" onclick="closeModal('addModal')">✕</button></div>
            <div class="modal_bd">
                <div class="form_group"><label>제목</label><input type="text" name="title" class="form_input" required></div>
                <div class="form_group"><label>카테고리</label><input type="text" name="category" class="form_input" placeholder="예: 신문, 방송, 온라인" list="cat_list"></div>
                <datalist id="cat_list"><?php foreach ($categories as $c): ?><option value="<?= htmlspecialchars($c) ?>"><?php endforeach; ?></datalist>
                <div class="form_group"><label>연결 URL</label><input type="text" name="link_url" class="form_input" placeholder="https://"></div>

                <div class="form_grid2">
                    <div class="form_group">
                        <label>대표 이미지</label>
                        <div class="upload_zone" ondrop="handleDrop(event,'add_image_val','add_image_preview','add_image_loading')" ondragover="event.preventDefault();this.classList.add('dragover')" ondragleave="this.classList.remove('dragover')">
                            <input type="file" accept="image/*" onchange="uploadImage(this.files[0],'add_image_val','add_image_preview','add_image_loading')">
                            <div class="upload_zone_icon">🖼️</div>
                            <div class="upload_zone_text"><strong>클릭</strong> 또는 드래그</div>
                        </div>
                        <div class="upload_loading" id="add_image_loading">업로드 중…</div>
                        <img class="upload_preview" id="add_image_preview">
                        <input type="hidden" name="image" id="add_image_val">
                    </div>
                    <div class="form_group">
                        <label>썸네일</label>
                        <div class="upload_zone" ondrop="handleDrop(event,'add_thumb_val','add_thumb_preview','add_thumb_loading')" ondragover="event.preventDefault();this.classList.add('dragover')" ondragleave="this.classList.remove('dragover')">
                            <input type="file" accept="image/*" onchange="uploadImage(this.files[0],'add_thumb_val','add_thumb_preview','add_thumb_loading')">
                            <div class="upload_zone_icon">🖼️</div>
                            <div class="upload_zone_text"><strong>클릭</strong> 또는 드래그</div>
                        </div>
                        <div class="upload_loading" id="add_thumb_loading">업로드 중…</div>
                        <img class="upload_preview" id="add_thumb_preview">
                        <input type="hidden" name="thumbnail" id="add_thumb_val">
                    </div>
                </div>

                <div class="form_grid2">
                    <div class="form_group"><label>정렬 순서</label><input type="number" name="display_order" class="form_input" value="0"></div>
                    <div class="form_group" style="display:flex;align-items:flex-end;">
                        <label class="check_wrap"><input type="checkbox" name="is_visible" checked> 노출</label>
                    </div>
                </div>
            </div>
            <div class="modal_ft">
                <button type="button" class="btn_modal_cancel" onclick="closeModal('addModal')">취소</button>
                <button type="submit" class="btn_modal_submit">추가</button>
            </div>
        </form>
    </div>
</div>

<!-- 수정 모달 -->
<div class="modal_overlay" id="editModal">
    <div class="modal_box">
        <form method="post" enctype="multipart/form-data">
            <input type="hidden" name="action" value="update_media">
            <input type="hidden" name="id" id="edit_id">
            <div class="modal_hd"><h3>보도자료 수정</h3><button type="button" class="modal_close" onclick="closeModal('editModal')">✕</button></div>
            <div class="modal_bd">
                <div class="form_group"><label>제목</label><input type="text" name="title" id="edit_title" class="form_input" required></div>
                <div class="form_group"><label>카테고리</label><input type="text" name="category" id="edit_category" class="form_input" list="cat_list"></div>
                <div class="form_group"><label>연결 URL</label><input type="text" name="link_url" id="edit_link_url" class="form_input"></div>

                <div class="form_grid2">
                    <div class="form_group">
                        <label>대표 이미지</label>
                        <div class="upload_zone" ondrop="handleDrop(event,'edit_image_val','edit_image_preview','edit_image_loading')" ondragover="event.preventDefault();this.classList.add('dragover')" ondragleave="this.classList.remove('dragover')">
                            <input type="file" accept="image/*" onchange="uploadImage(this.files[0],'edit_image_val','edit_image_preview','edit_image_loading')">
                            <div class="upload_zone_icon">🖼️</div>
                            <div class="upload_zone_text"><strong>클릭</strong> 또는 드래그</div>
                        </div>
                        <div class="upload_loading" id="edit_image_loading">업로드 중…</div>
                        <img class="upload_preview" id="edit_image_preview">
                        <input type="hidden" name="image" id="edit_image_val">
                    </div>
                    <div class="form_group">
                        <label>썸네일</label>
                        <div class="upload_zone" ondrop="handleDrop(event,'edit_thumb_val','edit_thumb_preview','edit_thumb_loading')" ondragover="event.preventDefault();this.classList.add('dragover')" ondragleave="this.classList.remove('dragover')">
                            <input type="file" accept="image/*" onchange="uploadImage(this.files[0],'edit_thumb_val','edit_thumb_preview','edit_thumb_loading')">
                            <div class="upload_zone_icon">🖼️</div>
                            <div class="upload_zone_text"><strong>클릭</strong> 또는 드래그</div>
                        </div>
                        <div class="upload_loading" id="edit_thumb_loading">업로드 중…</div>
                        <img class="upload_preview" id="edit_thumb_preview">
                        <input type="hidden" name="thumbnail" id="edit_thumb_val">
                    </div>
                </div>

                <div class="form_grid2">
                    <div class="form_group"><label>정렬 순서</label><input type="number" name="display_order" id="edit_display_order" class="form_input"></div>
                    <div class="form_group" style="display:flex;align-items:flex-end;">
                        <label class="check_wrap"><input type="checkbox" name="is_visible" id="edit_is_visible"> 노출</label>
                    </div>
                </div>
            </div>
            <div class="modal_ft">
                <button type="button" class="btn_modal_cancel" onclick="closeModal('editModal')">취소</button>
                <button type="submit" class="btn_modal_submit">저장</button>
            </div>
        </form>
    </div>
</div>

<script>
function closeModal(id) { document.getElementById(id).classList.remove('active'); }

function openAddModal() {
    document.querySelectorAll('#addModal .upload_preview').forEach(el => { el.style.display='none'; el.src=''; });
    document.querySelectorAll('#addModal .upload_loading').forEach(el => el.style.display='none');
    document.getElementById('addModal').classList.add('active');
}

function openEditModal(data) {
    document.getElementById('edit_id').value            = data.id;
    document.getElementById('edit_title').value         = data.title;
    document.getElementById('edit_category').value      = data.category || '';
    document.getElementById('edit_link_url').value      = data.link_url || '';
    document.getElementById('edit_display_order').value = data.display_order;
    document.getElementById('edit_is_visible').checked  = data.is_visible == 1;

    document.getElementById('edit_image_val').value     = data.image || '';
    document.getElementById('edit_thumb_val').value      = data.thumbnail || '';
    document.getElementById('edit_image_loading').style.display = 'none';
    document.getElementById('edit_thumb_loading').style.display = 'none';

    const imgPrev = document.getElementById('edit_image_preview');
    if (data.image) { imgPrev.src = data.image; imgPrev.style.display = 'block'; } else { imgPrev.src=''; imgPrev.style.display='none'; }

    const thumbPrev = document.getElementById('edit_thumb_preview');
    if (data.thumbnail) { thumbPrev.src = data.thumbnail; thumbPrev.style.display = 'block'; } else { thumbPrev.src=''; thumbPrev.style.display='none'; }

    document.getElementById('editModal').classList.add('active');
}

function uploadImage(file, hiddenId, previewId, loadingId) {
    if (!file) return;
    document.getElementById(loadingId).style.display = 'block';
    document.getElementById(previewId).style.display = 'none';
    const fd = new FormData();
    fd.append('dm_image', file);
    fetch('./media_manager.php', { method: 'POST', body: fd })
        .then(r => r.json())
        .then(data => {
            document.getElementById(loadingId).style.display = 'none';
            if (data.success) {
                document.getElementById(hiddenId).value = data.url;
                document.getElementById(previewId).src  = data.url;
                document.getElementById(previewId).style.display = 'block';
            } else {
                alert(data.message || '업로드 실패');
            }
        })
        .catch(() => { document.getElementById(loadingId).style.display = 'none'; alert('업로드 중 오류'); });
}

function handleDrop(event, hiddenId, previewId, loadingId) {
    event.preventDefault();
    event.currentTarget.classList.remove('dragover');
    const file = event.dataTransfer.files[0];
    if (file && file.type.startsWith('image/')) uploadImage(file, hiddenId, previewId, loadingId);
    else alert('이미지 파일만 업로드 가능합니다.');
}

function toggleVisible(id) {
    fetch(`./media_manager.php?toggle_id=${id}`)
        .then(r => r.json())
        .then(data => {
            if (!data.success) return;
            const card  = document.getElementById('card_' + id);
            const badge = document.getElementById('badge_' + id);
            const btn   = document.getElementById('toggle_btn_' + id);
            if (data.is_visible) {
                card.classList.remove('hidden_card');
                badge.className = 'gl_badge visible';
                badge.textContent = '노출';
                btn.textContent = '숨기기';
            } else {
                card.classList.add('hidden_card');
                badge.className = 'gl_badge invisible';
                badge.textContent = '숨김';
                btn.textContent = '노출';
            }
        });
}
</script>
</body>
</html>
