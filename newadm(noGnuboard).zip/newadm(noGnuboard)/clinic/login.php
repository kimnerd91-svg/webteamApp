<?php
/**
 * /clinic/login.php — 병원용 관리자 로그인
 * - 인증: nerdDoc_member, Lv10 이상 (newadm login.php와 동일 제약)
 * - 성공 시 /clinic/index.php 로 이동
 * - dev_login 백도어 없음. 비번 리셋은 병원계정(mb_is_clinic=1)만 허용
 */
include_once($_SERVER['DOCUMENT_ROOT'] . '/common.php');

// 병원계정 플래그 컬럼 보장 (세션당 1회)
if (empty($_SESSION['_clinic_col_ok'])) {
    sql_query("ALTER TABLE {$g5['member_table']} ADD COLUMN IF NOT EXISTS `mb_is_clinic` TINYINT(1) NOT NULL DEFAULT 0", false);
    $_SESSION['_clinic_col_ok'] = 1;
}

// 자동 로그인 체크
if (!isset($_SESSION['adm_mb_id']) || !$_SESSION['adm_mb_id']) {
    if (!empty($_COOKIE['clinic_auto_login'])) {
        $token = sql_real_escape_string($_COOKIE['clinic_auto_login']);
        $row = sql_fetch(" SELECT * FROM {$g5['member_table']} WHERE mb_memo = '$token' AND mb_level >= 10 LIMIT 1 ");
        if (!empty($row['mb_id'])) {
            set_session('ss_mb_id', $row['mb_id']);
            $_SESSION['adm_mb_id']     = $row['mb_id'];
            $_SESSION['adm_mb_name']   = $row['mb_name'];
            $_SESSION['adm_login_time']= time();
            sql_query(" UPDATE {$g5['member_table']} SET mb_today_login = '".G5_TIME_YMDHIS."', mb_login_ip = '{$_SERVER['REMOTE_ADDR']}' WHERE mb_id = '{$row['mb_id']}' ");
            goto_url('/clinic/index.php');
        }
    }
}

// 이미 로그인되어 있으면 clinic 홈으로
if (isset($_SESSION['adm_mb_id']) && $_SESSION['adm_mb_id']) {
    goto_url('/clinic/index.php');
}

$error_msg = '';

// 로그인 처리
if (isset($_POST['mode']) && $_POST['mode'] == 'login') {
    $mb_id       = sql_real_escape_string(trim($_POST['mb_id']));
    $mb_password = trim($_POST['mb_password']);
    $auto_login  = isset($_POST['auto_login']) ? $_POST['auto_login'] : '';

    if (!$mb_id || !$mb_password) {
        $error_msg = '아이디와 비밀번호를 입력해주세요.';
    } else {
        $row = sql_fetch(" SELECT * FROM {$g5['member_table']} WHERE mb_id = '$mb_id' ");
        if (empty($row['mb_id'])) {
            $error_msg = '존재하지 않는 아이디입니다.';
        } else if ($row['mb_level'] < 10) {
            $error_msg = '관리자 권한이 없습니다.';
        } else if (!check_password($mb_password, $row['mb_password'])) {
            $error_msg = '비밀번호가 일치하지 않습니다.';
        } else {
            set_session('ss_mb_id', $row['mb_id']);
            $_SESSION['adm_mb_id']     = $row['mb_id'];
            $_SESSION['adm_mb_name']   = $row['mb_name'];
            $_SESSION['adm_login_time']= time();

            if ($auto_login == '1') {
                $token = md5($row['mb_id'].time().rand());
                setcookie('clinic_auto_login', $token, time() + (86400 * 7), '/');
                sql_query("UPDATE {$g5['member_table']} SET mb_memo = '$token' WHERE mb_id = '$mb_id'");
            }
            sql_query(" UPDATE {$g5['member_table']} SET mb_today_login = '".G5_TIME_YMDHIS."', mb_login_ip = '{$_SERVER['REMOTE_ADDR']}' WHERE mb_id = '$mb_id' ");
            goto_url('/clinic/index.php');
        }
    }
}

// 비밀번호 찾기 (병원계정만 0000 리셋)
if (isset($_POST['mode']) && $_POST['mode'] == 'reset_password') {
    $reset_email = sql_real_escape_string(trim($_POST['reset_email']));
    if (!$reset_email) {
        $error_msg = '이메일 주소를 입력해주세요.';
    } else {
        $row = sql_fetch(" SELECT mb_id FROM {$g5['member_table']} WHERE mb_email = '$reset_email' AND mb_level >= 10 AND mb_is_clinic = 1 ");
        if (empty($row['mb_id'])) {
            $error_msg = '등록된 병원 계정 이메일이 없습니다. (관리자에게 문의)';
        } else {
            $hash = get_encrypt_string("0000");
            sql_query(" UPDATE {$g5['member_table']} SET mb_password = '$hash' WHERE mb_id = '{$row['mb_id']}' ");
            alert_toast('비밀번호가 0000으로 리셋되었습니다.\n로그인 후 반드시 변경해주세요.', './login.php', 'success');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>병원 관리자 로그인</title>
    <style>
        *,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
        :root{ --c-main:#16a34a; --c-main-d:#15803d; --c-main-dd:#166534; --c-main-l:#dcfce7; --c-main-xl:#f0fdf4;
               --border:#e8eaf0; --muted:#9999bb; --strong:#1a1a2e; --text:#444466; }
        body{ font-family:'Pretendard','Apple SD Gothic Neo',sans-serif; min-height:100vh; background:#f5f6fa;
              display:flex; align-items:center; justify-content:center; padding:20px; color:var(--text); }
        .login_card{ width:100%; max-width:420px; background:#fff; border:1px solid var(--border);
              border-radius:20px; box-shadow:0 14px 50px rgba(20,83,45,.08); padding:40px 36px; }
        .lc_head{ text-align:center; margin-bottom:30px; }
        .lc_logo{ font-size:12px; font-weight:800; letter-spacing:2px; color:var(--c-main); }
        .lc_head h1{ font-size:24px; font-weight:800; color:var(--strong); margin-top:8px; }
        .lc_head p{ font-size:13px; color:var(--muted); margin-top:6px; }
        .field{ margin-bottom:16px; }
        .field label{ display:block; font-size:13px; font-weight:700; color:var(--strong); margin-bottom:7px; }
        .field input[type=text],.field input[type=password],.field input[type=email]{
              width:100%; height:48px; border:1px solid var(--border); border-radius:11px; padding:0 16px;
              font-size:15px; background:#fff; transition:all .2s; font-family:inherit; }
        .field input:focus{ outline:none; border-color:var(--c-main); box-shadow:0 0 0 3px rgba(22,163,74,.12); }
        .check_wrap{ display:flex; align-items:center; gap:9px; margin-bottom:20px; cursor:pointer; user-select:none; }
        .check_wrap input{ width:20px; height:20px; accent-color:var(--c-main); cursor:pointer; }
        .check_wrap span{ font-size:13.5px; color:var(--text); }
        .btn_login{ width:100%; height:50px; background:var(--c-main); color:#fff; border:none; border-radius:12px;
              font-size:16px; font-weight:800; cursor:pointer; transition:all .15s; }
        .btn_login:hover{ background:var(--c-main-d); box-shadow:0 6px 20px rgba(22,163,74,.22); }
        .btn_forgot{ width:100%; background:none; border:none; color:var(--muted); font-size:13px; font-weight:700;
              padding:14px 0 0; cursor:pointer; text-align:center; }
        .btn_forgot:hover{ color:var(--c-main-d); }
        .err{ background:#fef2f2; border:1px solid #fecaca; color:#dc2626; padding:12px 14px; border-radius:10px;
              margin-bottom:18px; font-size:13.5px; font-weight:600; }
        .modal_ov{ display:none; position:fixed; inset:0; background:rgba(26,26,46,.5); z-index:9999;
              align-items:center; justify-content:center; padding:20px; }
        .modal_ov.on{ display:flex; }
        .modal_bx{ background:#fff; border-radius:16px; padding:32px 28px; width:100%; max-width:380px; }
        .modal_bx h2{ font-size:18px; font-weight:800; color:var(--strong); margin-bottom:10px; }
        .modal_bx p{ font-size:13px; color:var(--muted); margin-bottom:18px; line-height:1.6; }
        .modal_btns{ display:flex; gap:10px; margin-top:6px; }
        .modal_btns button{ flex:1; height:46px; border-radius:11px; font-size:14px; font-weight:700; cursor:pointer; }
        .mb_cancel{ background:#f5f6fa; border:1px solid var(--border); color:var(--text); }
        .mb_ok{ background:var(--c-main); border:none; color:#fff; }
    </style>
</head>
<body>
    <div class="login_card">
        <div class="lc_head">
            <div class="lc_logo">CLINIC ADMIN</div>
            <h1>병원 관리자 로그인</h1>
            <p>상담 문의·콘텐츠 관리 전용</p>
        </div>

        <?php if ($error_msg): ?>
        <div class="err"><?= $error_msg ?></div>
        <?php endif; ?>

        <form method="post" action="">
            <input type="hidden" name="mode" value="login">
            <div class="field">
                <label>아이디</label>
                <input type="text" name="mb_id" placeholder="아이디 입력" required autofocus>
            </div>
            <div class="field">
                <label>비밀번호</label>
                <input type="password" name="mb_password" placeholder="비밀번호 입력" required>
            </div>
            <label class="check_wrap">
                <input type="checkbox" name="auto_login" value="1">
                <span>자동 로그인 (7일 유지)</span>
            </label>
            <button type="submit" class="btn_login">로그인</button>
            <button type="button" class="btn_forgot" onclick="document.getElementById('resetModal').classList.add('on')">비밀번호를 잊으셨나요?</button>
        </form>
    </div>

    <div class="modal_ov" id="resetModal">
        <div class="modal_bx">
            <h2>비밀번호 찾기</h2>
            <p>병원 계정 이메일을 입력하면 비밀번호를 <b>0000</b>으로 리셋합니다. 로그인 후 반드시 변경하세요.</p>
            <form method="post">
                <input type="hidden" name="mode" value="reset_password">
                <div class="field">
                    <label>이메일 주소</label>
                    <input type="email" name="reset_email" placeholder="example@email.com" required>
                </div>
                <div class="modal_btns">
                    <button type="button" class="mb_cancel" onclick="document.getElementById('resetModal').classList.remove('on')">취소</button>
                    <button type="submit" class="mb_ok">리셋</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        const rm = document.getElementById('resetModal');
        rm.addEventListener('click', function(e){ if (e.target === rm) rm.classList.remove('on'); });
    </script>
</body>
</html>