<?php
/**
 * nerdDoc bootstrap
 * 그누보드 코어에 대한 의존 없이 동작하는 독립 부트스트랩.
 * 파일명/include 경로는 기존 그누보드 common.php 자리를 그대로 유지해서
 * 이 파일을 include하는 수십 곳(newadm/_common.php, bbs/*.php, clinic/*.php 등)을
 * 한 곳도 고치지 않아도 되도록 한다. $g5 배열·sql_*·G5_* 상수 시그니처는
 * 기존 코드와 호환되게 유지하되, 내부 구현은 완전히 새 DB 기반으로 교체했다.
 */

if (!defined('_GNUBOARD_')) define('_GNUBOARD_', true);

error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE & ~E_WARNING);
// [임시 디버그] 카페24 운영 설정은 보통 display_errors=Off라 오류가 흰 화면으로만 나온다.
// 원인 파악되면 이 줄은 지우거나 0으로 되돌릴 것.
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');

//==============================================================================
// 경로 / URL 상수
//------------------------------------------------------------------------------
define('G5_PATH', str_replace('\\', '/', __DIR__));

$__nd_scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
define('G5_URL', $__nd_scheme . '://' . $_SERVER['HTTP_HOST']);
unset($__nd_scheme);

define('G5_DATA_DIR',  'data');
define('G5_DATA_PATH', G5_PATH . '/' . G5_DATA_DIR);
define('G5_DATA_URL',  G5_URL  . '/' . G5_DATA_DIR);

define('G5_BBS_DIR',  'bbs');
define('G5_BBS_PATH', G5_PATH . '/' . G5_BBS_DIR);
define('G5_BBS_URL',  G5_URL  . '/' . G5_BBS_DIR);

define('G5_ADMIN_DIR',  'newadm');
define('G5_ADMIN_PATH', G5_PATH . '/' . G5_ADMIN_DIR);
define('G5_ADMIN_URL',  G5_URL  . '/' . G5_ADMIN_DIR);

// 그누보드 코어의 정적 자산(jquery/common.js/wrest.js 등)은 서버의 실제 /js 폴더에
// 그대로 남아있는 정적 파일이라 경로만 유지한다. (PHP 로직 의존 없음)
define('G5_JS_URL',  G5_URL . '/js');
define('G5_JS_VER',  '1');
define('G5_CSS_VER', '1');

define('G5_DIR_PERMISSION', 0707);
define('G5_FILE_PERMISSION', 0606);

if (!is_dir(G5_DATA_PATH)) @mkdir(G5_DATA_PATH, G5_DIR_PERMISSION, true);

//==============================================================================
// 시간
//------------------------------------------------------------------------------
define('G5_SERVER_TIME', time());
define('G5_TIME_YMDHIS', date('Y-m-d H:i:s', G5_SERVER_TIME));
define('G5_TIME_YMD',    date('Y-m-d', G5_SERVER_TIME));

//==============================================================================
// DB 접속
//------------------------------------------------------------------------------
include_once(__DIR__ . '/_dbconfig.php');

// PHP 8.1+는 mysqli 연결 실패 시 기본적으로 예외(mysqli_sql_exception)를 던진다.
// 아래 die()가 "실패하면 false를 반환"하던 예전 방식을 가정하고 있으므로,
// 예전 방식으로 되돌려서 접속 실패 시 흰 화면 대신 이 메시지가 뜨게 한다.
mysqli_report(MYSQLI_REPORT_OFF);

$connect_db = mysqli_connect(NERDDOC_DB_HOST, NERDDOC_DB_USER, NERDDOC_DB_PASSWORD, NERDDOC_DB_NAME);
if (!$connect_db) {
    die('MySQL Connect Error: ' . mysqli_connect_error() . ' — _dbconfig.php의 DB 접속정보를 확인하세요.');
}
mysqli_set_charset($connect_db, 'utf8mb4');

// 참고용으로 원본 상수도 유지 (setup_admin.php의 백업 복원 기능 등이 참조)
define('G5_MYSQL_HOST',     NERDDOC_DB_HOST);
define('G5_MYSQL_USER',     NERDDOC_DB_USER);
define('G5_MYSQL_PASSWORD', NERDDOC_DB_PASSWORD);
define('G5_MYSQL_DB',       NERDDOC_DB_NAME);

//==============================================================================
// $g5 배열 — 테이블명 매핑 (신규 회원/게시판 테이블은 nerdDoc_ 접두사)
//------------------------------------------------------------------------------
$g5 = array(
    'connect_db'       => $connect_db,
    'member_table'     => 'nerdDoc_member',
    'board_table'      => 'nerdDoc_board',
    'board_new_table'  => 'nerdDoc_board_new',
    'board_file_table' => 'nerdDoc_board_file',
    'write_prefix'     => 'nerdDoc_write_',
    'visit_table'      => 'dm_visit',
    'title'            => '',
);

//==============================================================================
// DB 함수 (그누보드 sql_* 시그니처 호환)
//------------------------------------------------------------------------------
function sql_real_escape_string($str)
{
    global $connect_db;
    if (is_array($str)) return array_map('sql_real_escape_string', $str);
    return mysqli_real_escape_string($connect_db, (string) $str);
}

function sql_escape_string($str)
{
    return sql_real_escape_string($str);
}

function sql_query($sql, $die = true)
{
    global $connect_db;
    $result = mysqli_query($connect_db, $sql);
    if ($result === false && $die) {
        die('<pre>SQL Error: ' . htmlspecialchars(mysqli_error($connect_db)) . "\n\n" . htmlspecialchars($sql) . '</pre>');
    }
    return $result;
}

function sql_fetch($sql)
{
    $result = sql_query($sql, false);
    if (!$result) return array();
    $row = mysqli_fetch_assoc($result);
    return $row ?: array();
}

function sql_fetch_array($result)
{
    if (!$result) return false;
    return mysqli_fetch_assoc($result);
}

function sql_num_rows($result)
{
    if (!$result) return 0;
    return mysqli_num_rows($result);
}

function sql_affected_rows()
{
    global $connect_db;
    return mysqli_affected_rows($connect_db);
}

function sql_insert_id()
{
    global $connect_db;
    return mysqli_insert_id($connect_db);
}

function sql_error()
{
    global $connect_db;
    return mysqli_error($connect_db);
}

//==============================================================================
// 세션 / 쿠키
//------------------------------------------------------------------------------
ini_set('session.gc_maxlifetime', 86400);
if (session_status() === PHP_SESSION_NONE) {
    @session_start();
}

function set_session($key, $val) { $_SESSION[$key] = $val; }
function get_session($key, $default = '') { return $_SESSION[$key] ?? $default; }
function get_cookie($key, $default = '') { return $_COOKIE[$key] ?? $default; }
function set_cookie($key, $val, $expire_seconds = 0)
{
    setcookie($key, $val, $expire_seconds ? time() + $expire_seconds : 0, '/');
}

function goto_url($url)
{
    echo '<script>location.href="' . addslashes($url) . '";</script>';
    exit;
}

function alert($msg, $url = '')
{
    echo '<script>alert("' . addslashes($msg) . '");';
    if ($url) {
        echo 'location.href="' . addslashes($url) . '";';
    } else {
        echo 'history.back();';
    }
    echo '</script>';
    exit;
}

//==============================================================================
// 사이트 전역 설정 ($config) — bbs/register.php 등 회원가입 기본값에 사용
//------------------------------------------------------------------------------
$config = array(
    'cf_register_level' => 2,
    'cf_register_point' => 0,
    'cf_title'          => '',
);
$__nd_dm_conf = sql_fetch("SELECT cf_title, cf_site_name FROM dm_config WHERE cf_id = 1");
if (!empty($__nd_dm_conf)) {
    $config['cf_title'] = $__nd_dm_conf['cf_title'] ?: ($__nd_dm_conf['cf_site_name'] ?? '');
}
unset($__nd_dm_conf);

//==============================================================================
// 회원 함수
//------------------------------------------------------------------------------
function get_encrypt_string($str)
{
    return password_hash($str, PASSWORD_BCRYPT);
}

function check_password($input, $hash)
{
    if (!$hash) return false;
    return password_verify($input, $hash);
}

function get_member($mb_id)
{
    global $g5;
    if (!$mb_id) return array();
    $mb_id = sql_real_escape_string($mb_id);
    $row = sql_fetch("SELECT * FROM {$g5['member_table']} WHERE mb_id = '{$mb_id}'");
    return $row ?: array();
}

function insert_point($mb_id, $point, $content = '', $rel_table = '', $rel_id = '', $rel_action = '')
{
    global $g5;
    if (!$mb_id || !$point) return false;
    $mb_id_esc = sql_real_escape_string($mb_id);
    $point = (int) $point;
    return sql_query("UPDATE {$g5['member_table']} SET mb_point = mb_point + ({$point}) WHERE mb_id = '{$mb_id_esc}'", false);
}

//==============================================================================
// 유틸
//------------------------------------------------------------------------------
function run_event($trigger, $arg = null)
{
    // 리스너 없는 훅 시스템 — 그누보드 확장 파일 없이 호출부만 안전하게 통과
    return $arg;
}

function get_microtime()
{
    return microtime(true);
}

function clean_xss_tags($str)
{
    if (is_array($str)) return array_map('clean_xss_tags', $str);
    return strip_tags((string) $str);
}

function cut_str($str, $length, $suffix = '...')
{
    if (mb_strlen($str, 'UTF-8') <= $length) return $str;
    return mb_substr($str, 0, $length, 'UTF-8') . $suffix;
}

function get_search_string($str)
{
    return trim(strip_tags((string) $str));
}

$GLOBALS['__nd_js_queue'] = array();
function add_javascript($script, $priority = 0)
{
    $GLOBALS['__nd_js_queue'][] = $script;
}

function html_end()
{
    $out = implode("\n", $GLOBALS['__nd_js_queue']);
    $GLOBALS['__nd_js_queue'] = array();
    return $out . "\n</html>";
}

//==============================================================================
// 토스트 메시지 함수 (alert 대체용) — 기존 그누보드 common.php의 커스텀 함수를 그대로 이식
//------------------------------------------------------------------------------
function alert_toast($msg, $url = '', $type = 'default')
{
    echo "<style>
        .toast-message {
            position: fixed;
            bottom: 40px;
            left: 50%;
            transform: translateX(-50%) translateY(20px);
            background: rgba(255, 255, 255, 0.95);
            color: #333;
            padding: 16px 32px;
            border-radius: 12px;
            font-size: 15px;
            font-weight: 600;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            border: 1px solid #e5e7eb;
            backdrop-filter: blur(10px);
            z-index: 9999;
            opacity: 0;
            transition: all 0.3s ease;
        }
        .toast-message.show {
            opacity: 1;
            transform: translateX(-50%) translateY(0);
        }
        .toast-message.success {
            border-left: 4px solid #10b981;
            color: #059669;
        }
        .toast-message.error {
            border-left: 4px solid #ef4444;
            color: #dc2626;
        }
        .toast-message.warning {
            border-left: 4px solid #f59e0b;
            color: #d97706;
        }
    </style>";

    echo "<div id='toast' class='toast-message " . htmlspecialchars($type) . "'>"
        . htmlspecialchars($msg) . "</div>";

    echo "<script>
        setTimeout(() => document.getElementById('toast').classList.add('show'), 100);
        setTimeout(() => {
            document.getElementById('toast').classList.remove('show');
            setTimeout(() => {";

    if ($url) {
        echo "location.replace('" . addslashes($url) . "');";
    }

    echo "}, 300);
        }, 1500);
    </script>";
    exit;
}

//==============================================================================
// 로그인 상태 판별 (세션 → $member / $is_member / $is_admin)
//------------------------------------------------------------------------------
$member    = array('mb_id' => '', 'mb_level' => 1);
$is_member = false;
$is_admin  = '';

if (!empty($_SESSION['ss_mb_id'])) {
    $__nd_member = get_member($_SESSION['ss_mb_id']);
    if (!empty($__nd_member['mb_id'])) {
        $member    = $__nd_member;
        $is_member = true;
        if ((int) $member['mb_level'] >= 10) $is_admin = 'super';
    } else {
        unset($_SESSION['ss_mb_id']);
    }
    unset($__nd_member);
} elseif (!empty($_COOKIE['ck_mb_id']) && !empty($_COOKIE['ck_auto'])) {
    // 일반 회원(비관리자) 자동로그인
    $__nd_tmp_id = substr(preg_replace('/[^a-zA-Z0-9_]/', '', $_COOKIE['ck_mb_id']), 0, 20);
    $__nd_row = get_member($__nd_tmp_id);
    if (!empty($__nd_row['mb_password'])) {
        $__nd_key = md5(($_SERVER['SERVER_ADDR'] ?? '') . ($_SERVER['SERVER_SOFTWARE'] ?? '') . ($_SERVER['HTTP_USER_AGENT'] ?? '') . $__nd_row['mb_password']);
        if ($__nd_key === $_COOKIE['ck_auto']) {
            $member    = $__nd_row;
            $is_member = true;
            set_session('ss_mb_id', $member['mb_id']);
            if ((int) $member['mb_level'] >= 10) $is_admin = 'super';
        }
    }
    unset($__nd_tmp_id, $__nd_row, $__nd_key);
}

if (empty($member['mb_id'])) {
    $member = array('mb_id' => '', 'mb_level' => 1);
}

//==============================================================================
// 모바일 판별 (간이)
//------------------------------------------------------------------------------
define('G5_IS_MOBILE', (bool) preg_match('/mobile|android|iphone|ipad/i', $_SERVER['HTTP_USER_AGENT'] ?? ''));

//==============================================================================
// 방문자 카운트 (기존 dm_visit / dm_visit_sum 테이블 사용)
//------------------------------------------------------------------------------
$__nd_vi_ip = $_SERVER['REMOTE_ADDR'] ?? '';
if ($__nd_vi_ip && sql_num_rows(sql_query("SHOW TABLES LIKE 'dm_visit'", false)) > 0) {
    $__nd_vi_ip_esc = sql_real_escape_string($__nd_vi_ip);
    $__nd_vi_today  = date('Y-m-d');
    $__nd_vi_dup    = sql_fetch("SELECT vi_id FROM dm_visit WHERE vi_ip = '{$__nd_vi_ip_esc}' AND vi_date = '{$__nd_vi_today}' LIMIT 1");
    if (empty($__nd_vi_dup['vi_id'])) {
        $__nd_vi_agent = sql_real_escape_string(substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 490));
        $__nd_vi_ref   = sql_real_escape_string(substr($_SERVER['HTTP_REFERER'] ?? '', 0, 490));
        $__nd_vi_device = G5_IS_MOBILE ? 'Mobile' : 'PC';
        sql_query("INSERT INTO dm_visit SET vi_ip='{$__nd_vi_ip_esc}', vi_date='{$__nd_vi_today}', vi_time='" . date('H:i:s') . "', vi_referer='{$__nd_vi_ref}', vi_agent='{$__nd_vi_agent}', vi_device='{$__nd_vi_device}'", false);
        sql_query("INSERT INTO dm_visit_sum (vs_date, vs_count) VALUES ('{$__nd_vi_today}', 1) ON DUPLICATE KEY UPDATE vs_count = vs_count + 1", false);
    }
    unset($__nd_vi_ip_esc, $__nd_vi_today, $__nd_vi_dup, $__nd_vi_agent, $__nd_vi_ref, $__nd_vi_device);
}
unset($__nd_vi_ip);
