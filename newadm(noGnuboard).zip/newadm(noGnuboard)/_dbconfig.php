<?php
/**
 * nerdDoc — 독립 DB 접속 정보
 * 카페24 호스팅 관리 도구에서 신규로 만든 MySQL DB의 정보를 아래에 채워 넣는다.
 * 그누보드 DB와는 완전히 별개의 새 DB를 사용해야 한다.
 */

define('NERDDOC_DB_HOST', 'localhost');
define('NERDDOC_DB_USER', '여기에_DB_계정');
define('NERDDOC_DB_PASSWORD', '여기에_DB_비밀번호');
define('NERDDOC_DB_NAME', '여기에_DB_이름');
