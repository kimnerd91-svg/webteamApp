<?php
chdir(dirname(__FILE__) . '/../..');
include_once('./_common.php');

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if (!$id) { header('Location: /sub/board/case_list.php'); exit; }

// ── dm_beforeafter에서 데이터 조회 ───────────────────────
$post = sql_fetch("SELECT * FROM dm_beforeafter WHERE id = {$id} AND is_visible = 1");
if (!$post) { header('Location: /sub/board/case_list.php'); exit; }

// ── 이전/다음 ────────────────────────────────────────────
$prev = sql_fetch("SELECT id, title FROM dm_beforeafter WHERE is_visible=1 AND id > {$id} ORDER BY id ASC LIMIT 1");
$next = sql_fetch("SELECT id, title FROM dm_beforeafter WHERE is_visible=1 AND id < {$id} ORDER BY id DESC LIMIT 1");

// ── localStorage 멤버 확인 AJAX ──────────────────────────
if (isset($_GET['check_member'])) {
    $mb_id_chk = sql_real_escape_string($_GET['mb_id'] ?? '');
    $exists = $mb_id_chk ? sql_fetch("SELECT mb_id FROM {$g5['member_table']} WHERE mb_id = '{$mb_id_chk}'") : false;
    header('Content-Type: application/json');
    echo json_encode(['ok' => !empty($exists)]);
    exit;
}

$before  = !empty($post['image_before']) ? $post['image_before'] : '/images/defaultBF.png';
$after   = !empty($post['image_after'])  ? $post['image_after']  : '/images/defaultAF.png';
$cat     = htmlspecialchars($post['treatment_category'] ?? '');
$period  = htmlspecialchars($post['treatment_period']   ?? '');
$age     = htmlspecialchars($post['patient_age']        ?? '');
$gender  = !empty($post['patient_gender']) ? $post['patient_gender'].'성' : '';
$desc    = $post['description'] ?? '';
$date    = $post['created_at'] ? date('Y.m.d', strtotime($post['created_at'])) : '';

$is_logged_in = !empty($member['mb_id']);

include_once(G5_PATH . '/head_sub.php');
include_once(G5_PATH . '/head.php');
?>

<style>
.cv-wrap { max-width: 1440px; margin: 0 auto; padding: 60px 24px 100px; }

/* 헤더 */
.cv-header { margin-bottom: 40px; }
.cv-cat { display:inline-block; padding:4px 14px; background:var(--sub); color:var(--white); border-radius:20px; font-size:12px; font-weight:700; margin-bottom:14px; }
.cv-title { font-size:28px; font-weight:700; color:#1a1a2e; line-height:1.4; margin-bottom:16px; }
.cv-meta { display:flex; gap:16px; flex-wrap:wrap; align-items:center; }
.cv-meta span { font-size:13px; color:#6b7280; display:flex; align-items:center; gap:5px; }
.cv-meta strong { color:#374151; font-weight:600; }

/* B/A 이미지 */
.cv-images { display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-bottom:40px; border-radius:16px; overflow:hidden; }
.cv-img-box { position:relative;overflow:hidden; background:#f5f6fa; }
.cv-img-box img { width:100%; display:block; transition:transform .3s; }
.cv-img-box:hover img { transform:scale(1.03); }
.cv-img-label { position:absolute; top:12px; left:12px; padding:4px 12px; border-radius:20px; font-size:12px; font-weight:700; color:#fff; z-index:2; }
.cv-img-label.before { background:rgba(0,0,0,.55); }
.cv-img-label.after  { background: var(--point)}

/* 설명 */
.cv-desc { background:var(--gray-100); border-radius:12px; padding:28px 32px; margin-bottom:40px; line-height:1.9; color:#374151; }

/* 블러 오버레이 */
.cv-locked { position:relative; }
.cv-blur { filter:blur(12px); user-select:none; pointer-events:none; }
.cv-lock-overlay { position:absolute; inset:0; background:rgba(0,0,0,.55); z-index:50; display:flex; align-items:center; justify-content:center; padding:20px; border-radius:16px; }
.cv-lock-box { background:#fff; border-radius:20px; padding:40px; max-width:400px; width:100%; text-align:center; box-shadow:0 24px 60px rgba(0,0,0,.3); }
.cv-lock-icon { font-size:48px; margin-bottom:20px; }
.cv-lock-title { font-size:20px; font-weight:700; color:#1a1a2e; margin-bottom:10px; line-height:1.5; }
.cv-lock-sub { font-size:13px; color:#6b7280; line-height:1.7; margin-bottom:28px; }
.cv-lock-btn { display:block; width:100%; padding:14px; background:#4f46e5; color:#fff; border:none; border-radius:10px; font-size:15px; font-weight:700; cursor:pointer; text-decoration:none; transition:background .2s; }
.cv-lock-btn:hover { background:#4338ca; }

/* 가입 모달 (case_list 와 동일 톤) */
#cvJoinModal { display:none; position:fixed; inset:0; background:rgba(0,0,0,.6); z-index:9990; align-items:center; justify-content:center; padding:20px; }
#cvJoinModal.active { display:flex; }
.cv-modal-box { background:#fff; border-radius:16px; width:100%; max-width:420px; overflow:hidden; box-shadow:0 20px 60px rgba(0,0,0,.25); }
.cv-modal-head { display:flex; align-items:flex-start; justify-content:space-between; gap:12px; padding:20px 24px; border-bottom:1px solid #e8eaf0; }
.cv-modal-head .t { font-size:18px; font-weight:700; color:#1a1a2e; margin-bottom:4px; }
.cv-modal-head .s { font-size:12px; color:#9999bb; }
.cv-modal-x { background:none; border:none; font-size:22px; line-height:1; color:#9999bb; cursor:pointer; }
.cv-modal-body { display:flex; flex-direction:column; gap:14px; padding:20px 24px; }
.cv-modal-body label { font-size:12px; font-weight:700; color:#9999bb; margin-bottom:8px; display:block; }
.cv-modal-body input { width:100%; height:44px; padding:0 14px; border:1px solid #e8eaf0; background:#f5f6fa; border-radius:8px; font-size:14px; font-family:inherit; }
.cv-modal-note { font-size:11px; color:#9999bb; line-height:1.7; background:#f5f6fa; border-radius:8px; padding:10px 14px; }
.cv-modal-foot { display:grid; grid-template-columns:1fr 2fr; gap:10px; padding:16px 24px; border-top:1px solid #e8eaf0; }
.cv-modal-foot button { border:none; border-radius:8px; font-size:14px; font-weight:700; padding:12px; cursor:pointer; font-family:inherit; }
.cv-modal-foot .cancel { background:#f5f6fa; color:#374151; }
.cv-modal-foot .ok { background:var(--sub, #4f46e5); color:#fff; }

/* 이전/다음 */
.cv-nav { border-top:1px solid #e8eaf0; margin-top:60px; }
.cv-nav-item { display:flex; align-items:center; gap:16px; padding:16px 0; border-bottom:1px solid #f0f0f0; }
.cv-nav-label { font-size:12px; font-weight:700; color:#9999bb; white-space:nowrap; min-width:48px; }
.cv-nav-item a { font-size:14px; color:#374151; text-decoration:none; line-height:1.5; }
.cv-nav-item a:hover { color:#4f46e5; }
.cv-nav-item p { font-size:14px; color:var(--gray-500); }

@media(max-width:600px) {
    .cv-images { grid-template-columns:1fr; }
    .cv-desc { padding:20px; }
    .cv-lock-box { padding:28px 20px; }
}
</style>

<main class="u-pretendard">
    <div class="intro d-flex justify-content-center align-items-center flex-column u-gap-20 position-relative u-mt-80 u-mt-20-sm">
        <h6 class="t-fs-20 fw-700 u-lh-14 u-ls-10 u-txt-white" style="text-transform:uppercase;">Dentist Story</h6>
        <h2 class="t-fs-46 t-fs-32-sm fw-700 u-lh-14 u-ls-15 u-txt-white text-center">임상 증례</h2>
    </div>

    <div class="cv-wrap">

        <!-- 헤더 -->
        <div class="cv-header">
            <?php if ($cat): ?><span class="cv-cat"><?= $cat ?></span><?php endif; ?>
            <h1 class="cv-title"><?= htmlspecialchars($post['title']) ?></h1>
            <div class="cv-meta">
                <?php if ($date): ?><span><strong>등록일</strong><?= $date ?></span><?php endif; ?>
                <?php if ($period): ?><span><strong>치료기간</strong><?= $period ?></span><?php endif; ?>
                <?php if ($age): ?><span><strong>나이</strong><?= $age ?></span><?php endif; ?>
                <?php if ($gender): ?><span><strong>성별</strong><?= $gender ?></span><?php endif; ?>
            </div>
        </div>

        <!-- B/A 이미지 + 설명 (로그인/가입 체크) -->
        <div class="cv-locked" id="cvContent">
            <div id="cvInner">
                <!-- 이미지 -->
                <div class="cv-images">
                    <div class="cv-img-box">
                        <span class="cv-img-label before">Before</span>
                        <img class="w-100 h-100" src="<?= htmlspecialchars($before) ?>" alt="Before" onerror="this.src='/images/defaultBF.png'">
                    </div>
                    <div class="cv-img-box">
                        <span class="cv-img-label after">After</span>
                        <img class="w-100 h-100" src="<?= htmlspecialchars($after) ?>" alt="After" onerror="this.src='/images/defaultAF.png'">
                    </div>
                </div>

                <!-- 설명 -->
                <?php if ($desc): ?>
                <div class="cv-desc c-fs-16 fw-400">
                    <p class="cv-desc-title c-fs-20 fw-700 u-mb-16">치료 상세 내용</p>
                    <?= $desc ?>
                </div>
                <?php endif; ?>
            </div>

            <!-- 잠금 오버레이 (미가입 시 JS가 표시) -->
            <div class="cv-lock-overlay" id="cvLockOverlay" style="display:none;">
                <div class="cv-lock-box">
                    <div class="cv-lock-icon">🔒</div>
                    <p class="cv-lock-title">전·후 케이스는<br>로그인 후 확인 가능합니다</p>
                    <p class="cv-lock-sub">의료법 제56조에 의거하여<br>간단한 정보 입력 후 열람이 가능합니다.</p>
                    <button class="cv-lock-btn" onclick="cvModalOpen()">간편 로그인하기 →</button>
                </div>
            </div>
        </div>

        <!-- 이전/다음 -->
        <div class="cv-nav">
            <div class="cv-nav-item">
                <span class="cv-nav-label">▲ 다음</span>
                <?php if ($next): ?>
                    <a href="/case/<?= (int)$next['id'] ?>"><?= htmlspecialchars($next['title']) ?></a>
                <?php else: ?>
                    <p>다음 글이 없습니다.</p>
                <?php endif; ?>
            </div>
            <div class="cv-nav-item">
                <span class="cv-nav-label">▼ 이전</span>
                <?php if ($prev): ?>
                    <a href="/case/<?= (int)$prev['id'] ?>"><?= htmlspecialchars($prev['title']) ?></a>
                <?php else: ?>
                    <p>이전 글이 없습니다.</p>
                <?php endif; ?>
            </div>
        </div>

        <div style="text-align:center;margin-top:32px;">
            <a href="/case" style="display:inline-flex;align-items:center;gap:6px;padding:12px 28px;border:1px solid #e8eaf0;border-radius:50px;font-size:14px;color:#374151;text-decoration:none;font-weight:600;">
                <span class="material-symbols-outlined" style="font-size:16px;">arrow_back</span> 목록으로
            </a>
        </div>

    </div>

    <!-- 가입 모달 -->
    <div id="cvJoinModal">
        <div class="cv-modal-box">
            <div class="cv-modal-head">
                <div>
                    <p class="t">임상 증례 열람</p>
                    <p class="s">간단한 정보 입력 후 케이스를 확인하세요</p>
                </div>
                <button class="cv-modal-x" onclick="cvModalClose()">&times;</button>
            </div>
            <form method="post" id="cvJoinForm" action="/sub/board/case_list.php">
                <input type="hidden" name="action" value="simple_join">
                <div class="cv-modal-body">
                    <div>
                        <label>이름 *</label>
                        <input type="text" name="mb_name" placeholder="홍길동" required autocomplete="name">
                    </div>
                    <div>
                        <label>전화번호 *</label>
                        <input type="tel" name="mb_hp" placeholder="010-0000-0000" required autocomplete="tel"
                            oninput="this.value=this.value.replace(/[^0-9-]/g,'')">
                    </div>
                    <div>
                        <label>이메일 *</label>
                        <input type="email" name="mb_email" placeholder="example@email.com" required autocomplete="email">
                    </div>
                    <p class="cv-modal-note">입력하신 정보는 의료법 제56조 준수를 위한 열람 확인 목적으로만 사용되며 외부에 제공되지 않습니다.</p>
                </div>
                <div class="cv-modal-foot">
                    <button type="button" class="cancel" onclick="cvModalClose()">취소</button>
                    <button type="submit" class="ok">확인 후 열람하기</button>
                </div>
            </form>
        </div>
    </div>
</main>

<script>
(function () {
    var inner   = document.getElementById('cvInner');
    var overlay = document.getElementById('cvLockOverlay');
    var member  = localStorage.getItem('dm_member_hp');

    // 미가입자 → 블러 + 잠금 오버레이
    if (!member) {
        inner.classList.add('cv-blur');
        overlay.style.display = 'flex';
    }

    // 모달 제어
    window.cvModalOpen = function () {
        document.getElementById('cvJoinModal').classList.add('active');
    };
    window.cvModalClose = function () {
        document.getElementById('cvJoinModal').classList.remove('active');
    };
    document.getElementById('cvJoinModal').addEventListener('click', function (e) {
        if (e.target === this) cvModalClose();
    });

    // 가입 폼 제출 → localStorage 저장 후 현재 글 잠금 해제
    document.getElementById('cvJoinForm').addEventListener('submit', function (e) {
        e.preventDefault();
        var hp = (this.querySelector('[name=mb_hp]').value || '').replace(/[^0-9]/g, '');
        if (hp) localStorage.setItem('dm_member_hp', 'u' + hp);
        var form = this;
        fetch(form.action, { method: 'POST', body: new FormData(form) })
            .then(function () { unlock(); })
            .catch(function () { unlock(); });

        function unlock() {
            cvModalClose();
            inner.classList.remove('cv-blur');
            overlay.style.display = 'none';
        }
    });
})();
</script>
<script type="application/ld+json">
    <?php
    $host       = 'https://' . $_SERVER['HTTP_HOST'];
    $page_url   = $host . strtok($_SERVER['REQUEST_URI'], '?') . '?id=' . (int)$id;
    $list_url   = $host . '/sub/board/case_list.php';
    $clinic_ref = ['@id' => $host . '/#organization'];
 
    $absUrl = function ($path) use ($host) {
        if (!$path) return '';
        return (strpos($path, 'http') === 0) ? $path : $host . $path;
    };
 
    $cv_title = $post['title'] ?? '임상 증례';
    $cv_desc  = trim(strip_tags($post['description'] ?? '')) ?: ($post['subtitle'] ?? '실제 내원 환자분의 동의를 받아 게시한 치료 전후 임상 증례입니다.');
    $cv_date  = !empty($post['created_at']) ? date('Y-m-d', strtotime($post['created_at'])) : date('Y-m-d');
 
    // before/after 이미지
    $cv_images = [];
    if (!empty($post['image_before'])) {
        $cv_images[] = ['@type' => 'ImageObject', 'url' => $absUrl($post['image_before']), 'name' => $cv_title . ' - Before', 'caption' => 'Before'];
    }
    if (!empty($post['image_after'])) {
        $cv_images[] = ['@type' => 'ImageObject', 'url' => $absUrl($post['image_after']), 'name' => $cv_title . ' - After', 'caption' => 'After'];
    }
 
    $schema = [
 
        // 1. BreadcrumbList
        [
            '@context' => 'https://schema.org',
            '@type'    => 'BreadcrumbList',
            '@id'      => $page_url . '#breadcrumb',
            'itemListElement' => [
                ['@type' => 'ListItem', 'position' => 1, 'name' => '홈',       'item' => $host . '/'],
                ['@type' => 'ListItem', 'position' => 2, 'name' => '임상케이스', 'item' => $list_url],
                ['@type' => 'ListItem', 'position' => 3, 'name' => $cv_title,   'item' => $page_url],
            ],
        ],
 
        // 2. MedicalWebPage
        [
            '@context'     => 'https://schema.org',
            '@type'        => 'MedicalWebPage',
            '@id'          => $page_url . '#webpage',
            'name'         => $cv_title . ' | ' . $cf_site_name . ' 임상케이스',
            'description'  => $cv_desc,
            'url'          => $page_url,
            'inLanguage'   => 'ko-KR',
            'isPartOf'     => ['@id' => $host . '/#website'],
            'specialty'    => ['@type' => 'MedicalSpecialty', 'name' => 'Dentistry'],
            'audience'     => ['@type' => 'MedicalAudience', 'audienceType' => 'Patient'],
            'publisher'    => $clinic_ref,
            'breadcrumb'   => ['@id' => $page_url . '#breadcrumb'],
            'datePublished' => $cv_date,
            'lastReviewed' => $cv_date,
            'reviewedBy'   => $clinic_ref,
        ],
    ];
 
    // 3. ImageGallery — before/after 있을 때만
    if (!empty($cv_images)) {
        $schema[] = [
            '@context'    => 'https://schema.org',
            '@type'       => 'ImageGallery',
            '@id'         => $page_url . '#cases',
            'name'        => $cv_title . ' 치료 전후',
            'description' => '실제 내원 환자분의 동의를 받아 게시한 치료 전후 사진입니다. 결과는 개인마다 차이가 있을 수 있습니다.',
            'isPartOf'    => ['@id' => $page_url . '#webpage'],
            'image'       => $cv_images,
        ];
    }
 
    echo json_encode($schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    ?>
</script>

<?php include_once(G5_PATH . '/tail.php'); ?>