<?php
chdir(dirname(__FILE__) . '/..');
include_once('./_common.php');

global $connect_db;
$db = $connect_db;

$table        = 'nerdDoc_column';
$column_path  = '/sub';
$column_label = '원장님 칼럼';

$id = (int)($_GET['id'] ?? 0);
if (!$id) {
    header('Location: /');
    exit;
}

$post = mysqli_fetch_assoc(mysqli_query($db, "SELECT * FROM `{$table}` WHERE id={$id}"));
if (!$post) {
    header('Location: /');
    exit;
}

// 카테고리명
$cat_name = '미분류';
if (!empty($post['cat_id'])) {
    $cat_row = mysqli_fetch_assoc(mysqli_query($db, "SELECT name FROM nerdDoc_column_cat WHERE id=" . (int)$post['cat_id']));
    if ($cat_row) $cat_name = $cat_row['name'];
}

// 조회수
if (empty($_SESSION['viewed_col_' . $id])) {
    mysqli_query($db, "UPDATE `{$table}` SET hit=hit+1 WHERE id={$id}");
    $_SESSION['viewed_col_' . $id] = true;
    $post['hit'] = (int)$post['hit'] + 1;
}

// 이전/다음
$prev = mysqli_fetch_assoc(mysqli_query($db, "SELECT id,title FROM `{$table}` WHERE id > {$id} ORDER BY id ASC  LIMIT 1"));
$next = mysqli_fetch_assoc(mysqli_query($db, "SELECT id,title FROM `{$table}` WHERE id < {$id} ORDER BY id DESC LIMIT 1"));

$date = date('Y.m.d', strtotime($post['created_at']));
$tags = array_filter(array_map('trim', explode(',', $post['tags'] ?? '')));

// FAQ
$faqs = [];
if (!empty($post['faq'])) {
    $d = json_decode($post['faq'], true);
    if (is_array($d)) $faqs = $d;
}

// ── 블록 에디터 JSON → HTML 변환 ──────────────────────────
function render_block_content($json_str)
{
    $data = json_decode($json_str, true);
    if (!$data || !isset($data['rows'])) return $json_str;
    $html = '';
    foreach ($data['rows'] as $row) {
        $sec_id = !empty($row['sectionId']) ? ' id="' . htmlspecialchars($row['sectionId']) . '"' : '';
        $html .= '<div class="pb-row"' . $sec_id . '>';
        foreach ($row['columns'] as $col) {
            $span = (int)($col['span'] ?? 12);
            $html .= '<div class="pb-col pb-col-' . $span . '">';
            foreach ($col['blocks'] as $block) {
                $d = $block['data'] ?? [];
                $s = $d['style'] ?? [];
                $si = '';
                if (!empty($s['fontSize']))     $si .= 'font-size:'      . (int)$s['fontSize']  . 'px;';
                if (!empty($s['fontWeight']))    $si .= 'font-weight:'    . $s['fontWeight']      . ';';
                if (!empty($s['textAlign']))     $si .= 'text-align:'     . $s['textAlign']       . ';';
                if (!empty($s['color']))         $si .= 'color:'          . $s['color']           . ';';
                if (!empty($s['lineHeight']))    $si .= 'line-height:'    . $s['lineHeight']      . ';';
                if (!empty($s['letterSpacing'])) $si .= 'letter-spacing:' . $s['letterSpacing']  . 'px;';
                if (!empty($d['bgColor']))       $si .= 'background:'     . $d['bgColor']         . ';';
                $style = $si ? ' style="' . $si . '"' : '';
                switch ($block['type']) {
                    case 'paragraph': $html .= '<p'.$style.'>' . ($d['text'] ?? '') . '</p>'; break;
                    case 'h2': $html .= '<h2'.$style.'>' . ($d['text'] ?? '') . '</h2>'; break;
                    case 'h3': $html .= '<h3'.$style.'>' . ($d['text'] ?? '') . '</h3>'; break;
                    case 'h4': $html .= '<h4'.$style.'>' . ($d['text'] ?? '') . '</h4>'; break;
                    case 'quote': $html .= '<blockquote class="pb-quote"'.$style.'>' . ($d['text'] ?? '') . '</blockquote>'; break;
                    case 'warning':
                        $html .= '<div class="pb-warning"'.$style.'><strong>' . ($d['title'] ?? '') . '</strong><p>' . ($d['text'] ?? '') . '</p></div>';
                        break;
                    case 'image':
                        if (!empty($d['url'])) {
                            $br  = (int)($d['borderRadius'] ?? 6);
                            $alt = htmlspecialchars($d['alt'] ?? '');
                            $html .= '<img src="' . htmlspecialchars($d['url']) . '" alt="' . $alt . '" style="max-width:100%;border-radius:' . $br . 'px;display:block;">';
                        }
                        break;
                    case 'list':
                        $html .= '<ul'.$style.'>';
                        foreach ($d['items'] ?? [] as $item) $html .= '<li>' . $item . '</li>';
                        $html .= '</ul>';
                        break;
                    case 'delimiter': $html .= '<hr class="pb-hr">'; break;
                    case 'table':
                        if (!empty($d['rows'])) {
                            $html .= '<table class="pb-table"'.$style.'>';
                            foreach ($d['rows'] as $ri => $trow) {
                                $html .= '<tr>';
                                foreach ($trow as $cell) {
                                    $html .= ($ri === 0) ? '<th>' . $cell . '</th>' : '<td>' . $cell . '</td>';
                                }
                                $html .= '</tr>';
                            }
                            $html .= '</table>';
                        }
                        break;
                    case 'button':
                        $href = htmlspecialchars($d['href'] ?? '#');
                        $html .= '<div class="pb-btn-wrap"><a class="pb-btn"'.$style.' href="'.$href.'">' . ($d['text'] ?? '버튼') . '</a></div>';
                        break;
                    case 'faq':
                        if (!empty($d['items'])) {
                            $html .= '<div class="pb-faq">';
                            foreach ($d['items'] as $fi) {
                                $html .= '<details class="pb-faq-item">';
                                $html .= '<summary class="pb-faq-q">' . ($fi['q'] ?? '') . '</summary>';
                                $html .= '<div class="pb-faq-a">' . ($fi['a'] ?? '') . '</div>';
                                $html .= '</details>';
                            }
                            $html .= '</div>';
                        }
                        break;
                }
            }
            $html .= '</div>';
        }
        $html .= '</div>';
    }
    return $html;
}

$editor_type = $post['editor_type'] ?? 'html';
$raw = $post['content'] ?? '';
// 저장 시 mysqli_real_escape_string으로 생긴 백슬래시 제거
$raw = stripslashes($raw);

// editor_type 컬럼이 없거나 기본값 'html'이어도
// JSON에 'rows' 키가 있으면 블록 에디터 콘텐츠로 자동 감지
if ($editor_type !== 'builder') {
    $_test = json_decode($raw, true);
    if (is_array($_test) && isset($_test['rows'])) {
        $editor_type = 'builder';
    }
}

$content = ($editor_type === 'builder')
    ? render_block_content($raw)
    : $raw;

// ── 상대경로 이미지 제거 (서버에서 접근 불가) ─────────────
$content = preg_replace_callback('/<img[^>]+>/i', function($m) {
    if (preg_match('/src=["\']([^"\']*)["\']/', $m[0], $s)) {
        $src = $s[1];
        // http/https 또는 /로 시작하지 않으면 제거
        if (!preg_match('/^https?:\/\//i', $src) && strpos($src, '/') !== 0) {
            return '';
        }
    }
    return $m[0];
}, $content);

// ── 구버전 본문 마이크로데이터 제거 (JSON-LD FAQPage와 중복 방지) ──
// 일부 구버전 글은 본문에 itemscope/itemprop/itemtype(FAQPage·Question 등)을 갖고 있음.
// 이제 FAQPage는 아래에서 JSON-LD로 일원 생성하므로, 본문의 스키마 속성만 벗긴다(보이는 구조·텍스트는 유지).
$content = preg_replace('/\s+item(scope|type|prop)(=("[^"]*"|\'[^\']*\'))?/i', '', $content);

// ── FAQPage 스키마용 FAQ 수집 ─────────────────────────────
// maker는 마이크로데이터 없이 순수 <details><summary>Q</summary>답변</details>만 출력하므로,
// 시스템(여기)이 본문을 파싱해 FAQPage JSON-LD를 생성한다. 소스 2가지 + 중복제거:
//   (1) 본문 $content 안의 <details> 전부 (builder pb-faq / 레거시 .faq-item / maker 출력 공통)
//   (2) 별도 저장된 $post['faq'] (위에서 $faqs로 디코드됨)
$faq_pairs = [];

// (1) 본문 details 파싱
if (preg_match_all('/<details\b[^>]*>(.*?)<\/details>/is', $content, $dm_all)) {
    foreach ($dm_all[1] as $inner) {
        if (!preg_match('/<summary\b[^>]*>(.*?)<\/summary>/is', $inner, $sm)) continue;
        $q = trim(html_entity_decode(strip_tags($sm[1]), ENT_QUOTES, 'UTF-8'));
        // summary를 제거한 나머지가 답변
        $a_html = preg_replace('/<summary\b[^>]*>.*?<\/summary>/is', '', $inner, 1);
        $a = trim(html_entity_decode(strip_tags($a_html), ENT_QUOTES, 'UTF-8'));
        $a = preg_replace('/\s+/', ' ', $a);
        if ($q !== '' && $a !== '') $faq_pairs[] = ['q' => $q, 'a' => $a];
    }
}

// (2) 별도 $faqs 병합 (q/a 키 다양성 대응)
foreach ($faqs as $fi) {
    $q = trim(strip_tags($fi['q'] ?? $fi['question'] ?? ''));
    $a = trim(strip_tags($fi['a'] ?? $fi['answer'] ?? ''));
    $a = preg_replace('/\s+/', ' ', $a);
    if ($q !== '' && $a !== '') $faq_pairs[] = ['q' => $q, 'a' => $a];
}

// 질문 기준 중복 제거 (앞 'Q.' 접두어 정규화 후 비교)
$faq_seen = [];
$faq_unique = [];
foreach ($faq_pairs as $p) {
    $key = preg_replace('/^Q\.?\s*/u', '', $p['q']);
    $key = preg_replace('/\s+/', '', mb_strtolower($key, 'UTF-8'));
    if ($key === '' || isset($faq_seen[$key])) continue;
    $faq_seen[$key] = true;
    $faq_unique[] = $p;
}

// SEO
// cf_ceo_name 컬럼 보장 (Editor 표기용 — 없으면 최초 1회만 추가)
$ceo_col_chk = mysqli_query($db, "SHOW COLUMNS FROM `dm_config` LIKE 'cf_ceo_name'");
if ($ceo_col_chk && mysqli_num_rows($ceo_col_chk) == 0) {
    mysqli_query($db, "ALTER TABLE `dm_config` ADD `cf_ceo_name` varchar(100) DEFAULT ''");
}
$dm_conf = mysqli_fetch_assoc(mysqli_query($db, "SELECT cf_site_name, cf_doctors, cf_ceo_name FROM dm_config WHERE cf_id=1"));
$hospital_name = $dm_conf['cf_site_name'] ?? $_SERVER['HTTP_HOST'];
$editor_name   = trim($dm_conf['cf_ceo_name'] ?? '');
$subtitle      = trim($post['subtitle'] ?? '');
$site_url  = 'https://' . $_SERVER['HTTP_HOST'];
$page_url  = $site_url . $_SERVER['REQUEST_URI'];

// 헤더 히어로 이미지 (하단 JSON-LD article.image와 동일 소스)
$thumb_url  = !empty($post['thumbnail'])
    ? (strpos($post['thumbnail'], 'http') === 0 ? $post['thumbnail'] : $site_url . $post['thumbnail'])
    : '';

$g5['title']      = $post['title'];
$page_description = !empty($post['meta_desc'])
    ? $post['meta_desc']
    : mb_substr(trim(preg_replace('/\s+/', ' ', strip_tags($content))), 0, 160, 'UTF-8');

// canonical — id 파라미터 포함 (head_sub의 path-only canonical을 override)
$protocol       = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$page_canonical = $protocol . '://' . $_SERVER['HTTP_HOST'] . '/column/' . $id;

include_once(G5_PATH . '/head_sub.php');
include_once(G5_PATH . '/head.php');
?>

<main class="u-pretendard column-detail u-pb-80">
    <div class="u-fluid-lg u-fluid-xl-sm u-px-20-sm mx-auto col-article-wrap u-pt-150-sm">
        <div class="row col-article-row">
            <!-- 좌측: 카테고리/제목/부제목/태그/에디터/날짜 + 목차 (sticky) -->
            <div class="col-lg-4 col-article-left">
                <span class="col-head-cat u-txt-point c-fs-12 fw-700 u-bd-1 u-b-solid u-bc-point u-round-20 u-px-10 u-py-4 w-max d-inline-block u-mb-16"><?= htmlspecialchars($cat_name) ?></span>
                <h1 class="u-txt-dark t-fs-32 t-fs-24-md fw-700 u-lh-13 u-mb-16"><?= htmlspecialchars($post['title']) ?></h1>
                <?php if ($subtitle !== ''): ?>
                    <p class="u-txt-gray-600 c-fs-14 u-lh-15 u-mb-20"><?= htmlspecialchars($subtitle) ?></p>
                <?php endif; ?>
                <?php if (!empty($tags)): ?>
                    <div class="d-flex flex-wrap u-gap-6 u-mb-24">
                        <?php foreach ($tags as $t): ?>
                            <span class="u-txt-gray-600 c-fs-12 fw-600 u-bg-gray-100 u-round-8 u-px-10 u-py-4">#<?= htmlspecialchars($t) ?></span>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
                <div class="u-pt-14 u-mb-28">
                    <?php if ($editor_name !== ''): ?>
                        <p class="c-fs-12 u-txt-dark u-mb-4">Editor <b class="fw-700"><?= htmlspecialchars($editor_name) ?></b></p>
                    <?php endif; ?>
                    <p class="c-fs-12 u-txt-gray-500"><?= $date ?></p>
                </div>

                <!-- 목차: 박스/테두리 없이 세로 리스트만 -->
                <div class="col-toc u-pt-8">
                    <p class="c-fs-12 fw-700 u-txt-main d-flex align-items-center u-gap-6 u-mb-12">
                        <span class="material-symbols-outlined" style="font-size:var(--sp-16);">menu_book</span>목차
                    </p>
                    <nav id="tocNav"></nav>
                </div>
            </div>

            <!-- 우측: 본문 (스크롤 시 여기만 이동) — 썸네일이 있으면 항상 맨 앞, 그 다음 본문 텍스트 -->
            <div class="col-lg-8 col-article-right">
                <?php if ($thumb_url): ?>
                    <figure class="col-thumb-figure u-mb-28">
                        <img src="<?= htmlspecialchars($thumb_url) ?>" alt="<?= htmlspecialchars($post['title']) ?>" class="w-100 u-round-8">
                    </figure>
                <?php endif; ?>
                <div id="content">
                    <?= $content ?>
                </div>

            </div>
        </div>
    </div>

    <div class="u-fluid-lg u-fluid-xl-sm u-px-20-sm">
        <div class="u-bt-1 u-bc-gray-300 u-py-40 content-footer">
            <h2 class="u-mt-48 u-txt-dark t-fs-16 fw-600 u-mb-8 u-notoserif text-center"><?= htmlspecialchars($hospital_name) ?></h2>
            <p class="u-txt-gray-700 u-lh-20 c-fs-14 text-center">좋은 치료를 위해 온 마음을 담는 <?= htmlspecialchars($hospital_name) ?>입니다. 감사합니다.</p>
            <div class="u-px-20 u-mt-60">
                <?php
                $has_treat = !empty($post['treat_start']) || !empty($post['treat_end']) || !empty($post['treat_side']);
                ?>
                <?php if ($has_treat): ?>
                    <div class="u-bd-1 u-round-8 u-px-24 u-py-16 u-mb-100 u-bc-gray-300 u-b-solid">
                        <h6 class="u-txt-point u-mb-16 fw-700 t-fs-14">치료 정보</h6>
                        <ul>
                            <?php if (!empty($post['treat_start'])): ?>
                                <li><p class="u-txt-gray-500 u-mb-16 fw-400 t-fs-14"><strong class="u-txt-dark fw-600">치료 시작일:</strong> <?= htmlspecialchars($post['treat_start']) ?></p></li>
                            <?php endif; ?>
                            <?php if (!empty($post['treat_end'])): ?>
                                <li><p class="u-txt-gray-500 u-mb-16 fw-400 t-fs-14"><strong class="u-txt-dark fw-600">치료 종료일:</strong> <?= htmlspecialchars($post['treat_end']) ?></p></li>
                            <?php endif; ?>
                            <?php if (!empty($post['treat_side'])): ?>
                                <li><p class="u-txt-gray-500 u-mb-16 fw-400 t-fs-14"><strong class="u-txt-dark fw-600">부작용 및 합병증:</strong> <?= htmlspecialchars($post['treat_side']) ?></p></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <div class="u-round-8 u-px-24 u-py-16 u-bg-light">
                    <h6 class="u-txt-main u-mb-16 fw-700 t-fs-14">의료법상 고지 의무 사항</h6>
                    <p class="c-fs-16 u-mb-20 u-txt-gray-700 fw-500 u-lh-15 c-fs-20 fw-400"><strong><?= htmlspecialchars($hospital_name) ?> 블로그의 모든 게시물은 환자분께 의학적으로 정확하고 상세한 정보를 제공하기 위해 대표원장이 직접 작성합니다.</strong></p>
                    <ul>
                        <li class="u-txt-gray-500 c-fs-12 fw-400 u-gap-8 d-flex align-items-start"><span class="d-block">ㆍ</span>본 포스팅은 의료 정보 제공 및 광고를 목적으로 환자분의 동의를 받아 의료법 제56조 및 의료법 시행령 제23조를 준수하여 작성하였습니다.</li>
                        <li class="u-txt-gray-500 c-fs-12 fw-400 u-gap-8 d-flex align-items-start"><span class="d-block">ㆍ</span>사용된 모든 사진은 본원에서 치료받은 환자로, 동일 부위를 같은 환경에서 촬영하였으며, 일체의 후보정작업은 거치지 않았습니다.</li>
                        <li class="u-txt-gray-500 c-fs-12 fw-400 u-gap-8 d-flex align-items-start"><span class="d-block">ㆍ</span>치료의 결과는 환자들마다 상이할 수 있으며, 이 치료 결과는 본 케이스에만 해당되는 것입니다.</li>
                        <li class="u-txt-gray-500 c-fs-12 fw-400 u-gap-8 d-flex align-items-start"><span class="d-block">ㆍ</span>모든 치과 시술은 개인의 특성에 따라 크고 작은 부작용이 발생될 수 있습니다.</li>
                        <li class="u-txt-gray-500 c-fs-12 fw-400 u-gap-8 d-flex align-items-start"><span class="d-block">ㆍ</span>정확한 사항은 경험이 풍부한 의료진과 충분히 상의하신 후에 시술을 결정하시기 바랍니다.</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</main>

<style>

    /* 관련 링크 박스 */
.related-link-box { display:flex; align-items:stretch; border:1px solid #e8eaf0; border-radius:var(--sp-12); overflow:hidden; text-decoration:none; margin:var(--sp-24) 0; background:#fff; transition:box-shadow .2s, border-color .2s; }
.related-link-box:hover { border-color:var(--sub-color,#4a7ab5); box-shadow:0 4px var(--sp-16) rgba(0,0,0,.08); }
.rlb-img { width:1var(--sp-20); min-width:1var(--sp-20); flex-shrink:0; background:#f5f6fa; overflow:hidden; display:flex; align-items:center; justify-content:center; }
.rlb-img img { width:100%; height:100%; object-fit:cover; display:block; }
.rlb-img-ph { font-size:var(--sp-28); color:#c4b5fd; }
.rlb-content { flex:1; display:flex; flex-direction:column; justify-content:center; min-width:0; }
.related-link-box .rlb-body { padding:var(--sp-14) var(--sp-16) var(--sp-10); }
.related-link-box .rlb-title { font-size:var(--sp-14); font-weight:700; color:#1a1a2e; margin-bottom:5px; line-height:1.4; }
.related-link-box .rlb-desc { font-size:var(--sp-12); color:#6b7280; line-height:1.6; display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden; }
.related-link-box .rlb-url { padding:6px var(--sp-16); background:#f5f6fa; font-size:11px; color:var(--main-color,#25456b); border-top:1px solid #e8eaf0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
@media(max-width:600px){ .rlb-img{width:80px;min-width:80px;} }
    /* ── 기사 2단 레이아웃: 좌(sticky, 카테고리·제목·부제·태그·에디터·목차) / 우(본문, 스크롤) ── */
    /* 사이트 상단 고정 헤더 높이 — 실제 헤더 px에 맞게 이 값만 조정하면 됨 */
    :root { --col-header-h: var(--sp-120); }
    .col-article-wrap { padding-top: var(--col-header-h); margin-left: 0; margin-right: auto; }
    .col-article-row { align-items: flex-start; }
    .col-article-left { position: sticky; top: var(--col-header-h); }
    .col-article-right { min-width: 0; }

    /* 목차: 세로 리스트, 대제목(h2)-소제목(h3), 유동 폰트사이즈 */
    #tocNav ul { list-style: none; padding: 0; margin: 0; }
    #tocNav li { margin: 0; }
    #tocNav .toc-h2 > a {
        display: block; text-decoration: none; color: #374151; font-weight: 700;
        font-size: clamp(var(--sp-14), 0.35vw + var(--sp-14), var(--sp-16));
        padding: 8px var(--sp-10); border-radius: 7px; line-height: 1.5;
        border-left: 3px solid transparent; transition: all .15s;
    }
    #tocNav .toc-h3 > a {
        display: block; text-decoration: none; color: #6b7280; font-weight: 500;
        font-size: clamp(12.5px, 0.25vw + 11.5px, var(--sp-14));
        padding: 6px var(--sp-10) 6px var(--sp-22); border-radius: 7px; line-height: 1.5;
        border-left: 3px solid transparent; transition: all .15s;
    }
    #tocNav a:hover { background: var(--light, #F9FBF4); color: var(--main-color); }
    #tocNav a.active { background: var(--light2, #F6F4EC); color: var(--main-color) !important; font-weight: 700; border-left-color: var(--point); }

    @media (max-width: 991.98px) {
        .col-article-wrap { padding-top: var(--sp-80); }
        .col-article-left { position: static; top: auto; margin-bottom: var(--sp-32); }
    }

    /* ── 본문(우측 컬럼) 콘텐츠 ── */
    #content { font-size: var(--sp-16); line-height: 1.95; color: #333; }

    /* ── 본문 공통 ── */
    #content p { font-size: var(--sp-16); line-height: 1.95; color: #333; margin-bottom: var(--sp-18); }
    #content strong { font-weight: 700; }
    #content a { color: var(--sub-color, #2563eb); }
    #content img { max-width: 100%; border-radius: 6px; margin: var(--sp-24) 0; display: block; width: 100% }

    /* H2 — main-color + sub-color 보더 */
    #content h2 {
        display: flex;
        align-items: center;
        gap: var(--sp-12);
        font-size: var(--sp-20);
        font-weight: 700;
        color: var(--main-color, #25456b);
        margin: var(--sp-44) 0 var(--sp-16);
        padding-bottom: var(--sp-12);
        border-bottom: 2px solid var(--sub-color, #4a7ab5);
        scroll-margin-top: 1var(--sp-20);
    }
    #content h2::before {
        content: '';
        display: block;
        width: 4px;
        min-width: 4px;
        height: var(--sp-22);
        background: var(--main-color, #25456b);
        border-radius: 2px;
        flex-shrink: 0;
    }

    /* H3 */
    #content h3 { font-size: var(--sp-16); font-weight: 700; color: #1a1a1a; margin: var(--sp-28) 0 var(--sp-10); scroll-margin-top: 1var(--sp-20); }

    /* H4 */
    #content h4 { font-size: var(--sp-14); font-weight: 700; color: #333; margin: var(--sp-20) 0 8px; }

    /* H6 — 인용 강조 박스 */
    #content h6 {
        border: 1px solid #e8d9bc;
        border-left: 4px solid var(--sub-color, #e8a020);
        border-radius: 0 8px 8px 0;
        padding: var(--sp-14) var(--sp-20);
        margin: var(--sp-20) 0;
        font-size: var(--sp-14);
        font-weight: 500;
        color: #854d0e;
        background: linear-gradient(135deg, #fdf8f0, #faf4e8);
        font-style: italic;
        line-height: 1.7;
    }

    /* figcaption */
    #content figcaption { text-align: center; color: #9ca3af; font-size: var(--sp-14); margin-top: 8px; line-height: 1.5; }

    /* blockquote */
    #content blockquote {
        border: 1px solid #e8e4de;
        border-radius: 8px;
        padding: var(--sp-22) var(--sp-24) var(--sp-22) var(--sp-40);
        margin: var(--sp-28) 0;
        background: #f8f7f5;
        font-size: var(--sp-14);
        color: #333;
        line-height: 1.8;
        position: relative;
    }
    #content blockquote::before {
        content: '"';
        font-size: var(--sp-52);
        color: var(--main-color, #25456b);
        opacity: 0.2;
        position: absolute;
        top: 6px;
        left: var(--sp-14);
        line-height: 1;
        font-family: Georgia, serif;
    }
    #content blockquote p { margin: 0; }

    /* ul / ol */
    #content ul, #content ol { padding-left: var(--sp-22); margin: 0 0 var(--sp-18); }
    #content li { font-size: var(--sp-16); line-height: 1.85; color: #333; margin-bottom: 6px; }

    /* hr */
    #content hr { border: none; border-top: 1px solid #e8e4de; margin: var(--sp-40) 0; }

    /* ── 테이블 ── */
    #content table { width: 100%; border-collapse: collapse; margin: var(--sp-24) 0; font-size: var(--sp-14); overflow: hidden; box-shadow: 0 1px 4px rgba(0,0,0,0.07); }
    #content table caption { font-size: var(--sp-14); color: #6b7280; margin-bottom: 8px; text-align: center; }
    #content table th { background: var(--main-color, #25456b); color: var(--point, #FABE00); padding: var(--sp-12) var(--sp-16); font-weight: 700; text-align: left; font-size: var(--sp-14); }
    #content table td { padding: var(--sp-12) var(--sp-16); border: 1px solid #e5e7eb; vertical-align: top; line-height: 1.7; color: #374151; }
    #content table tr:nth-child(even) td { background: #f9fafb; }
    #content table tr:hover td { background: #f0f4f8; }
    #content table th + th, #content table td + td { border-left: 1px solid #e5e7eb; }

    /* ── FAQ details/summary ── */
    .faq-item { margin-bottom: var(--sp-10); }
    .faq-item  { border: 1px solid #e8e4de; border-radius: var(--sp-10); overflow: hidden; }
    .faq-item  summary {
        padding: var(--sp-16) var(--sp-20);
        background: #f8f7f5;
        cursor: pointer;
        font-weight: 600;
        font-size: var(--sp-16);
        list-style: none;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: var(--sp-12);
        color: #1a1a1a;
        transition: background .15s;
    }
    .faq-item  p {
        padding: var(--sp-16);
    }
    .faq-item  summary::-webkit-details-marker { display: none; }
    .faq-item  summary::after { content: '+'; font-size: var(--sp-22); font-weight: 300; color: var(--main-color, #25456b); flex-shrink: 0; }
    .faq-item [open] summary { background: var(--main-color, #25456b); color: #fff; }
    .faq-item [open] summary::after { content: '−'; color: #fff; }
    .faq-item .faq-answer { padding: var(--sp-16) var(--sp-20); font-size: var(--sp-14); line-height: 1.85; color: #374151; border-top: 1px solid #e8e4de; background: #fff; }

    /* maker가 래퍼 클래스 없이 순수 <details><summary>로만 출력하는 경우를 위한 범용 박스 스타일
       (.pb-faq-item / .faq-item 처럼 이미 자체 스타일이 있는 것들은 :not()으로 제외해 충돌 방지) */
    #content details:not(.pb-faq-item):not(.faq-item):not(.faq-item *) {
        border: 1px solid #e8e4de;
        border-radius: var(--sp-10);
        overflow: hidden;
        margin-bottom: var(--sp-10);
        background: #fff;
    }
    #content details:not(.pb-faq-item):not(.faq-item):not(.faq-item *) summary {
        padding: var(--sp-16) var(--sp-20);
        background: #f8f7f5;
        cursor: pointer;
        font-weight: 600;
        font-size: var(--sp-16);
        list-style: none;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: var(--sp-12);
        color: #1a1a1a;
        transition: background .15s;
    }
    #content details:not(.pb-faq-item):not(.faq-item):not(.faq-item *) summary::-webkit-details-marker { display: none; }
    #content details:not(.pb-faq-item):not(.faq-item):not(.faq-item *) summary::after { content: '+'; font-size: var(--sp-20); font-weight: 300; color: var(--main-color); flex-shrink: 0; }
    #content details[open]:not(.pb-faq-item):not(.faq-item):not(.faq-item *) summary { background: var(--main-color); color: #fff; }
    #content details[open]:not(.pb-faq-item):not(.faq-item):not(.faq-item *) summary::after { content: '−'; color: #fff; }
    #content details:not(.pb-faq-item):not(.faq-item):not(.faq-item *) > summary + * {
        display: block;
        padding: var(--sp-16) var(--sp-20);
        font-size: var(--sp-14);
        line-height: 1.85;
        color: #374151;
        border-top: 1px solid #e8e4de;
        background: #fff;
        margin: 0;
    }

    /* ── 블록 에디터 전용 ── */
    .pb-row { display: flex; flex-wrap: wrap; gap: var(--sp-20); margin-bottom: var(--sp-24); }
    .pb-col { flex: 1; min-width: 0; }
    .pb-col-1{flex:1} .pb-col-2{flex:2} .pb-col-3{flex:3} .pb-col-4{flex:4}
    .pb-col-5{flex:5} .pb-col-6{flex:6} .pb-col-7{flex:7} .pb-col-8{flex:8}
    .pb-col-9{flex:9} .pb-col-10{flex:10} .pb-col-11{flex:11} .pb-col-12{flex:12}
    .pb-quote { border:1px solid #e8e4de; border-radius:8px; padding:var(--sp-22) var(--sp-24) var(--sp-22) var(--sp-40); margin:var(--sp-28) 0; background:#f8f7f5; font-size:var(--sp-16); color:#333; line-height:1.8; position:relative; }
    .pb-quote::before { content:'"'; font-size:var(--sp-52); color:var(--main-color,#25456b); opacity:.2; position:absolute; top:6px; left:var(--sp-14); line-height:1; font-family:Georgia,serif; }
    .pb-warning { background:linear-gradient(135deg,#fdf8f0,#faf4e8); border:1px solid #e8d9bc; border-radius:8px; padding:var(--sp-20) var(--sp-24); margin:var(--sp-28) 0; }
    .pb-warning strong { font-size:11px; font-weight:700; letter-spacing:.1em; text-transform:uppercase; color:var(--main-color,#25456b); display:block; margin-bottom:8px; }
    .pb-warning p { font-size:var(--sp-14); color:#333; margin:0; line-height:1.8; }
    .pb-row h2 { display:flex; align-items:center; gap:var(--sp-12); font-size:var(--sp-20); font-weight:700; color:var(--main-color,#25456b); margin:var(--sp-44) 0 var(--sp-16); padding-bottom:var(--sp-12); border-bottom:2px solid var(--sub-color,#4a7ab5); }
    .pb-row h2::before { content:''; display:block; width:4px; min-width:4px; height:var(--sp-22); background:var(--main-color,#25456b); border-radius:2px; }
    .pb-row h3 { font-size:var(--sp-16); font-weight:700; color:#1a1a1a; margin:var(--sp-28) 0 var(--sp-10); }
    .pb-hr { border:none; border-top:1px solid #e8e4de; margin:var(--sp-40) 0; }
    .pb-table { width:100%; border-collapse:collapse; margin:8px 0; font-size:var(--sp-14); }
    .pb-table td, .pb-table th { border:1.5px solid #e5e7eb; padding:8px var(--sp-12); }
    .pb-table th { background:var(--main-color,#25456b); color:var(--point,#FABE00); font-weight:700; }
    .pb-table tr:nth-child(even) td { background:#f9fafb; }

    /* FAQ details/summary */
    .pb-faq { display:flex; flex-direction:column; gap:0; border:1.5px solid #e8eaf0; border-radius:var(--sp-12); overflow:hidden; margin:var(--sp-20) 0; }
    .pb-faq-item { border-bottom:1px solid #e8eaf0; }
    .pb-faq-item:last-child { border-bottom:none; }
    .pb-faq-q { list-style:none; padding:var(--sp-16) var(--sp-18); font-size:var(--sp-16); font-weight:600; color:#1a1a2e; cursor:pointer; display:flex; align-items:center; justify-content:space-between; gap:var(--sp-12); user-select:none; transition:background .15s; }
    .pb-faq-q:hover { background:#f8f9fb; }
    .pb-faq-q::marker,.pb-faq-q::-webkit-details-marker { display:none; }
    .pb-faq-q::after { content:'\002B'; font-size:var(--sp-16); color:#99b5d7; flex-shrink:0; }
    .pb-faq-item[open] > .pb-faq-q::after { content:'\2212'; color:var(--main-color,#25456b); }
    .pb-faq-item[open] > .pb-faq-q { color:var(--main-color,#25456b); background:#f0f4ff; }
    .pb-faq-a { padding:var(--sp-12) var(--sp-18) var(--sp-16); font-size:var(--sp-14); line-height:1.8; color:#555; border-top:1px solid #f0f3f8; }
    /* figure/figcaption */
    .pb-figure { margin:var(--sp-16) 0; }
    .pb-figcaption { font-size:var(--sp-12); color:#8090b0; text-align:center; margin-top:8px; font-style:italic; }
    .pb-btn-wrap { margin:8px 0; }
    .pb-btn { display:inline-flex; padding:var(--sp-10) var(--sp-22); border-radius:8px; background:var(--main-color,#25456b); color:#fff; font-weight:700; text-decoration:none; font-size:var(--sp-14); }

    /* ── 반응형 ── */
    @media (max-width: 992px) {
        #content { max-width: 100%; }
        .pb-row { flex-direction: column; }
        [class*="pb-col-"] { flex: 0 0 100% !important; }
    }
</style>

<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200">
<script>
document.addEventListener('DOMContentLoaded', function() {
    var content = document.getElementById('content');
    if (!content) return;

    /* ── FAQ: details/summary 변환 ── */
    content.querySelectorAll('.faq-item').forEach(function(item) {
        var h3  = item.querySelector('h3[itemprop="name"], h3');
        var ans = item.querySelector('[itemprop="acceptedAnswer"], [class*="answer"], div');
        if (!h3) return;
        var details = document.createElement('details');
        var summary = document.createElement('summary');
        summary.textContent = h3.textContent.replace(/^Q\.\s*/,'Q. ');
        var ansDiv = document.createElement('div');
        ansDiv.className = 'faq-answer';
        ansDiv.innerHTML = ans ? ans.innerHTML : '';
        details.appendChild(summary);
        details.appendChild(ansDiv);
        item.innerHTML = '';
        item.appendChild(details);
    });

    /* ── 목차 생성 ── */
    var headings = content.querySelectorAll('h2, h3');
    if (headings.length === 0) return;

    function buildToc(navEl) {
        var ul = document.createElement('ul');
        headings.forEach(function(h, i) {
            if (!h.id) h.id = 'toc-h-' + i;
            var li = document.createElement('li');
            li.className = h.tagName === 'H2' ? 'toc-h2' : 'toc-h3';
            var a = document.createElement('a');
            a.href = '#' + h.id;
            // h2는 ::before 막대 때문에 textContent가 공백 포함 — trim
            a.textContent = h.textContent.trim();
            a.addEventListener('click', function(e) {
                e.preventDefault();
                h.scrollIntoView({ behavior: 'smooth', block: 'start' });
            });
            li.appendChild(a);
            ul.appendChild(li);
        });
        navEl.appendChild(ul);
    }

    var tocNav    = document.getElementById('tocNav');
    var tocNavMob = document.getElementById('tocNavMobile');
    if (tocNav)    buildToc(tocNav);
    if (tocNavMob) buildToc(tocNavMob);

    /* ── 스크롤 감지 → active ── */
    function setActive(id) {
        [tocNav, tocNavMob].forEach(function(nav) {
            if (!nav) return;
            nav.querySelectorAll('a').forEach(function(a) { a.classList.remove('active'); });
            var link = nav.querySelector('a[href="#' + id + '"]');
            if (link) link.classList.add('active');
        });
    }

    var io = new IntersectionObserver(function(entries) {
        entries.forEach(function(entry) {
            if (entry.isIntersecting) setActive(entry.target.id);
        });
    }, { rootMargin: '-10% 0px -75% 0px' });

    headings.forEach(function(h) { io.observe(h); });

    /* ── 관련 링크 박스: DOM 재구성 + OG 이미지 로드 ── */
    document.querySelectorAll('a.related-link-box').forEach(function(box) {
        try {
            // 이미 재구성됐으면 스킵
            if (box.querySelector('.rlb-img')) return;

            // rlb-img 플레이스홀더
            var imgDiv = document.createElement('div');
            imgDiv.className = 'rlb-img';
            imgDiv.innerHTML = '<span class="rlb-img-ph material-symbols-outlined">link</span>';

            // 기존 내용을 rlb-content로 감싸기
            var contentDiv = document.createElement('div');
            contentDiv.className = 'rlb-content';
            while (box.firstChild) contentDiv.appendChild(box.firstChild);

            box.appendChild(imgDiv);
            box.appendChild(contentDiv);

            // OG 이미지 fetch (같은 도메인만)
            var href = box.getAttribute('href') || '';
            if (!href) return;
            var absUrl = href.startsWith('/') ? location.origin + href : href;
            var isSame = absUrl.startsWith(location.origin);
            if (!isSame) return;

            fetch(absUrl, { credentials: 'same-origin' })
                .then(function(r) {
                    if (!r.ok) return null;
                    return r.text();
                })
                .then(function(html) {
                    if (!html) return;
                    var parser = new DOMParser();
                    var doc = parser.parseFromString(html, 'text/html');

                    // OG 이미지
                    var ogImgEl = doc.querySelector('meta[property="og:image"]');
                    var imgSrc  = ogImgEl ? (ogImgEl.getAttribute('content') || '') : '';
                    if (!imgSrc) {
                        var firstImg = doc.querySelector('main img[src], article img[src], #content img[src]');
                        if (firstImg) {
                            imgSrc = firstImg.getAttribute('src') || '';
                            if (imgSrc && imgSrc.startsWith('/')) imgSrc = location.origin + imgSrc;
                        }
                    }
                    if (imgSrc) {
                        imgDiv.innerHTML = '<img src="' + imgSrc + '" alt="" loading="lazy">';
                    }

                    // title / desc가 비어있으면 OG에서 보완
                    var titleEl = contentDiv.querySelector('.rlb-title');
                    var descEl  = contentDiv.querySelector('.rlb-desc');
                    if (titleEl && !titleEl.textContent.trim()) {
                        var ogTitle = doc.querySelector('meta[property="og:title"]');
                        if (ogTitle) titleEl.textContent = ogTitle.getAttribute('content') || '';
                        if (!titleEl.textContent.trim()) titleEl.textContent = doc.title || '';
                    }
                    if (descEl && !descEl.textContent.trim()) {
                        var ogDesc = doc.querySelector('meta[property="og:description"]');
                        if (!ogDesc) ogDesc = doc.querySelector('meta[name="description"]');
                        if (ogDesc) descEl.textContent = ogDesc.getAttribute('content') || '';
                    }
                })
                .catch(function() {});
        } catch(e) {}
    });

});
</script>

<?php
// ── JSON-LD 스키마 ─────────────────────────────────────
$json_opts  = JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT;
// $thumb_url는 상단(헤더 히어로 이미지)에서 이미 계산됨

// BreadcrumbList
// (JSON_UNESCAPED_UNICODE 출력이므로 htmlspecialchars 금지 — 이중 인코딩되어 &amp; 등으로 깨짐)
$breadcrumb = [
    '@context'        => 'https://schema.org',
    '@type'           => 'BreadcrumbList',
    '@id'             => $page_canonical . '#breadcrumb',
    'itemListElement' => [
        ['@type'=>'ListItem','position'=>1,'name'=>$hospital_name,'item'=>$site_url],
        ['@type'=>'ListItem','position'=>2,'name'=>$column_label,'item'=>$site_url.$column_path.'/column_list.php'],
        ['@type'=>'ListItem','position'=>3,'name'=>$post['title'],'item'=>$page_canonical],
    ],
];

// ── author 결정: 대표원장(cf_doctors 첫 번째) Person 참조 ──
// 본문에 "모든 게시물은 대표원장이 직접 작성"이라 명시되어 있어 author=대표원장이 사실과 일치(E-E-A-T).
// cf_doctors가 없으면 기존처럼 병원(#organization)으로 폴백.
$author_ref = ['@id' => $site_url . '/#organization'];
$__docs = [];
if (!empty($dm_conf['cf_doctors'])) {
    $__d = json_decode($dm_conf['cf_doctors'], true);
    if (is_array($__d)) $__docs = $__d;
}
// 이름 있는 첫 원장을 대표원장으로
foreach ($__docs as $__one) {
    if (!empty($__one['name']) && trim($__one['name']) !== '') {
        $author_ref = ['@id' => $site_url . '/#dentist-1'];  // site_config가 생성하는 첫 Person @id와 동일
        break;
    }
}

// Article — author는 대표원장 Person(@id) 참조, publisher는 병원(@id) 참조 → 엔티티 그래프 연결
$article = [
    '@context'      => 'https://schema.org',
    '@type'         => 'Article',
    '@id'           => $page_canonical . '#article',
    'headline'      => $post['title'],
    'description'   => $page_description,
    'url'           => $page_canonical,
    'mainEntityOfPage' => $page_canonical,
    'datePublished' => !empty($post['created_at']) ? date('c', strtotime($post['created_at'])) : '',
    'dateModified'  => !empty($post['updated_at']) ? date('c', strtotime($post['updated_at'])) : (!empty($post['created_at']) ? date('c', strtotime($post['created_at'])) : ''),
    'author'        => $author_ref,
    'publisher'     => ['@id' => $site_url . '/#organization'],
    'inLanguage'    => 'ko-KR',
];
if ($thumb_url) $article['image'] = $thumb_url;

// FAQPage — 본문을 파싱한 $faq_unique로 생성 (maker가 마이크로데이터를 안 쓰므로 시스템이 생성).
// FAQ가 1개 이상일 때만 출력. mainEntity는 Question→acceptedAnswer 구조.
$faqpage = null;
if (!empty($faq_unique)) {
    $faq_items = [];
    foreach ($faq_unique as $p) {
        $faq_items[] = [
            '@type' => 'Question',
            'name'  => $p['q'],
            'acceptedAnswer' => [
                '@type' => 'Answer',
                'text'  => $p['a'],
            ],
        ];
    }
    $faqpage = [
        '@context'   => 'https://schema.org',
        '@type'      => 'FAQPage',
        '@id'        => $page_canonical . '#faq',
        'mainEntity' => $faq_items,
    ];
}
?>
<script type="application/ld+json"><?= json_encode($breadcrumb, $json_opts) ?></script>
<script type="application/ld+json"><?= json_encode($article,   $json_opts) ?></script>
<?php if ($faqpage): ?>
<script type="application/ld+json"><?= json_encode($faqpage, $json_opts) ?></script>
<?php endif; ?>

<?php include_once(G5_PATH . '/tail.php'); ?>