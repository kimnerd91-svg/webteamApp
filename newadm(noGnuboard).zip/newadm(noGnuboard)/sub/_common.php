<?php
/**
 * sub/ 공통 부트스트랩 — 루트 common.php를 그대로 로드한다.
 * sub/board/board.php, board_list.php 등이 chdir 후 './_common.php'로 include한다.
 */
include_once(__DIR__ . '/../common.php');
