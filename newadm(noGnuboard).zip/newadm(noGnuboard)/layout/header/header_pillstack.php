<?php
/**
 * header_pillstack.php — 필스택 타입 (우측에 색색의 알약 CTA 버튼 여러 개를 세로로 쌓음)
 * 로고 + 평평한 메뉴 + 우측에 전화상담/카톡상담/온라인상담/칼럼/이벤트 등
 * 컬러가 다른 알약 버튼을 세로로 나열. (참고: 상록수치과류 헤더)
 * 전제: $dm_conf, $cf_tel, $cf_kakao, $cf_naver_booking 등이 head_sub.php를 통해 채워진 상태에서 include됨.
 */

$nav_menus = [
    ['label' => '병원소개', 'href' => '/sub/about.php'],
    ['label' => '진료안내', 'href' => '/sub/info.php'],
    ['label' => '심미교정', 'href' => '/sub/aesthetic.php'],
    ['label' => '임플란트', 'href' => '/sub/implant/implant_highLevel.php'],
    ['label' => '임상케이스', 'href' => '/case'],
];
$current_path = strtok($_SERVER['REQUEST_URI'], '?');

$pill_ctas = [
    ['label' => '전화상담 예약',       'icon' => 'call',         'href' => 'tel:' . preg_replace('/[^0-9]/', '', $cf_tel ?? ''), 'bg' => '#2f7a5f'],
    ['label' => '카카오톡 상담',       'icon' => 'chat',         'href' => $cf_kakao ?? '#', 'bg' => '#FEE500', 'dark' => true],
    ['label' => '온라인 상담신청',     'icon' => 'edit_note',    'href' => '#inquiryModal', 'modal' => true, 'bg' => '#3b6bd6'],
    ['label' => '원장님 칼럼 보기',    'icon' => 'article',      'href' => '/column', 'bg' => '#6b6f76'],
    ['label' => '이벤트/할인',        'icon' => 'local_offer',  'href' => '/sub/event.php', 'bg' => '#d9534f'],
];
?>

<header class="u-pretendard position-fixed w-100 z-header" id="site-header" style="background:#fff; border-bottom:1px solid #eee;">
    <div class="d-flex align-items-stretch justify-content-between u-px-32">
        <div class="d-flex flex-column justify-content-center u-gap-20" style="padding:18px 0;">
            <a href="/" class="d-flex align-items-center u-gap-8" style="text-decoration:none;">
                <?php if (!empty($dm_conf['cf_logo'])): ?>
                    <img src="<?= G5_DATA_URL ?>/common/<?= $dm_conf['cf_logo'] ?>" alt="<?= htmlspecialchars($dm_conf['cf_site_name']) ?>" style="max-height:30px; display:block;">
                <?php else: ?>
                    <span class="fw-800 c-fs-17 u-txt-dark"><?= htmlspecialchars($dm_conf['cf_site_name'] ?? '') ?></span>
                <?php endif; ?>
            </a>
            <nav class="d-none d-lg-flex align-items-center u-gap-24">
                <?php foreach ($nav_menus as $menu): ?>
                    <a href="<?= htmlspecialchars($menu['href']) ?>"
                       class="c-fs-14 fw-600 u-txt-dark<?= $current_path === $menu['href'] ? ' u-txt-main' : '' ?>" style="text-decoration:none;">
                        <?= htmlspecialchars($menu['label']) ?>
                    </a>
                <?php endforeach; ?>
            </nav>
        </div>

        <div class="d-none d-xl-flex flex-column justify-content-center u-gap-4" style="padding:10px 0;">
            <?php
            $promo_id       = 'promoPillstack';
            $promo_width    = '100%';
            $promo_height   = '26px';
            $promo_bg       = 'var(--sub-color, #444)';
            $promo_messages = [
                '📞 ' . htmlspecialchars($cf_tel ?? '02-0000-0000'),
                '🎉 이달의 이벤트 진행중',
            ];
            include __DIR__ . '/_promo_pill.php';
            ?>
            <?php foreach ($pill_ctas as $cta): ?>
                <a <?= !empty($cta['modal']) ? 'href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="' . htmlspecialchars($cta['href']) . '"' : 'href="' . htmlspecialchars($cta['href']) . '" target="_blank"' ?>
                   class="d-flex align-items-center u-gap-8 c-fs-13 fw-700"
                   style="background:<?= htmlspecialchars($cta['bg']) ?>; color:<?= !empty($cta['dark']) ? '#191919' : '#fff' ?>; padding:8px 16px; border-radius:999px; text-decoration:none; white-space:nowrap;">
                    <span class="material-symbols-outlined c-fs-16"><?= $cta['icon'] ?></span>
                    <?= htmlspecialchars($cta['label']) ?>
                </a>
            <?php endforeach; ?>
        </div>

        <button class="u-bd-n u-bg-white d-flex d-xl-none align-items-center justify-content-center" data-bs-toggle="offcanvas" data-bs-target="#mobileMenuHeader" style="width:36px;height:36px; align-self:center;">
            <span class="material-symbols-outlined c-fs-28">menu</span>
        </button>
    </div>

    <div class="offcanvas offcanvas-end u-bg-white" id="mobileMenuHeader">
        <div class="offcanvas-header justify-content-end u-py-20 u-px-20">
            <button type="button" class="u-bd-n d-flex align-items-center justify-content-center" style="width:30px;height:30px;" data-bs-dismiss="offcanvas">
                <span class="material-symbols-outlined c-fs-20">close</span>
            </button>
        </div>
        <div class="offcanvas-body u-p-0">
            <ul style="list-style:none;margin:0;padding:0;">
                <?php foreach ($nav_menus as $menu): ?>
                    <li><a href="<?= htmlspecialchars($menu['href']) ?>" class="d-block u-px-22 u-py-14 c-fs-16 fw-600 u-txt-dark" style="border-bottom:1px solid #f0f0f0;"><?= htmlspecialchars($menu['label']) ?></a></li>
                <?php endforeach; ?>
                <?php foreach ($pill_ctas as $cta): ?>
                    <li class="u-p-14">
                        <a <?= !empty($cta['modal']) ? 'href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="' . htmlspecialchars($cta['href']) . '"' : 'href="' . htmlspecialchars($cta['href']) . '"' ?>
                           class="d-flex align-items-center justify-content-center u-gap-8 c-fs-14 fw-700"
                           style="background:<?= htmlspecialchars($cta['bg']) ?>; color:<?= !empty($cta['dark']) ? '#191919' : '#fff' ?>; padding:10px; border-radius:10px; text-decoration:none;">
                            <?= htmlspecialchars($cta['label']) ?>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</header>

<style>
    #site-header { top: 0; }
    body { padding-top: 112px; }
    @media (max-width: 1199px) { body { padding-top: 76px; } }
</style>
