<?php
/**
 * header_old.php — 기존에 실사용하던 헤더 백업 (GNB 메가메뉴 + 프로모 슬라이더)
 * 원래 파일명은 header_default.php였음. 새 컴포넌트 시스템 도입 후에도
 * 실제 운영 중이던 원본 디자인을 그대로 보존하기 위해 이름만 바꿔 남겨둔 것.
 * 전제: 루트 head.php가 이 파일을 include하기 전에 $dm_conf, $cf_tel 등을
 *       head_sub.php를 통해 이미 채워둔 상태여야 한다.
 */
if (isset($dm_conf['cf_add_body_script']) && $dm_conf['cf_add_body_script']) {
    echo stripslashes($dm_conf['cf_add_body_script']) . "\n";
}

$nav_menus = [
    ['label' => '베스트플란트치과', 'href' => '/', 'children' => [
        // ['label' => '진료 철학',   'href' => '/sub/introduce.php'],
        //['label' => '둘러보기',   'href' => '/sub/interior.php'],
        // ['label' => '진료안내 / 오시는 길',   'href' => '/sub/info.php'],
        // ['label' => '임상증례',    'href' => '/sub/column_list.php'],
    ]],
    ['label' => '임플란트', 'href' => '/sub/implant/implant_highLevel.php', 'children' => [
        ['label' => '베스트플란트 임플란트',   'href' => '/sub/implant/implant_highLevel.php'],
        ['label' => '앞니 임플란트', 'href' => '/sub/implant/implant_FT.php'],
        ['label' => '상악동 거상술 & 뼈이식 임플란트',   'href' => '/sub/implant/implant_SL_BA.php'],
        ['label' => '임플란트 재수술', 'href' => '/sub/implant/implant_retreatment.php'],
        ['label' => '전체 임플란트', 'href' => '/sub/implant/implant_FA.php'],
    ]],
    ['label' => '충치치료', 'href' => '/sub/inlay.php', 'children' => []],
    ['label' => 'EMS 스케일링', 'href' => '/sub/ems_scale.php', 'children' => []],
    ['label' => '퍼스널 미백', 'href' => '/sub/whitening.php', 'children' => []],
    ['label' => '통증 경감 시스템', 'href' => '/sub/painless_system.php', 'children' => []],
    ['label' => '임상케이스', 'href' => '/case', 'children' => []],
    ['label' => '닥터 칼럼', 'href' => '/column', 'children' => []],
];

$current_path = strtok($_SERVER['REQUEST_URI'], '?');
?>

<header class="u-pretendard position-fixed u-bg-white z-header w-100" id="site-header">

    <!-- ── PC 헤더 ── -->
    <div class="d-none d-xxl-flex w-100">

        <!-- 헤더 바 -->
        <div class="hd-bar d-flex align-items-stretch position-relative z-two u-bg-white w-100">

            <!-- 로고: 좌측 고정 공백 -->
            <div class="hd-side d-flex align-items-center u-px-32">
                <a href="/">
                    <?php if (!empty($dm_conf['cf_logo'])): ?>
                        <img src="<?= G5_DATA_URL ?>/common/<?= $dm_conf['cf_logo'] ?>" alt="<?= htmlspecialchars($dm_conf['cf_site_name']) ?>" style="max-height:40px; display:block;">
                    <?php else: ?>
                        <!-- 로고 삽입 위치 -->
                    <?php endif; ?>
                </a>
            </div>

            <!-- GNB: flex:1 채움 -->
            <nav class="hd-nav d-flex align-items-center justify-content-center  u-bc-gray-200" style="border-bottom-width: 0.5px!important;">
                <ul class="gnb d-flex align-items-stretch">
                    <?php foreach ($nav_menus as $i => $menu): ?>
                        <?php
                        $children = array_filter($menu['children'] ?? [], fn($c) => !empty($c['label']));
                        $has_children = !empty($children);
                        ?>
                        <li class="gnb-item position-relative<?= $current_path === $menu['href'] ? ' is-page-active' : '' ?>"
                            data-index="<?= $i ?>">
                            <a href="<?= htmlspecialchars($menu['href']) ?>"
                                class="gnb-link c-fs-16 fw-500 u-ls-10 u-txt-dark">
                                <?= htmlspecialchars($menu['label']) ?>
                            </a>
                            <?php if ($has_children): ?>
                            <div class="gnb-submenu u-bg-white u-round-8 shadow-hard" aria-hidden="true">
                                <?php foreach ($children as $child): ?>
                                    <a href="<?= htmlspecialchars($child['href']) ?>"
                                        class="gnb-submenu-link d-block c-fs-16 u-ls-10 u-txt-gray-700 u-py-10 u-px-24 keep-all<?= $current_path === $child['href'] ? ' is-active' : '' ?>">
                                        <?= htmlspecialchars($child['label']) ?>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </nav>

            <!-- 슬라이더 -->
            <div class="hd-side d-flex align-items-center justify-content-end u-px-32 u-bb- u-bc-gray-200">
                <?php
                $promo_id       = 'promoDefault';
                $promo_width    = 'max-content';
                $promo_height   = '2.5vw';
                $promo_bg       = 'var(--sub-color)';
                $promo_messages = [
                    '<img src="/images/call.svg" alt="" style="height:1.1em;"> <a href="tel:' . htmlspecialchars($cf_tel ?? '') . '" class="u-txt-white fw-bold" style="text-decoration:none;">' . htmlspecialchars($cf_tel ?? '') . '</a>',
                    '<img src="/images/dk.svg" alt="" style="height:1.1em;"> 단국대학교 치과병원 외래교수',
                    '<img src="/images/medal_1.svg" alt="" style="height:1.1em;"> 대표원장 책임진료',
                    '<img src="/images/imp.svg" alt="" style="height:1.1em;"> 편안한 무주수 임플란트',
                    '<img src="/images/heart.svg" alt="" style="height:1.1em;"> 치과 공포증 통증 경감 시스템',
                    '<img src="/images/park.svg" alt="" style="height:1.1em;"> <a href="/#location" class="u-txt-white fw-bold" style="text-decoration:none;">건물 내 넓은 주차 공간</a>',
                ];
                include __DIR__ . '/_promo_pill.php';
                ?>
            </div>
        </div>
    </div>

    <!-- ── 모바일 헤더 ── -->
    <div class="d-flex d-xxl-none justify-content-between u-bg-white align-items-center u-p-20">
        <a href="<?= G5_URL ?>">
            <?php if (!empty($dm_conf['cf_logo'])): ?>
                <img src="<?= G5_DATA_URL ?>/common/<?= $dm_conf['cf_logo'] ?>" alt="<?= htmlspecialchars($dm_conf['cf_site_name']) ?>" style="max-height:40px; display:block;">
            <?php endif; ?>
        </a>
        <button class="u-bd-n u-bg-white d-flex align-items-center justify-content-center u-txt-dark"
            data-bs-toggle="offcanvas" data-bs-target="#mobileMenuHeader" style="width:36px;height:36px;">
            <span class="material-symbols-outlined c-fs-28">menu</span>
        </button>
    </div>

    <!-- 모바일 Offcanvas -->
    <div class="offcanvas offcanvas-end u-bg-main" id="mobileMenuHeader">
        <div class="offcanvas-header justify-content-end u-py-24 u-px-20">
            <button type="button" class="u-bg-sub u-bd-n d-flex align-items-center justify-content-center"
                style="width:32px;height:32px;" data-bs-dismiss="offcanvas">
                <span class="material-symbols-outlined u-txt-white c-fs-22">close</span>
            </button>
        </div>
        <div class="offcanvas-body u-p-0">
            <ul style="list-style:none;margin:0;padding:0;">
                <?php foreach ($nav_menus as $idx => $menu): ?>
                    <?php $has_children = !empty(array_filter($menu['children'] ?? [], fn($c) => isset($c['label']))); ?>
                    <li>
                        <a href="<?= htmlspecialchars($menu['href']) ?>"
                            class="d-flex justify-content-between align-items-center u-px-30 u-py-14 t-fs-20 fw-400 u-ls-10 u-txt-white"
                            <?= $has_children ? 'data-bs-toggle="collapse" data-bs-target="#mob-sub-' . $idx . '"' : '' ?>>
                            <span><?= htmlspecialchars($menu['label']) ?></span>
                            <?php if ($has_children): ?>
                                <i class="bi bi-chevron-down c-fs-14"></i>
                            <?php endif; ?>
                        </a>
                        <?php if ($has_children): ?>
                            <ul class="collapse" id="mob-sub-<?= $idx ?>"
                                style="list-style:none;margin:0;padding:0;background:var(--sub-color);">
                                <?php foreach ($menu['children'] as $child): ?>
                                    <?php if (!isset($child['label'])) continue; ?>
                                    <li>
                                        <a href="<?= htmlspecialchars($child['href']) ?>"
                                            class="d-flex align-items-center u-px-30 u-py-10 c-fs-18 u-ls-10 u-txt-gray-300">
                                            <?= htmlspecialchars($child['label']) ?>
                                        </a>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>

</header>
<script>
    window.addEventListener('scroll', function() {
        var bar = document.querySelector('.hd-bar');
        if (!bar) return;
        if (window.scrollY > 0) {
            bar.classList.remove('u-bg-transparent');
            bar.classList.add('u-bg-main');
        } else {
            bar.classList.remove('u-bg-main');
            bar.classList.add('u-bg-transparent');
        }
    });
</script>
<script>
    (function() {
        const gnbItems = document.querySelectorAll('.gnb-item');
        let closeTimer = null;

        function openSubmenu(item) {
            clearTimeout(closeTimer);
            const submenu = item.querySelector('.gnb-submenu');
            if (!submenu) return;

            gnbItems.forEach(el => {
                el.classList.remove('is-open', 'is-hover');
                el.querySelector('.gnb-submenu')?.setAttribute('aria-hidden', 'true');
            });

            item.classList.add('is-open', 'is-hover');
            submenu.setAttribute('aria-hidden', 'false');
        }

        function closeSubmenu() {
            closeTimer = setTimeout(() => {
                gnbItems.forEach(el => {
                    el.classList.remove('is-open', 'is-hover');
                    el.querySelector('.gnb-submenu')?.setAttribute('aria-hidden', 'true');
                });
            }, 120);
        }

        gnbItems.forEach(item => {
            const submenu = item.querySelector('.gnb-submenu');
            if (!submenu) return;

            item.addEventListener('mouseenter', () => openSubmenu(item));
            item.addEventListener('mouseleave', closeSubmenu);
            submenu.addEventListener('mouseenter', () => clearTimeout(closeTimer));
            submenu.addEventListener('mouseleave', closeSubmenu);
        });
    })();
</script>

<script>
    if (typeof AOS !== 'undefined' && !window.aosInitialized) {
        AOS.init();
        window.aosInitialized = true;
    }
</script>

<script>
    const header = document.getElementById('site-header');

    const updateMargin = () => {
        const height = header.offsetHeight;
        document.documentElement.style.setProperty('--header-height', `${height}px`);
    };

    const headerBottom = document.querySelector('#site-header').getBoundingClientRect().bottom;
    document.documentElement.style.setProperty('--header-height', `${headerBottom}px`);

    updateMargin();
    window.addEventListener('resize', updateMargin);
</script>

<div id="google_translate_element" style="display:none;"></div>
