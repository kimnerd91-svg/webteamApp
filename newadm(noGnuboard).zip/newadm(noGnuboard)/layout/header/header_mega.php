<?php
/**
 * header_mega.php — 메가메뉴 타입 (컬러 플라이아웃 패널)
 * 상단 nav 항목에 마우스오버하면 브랜드 컬러가 들어간 넓은 패널이 아래로 펼쳐지며
 * 하위 메뉴를 리스트로 보여준다. (참고: 메디앤메디치과·베스트플란트치과류 헤더)
 * 전제: $dm_conf, $cf_tel 등이 head_sub.php를 통해 이미 채워진 상태에서 include됨.
 */

$nav_menus = [
    ['label' => '메디앤메디치과', 'href' => '/', 'children' => []],
    ['label' => '임플란트', 'href' => '/sub/implant/implant_highLevel.php', 'children' => [
        ['label' => '상담부터 마무리까지'], ['label' => '베스트임플란트'], ['label' => '진심임플란트'],
        ['label' => '정확임플란트'], ['label' => '원함임플란트'], ['label' => '당일임플란트'],
    ]],
    ['label' => '인레이', 'href' => '/sub/inlay.php', 'children' => []],
    ['label' => 'EMS 스케일링', 'href' => '/sub/ems_scale.php', 'children' => []],
    ['label' => '퍼스널 미백', 'href' => '/sub/whitening.php', 'children' => []],
    ['label' => '통증 경감 시스템', 'href' => '/sub/painless_system.php', 'children' => []],
    ['label' => '임상케이스', 'href' => '/case', 'children' => []],
    ['label' => '닥터 칼럼', 'href' => '/column', 'children' => []],
];
$current_path = strtok($_SERVER['REQUEST_URI'], '?');
?>

<header class="u-pretendard position-fixed w-100 z-header" id="site-header" style="background:#fff; border-bottom:1px solid #eee;">
    <div class="d-flex align-items-center justify-content-between u-px-32" style="height:76px;">
        <a href="/" class="d-flex align-items-center u-gap-8" style="text-decoration:none;">
            <?php if (!empty($dm_conf['cf_logo'])): ?>
                <img src="<?= G5_DATA_URL ?>/common/<?= $dm_conf['cf_logo'] ?>" alt="<?= htmlspecialchars($dm_conf['cf_site_name']) ?>" style="max-height:34px; display:block;">
            <?php else: ?>
                <span class="fw-800 c-fs-18 u-txt-dark"><?= htmlspecialchars($dm_conf['cf_site_name'] ?? '') ?></span>
            <?php endif; ?>
        </a>

        <nav class="d-none d-xl-flex align-items-stretch h-100">
            <ul class="mega-gnb d-flex align-items-stretch h-100" style="list-style:none;margin:0;padding:0;">
                <?php foreach ($nav_menus as $i => $menu): ?>
                    <?php $children = array_filter($menu['children'] ?? [], fn($c) => !empty($c['label'])); ?>
                    <li class="mega-item h-100 d-flex align-items-center<?= $current_path === $menu['href'] ? ' is-active' : '' ?>">
                        <a href="<?= htmlspecialchars($menu['href']) ?>" class="mega-link c-fs-15 fw-600 u-txt-dark u-px-16">
                            <?= htmlspecialchars($menu['label']) ?>
                        </a>
                        <?php if ($children): ?>
                        <!-- 메가메뉴: 이 항목 밑이 아니라 헤더 전체 폭(#site-header 기준)으로 펼쳐진다.
                             플라이아웃(header_flyout.php)의 .flyout-panel은 항목 바로 아래 좁은 박스만 뜨는 것과 대비됨. -->
                        <div class="mega-panel" aria-hidden="true">
                            <div class="mega-panel-inner">
                                <p class="mega-panel-title"><?= htmlspecialchars($menu['label']) ?></p>
                                <div class="mega-panel-grid">
                                    <?php foreach ($children as $child): ?>
                                        <a href="<?= htmlspecialchars($child['href'] ?? '#') ?>"><?= htmlspecialchars($child['label']) ?></a>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </nav>

        <!-- 우측 긴 알약 배너 — 세로(아래→위) Swiper -->
        <div class="d-none d-xl-block">
            <?php
            $promo_id       = 'promoMega';
            $promo_width    = '280px';
            $promo_height   = '40px';
            $promo_bg       = 'var(--sub-color, #6b4a2f)';
            $promo_messages = [
                '📞 ' . htmlspecialchars($cf_tel ?? '02-0000-0000'),
                '🎗 신환 첫 상담 무료 이벤트',
                '🅿️ 건물 내 주차 공간 완비',
            ];
            include __DIR__ . '/_promo_pill.php';
            ?>
        </div>

        <button class="u-bd-n u-bg-white d-flex d-xl-none align-items-center justify-content-center" data-bs-toggle="offcanvas" data-bs-target="#mobileMenuHeader" style="width:36px;height:36px;">
            <span class="material-symbols-outlined c-fs-28">menu</span>
        </button>
    </div>

    <!-- 모바일 Offcanvas -->
    <div class="offcanvas offcanvas-end u-bg-white" id="mobileMenuHeader">
        <div class="offcanvas-header justify-content-end u-py-24 u-px-20">
            <button type="button" class="u-bd-n d-flex align-items-center justify-content-center" style="width:32px;height:32px;" data-bs-dismiss="offcanvas">
                <span class="material-symbols-outlined c-fs-22">close</span>
            </button>
        </div>
        <div class="offcanvas-body u-p-0">
            <ul style="list-style:none;margin:0;padding:0;">
                <?php foreach ($nav_menus as $menu): ?>
                    <li><a href="<?= htmlspecialchars($menu['href']) ?>" class="d-block u-px-24 u-py-16 c-fs-17 fw-600 u-txt-dark" style="border-bottom:1px solid #f0f0f0;"><?= htmlspecialchars($menu['label']) ?></a></li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</header>

<style>
    /* #site-header가 position:fixed라 이미 포지셔닝 컨텍스트임 — .mega-panel은
       개별 li가 아니라 이 헤더 전체를 기준으로 절대배치해서 화면 전체 폭으로 펼침 */
    #site-header { top: 0; position: fixed; }
    body { padding-top: 76px; }

    /* .mega-item에는 일부러 position:relative를 안 준다 — 줘버리면 .mega-panel의
       절대배치 기준이 #site-header가 아니라 이 li가 돼서 다시 플라이아웃처럼 좁아짐 */
    .mega-item .mega-link { display:flex; align-items:center; height:100%; text-decoration:none; border-bottom:2px solid transparent; transition:border-color .15s; }
    .mega-item:hover .mega-link, .mega-item.is-active .mega-link { border-color: var(--main-color, #6b4a2f); }

    .mega-panel {
        position:absolute; top:100%; left:0; right:0; width:100%;
        background: var(--sub-color, #b8794f);
        box-shadow:0 18px 34px rgba(0,0,0,.18); opacity:0; visibility:hidden; pointer-events:none;
        transform: translateY(-8px);
        transition: opacity .18s ease, transform .18s ease, visibility .18s;
        z-index: 20;
    }
    /* 순수 :hover는 대각선으로 움직이다 살짝만 벗어나도 바로 닫혀버려서
       is-open 클래스(JS가 mouseenter/mouseleave+지연타이머로 토글)로 바꿈.
       header_old.php의 gnb-submenu와 동일한 방식. */
    .mega-item.is-open .mega-panel { opacity:1; visibility:visible; pointer-events:auto; transform:translateY(0); }
    .mega-panel-inner { max-width:1200px; margin:0 auto; padding:28px 32px 32px; }
    .mega-panel-title { color:#fff; font-weight:800; font-size:14px; margin:0 0 14px; opacity:.85; }
    .mega-panel-grid {
        display:grid; grid-template-columns:repeat(auto-fill, minmax(180px, 1fr)); gap:4px 28px;
    }
    .mega-panel-grid a { display:block; padding:8px 0; color:#fff; text-decoration:none; font-size:14.5px; font-weight:600; opacity:.9; border-bottom:1px solid rgba(255,255,255,.12); }
    .mega-panel-grid a:hover { opacity:1; text-decoration:underline; }
</style>

<script>
    new Swiper('.megaPromoSwiper', {
        direction: 'vertical', slidesPerView: 1, loop: true,
        autoplay: { delay: 2400, disableOnInteraction: false }, speed: 600,
    });
</script>

<script>
    (function() {
        const items = document.querySelectorAll('.mega-item');
        let closeTimer = null;

        function open(item) {
            clearTimeout(closeTimer);
            if (!item.querySelector('.mega-panel')) return;
            items.forEach(el => el.classList.remove('is-open'));
            item.classList.add('is-open');
        }
        function close() {
            closeTimer = setTimeout(() => {
                items.forEach(el => el.classList.remove('is-open'));
            }, 150);
        }

        items.forEach(item => {
            const panel = item.querySelector('.mega-panel');
            if (!panel) return;
            item.addEventListener('mouseenter', () => open(item));
            item.addEventListener('mouseleave', close);
            panel.addEventListener('mouseenter', () => clearTimeout(closeTimer));
            panel.addEventListener('mouseleave', close);
        });
    })();
</script>
