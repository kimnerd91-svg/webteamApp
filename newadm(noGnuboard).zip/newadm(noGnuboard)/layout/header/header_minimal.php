<?php
/**
 * header_minimal.php — 미니멀 헤더 (로고 + 전화번호 + 심플 메뉴, 메가메뉴/프로모 슬라이더 없음)
 * 전제: 루트 head.php가 이 파일을 include하기 전에 $dm_conf, $cf_tel 등을
 *       head_sub.php를 통해 이미 채워둔 상태여야 한다.
 */

$nav_menus_min = [
    ['label' => '홈',         'href' => '/'],
    ['label' => '진료안내',   'href' => '/sub/info.php'],
    ['label' => '임상케이스', 'href' => '/case'],
    ['label' => '닥터 칼럼',  'href' => '/column'],
];

$current_path = strtok($_SERVER['REQUEST_URI'], '?');
?>

<header class="u-pretendard position-fixed u-bg-white z-header w-100" id="site-header">
    <div class="d-flex align-items-center justify-content-between u-px-24 u-py-16" style="border-bottom:1px solid #eee;">
        <a href="/" class="d-flex align-items-center">
            <?php if (!empty($dm_conf['cf_logo'])): ?>
                <img src="<?= G5_DATA_URL ?>/common/<?= $dm_conf['cf_logo'] ?>" alt="<?= htmlspecialchars($dm_conf['cf_site_name']) ?>" style="max-height:36px; display:block;">
            <?php else: ?>
                <span class="fw-700 c-fs-20 u-txt-dark"><?= htmlspecialchars($dm_conf['cf_site_name'] ?? '') ?></span>
            <?php endif; ?>
        </a>

        <nav class="d-none d-lg-flex align-items-center u-gap-24">
            <?php foreach ($nav_menus_min as $menu): ?>
                <a href="<?= htmlspecialchars($menu['href']) ?>"
                   class="c-fs-15 fw-500 u-txt-dark<?= $current_path === $menu['href'] ? ' u-txt-main' : '' ?>">
                    <?= htmlspecialchars($menu['label']) ?>
                </a>
            <?php endforeach; ?>
        </nav>

        <div class="d-flex align-items-center u-gap-16">
            <div class="d-none d-md-block">
                <?php
                $promo_id       = 'promoMinimal';
                $promo_width    = '200px';
                $promo_height   = '34px';
                $promo_bg       = 'var(--main-color, #333)';
                $promo_messages = [
                    '📞 ' . htmlspecialchars($cf_tel ?? '02-0000-0000'),
                    '💬 카톡 상담 환영',
                ];
                include __DIR__ . '/_promo_pill.php';
                ?>
            </div>
            <button class="u-bd-n u-bg-white d-flex d-lg-none align-items-center justify-content-center u-txt-dark"
                data-bs-toggle="offcanvas" data-bs-target="#mobileMenuHeader" style="width:36px;height:36px;">
                <span class="material-symbols-outlined c-fs-28">menu</span>
            </button>
        </div>
    </div>

    <!-- 모바일 Offcanvas -->
    <div class="offcanvas offcanvas-end u-bg-white" id="mobileMenuHeader">
        <div class="offcanvas-header justify-content-end u-py-24 u-px-20">
            <button type="button" class="u-bd-n d-flex align-items-center justify-content-center"
                style="width:32px;height:32px;" data-bs-dismiss="offcanvas">
                <span class="material-symbols-outlined c-fs-22">close</span>
            </button>
        </div>
        <div class="offcanvas-body u-p-0">
            <ul style="list-style:none;margin:0;padding:0;">
                <?php foreach ($nav_menus_min as $menu): ?>
                    <li>
                        <a href="<?= htmlspecialchars($menu['href']) ?>"
                           class="d-block u-px-24 u-py-16 c-fs-18 fw-500 u-txt-dark" style="border-bottom:1px solid #f0f0f0;">
                            <?= htmlspecialchars($menu['label']) ?>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</header>

<script>
    const header = document.getElementById('site-header');
    const updateMargin = () => {
        document.documentElement.style.setProperty('--header-height', `${header.offsetHeight}px`);
    };
    updateMargin();
    window.addEventListener('resize', updateMargin);
</script>
