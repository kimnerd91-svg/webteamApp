<?php
/**
 * header_flyout.php — 플라이아웃 타입 (가벼운 화이트 드롭다운)
 * 상단 nav 항목에 마우스오버하면 해당 항목 바로 아래에 좁고 가벼운(화이트) 드롭다운이
 * 나타난다. 우측엔 진료 예약용 긴 알약 CTA 버튼 1개.
 * (참고: 연세바로치과류 헤더)
 * 전제: $dm_conf, $cf_tel, $cf_naver_booking 등이 head_sub.php를 통해 채워진 상태에서 include됨.
 */

$nav_menus = [
    ['label' => '연세바로교정치과', 'href' => '/', 'children' => [
        ['label' => '진료철학'], ['label' => '의료진 소개'], ['label' => '특별진료'],
    ]],
    ['label' => '소아 교정', 'href' => '/sub/children.php', 'children' => []],
    ['label' => '성인 교정', 'href' => '/sub/adult.php', 'children' => []],
    ['label' => '안면윤곽', 'href' => '/sub/facial.php', 'children' => []],
    ['label' => '임상케이스', 'href' => '/case', 'children' => []],
    ['label' => '닥터칼럼', 'href' => '/column', 'children' => []],
];
$current_path = strtok($_SERVER['REQUEST_URI'], '?');
?>

<header class="u-pretendard position-fixed w-100 z-header" id="site-header" style="background:#fff; border-bottom:1px solid #e8eaf0;">
    <div class="d-flex align-items-center justify-content-between u-px-32" style="height:66px;">
        <a href="/" class="d-flex align-items-center u-gap-8" style="text-decoration:none;">
            <?php if (!empty($dm_conf['cf_logo'])): ?>
                <img src="<?= G5_DATA_URL ?>/common/<?= $dm_conf['cf_logo'] ?>" alt="<?= htmlspecialchars($dm_conf['cf_site_name']) ?>" style="max-height:30px; display:block;">
            <?php else: ?>
                <span class="fw-800 c-fs-17 u-txt-dark"><?= htmlspecialchars($dm_conf['cf_site_name'] ?? '') ?></span>
            <?php endif; ?>
        </a>

        <nav class="d-none d-lg-flex align-items-center u-gap-4">
            <?php foreach ($nav_menus as $menu): ?>
                <?php $children = array_filter($menu['children'] ?? [], fn($c) => !empty($c['label'])); ?>
                <div class="flyout-item position-relative">
                    <a href="<?= htmlspecialchars($menu['href']) ?>" class="flyout-link c-fs-14 fw-600 u-txt-dark u-px-14 u-py-8 d-block<?= $current_path === $menu['href'] ? ' is-active' : '' ?>">
                        <?= htmlspecialchars($menu['label']) ?>
                    </a>
                    <?php if ($children): ?>
                    <div class="flyout-panel" aria-hidden="true">
                        <?php foreach ($children as $child): ?>
                            <a href="<?= htmlspecialchars($child['href'] ?? '#') ?>"><?= htmlspecialchars($child['label']) ?></a>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </nav>

        <div class="d-flex align-items-center u-gap-12">
            <div class="d-none d-md-block">
                <?php
                $promo_id       = 'promoFlyout';
                $promo_width    = '220px';
                $promo_height   = '40px';
                $promo_bg       = 'var(--main-color, #1e3a6e)';
                $promo_messages = [
                    '🌙 해울 야간진료',
                    '<a href="' . htmlspecialchars($cf_naver_booking ?? '#') . '" class="u-txt-white" style="text-decoration:none;">📅 네이버 예약하기</a>',
                    '📞 ' . htmlspecialchars($cf_tel ?? '02-0000-0000'),
                ];
                include __DIR__ . '/_promo_pill.php';
                ?>
            </div>
            <button class="u-bd-n u-bg-white d-flex d-lg-none align-items-center justify-content-center" data-bs-toggle="offcanvas" data-bs-target="#mobileMenuHeader" style="width:34px;height:34px;">
                <span class="material-symbols-outlined c-fs-26">menu</span>
            </button>
        </div>
    </div>

    <div class="offcanvas offcanvas-end u-bg-white" id="mobileMenuHeader">
        <div class="offcanvas-header justify-content-end u-py-20 u-px-20">
            <button type="button" class="u-bd-n d-flex align-items-center justify-content-center" style="width:30px;height:30px;" data-bs-dismiss="offcanvas">
                <span class="material-symbols-outlined c-fs-20">close</span>
            </button>
        </div>
        <div class="offcanvas-body u-p-0">
            <ul style="list-style:none;margin:0;padding:0;">
                <?php foreach ($nav_menus as $menu): ?>
                    <li><a href="<?= htmlspecialchars($menu['href']) ?>" class="d-block u-px-22 u-py-14 c-fs-16 fw-600 u-txt-dark" style="border-bottom:1px solid #f0f0f0;"><?= htmlspecialchars($menu['label']) ?></a></li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</header>

<style>
    .flyout-link { text-decoration:none; border-radius:8px; transition: background .15s, color .15s; }
    .flyout-link:hover, .flyout-link.is-active { background:#f4f6fb; color: var(--main-color,#1e3a6e); }
    .flyout-panel {
        position:absolute; top:100%; left:0; margin-top:6px; min-width:170px;
        background:#fff; border:1px solid #e8eaf0; border-radius:12px;
        box-shadow:0 12px 28px rgba(20,30,60,.12); padding:8px;
        opacity:0; visibility:hidden; pointer-events:none; transform:translateY(-6px);
        transition: opacity .15s ease, transform .15s ease, visibility .15s;
        z-index: 20;
    }
    /* 순수 :hover 대신 is-open 클래스(JS mouseenter/mouseleave+지연타이머)로 토글 —
       대각선 마우스 이동에 취약한 :hover 단독 방식의 "이동하면 사라짐" 문제 방지 */
    .flyout-item.is-open .flyout-panel { opacity:1; visibility:visible; transform:translateY(0); pointer-events:auto; }
    .flyout-panel a { display:block; padding:9px 12px; border-radius:7px; color:#444; text-decoration:none; font-size:13.5px; font-weight:500; }
    .flyout-panel a:hover { background:#f4f6fb; color: var(--main-color,#1e3a6e); }
    #site-header { top: 0; }
    body { padding-top: 66px; }
</style>

<script>
    (function() {
        const items = document.querySelectorAll('.flyout-item');
        let closeTimer = null;

        function open(item) {
            clearTimeout(closeTimer);
            if (!item.querySelector('.flyout-panel')) return;
            items.forEach(el => el.classList.remove('is-open'));
            item.classList.add('is-open');
        }
        function close() {
            closeTimer = setTimeout(() => {
                items.forEach(el => el.classList.remove('is-open'));
            }, 150);
        }

        items.forEach(item => {
            const panel = item.querySelector('.flyout-panel');
            if (!panel) return;
            item.addEventListener('mouseenter', () => open(item));
            item.addEventListener('mouseleave', close);
            panel.addEventListener('mouseenter', () => clearTimeout(closeTimer));
            panel.addEventListener('mouseleave', close);
        });
    })();
</script>
