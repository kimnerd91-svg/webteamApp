<?php
/**
 * 루트 공통 부트스트랩 — 루트 common.php를 그대로 로드한다.
 * index.php, sub/*.php 등 공개 페이지들이 './_common.php'로 include한다.
 */
include_once(__DIR__ . '/common.php');
