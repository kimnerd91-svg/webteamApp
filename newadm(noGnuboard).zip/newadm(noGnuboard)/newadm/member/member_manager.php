<?php
register_shutdown_function(function () {
    $e = error_get_last();
    if ($e && in_array($e['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        echo '<pre style="background:#fee;padding:20px;font:14px monospace;">FATAL: '
           . htmlspecialchars($e['message']) . "\n@ " . $e['file'] . ':' . $e['line'] . '</pre>';
    }
});
include_once('../_common.php');
include_once('../_auth_check.php');

// mb_is_clinic 컬럼 자동 보장 (병원계정 분기 플래그)
$chk = sql_query("SHOW COLUMNS FROM {$g5['member_table']} LIKE 'mb_is_clinic'");
if (!sql_num_rows($chk)) {
    sql_query("ALTER TABLE {$g5['member_table']} ADD mb_is_clinic TINYINT(1) NOT NULL DEFAULT 0");
}

if (isset($_GET['leave_id'])) {
    $mb_id = sql_real_escape_string($_GET['leave_id']);
    sql_query(" UPDATE {$g5['member_table']} SET mb_leave_date = '".date('Ymd')."' WHERE mb_id = '$mb_id' ");
    alert_toast('해당 회원을 탈퇴 처리하였습니다.', './member_manager.php');
}

if (isset($_POST['action']) && $_POST['action'] == 'add_member') {
    $mb_id = trim($_POST['mb_id']); $mb_password = $_POST['mb_password'];
    $mb_name = trim($_POST['mb_name']); $mb_email = trim($_POST['mb_email']); $mb_level = (int)$_POST['mb_level'];
    $is_clinic = isset($_POST['mb_is_clinic']) ? 1 : 0;
    if ($is_clinic) $mb_level = 10; // 병원계정은 로그인 가능하도록 Lv10 고정 (분기는 mb_is_clinic이 담당)
    $row = sql_fetch(" SELECT count(*) as cnt FROM {$g5['member_table']} WHERE mb_id = '$mb_id' ");
    if ($row['cnt']) alert_toast('이미 존재하는 아이디입니다.', 'error');
$mb_password = get_encrypt_string($mb_password);
    $ins = sql_query(" INSERT INTO {$g5['member_table']} SET mb_id='$mb_id', mb_password='$mb_password', mb_name='$mb_name', mb_email='$mb_email', mb_level='$mb_level', mb_is_clinic='$is_clinic', mb_datetime='".G5_TIME_YMDHIS."', mb_email_certify='".G5_TIME_YMDHIS."', mb_hp='', mb_certify='', mb_login_ip='{$_SERVER['REMOTE_ADDR']}' ");
    if (!$ins) { global $connect_db; die('INSERT 실패: ' . mysqli_error($connect_db)); }
    alert_toast('새 회원이 등록되었습니다.', './member_manager.php', 'success');
}

if (isset($_POST['action']) && $_POST['action'] == 'update_member') {
    $mb_id = sql_real_escape_string($_POST['mb_id']); $mb_name = sql_real_escape_string($_POST['mb_name']);
    $mb_email = sql_real_escape_string($_POST['mb_email']); $mb_level = (int)$_POST['mb_level'];
    $is_clinic = isset($_POST['mb_is_clinic']) ? 1 : 0;
    if ($is_clinic) $mb_level = 10; // 병원계정은 로그인 가능하도록 Lv10 고정
    $sql_password = "";
    if (trim($_POST['mb_password'])) { $mb_password = get_encrypt_string($_POST['mb_password']); $sql_password = " , mb_password='$mb_password' "; }
    sql_query(" UPDATE {$g5['member_table']} SET mb_name='$mb_name', mb_email='$mb_email', mb_level='$mb_level', mb_is_clinic='$is_clinic' $sql_password WHERE mb_id='$mb_id' ");
    alert_toast('회원 정보가 수정되었습니다.', './member_manager.php');
}

$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$sql = "SELECT * FROM {$g5['member_table']} WHERE 1=1";
if ($search) { $s = sql_real_escape_string($search); $sql .= " AND (mb_id LIKE '%{$s}%' OR mb_name LIKE '%{$s}%')"; }
$sql .= " ORDER BY mb_datetime DESC";
$result = sql_query($sql);
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>회원 관리</title>
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Pretendard', 'Apple SD Gothic Neo', sans-serif; background: rgba(255,255,255,0.06); color: #f1f2f5; }
        #admin_wrapper { display: flex; min-height: 100vh; }
        .content_area { flex: 1; padding: 40px; overflow-x: hidden; }

        .page_header { display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 14px; margin-bottom: 28px; }
        .page_title  { font-size: 22px; font-weight: 700; }

        .search_form { display: flex; gap: 8px; flex-wrap: wrap; }
        .search_input { height: 40px; width: 260px; border: 1px solid rgba(255,255,255,0.14); border-radius: 8px; padding: 0 14px; font-size: 13px; background: transparent; transition: all 0.2s; }
        .search_input:focus { outline: none; border-color: #8b7cf9; box-shadow: 0 0 0 3px rgba(139, 124, 249,0.1); }
        .btn_search { height: 40px; padding: 0 18px; background: #8b7cf9; color: #fff; border: none; border-radius: 8px; font-size: 13px; font-weight: 700; cursor: pointer; transition: all 0.2s; }
        .btn_search:hover { background: #7c6cf0; }
        .btn_reset  { height: 40px; padding: 0 16px; background: rgba(255,255,255,0.06); color: #b7bac8; border: 1px solid rgba(255,255,255,0.14); border-radius: 8px; font-size: 13px; font-weight: 600; cursor: pointer; }

        .card { background: transparent; border-radius: 12px; box-shadow: 0 2px 12px rgba(0,0,0,0.06); border: 1px solid rgba(255,255,255,0.14); overflow: hidden; }
        .search_result { padding: 11px 16px; background: rgba(139,124,249,0.18); color: #8b7cf9; font-size: 13px; font-weight: 600; border-bottom: 1px solid rgba(255,255,255,0.14); }

        .table_wrap { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; min-width: 560px; }
        thead th { background: rgba(255,255,255,0.06); padding: 11px 18px; font-size: 12px; font-weight: 700; color: #9aa0ac; text-align: left; border-bottom: 2px solid rgba(255,255,255,0.14); }
        tbody td { padding: 13px 18px; border-bottom: 1px solid rgba(255,255,255,0.06); vertical-align: middle; font-size: 14px; }
        tbody tr:last-child td { border-bottom: none; }
        tbody tr:hover td { background: rgba(255,255,255,0.05); }

        .member_avatar { width: 36px; height: 36px; border-radius: 50%; background: rgba(139,124,249,0.18); display: flex; align-items: center; justify-content: center; font-weight: 700; color: #8b7cf9; font-size: 15px; flex-shrink: 0; }
        .member_info { display: flex; align-items: center; gap: 12px; }
        .member_name { font-weight: 700; color: #f1f2f5; }
        .member_email { font-size: 12px; color: #9aa0ac; margin-top: 2px; }
        .member_id { font-family: monospace; font-size: 13px; background: rgba(255,255,255,0.06); padding: 3px 8px; border-radius: 5px; color: #b7bac8; }
        .level_badge { display: inline-block; background: rgba(139,124,249,0.18); color: #8b7cf9; padding: 3px 10px; border-radius: 20px; font-size: 11px; font-weight: 700; }
        .clinic_badge { display: inline-block; background: #dcfce7; color: #16a34a; padding: 3px 10px; border-radius: 20px; font-size: 11px; font-weight: 700; margin-left: 4px; }
        .clinic_check { display: flex; align-items: center; gap: 9px; background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 9px; padding: 13px 15px; cursor: pointer; }
        .clinic_check input { width: 18px; height: 18px; accent-color: #16a34a; flex-shrink: 0; }
        .clinic_check .cc_txt { font-size: 13px; }
        .clinic_check .cc_txt b { display: block; color: #15803d; font-weight: 700; margin-bottom: 2px; }
        .clinic_check .cc_txt span { color: #4d7c5a; font-size: 12px; }
        .td_date { font-size: 12px; color: #9aa0ac; }
        .td_actions { display: flex; gap: 7px; justify-content: center; }
        .btn_edit { padding: 6px 14px; background: #8b7cf9; color: #fff; border: none; border-radius: 7px; font-size: 12px; font-weight: 700; cursor: pointer; transition: all 0.2s; }
        .btn_edit:hover { background: #7c6cf0; }
        .btn_leave { padding: 6px 14px; background: #fee2e2; color: #dc2626; border: none; border-radius: 7px; font-size: 12px; font-weight: 700; cursor: pointer; transition: all 0.2s; }
        .btn_leave:hover { background: #fecaca; }

        .add_row { display: flex; justify-content: flex-end; margin-top: 20px; }
        .btn_add { padding: 11px 24px; background: #8b7cf9; color: #fff; border: none; border-radius: 9px; font-size: 14px; font-weight: 700; cursor: pointer; box-shadow: 0 4px 12px rgba(139, 124, 249,0.25); transition: all 0.2s; }
        .btn_add:hover { background: #7c6cf0; }
        .empty_row td { text-align: center; padding: 56px; color: #9aa0ac; }

        /* 모달 */
        .modal_overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.55); z-index: 10000; align-items: center; justify-content: center; padding: 20px; }
        .modal_overlay.active { display: flex; }
        .modal_box { background: transparent; border-radius: 14px; width: 100%; max-width: 460px; overflow: hidden; animation: modal_in 0.25s ease; }
        @keyframes modal_in { from { transform: translateY(-20px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
        .modal_hd { padding: 22px 24px; border-bottom: 1px solid rgba(255,255,255,0.14); display: flex; align-items: center; justify-content: space-between; }
        .modal_hd h3 { font-size: 17px; font-weight: 700; }
        .modal_close { background: none; border: none; font-size: 22px; cursor: pointer; color: #9aa0ac; }
        .modal_close:hover { color: #f1f2f5; }
        .modal_bd { padding: 24px; display: flex; flex-direction: column; gap: 16px; }
        .form_group label { display: block; font-size: 12px; font-weight: 700; color: #9aa0ac; margin-bottom: 6px; }
        .form_group input, .form_group select { width: 100%; height: 44px; border: 1px solid rgba(255,255,255,0.14); border-radius: 8px; padding: 0 14px; font-size: 14px; background: rgba(255,255,255,0.06); transition: all 0.2s; }
        .form_group input:focus, .form_group select:focus { outline: none; border-color: #8b7cf9; background: transparent; box-shadow: 0 0 0 3px rgba(139, 124, 249,0.1); }
        .form_group input:disabled { opacity: 0.6; cursor: not-allowed; }
        .modal_ft { padding: 16px 24px; border-top: 1px solid rgba(255,255,255,0.14); display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
        .btn_modal_cancel { padding: 12px; border-radius: 8px; background: rgba(255,255,255,0.06); color: #b7bac8; border: 1px solid rgba(255,255,255,0.14); font-size: 14px; font-weight: 700; cursor: pointer; }
        .btn_modal_submit { padding: 12px; border-radius: 8px; background: #8b7cf9; color: #fff; border: none; font-size: 14px; font-weight: 700; cursor: pointer; }
        .btn_modal_submit:hover { background: #7c6cf0; }
    </style>
</head>
<body>
<div id="admin_wrapper">
    <?php include_once('../aside.php'); ?>
    <main class="content_area">

        <div class="page_header">
            <h2 class="page_title">회원 관리</h2>
            <form method="get" class="search_form">
                <input type="text" name="search" class="search_input" placeholder="아이디, 이름 검색..." value="<?= htmlspecialchars($search) ?>">
                <button type="submit" class="btn_search">검색</button>
                <?php if ($search): ?>
                <button type="button" onclick="location.href='<?= strtok($_SERVER['REQUEST_URI'],'?') ?>'" class="btn_reset">초기화</button>
                <?php endif; ?>
            </form>
        </div>

        <div class="card">
            <?php if ($search): ?>
            <div class="search_result">"<?= htmlspecialchars($search) ?>" 검색결과 — <?= sql_num_rows($result) ?>건</div>
            <?php endif; ?>
            <div class="table_wrap">
                <table>
                    <thead>
                        <tr>
                            <th>회원 정보</th>
                            <th>아이디</th>
                            <th style="text-align:center;">권한</th>
                            <th style="text-align:center;">가입일</th>
                            <th style="text-align:center;">관리</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i = 0;
                        while ($row = sql_fetch_array($result)):
                            $i++;
                        ?>
                        <tr>
                            <td>
                                <div class="member_info">
                                    <div class="member_avatar"><?= mb_substr($row['mb_name'], 0, 1) ?></div>
                                    <div>
                                        <div class="member_name"><?= htmlspecialchars($row['mb_name']) ?></div>
                                        <div class="member_email"><?= htmlspecialchars($row['mb_email']) ?></div>
                                    </div>
                                </div>
                            </td>
                            <td><span class="member_id"><?= htmlspecialchars($row['mb_id']) ?></span></td>
                            <td style="text-align:center;">
                                <span class="level_badge">Lv.<?= $row['mb_level'] ?></span>
                                <?php if (!empty($row['mb_is_clinic'])): ?><span class="clinic_badge">병원</span><?php endif; ?>
                            </td>
                            <td style="text-align:center;" class="td_date"><?= substr($row['mb_datetime'], 0, 10) ?></td>
                            <td>
                                <div class="td_actions">
                                    <button type="button" onclick='openEditModal(<?= json_encode($row) ?>)' class="btn_edit">수정</button>
                                    <button onclick="if(confirm('탈퇴 처리하시겠습니까?')) location.href='?leave_id=<?= $row['mb_id'] ?><?= $search ? '&search='.urlencode($search) : '' ?>'" class="btn_leave">탈퇴</button>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                        <?php if ($i === 0): ?>
                        <tr class="empty_row"><td colspan="5"><?= $search ? '검색 결과가 없습니다.' : '등록된 회원이 없습니다.' ?></td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="add_row">
            <button onclick="document.getElementById('addModal').classList.add('active')" class="btn_add">+ 회원 추가</button>
        </div>
    </main>
</div>

<!-- 회원 추가 모달 -->
<div class="modal_overlay" id="addModal">
    <div class="modal_box">
        <div class="modal_hd">
            <h3>새 회원 등록</h3>
            <button class="modal_close" onclick="document.getElementById('addModal').classList.remove('active')">✕</button>
        </div>
        <form method="post">
            <input type="hidden" name="action" value="add_member">
            <div class="modal_bd">
                <div class="form_group"><label>아이디</label><input type="text" name="mb_id" placeholder="아이디 입력" required></div>
                <div class="form_group"><label>비밀번호</label><input type="password" name="mb_password" placeholder="비밀번호 입력" required></div>
                <div class="form_group"><label>이름</label><input type="text" name="mb_name" placeholder="실명 입력" required></div>
                <div class="form_group"><label>이메일</label><input type="email" name="mb_email" placeholder="email@example.com" required></div>
                <div class="form_group">
                    <label>권한 레벨</label>
                    <select name="mb_level" id="add_mb_level">
                        <?php for ($i = 2; $i <= 10; $i++): ?>
                        <option value="<?= $i ?>" <?= $i == 2 ? 'selected' : '' ?>>Level <?= $i ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
                <label class="clinic_check">
                    <input type="checkbox" name="mb_is_clinic" id="add_is_clinic" onchange="toggleClinic(this,'add')">
                    <span class="cc_txt"><b>병원 계정으로 지정</b><span>체크 시 newadm 접근이 차단되고 병원 관리자(/clinic)만 사용합니다. (자동 Lv10)</span></span>
                </label>
            </div>
            <div class="modal_ft">
                <button type="button" class="btn_modal_cancel" onclick="document.getElementById('addModal').classList.remove('active')">취소</button>
                <button type="submit" class="btn_modal_submit">등록하기</button>
            </div>
        </form>
    </div>
</div>

<!-- 회원 수정 모달 -->
<div class="modal_overlay" id="editModal">
    <div class="modal_box">
        <div class="modal_hd">
            <h3>회원 정보 수정</h3>
            <button class="modal_close" onclick="document.getElementById('editModal').classList.remove('active')">✕</button>
        </div>
        <form method="post">
            <input type="hidden" name="action" value="update_member">
            <input type="hidden" name="mb_id" id="edit_mb_id">
            <div class="modal_bd">
                <div class="form_group"><label>아이디</label><input type="text" id="display_mb_id" disabled></div>
                <div class="form_group"><label>이름</label><input type="text" name="mb_name" id="edit_mb_name" required></div>
                <div class="form_group"><label>이메일</label><input type="email" name="mb_email" id="edit_mb_email" required></div>
                <div class="form_group"><label>비밀번호 (변경 시만 입력)</label><input type="password" name="mb_password" placeholder="미입력 시 기존 유지"></div>
                <div class="form_group">
                    <label>권한 레벨</label>
                    <select name="mb_level" id="edit_mb_level">
                        <?php for ($i = 2; $i <= 10; $i++): ?>
                        <option value="<?= $i ?>">Level <?= $i ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
                <label class="clinic_check">
                    <input type="checkbox" name="mb_is_clinic" id="edit_is_clinic" onchange="toggleClinic(this,'edit')">
                    <span class="cc_txt"><b>병원 계정으로 지정</b><span>체크 시 newadm 접근이 차단되고 병원 관리자(/clinic)만 사용합니다. (자동 Lv10)</span></span>
                </label>
            </div>
            <div class="modal_ft">
                <button type="button" class="btn_modal_cancel" onclick="document.getElementById('editModal').classList.remove('active')">취소</button>
                <button type="submit" class="btn_modal_submit">수정 완료</button>
            </div>
        </form>
    </div>
</div>

<script>
function openEditModal(data) {
    document.getElementById('edit_mb_id').value = data.mb_id;
    document.getElementById('display_mb_id').value = data.mb_id;
    document.getElementById('edit_mb_name').value = data.mb_name;
    document.getElementById('edit_mb_email').value = data.mb_email;
    document.getElementById('edit_mb_level').value = data.mb_level;
    var chk = document.getElementById('edit_is_clinic');
    chk.checked = (data.mb_is_clinic == 1);
    toggleClinic(chk, 'edit');
    document.getElementById('editModal').classList.add('active');
}

// 병원계정 체크 시 레벨을 10으로 고정(잠금)
function toggleClinic(chk, mode) {
    var sel = document.getElementById(mode + '_mb_level');
    if (!sel) return;
    if (chk.checked) { sel.value = '10'; sel.disabled = true; }
    else { sel.disabled = false; }
}
['addModal','editModal'].forEach(id => {
    document.getElementById(id).addEventListener('click', function(e) { if (e.target === this) this.classList.remove('active'); });
});
</script>
</body>
</html>