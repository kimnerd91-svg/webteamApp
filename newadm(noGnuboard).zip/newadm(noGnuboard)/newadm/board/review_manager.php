<?php
include_once('../_common.php');
include_once('../_auth_check.php');


// ============================================================
// 테이블 자동 생성
// ============================================================
$chk = sql_query("SHOW TABLES LIKE 'dm_review'");
if (sql_num_rows($chk) == 0) {
    sql_query("CREATE TABLE `dm_review` (
        `id`            int(11) NOT NULL AUTO_INCREMENT,
        `category`      varchar(100) NOT NULL DEFAULT '',
        `author`        varchar(100) NOT NULL DEFAULT '',
        `rating`        decimal(2,1) NOT NULL DEFAULT 5.0,
        `content`       text NOT NULL,
        `is_visible`    tinyint(1) NOT NULL DEFAULT 1,
        `display_order` int(11) NOT NULL DEFAULT 0,
        `created_at`    datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", false);
}

// 카테고리 테이블 자동 생성
$chk2 = sql_query("SHOW TABLES LIKE 'dm_review_category'");
if (sql_num_rows($chk2) == 0) {
    sql_query("CREATE TABLE `dm_review_category` (
        `id`   int(11) NOT NULL AUTO_INCREMENT,
        `name` varchar(100) NOT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", false);
    // 기본 카테고리 삽입
    sql_query("INSERT INTO dm_review_category (name) VALUES ('임플란트'),('심미치료'),('자연치아 살리기'),('일반진료'),('기타')");
}

// ============================================================
// AJAX 처리
// ============================================================
if (isset($_POST['ajax_action'])) {
    header('Content-Type: application/json');
    $action = $_POST['ajax_action'];

    // 카테고리 추가
    if ($action === 'add_category') {
        $name = sql_real_escape_string(trim($_POST['name'] ?? ''));
        if (!$name) { echo json_encode(['success' => false, 'msg' => '카테고리명을 입력하세요.']); exit; }
        $dup = sql_query("SELECT id FROM dm_review_category WHERE name='{$name}' LIMIT 1");
        if (sql_num_rows($dup) > 0) { echo json_encode(['success' => false, 'msg' => '이미 존재하는 카테고리입니다.']); exit; }
        sql_query("INSERT INTO dm_review_category (name) VALUES ('{$name}')");
        $new_id = sql_insert_id();
        echo json_encode(['success' => true, 'id' => $new_id, 'name' => stripslashes($name)]);
        exit;
    }

    // 카테고리 삭제
    if ($action === 'delete_category') {
        $id = (int)($_POST['id'] ?? 0);
        sql_query("DELETE FROM dm_review_category WHERE id={$id}");
        echo json_encode(['success' => true]);
        exit;
    }

    // 리뷰 저장/수정
if ($action === 'save_review') {
    // ▼ 임시 디버그
    $cols = [];
    $col_res = sql_query("SHOW COLUMNS FROM dm_review");
    while($c = sql_fetch_array($col_res)) $cols[] = $c['Field'];
    error_log("dm_review columns: " . implode(', ', $cols));
    $test = sql_query("INSERT INTO dm_review (category, author, rating, content, is_visible) VALUES ('test','test',5.0,'test',1)");
    if (!$test) {
        echo json_encode(['success' => false, 'msg' => '직접 INSERT 실패 — 컬럼 불일치 가능성', 'cols' => $cols]);
        exit;
    }
    sql_query("DELETE FROM dm_review WHERE author='test' AND content='test'");
    // ▲ 여기까지
        $id       = (int)($_POST['id'] ?? 0);
        $category = sql_real_escape_string(trim($_POST['category'] ?? ''));
        $author   = sql_real_escape_string(trim($_POST['author'] ?? ''));
        $rating   = number_format(min(5, max(0.5, (float)($_POST['rating'] ?? 5))), 1);
        $content  = sql_real_escape_string(trim($_POST['content'] ?? ''));
        $visible  = (int)($_POST['is_visible'] ?? 1);

        if ($id > 0) {
            sql_query("UPDATE dm_review SET category='{$category}', author='{$author}', rating={$rating}, content='{$content}', is_visible={$visible} WHERE id={$id}");
        } else {
            sql_query("INSERT INTO dm_review (category, author, rating, content, is_visible) VALUES ('{$category}', '{$author}', {$rating}, '{$content}', {$visible})");
            $id = sql_insert_id();
        }
        echo json_encode(['success' => true, 'id' => $id]);
        exit;
    }

    // 리뷰 삭제
    if ($action === 'delete_review') {
        $id = (int)($_POST['id'] ?? 0);
        sql_query("DELETE FROM dm_review WHERE id={$id}");
        echo json_encode(['success' => true]);
        exit;
    }

    // 노출 토글
    if ($action === 'toggle_visible') {
        $id = (int)($_POST['id'] ?? 0);
        $v  = (int)($_POST['is_visible'] ?? 0);
        sql_query("UPDATE dm_review SET is_visible={$v} WHERE id={$id}");
        echo json_encode(['success' => true]);
        exit;
    }

    echo json_encode(['success' => false, 'msg' => 'unknown action']);
    exit;
}

// ============================================================
// 데이터 조회
// ============================================================
$categories = [];
$cat_result = sql_query("SELECT * FROM dm_review_category ORDER BY id ASC");
while ($row = sql_fetch_array($cat_result)) $categories[] = $row;

$reviews = [];
$rev_result = sql_query("SELECT * FROM dm_review ORDER BY display_order ASC, id DESC");
while ($row = sql_fetch_array($rev_result)) $reviews[] = $row;
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>리뷰 관리</title>
<style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Pretendard', 'Apple SD Gothic Neo', sans-serif; background: rgba(255,255,255,0.06); color: #f1f2f5; }
    #admin_wrapper { display: flex; min-height: 100vh; }
    .content_area { flex: 1; padding: 40px; overflow-x: hidden; }

    .page_header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 28px; }
    .page_title  { font-size: 22px; font-weight: 700; }
    .btn_add { padding: 11px 22px; background: #8b7cf9; color: #fff; border: none; border-radius: 9px; font-size: 13px; font-weight: 700; cursor: pointer; box-shadow: 0 4px 12px rgba(139, 124, 249,0.25); transition: all 0.2s; }
    .btn_add:hover { background: #7c6cf0; }

    /* 카테고리 관리 카드 */
    .cat_card { background: transparent; border-radius: 12px; box-shadow: 0 2px 12px rgba(0,0,0,0.06); border: 1px solid rgba(255,255,255,0.14); padding: 20px 24px; margin-bottom: 20px; }
    .cat_card_title { font-size: 13px; font-weight: 700; color: #9aa0ac; margin-bottom: 14px; }
    .cat_list { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 14px; }
    .cat_chip { display: inline-flex; align-items: center; gap: 6px; background: rgba(139,124,249,0.18); color: #8b7cf9; padding: 5px 12px; border-radius: 20px; font-size: 12px; font-weight: 700; }
    .cat_chip_del { background: none; border: none; color: #7c6fcd; cursor: pointer; font-size: 14px; line-height: 1; padding: 0; }
    .cat_chip_del:hover { color: #dc2626; }
    .cat_add_row { display: flex; gap: 8px; }
    .cat_add_input { flex: 1; border: 1px solid rgba(255,255,255,0.14); border-radius: 8px; padding: 9px 14px; font-size: 13px; background: rgba(255,255,255,0.06); font-family: inherit; }
    .cat_add_input:focus { outline: none; border-color: #8b7cf9; background: transparent; }
    .cat_add_btn { padding: 9px 18px; background: #8b7cf9; color: #fff; border: none; border-radius: 8px; font-size: 13px; font-weight: 700; cursor: pointer; }
    .cat_add_btn:hover { background: #7c6cf0; }

    /* 리뷰 카드 그리드 */
    .review_grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(340px, 1fr)); gap: 16px; }
    .rv_card { background: transparent; border-radius: 16px; box-shadow: 0 2px 12px rgba(0,0,0,0.07); border: 1px solid rgba(255,255,255,0.14); padding: 24px; display: flex; flex-direction: column; gap: 14px; transition: box-shadow 0.2s; }
    .rv_card:hover { box-shadow: 0 6px 24px rgba(0,0,0,0.11); }
    .rv_card_top { display: flex; align-items: center; justify-content: space-between; }
    .cat_badge { display: inline-block; padding: 6px 16px; background: transparent; color: #4f6ef7; border: 1.5px solid #4f6ef7; border-radius: 999px; font-size: 13px; font-weight: 500; }
    .stars_display { color: #f59e0b; font-size: 20px; letter-spacing: 2px; white-space: nowrap; }
    .rv_author { font-size: 15px; font-weight: 700; color: #f1f2f5; }
    .rv_content { font-size: 15px; color: #d7d9e2; line-height: 1.7; word-break: keep-all; }
    .rv_card_ft { display: flex; align-items: center; justify-content: space-between; padding-top: 10px; border-top: 1px solid #f0f0f8; margin-top: auto; }
    .rv_date { font-size: 12px; color: #b0b0c8; }
    .rv_actions { display: flex; gap: 8px; }
    .btn_edit_row { padding: 6px 14px; background: rgba(139,124,249,0.18); color: #8b7cf9; border: none; border-radius: 7px; font-size: 12px; font-weight: 700; cursor: pointer; }
    .btn_edit_row:hover { background: #ddd6fe; }
    .btn_del_row { padding: 6px 14px; background: #fee2e2; color: #dc2626; border: none; border-radius: 7px; font-size: 12px; font-weight: 700; cursor: pointer; }
    .btn_del_row:hover { background: #fecaca; }
    .rv_hidden_badge { font-size: 11px; color: #9aa0ac; background: rgba(255,255,255,0.06); border-radius: 5px; padding: 2px 8px; }
    .empty_grid { text-align: center; padding: 60px; color: #9aa0ac; font-size: 14px; background: transparent; border-radius: 16px; border: 1px dashed rgba(255,255,255,0.14); }

    /* 토글 스위치 */
    .sw { position: relative; display: inline-block; width: 40px; height: 21px; }
    .sw input { opacity: 0; width: 0; height: 0; }
    .sl { position: absolute; cursor: pointer; inset: 0; background: #d1d5e0; border-radius: 21px; transition: .3s; }
    .sl:before { content: ''; position: absolute; height: 15px; width: 15px; left: 3px; bottom: 3px; background: #fff; border-radius: 50%; transition: .3s; }
    input:checked + .sl { background: #8b7cf9; }
    input:checked + .sl:before { transform: translateX(19px); }

    /* 모달 */
    .modal_overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.55); z-index: 10000; align-items: flex-start; justify-content: center; padding: 40px 20px; overflow-y: auto; }
    .modal_overlay.active { display: flex; }
    .modal_box { background: transparent; border-radius: 14px; width: 100%; max-width: 560px; overflow: hidden; animation: modal_in 0.25s ease; margin: auto; }
    @keyframes modal_in { from { transform: translateY(-20px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
    .modal_hd { padding: 20px 24px; border-bottom: 1px solid rgba(255,255,255,0.14); display: flex; align-items: center; justify-content: space-between; }
    .modal_hd h3 { font-size: 16px; font-weight: 700; }
    .modal_close { background: none; border: none; font-size: 20px; cursor: pointer; color: #9aa0ac; }
    .modal_bd { padding: 24px; display: flex; flex-direction: column; gap: 18px; max-height: 80vh; overflow-y: auto; }
    .modal_ft { padding: 16px 24px; border-top: 1px solid rgba(255,255,255,0.14); display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }

    .form_group label { display: block; font-size: 12px; font-weight: 700; color: #9aa0ac; margin-bottom: 7px; }
    .form_group label span { color: #dc2626; }
    .form_input { width: 100%; border: 1px solid rgba(255,255,255,0.14); border-radius: 8px; padding: 10px 14px; font-size: 14px; background: rgba(255,255,255,0.06); font-family: inherit; transition: all 0.2s; }
    .form_input:focus { outline: none; border-color: #8b7cf9; background: transparent; box-shadow: 0 0 0 3px rgba(139, 124, 249,0.1); }
    select.form_input { height: 44px; cursor: pointer; }

    /* 토글 행 */
    .toggle_row { display: flex; align-items: center; gap: 12px; background: rgba(255,255,255,0.06); padding: 12px 16px; border-radius: 9px; }
    .toggle_row label { font-size: 13px; font-weight: 700; color: #f1f2f5; }

    /* 별점 입력 */
    .star_wrap { display: flex; align-items: center; gap: 10px; }
    .star_input_area { display: flex; gap: 2px; cursor: pointer; user-select: none; }
    .star_seg { font-size: 28px; color: #d1d5e0; transition: color 0.15s; }
    .star_seg.filled { color: #f59e0b; }
    .star_seg.half-filled { background: linear-gradient(90deg, #f59e0b 50%, #d1d5e0 50%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; }
    .rating_display { font-size: 15px; font-weight: 700; color: #f59e0b; min-width: 30px; }

    /* contenteditable 입력창 */
    .content_editable { width: 100%; min-height: 100px; border: 1px solid rgba(255,255,255,0.14); border-radius: 8px; padding: 12px 14px; font-size: 14px; background: rgba(255,255,255,0.06); font-family: inherit; line-height: 1.7; color: #f1f2f5; transition: all 0.2s; outline: none; }
    .content_editable:focus { border-color: #8b7cf9; background: transparent; box-shadow: 0 0 0 3px rgba(139, 124, 249,0.1); }
    .content_editable:empty::before { content: attr(data-placeholder); color: #b0b0c8; pointer-events: none; }

    .btn_modal_cancel { padding: 12px; border-radius: 8px; background: rgba(255,255,255,0.06); color: #b7bac8; border: 1px solid rgba(255,255,255,0.14); font-size: 14px; font-weight: 700; cursor: pointer; }
    .btn_modal_submit { padding: 12px; border-radius: 8px; background: #8b7cf9; color: #fff; border: none; font-size: 14px; font-weight: 700; cursor: pointer; }
    .btn_modal_submit:hover { background: #7c6cf0; }
</style>
</head>
<body>
<div id="admin_wrapper">
    <?php include_once('../aside.php'); ?>
    <main class="content_area">

        <div class="page_header">
            <h2 class="page_title">⭐ 리뷰 관리</h2>
            <button type="button" class="btn_add" onclick="openReviewModal()">+ 리뷰 추가</button>
        </div>

        <!-- 카테고리 관리 -->
        <div class="cat_card">
            <div class="cat_card_title">카테고리 관리</div>
            <div class="cat_list" id="catList">
                <?php foreach ($categories as $cat): ?>
                <span class="cat_chip" id="cat-chip-<?= $cat['id'] ?>">
                    <?= htmlspecialchars($cat['name']) ?>
                    <button class="cat_chip_del" onclick="deleteCategory(<?= $cat['id'] ?>, '<?= htmlspecialchars($cat['name'], ENT_QUOTES) ?>')">✕</button>
                </span>
                <?php endforeach; ?>
            </div>
            <div class="cat_add_row">
                <input type="text" class="cat_add_input" id="newCatInput" placeholder="새 카테고리 입력" onkeydown="if(event.key==='Enter') addCategory()">
                <button type="button" class="cat_add_btn" onclick="addCategory()">추가</button>
            </div>
        </div>

        <!-- 리뷰 카드 목록 -->
        <?php if (empty($reviews)): ?>
        <div class="empty_grid">등록된 리뷰가 없습니다.</div>
        <?php else: ?>
        <div class="review_grid" id="reviewGrid">
            <?php foreach ($reviews as $r): ?>
            <div class="rv_card">
                <!-- 상단: 카테고리 뱃지 + 별점 -->
                <div class="rv_card_top">
                    <?php if ($r['category']): ?>
                        <span class="cat_badge"><?= htmlspecialchars($r['category']) ?></span>
                    <?php else: ?>
                        <span></span>
                    <?php endif; ?>
                    <span class="stars_display"><?= renderStars((float)$r['rating']) ?></span>
                </div>

                <!-- 작성자 -->
                <div class="rv_author"><?= htmlspecialchars($r['author']) ?></div>

                <!-- 내용 -->
                <div class="rv_content"><?= nl2br(htmlspecialchars($r['content'])) ?></div>

                <!-- 하단: 날짜 + 노출토글 + 수정/삭제 -->
                <div class="rv_card_ft">
                    <div style="display:flex; align-items:center; gap:10px;">
                        <span class="rv_date"><?= date('Y.m.d', strtotime($r['created_at'])) ?></span>
                        <?php if (!$r['is_visible']): ?>
                            <span class="rv_hidden_badge">비노출</span>
                        <?php endif; ?>
                        <label class="sw" title="노출 여부">
                            <input type="checkbox" <?= $r['is_visible'] ? 'checked' : '' ?>
                                onchange="toggleVisible(<?= $r['id'] ?>, this.checked ? 1 : 0)">
                            <span class="sl"></span>
                        </label>
                    </div>
                    <div class="rv_actions">
                        <button class="btn_edit_row"
                            onclick="openReviewModal(<?= htmlspecialchars(json_encode($r), ENT_QUOTES) ?>)">수정</button>
                        <button class="btn_del_row"
                            onclick="deleteReview(<?= $r['id'] ?>)">삭제</button>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

    </main>
</div>

<!-- 리뷰 모달 -->
<div class="modal_overlay" id="reviewModal">
    <div class="modal_box">
        <div class="modal_hd">
            <h3 id="modalTitle">리뷰 추가</h3>
            <button class="modal_close" onclick="closeModal('reviewModal')">✕</button>
        </div>
        <div class="modal_bd">
            <input type="hidden" id="reviewId" value="0">

            <div class="toggle_row">
                <label class="sw"><input type="checkbox" id="isVisible" checked><span class="sl"></span></label>
                <label>노출 여부</label>
            </div>

            <div class="form_group">
                <label>카테고리 <span>*</span></label>
                <select class="form_input" id="reviewCategory">
                    <option value="">선택</option>
                    <?php foreach ($categories as $cat): ?>
                    <option value="<?= htmlspecialchars($cat['name']) ?>"><?= htmlspecialchars($cat['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form_group">
                <label>작성자 (이름 또는 아이디) <span>*</span></label>
                <input type="text" class="form_input" id="reviewAuthor" placeholder="예: par***">
            </div>

            <div class="form_group">
                <label>별점</label>
                <div class="star_wrap">
                    <div class="star_input_area" id="starInput">
                        <span class="star_seg" data-index="1">★</span>
                        <span class="star_seg" data-index="2">★</span>
                        <span class="star_seg" data-index="3">★</span>
                        <span class="star_seg" data-index="4">★</span>
                        <span class="star_seg" data-index="5">★</span>
                    </div>
                    <span class="rating_display" id="ratingDisplay">5.0</span>
                    <input type="hidden" id="reviewRating" value="5.0">
                </div>
            </div>

            <div class="form_group">
                <label>리뷰 내용 <span>*</span></label>
                <div class="content_editable"
                    id="reviewContent"
                    contenteditable="true"
                    data-placeholder="치료 후기를 입력해주세요"></div>
            </div>

        </div>
        <div class="modal_ft">
            <button type="button" class="btn_modal_cancel" onclick="closeModal('reviewModal')">취소</button>
            <button type="button" class="btn_modal_submit" onclick="saveReview()">저장</button>
        </div>
    </div>
</div>

<?php
function renderStars(float $rating): string {
    $html = '';
    for ($i = 1; $i <= 5; $i++) {
        if ($rating >= $i) $html .= '★';
        elseif ($rating >= $i - 0.5) $html .= '⯨'; // half star fallback
        else $html .= '☆';
    }
    return $html;
}
?>

<script>
const AJAX_URL = './review_manager.php';

// ── 별점 입력 ──────────────────────────────────────────────
(function () {
    const area    = document.getElementById('starInput');
    const segs    = area.querySelectorAll('.star_seg');
    const hidden  = document.getElementById('reviewRating');
    const display = document.getElementById('ratingDisplay');

    function setRating(val) {
        hidden.value  = val.toFixed(1);
        display.textContent = val.toFixed(1);
        segs.forEach((s, i) => {
            s.classList.remove('filled', 'half-filled');
            const pos = i + 1;
            if (val >= pos) s.classList.add('filled');
            else if (val >= pos - 0.5) s.classList.add('half-filled');
        });
    }

    area.addEventListener('mousemove', function (e) {
        const rect = area.getBoundingClientRect();
        const x    = e.clientX - rect.left;
        const w    = rect.width;
        const raw  = (x / w) * 5;
        const val  = Math.max(0.5, Math.round(raw * 2) / 2);
        setRating(val);
    });

    area.addEventListener('mouseleave', function () {
        setRating(parseFloat(hidden.value));
    });

    area.addEventListener('click', function (e) {
        // 값 고정 (mousemove에서 이미 설정됨)
    });

    // 기본 5점
    setRating(5.0);
    window._setStarRating = setRating;
})();

// ── 모달 ──────────────────────────────────────────────────
function closeModal(id) {
    document.getElementById(id).classList.remove('active');
}

function openReviewModal(data) {
    document.getElementById('reviewId').value       = data ? data.id : 0;
    document.getElementById('reviewCategory').value = data ? (data.category || '') : '';
    document.getElementById('reviewAuthor').value   = data ? (data.author || '') : '';
    document.getElementById('reviewContent').innerText = data ? (data.content || '') : '';
    document.getElementById('isVisible').checked   = data ? data.is_visible == 1 : true;
    window._setStarRating(data ? parseFloat(data.rating) : 5.0);
    document.getElementById('modalTitle').textContent = data ? '리뷰 수정' : '리뷰 추가';
    document.getElementById('reviewModal').classList.add('active');
}

// ── 저장 ──────────────────────────────────────────────────
async function saveReview() {
    const category = document.getElementById('reviewCategory').value.trim();
    const author   = document.getElementById('reviewAuthor').value.trim();
    const content  = document.getElementById('reviewContent').innerText.trim();
    const rating   = document.getElementById('reviewRating').value;
    const visible  = document.getElementById('isVisible').checked ? 1 : 0;
    const id       = document.getElementById('reviewId').value;

    if (!category) { alert('카테고리를 선택하세요.'); return; }
    if (!author)   { alert('작성자를 입력하세요.'); return; }
    if (!content)  { alert('리뷰 내용을 입력하세요.'); return; }

    const res = await ajax({ ajax_action: 'save_review', id, category, author, rating, content, is_visible: visible });
    if (res.success) { closeModal('reviewModal'); location.reload(); }
    else alert(res.msg || '저장 실패');
}

// ── 삭제 ──────────────────────────────────────────────────
async function deleteReview(id) {
    if (!confirm('리뷰를 삭제하시겠습니까?')) return;
    const res = await ajax({ ajax_action: 'delete_review', id });
    if (res.success) location.reload();
}

// ── 노출 토글 ──────────────────────────────────────────────
async function toggleVisible(id, v) {
    await ajax({ ajax_action: 'toggle_visible', id, is_visible: v });
}

// ── 카테고리 추가 ──────────────────────────────────────────
async function addCategory() {
    const input = document.getElementById('newCatInput');
    const name  = input.value.trim();
    if (!name) return;
    const res = await ajax({ ajax_action: 'add_category', name });
    if (res.success) {
        // 칩 추가
        const list = document.getElementById('catList');
        const chip = document.createElement('span');
        chip.className = 'cat_chip';
        chip.id = 'cat-chip-' + res.id;
        chip.innerHTML = `${esc(res.name)} <button class="cat_chip_del" onclick="deleteCategory(${res.id}, '${esc(res.name)}')">✕</button>`;
        list.appendChild(chip);
        // 셀렉트에도 추가
        const sel = document.getElementById('reviewCategory');
        const opt = document.createElement('option');
        opt.value = res.name; opt.textContent = res.name;
        sel.appendChild(opt);
        input.value = '';
    } else {
        alert(res.msg || '추가 실패');
    }
}

// ── 카테고리 삭제 ──────────────────────────────────────────
async function deleteCategory(id, name) {
    if (!confirm(`"${name}" 카테고리를 삭제하시겠습니까?`)) return;
    const res = await ajax({ ajax_action: 'delete_category', id });
    if (res.success) {
        const chip = document.getElementById('cat-chip-' + id);
        if (chip) chip.remove();
        // 셀렉트에서도 제거
        const sel = document.getElementById('reviewCategory');
        [...sel.options].forEach(o => { if (o.value === name) o.remove(); });
    }
}

// ── 공통 AJAX ──────────────────────────────────────────────
async function ajax(data) {
    const body = new URLSearchParams(data);
    const res  = await fetch(AJAX_URL, { method: 'POST', body });
    return res.json();
}

function esc(str) {
    return String(str || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
</script>
</body>
</html>