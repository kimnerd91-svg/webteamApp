<?php
include_once('../../common.php');
include_once('../_common.php');
include_once('../_auth_check.php');

if ($is_admin != 'super') alert('최고관리자만 접근 가능합니다.');

$dm = sql_fetch("SELECT * FROM dm_config WHERE cf_id = 1");
if (!$dm) {
    sql_query("INSERT INTO dm_config (cf_id, cf_langs) VALUES (1, 'ko')");
    $dm = sql_fetch("SELECT * FROM dm_config WHERE cf_id = 1");
}

$g5['title'] = '디렉트 통합 관리자';
include_once(G5_ADMIN_PATH . '/admin.head.php');
?>

<style>
    *, *::before, *::after { box-sizing: border-box; }
    body { background: rgba(255,255,255,0.06) !important; }

    #dm_admin_wrap { max-width: 960px; margin: 0 auto; padding: 40px 20px 80px; }

    .dm_page_title { font-size: 22px; font-weight: 700; color: #f1f2f5; margin-bottom: 28px; }

    .admin-card {
        background: transparent;
        border-radius: 12px;
        box-shadow: 0 2px 12px rgba(0,0,0,0.06);
        border: 1px solid rgba(255,255,255,0.14);
        padding: 24px 28px;
        margin-bottom: 20px;
    }

    .admin-card h3 { font-size: 15px; font-weight: 700; color: #f1f2f5; margin-bottom: 16px; }

    /* 다국어 체크박스 */
    .lang_checks { display: flex; gap: 20px; flex-wrap: wrap; }
    .lang_checks label { display: flex; align-items: center; gap: 7px; font-size: 14px; font-weight: 600; color: #d7d9e2; cursor: pointer; }
    .lang_checks input[type="checkbox"] { width: 16px; height: 16px; accent-color: #8b7cf9; cursor: pointer; }
    .lang_note { font-size: 12px; color: #9aa0ac; margin-top: 10px; }

    /* 폼 */
    .form_group { margin-bottom: 16px; }
    .form_group label { display: block; font-size: 13px; font-weight: 700; color: #f1f2f5; margin-bottom: 6px; }
    .form_group input[type="text"],
    .form_group textarea {
        width: 100%; border: 1px solid rgba(255,255,255,0.14); border-radius: 8px;
        padding: 10px 14px; font-size: 14px; background: rgba(255,255,255,0.06); color: #f1f2f5;
        font-family: inherit; transition: all 0.2s;
    }
    .form_group input[type="text"] { height: 44px; }
    .form_group textarea { resize: vertical; }
    .form_group input:focus, .form_group textarea:focus { outline: none; border-color: #8b7cf9; background: #fff; box-shadow: 0 0 0 3px rgba(139, 124, 249,0.1); }

    /* 테이블 */
    .dm_table_wrap { overflow-x: auto; }
    .dm_table { width: 100%; border-collapse: collapse; min-width: 520px; }
    .dm_table thead th { background: rgba(255,255,255,0.06); padding: 11px 16px; font-size: 12px; font-weight: 700; color: #9aa0ac; text-align: left; border-bottom: 2px solid rgba(255,255,255,0.14); }
    .dm_table tbody td { padding: 13px 16px; border-bottom: 1px solid #f5f6fa; font-size: 14px; color: #d7d9e2; vertical-align: middle; }
    .dm_table tbody tr:last-child td { border-bottom: none; }
    .dm_table tbody tr:hover td { background: #fafafa; }

    .board_name { font-weight: 700; color: #f1f2f5; }
    .board_table_code { font-family: monospace; font-size: 12px; background: rgba(255,255,255,0.06); padding: 3px 8px; border-radius: 5px; color: #b7bac8; }
    .post_count { display: inline-block; background: rgba(139,124,249,0.18); color: #8b7cf9; padding: 3px 10px; border-radius: 20px; font-size: 12px; font-weight: 700; }
    .status_badge { display: inline-block; background: #d1fae5; color: #059669; padding: 3px 10px; border-radius: 20px; font-size: 11px; font-weight: 700; }

    .btn_sm { display: inline-block; padding: 5px 12px; border-radius: 6px; font-size: 12px; font-weight: 700; text-decoration: none; transition: all 0.2s; border: 1px solid rgba(255,255,255,0.14); color: #d7d9e2; background: rgba(255,255,255,0.06); margin-right: 4px; }
    .btn_sm:hover { background: rgba(255,255,255,0.14); color: #f1f2f5; }
    .btn_sm.primary { background: #8b7cf9; color: #fff; border-color: #8b7cf9; }
    .btn_sm.primary:hover { background: #7c6cf0; }

    .card_header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px; }
    .card_header h3 { margin-bottom: 0; }

    /* 저장 버튼 */
    .submit_bar { display: flex; justify-content: center; margin-top: 32px; }
    .btn_submit { padding: 14px 52px; background: #8b7cf9; color: #fff; border: none; border-radius: 10px; font-size: 15px; font-weight: 700; cursor: pointer; box-shadow: 0 4px 16px rgba(139, 124, 249,0.3); transition: all 0.2s; }
    .btn_submit:hover { background: #7c6cf0; transform: translateY(-1px); }
</style>

<form name="fadmin" method="post" action="./site_config_update.php" enctype="multipart/form-data">
<div id="dm_admin_wrap">

    <h2 class="dm_page_title">디렉트 통합 관리자</h2>

    <!-- 다국어 설정 -->
    <div class="admin-card">
        <h3>다국어 설정</h3>
        <div class="lang_checks">
            <label><input type="checkbox" name="cf_langs[]" value="ko" checked disabled> 한국어 (기본)</label>
            <label><input type="checkbox" name="cf_langs[]" value="en" <?= strpos($dm['cf_langs'] ?? '', 'en') !== false ? 'checked' : '' ?>> 영어</label>
            <label><input type="checkbox" name="cf_langs[]" value="ja" <?= strpos($dm['cf_langs'] ?? '', 'ja') !== false ? 'checked' : '' ?>> 일본어</label>
            <label><input type="checkbox" name="cf_langs[]" value="zh" <?= strpos($dm['cf_langs'] ?? '', 'zh') !== false ? 'checked' : '' ?>> 중국어</label>
        </div>
        <p class="lang_note">* 선택 시 홈페이지 상단에 언어 선택 박스가 자동 노출됩니다.</p>
    </div>

    <!-- SEO -->
    <div class="admin-card">
        <h3>검색엔진 최적화 (SEO)</h3>
        <div class="form_group">
            <label>사이트 타이틀</label>
            <input type="text" name="cf_title" value="<?= htmlspecialchars($dm['cf_title'] ?? '') ?>" placeholder="네이버 검색 시 제목으로 노출">
        </div>
        <div class="form_group">
            <label>사이트 설명 (Description)</label>
            <textarea name="cf_description" rows="3" placeholder="검색 결과 아래에 표시되는 설명글"><?= htmlspecialchars($dm['cf_description'] ?? '') ?></textarea>
        </div>
    </div>

    <!-- 게시판 목록 -->
    <div class="admin-card">
        <div class="card_header">
            <h3>게시판 및 게시물 관리</h3>
            <a href="<?= G5_ADMIN_URL ?>/board_form.php" class="btn_sm primary">+ 새 게시판 생성</a>
        </div>
        <div class="dm_table_wrap">
            <table class="dm_table">
                <thead>
                    <tr>
                        <th>테이블명</th>
                        <th>게시판 이름</th>
                        <th style="text-align:center;">글 개수</th>
                        <th style="text-align:center;">상태</th>
                        <th style="text-align:right;">관리</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sql    = "SELECT bo_table, bo_subject, bo_count_write FROM {$g5['board_table']} ORDER BY bo_table ASC";
                    $result = sql_query($sql);
                    $i      = 0;
                    while ($row = sql_fetch_array($result)):
                        $i++;
                    ?>
                    <tr>
                        <td><span class="board_table_code"><?= htmlspecialchars($row['bo_table']) ?></span></td>
                        <td><span class="board_name"><?= htmlspecialchars($row['bo_subject']) ?></span></td>
                        <td style="text-align:center;"><span class="post_count"><?= number_format($row['bo_count_write']) ?></span></td>
                        <td style="text-align:center;"><span class="status_badge">노출중</span></td>
                        <td style="text-align:right;">
                            <a href="<?= G5_ADMIN_URL ?>/board_form.php?w=u&bo_table=<?= $row['bo_table'] ?>" class="btn_sm">설정</a>
                            <a href="<?= G5_URL ?>/<?= $row['bo_table'] ?>" target="_blank" class="btn_sm">게시물 보기</a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                    <?php if ($i === 0): ?>
                    <tr><td colspan="5" style="text-align:center; padding:48px; color:#9aa0ac;">생성된 게시판이 없습니다.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="submit_bar">
        <button type="submit" class="btn_submit">설정값 일괄 저장하기</button>
    </div>

</div>
</form>

<?php include_once(G5_ADMIN_PATH . '/admin.tail.php'); ?>