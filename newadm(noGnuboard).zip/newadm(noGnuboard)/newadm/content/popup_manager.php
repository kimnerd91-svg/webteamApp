<?php
include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/_common.php');
include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/_auth_check.php');

sql_query(" CREATE TABLE IF NOT EXISTS `dm_popup` (
    `nw_id` int(11) NOT NULL AUTO_INCREMENT,
    `nw_subject` varchar(255) DEFAULT '',
    `nw_begin_time` datetime DEFAULT '0000-00-00 00:00:00',
    `nw_end_time` datetime DEFAULT '0000-00-00 00:00:00',
    `nw_width` int(11) DEFAULT '0',
    `nw_height` int(11) DEFAULT '0',
    `nw_left` int(11) DEFAULT '0',
    `nw_top` int(11) DEFAULT '0',
    `nw_img` varchar(255) DEFAULT '',
    `nw_status` tinyint(4) DEFAULT '1',
    `nw_type` varchar(20) DEFAULT 'general',
    PRIMARY KEY (`nw_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ");

sql_query(" ALTER TABLE `dm_popup` ADD IF NOT EXISTS `cf_popup_type` VARCHAR(20) DEFAULT 'general' ");

sql_query("
    UPDATE dm_popup SET nw_status = 0
    WHERE nw_status = 1 AND nw_end_time < NOW() AND nw_end_time != '0000-00-00 00:00:00'
");

$expired_list = sql_query("
    SELECT nw_id, nw_subject, nw_end_time FROM dm_popup
    WHERE nw_status = 0 AND nw_end_time < NOW() AND nw_end_time != '0000-00-00 00:00:00'
    AND DATE(nw_end_time) >= DATE(NOW() - INTERVAL 7 DAY)
    ORDER BY nw_end_time DESC
");
$expired_popups = [];
while ($exp = sql_fetch_array($expired_list)) $expired_popups[] = $exp;

if (isset($_POST['update_pop_mode'])) {
    $new_mode = sql_real_escape_string($_POST['pop_mode']);
    $check = sql_fetch(" SELECT count(*) as cnt FROM `dm_popup` ");
    if ($check['cnt'] == 0) sql_query(" INSERT INTO `dm_popup` SET cf_id = 1, cf_popup_type = '$new_mode' ");
    else sql_query(" UPDATE `dm_popup` SET cf_popup_type = '$new_mode' LIMIT 1 ");
    goto_url('./popup_manager.php');
}

$conf = sql_fetch(" SELECT cf_popup_type FROM `dm_popup` LIMIT 1 ");
$current_mode = (isset($conf['cf_popup_type']) && $conf['cf_popup_type']) ? $conf['cf_popup_type'] : 'general';
$result = sql_query(" SELECT * FROM dm_popup ORDER BY nw_id DESC ");
$rows = [];
while ($row = sql_fetch_array($result)) $rows[] = $row;
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>팝업 관리</title>
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Pretendard', 'Apple SD Gothic Neo', sans-serif; background: rgba(255,255,255,0.06); color: #f1f2f5; }
        #admin_wrapper { display: flex; min-height: 100vh; }
        .content_area { flex: 1; padding: 40px; overflow-x: hidden; }

        .page_header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 28px; }
        .page_title  { font-size: 22px; font-weight: 700; }
        .btn_primary { padding: 11px 22px; background: #8b7cf9; color: #fff; border: none; border-radius: 9px; font-size: 13px; font-weight: 700; cursor: pointer; box-shadow: 0 4px 12px rgba(139, 124, 249,0.25); transition: all 0.2s; text-decoration: none; display: inline-block; }
        .btn_primary:hover { background: #7c6cf0; }

        .card { background: transparent; border-radius: 12px; box-shadow: 0 2px 12px rgba(0,0,0,0.06); border: 1px solid rgba(255,255,255,0.14); margin-bottom: 24px; }
        .card_body { padding: 24px; }

        /* 운영 모드 */
        .mode_row { display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 16px; }
        .mode_title { font-size: 15px; font-weight: 700; margin-bottom: 5px; }
        .mode_sub   { font-size: 13px; color: #9aa0ac; }
        .mode_sub b { color: #ef4444; text-transform: uppercase; }
        .mode_controls { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
        .mode_radio_group { display: flex; gap: 8px; }
        .mode_radio_item { position: relative; }
        .mode_radio_item input[type="radio"] { position: absolute; opacity: 0; width: 0; height: 0; }
        .mode_label { display: inline-block; padding: 10px 18px; cursor: pointer; border-radius: 8px; border: 2px solid rgba(255,255,255,0.14); background: rgba(255,255,255,0.06); font-weight: 700; font-size: 13px; transition: all 0.2s; }
        .mode_radio_item input[type="radio"]:checked + .mode_label { border-color: #8b7cf9; background: rgba(139,124,249,0.18); color: #8b7cf9; }
        .btn_save { padding: 10px 20px; background: #8b7cf9; color: #fff; border: none; border-radius: 8px; font-size: 13px; font-weight: 700; cursor: pointer; transition: all 0.2s; }
        .btn_save:hover { background: #7c6cf0; }

        /* 테이블 */
        .table_topbar { padding: 14px 24px; border-bottom: 1px solid rgba(255,255,255,0.14); font-size: 13px; font-weight: 600; color: #b7bac8; }
        .table_topbar b { color: #8b7cf9; }
        .eq_table { width: 100%; border-collapse: collapse; }
        .eq_table thead tr { background: #fafafa; border-bottom: 1px solid rgba(255,255,255,0.14); }
        .eq_table th { padding: 11px 20px; font-size: 11px; font-weight: 700; color: #9aa0ac; text-transform: uppercase; letter-spacing: 0.05em; text-align: left; }
        .eq_table th.tc { text-align: center; }
        .eq_table td { padding: 15px 20px; border-bottom: 1px solid #f5f5f5; vertical-align: middle; }
        .eq_table tbody tr:last-child td { border-bottom: none; }
        .eq_table tbody tr { transition: background 0.15s; }
        .eq_table tbody tr:hover { background: #fafbff; }
        .eq_table tbody tr.row_expired { background: #fff5f5 !important; border-left: 3px solid #ef4444; }
        .eq_table tbody tr.row_slide   { background: #f5f3ff !important; border-left: 3px solid #8b7cf9; }
        .eq_table tbody tr.row_off     { opacity: 0.45; }

        .popup_thumb    { width: 84px; height: 54px; object-fit: cover; border-radius: 8px; border: 1px solid rgba(255,255,255,0.14); display: block; }
        .popup_thumb_ph { width: 84px; height: 54px; background: rgba(255,255,255,0.06); border-radius: 8px; border: 1px solid rgba(255,255,255,0.14); display: flex; align-items: center; justify-content: center; color: #c4b5fd; font-size: 20px; }

        .popup_name   { font-size: 14px; font-weight: 700; color: #f1f2f5; margin-bottom: 4px; display: flex; align-items: center; gap: 7px; }
        .popup_period { font-size: 12px; color: #9aa0ac; }
        .badge_expired_inline { background: #fee2e2; color: #dc2626; font-size: 10px; font-weight: 700; padding: 2px 7px; border-radius: 20px; }

        .status_badge { display: inline-block; padding: 4px 13px; border-radius: 20px; font-size: 11px; font-weight: 700; }
        .s_general { background: #d1fae5; color: #059669; }
        .s_slide   { background: rgba(139,124,249,0.18); color: #8b7cf9; }
        .s_off     { background: #f0f0f5; color: #9aa0ac; }
        .s_end     { background: #fee2e2; color: #dc2626; }

        .action_wrap { display: flex; gap: 7px; justify-content: center; }
        .btn_edit { padding: 7px 14px; background: #8b7cf9; color: #fff; border: none; border-radius: 7px; font-size: 12px; font-weight: 700; cursor: pointer; text-decoration: none; transition: background 0.2s; }
        .btn_edit:hover { background: #7c6cf0; }
        .btn_del  { padding: 7px 14px; background: #fee2e2; color: #dc2626; border: none; border-radius: 7px; font-size: 12px; font-weight: 700; cursor: pointer; text-decoration: none; transition: background 0.2s; }
        .btn_del:hover { background: #fecaca; }
        .empty_state { text-align: center; padding: 60px; color: #9aa0ac; font-size: 14px; }

        /* 토스트 */
        .toast { position: fixed; top: 24px; right: 24px; background: transparent; border-left: 4px solid #f59e0b; padding: 16px 20px; border-radius: 10px; box-shadow: 0 8px 24px rgba(0,0,0,0.12); z-index: 9999; min-width: 300px; max-width: 400px; animation: toast_in 0.3s ease; }
        .toast_hd { display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px; }
        .toast_title { font-size: 13px; font-weight: 700; }
        .toast_close { background: none; border: none; font-size: 18px; cursor: pointer; color: #9aa0ac; line-height: 1; }
        .toast_body { font-size: 12px; color: #b7bac8; line-height: 1.6; }
        .toast_list { margin: 6px 0 0 16px; }
        .toast_list li { margin: 3px 0; }
        @keyframes toast_in  { from { transform: translateX(420px); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
        @keyframes toast_out { from { transform: translateX(0); opacity: 1; } to { transform: translateX(420px); opacity: 0; } }
        .toast.hiding { animation: toast_out 0.3s ease forwards; }
    </style>
</head>
<body>
<div id="admin_wrapper">
    <?php include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/aside.php'); ?>

    <main class="content_area">

        <div class="page_header">
            <h2 class="page_title">팝업 관리</h2>
            <a href="./popup_form.php" class="btn_primary">+ 새 팝업 등록</a>
        </div>

        <!-- 운영 모드 -->
        <div class="card" style="border: 2px solid #8b7cf9;">
            <div class="card_body">
                <form method="post">
                    <input type="hidden" name="update_pop_mode" value="1">
                    <div class="mode_row">
                        <div>
                            <div class="mode_title">사이트 전체 팝업 운영 모드</div>
                            <div class="mode_sub">현재 적용 모드: <b><?= htmlspecialchars($current_mode) ?></b></div>
                        </div>
                        <div class="mode_controls">
                            <div class="mode_radio_group">
                                <div class="mode_radio_item">
                                    <input type="radio" name="pop_mode" id="opt_gen" value="general" <?= ($current_mode == 'general') ? 'checked' : '' ?>>
                                    <label for="opt_gen" class="mode_label">일반 개별형</label>
                                </div>
                                <div class="mode_radio_item">
                                    <input type="radio" name="pop_mode" id="opt_slide" value="slide" <?= ($current_mode == 'slide') ? 'checked' : '' ?>>
                                    <label for="opt_slide" class="mode_label">슬라이드 통합형</label>
                                </div>
                            </div>
                            <button type="submit" class="btn_save">설정 저장</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- 팝업 목록 -->
        <div class="card" style="padding: 0; overflow: hidden;">
            <div class="table_topbar">
                현재 사이트는 <b><?= ($current_mode == 'slide') ? '슬라이드 통합형' : '일반 개별형' ?></b> 모드로 작동 중입니다.
            </div>
            <?php if (!empty($rows)): ?>
            <table class="eq_table">
                <thead>
                    <tr>
                        <th width="110">미리보기</th>
                        <th>팝업 제목 / 기간</th>
                        <th class="tc" width="140">상태</th>
                        <th class="tc" width="160">관리</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($rows as $row):
                    $img_url   = $row['nw_img'] ? G5_DATA_URL . '/popup/' . $row['nw_img'] : '';
                    $is_on     = (bool)$row['nw_status'];
                    $is_expired = ($row['nw_end_time'] != '0000-00-00 00:00:00' && strtotime($row['nw_end_time']) < time());
                    $row_class = $is_expired ? 'row_expired' : (!$is_on ? 'row_off' : ($current_mode == 'slide' ? 'row_slide' : ''));
                ?>
                <tr class="<?= $row_class ?>">
                    <td>
                        <?php if ($img_url): ?>
                            <img src="<?= htmlspecialchars($img_url) ?>" class="popup_thumb" alt="">
                        <?php else: ?>
                            <div class="popup_thumb_ph">🖼️</div>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="popup_name">
                            <?= htmlspecialchars($row['nw_subject']) ?>
                            <?php if ($is_expired): ?><span class="badge_expired_inline">⏰ 만료</span><?php endif; ?>
                        </div>
                        <div class="popup_period">
                            <?= substr($row['nw_begin_time'], 2, 14) ?> ~ <?= substr($row['nw_end_time'], 2, 14) ?>
                        </div>
                    </td>
                    <td style="text-align:center;">
                        <?php if ($is_expired): ?>
                            <span class="status_badge s_end">기간 만료</span>
                        <?php elseif ($is_on && $current_mode == 'slide'): ?>
                            <span class="status_badge s_slide">슬라이드 활성</span>
                        <?php elseif ($is_on): ?>
                            <span class="status_badge s_general">개별 노출중</span>
                        <?php else: ?>
                            <span class="status_badge s_off">중지</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="action_wrap">
                            <a href="./popup_form.php?nw_id=<?= $row['nw_id'] ?>" class="btn_edit">수정</a>
                            <a href="javascript:void(0);" onclick="if(confirm('정말 삭제하시겠습니까?')) location.href='popup_update.php?mode=d&nw_id=<?= $row['nw_id'] ?>';" class="btn_del">삭제</a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php else: ?>
            <div class="empty_state">등록된 팝업이 없습니다.</div>
            <?php endif; ?>
        </div>

    </main>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const expired = <?= json_encode($expired_popups) ?>;
    if (expired.length > 0) showToast(expired);
});
function showToast(popups) {
    const t = document.createElement('div');
    t.className = 'toast';
    const list = popups.map(p => `<li><strong>${p.nw_subject}</strong> (${p.nw_end_time.substring(0,16)} 종료)</li>`).join('');
    t.innerHTML = `
        <div class="toast_hd">
            <span class="toast_title">⚠️ 만료된 팝업 (${popups.length}개)</span>
            <button class="toast_close" onclick="closeToast(this)">×</button>
        </div>
        <div class="toast_body">
            아래 팝업이 자동으로 비활성화되었습니다:
            <ul class="toast_list">${list}</ul>
        </div>`;
    document.body.appendChild(t);
    setTimeout(() => closeToast(t.querySelector('.toast_close')), 10000);
}
function closeToast(btn) {
    const t = btn.closest('.toast');
    t.classList.add('hiding');
    setTimeout(() => t.remove(), 300);
}
</script>
</body>
</html>