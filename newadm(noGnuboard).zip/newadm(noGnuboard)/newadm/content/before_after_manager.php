<?php
include_once('../_common.php');
include_once('../_auth_check.php');

$ba_table  = 'dm_beforeafter';
$cat_table = 'dm_ba_category';

// ── 테이블 자동 생성 ─────────────────────────────────────
$table_exists = sql_query("SHOW TABLES LIKE '{$ba_table}'");
if (sql_num_rows($table_exists) == 0) {
    sql_query("CREATE TABLE `{$ba_table}` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `title` varchar(255) NOT NULL,
      `image_before` varchar(255) DEFAULT NULL,
      `image_after` varchar(255) DEFAULT NULL,
      `treatment_category` varchar(100) DEFAULT NULL,
      `patient_age` varchar(50) DEFAULT NULL,
      `patient_gender` varchar(10) DEFAULT NULL,
      `treatment_period` varchar(100) DEFAULT NULL,
      `description` text,
      `is_visible` tinyint(1) DEFAULT 1,
      `display_order` int(11) DEFAULT 0,
      `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", false);
}

// 카테고리 테이블
sql_query("CREATE TABLE IF NOT EXISTS `{$cat_table}` (
    `id`         INT(11) NOT NULL AUTO_INCREMENT,
    `name`       VARCHAR(100) NOT NULL DEFAULT '',
    `tab_id`     VARCHAR(50)  NOT NULL DEFAULT '',
    `sort`       INT(11) DEFAULT 0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `tab_id` (`tab_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");


// ── 카테고리 CRUD (AJAX) ──────────────────────────────────
if (isset($_POST['action']) && $_POST['action'] === 'add_cat') {
    $name   = trim($_POST['cat_name'] ?? '');
    $tab_id = preg_replace('/[^a-z0-9_]/', '', strtolower(trim($_POST['cat_tab_id'] ?? '')));
    if ($name && $tab_id) {
        $n = sql_real_escape_string($name);
        $t = sql_real_escape_string($tab_id);
        $s = (int)(sql_fetch("SELECT MAX(sort) ms FROM `{$cat_table}`")['ms'] ?? 0) + 1;
        sql_query("INSERT IGNORE INTO `{$cat_table}` (name,tab_id,sort) VALUES('{$n}','{$t}',{$s})");
    }
    echo json_encode(['success' => true]); exit;
}

if (isset($_POST['action']) && $_POST['action'] === 'del_cat') {
    $id = (int)($_POST['cat_id'] ?? 0);
    if ($id) sql_query("DELETE FROM `{$cat_table}` WHERE id={$id}");
    echo json_encode(['success' => true]); exit;
}

// 카테고리 목록 API
if (isset($_GET['action']) && $_GET['action'] === 'get_cats') {
    $cats = [];
    $r = sql_query("SELECT * FROM `{$cat_table}` ORDER BY sort ASC, id ASC");
    while ($row = sql_fetch_array($r)) $cats[] = $row;
    header('Content-Type: application/json');
    echo json_encode($cats, JSON_UNESCAPED_UNICODE); exit;
}

// ── B/A CRUD ─────────────────────────────────────────────

if (isset($_POST['action']) && $_POST['action'] == 'delete') {
    $id = (int)$_POST['id'];
    $ba = sql_fetch("SELECT image_before, image_after FROM {$ba_table} WHERE id = {$id}");
    foreach (['image_before','image_after'] as $f) {
        if ($ba[$f] && file_exists($_SERVER['DOCUMENT_ROOT'] . $ba[$f])) @unlink($_SERVER['DOCUMENT_ROOT'] . $ba[$f]);
    }
    sql_query("DELETE FROM {$ba_table} WHERE id = {$id}");
    echo json_encode(['success' => true]); exit;
}

if (isset($_POST['action']) && in_array($_POST['action'], ['save','update'])) {
    $id                 = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    $title              = sql_real_escape_string(trim($_POST['title']));
    $treatment_category = sql_real_escape_string(trim($_POST['treatment_category']));
    $patient_age        = sql_real_escape_string(trim($_POST['patient_age']));
    $patient_gender     = sql_real_escape_string(trim($_POST['patient_gender']));
    $treatment_period   = sql_real_escape_string(trim($_POST['treatment_period']));
    $description        = sql_real_escape_string(trim($_POST['description']));
    $is_visible         = isset($_POST['is_visible']) ? 1 : 0;

    $upload_dir = $_SERVER['DOCUMENT_ROOT'] . '/data/beforeafter/';
    if (!is_dir($upload_dir)) @mkdir($upload_dir, 0755, true);

    $image_before_path = '';
    $image_after_path  = '';
    foreach (['before','after'] as $type) {
        $key = 'image_' . $type;
        if (isset($_FILES[$key]) && $_FILES[$key]['error'] == 0) {
            $ext = strtolower(pathinfo($_FILES[$key]['name'], PATHINFO_EXTENSION));
            if (in_array($ext, ['jpg','jpeg','png','gif','webp'])) {
                $new_name = $type . '_' . time() . '_' . uniqid() . '.' . $ext;
                if (move_uploaded_file($_FILES[$key]['tmp_name'], $upload_dir . $new_name)) {
                    if ($id > 0) {
                        $old = sql_fetch("SELECT {$key} FROM {$ba_table} WHERE id = {$id}");
                        if ($old[$key] && file_exists($_SERVER['DOCUMENT_ROOT'] . $old[$key])) @unlink($_SERVER['DOCUMENT_ROOT'] . $old[$key]);
                    }
                    ${'image_'.$type.'_path'} = '/data/beforeafter/' . $new_name;
                }
            }
        }
    }

    if ($id > 0) {
        $sql = "UPDATE {$ba_table} SET title='{$title}', treatment_category='{$treatment_category}', patient_age='{$patient_age}', patient_gender='{$patient_gender}', treatment_period='{$treatment_period}', description='{$description}', is_visible={$is_visible}";
        if ($image_before_path) $sql .= ", image_before='{$image_before_path}'";
        if ($image_after_path)  $sql .= ", image_after='{$image_after_path}'";
        $sql .= " WHERE id={$id}";
    } else {
        $sql = "INSERT INTO {$ba_table} (title,image_before,image_after,treatment_category,patient_age,patient_gender,treatment_period,description,is_visible) VALUES ('{$title}','{$image_before_path}','{$image_after_path}','{$treatment_category}','{$patient_age}','{$patient_gender}','{$treatment_period}','{$description}',{$is_visible})";
    }
    sql_query($sql);
    echo json_encode(['success' => true]); exit;
}

if (isset($_POST['action']) && $_POST['action'] == 'toggle_visible') {
    $id = (int)$_POST['id']; $iv = (int)$_POST['is_visible'];
    sql_query("UPDATE {$ba_table} SET is_visible={$iv} WHERE id={$id}");
    echo json_encode(['success' => true]); exit;
}

$result = sql_query("SELECT * FROM {$ba_table} ORDER BY display_order ASC, id DESC");
$cases = [];
while ($row = sql_fetch_array($result)) $cases[] = $row;

// 카테고리 목록
$categories = [];
$cr = sql_query("SELECT * FROM `{$cat_table}` ORDER BY sort ASC, id ASC");
while ($row = sql_fetch_array($cr)) $categories[] = $row;
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>비포앤애프터 관리</title>
<script src="https://cdn.ckeditor.com/ckeditor5/39.0.1/classic/ckeditor.js"></script>
<style>
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: 'Pretendard', 'Apple SD Gothic Neo', sans-serif; background: rgba(255,255,255,0.06); color: #f1f2f5; }
#admin_wrapper { display: flex; min-height: 100vh; }
.content_area { flex: 1; padding: 40px; overflow-x: hidden; }

.page_header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 28px; }
.page_title { font-size: 22px; font-weight: 700; }
.btn_primary { padding: 11px 22px; background: #8b7cf9; color: #fff; border: none; border-radius: 9px; font-size: 13px; font-weight: 700; cursor: pointer; box-shadow: 0 4px 12px rgba(139, 124, 249,.25); transition: all .2s; }
.btn_primary:hover { background: #7c6cf0; }

/* 카드 그리드 */
.ba_grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px; }

.ba_card { background: transparent; border-radius: 14px; border: 1px solid rgba(255,255,255,0.14); box-shadow: 0 2px 12px rgba(0,0,0,.06); overflow: hidden; display: flex; flex-direction: column; transition: all .2s; }
.ba_card:hover { transform: translateY(-2px); box-shadow: 0 8px 24px rgba(0,0,0,.10); }
.ba_card.hidden_card { opacity: .5; }

/* 이미지 영역 */
.ba_images { display: flex; height: 180px; position: relative; }
.ba_img_wrap { flex: 1; overflow: hidden; position: relative; }
.ba_img_wrap img { width: 100%; height: 100%; object-fit: cover; display: block; }
.ba_img_ph { width: 100%; height: 100%; background: rgba(255,255,255,0.06); display: flex; align-items: center; justify-content: center; color: #c4b5fd; font-size: 13px; font-weight: 600; }
.ba_label { position: absolute; top: 8px; padding: 2px 10px; border-radius: 20px; font-size: 11px; font-weight: 700; color: #fff; z-index: 2; }
.ba_label.before { left: 8px; background: rgba(0,0,0,.5); }
.ba_label.after  { right: 8px; background: #8b7cf9; }
.ba_divider { width: 3px; background: #fff; flex-shrink: 0; z-index: 2; }

/* 카드 바디 */
.ba_body { padding: 16px; flex: 1; display: flex; flex-direction: column; gap: 8px; }
.ba_title { font-size: 14px; font-weight: 700; color: #f1f2f5; line-height: 1.4; }
.ba_meta { font-size: 12px; color: #9aa0ac; display: flex; gap: 8px; flex-wrap: wrap; align-items: center; }
.cat_badge { display: inline-block; padding: 2px 9px; background: rgba(139,124,249,0.18); color: #8b7cf9; border-radius: 20px; font-size: 11px; font-weight: 700; }

/* 카드 푸터 */
.ba_footer { padding: 12px 16px; border-top: 1px solid #f5f5f5; display: flex; align-items: center; justify-content: space-between; }
.switch { position: relative; display: inline-block; width: 44px; height: 22px; }
.switch input { opacity: 0; width: 0; height: 0; }
.slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background: #d1d5e0; border-radius: 11px; transition: .3s; }
.slider:before { position: absolute; content: ''; height: 16px; width: 16px; left: 3px; bottom: 3px; background: #fff; border-radius: 50%; transition: .3s; }
input:checked + .slider { background: #8b7cf9; }
input:checked + .slider:before { transform: translateX(22px); }
.vis_label { font-size: 11px; color: #9aa0ac; margin-left: 6px; }
.ba_actions { display: flex; gap: 6px; }
.btn_edit { padding: 5px 12px; background: rgba(139,124,249,0.18); color: #8b7cf9; border: none; border-radius: 6px; font-size: 12px; font-weight: 700; cursor: pointer; transition: all .15s; }
.btn_edit:hover { background: #8b7cf9; color: #fff; }
.btn_del  { padding: 5px 12px; background: #fee2e2; color: #dc2626; border: none; border-radius: 6px; font-size: 12px; font-weight: 700; cursor: pointer; transition: all .15s; }
.btn_del:hover { background: #dc2626; color: #fff; }

.empty_state { text-align: center; padding: 80px; color: #9aa0ac; font-size: 14px; background: transparent; border-radius: 14px; border: 1px solid rgba(255,255,255,0.14); }

/* 슬라이드 패널 */
.panel_overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,.45); z-index: 9998; }
.panel_overlay.open { display: block; }
.slide_panel { position: fixed; top: 0; right: -760px; width: 720px; max-width: 95vw; height: 100vh; background: transparent; z-index: 9999; box-shadow: -8px 0 32px rgba(0,0,0,.15); overflow-y: auto; transition: right .3s cubic-bezier(.4,0,.2,1); display: flex; flex-direction: column; }
.slide_panel.open { right: 0; }
.panel_head { padding: 24px 28px; border-bottom: 1px solid rgba(255,255,255,0.14); display: flex; align-items: center; justify-content: space-between; position: sticky; top: 0; background: transparent; z-index: 1; }
.panel_title { font-size: 18px; font-weight: 700; }
.btn_close { background: none; border: none; font-size: 22px; cursor: pointer; color: #9aa0ac; line-height: 1; }
.btn_close:hover { color: #f1f2f5; }
.panel_body { padding: 28px; flex: 1; }
.panel_foot { padding: 20px 28px; border-top: 1px solid rgba(255,255,255,0.14); display: flex; gap: 12px; position: sticky; bottom: 0; background: transparent; }
.panel_foot button { flex: 1; height: 46px; border-radius: 9px; font-size: 14px; font-weight: 700; cursor: pointer; border: none; transition: all .2s; }
.btn_cancel { background: rgba(255,255,255,0.06); color: #b7bac8; border: 1px solid rgba(255,255,255,0.14) !important; }
.btn_cancel:hover { background: rgba(255,255,255,0.14); }
.btn_save { background: #8b7cf9; color: #fff; box-shadow: 0 4px 12px rgba(139, 124, 249,.25); }
.btn_save:hover { background: #7c6cf0; }

/* 폼 */
.form_row { margin-bottom: 20px; }
.form_row label { display: block; font-size: 12px; font-weight: 700; color: #9aa0ac; margin-bottom: 7px; }
.form_row input[type=text], .form_row select, .form_row textarea { width: 100%; border: 1px solid rgba(255,255,255,0.14); border-radius: 8px; padding: 10px 14px; font-size: 14px; background: rgba(255,255,255,0.06); font-family: inherit; transition: all .2s; }
.form_row input:focus, .form_row select:focus { outline: none; border-color: #8b7cf9; background: #fff; box-shadow: 0 0 0 3px rgba(139, 124, 249,.1); }
.form_grid2 { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.img_upload_wrap { border: 2px dashed rgba(255,255,255,0.14); border-radius: 10px; height: 160px; display: flex; align-items: center; justify-content: center; cursor: pointer; overflow: hidden; position: relative; transition: border-color .2s; }
.img_upload_wrap:hover { border-color: #8b7cf9; }
.img_upload_wrap img { width: 100%; height: 100%; object-fit: cover; display: none; }
.img_upload_wrap img.has_img { display: block; }
.img_upload_ph { position: absolute; text-align: center; color: #9aa0ac; font-size: 13px; pointer-events: none; }
.img_upload_ph.hidden { display: none; }
.img_upload_ph span { font-size: 32px; display: block; margin-bottom: 6px; }
.radio_row { display: flex; gap: 20px; height: 44px; align-items: center; }
.radio_row label { display: flex; align-items: center; gap: 6px; cursor: pointer; font-size: 14px; color: #f1f2f5; font-weight: 400; }
.radio_row input { width: auto; }
.vis_row { display: flex; align-items: center; gap: 10px; }
.ck-editor__editable { min-height: 200px !important; }

/* 카테고리 관리 */
.cat_manager { background:transparent; border-radius:12px; border:1px solid rgba(255,255,255,0.14); padding:20px 24px; margin-bottom:24px; }
.cat_manager_title { font-size:14px; font-weight:700; color:#f1f2f5; margin-bottom:14px; display:flex; align-items:center; gap:8px; }
.cat_list { display:flex; flex-wrap:wrap; gap:8px; margin-bottom:14px; }
.cat_tag { display:inline-flex; align-items:center; gap:6px; background:rgba(139,124,249,0.18); color:#8b7cf9; border-radius:20px; padding:5px 14px; font-size:12px; font-weight:700; }
.cat_tag_del { background:none; border:none; color:#8b7cf9; cursor:pointer; font-size:14px; line-height:1; opacity:.6; }
.cat_tag_del:hover { opacity:1; }
.cat_add_row { display:flex; gap:8px; }
.cat_add_row input { border:1px solid rgba(255,255,255,0.14); border-radius:8px; padding:8px 12px; font-size:13px; background:rgba(255,255,255,0.06); font-family:inherit; flex:1; }
.cat_add_row input:focus { outline:none; border-color:#8b7cf9; }
.btn_cat_add { padding:8px 16px; background:#8b7cf9; color:#fff; border:none; border-radius:8px; font-size:13px; font-weight:700; cursor:pointer; white-space:nowrap; }
.btn_cat_add:hover { background:#7c6cf0; }
</style>
</head>
<body>
<div id="admin_wrapper">
    <?php include_once('../aside.php'); ?>
    <main class="content_area">

        <div class="page_header">
            <h2 class="page_title">비포앤애프터 관리</h2>
            <button class="btn_primary" onclick="openPanel()">+ 케이스 추가</button>
        </div>

        <!-- 카테고리 관리 -->
        <div class="cat_manager">
            <div class="cat_manager_title">🏷️ 카테고리 관리 <span style="font-size:11px;font-weight:400;color:#9aa0ac;">— 추가한 카테고리는 인덱스 B/A 섹션과 케이스 목록에 자동 반영됩니다</span></div>
            <div class="cat_list" id="catList">
                <?php foreach ($categories as $cat): ?>
                <span class="cat_tag" id="cat-tag-<?= $cat['id'] ?>">
                    <?= htmlspecialchars($cat['name']) ?>
                    <span style="font-size:10px;opacity:.5;margin-left:2px;">#<?= htmlspecialchars($cat['tab_id']) ?></span>
                    <button class="cat_tag_del" onclick="deleteCat(<?= $cat['id'] ?>)">×</button>
                </span>
                <?php endforeach; ?>
            </div>
            <div class="cat_add_row">
                <input type="text" id="newCatName" placeholder="카테고리명 (예: 라미네이트)">
                <input type="text" id="newCatTabId" placeholder="탭 ID (영문, 예: laminate)">
                <button class="btn_cat_add" onclick="addCat()">+ 추가</button>
            </div>
        </div>

        <?php if (!empty($cases)): ?>
        <div class="ba_grid">
        <?php foreach ($cases as $ba): ?>
            <div class="ba_card <?= $ba['is_visible'] ? '' : 'hidden_card' ?>" id="card-<?= $ba['id'] ?>">
                <!-- 이미지 -->
                <div class="ba_images">
                    <div class="ba_img_wrap">
                        <span class="ba_label before">Before</span>
                        <?php if ($ba['image_before']): ?>
                            <img src="<?= htmlspecialchars($ba['image_before']) ?>" alt="Before">
                        <?php else: ?>
                            <div class="ba_img_ph">Before<br>없음</div>
                        <?php endif; ?>
                    </div>
                    <div class="ba_divider"></div>
                    <div class="ba_img_wrap">
                        <span class="ba_label after">After</span>
                        <?php if ($ba['image_after']): ?>
                            <img src="<?= htmlspecialchars($ba['image_after']) ?>" alt="After">
                        <?php else: ?>
                            <div class="ba_img_ph">After<br>없음</div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- 바디 -->
                <div class="ba_body">
                    <?php if ($ba['treatment_category']): ?>
                        <span class="cat_badge"><?= htmlspecialchars($ba['treatment_category']) ?></span>
                    <?php endif; ?>
                    <p class="ba_title"><?= htmlspecialchars($ba['title']) ?></p>
                    <div class="ba_meta">
                        <?php if ($ba['patient_age']): ?><span><?= htmlspecialchars($ba['patient_age']) ?></span><?php endif; ?>
                        <?php if ($ba['patient_gender']): ?><span><?= htmlspecialchars($ba['patient_gender']) ?>성</span><?php endif; ?>
                        <?php if ($ba['treatment_period']): ?><span>📅 <?= htmlspecialchars($ba['treatment_period']) ?></span><?php endif; ?>
                        <span style="margin-left:auto;"><?= substr($ba['created_at'],0,10) ?></span>
                    </div>
                </div>

                <!-- 푸터: 노출 토글 + 수정/삭제 -->
                <div class="ba_footer">
                    <div style="display:flex;align-items:center;">
                        <label class="switch">
                            <input type="checkbox" <?= $ba['is_visible'] ? 'checked' : '' ?>
                                onchange="toggleVisible(<?= $ba['id'] ?>, this)">
                            <span class="slider"></span>
                        </label>
                        <span class="vis_label" id="vis-label-<?= $ba['id'] ?>"><?= $ba['is_visible'] ? '노출중' : '숨김' ?></span>
                    </div>
                    <div class="ba_actions">
                        <button class="btn_edit" onclick="editCase(<?= $ba['id'] ?>)">수정</button>
                        <button class="btn_del"  onclick="deleteCase(<?= $ba['id'] ?>)">삭제</button>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
        </div>
        <?php else: ?>
            <div class="empty_state">등록된 비포앤애프터 케이스가 없습니다.</div>
        <?php endif; ?>

    </main>
</div>

<!-- 슬라이드 패널 -->
<div class="panel_overlay" id="panelOverlay" onclick="closePanel()"></div>
<div class="slide_panel" id="slidePanel">
    <div class="panel_head">
        <h3 class="panel_title" id="panelTitle">케이스 추가</h3>
        <button class="btn_close" onclick="closePanel()">✕</button>
    </div>
    <div class="panel_body">
        <form id="baForm" enctype="multipart/form-data">
            <input type="hidden" id="baId" name="id">

            <!-- 이미지 -->
            <div class="form_grid2 form_row">
                <div>
                    <label>전 사진 (Before)</label>
                    <div class="img_upload_wrap" onclick="document.getElementById('imgBefore').click()">
                        <img id="prevBefore" src="">
                        <div class="img_upload_ph" id="phBefore"><span>📷</span>Before 업로드</div>
                    </div>
                    <input type="file" id="imgBefore" name="image_before" accept="image/*" onchange="previewImg(this,'Before')">
                </div>
                <div>
                    <label>후 사진 (After)</label>
                    <div class="img_upload_wrap" onclick="document.getElementById('imgAfter').click()">
                        <img id="prevAfter" src="">
                        <div class="img_upload_ph" id="phAfter"><span>📷</span>After 업로드</div>
                    </div>
                    <input type="file" id="imgAfter" name="image_after" accept="image/*" onchange="previewImg(this,'After')">
                </div>
            </div>

            <div class="form_row">
                <label>제목 *</label>
                <input type="text" id="fTitle" name="title" placeholder="예: 30대 남성 임플란트 케이스" required>
            </div>
            <div class="form_row">
                <label>시술 카테고리</label>
                <select id="fCat" name="treatment_category">
                    <option value="">선택</option>
                    <?php foreach ($categories as $cat): ?>
                    <option value="<?= htmlspecialchars($cat['name']) ?>"><?= htmlspecialchars($cat['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form_grid2 form_row">
                <div>
                    <label>환자 나이</label>
                    <input type="text" id="fAge" name="patient_age" placeholder="예: 30대">
                </div>
                <div>
                    <label>환자 성별</label>
                    <div class="radio_row">
                        <label><input type="radio" name="patient_gender" value="남"> 남성</label>
                        <label><input type="radio" name="patient_gender" value="여"> 여성</label>
                    </div>
                </div>
            </div>
            <div class="form_row">
                <label>시술 기간</label>
                <input type="text" id="fPeriod" name="treatment_period" placeholder="예: 3개월">
            </div>
            <div class="form_row">
                <label>상세 설명</label>
                <div id="fDesc"></div>
            </div>
            <div class="form_row">
                <label>노출 여부</label>
                <div class="vis_row">
                    <label class="switch"><input type="checkbox" id="fVisible" name="is_visible" checked><span class="slider"></span></label>
                    <span style="font-size:13px;color:#b7bac8;">노출함</span>
                </div>
            </div>
        </form>
    </div>
    <div class="panel_foot">
        <button class="btn_cancel" onclick="closePanel()">취소</button>
        <button class="btn_save" onclick="submitForm()">저장하기</button>
    </div>
</div>

<script>
const CASES = <?= json_encode(array_column($cases, null, 'id'), JSON_UNESCAPED_UNICODE) ?>;
let editor = null;

// ── 카테고리 관리 ─────────────────────────────────────────
async function addCat() {
    const name  = document.getElementById('newCatName').value.trim();
    const tabId = document.getElementById('newCatTabId').value.trim().toLowerCase().replace(/[^a-z0-9_]/g,'');
    if (!name || !tabId) { alert('카테고리명과 탭 ID를 모두 입력해주세요.'); return; }
    const fd = new FormData();
    fd.append('action','add_cat'); fd.append('cat_name',name); fd.append('cat_tab_id',tabId);
    const res = await fetch('', {method:'POST',body:fd}).then(r=>r.json());
    if (res.success) {
        location.reload();
    }
}

function deleteCat(id) {
    if (!confirm('카테고리를 삭제하시겠습니까?\n해당 카테고리의 케이스들은 카테고리 없음 상태가 됩니다.')) return;
    const fd = new FormData();
    fd.append('action','del_cat'); fd.append('cat_id',id);
    fetch('', {method:'POST',body:fd}).then(r=>r.json()).then(d => {
        if (d.success) {
            const el = document.getElementById('cat-tag-'+id);
            if (el) el.remove();
        }
    });
}

ClassicEditor.create(document.querySelector('#fDesc'), {
    language: 'ko',
    toolbar: ['bold','italic','|','bulletedList','numberedList','|','link','imageUpload','|','undo','redo']
}).then(e => {
    editor = e;
    e.editing.view.change(w => w.setStyle('min-height','200px', e.editing.view.document.getRoot()));
});

function openPanel(id = null) {
    document.getElementById('baForm').reset();
    document.getElementById('baId').value = '';
    resetImg('Before'); resetImg('After');
    if (editor) editor.setData('');

    if (id) {
        document.getElementById('panelTitle').textContent = '케이스 수정';
        const ba = CASES[id];
        if (!ba) return;
        document.getElementById('baId').value   = ba.id;
        document.getElementById('fTitle').value  = ba.title || '';
        document.getElementById('fCat').value    = ba.treatment_category || '';
        document.getElementById('fAge').value    = ba.patient_age || '';
        document.getElementById('fPeriod').value = ba.treatment_period || '';
        if (editor) editor.setData(ba.description || '');
        document.getElementById('fVisible').checked = ba.is_visible == 1;
        if (ba.patient_gender) {
            document.querySelectorAll('[name=patient_gender]').forEach(r => { r.checked = r.value === ba.patient_gender; });
        }
        if (ba.image_before) setImg('Before', ba.image_before);
        if (ba.image_after)  setImg('After',  ba.image_after);
    } else {
        document.getElementById('panelTitle').textContent = '케이스 추가';
    }
    document.getElementById('slidePanel').classList.add('open');
    document.getElementById('panelOverlay').classList.add('open');
}

function closePanel() {
    document.getElementById('slidePanel').classList.remove('open');
    document.getElementById('panelOverlay').classList.remove('open');
}

function editCase(id) { openPanel(id); }

function previewImg(input, type) {
    if (!input.files || !input.files[0]) return;
    const reader = new FileReader();
    reader.onload = e => setImg(type, e.target.result);
    reader.readAsDataURL(input.files[0]);
}
function setImg(type, src) {
    const img = document.getElementById('prev' + type);
    const ph  = document.getElementById('ph' + type);
    img.src = src; img.classList.add('has_img'); ph.classList.add('hidden');
}
function resetImg(type) {
    const img = document.getElementById('prev' + type);
    const ph  = document.getElementById('ph' + type);
    img.src = ''; img.classList.remove('has_img'); ph.classList.remove('hidden');
}

function submitForm() {
    const fd = new FormData(document.getElementById('baForm'));
    const id  = document.getElementById('baId').value;
    fd.append('action', id ? 'update' : 'save');
    if (editor) fd.set('description', editor.getData());
    fetch('', { method: 'POST', body: fd })
        .then(r => r.json())
        .then(d => { if (d.success) location.reload(); });
}

function toggleVisible(id, el) {
    const iv = el.checked ? 1 : 0;
    const card  = document.getElementById('card-' + id);
    const label = document.getElementById('vis-label-' + id);
    const fd = new FormData();
    fd.append('action','toggle_visible'); fd.append('id',id); fd.append('is_visible',iv);
    fetch('', { method: 'POST', body: fd }).then(r => r.json()).then(d => {
        if (d.success) {
            card.classList.toggle('hidden_card', !el.checked);
            label.textContent = el.checked ? '노출중' : '숨김';
        } else { el.checked = !el.checked; }
    });
}

function deleteCase(id) {
    if (!confirm('정말 삭제하시겠습니까?')) return;
    const fd = new FormData(); fd.append('action','delete'); fd.append('id',id);
    fetch('', { method: 'POST', body: fd }).then(r => r.json()).then(d => {
        if (d.success) { const c = document.getElementById('card-'+id); if(c) c.remove(); }
    });
}
</script>
</body>
</html>