<?php
include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/_common.php');
include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/_auth_check.php');

if (!defined('G5_NEWADM_PATH')) define('G5_NEWADM_PATH', $_SERVER['DOCUMENT_ROOT'] . '/newadm');

$nw_id = (int)($_GET['nw_id'] ?? 0);
$mode  = $nw_id ? 'u' : 'w';
$nw    = $nw_id ? sql_fetch(" SELECT * FROM dm_popup WHERE nw_id = '$nw_id' ") : [];

if (!$nw_id) {
    $nw['nw_begin_time'] = date('Y-m-d H:i:s');
    $nw['nw_end_time']   = date('Y-m-d H:i:s', strtotime('+7 days'));
    $nw['nw_width']      = 500;
    $nw['nw_height']     = 500;
    $nw['nw_left']       = 0;
    $nw['nw_top']        = 0;
    $nw['nw_status']     = 1;
    $nw['nw_subject']    = '';
    $nw['nw_img']        = '';
    $nw['nw_link']       = '';
    $nw['nw_target']     = '_blank';
}
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title><?= $nw_id ? '팝업 수정' : '새 팝업 등록' ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Pretendard', 'Apple SD Gothic Neo', sans-serif; background: rgba(255,255,255,0.06); color: #f1f2f5; }
        #admin_wrapper { display: flex; min-height: 100vh; }
        .content_area { flex: 1; padding: 40px; overflow-x: hidden; }

        /* 헤더 */
        .page_header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 28px; }
        .page_title  { font-size: 22px; font-weight: 700; }
        .page_sub    { font-size: 13px; color: #9aa0ac; margin-top: 4px; }

        /* 카드 */
        .card { background: transparent; border-radius: 12px; box-shadow: 0 2px 12px rgba(0,0,0,0.06); border: 1px solid rgba(255,255,255,0.14); padding: 28px; margin-bottom: 20px; }
        .section_title { font-size: 14px; font-weight: 700; color: #8b7cf9; margin-bottom: 20px; padding-bottom: 12px; border-bottom: 1px solid rgba(255,255,255,0.14); display: flex; align-items: center; gap: 7px; }

        /* 폼 레이아웃 */
        .form_grid2 { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
        .form_grid3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 16px; }
        .form_grid4 { display: grid; grid-template-columns: 1fr 1fr 1fr 1fr; gap: 16px; }
        @media (max-width: 700px) { .form_grid2, .form_grid3, .form_grid4 { grid-template-columns: 1fr; } }

        .form_group { display: flex; flex-direction: column; gap: 6px; }
        .form_group label { font-size: 12px; font-weight: 700; color: #9aa0ac; }

        .form_input, .form_select { width: 100%; border: 1px solid rgba(255,255,255,0.14); border-radius: 8px; padding: 10px 14px; font-size: 14px; background: rgba(255,255,255,0.06); font-family: inherit; transition: all 0.2s; color: #f1f2f5; }
        .form_input:focus, .form_select:focus { outline: none; border-color: #8b7cf9; background: transparent; box-shadow: 0 0 0 3px rgba(139, 124, 249,0.1); }
        .form_input::placeholder { color: #c4b5fd; }
        .form_hint { font-size: 11px; color: #9aa0ac; margin-top: 2px; }

        /* 이미지 업로드 */
        .img_current { margin-top: 12px; border-radius: 10px; border: 1px solid rgba(255,255,255,0.14); overflow: hidden; }
        .img_current_label { padding: 10px 14px; background: rgba(255,255,255,0.06); font-size: 12px; font-weight: 700; color: #9aa0ac; border-bottom: 1px solid rgba(255,255,255,0.14); }
        .img_current img { display: block; max-width: 240px; padding: 14px; }

        /* 파일 인풋 */
        input[type="file"].form_input { padding: 8px 14px; cursor: pointer; }

        /* 하단 버튼 */
        .form_footer { display: flex; justify-content: center; gap: 12px; margin-top: 8px; }
        .btn_cancel { padding: 12px 28px; border-radius: 9px; background: rgba(255,255,255,0.06); color: #b7bac8; border: 1px solid rgba(255,255,255,0.14); font-size: 14px; font-weight: 700; cursor: pointer; transition: all 0.2s; }
        .btn_cancel:hover { background: rgba(255,255,255,0.14); }
        .btn_submit { padding: 12px 36px; border-radius: 9px; background: #8b7cf9; color: #fff; border: none; font-size: 14px; font-weight: 700; cursor: pointer; box-shadow: 0 4px 12px rgba(139, 124, 249,0.25); transition: all 0.2s; }
        .btn_submit:hover { background: #7c6cf0; }

        /* flatpickr 커스터마이징 */
        .flatpickr-input { background: rgba(255,255,255,0.06) !important; }
        .flatpickr-calendar { border-radius: 10px !important; box-shadow: 0 8px 24px rgba(0,0,0,0.12) !important; }
    </style>
</head>
<body>
<div id="admin_wrapper">
    <?php include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/aside.php'); ?>

    <main class="content_area">

        <div class="page_header">
            <div>
                <h2 class="page_title"><?= $nw_id ? '팝업 수정' : '새 팝업 등록' ?></h2>
                <div class="page_sub">팝업의 노출 기간, 크기, 위치를 설정합니다.</div>
            </div>
            <a href="./popup_manager.php" style="padding:10px 18px;background:rgba(255,255,255,0.06);color:#b7bac8;border:1px solid rgba(255,255,255,0.14);border-radius:8px;font-size:13px;font-weight:700;text-decoration:none;transition:all 0.2s;" onmouseover="this.style.background='rgba(255,255,255,0.14)'" onmouseout="this.style.background='rgba(255,255,255,0.06)'">← 목록으로</a>
        </div>

        <form action="popup_update.php" method="post" enctype="multipart/form-data">
            <input type="hidden" name="nw_id" value="<?= $nw_id ?>">
            <input type="hidden" name="mode" value="<?= $mode ?>">
            <input type="hidden" name="nw_img_old" value="<?= htmlspecialchars($nw['nw_img']) ?>">

            <!-- 기본 정보 -->
            <div class="card">
                <div class="section_title">📌 기본 정보</div>
                <div class="form_grid2" style="margin-bottom: 16px;">
                    <div class="form_group">
                        <label>팝업 제목 *</label>
                        <input type="text" name="nw_subject" value="<?= htmlspecialchars($nw['nw_subject']) ?>" class="form_input" placeholder="관리용 제목" required>
                    </div>
                    <div class="form_group">
                        <label>노출 여부</label>
                        <select name="nw_status" class="form_select">
                            <option value="1" <?= $nw['nw_status'] == 1 ? 'selected' : '' ?>>✅ 노출함</option>
                            <option value="0" <?= $nw['nw_status'] == 0 ? 'selected' : '' ?>>❌ 중지</option>
                        </select>
                    </div>
                </div>
            </div>

            <!-- 링크 설정 -->
            <div class="card">
                <div class="section_title">🔗 링크 설정</div>
                <div class="form_grid2">
                    <div class="form_group">
                        <label>클릭 시 이동 URL</label>
                        <input type="text" name="nw_link" value="<?= htmlspecialchars($nw['nw_link'] ?? '') ?>" class="form_input" placeholder="https://example.com (선택사항)">
                        <span class="form_hint">비워두면 클릭해도 이동하지 않습니다.</span>
                    </div>
                    <div class="form_group">
                        <label>열기 방식</label>
                        <select name="nw_target" class="form_select">
                            <option value="_blank" <?= (isset($nw['nw_target']) && $nw['nw_target'] == '_blank') ? 'selected' : '' ?>>🔗 새창으로 열기</option>
                            <option value="_self"  <?= (isset($nw['nw_target']) && $nw['nw_target'] == '_self')  ? 'selected' : '' ?>>📄 현재창에서 열기</option>
                        </select>
                    </div>
                </div>
            </div>

            <!-- 노출 기간 -->
            <div class="card">
                <div class="section_title">📅 노출 기간</div>
                <div class="form_grid2">
                    <div class="form_group">
                        <label>시작 일시</label>
                        <input type="text" id="nw_begin_time" name="nw_begin_time" value="<?= htmlspecialchars($nw['nw_begin_time']) ?>" class="form_input" placeholder="YYYY-MM-DD 00:00:00" readonly>
                    </div>
                    <div class="form_group">
                        <label>종료 일시</label>
                        <input type="text" id="nw_end_time" name="nw_end_time" value="<?= htmlspecialchars($nw['nw_end_time']) ?>" class="form_input" placeholder="YYYY-MM-DD 00:00:00" readonly>
                    </div>
                </div>
            </div>

            <!-- 크기 및 위치 -->
            <div class="card">
                <div class="section_title">📐 크기 및 위치 (px)</div>
                <div class="form_grid4">
                    <div class="form_group">
                        <label>가로 크기</label>
                        <input type="number" name="nw_width"  value="<?= (int)$nw['nw_width']  ?>" class="form_input">
                    </div>
                    <div class="form_group">
                        <label>세로 크기</label>
                        <input type="number" name="nw_height" value="<?= (int)$nw['nw_height'] ?>" class="form_input">
                    </div>
                    <div class="form_group">
                        <label>좌측 위치</label>
                        <input type="number" name="nw_left"   value="<?= (int)$nw['nw_left']   ?>" class="form_input">
                    </div>
                    <div class="form_group">
                        <label>상단 위치</label>
                        <input type="number" name="nw_top"    value="<?= (int)$nw['nw_top']    ?>" class="form_input">
                    </div>
                </div>
            </div>

            <!-- 이미지 -->
            <div class="card">
                <div class="section_title">🖼️ 팝업 이미지</div>
                <div class="form_group">
                    <label>이미지 파일</label>
                    <input type="file" name="nw_img_file" class="form_input" accept="image/*">
                </div>
                <?php if ($nw['nw_img']): ?>
                <div class="img_current">
                    <div class="img_current_label">현재 등록된 이미지</div>
                    <img src="<?= G5_DATA_URL ?>/popup/<?= htmlspecialchars($nw['nw_img']) ?>" alt="현재 팝업 이미지" style="max-width:300px;padding:14px;display:block;">
                </div>
                <?php endif; ?>
            </div>

            <!-- 저장 버튼 -->
            <div class="form_footer">
                <button type="button" class="btn_cancel" onclick="history.back();">취소</button>
                <button type="submit" class="btn_submit">저장하기</button>
            </div>

        </form>
    </main>
</div>

<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/ko.js"></script>
<script>
flatpickr("#nw_begin_time", {
    enableTime: true, dateFormat: "Y-m-d H:i:S", time_24hr: true, locale: "ko",
    onChange: function(selectedDates) {
        const endPicker = document.querySelector("#nw_end_time")._flatpickr;
        if (endPicker.selectedDates[0] && selectedDates[0] > endPicker.selectedDates[0]) {
            endPicker.setDate(selectedDates[0]);
        }
    }
});
flatpickr("#nw_end_time", {
    enableTime: true, dateFormat: "Y-m-d H:i:S", time_24hr: true, locale: "ko"
});
</script>
</body>
</html>