<?php
include_once('../_common.php');
include_once('../_auth_check.php');

$parallax_table = 'dm_parallax_items';

// ============================================
// 테이블 자동 생성
// ============================================
$table_exists = sql_query("SHOW TABLES LIKE '{$parallax_table}'");
if (sql_num_rows($table_exists) == 0) {
    $create_sql = "
    CREATE TABLE `{$parallax_table}` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `section_title` varchar(200) DEFAULT '특별한 진료 시스템',
      `number` varchar(10) NOT NULL,
      `title` varchar(200) NOT NULL,
      `description` text NOT NULL,
      `image` varchar(255) DEFAULT NULL,
      `is_visible` tinyint(1) DEFAULT 1,
      `display_order` int(11) DEFAULT 0,
      `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
    ";
    sql_query($create_sql, false);
    
    // 초기 데이터 4개 생성
    $init_data = [
        ['01', '정밀 진단', '최신 장비를 활용한 정확한 진단으로\n환자의 상태를 정밀하게 파악합니다.'],
        ['02', '맞춤 치료', '개인별 특성을 고려한\n최적의 치료 계획을 수립합니다.'],
        ['03', '사후 관리', '치료 후에도 지속적인 관리를 통해\n완벽한 회복을 도와드립니다.'],
        ['04', '안심 케어', '환자의 심리적 안정까지 고려한\n전인적 치료를 제공합니다.']
    ];
    
    foreach ($init_data as $idx => $data) {
        $number = sql_real_escape_string($data[0]);
        $title = sql_real_escape_string($data[1]);
        $description = sql_real_escape_string($data[2]);
        $order = $idx + 1;
        sql_query("INSERT INTO {$parallax_table} (section_title, number, title, description, display_order, is_visible) 
                   VALUES ('특별한 진료 시스템', '{$number}', '{$title}', '{$description}', {$order}, 1)");
    }
    
    $table_created = true;
}

// ============================================
// 섹션 제목 업데이트 - 모든 행 업데이트
// ============================================
if (isset($_POST['action']) && $_POST['action'] == 'update_section_title') {
    $section_title = sql_real_escape_string(trim($_POST['section_title']));
    sql_query("UPDATE {$parallax_table} SET section_title = '{$section_title}' WHERE 1");
    echo json_encode(['success' => true]);
    exit;
}

// ============================================
// 삭제 처리
// ============================================
if (isset($_POST['action']) && $_POST['action'] == 'delete' && isset($_POST['id'])) {
    $id = (int)$_POST['id'];
    $item = sql_fetch("SELECT image FROM {$parallax_table} WHERE id = {$id}");
    
    if ($item['image'] && file_exists($_SERVER['DOCUMENT_ROOT'] . $item['image'])) {
        @unlink($_SERVER['DOCUMENT_ROOT'] . $item['image']);
    }

    sql_query("DELETE FROM {$parallax_table} WHERE id = {$id}");
    echo json_encode(['success' => true]);
    exit;
}

// ============================================
// 저장/수정 처리
// ============================================
if (isset($_POST['action']) && ($_POST['action'] == 'save' || $_POST['action'] == 'update')) {
    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    $number = sql_real_escape_string(trim($_POST['number']));
    $title = sql_real_escape_string(trim($_POST['title']));
    $description = sql_real_escape_string(trim($_POST['description']));
    $is_visible = isset($_POST['is_visible']) ? 1 : 0;

    // 이미지 업로드
    $image_path = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $upload_dir = $_SERVER['DOCUMENT_ROOT'] . '/data/parallax/';
        if (!is_dir($upload_dir)) @mkdir($upload_dir, 0755, true);

        $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) {
            $new_name = 'parallax_' . time() . '_' . uniqid() . '.' . $ext;
            if (move_uploaded_file($_FILES['image']['tmp_name'], $upload_dir . $new_name)) {
                $image_path = '/data/parallax/' . $new_name;
                
                if ($id > 0) {
                    $old = sql_fetch("SELECT image FROM {$parallax_table} WHERE id = {$id}");
                    if ($old['image'] && file_exists($_SERVER['DOCUMENT_ROOT'] . $old['image'])) {
                        @unlink($_SERVER['DOCUMENT_ROOT'] . $old['image']);
                    }
                }
            }
        }
    }

    if ($id > 0) {
        $sql = "UPDATE {$parallax_table} SET 
                number = '{$number}',
                title = '{$title}',
                description = '{$description}',
                is_visible = {$is_visible}";
        if ($image_path) $sql .= ", image = '{$image_path}'";
        $sql .= " WHERE id = {$id}";
    } else {
        // 새로 추가할 때 현재 section_title 값을 가져와서 사용
        $current_section = sql_fetch("SELECT section_title FROM {$parallax_table} LIMIT 1");
        $section_title = $current_section ? sql_real_escape_string($current_section['section_title']) : '특별한 진료 시스템';
        
        $max_order = sql_fetch("SELECT MAX(display_order) as max_order FROM {$parallax_table}");
        $display_order = ($max_order['max_order'] ?? 0) + 1;
        
        $sql = "INSERT INTO {$parallax_table} 
                (section_title, number, title, description, image, is_visible, display_order) 
                VALUES ('{$section_title}', '{$number}', '{$title}', '{$description}', '{$image_path}', {$is_visible}, {$display_order})";
    }

    sql_query($sql);
    echo json_encode(['success' => true]);
    exit;
}

// ============================================
// 노출 토글
// ============================================
if (isset($_POST['action']) && $_POST['action'] == 'toggle_visible') {
    $id = (int)$_POST['id'];
    $is_visible = (int)$_POST['is_visible'];
    sql_query("UPDATE {$parallax_table} SET is_visible = {$is_visible} WHERE id = {$id}");
    echo json_encode(['success' => true]);
    exit;
}

// ============================================
// 순서 변경
// ============================================
if (isset($_POST['action']) && $_POST['action'] == 'update_order') {
    $data = json_decode(file_get_contents('php://input'), true);
    $items = $data['items'];
    foreach ($items as $item) {
        $id = (int)$item['id'];
        $order = (int)$item['order'];
        sql_query("UPDATE {$parallax_table} SET display_order = {$order} WHERE id = {$id}");
    }
    echo json_encode(['success' => true]);
    exit;
}

// ============================================
// 목록 조회
// ============================================
$section_sql = "SELECT section_title FROM {$parallax_table} LIMIT 1";
$section_result = sql_query($section_sql, false);
$section_title = "특별한 진료 시스템";
if ($section_result && sql_num_rows($section_result) > 0) {
    $section_row = sql_fetch_array($section_result);
    if (!empty($section_row['section_title'])) {
        $section_title = $section_row['section_title'];
    }
}

$sql = "SELECT * FROM {$parallax_table} ORDER BY display_order ASC, id DESC";
$result = sql_query($sql);
?>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>패럴렉스 관리</title>
    <link rel="stylesheet" href="/css/setting.css">
    <link rel="stylesheet" href="/css/base_core.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sortablejs@latest/Sortable.min.js"></script>
    <style>
        .parallax-table { width: 100%; border-collapse: collapse; }
        .parallax-table thead { background: rgba(255,255,255,0.06); }
        .parallax-table th { padding: var(--sp-16); font-weight: 700; text-align: left; border-bottom: 2px solid #d1d5e0; }
        .parallax-table td { padding: var(--sp-20); border-bottom: 1px solid rgba(255,255,255,0.06); }
        .parallax-table tbody tr { cursor: move; transition: all 0.2s; }
        .parallax-table tbody tr:hover { background: rgba(255,255,255,0.06); }
        .sortable-ghost { opacity: 0.4; background: rgba(255,255,255,0.06); }
        .parallax-img { 
            width: clamp(80px, 10vw, 120px); 
            height: clamp(50px, 6vw, 75px); 
            object-fit: cover; 
            border-radius: var(--sp-8); 
        }
        .switch { position: relative; display: inline-block; width: 50px; height: 24px; }
        .switch input { opacity: 0; width: 0; height: 0; }
        .slider {
            position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0;
            background-color: #b0b4c4; transition: .4s; border-radius: 12px;
        }
        .slider:before {
            position: absolute; content: ""; height: 18px; width: 18px;
            left: 3px; bottom: 3px; background-color: var(--white);
            transition: .4s; border-radius: 50%;
        }
        input:checked+.slider { background-color: #8b7cf9; }
        input:checked+.slider:before { transform: translateX(26px); }
        .btn-delete {
            background: none; color: var(--danger-color); border: 1px solid var(--danger-color);
            padding: var(--sp-8) var(--sp-16); font-size: 13px; border-radius: var(--sp-4); cursor: pointer;
        }
        .image-upload-wrapper {
            position: relative; width: 100%; max-width: 400px; aspect-ratio: 16/10;
            margin: 0 auto; border: 2px dashed #d1d5e0; border-radius: var(--sp-12);
            overflow: hidden; cursor: pointer;
        }
        .image-upload-wrapper:hover { border-color: #8b7cf9; }
        .image-preview { width: 100%; height: 100%; object-fit: cover; display: none; }
        .image-preview.active { display: block; }
        .image-upload-label {
            position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);
            text-align: center; color: #9aa0ac; pointer-events: none;
        }
        .image-upload-label.hidden { display: none; }
    </style>
</head>
<body>
    <div id="admin_wrapper">
        <?php include_once('../aside.php'); ?>

        <main class="content_area">
            <?php if (isset($table_created)): ?>
                <div class="alert alert-success">✓ 패럴렉스 테이블이 생성되고 초기 데이터가 등록되었습니다!</div>
            <?php endif; ?>

            <div class="d-flex justify-content-between align-items-center u-mb-32">
                <h2 class="admin-card-title">🎨 패럴렉스 관리</h2>
                <button onclick="openModal()" class="u-btn u-btn-main rounded-8 u-py-8 u-px-20">+ 항목 추가</button>
            </div>

            <!-- 섹션 제목 설정 -->
            <section class="card_custom u-mb-24">
                <h3 class="t-fs-20 fw-700 u-mb-16">📝 섹션 제목 설정</h3>
                <form id="sectionTitleForm" class="d-flex u-gap-12 align-items-center">
                    <input type="text" id="sectionTitle" value="<?= htmlspecialchars($section_title) ?>" 
                           class="u-input flex-1" placeholder="예: 특별한 진료 시스템">
                    <button type="submit" class="u-btn u-btn-main rounded-8 u-py-8 u-px-16">저장</button>
                </form>
            </section>

            <!-- 목록 -->
            <section class="card_custom">
                <table class="parallax-table">
                    <thead>
                        <tr>
                            <th style="width: 60px;">순서</th>
                            <th style="width: 80px;">번호</th>
                            <th style="width: 140px;">이미지</th>
                            <th>제목</th>
                            <th>설명</th>
                            <th style="width: 80px;">노출</th>
                            <th style="width: 100px;">관리</th>
                        </tr>
                    </thead>
                    <tbody id="sortableList">
                        <?php
                        $i = 0;
                        while ($item = sql_fetch_array($result)):
                            $i++;
                        ?>
                        <tr data-id="<?= $item['id'] ?>" onclick="editItem(<?= $item['id'] ?>)">
                            <td class="text-center">
                                <span style="cursor: move; color: #9aa0ac;">⋮⋮</span>
                            </td>
                            <td class="text-center"><strong><?= htmlspecialchars($item['number']) ?></strong></td>
                            <td class="text-center">
                                <?php if ($item['image']): ?>
                                    <img src="<?= htmlspecialchars($item['image']) ?>" class="parallax-img" alt="이미지">
                                <?php else: ?>
                                    <div class="parallax-img" style="background: rgba(255,255,255,0.06); display: flex; align-items: center; justify-content: center; color: #9aa0ac; font-size: 12px;">No Image</div>
                                <?php endif; ?>
                            </td>
                            <td><?= htmlspecialchars($item['title']) ?></td>
                            <td class="u-txt-muted" style="font-size: 14px;"><?= nl2br(htmlspecialchars(cut_str($item['description'], 50))) ?></td>
                            <td class="text-center" onclick="event.stopPropagation();">
                                <label class="switch">
                                    <input type="checkbox" <?= $item['is_visible'] ? 'checked' : '' ?>
                                        onchange="toggleVisible(<?= $item['id'] ?>, this.checked)">
                                    <span class="slider"></span>
                                </label>
                            </td>
                            <td class="text-center" onclick="event.stopPropagation();">
                                <button class="u-btn u-btn-danger u-py-4 u-px-12 rounded-4" onclick="deleteItem(<?= $item['id'] ?>)">삭제</button>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                        <?php if ($i == 0): ?>
                        <tr>
                            <td colspan="7" class="text-center u-p-60 u-txt-muted">등록된 항목이 없습니다.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </section>
        </main>
    </div>

    <!-- 모달 -->
    <div class="modal fade" id="itemModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTitle">항목 추가</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="itemForm" enctype="multipart/form-data">
                        <input type="hidden" id="itemId" name="id">
                        
                        <!-- 이미지 업로드 -->
                        <div class="u-input-group">
                            <label class="u-label">이미지 *</label>
                            <div class="image-upload-wrapper" onclick="document.getElementById('imageInput').click()">
                                <img id="imagePreview" class="image-preview" src="" alt="미리보기">
                                <div id="imageLabel" class="image-upload-label">
                                    <div style="font-size: 48px; margin-bottom: 10px;">🖼️</div>
                                    <div>이미지 업로드</div>
                                    <div class="u-txt-muted" style="font-size: 12px; margin-top: 5px;">클릭하여 선택 (권장: 800x500px)</div>
                                </div>
                            </div>
                            <input type="file" id="imageInput" name="image" accept="image/*" onchange="previewImage(this)" style="display: none;">
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="u-input-group">
                                    <label class="u-label">번호 *</label>
                                    <input type="text" id="number" name="number" class="u-input" placeholder="예: 01" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="u-input-group">
                                    <label class="u-label">노출 여부</label>
                                    <div>
                                        <label class="switch" style="vertical-align: middle;">
                                            <input type="checkbox" id="isVisible" name="is_visible" checked>
                                            <span class="slider"></span>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="u-input-group">
                            <label class="u-label">제목 *</label>
                            <input type="text" id="title" name="title" class="u-input" placeholder="예: 정밀 진단" required>
                        </div>

                        <div class="u-input-group">
                            <label class="u-label">설명 *</label>
                            <textarea id="description" name="description" class="u-input" rows="4" 
                                      placeholder="예: 최신 장비를 활용한 정확한 진단으로&#10;환자의 상태를 정밀하게 파악합니다." required></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="u-btn u-btn-secondary" data-bs-dismiss="modal">취소</button>
                    <button type="button" class="u-btn u-btn-primary" onclick="saveItem()">저장</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const modal = new bootstrap.Modal(document.getElementById('itemModal'));
        
        // Sortable 초기화
        const sortable = Sortable.create(document.getElementById('sortableList'), {
            animation: 150,
            onEnd: function() {
                const items = [];
                document.querySelectorAll('#sortableList tr[data-id]').forEach((row, idx) => {
                    items.push({ id: row.dataset.id, order: idx + 1 });
                });
                
                fetch('', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ action: 'update_order', items })
                })
                .then(r => r.json())
                .then(data => {
                    if (data.success) showToast('순서가 저장되었습니다.', 'success');
                });
            }
        });

        function openModal(id = null) {
            document.getElementById('itemForm').reset();
            document.getElementById('itemId').value = '';
            document.getElementById('imagePreview').classList.remove('active');
            document.getElementById('imageLabel').classList.remove('hidden');
            
            if (id) {
                document.getElementById('modalTitle').textContent = '항목 수정';
                loadItemData(id);
            } else {
                document.getElementById('modalTitle').textContent = '항목 추가';
            }
            modal.show();
        }

        function editItem(id) {
            openModal(id);
        }

        function loadItemData(id) {
            <?php
            sql_data_seek($result, 0);
            $items = [];
            while ($row = sql_fetch_array($result)) {
                $items[$row['id']] = $row;
            }
            echo "const items = " . json_encode($items, JSON_UNESCAPED_UNICODE) . ";";
            ?>

            const item = items[id];
            if (!item) return;

            document.getElementById('itemId').value = item.id;
            document.getElementById('number').value = item.number;
            document.getElementById('title').value = item.title;
            document.getElementById('description').value = item.description;
            document.getElementById('isVisible').checked = item.is_visible == 1;

            if (item.image) {
                document.getElementById('imagePreview').src = item.image;
                document.getElementById('imagePreview').classList.add('active');
                document.getElementById('imageLabel').classList.add('hidden');
            }
        }

        function previewImage(input) {
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('imagePreview').src = e.target.result;
                    document.getElementById('imagePreview').classList.add('active');
                    document.getElementById('imageLabel').classList.add('hidden');
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        function saveItem() {
            const formData = new FormData(document.getElementById('itemForm'));
            const id = document.getElementById('itemId').value;
            formData.append('action', id ? 'update' : 'save');

            fetch('', { method: 'POST', body: formData })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        showToast('저장되었습니다!', 'success');
                        setTimeout(() => location.reload(), 1000);
                    }
                });
        }

        function toggleVisible(id, isVisible) {
            const formData = new FormData();
            formData.append('action', 'toggle_visible');
            formData.append('id', id);
            formData.append('is_visible', isVisible ? 1 : 0);
            fetch('', { method: 'POST', body: formData })
                .then(r => r.json())
                .then(data => {
                    if (data.success) showToast('노출 상태가 변경되었습니다.', 'success');
                });
        }

        function deleteItem(id) {
            if (!confirm('정말 삭제하시겠습니까?')) return;
            
            const formData = new FormData();
            formData.append('action', 'delete');
            formData.append('id', id);

            fetch('', { method: 'POST', body: formData })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        showToast('삭제되었습니다.', 'success');
                        setTimeout(() => location.reload(), 1000);
                    }
                });
        }

        // 섹션 제목 저장
        document.getElementById('sectionTitleForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData();
            formData.append('action', 'update_section_title');
            formData.append('section_title', document.getElementById('sectionTitle').value);

            fetch('', { method: 'POST', body: formData })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        showToast('섹션 제목이 저장되었습니다!', 'success');
                    }
                });
        });

        function showToast(message, type = 'default') {
            const toast = document.createElement('div');
            toast.textContent = message;
            toast.style.cssText = 'position:fixed;bottom:40px;left:50%;transform:translateX(-50%);background:rgba(255,255,255,0.95);color:#333;padding:16px 32px;border-radius:12px;font-weight:600;box-shadow:0 4px 12px rgba(0,0,0,0.15);z-index:10000;opacity:0;transition:opacity 0.3s;';
            if (type === 'success') toast.style.borderLeft = '4px solid #10b981';
            
            document.body.appendChild(toast);
            setTimeout(() => toast.style.opacity = '1', 10);
            setTimeout(() => {
                toast.style.opacity = '0';
                setTimeout(() => toast.remove(), 300);
            }, 2500);
        }
    </script>
</body>
</html>