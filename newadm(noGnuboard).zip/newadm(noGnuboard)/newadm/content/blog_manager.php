<?php
include_once('../_common.php');
include_once('../_auth_check.php');

// ── 이미지 업로드 ───────────────────────────────────────────
if (isset($_FILES['gl_image']['name']) && $_FILES['gl_image']['error'] === UPLOAD_ERR_OK) {
    while (ob_get_level()) ob_end_clean();
    $upload_dir = G5_DATA_PATH . '/gallery/' . date('Ym');
    $upload_url = G5_DATA_URL  . '/gallery/' . date('Ym');
    if (!is_dir($upload_dir)) { @mkdir($upload_dir, G5_DIR_PERMISSION, true); @chmod($upload_dir, G5_DIR_PERMISSION); }
    $ext = strtolower(pathinfo($_FILES['gl_image']['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg','jpeg','png','gif','webp'])) {
        header('Content-Type: application/json');
        echo json_encode(['success'=>0,'message'=>'이미지 파일만 업로드 가능합니다.']);
        exit;
    }
    $new_name = time().'_'.md5(uniqid()).'.'.$ext;
    if (move_uploaded_file($_FILES['gl_image']['tmp_name'], $upload_dir.'/'.$new_name)) {
        header('Content-Type: application/json');
        echo json_encode(['success'=>1,'url'=>$upload_url.'/'.$new_name]);
    } else {
        header('Content-Type: application/json');
        echo json_encode(['success'=>0,'message'=>'업로드 실패. 폴더 권한을 확인하세요.']);
    }
    exit;
}

// ── 테이블 생성 ─────────────────────────────────────────────
sql_query("CREATE TABLE IF NOT EXISTS `dm_gallery` (
    `id`            INT(11) NOT NULL AUTO_INCREMENT,
    `title`         VARCHAR(500) NOT NULL DEFAULT '',
    `description`   TEXT,
    `image`         VARCHAR(500) DEFAULT '',
    `link_url`      VARCHAR(1000) DEFAULT '',
    `display_order` INT(11) DEFAULT 0,
    `is_visible`    TINYINT(1) DEFAULT 1,
    `created_at`    DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ── RSS 연동용 컬럼 자동 추가 ───────────────────────────────
// source: manual(수동등록) / rss(자동수집)  |  guid: RSS 글 고유키(중복방지)  |  pub_date: 원문 발행일
$rss_cols = [
    'source'   => "VARCHAR(20) DEFAULT 'manual'",
    'guid'     => "VARCHAR(500) DEFAULT ''",
    'pub_date' => "DATETIME NULL",
];
foreach ($rss_cols as $col => $type) {
    $c = sql_query("SHOW COLUMNS FROM `dm_gallery` LIKE '{$col}'");
    if (sql_num_rows($c) == 0) sql_query("ALTER TABLE `dm_gallery` ADD `{$col}` {$type}");
}

// ── 사이트 컨피그(cf_blog)에서 네이버 블로그 RSS 주소 자동 생성 ──
$dm_conf  = sql_fetch("SELECT cf_blog FROM dm_config WHERE cf_id = 1");
$cf_blog  = $dm_conf['cf_blog'] ?? '';
$blog_id  = '';
$rss_url  = '';
// PC 주소 기준: https://blog.naver.com/{아이디}  (모바일/PostList 형태도 보수적으로 대응)
if (preg_match('#blog\.naver\.com/(?:PostList\.naver\?blogId=)?([a-zA-Z0-9_-]+)#', $cf_blog, $m)) {
    $blog_id = $m[1];
    $rss_url = "https://rss.blog.naver.com/{$blog_id}.xml";
}

// ── 페이지 fetch 헬퍼 ───────────────────────────────────────
// UA를 실제 브라우저로 사용해야 네이버가 정상 페이지(og 태그 포함)를 내려줌
function bm_fetch($url, $referer = '') {
    $ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT        => 10,
            CURLOPT_MAXREDIRS      => 5,
            CURLOPT_USERAGENT      => $ua,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_REFERER        => $referer,
            CURLOPT_HTTPHEADER     => [
                'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language: ko-KR,ko;q=0.9,en;q=0.8',
            ],
        ]);
        $body = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return ($code >= 200 && $code < 400) ? $body : false;
    }
    $ctx = stream_context_create(['http' => ['timeout'=>10,'user_agent'=>$ua]]);
    return @file_get_contents($url, false, $ctx);
}

// 글 본문 페이지에서 대표 이미지(og:image) 추출 — 네이버 RSS description엔 이미지가 없으므로 원문에서 가져옴
function bm_og_image($url) {
    // 모바일 페이지가 og:image 추출에 더 안정적
    $murl = preg_replace('#https?://blog\.naver\.com/#', 'https://m.blog.naver.com/', $url);
    $html = bm_fetch($murl);
    if ($html === false) $html = bm_fetch($url);
    if ($html === false) return '';
    // og:image 메타태그 (속성 순서 양쪽 다 대응)
    if (preg_match('/<meta[^>]*property=["\']og:image["\'][^>]*content=["\']([^"\']+)["\']/i', $html, $m)) {
        return html_entity_decode($m[1]);
    }
    if (preg_match('/<meta[^>]*content=["\']([^"\']+)["\'][^>]*property=["\']og:image["\']/i', $html, $m)) {
        return html_entity_decode($m[1]);
    }
    // 본문 첫 이미지 fallback
    if (preg_match('/<img[^>]+src=["\']([^"\']+(?:postfiles|blogfiles|pstatic)[^"\']*)["\']/i', $html, $m)) {
        return html_entity_decode($m[1]);
    }
    return '';
}

// description에서 텍스트 요약 추출 (태그 제거 후 150자)
function bm_summary($html, $len = 150) {
    $txt = trim(preg_replace('/\s+/', ' ', strip_tags($html)));
    if (mb_strlen($txt) > $len) $txt = mb_substr($txt, 0, $len) . '…';
    return $txt;
}

// ── RSS 동기화 (모드①: 최신글 카드 자동 수집 / force=전체 갱신) ──
if (isset($_POST['action']) && $_POST['action'] === 'sync_rss') {
    header('Content-Type: application/json');
    @set_time_limit(180); // 글마다 본문 fetch하므로 시간 여유
    $force = !empty($_POST['force']); // 전체 새로고침: 기존 행도 다시 갱신
    if (!$rss_url) { echo json_encode(['success'=>0,'message'=>'사이트 설정(cf_blog)에 네이버 블로그 주소가 없습니다.']); exit; }

    $xml_raw = bm_fetch($rss_url);
    if ($xml_raw === false) { echo json_encode(['success'=>0,'message'=>'RSS를 불러오지 못했습니다. 블로그 주소를 확인하세요.']); exit; }

    libxml_use_internal_errors(true);
    $xml = simplexml_load_string($xml_raw);
    if (!$xml || !isset($xml->channel->item)) {
        echo json_encode(['success'=>0,'message'=>'RSS 파싱 실패. 형식을 확인하세요.']); exit;
    }

    $added = 0; $updated = 0; $order = 0;
    foreach ($xml->channel->item as $item) {
        $raw_link = trim((string)$item->link);
        $guid     = trim((string)($item->guid ?: $item->link));
        $guid_esc = sql_real_escape_string($guid);

        $dup = sql_fetch("SELECT id, image FROM dm_gallery WHERE guid='{$guid_esc}' LIMIT 1");

        $title    = sql_real_escape_string(trim((string)$item->title));
        $link     = sql_real_escape_string($raw_link);
        $summary  = sql_real_escape_string(bm_summary((string)$item->description));
        $pub      = (string)$item->pubDate;
        $pub_date = $pub ? date('Y-m-d H:i:s', strtotime($pub)) : date('Y-m-d H:i:s');

        if ($dup) {
            if (!$force) continue; // 일반 동기화: 기존 글은 건너뜀 (속도 최적화)
            // 전체 새로고침: og:image 다시 가져오기 (못 가져오면 기존값 유지)
            $new_img = bm_og_image($raw_link);
            if ($new_img === '') $new_img = $dup['image'];
            $image = sql_real_escape_string($new_img);
            sql_query("UPDATE dm_gallery SET
                title='{$title}', description='{$summary}', image='{$image}',
                link_url='{$link}', pub_date='{$pub_date}'
                WHERE id={$dup['id']}");
            $updated++;
        } else {
            // 네이버 RSS엔 이미지가 없으므로, 글 원문에서 og:image를 가져옴
            $image = sql_real_escape_string(bm_og_image($raw_link));
            sql_query("INSERT INTO dm_gallery SET
                title='{$title}', description='{$summary}', image='{$image}',
                link_url='{$link}', display_order='{$order}', is_visible=1,
                source='rss', guid='{$guid_esc}', pub_date='{$pub_date}', created_at=NOW()");
            $added++;
        }
        $order++;
    }
    echo json_encode(['success'=>1,'added'=>$added,'updated'=>$updated,'blog_id'=>$blog_id]);
    exit;
}

// ── 이미지 일괄 복구 (RSS 범위와 무관하게 DB의 빈 이미지를 link_url로 채움) ──
if (isset($_POST['action']) && $_POST['action'] === 'refill_images') {
    header('Content-Type: application/json');
    @set_time_limit(300);
    // 이미지가 비어있고 링크가 있는 행만 대상
    $rows = sql_query("SELECT id, link_url FROM dm_gallery
                       WHERE (image='' OR image IS NULL) AND link_url<>''");
    $fixed = 0; $failed = 0;
    while ($r = sql_fetch_array($rows)) {
        $img = bm_og_image($r['link_url']);
        if ($img !== '') {
            $img_esc = sql_real_escape_string($img);
            sql_query("UPDATE dm_gallery SET image='{$img_esc}' WHERE id={$r['id']}");
            $fixed++;
        } else {
            $failed++;
        }
    }
    echo json_encode(['success'=>1,'fixed'=>$fixed,'failed'=>$failed]);
    exit;
}

// ── RSS 글 전체삭제 (source='rss' 행 일괄 삭제) ────────────────
// 수동등록(manual)은 건드리지 않음. RSS 이미지는 네이버 원문 URL이라 디스크 파일 없음(행만 삭제).
if (isset($_POST['action']) && $_POST['action'] === 'delete_all_rss') {
    header('Content-Type: application/json');
    $cnt = sql_fetch("SELECT COUNT(*) AS c FROM dm_gallery WHERE source='rss'");
    sql_query("DELETE FROM dm_gallery WHERE source='rss'");
    echo json_encode(['success'=>1,'deleted'=>(int)($cnt['c'] ?? 0)]);
    exit;
}

// ── 칼럼으로 가져오기 (모드②: 본문 전체복사 → nerdDoc_column) ────
if (isset($_POST['action']) && $_POST['action'] === 'import_to_column') {
    header('Content-Type: application/json');
    $gid = (int)($_POST['gallery_id'] ?? 0);
    $g = sql_fetch("SELECT * FROM dm_gallery WHERE id={$gid}");
    if (!$g) { echo json_encode(['success'=>0,'message'=>'대상 글을 찾을 수 없습니다.']); exit; }

    // 네이버 본문은 모바일 주소로 fetch하면 깔끔하게 추출됨
    // link: https://blog.naver.com/{id}/{logNo}  →  https://m.blog.naver.com/{id}/{logNo}
    $link = $g['link_url'];
    $mlink = preg_replace('#https?://blog\.naver\.com/#', 'https://m.blog.naver.com/', $link);
    $body_html = bm_fetch($mlink);
    $content = '';
    if ($body_html !== false) {
        // 모바일 본문 영역(.se-main-container) 추출 시도
        if (preg_match('/<div[^>]*class="[^"]*se-main-container[^"]*"[^>]*>(.*?)<\/div>\s*<\/div>/is', $body_html, $mm)) {
            $content = $mm[1];
        } elseif (preg_match('/<div[^>]*id="postViewArea"[^>]*>(.*?)<\/div>/is', $body_html, $mm)) {
            $content = $mm[1]; // 구버전 에디터
        }
    }
    // 본문 추출 실패 시 RSS 요약이라도 사용
    if (!trim(strip_tags($content))) $content = '<p>'.htmlspecialchars($g['description']).'</p>';

    // canonical(원문)을 본문 상단에 주석+표기 → 중복 리스크 완화 안내
    $origin_note = '<p style="font-size:13px;color:#888;">※ 본 글의 원문: <a href="'.htmlspecialchars($link).'" target="_blank" rel="noopener">네이버 블로그에서 보기</a></p>';
    $final_content = $origin_note . $content;

    // nerdDoc_column 테이블 존재 확인
    $col_chk = sql_query("SHOW TABLES LIKE 'nerdDoc_column'", false);
    if (!$col_chk || sql_num_rows($col_chk) == 0) {
        echo json_encode(['success'=>0,'message'=>'nerdDoc_column 테이블이 없습니다. 칼럼 기능을 먼저 설정하세요.']); exit;
    }
    $c_title   = sql_real_escape_string($g['title']);
    $c_content = sql_real_escape_string($final_content);
    // 기본 카테고리(첫번째) 사용
    $cat = sql_fetch("SELECT id FROM nerdDoc_column_cat ORDER BY id ASC LIMIT 1");
    $cat_id = $cat ? (int)$cat['id'] : 0;

    $ok = sql_query("INSERT INTO nerdDoc_column SET
        cat_id={$cat_id}, title='{$c_title}', content='{$c_content}',
        editor_type='html', created_at=NOW()");
    if ($ok) echo json_encode(['success'=>1,'message'=>'칼럼으로 가져왔습니다. 칼럼 관리에서 본문을 다듬어 주세요.']);
    else     echo json_encode(['success'=>0,'message'=>'칼럼 저장 실패: '.sql_error()]);
    exit;
}

// ── 삭제 ────────────────────────────────────────────────────
if (isset($_GET['delete_id'])) {
    sql_query("DELETE FROM dm_gallery WHERE id=" . (int)$_GET['delete_id']);
    alert_toast('삭제되었습니다.', './blog_manager.php');
}

// ── 노출 토글 ───────────────────────────────────────────────
if (isset($_GET['toggle_id'])) {
    $tid = (int)$_GET['toggle_id'];
    $cur = sql_fetch("SELECT is_visible FROM dm_gallery WHERE id={$tid}");
    $new = $cur['is_visible'] ? 0 : 1;
    sql_query("UPDATE dm_gallery SET is_visible={$new} WHERE id={$tid}");
    header('Content-Type: application/json');
    echo json_encode(['success'=>1,'is_visible'=>$new]);
    exit;
}

// ── 추가 ────────────────────────────────────────────────────
if (isset($_POST['action']) && $_POST['action'] === 'add_gallery') {
    $title         = sql_real_escape_string(trim($_POST['title']));
    $description   = sql_real_escape_string(trim($_POST['description'] ?? ''));
    $image         = sql_real_escape_string(trim($_POST['image'] ?? ''));
    $link_url      = sql_real_escape_string(trim($_POST['link_url'] ?? ''));
    $display_order = (int)($_POST['display_order'] ?? 0);
    $is_visible    = isset($_POST['is_visible']) ? 1 : 0;
    sql_query("INSERT INTO dm_gallery SET
        title='{$title}', description='{$description}', image='{$image}',
        link_url='{$link_url}', display_order='{$display_order}',
        is_visible='{$is_visible}', created_at=NOW()");
    alert_toast('추가되었습니다.', './blog_manager.php', 'success');
}

// ── 수정 ────────────────────────────────────────────────────
if (isset($_POST['action']) && $_POST['action'] === 'update_gallery') {
    $id            = (int)$_POST['id'];
    $title         = sql_real_escape_string(trim($_POST['title']));
    $description   = sql_real_escape_string(trim($_POST['description'] ?? ''));
    $image         = sql_real_escape_string(trim($_POST['image'] ?? ''));
    $link_url      = sql_real_escape_string(trim($_POST['link_url'] ?? ''));
    $display_order = (int)($_POST['display_order'] ?? 0);
    $is_visible    = isset($_POST['is_visible']) ? 1 : 0;
    sql_query("UPDATE dm_gallery SET
        title='{$title}', description='{$description}', image='{$image}',
        link_url='{$link_url}', display_order='{$display_order}',
        is_visible='{$is_visible}'
        WHERE id={$id}");
    alert_toast('수정되었습니다.', './blog_manager.php', 'success');
}

// ── 목록 조회 ────────────────────────────────────────────────
$result   = sql_query("SELECT * FROM dm_gallery ORDER BY display_order ASC, id DESC");
$galleries = [];
while ($row = sql_fetch_array($result)) $galleries[] = $row;
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>갤러리(블로그) 관리</title>
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Pretendard', 'Apple SD Gothic Neo', sans-serif; background: rgba(255,255,255,0.06); color: #f1f2f5; }
        #admin_wrapper { display: flex; min-height: 100vh; }
        .content_area { flex: 1; padding: 40px; overflow-x: hidden; }

        .page_header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 28px; }
        .page_title  { font-size: 22px; font-weight: 700; }
        .btn_add { padding: 11px 22px; background: #8b7cf9; color: #fff; border: none; border-radius: 9px; font-size: 13px; font-weight: 700; cursor: pointer; box-shadow: 0 4px 12px rgba(139, 124, 249,0.25); transition: all 0.2s; }
        .btn_add:hover { background: #7c6cf0; }
        .btn_add:disabled { opacity: 0.6; cursor: not-allowed; }

        .card { background: transparent; border-radius: 12px; box-shadow: 0 2px 12px rgba(0,0,0,0.06); border: 1px solid rgba(255,255,255,0.14); padding: 24px; margin-bottom: 24px; }

        /* 갤러리 그리드 */
        .gl_grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 18px; }
        .gl_card { background: transparent; border-radius: 12px; border: 1px solid rgba(255,255,255,0.14); overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.05); transition: all 0.2s; }
        .gl_card:hover { transform: translateY(-3px); box-shadow: 0 8px 24px rgba(0,0,0,0.1); border-color: #c4b5fd; }
        .gl_card.hidden_card { opacity: 0.5; }
        .gl_thumb { width: 100%; aspect-ratio: 4/3; object-fit: cover; display: block; }
        .gl_thumb_ph { width: 100%; aspect-ratio: 4/3; background: rgba(255,255,255,0.06); display: flex; align-items: center; justify-content: center; color: #9aa0ac; font-size: 13px; }
        .gl_body { padding: 14px 16px; }
        .gl_badge_wrap { display: flex; gap: 6px; margin-bottom: 8px; }
        .gl_badge { display: inline-block; font-size: 11px; font-weight: 700; padding: 3px 10px; border-radius: 20px; }
        .gl_badge.visible   { background: #dcfce7; color: #166534; }
        .gl_badge.invisible { background: #fee2e2; color: #991b1b; }
        .gl_title { font-size: 15px; font-weight: 700; color: #f1f2f5; margin-bottom: 5px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .gl_desc  { font-size: 12px; color: #9aa0ac; line-height: 1.5; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; margin-bottom: 8px; }
        .gl_link  { font-size: 11px; color: #8b7cf9; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-bottom: 12px; display: block; }
        .gl_actions { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 6px; }
        .btn_gl { padding: 7px 4px; border: none; border-radius: 7px; font-size: 11px; font-weight: 700; cursor: pointer; transition: all 0.2s; }
        .btn_edit   { background: #8b7cf9; color: #fff; }
        .btn_edit:hover { background: #7c6cf0; }
        .btn_toggle { background: #fef9c3; color: #854d0e; }
        .btn_toggle:hover { background: #fde68a; }
        .btn_del    { background: #fee2e2; color: #dc2626; }
        .btn_del:hover { background: #fecaca; }
        .empty_state { text-align: center; padding: 60px; color: #9aa0ac; font-size: 14px; }

        /* 모달 */
        .modal_overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.55); z-index: 10000; align-items: flex-start; justify-content: center; padding: 40px 20px; overflow-y: auto; }
        .modal_overlay.active { display: flex; }
        .modal_box { background: transparent; border-radius: 14px; width: 100%; max-width: 600px; overflow: hidden; animation: modal_in 0.25s ease; margin: auto; }
        @keyframes modal_in { from { transform: translateY(-20px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
        .modal_hd { padding: 20px 24px; border-bottom: 1px solid rgba(255,255,255,0.14); display: flex; align-items: center; justify-content: space-between; }
        .modal_hd h3 { font-size: 16px; font-weight: 700; }
        .modal_close { background: none; border: none; font-size: 20px; cursor: pointer; color: #9aa0ac; }
        .modal_bd { padding: 24px; display: flex; flex-direction: column; gap: 14px; max-height: 75vh; overflow-y: auto; }
        .form_group label { display: block; font-size: 12px; font-weight: 700; color: #9aa0ac; margin-bottom: 6px; }
        .form_input { width: 100%; border: 1px solid rgba(255,255,255,0.14); border-radius: 8px; padding: 10px 14px; font-size: 14px; background: rgba(255,255,255,0.06); font-family: inherit; transition: all 0.2s; }
        .form_input:focus { outline: none; border-color: #8b7cf9; background: #fff; box-shadow: 0 0 0 3px rgba(139, 124, 249,0.1); }
        textarea.form_input { resize: vertical; min-height: 80px; }
        .form_grid2 { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
        .check_wrap { display: flex; align-items: center; gap: 8px; font-size: 14px; cursor: pointer; }
        .check_wrap input { width: 16px; height: 16px; cursor: pointer; accent-color: #8b7cf9; }

        /* 업로드 존 */
        .upload_zone { border: 2px dashed rgba(255,255,255,0.14); border-radius: 10px; padding: 20px; text-align: center; cursor: pointer; transition: all 0.2s; background: rgba(255,255,255,0.06); position: relative; min-height: 90px; display: flex; flex-direction: column; align-items: center; justify-content: center; }
        .upload_zone:hover, .upload_zone.dragover { border-color: #8b7cf9; background: #ede9fe; }
        .upload_zone input[type="file"] { position: absolute; inset: 0; opacity: 0; cursor: pointer; width: 100%; height: 100%; }
        .upload_zone_icon { font-size: 22px; margin-bottom: 4px; pointer-events: none; }
        .upload_zone_text { font-size: 12px; color: #9aa0ac; pointer-events: none; }
        .upload_zone_text strong { color: #8b7cf9; }
        .upload_preview { width: 100%; height: 100px; object-fit: cover; border-radius: 8px; margin-top: 8px; border: 1px solid rgba(255,255,255,0.14); display: none; }
        .upload_loading { display: none; font-size: 12px; color: #9aa0ac; margin-top: 6px; text-align: center; }

        .modal_ft { padding: 16px 24px; border-top: 1px solid rgba(255,255,255,0.14); display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
        .btn_modal_cancel { padding: 12px; border-radius: 8px; background: rgba(255,255,255,0.06); color: #b7bac8; border: 1px solid rgba(255,255,255,0.14); font-size: 14px; font-weight: 700; cursor: pointer; }
        .btn_modal_submit { padding: 12px; border-radius: 8px; background: #8b7cf9; color: #fff; border: none; font-size: 14px; font-weight: 700; cursor: pointer; }
        .btn_modal_submit:hover { background: #7c6cf0; }

        .stat_bar { display: flex; gap: 16px; margin-bottom: 20px; flex-wrap: wrap; }
        .stat_chip { background: transparent; border: 1px solid rgba(255,255,255,0.14); border-radius: 10px; padding: 10px 18px; font-size: 13px; font-weight: 600; color: #b7bac8; }
        .stat_chip span { font-size: 18px; font-weight: 700; color: #8b7cf9; margin-right: 4px; }
    </style>
</head>
<body>
<div id="admin_wrapper">
    <?php include_once('../aside.php'); ?>
    <main class="content_area">

        <div class="page_header">
            <h2 class="page_title">📸 갤러리(블로그) 관리</h2>
            <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;justify-content:flex-end;">
                <?php if ($rss_url): ?>
                <button onclick="syncRss(false)" id="rssSyncBtn" class="btn_add" style="background:#03c75a;box-shadow:0 4px 12px rgba(3,199,90,0.25);">
                    ⟳ 네이버 블로그 동기화
                </button>
                <button onclick="syncRss(true)" id="rssForceBtn" class="btn_add" style="background:#f59e0b;box-shadow:0 4px 12px rgba(245,158,11,0.25);">
                    ↻ 전체 새로고침
                </button>
                <button onclick="refillImages()" id="refillBtn" class="btn_add" style="background:#0ea5e9;box-shadow:0 4px 12px rgba(14,165,233,0.25);">
                    🖼️ 이미지 일괄 복구
                </button>
                <button onclick="deleteAllRss()" id="delAllRssBtn" class="btn_add" style="background:#dc2626;box-shadow:0 4px 12px rgba(220,38,38,0.25);">
                    🗑️ RSS 글 전체삭제
                </button>
                <?php endif; ?>
                <button onclick="openAddModal()" class="btn_add">+ 새 항목 추가</button>
            </div>
        </div>

        <?php if ($rss_url): ?>
        <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:10px 16px;font-size:13px;color:#166534;margin-bottom:16px;">
            연결된 블로그: <strong><?= htmlspecialchars($blog_id) ?></strong>
            <span style="color:#9aa0ac;">(<?= htmlspecialchars($rss_url) ?>)</span><br>
            <span style="color:#15803d;">· <b>동기화</b>: 새 글만 추가 &nbsp;·&nbsp; <b>전체 새로고침</b>: 최신글 본문·이미지까지 다시 갱신 &nbsp;·&nbsp; <b>이미지 일괄 복구</b>: 이미지 빠진 글을 원문에서 다시 수집 &nbsp;·&nbsp; <b>RSS 글 전체삭제</b>: 자동수집(RSS)된 글 전체 삭제(수동등록 유지)</span>
        </div>
        <?php else: ?>
        <div style="background:#fff7ed;border:1px solid #fed7aa;border-radius:8px;padding:10px 16px;font-size:13px;color:#92400e;margin-bottom:16px;">
            ⚠️ 사이트 설정의 블로그 주소(cf_blog)가 없거나 네이버 블로그 형식이 아닙니다. 기본정보에서 블로그 주소를 등록하면 자동 동기화가 활성화됩니다.
        </div>
        <?php endif; ?>

        <!-- 통계 -->
        <?php
        $total   = count($galleries);
        $visible = count(array_filter($galleries, fn($g) => $g['is_visible']));
        $no_img  = count(array_filter($galleries, fn($g) => empty($g['image'])));
        ?>
        <div class="stat_bar">
            <div class="stat_chip"><span><?= $total ?></span>전체</div>
            <div class="stat_chip"><span><?= $visible ?></span>노출 중</div>
            <div class="stat_chip"><span><?= $total - $visible ?></span>숨김</div>
            <div class="stat_chip"><span><?= $no_img ?></span>이미지 없음</div>
        </div>

        <div class="card">
            <?php if (!empty($galleries)): ?>
            <div class="gl_grid">
                <?php foreach ($galleries as $gl): ?>
                <div class="gl_card <?= $gl['is_visible'] ? '' : 'hidden_card' ?>">
                    <?php if ($gl['image']): ?>
                        <img class="gl_thumb" referrerpolicy="no-referrer" src="<?= htmlspecialchars($gl['image']) ?>" alt="<?= htmlspecialchars($gl['title']) ?>">
                    <?php else: ?>
                        <div class="gl_thumb_ph">이미지 없음</div>
                    <?php endif; ?>
                    <div class="gl_body">
                        <div class="gl_badge_wrap">
                            <span class="gl_badge <?= $gl['is_visible'] ? 'visible' : 'invisible' ?>">
                                <?= $gl['is_visible'] ? '노출' : '숨김' ?>
                            </span>
                            <?php if (($gl['source'] ?? 'manual') === 'rss'): ?>
                            <span class="gl_badge" style="background:#dcfce7;color:#16a34a;">RSS 자동</span>
                            <?php else: ?>
                            <span class="gl_badge" style="background:#ede9fe;color:#7c3aed;">수동</span>
                            <?php endif; ?>
                            <span class="gl_badge" style="background:#f1f5f9;color:#64748b;">순서 <?= (int)$gl['display_order'] ?></span>
                        </div>
                        <div class="gl_title"><?= htmlspecialchars($gl['title']) ?></div>
                        <?php if ($gl['description']): ?>
                        <div class="gl_desc"><?= htmlspecialchars($gl['description']) ?></div>
                        <?php endif; ?>
                        <?php if ($gl['link_url']): ?>
                        <a class="gl_link" href="<?= htmlspecialchars($gl['link_url']) ?>" target="_blank" title="<?= htmlspecialchars($gl['link_url']) ?>">
                            🔗 <?= htmlspecialchars($gl['link_url']) ?>
                        </a>
                        <?php endif; ?>
                        <div class="gl_actions">
                            <button class="btn_gl btn_edit"
                                onclick='openEditModal(<?= json_encode($gl, JSON_HEX_QUOT|JSON_HEX_TAG) ?>)'>수정</button>
                            <button class="btn_gl btn_toggle" id="toggle_btn_<?= $gl['id'] ?>"
                                onclick="toggleVisible(<?= $gl['id'] ?>)">
                                <?= $gl['is_visible'] ? '숨기기' : '노출' ?>
                            </button>
                            <button class="btn_gl btn_del"
                                onclick="if(confirm('정말 삭제하시겠습니까?')) location.href='?delete_id=<?= $gl['id'] ?>'">삭제</button>
                        </div>
                        <?php if ($gl['link_url']): ?>
                        <button class="btn_gl" style="width:100%;margin-top:6px;background:#f1f2f5;color:#fff;"
                            onclick="importToColumn(<?= $gl['id'] ?>, this)">📄 칼럼으로 가져오기 (본문복사)</button>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <div class="empty_state">등록된 항목이 없습니다.</div>
            <?php endif; ?>
        </div>

    </main>
</div>

<!-- 추가 모달 -->
<div class="modal_overlay" id="addModal">
    <div class="modal_box">
        <div class="modal_hd">
            <h3>새 항목 추가</h3>
            <span></span>
        </div>
        <form method="post" id="addForm">
            <input type="hidden" name="action" value="add_gallery">
            <input type="hidden" name="image" id="add_image_val">
            <div class="modal_bd">
                <div class="form_group">
                    <label>제목 *</label>
                    <input type="text" name="title" class="form_input" placeholder="블로그/갤러리 제목" required>
                </div>
                <div class="form_group">
                    <label>설명</label>
                    <textarea name="description" class="form_input" placeholder="간단한 설명"></textarea>
                </div>
                <div class="form_group">
                    <label>이미지</label>
                    <div class="upload_zone"
                        ondragover="event.preventDefault();this.classList.add('dragover')"
                        ondragleave="this.classList.remove('dragover')"
                        ondrop="handleDrop(event,'add_image_val','add_image_preview','add_image_loading')">
                        <input type="file" accept="image/*"
                            onchange="uploadImage(this.files[0],'add_image_val','add_image_preview','add_image_loading')">
                        <div class="upload_zone_icon">🖼️</div>
                        <div class="upload_zone_text">클릭 또는 <strong>드래그</strong> 업로드</div>
                    </div>
                    <div class="upload_loading" id="add_image_loading">⏳ 업로드 중...</div>
                    <img id="add_image_preview" class="upload_preview">
                </div>
                <div class="form_group">
                    <label>링크 URL</label>
                    <input type="url" name="link_url" class="form_input" placeholder="https://blog.naver.com/...">
                </div>
                <div class="form_grid2">
                    <div class="form_group">
                        <label>표시 순서</label>
                        <input type="number" name="display_order" class="form_input" value="0">
                    </div>
                    <div class="form_group" style="display:flex;align-items:flex-end;padding-bottom:2px;">
                        <label class="check_wrap">
                            <input type="checkbox" name="is_visible" checked>
                            바로 노출하기
                        </label>
                    </div>
                </div>
            </div>
            <div class="modal_ft">
                <button type="button" class="btn_modal_cancel" onclick="closeModal('addModal')">취소</button>
                <button type="submit" class="btn_modal_submit">추가하기</button>
            </div>
        </form>
    </div>
</div>

<!-- 수정 모달 -->
<div class="modal_overlay" id="editModal">
    <div class="modal_box">
        <div class="modal_hd">
            <h3>항목 수정</h3>
            <span></span>
        </div>
        <form method="post" id="editForm">
            <input type="hidden" name="action" value="update_gallery">
            <input type="hidden" name="id" id="edit_id">
            <input type="hidden" name="image" id="edit_image_val">
            <div class="modal_bd">
                <div class="form_group">
                    <label>제목 *</label>
                    <input type="text" name="title" id="edit_title" class="form_input" required>
                </div>
                <div class="form_group">
                    <label>설명</label>
                    <textarea name="description" id="edit_description" class="form_input"></textarea>
                </div>
                <div class="form_group">
                    <label>이미지</label>
                    <div class="upload_zone"
                        ondragover="event.preventDefault();this.classList.add('dragover')"
                        ondragleave="this.classList.remove('dragover')"
                        ondrop="handleDrop(event,'edit_image_val','edit_image_preview','edit_image_loading')">
                        <input type="file" accept="image/*"
                            onchange="uploadImage(this.files[0],'edit_image_val','edit_image_preview','edit_image_loading')">
                        <div class="upload_zone_icon">🖼️</div>
                        <div class="upload_zone_text">클릭 또는 <strong>드래그</strong> 교체</div>
                    </div>
                    <div class="upload_loading" id="edit_image_loading">⏳ 업로드 중...</div>
                    <img id="edit_image_preview" class="upload_preview">
                </div>
                <div class="form_group">
                    <label>링크 URL</label>
                    <input type="url" name="link_url" id="edit_link_url" class="form_input">
                </div>
                <div class="form_grid2">
                    <div class="form_group">
                        <label>표시 순서</label>
                        <input type="number" name="display_order" id="edit_display_order" class="form_input">
                    </div>
                    <div class="form_group" style="display:flex;align-items:flex-end;padding-bottom:2px;">
                        <label class="check_wrap">
                            <input type="checkbox" name="is_visible" id="edit_is_visible">
                            노출하기
                        </label>
                    </div>
                </div>
            </div>
            <div class="modal_ft">
                <button type="button" class="btn_modal_cancel" onclick="closeModal('editModal')">취소</button>
                <button type="submit" class="btn_modal_submit">수정 완료</button>
            </div>
        </form>
    </div>
</div>

<script>
// 모달 닫기 (취소 버튼 전용)
function closeModal(id) { document.getElementById(id).classList.remove('active'); }

// 추가 모달
function openAddModal() {
    document.getElementById('addForm').reset();
    document.getElementById('add_image_val').value = '';
    document.getElementById('add_image_preview').src = '';
    document.getElementById('add_image_preview').style.display = 'none';
    document.getElementById('add_image_loading').style.display = 'none';
    document.getElementById('addModal').classList.add('active');
}

// 수정 모달
function openEditModal(data) {
    document.getElementById('edit_id').value            = data.id;
    document.getElementById('edit_title').value         = data.title;
    document.getElementById('edit_description').value   = data.description || '';
    document.getElementById('edit_link_url').value      = data.link_url || '';
    document.getElementById('edit_display_order').value = data.display_order;
    document.getElementById('edit_is_visible').checked  = data.is_visible == 1;
    document.getElementById('edit_image_val').value     = data.image || '';
    document.getElementById('edit_image_loading').style.display = 'none';

    const preview = document.getElementById('edit_image_preview');
    if (data.image) { preview.src = data.image; preview.style.display = 'block'; }
    else            { preview.src = ''; preview.style.display = 'none'; }

    document.getElementById('editModal').classList.add('active');
}

// 이미지 업로드
function uploadImage(file, hiddenId, previewId, loadingId) {
    if (!file) return;
    document.getElementById(loadingId).style.display = 'block';
    document.getElementById(previewId).style.display = 'none';
    const fd = new FormData();
    fd.append('gl_image', file);
    fetch('./blog_manager.php', { method: 'POST', body: fd })
        .then(r => r.json())
        .then(data => {
            document.getElementById(loadingId).style.display = 'none';
            if (data.success) {
                document.getElementById(hiddenId).value      = data.url;
                document.getElementById(previewId).src       = data.url;
                document.getElementById(previewId).style.display = 'block';
            } else {
                alert(data.message || '업로드 실패');
            }
        })
        .catch(() => { document.getElementById(loadingId).style.display = 'none'; alert('업로드 중 오류'); });
}

function handleDrop(event, hiddenId, previewId, loadingId) {
    event.preventDefault();
    event.currentTarget.classList.remove('dragover');
    const file = event.dataTransfer.files[0];
    if (file && file.type.startsWith('image/')) uploadImage(file, hiddenId, previewId, loadingId);
    else alert('이미지 파일만 업로드 가능합니다.');
}

// 노출/숨김 토글 (페이지 새로고침 없이)
function toggleVisible(id) {
    fetch(`./blog_manager.php?toggle_id=${id}`)
        .then(r => r.json())
        .then(data => {
            if (!data.success) return;
            const card = document.getElementById('toggle_btn_' + id).closest('.gl_card');
            const badge = card.querySelector('.gl_badge.visible, .gl_badge.invisible');
            const btn   = document.getElementById('toggle_btn_' + id);
            if (data.is_visible) {
                card.classList.remove('hidden_card');
                badge.className = 'gl_badge visible';
                badge.textContent = '노출';
                btn.textContent = '숨기기';
            } else {
                card.classList.add('hidden_card');
                badge.className = 'gl_badge invisible';
                badge.textContent = '숨김';
                btn.textContent = '노출';
            }
        });
}

// ── RSS 동기화 (모드①) / 전체 새로고침(force=true) ──────────
function syncRss(force) {
    const btn  = force ? document.getElementById('rssForceBtn') : document.getElementById('rssSyncBtn');
    const orig = btn.textContent;
    if (force && !confirm('기존에 수집된 글까지 본문·이미지를 다시 가져옵니다.\n(RSS에 잡히는 최신 글 범위 기준)\n\n계속할까요?')) return;
    btn.disabled = true;
    btn.textContent = force ? '전체 새로고침 중…' : '동기화 중…';
    const fd = new FormData();
    fd.append('action', 'sync_rss');
    if (force) fd.append('force', '1');
    fetch('./blog_manager.php', { method:'POST', body:fd })
        .then(r => r.json())
        .then(d => {
            if (d.success) {
                alert(`완료! 새 글 ${d.added}개 추가, 기존 ${d.updated || 0}개 갱신.`);
                location.reload();
            } else {
                alert('실패: ' + (d.message || '알 수 없는 오류'));
                btn.disabled = false;
                btn.textContent = orig;
            }
        })
        .catch(e => {
            alert('통신 오류: ' + e);
            btn.disabled = false;
            btn.textContent = orig;
        });
}

// ── 이미지 일괄 복구 (RSS 범위 무관, DB의 빈 이미지 채우기) ──
function refillImages() {
    const btn  = document.getElementById('refillBtn');
    const orig = btn.textContent;
    if (!confirm('이미지가 비어있는 글들을 원문(link_url)에서 다시 가져옵니다.\n글 수가 많으면 시간이 걸릴 수 있습니다.\n\n계속할까요?')) return;
    btn.disabled = true;
    btn.textContent = '복구 중…';
    const fd = new FormData();
    fd.append('action', 'refill_images');
    fetch('./blog_manager.php', { method:'POST', body:fd })
        .then(r => r.json())
        .then(d => {
            if (d.success) {
                alert(`이미지 ${d.fixed}개 복구 완료.` + (d.failed ? `\n(${d.failed}개는 원문에서 이미지를 찾지 못함)` : ''));
                location.reload();
            } else {
                alert('실패: ' + (d.message || '알 수 없는 오류'));
                btn.disabled = false;
                btn.textContent = orig;
            }
        })
        .catch(e => {
            alert('통신 오류: ' + e);
            btn.disabled = false;
            btn.textContent = orig;
        });
}

// ── RSS 글 전체삭제 (source='rss' 만, 수동등록 유지) ──────────
function deleteAllRss() {
    const btn  = document.getElementById('delAllRssBtn');
    if (!btn) return;
    const orig = btn.textContent;
    if (!confirm('RSS로 수집된 글(자동수집)을 전부 삭제합니다.\n수동 등록한 글은 유지됩니다.\n\n이 작업은 되돌릴 수 없습니다. 계속할까요?')) return;
    if (!confirm('정말 RSS 글을 전체삭제할까요?\n(다시 동기화하면 새로 가져올 수 있습니다)')) return;
    btn.disabled = true;
    btn.textContent = '삭제 중…';
    const fd = new FormData();
    fd.append('action', 'delete_all_rss');
    fetch('./blog_manager.php', { method:'POST', body:fd })
        .then(r => r.json())
        .then(d => {
            if (d.success) {
                alert(`RSS 글 ${d.deleted}개를 삭제했습니다.`);
                location.reload();
            } else {
                alert('실패: ' + (d.message || '알 수 없는 오류'));
                btn.disabled = false;
                btn.textContent = orig;
            }
        })
        .catch(e => {
            alert('통신 오류: ' + e);
            btn.disabled = false;
            btn.textContent = orig;
        });
}

// ── 칼럼으로 가져오기 (모드②) ───────────────────────
function importToColumn(gid, btnEl) {
    if (!confirm('이 글의 본문을 복사해 칼럼으로 가져옵니다.\n\n⚠️ 주의: 네이버 원문과 동일한 본문이 우리 사이트에 생기면 구글이 중복 콘텐츠로 볼 수 있습니다. 가져온 뒤 칼럼 관리에서 본문을 우리만의 내용으로 다듬어 주세요.\n\n계속할까요?')) return;
    const orig = btnEl.textContent;
    btnEl.disabled = true;
    btnEl.textContent = '가져오는 중…';
    const fd = new FormData();
    fd.append('action', 'import_to_column');
    fd.append('gallery_id', gid);
    fetch('./blog_manager.php', { method:'POST', body:fd })
        .then(r => r.json())
        .then(d => {
            alert(d.message || (d.success ? '완료' : '실패'));
            btnEl.disabled = false;
            btnEl.textContent = orig;
        })
        .catch(e => {
            alert('통신 오류: ' + e);
            btnEl.disabled = false;
            btnEl.textContent = orig;
        });
}
</script>
</body>
</html>