﻿<?php
include_once('../_common.php');
include_once('../_auth_check.php');

/*
 * ============================================================
 * [index.php 적용 방법] 슬로건·설명 고정 텍스트 → DB 연동
 * ============================================================
 * 아래 고정 텍스트 블록을 다음과 같이 교체하세요:
 *
 * <!-- 슬로건 -->
 * <h6 class="u-txt-dark fw-400 u-lh-14 u-ls-10 c-fs-28 u-mb-30">
 *   <?php if (!empty($doc['slogan'])): ?>
 *     <?= $doc['slogan'] ?>
 *   <?php else: ?>
 *     치료 결과 만큼이나<br />
 *     치료 과정에서의
 *     <span class="u-txt-sub fw-bold">통증과 불안을 줄이기 위해</span><br />
 *     <strong class="fw-bold">끝까지 고민합니다.</strong>
 *   <?php endif; ?>
 * </h6>
 *
 * <!-- 설명 -->
 * <p class="fw-lg-600 c-fs-28 u-lh-14 u-ls-10 u-txt-gray-700 c-fs-14-sm fw-400">
 *   <?php if (!empty($doc['description'])): ?>
 *     <?= $doc['description'] ?>
 *   <?php else: ?>
 *     빠른 치료보다 정확한 판단을,<br />
 *     편한 설명과 신중한 선택으로<br class="d-block d-lg-none" />
 *     환자가 안심할 수 있는 진료를 지향합니다.
 *   <?php endif; ?>
 * </p>
 * ============================================================
 */

$doctor_table = 'dm_doctors';

// ============================================================
// 테이블 자동 생성 / 컬럼 체크
// ============================================================
sql_query("CREATE TABLE IF NOT EXISTS `{$doctor_table}` (
    `id`            INT(11) NOT NULL AUTO_INCREMENT,
    `name`          VARCHAR(100) NOT NULL,
    `position`      VARCHAR(100) NOT NULL,
    `image`         VARCHAR(255) DEFAULT NULL COMMENT '메인 이미지',
    `sub_image`     VARCHAR(255) DEFAULT NULL COMMENT '서브 이미지',
    `degree`        LONGTEXT COMMENT '학위 (JSON)',
    `career`        LONGTEXT COMMENT '경력 (JSON)',
    `slogan`        TEXT DEFAULT NULL COMMENT '슬로건 (HTML 허용)',
    `description`   TEXT DEFAULT NULL COMMENT '설명 (HTML 허용)',
    `is_visible`    TINYINT(1) DEFAULT 1,
    `display_order` INT(11) DEFAULT 0,
    `created_at`    DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// 기존 테이블 컬럼 체크
$cols_to_add = array(
    'sub_image'   => "ADD COLUMN `sub_image` VARCHAR(255) DEFAULT NULL COMMENT '서브 이미지' AFTER `image`",
    'degree'      => "ADD COLUMN `degree` LONGTEXT COMMENT '학위 (JSON)' AFTER `sub_image`",
    'career'      => "ADD COLUMN `career` LONGTEXT COMMENT '경력 (JSON)' AFTER `degree`",
    'slogan'      => "ADD COLUMN `slogan` TEXT DEFAULT NULL COMMENT '슬로건' AFTER `career`",
    'description' => "ADD COLUMN `description` TEXT DEFAULT NULL COMMENT '설명' AFTER `slogan`",
);
foreach ($cols_to_add as $col => $sql_part) {
    $chk = sql_query("SHOW COLUMNS FROM `{$doctor_table}` LIKE '{$col}'");
    if (sql_num_rows($chk) == 0) {
        sql_query("ALTER TABLE `{$doctor_table}` {$sql_part}");
    }
}

// ============================================================
// 헬퍼 — 이미지 업로드
// ============================================================
function upload_doctor_image($file_key, $sub_key = null) {
    $dir = $_SERVER['DOCUMENT_ROOT'] . '/data/doctors/';
    if (!is_dir($dir)) mkdir($dir, 0755, true);

    if ($sub_key !== null) {
        // 배열 파일 업로드 (degree_logo[idx])
        if (!isset($_FILES[$file_key]['name'][$sub_key]) || $_FILES[$file_key]['error'][$sub_key] != 0) return '';
        $name = $_FILES[$file_key]['name'][$sub_key];
        $tmp  = $_FILES[$file_key]['tmp_name'][$sub_key];
    } else {
        if (!isset($_FILES[$file_key]) || $_FILES[$file_key]['error'] != 0) return '';
        $name = $_FILES[$file_key]['name'];
        $tmp  = $_FILES[$file_key]['tmp_name'];
    }

    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    if (!in_array($ext, array('jpg','jpeg','png','gif','webp','svg'))) return '';
    $fn = 'doctor_' . time() . '_' . rand(1000,9999) . '.' . $ext;
    if (move_uploaded_file($tmp, $dir . $fn)) return '/data/doctors/' . $fn;
    return '';
}

function delete_file($path) {
    if ($path) { $f = $_SERVER['DOCUMENT_ROOT'] . $path; if (file_exists($f)) @unlink($f); }
}

// ============================================================
// AJAX — 삭제
// ============================================================
if (isset($_POST['action']) && $_POST['action'] === 'delete' && isset($_POST['id'])) {
    $id  = (int)$_POST['id'];
    $row = sql_fetch("SELECT image, sub_image, degree, career, slogan, description FROM `{$doctor_table}` WHERE id = {$id}");
    delete_file($row['image']);
    delete_file($row['sub_image']);
    foreach (array('degree','career') as $type) {
        $items = json_decode($row[$type], true);
        if (is_array($items)) foreach ($items as $item) delete_file($item['logo'] ?? '');
    }
    sql_query("DELETE FROM `{$doctor_table}` WHERE id = {$id}");
    echo json_encode(array('success' => true)); exit;
}

// ============================================================
// AJAX — 노출 토글
// ============================================================
if (isset($_POST['action']) && $_POST['action'] === 'toggle_visible') {
    $id  = (int)$_POST['id'];
    $vis = (int)$_POST['is_visible'];
    sql_query("UPDATE `{$doctor_table}` SET is_visible = {$vis} WHERE id = {$id}");
    echo json_encode(array('success' => true)); exit;
}

// ============================================================
// AJAX — 순서 변경
// ============================================================
if (isset($_POST['action']) && $_POST['action'] === 'update_order') {
    $orders = $_POST['orders'] ?? [];
    foreach ($orders as $oid => $order) {
        sql_query("UPDATE `{$doctor_table}` SET display_order = " . (int)$order . " WHERE id = " . (int)$oid);
    }
    echo json_encode(array('success' => true)); exit;
}

// ============================================================
// AJAX — 저장 / 수정
// ============================================================
if (isset($_POST['action']) && in_array($_POST['action'], array('save','update'))) {
    $id       = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    $name     = sql_real_escape_string(trim($_POST['name']        ?? ''));
    $position = sql_real_escape_string(trim($_POST['position']    ?? ''));
    $slogan   = sql_real_escape_string(trim($_POST['slogan']      ?? ''));
    $desc     = sql_real_escape_string(trim($_POST['description'] ?? ''));
    $visible  = isset($_POST['is_visible']) ? 1 : 0;

    // 메인 이미지
    $image_path = '';
    $new_main = upload_doctor_image('image');
    if ($new_main) {
        if ($id > 0) { $old = sql_fetch("SELECT image FROM `{$doctor_table}` WHERE id={$id}"); delete_file($old['image']); }
        $image_path = $new_main;
    } elseif ($id > 0) {
        $old = sql_fetch("SELECT image FROM `{$doctor_table}` WHERE id={$id}");
        $image_path = $old['image'];
    }

    // 서브 이미지
    $sub_image_path = '';
    $new_sub = upload_doctor_image('sub_image');
    if ($new_sub) {
        if ($id > 0) { $old2 = sql_fetch("SELECT sub_image FROM `{$doctor_table}` WHERE id={$id}"); delete_file($old2['sub_image']); }
        $sub_image_path = $new_sub;
    } elseif ($id > 0) {
        $old2 = sql_fetch("SELECT sub_image FROM `{$doctor_table}` WHERE id={$id}");
        $sub_image_path = $old2['sub_image'];
    }

    // 학위
    $degree_arr = array();
    if (isset($_POST['degree_text']) && is_array($_POST['degree_text'])) {
        foreach ($_POST['degree_text'] as $idx => $text) {
            if (!trim($text)) continue;
            $logo = upload_doctor_image('degree_logo', $idx);
            if (!$logo && isset($_POST['degree_logo_existing'][$idx])) $logo = $_POST['degree_logo_existing'][$idx];
            $degree_arr[] = array('text' => trim($text), 'logo' => $logo);
        }
    }

    // 경력 (Quill 에디터 HTML)
    $career_html = isset($_POST['career_html']) ? $_POST['career_html'] : '';
    $career_html = preg_replace('/<(script|iframe|object|embed|form)[^>]*>.*?<\/>/is', '', $career_html);
    $career_html = preg_replace('/<(script|iframe|object|embed|form)[^>]*\/?>/', '', $career_html);
    $career_html = preg_replace('/on\w+\s*=\s*"[^"]*"/i', '', $career_html);
    $career_html = preg_replace("/on\w+\s*=\s*'[^']*'/i", '', $career_html);

    $img_esc     = sql_real_escape_string($image_path);
    $sub_esc     = sql_real_escape_string($sub_image_path);
    $degree_esc  = sql_real_escape_string(json_encode($degree_arr, JSON_UNESCAPED_UNICODE));
    $career_esc  = sql_real_escape_string($career_html);

    if ($id > 0) {
        sql_query("UPDATE `{$doctor_table}` SET
            name='{$name}', position='{$position}',
            image='{$img_esc}', sub_image='{$sub_esc}',
            degree='{$degree_esc}', career='{$career_esc}',
            slogan='{$slogan}', description='{$desc}',
            is_visible={$visible}
            WHERE id={$id}");
    } else {
        sql_query("INSERT INTO `{$doctor_table}` (name, position, image, sub_image, degree, career, slogan, description, is_visible)
            VALUES ('{$name}','{$position}','{$img_esc}','{$sub_esc}','{$degree_esc}','{$career_esc}','{$slogan}','{$desc}',{$visible})");
    }
    echo json_encode(array('success' => true)); exit;
}

// ============================================================
// 목록 조회
// ============================================================
$result  = sql_query("SELECT * FROM `{$doctor_table}` ORDER BY display_order ASC, id DESC");
$no_img  = "https://upload.wikimedia.org/wikipedia/commons/1/14/No_Image_Available.jpg";

// JS에 넘길 doctors 데이터 미리 구성
$all_doctors = array();
$tmp_result  = sql_query("SELECT * FROM `{$doctor_table}` ORDER BY display_order ASC, id DESC");
while ($r = sql_fetch_array($tmp_result)) $all_doctors[$r['id']] = $r;
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>의료진 관리</title>
<link rel="stylesheet" href="https://cdn.quilljs.com/1.3.7/quill.snow.css">
<style>
@import url('https://cdn.jsdelivr.net/gh/orioncactus/pretendard/dist/web/static/pretendard.css');
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'Pretendard','Apple SD Gothic Neo',sans-serif;background:rgba(255,255,255,0.06);color:#f1f2f5;}
#admin_wrapper{display:flex;min-height:100vh;}
.content_area{flex:1;padding:40px;overflow-x:hidden;}

/* 의료진 카드 그리드 */
.doctor-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:20px;}

.doc-card{background: transparent;border:1px solid rgba(255,255,255,0.14);border-radius:12px;overflow:hidden;transition:.2s;position:relative;box-shadow:0 2px 10px rgba(0,0,0,.05);}
.doc-card:hover{border-color:#a99bfb;box-shadow:0 8px 24px rgba(0,0,0,.1);transform:translateY(-2px);}

.doc-card-thumb{position:relative;height:200px;background:rgba(255,255,255,0.06);overflow:hidden;}
.doc-card-thumb img{width:100%;height:100%;object-fit:cover;display:block;transition:.4s;}
.doc-card-thumb .sub-img{position:absolute;inset:0;opacity:0;transition:.4s;}
.doc-card:hover .doc-card-thumb .sub-img{opacity:1;}
.doc-card:hover .doc-card-thumb .main-img{opacity:0;}

.doc-card-badge{position:absolute;top:8px;left:8px;z-index:5;background:#8b7cf9;color:#fff;border-radius:20px;padding:3px 10px;font-size:11px;font-weight:700;}
.doc-card-badge.off{background:#9aa0ac;}

.doc-vis-toggle{position:absolute;top:10px;right:10px;z-index:5;}

.doc-card-body{padding:16px;}
.doc-name{font-size:16px;font-weight:700;color:#f1f2f5;margin-bottom:4px;}
.doc-position{font-size:13px;color:#8b7cf9;font-weight:600;margin-bottom:12px;}

.doc-info-row{display:flex;gap:6px;margin-bottom:6px;font-size:12px;color:#9aa0ac;flex-wrap:wrap;}
.doc-info-chip{background:rgba(255,255,255,0.06);border-radius:6px;padding:3px 8px;}

.doc-card-btns{display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:6px;margin-top:14px;}

/* 스위치 */
.sw{position:relative;display:inline-block;width:44px;height:22px;}
.sw input{opacity:0;width:0;height:0;}
.sw-slider{position:absolute;cursor:pointer;inset:0;background:rgba(255,255,255,0.14);border-radius:22px;transition:.3s;}
.sw-slider:before{position:absolute;content:"";height:16px;width:16px;left:3px;bottom:3px;background: transparent;border-radius:50%;transition:.3s;}
.sw input:checked + .sw-slider{background:#8b7cf9;}
.sw input:checked + .sw-slider:before{transform:translateX(22px);}

/* 모달 */
.bm-modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:9999;align-items:flex-start;justify-content:center;padding:40px 0;overflow-y:auto;}
.bm-modal.on{display:flex;}
.bm-box{background: transparent;border-radius:14px;width:94%;max-width:900px;overflow:hidden;margin:auto;}
.bm-header{display:flex;align-items:center;justify-content:space-between;padding:20px 28px;border-bottom:1px solid rgba(255,255,255,0.14);}
.bm-header h2{font-size:17px;font-weight:700;}
.bm-close{width:32px;height:32px;border:none;background:rgba(255,255,255,0.06);border-radius:50%;cursor:pointer;font-size:18px;display:flex;align-items:center;justify-content:center;transition:.2s;color:#9aa0ac;}
.bm-close:hover{background:rgba(255,255,255,0.14);color:#f1f2f5;}
.bm-body{padding:28px;max-height:78vh;overflow-y:auto;}
.bm-footer{padding:16px 28px;border-top:1px solid rgba(255,255,255,0.14);display:grid;grid-template-columns:1fr 1fr;gap:10px;}

/* 이미지 업로드 */
.img-upload-box{border:2px dashed rgba(255,255,255,0.14);border-radius:12px;overflow:hidden;cursor:pointer;transition:.2s;position:relative;background:rgba(255,255,255,0.06);text-align:center;}
.img-upload-box:hover{border-color:#8b7cf9;background:rgba(139,124,249,0.18);}
.img-upload-box.has-img{border-color:#8b7cf9;}
.img-upload-box input[type="file"]{display:none;}
.img-upload-preview{width:100%;height:100%;object-fit:cover;display:none;}
.img-upload-preview.on{display:block;}
.img-upload-ph{padding:20px;color:#9aa0ac;}
.img-upload-ph .icon{font-size:32px;margin-bottom:8px;}
.img-upload-ph p{font-size:12px;margin:0;}

/* 2컬럼 이미지 */
.img-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:24px;}
.img-upload-box.main-box{height:220px;}
.img-upload-box.sub-box{height:220px;}

/* 폼 */
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px;}
.form-group{margin-bottom:14px;}
.form-label{display:block;font-weight:700;font-size:12px;color:#9aa0ac;margin-bottom:6px;}
.u-input{width:100%;padding:10px 14px;border:1px solid rgba(255,255,255,0.14);border-radius:8px;font-size:14px;background:rgba(255,255,255,0.06);box-sizing:border-box;font-family:inherit;transition:.2s;color:#f1f2f5;}
.u-input:focus{outline:none;border-color:#8b7cf9;background: transparent;box-shadow:0 0 0 3px rgba(139, 124, 249,.1);}

/* 구분선 */
.section-divider{border:none;border-top:1px solid rgba(255,255,255,0.14);margin:24px 0;}
.section-title{font-size:14px;font-weight:700;color:#8b7cf9;margin-bottom:14px;display:flex;align-items:center;gap:8px;}

/* Repeater */
.repeater{display:flex;flex-direction:column;gap:10px;}
.rep-row{display:flex;gap:10px;align-items:center;background:rgba(255,255,255,0.06);border-radius:10px;padding:12px;}
.rep-logo-box{flex-shrink:0;width:52px;height:52px;border:2px dashed rgba(255,255,255,0.14);border-radius:8px;cursor:pointer;position:relative;background: transparent;overflow:hidden;}
.rep-logo-box:hover{border-color:#8b7cf9;}
.rep-logo-box input[type="file"]{display:none;}
.rep-logo-preview{width:100%;height:100%;object-fit:contain;display:none;}
.rep-logo-preview.on{display:block;}
.rep-logo-ph{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:20px;color:#a99bfb;pointer-events:none;}
.rep-logo-ph.hidden{display:none;}
.rep-text{flex:1;}
.rep-del{flex-shrink:0;width:30px;height:30px;border:none;background:#fee2e2;color:#dc2626;border-radius:8px;cursor:pointer;font-size:16px;display:flex;align-items:center;justify-content:center;}
.rep-del:hover{background:#fca5a5;}
.rep-add-btn{border:2px dashed rgba(255,255,255,0.14);background:transparent;border-radius:10px;padding:10px;width:100%;cursor:pointer;font-size:13px;font-weight:700;color:#9aa0ac;transition:.2s;}
.rep-add-btn:hover{border-color:#8b7cf9;color:#8b7cf9;background:rgba(139,124,249,0.18);}

/* 버튼 */
.btn_primary{padding:11px 22px;background:#8b7cf9;color:#fff;border:none;border-radius:9px;font-size:13px;font-weight:700;cursor:pointer;box-shadow:0 4px 12px rgba(139, 124, 249,.25);transition:all .2s;}
.btn_primary:hover{background:#7c6cf0;}
.btn_neutral{padding:11px 22px;background:rgba(255,255,255,0.06);color:#b7bac8;border:1px solid rgba(255,255,255,0.14);border-radius:9px;font-size:13px;font-weight:600;cursor:pointer;transition:all .2s;}
.btn_neutral:hover{background:rgba(255,255,255,0.14);}
.btn_sm{padding:8px;background:#8b7cf9;color:#fff;border:none;border-radius:7px;font-size:13px;cursor:pointer;transition:.2s;width:100%;}
.btn_sm:hover{background:#7c6cf0;}
.btn_sm_gray{padding:8px;background:rgba(255,255,255,0.06);color:#b7bac8;border:1px solid rgba(255,255,255,0.14);border-radius:7px;font-size:13px;cursor:pointer;transition:.2s;width:100%;}
.btn_sm_gray:hover{background:rgba(255,255,255,0.14);}
.btn_sm_del{padding:8px;background:#fee2e2;color:#dc2626;border:none;border-radius:7px;font-size:13px;cursor:pointer;transition:.2s;width:100%;}
.btn_sm_del:hover{background:#fecaca;}

/* 토스트 */
.toast-msg{position:fixed;bottom:32px;left:50%;transform:translateX(-50%);padding:13px 28px;border-radius:12px;font-size:14px;font-weight:600;box-shadow:0 8px 24px rgba(0,0,0,.15);z-index:10000;opacity:0;transition:opacity .3s;color:#fff;}
.toast-msg.success{background:#10b981;}
.toast-msg.error{background:#ef4444;}
.toast-msg.show{opacity:1;}

/* Quill */
.quill-wrap{border:1px solid rgba(255,255,255,0.14);border-radius:8px;overflow:hidden;transition:.2s;}
.quill-wrap:focus-within{border-color:#8b7cf9;box-shadow:0 0 0 3px rgba(139, 124, 249,.1);}
.quill-wrap .ql-toolbar{border:none;border-bottom:1px solid rgba(255,255,255,0.14);background:rgba(255,255,255,0.06);}
.quill-wrap .ql-container{border:none;font-size:14px;font-family:inherit;}
.quill-wrap .ql-editor{min-height:180px;padding:12px 14px;line-height:1.8;}
.quill-wrap .ql-editor.ql-blank::before{color:#9aa0ac;font-style:normal;}
</style>
</head>
<body>
<div id="admin_wrapper">
<?php include_once('../aside.php'); ?>

<main class="content_area">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:28px;">
    <h2 style="font-size:22px;font-weight:700;">의료진 관리</h2>
    <button onclick="openModal()" class="btn_primary">+ 의료진 추가</button>
  </div>

  <div style="background: transparent;border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,.06);border:1px solid rgba(255,255,255,0.14);padding:24px;">
    <div class="doctor-grid">
    <?php
    $cnt = 0;
    while ($doc = sql_fetch_array($result)):
        $cnt++;
        $degrees = json_decode($doc['degree'], true);
        $careers = json_decode($doc['career'], true);
        $deg_cnt = is_array($degrees) ? count($degrees) : 0;
        $car_cnt = is_array($careers) ? count($careers) : 0;
    ?>
    <div class="doc-card" data-id="<?php echo $doc['id']; ?>">
      <!-- 썸네일 -->
      <div class="doc-card-thumb">
        <img class="main-img" src="<?php echo $doc['image'] ? htmlspecialchars($doc['image']) : $no_img; ?>" onerror="this.src='<?php echo $no_img; ?>'" alt="">
        <?php if ($doc['sub_image']): ?>
        <img class="sub-img" src="<?php echo htmlspecialchars($doc['sub_image']); ?>" onerror="this.src='<?php echo $no_img; ?>'" alt="">
        <?php endif; ?>
        <!-- 노출 배지 -->
        <span class="doc-card-badge <?php echo $doc['is_visible'] ? '' : 'off'; ?>" id="badge-<?php echo $doc['id']; ?>">
          <?php echo $doc['is_visible'] ? '노출' : '비노출'; ?>
        </span>
        <!-- 노출 토글 -->
        <div class="doc-vis-toggle">
          <label class="sw" onclick="event.stopPropagation()">
            <input type="checkbox" <?php echo $doc['is_visible'] ? 'checked' : ''; ?>
                   onchange="toggleVis(<?php echo $doc['id']; ?>, this.checked, this)">
            <span class="sw-slider"></span>
          </label>
        </div>
      </div>

      <!-- 본문 -->
      <div class="doc-card-body">
        <div class="doc-name"><?php echo htmlspecialchars($doc['name']); ?></div>
        <div class="doc-position"><?php echo htmlspecialchars($doc['position']); ?></div>

        <div class="doc-info-row">
          <span class="doc-info-chip">📚 학위 <?php echo $deg_cnt; ?>개</span>
          <span class="doc-info-chip">💼 경력 <?php echo $car_cnt; ?>개</span>
          <?php if ($doc['sub_image']): ?>
          <span class="doc-info-chip">🖼️ 서브이미지 있음</span>
          <?php endif; ?>
        </div>

        <?php
        // 학위 첫 번째 미리보기
        if ($deg_cnt > 0 && !empty($degrees[0]['text'])):
        ?>
        <div style="font-size:12px; color:#9aa0ac; background:rgba(255,255,255,0.06); padding:8px 10px; border-radius:8px; margin-top:8px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
          📖 <?php echo htmlspecialchars($degrees[0]['text']); ?>
        </div>
        <?php endif; ?>

        <div class="doc-card-btns">
          <button onclick="moveOrder(<?php echo $doc['id']; ?>, -1)" class="btn_sm_gray" title="위로">↑</button>
          <button onclick="moveOrder(<?php echo $doc['id']; ?>, 1)"  class="btn_sm_gray" title="아래로">↓</button>
          <button onclick="openModal(<?php echo $doc['id']; ?>)" class="btn_sm">✏️</button>
          <button onclick="delDoctor(<?php echo $doc['id']; ?>)" class="btn_sm_del">🗑️</button>
        </div>
      </div>
    </div>
    <?php endwhile; ?>
    <?php if ($cnt === 0): ?>
    <div style="grid-column:1/-1;text-align:center;padding:60px 20px;color:#9aa0ac;font-size:14px;">
      등록된 의료진이 없습니다.
    </div>
    <?php endif; ?>
    </div>
  </div>
</main>
</div>

<!-- ============ 모달 ============ -->
<div id="doctorModal" class="bm-modal">
  <div class="bm-box">
    <div class="bm-header">
      <h2 id="modalTitle">의료진 추가</h2>
      <button class="bm-close" onclick="closeModal()">✕</button>
    </div>

    <form id="doctorForm" enctype="multipart/form-data">
      <input type="hidden" id="doctorId" name="id">

      <div class="bm-body">
        <!-- 이미지 2컬럼 -->
        <div class="img-grid">
          <!-- 메인 이미지 -->
          <div>
            <div class="form-label">🖼️ 메인 이미지</div>
            <div class="img-upload-box main-box" onclick="document.getElementById('mainImgInput').click()">
              <input type="file" id="mainImgInput" name="image" accept="image/*" onchange="prevImg(this,'mainImgPreview','mainImgPh','mainImgBox')">
              <div class="img-upload-ph" id="mainImgPh">
                <div class="icon">📷</div>
                <p>클릭하여 메인 이미지 선택</p>
                <p style="font-size:11px;color:#b7bac8;margin-top:4px">JPG · PNG · WEBP</p>
              </div>
              <img id="mainImgPreview" class="img-upload-preview" src="" alt="">
            </div>
          </div>
          <!-- 서브 이미지 -->
          <div>
            <div class="form-label">🖼️ 서브 이미지 <small style="font-weight:400;color:#b7bac8">(호버 시 전환)</small></div>
            <div class="img-upload-box sub-box" onclick="document.getElementById('subImgInput').click()">
              <input type="file" id="subImgInput" name="sub_image" accept="image/*" onchange="prevImg(this,'subImgPreview','subImgPh','subImgBox')">
              <div class="img-upload-ph" id="subImgPh">
                <div class="icon">🖼️</div>
                <p>클릭하여 서브 이미지 선택</p>
                <p style="font-size:11px;color:#b7bac8;margin-top:4px">선택사항</p>
              </div>
              <img id="subImgPreview" class="img-upload-preview" src="" alt="">
            </div>
          </div>
        </div>

        <!-- 기본 정보 -->
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">이름 *</label>
            <input type="text" id="docName" name="name" class="u-input" placeholder="예: 홍길동" required>
          </div>
          <div class="form-group">
            <label class="form-label">직위 *</label>
            <input type="text" id="docPosition" name="position" class="u-input" placeholder="예: 원장, 부원장" required>
          </div>
        </div>

        <!-- 노출 여부 -->
        <div class="form-group" style="display:flex; align-items:center; gap:12px;">
          <label class="form-label" style="margin:0">노출 여부</label>
          <label class="sw">
            <input type="checkbox" id="docVisible" name="is_visible" checked>
            <span class="sw-slider"></span>
          </label>
        </div>

        <hr class="section-divider">

        <!-- 슬로건 -->
        <div class="section-title">💬 슬로건</div>
        <div class="form-group">
          <label class="form-label">슬로건 텍스트 <small style="font-weight:400;color:#b7bac8">(HTML 태그 사용 가능 — &lt;br&gt;, &lt;strong&gt;, &lt;span&gt; 등)</small></label>
          <textarea id="docSlogan" name="slogan" class="u-input" rows="4"
            placeholder="예: 치료 결과 만큼이나&#10;치료 과정에서의 &lt;span class=&quot;u-txt-sub fw-bold&quot;&gt;통증과 불안을 줄이기 위해&lt;/span&gt;&lt;br /&gt;&lt;strong class=&quot;fw-bold&quot;&gt;끝까지 고민합니다.&lt;/strong&gt;"
            style="resize:vertical; line-height:1.6"></textarea>
          <p style="font-size:11px;color:#b7bac8;margin-top:4px">* 비워두면 기본 슬로건이 표시됩니다.</p>
        </div>

        <hr class="section-divider">

        <!-- 설명 -->
        <div class="section-title">📝 설명</div>
        <div class="form-group">
          <label class="form-label">설명 텍스트 <small style="font-weight:400;color:#b7bac8">(HTML 태그 사용 가능)</small></label>
          <textarea id="docDescription" name="description" class="u-input" rows="4"
            placeholder="예: 빠른 치료보다 정확한 판단을,&lt;br /&gt;편한 설명과 신중한 선택으로 환자가 안심할 수 있는 진료를 지향합니다."
            style="resize:vertical; line-height:1.6"></textarea>
          <p style="font-size:11px;color:#b7bac8;margin-top:4px">* 비워두면 기본 설명이 표시됩니다.</p>
        </div>

        <hr class="section-divider">
        <div class="section-title">📚 약력 — 학위</div>
        <div class="repeater" id="degreeRepeater"></div>
        <button type="button" class="rep-add-btn u-mt-10" onclick="addRow('degree')">+ 학위 항목 추가</button>

        <hr class="section-divider">

        <!-- 경력 -->
        <div class="section-title">💼 약력 — 경력</div>
        <div class="quill-wrap">
          <div id="careerEditor"></div>
        </div>
        <textarea id="careerHidden" name="career_html" style="display:none"></textarea>
      </div>

      <div class="bm-footer">
        <button type="button" onclick="closeModal()" class="btn_neutral">취소</button>
        <button type="submit" class="btn_primary">저장</button>
      </div>
    </form>
  </div>
</div>

<script>
// ============================================================
// 데이터
// ============================================================
const DOCTORS = <?php echo json_encode($all_doctors, JSON_UNESCAPED_UNICODE); ?>;

// ============================================================
// 토스트
// ============================================================
function showToast(msg, type) {
    type = type || 'success';
    var old = document.querySelector('.toast-msg'); if (old) old.remove();
    var t = document.createElement('div');
    t.className = 'toast-msg ' + type;
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(function(){ t.classList.add('show'); }, 10);
    setTimeout(function(){ t.classList.remove('show'); setTimeout(function(){ t.remove(); }, 300); }, 2500);
}

// ============================================================
// 이미지 미리보기
// ============================================================
function prevImg(input, prevId, phId, boxId) {
    if (!input.files || !input.files[0]) return;
    var r = new FileReader();
    r.onload = function(e) {
        document.getElementById(prevId).src = e.target.result;
        document.getElementById(prevId).classList.add('on');
        document.getElementById(phId).style.display = 'none';
        document.getElementById(boxId).classList.add('has-img');
    };
    r.readAsDataURL(input.files[0]);
}

// ============================================================
// Repeater
// ============================================================
var degreeCount = 0;
var careerCount = 0;

function addRow(type, text, logo) {
    text = text || ''; logo = logo || '';
    var rep   = document.getElementById(type === 'degree' ? 'degreeRepeater' : 'careerRepeater');
    var idx   = type === 'degree' ? degreeCount++ : careerCount++;
    var hasLogo = logo ? true : false;
    var hasDeg  = type === 'degree';

    var row = document.createElement('div');
    row.className = 'rep-row';
    row.dataset.type = type;

    var logoHtml = '';
    if (hasDeg) {
        var logoId  = type + '_logo_prev_' + idx;
        var logoPhId = type + '_logo_ph_' + idx;
        logoHtml = '<div class="rep-logo-box" onclick="this.querySelector(\'input\').click()">' +
            '<input type="file" name="degree_logo[' + idx + ']" accept="image/*" onchange="prevRepLogo(this)">' +
            '<input type="hidden" name="degree_logo_existing[' + idx + ']" value="' + escHtml(logo) + '">' +
            '<img class="rep-logo-preview' + (hasLogo ? ' on' : '') + '" src="' + escHtml(logo) + '" id="' + logoId + '">' +
            '<div class="rep-logo-ph' + (hasLogo ? ' hidden' : '') + '" id="' + logoPhId + '">+</div>' +
            '</div>';
    }

    var nameAttr = hasDeg ? 'degree_text[' + idx + ']' : 'career_text[' + idx + ']';
    var cls      = hasDeg ? 'degree-text-input' : 'career-text-input';

    row.innerHTML = logoHtml +
        '<div class="rep-text">' +
            '<input type="text" name="' + nameAttr + '" class="u-input ' + cls + '" value="' + escHtml(text) + '" placeholder="' + (hasDeg ? '학위 내용 입력' : '경력 내용 입력') + '">' +
        '</div>' +
        '<button type="button" class="rep-del" onclick="this.closest(\'.rep-row\').remove()">−</button>';

    rep.appendChild(row);
}

function prevRepLogo(input) {
    if (!input.files || !input.files[0]) return;
    var r = new FileReader();
    r.onload = function(e) {
        var box = input.closest('.rep-logo-box');
        var prev = box.querySelector('.rep-logo-preview');
        var ph   = box.querySelector('.rep-logo-ph');
        prev.src = e.target.result;
        prev.classList.add('on');
        if (ph) ph.classList.add('hidden');
    };
    r.readAsDataURL(input.files[0]);
}

function escHtml(str) {
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
}

// ============================================================
// 모달 열기/닫기
// ============================================================
function openModal(id) {
    resetModal();
    if (id) {
        document.getElementById('modalTitle').textContent = '의료진 수정';
        loadDoctor(id);
    } else {
        document.getElementById('modalTitle').textContent = '의료진 추가';
        addRow('degree');
    }
    document.getElementById('doctorModal').classList.add('on');
}

function closeModal() {
    document.getElementById('doctorModal').classList.remove('on');
}

function resetModal() {
    document.getElementById('doctorForm').reset();
    document.getElementById('doctorId').value = '';
    document.getElementById('docSlogan').value      = '';
    document.getElementById('docDescription').value = '';

    // 이미지 초기화
    ['mainImgPreview','subImgPreview'].forEach(function(id){
        var el = document.getElementById(id);
        el.src = ''; el.classList.remove('on');
    });
    document.getElementById('mainImgPh').style.display = '';
    document.getElementById('subImgPh').style.display  = '';
    document.getElementById('mainImgBox') && document.getElementById('mainImgBox').classList.remove('has-img');
    document.getElementById('subImgBox')  && document.getElementById('subImgBox').classList.remove('has-img');

    document.getElementById('degreeRepeater').innerHTML = '';
    if (window.careerQuill) window.careerQuill.setContents([]);
    document.getElementById('careerHidden').value = '';
    degreeCount = 0;
}

function loadDoctor(id) {
    var doc = DOCTORS[id];
    if (!doc) return;

    document.getElementById('doctorId').value      = doc.id;
    document.getElementById('docName').value       = doc.name;
    document.getElementById('docPosition').value   = doc.position;
    document.getElementById('docVisible').checked  = doc.is_visible == 1;
    document.getElementById('docSlogan').value      = doc.slogan      || '';
    document.getElementById('docDescription').value = doc.description || '';

    // 메인 이미지
    if (doc.image) {
        document.getElementById('mainImgPreview').src = doc.image;
        document.getElementById('mainImgPreview').classList.add('on');
        document.getElementById('mainImgPh').style.display = 'none';
    }
    // 서브 이미지
    if (doc.sub_image) {
        document.getElementById('subImgPreview').src = doc.sub_image;
        document.getElementById('subImgPreview').classList.add('on');
        document.getElementById('subImgPh').style.display = 'none';
    }

    // 학위
    try {
        var degrees = JSON.parse(doc.degree || '[]');
        if (degrees.length > 0) degrees.forEach(function(d){ addRow('degree', d.text, d.logo); });
        else addRow('degree');
    } catch(e) { addRow('degree'); }

    // 경력 (Quill 에디터)
    if (window.careerQuill) {
        var careerVal = doc.career || '';
        try {
            var parsed = JSON.parse(careerVal);
            if (Array.isArray(parsed)) {
                careerVal = parsed.map(function(item){
                    return '<p>' + (item.text || '') + '</p>';
                }).join('');
            }
        } catch(ex) { /* HTML 문자열 그대로 사용 */ }
        window.careerQuill.root.innerHTML = careerVal || '';
        document.getElementById('careerHidden').value = careerVal || '';
    }
}

// ============================================================
// 폼 제출
// ============================================================
document.getElementById('doctorForm').addEventListener('submit', function(e) {
    e.preventDefault();

    // Quill 경력 내용 동기화
    if (window.careerQuill) {
        document.getElementById('careerHidden').value = window.careerQuill.root.innerHTML;
    }

    // 학위 name 속성 재정렬
    var degIdx = 0;
    document.querySelectorAll('#degreeRepeater .rep-row').forEach(function(row) {
        var ti = row.querySelector('.degree-text-input');  if (ti) ti.name = 'degree_text[' + degIdx + ']';
        var fi = row.querySelector('input[type="file"]');  if (fi) fi.name = 'degree_logo[' + degIdx + ']';
        var ei = row.querySelector('input[type="hidden"]'); if (ei) ei.name = 'degree_logo_existing[' + degIdx + ']';
        degIdx++;
    });

    var fd = new FormData(this);
    var id = document.getElementById('doctorId').value;
    fd.append('action', id ? 'update' : 'save');

    fetch('', { method:'POST', body:fd })
        .then(function(r){ return r.json(); })
        .then(function(d) {
            if (d.success) { showToast('저장되었습니다!', 'success'); setTimeout(function(){ location.reload(); }, 900); }
            else showToast('저장 실패', 'error');
        })
        .catch(function(err){ showToast('오류: ' + err.message, 'error'); });
});

// ============================================================
// 순서 변경
// ============================================================
function moveOrder(id, dir) {
    var cards = Array.from(document.querySelectorAll('.doc-card'));
    var ids = cards.map(function(c) { return parseInt(c.dataset.id); });

    var idx = ids.indexOf(id);
    var newIdx = idx + dir;
    if (newIdx < 0 || newIdx >= ids.length) return;

    var tmp = ids[idx]; ids[idx] = ids[newIdx]; ids[newIdx] = tmp;

    var fd = new FormData();
    fd.append('action', 'update_order');
    ids.forEach(function(cid, i) {
        fd.append('orders[' + cid + ']', i);
    });

    fetch('', { method:'POST', body:fd })
        .then(function(r){ return r.json(); })
        .then(function(d){ if (d.success) location.reload(); });
}

// ============================================================
// 삭제
// ============================================================
function delDoctor(id) {
    if (!confirm('정말 삭제하시겠습니까?')) return;
    var fd = new FormData();
    fd.append('action','delete'); fd.append('id', id);
    fetch('', { method:'POST', body:fd })
        .then(function(r){ return r.json(); })
        .then(function(d){ if (d.success){ showToast('삭제되었습니다.','success'); setTimeout(function(){ location.reload(); },900); } });
}

// ============================================================
// 노출 토글
// ============================================================
function toggleVis(id, checked, input) {
    var fd = new FormData();
    fd.append('action','toggle_visible'); fd.append('id', id); fd.append('is_visible', checked ? 1 : 0);
    fetch('', { method:'POST', body:fd })
        .then(function(r){ return r.json(); })
        .then(function(d) {
            if (d.success) {
                var badge = document.getElementById('badge-' + id);
                if (badge) { badge.textContent = checked ? '노출' : '비노출'; badge.className = 'doc-card-badge' + (checked ? '' : ' off'); }
            } else { input.checked = !checked; }
        });
}

// 모달 바깥 클릭 닫기
// document.getElementById('doctorModal').addEventListener('click', function(e){
//     if (e.target === this) closeModal();
// });
</script>

<script src="https://cdn.quilljs.com/1.3.7/quill.min.js"></script>
<script>
window.careerQuill = new Quill('#careerEditor', {
    theme: 'snow',
    placeholder: '약력 내용을 자유롭게 입력하세요.',
    modules: {
        toolbar: [
            ['bold', 'italic', 'underline'],
            [{ 'list': 'ordered' }, { 'list': 'bullet' }],
            [{ 'size': ['small', false, 'large'] }],
            [{ 'color': [] }],
            ['clean']
        ]
    }
});

window.careerQuill.on('text-change', function() {
    document.getElementById('careerHidden').value = window.careerQuill.root.innerHTML;
});
</script>
</body>
</html>