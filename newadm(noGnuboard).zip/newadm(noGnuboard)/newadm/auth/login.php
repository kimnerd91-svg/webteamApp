<?php
include_once('../_common.php'); 
// include_once(G5_PATH.'/head_sub.php');

// ── 개발자 모드 허용 여부 ──
// 관리자(mb_level >= 10)가 "기본 1명"일 때만 개발자 모드 로그인 허용.
// 관리자가 추가(2명 이상)되면 보안상 개발자 우회 로그인 차단.
$admin_count = (int) (sql_fetch("SELECT COUNT(*) AS cnt FROM {$g5['member_table']} WHERE mb_level >= 10")['cnt'] ?? 0);
$dev_mode_allowed = ($admin_count <= 1);

// --- 자동 로그인 체크 로직 ---
if (!isset($_SESSION['ss_mb_id']) || !$_SESSION['ss_mb_id']) {
    if (isset($_COOKIE['adm_auto_login']) && $_COOKIE['adm_auto_login']) {
        $token = sql_real_escape_string($_COOKIE['adm_auto_login']);
        
        $sql = " SELECT * FROM {$g5['member_table']} WHERE mb_memo = '$token' AND mb_level >= 10 LIMIT 1 ";
        $row = sql_fetch($sql);

        if (isset($row['mb_id']) && $row['mb_id']) {
            set_session('ss_mb_id', $row['mb_id']);
            $_SESSION['adm_mb_id'] = $row['mb_id'];
            $_SESSION['adm_mb_name'] = $row['mb_name'];
            $_SESSION['adm_login_time'] = time();
            
            sql_query(" UPDATE {$g5['member_table']} SET mb_today_login = '".G5_TIME_YMDHIS."', mb_login_ip = '{$_SERVER['REMOTE_ADDR']}' WHERE mb_id = '{$row['mb_id']}' ");
            
            goto_url('/newadm/index.php');
        }
    }
}

// 이미 로그인되어 있으면 대시보드로
if(isset($_SESSION['adm_mb_id']) && $_SESSION['adm_mb_id']) {
    goto_url('/newadm/index.php');
}

$error_msg = '';

// 임시 관리자 로그인 (개발용)
if(isset($_GET['mode']) && $_GET['mode'] == 'dev_login') {
    // 관리자가 추가된 상태면 개발자 우회 로그인 차단 (URL 직접 접근 방어)
    if (!$dev_mode_allowed) {
        alert_toast('관리자가 등록되어 개발자 모드 로그인이 비활성화되었습니다.', '/newadm/auth/login.php', 'error');
        exit;
    }
    set_session('ss_mb_id', 'kimnerd91');
    $_SESSION['adm_mb_id'] = 'kimnerd91';
    $_SESSION['adm_mb_name'] = '관리자';
    $_SESSION['adm_login_time'] = time();
    goto_url('/newadm/index.php');
}

// 로그인 처리
if(isset($_POST['mode']) && $_POST['mode'] == 'login') {
    $mb_id = sql_real_escape_string(trim($_POST['mb_id']));
    $mb_password = trim($_POST['mb_password']);
    $auto_login = $_POST['auto_login'] ?? '';
    
    if(!$mb_id || !$mb_password) {
        $error_msg = '아이디와 비밀번호를 입력해주세요.';
    } else {
        $sql = " SELECT * FROM {$g5['member_table']} WHERE mb_id = '$mb_id' ";
        $row = sql_fetch($sql);
        
        if(!$row['mb_id']) {
            $error_msg = '존재하지 않는 아이디입니다.';
        } else if($row['mb_level'] < 10) {
            $error_msg = '관리자 권한이 없습니다. (Level 10 이상 필요)';
        } else {
            if(check_password($mb_password, $row['mb_password'])) {
                set_session('ss_mb_id', $row['mb_id']);
                $_SESSION['adm_mb_id'] = $row['mb_id'];
                $_SESSION['adm_mb_name'] = $row['mb_name'];
                $_SESSION['adm_login_time'] = time();
                
                if($auto_login == '1') {
                    $auto_login_token = md5($row['mb_id'].time().rand());
                    setcookie('adm_auto_login', $auto_login_token, time() + (86400 * 7), '/');
                    sql_query("UPDATE {$g5['member_table']} SET mb_memo = '$auto_login_token' WHERE mb_id = '$mb_id'");
                }
                
                sql_query(" UPDATE {$g5['member_table']} SET mb_today_login = '".G5_TIME_YMDHIS."', mb_login_ip = '{$_SERVER['REMOTE_ADDR']}' WHERE mb_id = '$mb_id' ");
                
                goto_url('/newadm/index.php');
            } else {
                $error_msg = '비밀번호가 일치하지 않습니다.';
            }
        }
    }
}

// 비밀번호 찾기 처리
if(isset($_POST['mode']) && $_POST['mode'] == 'reset_password') {
    $reset_email = sql_real_escape_string(trim($_POST['reset_email']));
    
    if(!$reset_email) {
        $error_msg = '이메일 주소를 입력해주세요.';
    } else {
        $sql = " SELECT mb_id, mb_name, mb_email FROM {$g5['member_table']} WHERE mb_email = '$reset_email' AND mb_level >= 10 ";
        $row = sql_fetch($sql);
        
        if(!$row['mb_id']) {
            $error_msg = '등록된 이메일 주소가 없거나 관리자 권한이 없습니다.';
        } else {
            $new_password = "0000";
            $hash_password = get_encrypt_string($new_password);
            
            sql_query(" UPDATE {$g5['member_table']} SET mb_password = '$hash_password' WHERE mb_id = '{$row['mb_id']}' ");
            
       alert_toast('비밀번호가 0000으로 리셋되었습니다.\n로그인 후 반드시 변경해주세요.', './login.php', 'success');
            exit;
        }
    }
}
?><!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>관리자 로그인 - NEW ADM</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" />
    <style>
        *,*::before,*::after{ box-sizing:border-box; margin:0; padding:0; }
        body{
            font-family:'Pretendard','Apple SD Gothic Neo',sans-serif;
            min-height:100vh; display:flex; align-items:center; justify-content:center;
            padding:24px; position:relative; overflow:hidden; color:#fff;
            background:
                radial-gradient(900px 600px at 20% 12%, rgba(129,140,248,.35) 0%, transparent 55%),
                radial-gradient(1000px 700px at 85% 88%, rgba(167,139,250,.30) 0%, transparent 55%),
                linear-gradient(160deg, #2a2350 0%, #312a63 35%, #3a2f78 65%, #251f48 100%);
        }
        /* 은은한 별/입자 + 떠다니는 빛무리 */
        .orb{ position:fixed; border-radius:50%; filter:blur(70px); opacity:.5; z-index:0; pointer-events:none; }
        .orb.a{ width:420px; height:420px; top:-140px; left:-110px;
            background:radial-gradient(circle,#a5b4fc,#6366f1); animation:float1 17s ease-in-out infinite; }
        .orb.b{ width:360px; height:360px; bottom:-140px; right:-90px;
            background:radial-gradient(circle,#a99bfb,#7c3aed); animation:float2 21s ease-in-out infinite; }
        @keyframes float1{ 50%{ transform:translate(40px,30px) scale(1.08);} }
        @keyframes float2{ 50%{ transform:translate(-30px,-40px) scale(1.06);} }

        .login-card{
            position:relative; z-index:1; width:100%; max-width:440px;
            background:rgba(255,255,255,.08);
            backdrop-filter:blur(26px) saturate(150%);
            -webkit-backdrop-filter:blur(26px) saturate(150%);
            border:1px solid rgba(255,255,255,.18);
            border-radius:28px; padding:44px 38px;
            box-shadow:0 30px 80px rgba(20,16,50,.45), inset 0 1px 0 rgba(255,255,255,.12);
            animation:cardIn .6s cubic-bezier(.2,.8,.2,1) both;
        }
        @keyframes cardIn{ from{ opacity:0; transform:translateY(18px) scale(.985);} }

        .brand{ text-align:center; margin-bottom:30px; }
        .brand-badge{
            width:58px; height:58px; margin:0 auto 16px; border-radius:50%;
            display:flex; align-items:center; justify-content:center;
            border:2px dashed rgba(255,255,255,.55);
            box-shadow:0 6px 20px rgba(124,58,237,.35);
        }
        .brand-badge .material-symbols-outlined{ font-size:26px; color:#fff; }
        .brand h1{ font-size:26px; font-weight:800; letter-spacing:-.5px; color:#fff; }
        .brand p{ margin-top:8px; font-size:13.5px; color:rgba(255,255,255,.65); font-weight:500; }

        .error-msg{
            display:flex; align-items:center; gap:8px;
            background:rgba(244,63,94,.16); border:1px solid rgba(252,165,165,.4); color:#fecdd3;
            padding:12px 14px; border-radius:12px; margin-bottom:18px; font-size:13.5px; font-weight:600;
        }
        .error-msg .material-symbols-outlined{ font-size:18px; }

        .field{ margin-bottom:16px; }
        .field > label{ display:block; font-size:13px; font-weight:600; margin-bottom:8px; color:rgba(255,255,255,.78); }
        .input-wrap{ position:relative; }
        .input-wrap > .lead{
            position:absolute; left:16px; top:50%; transform:translateY(-50%);
            font-size:20px; color:rgba(255,255,255,.55); pointer-events:none; transition:.2s;
        }
        .input-wrap input{
            width:100%; height:54px; border:1.5px solid rgba(255,255,255,.18); border-radius:14px;
            background:rgba(255,255,255,.07); color:#fff;
            font-size:15px; padding:0 46px; transition:all .2s;
        }
        .input-wrap input::placeholder{ color:rgba(255,255,255,.45); }
        .input-wrap input:focus{
            outline:none; border-color:rgba(167,139,250,.9); background:rgba(255,255,255,.12);
            box-shadow:0 0 0 4px rgba(139,92,246,.22);
        }
        .input-wrap input:focus ~ .lead{ color:#a99bfb; }
        .pw-toggle{
            position:absolute; right:8px; top:50%; transform:translateY(-50%);
            width:38px; height:38px; border:none; background:none; cursor:pointer;
            display:flex; align-items:center; justify-content:center;
            color:rgba(255,255,255,.55); border-radius:10px; transition:.2s;
        }
        .pw-toggle:hover{ color:#fff; background:rgba(255,255,255,.08); }
        .pw-toggle .material-symbols-outlined{ font-size:21px; }

        .row-between{ display:flex; align-items:center; justify-content:space-between; margin:18px 0 22px; }
        .adm-check-wrap{ display:flex; align-items:center; gap:9px; cursor:pointer; user-select:none; }
        .adm-checkbox{
            appearance:none; -webkit-appearance:none; width:20px; height:20px;
            border:1.5px solid rgba(255,255,255,.4); border-radius:6px; background:rgba(255,255,255,.06);
            position:relative; cursor:pointer; margin:0; transition:.2s; flex-shrink:0;
        }
        .adm-checkbox:checked{
            background:linear-gradient(135deg,#8b5cf6,#6366f1); border-color:#8b5cf6;
        }
        .adm-checkbox:checked::after{
            content:"✔"; position:absolute; top:50%; left:50%;
            transform:translate(-50%,-50%); color:#fff; font-size:12px;
        }
        .adm-check-wrap span{ font-size:13.5px; color:rgba(255,255,255,.8); }
        .link-btn{
            background:none; border:none; cursor:pointer; padding:0;
            font-size:13.5px; font-weight:600; color:rgba(255,255,255,.7); transition:.2s;
        }
        .link-btn:hover{ color:#fff; }

        .btn-login{
            width:100%; height:54px; border:none; border-radius:14px; cursor:pointer;
            background:#fff; color:#2a2350; font-size:15.5px; font-weight:700;
            box-shadow:0 10px 30px rgba(0,0,0,.25); transition:all .2s;
        }
        .btn-login:hover{ transform:translateY(-1px); box-shadow:0 14px 36px rgba(0,0,0,.3); }
        .btn-login:active{ transform:translateY(0); }

        .dev-box{
            margin-top:20px; padding:11px; text-align:center;
            background:rgba(255,255,255,.05); border:1px solid rgba(255,255,255,.12);
            border-radius:12px;
        }
        .dev-box a{ font-size:13px; color:rgba(255,255,255,.6); text-decoration:none; }
        .dev-box a:hover{ color:#fff; }

        /* 모달 */
        .modal-overlay{
            display:none; position:fixed; inset:0; z-index:9999;
            background:rgba(20,16,50,.6); backdrop-filter:blur(6px);
            align-items:center; justify-content:center; padding:20px;
        }
        .modal-card{
            width:100%; max-width:400px;
            background:rgba(40,34,80,.85); backdrop-filter:blur(24px) saturate(150%);
            border:1px solid rgba(255,255,255,.16); border-radius:22px; padding:36px 32px;
            box-shadow:0 30px 70px rgba(0,0,0,.45);
        }
        .modal-card h2{ font-size:19px; font-weight:700; margin-bottom:10px; color:#fff; }
        .modal-card p{ font-size:13.5px; color:rgba(255,255,255,.65); margin-bottom:20px; }
        .modal-card input{
            width:100%; height:50px; border:1.5px solid rgba(255,255,255,.18); border-radius:13px;
            background:rgba(255,255,255,.07); color:#fff; font-size:15px; padding:0 16px; margin-bottom:22px;
        }
        .modal-card input::placeholder{ color:rgba(255,255,255,.45); }
        .modal-card input:focus{ outline:none; border-color:#a78bfa; background:rgba(255,255,255,.12); }
        .modal-actions{ display:flex; gap:12px; }
        .modal-actions button{
            flex:1; height:48px; border:none; border-radius:12px; cursor:pointer; font-size:14px; font-weight:600;
        }
        .btn-cancel{ background:rgba(255,255,255,.1); color:rgba(255,255,255,.85); }
        .btn-cancel:hover{ background:rgba(255,255,255,.18); }
        .btn-confirm{ background:linear-gradient(135deg,#8b5cf6,#6366f1); color:#fff; }
        .btn-confirm:hover{ filter:brightness(1.08); }
    </style>
</head>
<body>
    <div class="orb a"></div>
    <div class="orb b"></div>

    <div class="login-card">
        <header class="brand">
            <div class="brand-badge"><span class="material-symbols-outlined">shield_person</span></div>
            <h1>관리자 로그인</h1>
            <p>NEW ADM 관리자 전용</p>
        </header>

        <?php if($error_msg) { ?>
        <div class="error-msg"><span class="material-symbols-outlined">error</span><?php echo $error_msg; ?></div>
        <?php } ?>

        <form method="post" action="">
            <input type="hidden" name="mode" value="login">

            <div class="field">
                <label>아이디</label>
                <div class="input-wrap">
                    <input type="text" name="mb_id" placeholder="관리자 아이디 입력" required autofocus>
                    <span class="lead material-symbols-outlined">person</span>
                </div>
            </div>

            <div class="field">
                <label>비밀번호</label>
                <div class="input-wrap">
                    <input type="password" name="mb_password" id="mb_password" placeholder="비밀번호 입력" required>
                    <span class="lead material-symbols-outlined">lock</span>
                    <button type="button" class="pw-toggle" onclick="togglePw()" tabindex="-1">
                        <span class="material-symbols-outlined" id="pwIcon">visibility</span>
                    </button>
                </div>
            </div>

            <div class="row-between">
                <label class="adm-check-wrap">
                    <input type="checkbox" name="auto_login" value="1" class="adm-checkbox">
                    <span>자동 로그인 (7일간 유지)</span>
                </label>
                <button type="button" class="link-btn" onclick="openResetModal()">비밀번호 찾기</button>
            </div>

            <button type="submit" class="btn-login">로그인</button>

            <?php if ($dev_mode_allowed): ?>
            <div class="dev-box">
                <a href="?mode=dev_login">🔧 개발자 모드 로그인 (테스트용)</a>
            </div>
            <?php endif; ?>
        </form>
    </div>

    <div class="modal-overlay" id="resetModal">
        <div class="modal-card">
            <h2>비밀번호 찾기</h2>
            <p>등록된 관리자 이메일로 비밀번호를 0000으로 리셋합니다.</p>
            <form method="post">
                <input type="hidden" name="mode" value="reset_password">
                <input type="email" name="reset_email" placeholder="example@email.com" required>
                <div class="modal-actions">
                    <button type="button" class="btn-cancel" onclick="closeResetModal()">취소</button>
                    <button type="submit" class="btn-confirm">리셋</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        const resetModal = document.getElementById('resetModal');
        const openResetModal = () => { resetModal.style.display = 'flex'; };
        const closeResetModal = () => { resetModal.style.display = 'none'; };
        resetModal.addEventListener('click', (e) => { if(e.target === resetModal) closeResetModal(); });

        function togglePw(){
            const inp = document.getElementById('mb_password');
            const ic  = document.getElementById('pwIcon');
            const show = inp.type === 'password';
            inp.type = show ? 'text' : 'password';
            ic.textContent = show ? 'visibility_off' : 'visibility';
        }
    </script>
</body>
</html>