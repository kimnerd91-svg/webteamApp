<?php
/**
 * 초기 관리자 계정 생성 + DB 복원 스크립트
 * URL: /newadm/setup_admin.php
 * 
 * 이 파일은:
 * 1. 관리자 계정이 없을 때 admin 계정 생성
 * 2. DB가 비어있을 때 백업 복원 기능 제공
 */

// 그누보드 공통 파일 로드
if(file_exists('../../common.php')) {
    include_once('../../common.php');
} else {
    die('그누보드 common.php를 찾을 수 없습니다.');
}

// 백업 디렉토리 설정
$backup_dir = G5_DATA_PATH . '/db_backups';
if (!is_dir($backup_dir)) {
    @mkdir($backup_dir, G5_DIR_PERMISSION, true);
}

// ============================================
// 백업 복원 처리
// ============================================
if (isset($_FILES['restore_file']) && $_FILES['restore_file']['error'] === UPLOAD_ERR_OK) {
    $uploadfile = $_FILES['restore_file'];
    $temp_dir = $backup_dir . '/temp_restore';
    
    if (!is_dir($temp_dir)) {
        @mkdir($temp_dir, G5_DIR_PERMISSION, true);
    }
    
    $result_msg = '';
    $result_type = 'error';
    
    $zip = new ZipArchive;
    if ($zip->open($uploadfile['tmp_name']) === TRUE) {
        $zip->extractTo($temp_dir);
        $zip->close();
        
        // SQL 파일 찾기
        $files = scandir($temp_dir);
        $sqlfile = null;
        foreach ($files as $file) {
            if (pathinfo($file, PATHINFO_EXTENSION) === 'sql') {
                $sqlfile = $temp_dir . '/' . $file;
                break;
            }
        }
        
        if ($sqlfile && file_exists($sqlfile)) {
            $command = sprintf(
                'mysql -h%s -u%s -p%s %s < %s 2>&1',
                escapeshellarg(G5_MYSQL_HOST),
                escapeshellarg(G5_MYSQL_USER),
                escapeshellarg(G5_MYSQL_PASSWORD),
                escapeshellarg(G5_MYSQL_DB),
                escapeshellarg($sqlfile)
            );
            
            exec($command, $output, $result_code);
            
            // 임시 파일 삭제
            @unlink($sqlfile);
            @rmdir($temp_dir);
            
            if ($result_code === 0) {
                $result_msg = '✓ 백업이 성공적으로 복원되었습니다!';
                $result_type = 'success';
            } else {
                $result_msg = '✗ 복원 실패: ' . implode(' ', $output);
            }
        } else {
            $result_msg = '✗ ZIP 파일 내 SQL 파일을 찾을 수 없습니다.';
        }
    } else {
        $result_msg = '✗ ZIP 파일을 열 수 없습니다.';
    }
}

// ============================================
// 관리자 계정 생성 처리
// ============================================
$admin_exists = false;
$create_result = '';

// 1. admin 계정 존재 여부 확인
$check = sql_fetch("SELECT mb_id FROM {$g5['member_table']} WHERE mb_id = 'admin'");
if (isset($check['mb_id']) && $check['mb_id']) {
    $admin_exists = true;
}

// 2. 계정 생성 요청 처리
if (isset($_POST['create_admin']) && !$admin_exists) {
    $mb_id       = 'admin';
    $mb_password = 'pw1234'; // 실행 후 반드시 변경하세요!
    $mb_name     = '최고관리자';
    $mb_email    = 'admin@example.com';
    $mb_level    = 10;
    
    $mb_password_hash = get_encrypt_string($mb_password);
    $mb_datetime = G5_TIME_YMDHIS;
    $mb_ip = $_SERVER['REMOTE_ADDR'];
    
    $sql = "INSERT INTO {$g5['member_table']} 
            SET mb_id = '$mb_id',
                mb_password = '$mb_password_hash',
                mb_name = '$mb_name',
                mb_nick = '$mb_name',
                mb_email = '$mb_email',
                mb_level = '$mb_level',
                mb_datetime = '$mb_datetime',
                mb_today_login = '$mb_datetime',
                mb_login_ip = '$mb_ip',
                mb_email_certify = '$mb_datetime',
                mb_hp = '010-0000-0000',
                mb_mailling = '1',
                mb_open = '1',
                mb_nick_date = '$mb_datetime',
                mb_open_date = '$mb_datetime'";
    
    if (sql_query($sql, false)) {
        $create_result = 'success';
    } else {
        $create_result = 'error';
    }
}

// 백업 파일 목록
$backup_files = [];
if (is_dir($backup_dir)) {
    $files = scandir($backup_dir);
    foreach ($files as $file) {
        if (pathinfo($file, PATHINFO_EXTENSION) === 'zip') {
            $filepath = $backup_dir . '/' . $file;
            $backup_files[] = [
                'name' => $file,
                'size' => filesize($filepath),
                'date' => filemtime($filepath)
            ];
        }
    }
    usort($backup_files, function($a, $b) {
        return $b['date'] - $a['date'];
    });
}
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>초기 설정 & DB 복원</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, #8b7cf9 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: 40px auto;
            background: transparent;
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }
        h1 {
            color: #333;
            margin-bottom: 10px;
            font-size: 28px;
        }
        .subtitle {
            color: #666;
            margin-bottom: 30px;
            font-size: 14px;
        }
        .section {
            background: rgba(255,255,255,0.06);
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 25px;
            border: 2px solid rgba(255,255,255,0.14);
        }
        .section h2 {
            color: #c7c9d1;
            margin-bottom: 15px;
            font-size: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .icon {
            font-size: 24px;
        }
        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 500;
        }
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .alert-warning {
            background: #fff3cd;
            color: #856404;
            border: 1px solid #ffeaa7;
        }
        .alert-info {
            background: #d1ecf1;
            color: #0c5460;
            border: 1px solid #bee5eb;
        }
        .btn {
            display: inline-block;
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.3s;
            font-size: 15px;
        }
        .btn-primary {
            background: #8b7cf9;
            color: white;
        }
        .btn-primary:hover {
            background: #7c6cf0;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
        }
        .btn-success {
            background: #28a745;
            color: white;
        }
        .btn-success:hover {
            background: #218838;
        }
        .btn-danger {
            background: #dc3545;
            color: white;
        }
        .dropzone {
            border: 3px dashed #dee2e6;
            background: transparent;
            padding: 40px;
            text-align: center;
            border-radius: 12px;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 15px;
        }
        .dropzone:hover, .dropzone.dragover {
            border-color: #8b7cf9;
            background: #f8f9ff;
        }
        .info-box {
            background: transparent;
            padding: 20px;
            border-radius: 8px;
            margin: 15px 0;
            border-left: 4px solid #8b7cf9;
        }
        .info-box strong {
            color: #333;
            font-size: 16px;
        }
        .backup-list {
            margin-top: 15px;
        }
        .backup-item {
            background: transparent;
            padding: 12px 15px;
            border-radius: 6px;
            margin-bottom: 8px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border: 1px solid rgba(255,255,255,0.14);
        }
        .backup-info {
            font-size: 13px;
            color: #666;
        }
        .warning-text {
            color: #dc3545;
            font-weight: 600;
            margin-top: 10px;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🚀 초기 설정 & DB 복원</h1>
        <p class="subtitle">관리자 계정 생성 및 백업 데이터 복원</p>

        <?php if (isset($result_msg)): ?>
            <div class="alert <?= $result_type === 'success' ? 'alert-success' : 'alert-error' ?>">
                <?= $result_msg ?>
            </div>
        <?php endif; ?>

        <?php if ($create_result === 'success'): ?>
            <div class="alert alert-success">
                ✅ 관리자 계정이 생성되었습니다!
            </div>
            <div class="info-box">
                <strong>로그인 정보</strong><br>
                아이디: <b>admin</b><br>
                비밀번호: <b>pw1234</b>
            </div>
            <a href="./auth/login.php" class="btn btn-primary">로그인 페이지로 이동</a>
            <p class="warning-text">⚠️ 로그인 후 반드시 비밀번호를 변경하세요!</p>
            
        <?php elseif ($create_result === 'error'): ?>
            <div class="alert alert-error">
                ✗ 계정 생성 실패: <?= sql_error() ?>
            </div>
        <?php endif; ?>

        <!-- 관리자 계정 생성 섹션 -->
        <?php if (!$admin_exists && $create_result !== 'success'): ?>
            <div class="section">
                <h2><span class="icon">👤</span> 관리자 계정 생성</h2>
                <div class="alert alert-info">
                    현재 관리자 계정이 없습니다. admin 계정을 생성하세요.
                </div>
                <form method="post">
                    <button type="submit" name="create_admin" class="btn btn-success">
                        관리자 계정 생성 (ID: admin / PW: pw1234)
                    </button>
                </form>
            </div>
        <?php else: ?>
            <div class="alert alert-warning">
                ⚠️ 관리자 계정이 이미 존재합니다. 보안을 위해 이 파일(setup_admin.php)을 <strong>즉시 삭제</strong>하세요!
            </div>
        <?php endif; ?>

        <!-- DB 복원 섹션 -->
        <div class="section">
            <h2><span class="icon">💾</span> 백업 복원</h2>
            <p style="color: #666; margin-bottom: 15px;">
                이전에 생성한 백업 파일(.zip)을 업로드하여 데이터를 복원할 수 있습니다.
            </p>
            
            <form method="post" enctype="multipart/form-data" id="restoreForm">
                <div id="dropZone" class="dropzone">
                    <div style="font-size: 48px; margin-bottom: 10px;">📦</div>
                    <p style="font-weight: 600; margin-bottom: 5px;">백업 파일을 드래그하거나 클릭하여 선택</p>
                    <p style="font-size: 13px; color: #999;">ZIP 파일만 업로드 가능</p>
                    <input type="file" name="restore_file" id="fileInput" accept=".zip" style="display: none;">
                </div>
            </form>

            <?php if (!empty($backup_files)): ?>
                <div class="backup-list">
                    <strong style="display: block; margin-bottom: 10px;">📂 사용 가능한 백업 (<?= count($backup_files) ?>개)</strong>
                    <?php foreach ($backup_files as $backup): ?>
                        <div class="backup-item">
                            <div>
                                <div style="font-weight: 600; margin-bottom: 3px;">
                                    <?= htmlspecialchars($backup['name']) ?>
                                </div>
                                <div class="backup-info">
                                    <?= date('Y-m-d H:i:s', $backup['date']) ?> · 
                                    <?= number_format($backup['size'] / 1024, 1) ?> KB
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="alert alert-warning">
            <strong>⚠️ 보안 경고</strong><br>
            초기 설정이 완료되면 반드시 이 파일(<code>setup_admin.php</code>)을 서버에서 삭제하세요!
        </div>
    </div>

    <script>
        const dropZone = document.getElementById('dropZone');
        const fileInput = document.getElementById('fileInput');
        const restoreForm = document.getElementById('restoreForm');

        dropZone.onclick = () => fileInput.click();

        dropZone.ondragover = (e) => {
            e.preventDefault();
            dropZone.classList.add('dragover');
        };

        dropZone.ondragleave = () => {
            dropZone.classList.remove('dragover');
        };

        dropZone.ondrop = (e) => {
            e.preventDefault();
            dropZone.classList.remove('dragover');
            const file = e.dataTransfer.files[0];
            if (file && file.name.endsWith('.zip')) {
                fileInput.files = e.dataTransfer.files;
                uploadFile();
            } else {
                alert('ZIP 파일만 업로드 가능합니다.');
            }
        };

        fileInput.onchange = () => {
            if (fileInput.files[0]) {
                uploadFile();
            }
        };

        function uploadFile() {
            if (confirm('백업을 복원하시겠습니까?\n\n현재 데이터가 백업 시점으로 되돌아갑니다.')) {
                dropZone.innerHTML = '<div style="font-size: 48px;">⏳</div><p style="font-weight: 600;">복원 중...</p>';
                restoreForm.submit();
            }
        }
    </script>
</body>
</html>