<?php
/**
 * bbs 디렉터리 공통 부트스트랩 — 루트 common.php를 그대로 로드한다.
 */
include_once($_SERVER['DOCUMENT_ROOT'] . '/common.php');
