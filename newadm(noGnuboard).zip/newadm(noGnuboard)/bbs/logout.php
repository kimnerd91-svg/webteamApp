<?php
include_once('./_common.php');

$__nd_was_kakao = (strpos($_SESSION['ss_mb_id'] ?? '', 'kakao_') === 0);

set_session('ss_mb_id', '');
unset($_SESSION['ss_mb_id']);
set_cookie('ck_mb_id', '', 0);
set_cookie('ck_auto', '', 0);

if ($__nd_was_kakao) {
    $dm_conf = sql_fetch("SELECT cf_kakao_rest_key FROM dm_config WHERE cf_id = 1");
    if (!empty($dm_conf['cf_kakao_rest_key'])) {
        $kakao_logout_url = 'https://kauth.kakao.com/oauth/logout?client_id=' . $dm_conf['cf_kakao_rest_key']
            . '&logout_redirect_uri=' . urlencode(G5_URL);
        goto_url($kakao_logout_url);
    }
}

goto_url(G5_URL);
