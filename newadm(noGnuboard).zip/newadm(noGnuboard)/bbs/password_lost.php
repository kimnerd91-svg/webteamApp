<?php
include_once('./_common.php');

$result_msg = '';
$new_password = '';

if (isset($_POST['mode']) && $_POST['mode'] == 'find') {
    $mb_id    = sql_real_escape_string(trim($_POST['mb_id'] ?? ''));
    $mb_email = sql_real_escape_string(trim($_POST['mb_email'] ?? ''));

    if (!$mb_id || !$mb_email) {
        $result_msg = '아이디와 이메일을 모두 입력해주세요.';
    } else {
        $row = sql_fetch("SELECT mb_id FROM {$g5['member_table']} WHERE mb_id = '{$mb_id}' AND mb_email = '{$mb_email}'");
        if (empty($row['mb_id'])) {
            $result_msg = '일치하는 회원 정보가 없습니다.';
        } else {
            $new_password = substr(str_shuffle('ABCDEFGHJKLMNPQRSTUVWXYZ23456789'), 0, 8);
            $hash = get_encrypt_string($new_password);
            sql_query("UPDATE {$g5['member_table']} SET mb_password = '{$hash}' WHERE mb_id = '{$row['mb_id']}'");
            $result_msg = 'success';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>비밀번호 찾기</title>
    <link rel="stylesheet" href="/css/setting.css">
    <link rel="stylesheet" href="/css/base_core.css">
    <style>
        body { background: #f8f9fa; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; }
        .card { width: 100%; max-width: 400px; padding: 40px; background: #fff; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); }
        .u-input { width: 100%; padding: 12px; margin-bottom: 15px; border: 1px solid #ddd; border-radius: 8px; box-sizing: border-box; }
        .w-100 { width: 100%; }
        .result-box { padding: 14px; border-radius: 8px; margin-bottom: 15px; font-size: 14px; }
        .result-error { background: #fdecea; color: #b71c1c; }
        .result-success { background: #e8f5e9; color: #1b5e20; }
    </style>
</head>
<body>
    <div class="card">
        <h1 class="text-center fw-900 u-mb-32">비밀번호 찾기</h1>

        <?php if ($result_msg === 'success'): ?>
            <div class="result-box result-success">
                임시 비밀번호가 발급되었습니다: <b><?php echo htmlspecialchars($new_password); ?></b><br>
                로그인 후 반드시 비밀번호를 변경해주세요.
            </div>
            <a href="./login.php" class="u-btn u-bg-main u-txt-white w-100 u-py-12 rounded-8 fw-700 d-block text-center">로그인 하러가기</a>
        <?php else: ?>
            <?php if ($result_msg): ?>
                <div class="result-box result-error"><?php echo htmlspecialchars($result_msg); ?></div>
            <?php endif; ?>
            <form method="post">
                <input type="hidden" name="mode" value="find">
                <input type="text" name="mb_id" class="u-input" placeholder="아이디" required>
                <input type="email" name="mb_email" class="u-input" placeholder="가입 시 등록한 이메일" required>
                <button type="submit" class="u-btn u-bg-main u-txt-white w-100 u-py-12 rounded-8 fw-700">임시 비밀번호 발급</button>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>
