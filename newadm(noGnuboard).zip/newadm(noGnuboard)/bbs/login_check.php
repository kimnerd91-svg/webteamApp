<?php
include_once('./_common.php');

$mb_id       = sql_real_escape_string(trim($_POST['mb_id'] ?? ''));
$mb_password = trim($_POST['mb_password'] ?? '');
$auto_login  = $_POST['auto_login'] ?? '';
$url         = $_POST['url'] ?? '';

if (!$mb_id || !$mb_password) {
    alert('아이디와 비밀번호를 입력해주세요.', G5_BBS_URL . '/login.php');
}

$row = sql_fetch("SELECT * FROM {$g5['member_table']} WHERE mb_id = '{$mb_id}'");

if (empty($row['mb_id'])) {
    alert('존재하지 않는 아이디입니다.', G5_BBS_URL . '/login.php');
}

if (!empty($row['mb_leave_date']) || !empty($row['mb_intercept_date'])) {
    alert('탈퇴했거나 차단된 회원입니다.', G5_BBS_URL . '/login.php');
}

if (!check_password($mb_password, $row['mb_password'])) {
    alert('비밀번호가 일치하지 않습니다.', G5_BBS_URL . '/login.php');
}

set_session('ss_mb_id', $row['mb_id']);

sql_query("UPDATE {$g5['member_table']} SET mb_today_login = '" . G5_TIME_YMDHIS . "', mb_login_ip = '{$_SERVER['REMOTE_ADDR']}' WHERE mb_id = '{$row['mb_id']}'", false);

if ($auto_login == '1') {
    $key = md5(($_SERVER['SERVER_ADDR'] ?? '') . ($_SERVER['SERVER_SOFTWARE'] ?? '') . ($_SERVER['HTTP_USER_AGENT'] ?? '') . $row['mb_password']);
    set_cookie('ck_mb_id', $row['mb_id'], 86400 * 31);
    set_cookie('ck_auto', $key, 86400 * 31);
}

goto_url($url ?: G5_URL);
