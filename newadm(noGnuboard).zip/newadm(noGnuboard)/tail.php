<?php
/**
 * /tail.php (루트) — 문의모달 + 푸터/퀵메뉴 컴포넌트 선택기 + 페이지 마무리
 * (예전엔 layout/tail.php에 있었으나 루트로 이동함. 푸터/퀵메뉴 타입 파일들은 그대로 layout/footer/, layout/quickmenu/ 안에 있음)
 *
 * 사용법: 이 파일을 include하기 전에 원하는 푸터/퀵메뉴 타입을 지정할 수 있다.
 *   $footer_type    = 'map_split';   // 지정 안 하면 'old'(기존 실사용 푸터) 사용
 *   $quickmenu_type = 'fab';         // 지정 안 하면 'default' 사용
 *   include G5_PATH . '/tail.php';
 *
 * 사용 가능한 타입:
 *   footer_type    — old, minimal, map_full, map_split (layout/footer/ 안의 파일명 기준)
 *   quickmenu_type — default, minimal, modal, iconlabel, icontop, fab (layout/quickmenu/ 안의 파일명 기준)
 * 새 타입을 추가하려면 footer_{타입명}.php / quickmenu_{타입명}.php 파일만 만들면 된다.
 *
 * 참고: 다음(Daum) 지도 임베드는 이제 공용이 아니라 footer_map_full.php / footer_map_split.php
 * 안에 각각 들어있다 — 지도가 필요없는 푸터 타입을 쓰면 지도도 같이 빠진다.
 */
if (!defined('_GNUBOARD_')) exit;

// $conf 쿼리 제거 — head_sub.php의 $dm_conf / 전역변수 사용
$non_covered_file = G5_DATA_PATH . '/content/non_covered.json';
$non_covered = [];
if (file_exists($non_covered_file)) {
    $decoded_data = json_decode(file_get_contents($non_covered_file), true);
    if (is_array($decoded_data)) $non_covered = $decoded_data;
}
?>

<!-- 문의모달 -->
<?php
// ★ 여기서 true/false 로 껐다 켰다 ★
$use_consult_modal = true;   // 모달형 사용 여부 (전 페이지)
$use_consult_bar   = false;  // 막대형 사용 여부 (메인만)

$is_main = (basename($_SERVER['SCRIPT_NAME']) === 'index.php');

if (!empty($use_consult_modal)) include_once(G5_PATH . '/layout/consult_modal.php');
if ($is_main && !empty($use_consult_bar)) include_once(G5_PATH . '/layout/consult_bar.php');
?>

<!-- 푸터 -->
<?php
$footer_type   = $footer_type ?? 'old';
$__footer_file = G5_PATH . '/layout/footer/footer_' . preg_replace('/[^a-z0-9_]/i', '', $footer_type) . '.php';
if (!is_file($__footer_file)) $__footer_file = G5_PATH . '/layout/footer/footer_old.php';
include $__footer_file;
?>

<!-- 퀵메뉴 -->
<?php
$quickmenu_type = $quickmenu_type ?? 'default';
$__qm_file      = G5_PATH . '/layout/quickmenu/quickmenu_' . preg_replace('/[^a-z0-9_]/i', '', $quickmenu_type) . '.php';
if (!is_file($__qm_file)) $__qm_file = G5_PATH . '/layout/quickmenu/quickmenu_default.php';
include $__qm_file;
?>

<script>
    AOS.init();
</script>

<?php include_once(G5_PATH . '/tail_sub.php'); ?>

<?php
// ===== 다국어 텍스트 치환 =====
if (isset($lang) && $lang !== 'ko') {
    $html = ob_get_clean();

    $page_key  = ltrim(str_replace(['.php', '/'], ['', '__'], $_SERVER['SCRIPT_NAME']), '__');
    $json_file = $_SERVER['DOCUMENT_ROOT'] . '/lang/' . $page_key . '.json';

    if (file_exists($json_file)) {
        $trans = json_decode(file_get_contents($json_file), true) ?: [];

        // 긴 문자열 먼저 치환 (짧은 문자열이 먼저 치환되면 중복 문제 생김)
        uksort($trans, function ($a, $b) {
            return mb_strlen($b) - mb_strlen($a);
        });

        foreach ($trans as $ko => $langs) {
            $translated = $langs[$lang] ?? '';
            if (!$translated) continue;
            $html = str_replace(htmlspecialchars($ko, ENT_QUOTES, 'UTF-8'), htmlspecialchars($translated, ENT_QUOTES, 'UTF-8'), $html);
            $html = str_replace($ko, $translated, $html);
        }
    }

    echo $html;
}
// ================================
?>
