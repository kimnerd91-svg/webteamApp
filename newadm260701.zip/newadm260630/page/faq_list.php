<?php
if (!defined('_GNUBOARD_')) {
    include_once($_SERVER['DOCUMENT_ROOT'] . '/_common.php');
}

$bo_table = 'faq';
$write_table = $g5['write_prefix'] . $bo_table;
$category_table = $write_table . '_category';

$table_check = sql_query("SHOW TABLES LIKE '{$write_table}'", false);
if (!$table_check || sql_num_rows($table_check) == 0) return;

$sql = "SELECT * FROM {$write_table} ORDER BY wr_id DESC LIMIT 50";
$result = sql_query($sql, false);
if (!$result) return;

// 카테고리 목록 가져오기
$cat_result = sql_query("SELECT * FROM {$category_table} ORDER BY ca_order ASC", false);
$categories = [];
if ($cat_result) {
    while ($row = sql_fetch_array($cat_result)) {
        $categories[$row['ca_id']] = $row['ca_name'];
    }
}

// 데이터를 카테고리별로 그룹화
$faq_by_category = [];
while ($row = sql_fetch_array($result)) {
    $cat_id = $row['wr_10'];
    $cat_name = isset($categories[$cat_id]) ? $categories[$cat_id] : '기타';
    $faq_by_category[$cat_name][] = $row;
}

// 탭 버튼 순서를 위해 카테고리 이름만 추출
$cat_names = array_keys($faq_by_category);
?>

<section class="faq-section u-py-40">
    <div class="container" style="max-width: 1200px; margin: 0 auto; padding: 0 var(--sp-20);">
        
        <div class="text-center u-mb-40">
            <div class="u-txt-main fw-700 c-fs-14 u-mb-10">FAQ</div>
            <h2 class="t-fs-40">자주 묻는 질문</h2>
        </div>

        <?php if (!empty($faq_by_category)): ?>
            <ul class="nav nav-pills u-gap-16 u-mb-24" id="faqTab" role="tablist">
                <?php foreach ($cat_names as $i => $name): ?>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link <?= ($i === 0) ? 'active' : '' ?> faq-tab-btn" 
                                id="tab-btn-<?= $i ?>" 
                                data-bs-toggle="pill" 
                                data-bs-target="#tab-content-<?= $i ?>" 
                                type="button" role="tab">
                            <?= htmlspecialchars($name) ?>
                        </button>
                    </li>
                <?php endforeach; ?>
            </ul>

            <div class="tab-content" id="faqTabContent">
                <?php foreach ($cat_names as $i => $name): ?>
                    <div class="tab-pane fade <?= ($i === 0) ? 'show active' : '' ?>" 
                         id="tab-content-<?= $i ?>" role="tabpanel">
                        
                        <div class="accordion" id="accordion-<?= $i ?>">
                            <?php foreach ($faq_by_category[$name] as $idx => $faq): ?>
                                <div class="accordion-item u-mb-12 shadow-sm border-0 rounded-12 overflow-hidden">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button collapsed" type="button"
                                                data-bs-toggle="collapse"
                                                data-bs-target="#collapse-<?= $faq['wr_id'] ?>"
                                                style="padding: 20px; font-weight: 600;">
                                            <span class="faq-q-badge">Q</span>
                                            <span class="ms-2"><?= htmlspecialchars($faq['wr_subject']) ?></span>
                                        </button>
                                    </h2>
                                    <div id="collapse-<?= $faq['wr_id'] ?>" 
                                         class="accordion-collapse collapse" 
                                         data-bs-parent="#accordion-<?= $i ?>">
                                        <div class="accordion-body u-txt-body" style="padding: 24px; line-height: 1.8; background: #fafafa;">
                                          <?= conv_content($faq['wr_content'], 1) ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>

                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="text-center u-py-40 u-txt-muted">
                <p>등록된 FAQ가 없습니다.</p>
            </div>
        <?php endif; ?>

    </div>
</section>

<style>
    /* 탭 버튼 스타일 */
    .faq-tab-btn {
        padding: 10px 24px !important;
        border-radius: 50px !important;
        background: #f1f3f5 !important;
        color: #495057 !important;
        font-weight: 600;
        border: 1px solid #e9ecef !important;
        transition: all 0.3s;
    }
    .faq-tab-btn.active {
        background: var(--main-color, #007bff) !important;
        color: #fff !important;
        border-color: var(--main-color, #007bff) !important;
        box-shadow: 0 4px 12px rgba(0, 123, 255, 0.2);
    }

    /* Q 아이콘 스타일 */
    .faq-q-badge {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 28px;
        height: 28px;
        background: var(--main-color, #007bff);
        color: #fff;
        border-radius: 50%;
        font-weight: 700;
        font-size: 14px;
        flex-shrink: 0;
    }

    /* 아코디언 스타일 커스텀 */
    .faq-section .accordion-button:not(.collapsed) {
        background: #fff;
        color: var(--main-color, #007bff);
        box-shadow: none;
    }
    .faq-section .accordion-button:focus {
        box-shadow: none;
    }
    .faq-section .accordion-item {
        border-radius: 12px !important;
        transition: transform 0.2s;
    }
    .faq-section .accordion-item:hover {
        transform: translateY(-2px);
    }
    
    .rounded-12 { border-radius: 12px !important; }

    @media (max-width: 768px) {
        .nav-pills { gap: 8px !important; }
        .faq-tab-btn { padding: 8px 16px !important; font-size: 13px; }
    }
</style>