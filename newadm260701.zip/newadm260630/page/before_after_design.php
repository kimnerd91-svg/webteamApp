<?php
// 비포애프터 디자인 모듈 - 드래그 슬라이더 방식
// 다른 용도로도 재사용 가능

if (!defined('_GNUBOARD_')) {
    include_once($_SERVER['DOCUMENT_ROOT'] . '/_common.php');
}

$ba_table = 'dm_beforeafter';

// 테이블 존재 확인
$table_check = sql_query("SHOW TABLES LIKE '{$ba_table}'", false);
if (!$table_check || sql_num_rows($table_check) == 0) {
    return;
}

// 로그인 여부 확인
$is_logged_in = isset($_SESSION['ss_mb_id']) && $_SESSION['ss_mb_id'];

// 노출 가능한 데이터만 가져오기
$sql = "SELECT * FROM {$ba_table} WHERE is_visible = 1 ORDER BY display_order ASC, id DESC";
$result = sql_query($sql, false);

if (!$result || sql_num_rows($result) == 0) {
    return;
}
?>

<!-- SweetAlert2 CDN -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<!-- 비포애프터 디자인 섹션 -->
<section class="u-py-80" style="background: var(--bg-soft);">
    <div class="container" style="max-width: 1400px; margin: 0 auto; padding: 0 var(--sp-20);">
        
        <!-- 헤더 -->
        <div class="text-center u-mb-60" data-aos="fade-up">
            <div class="u-txt-main fw-700 c-fs-14 u-mb-10">BEFORE & AFTER</div>
            <h2 class="t-fs-48 fw-900 u-mb-16">치료 전후 비교</h2>
            <p class="c-fs-18 u-txt-muted">드래그하여 치료 결과를 확인하세요</p>
        </div>

        <!-- 슬라이더 목록 -->
        <div class="d-flex flex-column" style="gap: var(--sp-60);">
            <?php while ($ba = sql_fetch_array($result)): ?>
                <div class="ba-slider-item">
                    <div class="ba-slider-layout">
                        <!-- 좌측: 정보 -->
                        <div class="ba-slider-info">
                            <?php if ($ba['treatment_category']): ?>
                                <span class="u-badge u-badge-main u-mb-12"><?= htmlspecialchars($ba['treatment_category']) ?></span>
                            <?php endif; ?>
                            <h3 class="t-fs-32 fw-900 u-txt-title u-mb-12" style="line-height: 1.3;">
                                <?= htmlspecialchars($ba['title']) ?>
                            </h3>
                            <?php if ($ba['treatment_period']): ?>
                                <p class="c-fs-16 u-txt-muted">⏱️ <?= htmlspecialchars($ba['treatment_period']) ?></p>
                            <?php endif; ?>
                        </div>
                        
                        <!-- 우측: 이미지 슬라이더 -->
                        <div class="ba-slider-wrap" onclick="handleSliderClick(<?= $ba['id'] ?>, <?= $is_logged_in ? 'true' : 'false' ?>)">
                            <div class="ba-compare-container">
                                <?php if ($ba['image_before']): ?>
                                    <img src="<?= htmlspecialchars($ba['image_before']) ?>" alt="Before" class="ba-img ba-img-before">
                                <?php endif; ?>
                                <?php if ($ba['image_after']): ?>
                                    <img src="<?= htmlspecialchars($ba['image_after']) ?>" alt="After" class="ba-img ba-img-after">
                                <?php endif; ?>
                                <div class="ba-handle"></div>
                                
                                <!-- 블러 오버레이 -->
                                <?php if (!$is_logged_in): ?>
                                    <div class="ba-blur">
                                        <div class="ba-lock">🔒</div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <!-- 로그인 후 표시 정보 -->
                    <?php if ($is_logged_in): ?>
                    <div class="u-mt-32 u-pt-32" style="border-top: 1px solid var(--gray-200);">
                        <?php if ($ba['patient_age'] || $ba['patient_gender']): ?>
                            <p class="c-fs-14 u-txt-body u-mb-12">
                                👤 <?= htmlspecialchars($ba['patient_age']) ?> <?= htmlspecialchars($ba['patient_gender']) ?>
                            </p>
                        <?php endif; ?>
                        <?php if ($ba['description']): ?>
                            <p class="c-fs-15 u-txt-body" style="line-height: 1.7; white-space: pre-wrap;">
                                <?= nl2br(htmlspecialchars($ba['description'])) ?>
                            </p>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
</section>

<style>
/* 슬라이더 레이아웃 */
.ba-slider-layout {
    display: flex;
    gap: var(--sp-48);
    align-items: center;
}

.ba-slider-info {
    flex: 0 0 35%;
}

.ba-slider-wrap {
    flex: 1;
    position: relative;
    aspect-ratio: 16 / 10;
    border-radius: var(--sp-20);
    overflow: hidden;
    background: var(--gray-100);
}

.ba-compare-container {
    position: relative;
    width: 100%;
    height: 100%;
    overflow: hidden;
}

.ba-img {
    position: absolute;
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.ba-img-before {
    z-index: 2;
    clip-path: inset(0 50% 0 0);
}

.ba-img-after {
    z-index: 1;
}

.ba-handle {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 60px;
    height: 60px;
    background: var(--white);
    border-radius: 50%;
    cursor: ew-resize;
    z-index: 5;
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.3);
    display: flex;
    align-items: center;
    justify-content: center;
}

.ba-handle::before {
    content: '';
    position: absolute;
    top: 0;
    left: 50%;
    transform: translateX(-50%);
    width: 4px;
    height: 100vh;
    background: var(--white);
    z-index: -1;
}

.ba-handle::after {
    content: '◀ ▶';
    font-size: 18px;
    letter-spacing: 4px;
    color: var(--gray-700);
}

.ba-blur {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.3);
    backdrop-filter: blur(15px);
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    z-index: 10;
}

.ba-lock {
    font-size: 48px;
    animation: ba-pulse 2s infinite;
}

@keyframes ba-pulse {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.1); }
}

/* 반응형 */
@media (max-width: 768px) {
    .ba-slider-layout {
        flex-direction: column;
    }
    
    .ba-slider-info {
        flex: 1;
        width: 100%;
    }
}
</style>

<script>
// 이미지 클릭 처리
function handleSliderClick(id, isLoggedIn) {
    if (!isLoggedIn) {
        Swal.fire({
            icon: 'warning',
            title: '로그인이 필요합니다',
            html: '의료법 제56조에 따라<br>치료 결과는 회원에게만 공개됩니다',
            confirmButtonText: '로그인하기',
            confirmButtonColor: '#007bff',
            showCancelButton: true,
            cancelButtonText: '취소'
        }).then((result) => {
            if (result.isConfirmed) {
                location.href = '/bbs/login.php';
            }
        });
    }
}

// 슬라이더 드래그 기능
document.addEventListener('DOMContentLoaded', function() {
    const sliders = document.querySelectorAll('.ba-slider-wrap');
    
    sliders.forEach(slider => {
        const handle = slider.querySelector('.ba-handle');
        const beforeImg = slider.querySelector('.ba-img-before');
        
        if (!handle || !beforeImg) return;
        
        let isDragging = false;
        
        function updateSlider(clientX) {
            const rect = slider.getBoundingClientRect();
            const x = clientX - rect.left;
            const percentage = (x / rect.width) * 100;
            const clampedPercentage = Math.max(0, Math.min(100, percentage));
            
            handle.style.left = clampedPercentage + '%';
            beforeImg.style.clipPath = `inset(0 ${100 - clampedPercentage}% 0 0)`;
        }
        
        // 마우스 이벤트
        handle.addEventListener('mousedown', () => {
            isDragging = true;
        });
        
        document.addEventListener('mousemove', (e) => {
            if (isDragging) {
                updateSlider(e.clientX);
            }
        });
        
        document.addEventListener('mouseup', () => {
            isDragging = false;
        });
        
        // 터치 이벤트
        handle.addEventListener('touchstart', () => {
            isDragging = true;
        });
        
        document.addEventListener('touchmove', (e) => {
            if (isDragging) {
                updateSlider(e.touches[0].clientX);
            }
        });
        
        document.addEventListener('touchend', () => {
            isDragging = false;
        });
    });
});
</script>