<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>갤러리 모듈 테스트</title>
    
    <!-- Swiper CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">
    
    <!-- Setting CSS - 디자인 시스템 -->
    <link rel="stylesheet" href="/css/setting.css">
    
    <!-- Gallery CSS -->
    <link rel="stylesheet" href="/page/gallery.css">
    
    <style>
        body {
            margin: 0;
            padding: var(--sp-20);
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: var(--gray-100);
        }
        
        .test-section {
            margin: var(--sp-40) 0;
            padding: var(--sp-40);
            background: var(--white);
            border-radius: var(--sp-12);
        }
        
        .test-title {
            margin-bottom: var(--sp-32);
            padding-bottom: var(--sp-10);
            border-bottom: 2px solid var(--gray-800);
        }
        
        .page-title {
            text-align: center;
            margin: var(--sp-40) 0;
        }
    </style>
</head>
<body>

    <h1 class="page-title t-fs-40">갤러리 모듈 테스트</h1>

    <!-- 테스트 1: 기본 Swiper -->
    <div class="test-section">
        <h2 class="test-title t-fs-24">1. 기본 슬라이드 (gallery_swiper_basic)</h2>
        
        <div class="gallery-swiper-basic" id="testSwiper1">
            <div class="swiper">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <img src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?w=800" alt="시설 1">
                    </div>
                    <div class="swiper-slide">
                        <img src="https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?w=800" alt="시설 2">
                    </div>
                    <div class="swiper-slide">
                        <img src="https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=800" alt="시설 3">
                    </div>
                </div>
                <div class="swiper-pagination"></div>
                <div class="swiper-button-prev"></div>
                <div class="swiper-button-next"></div>
            </div>
        </div>
    </div>

    <!-- 테스트 2: 썸네일 Swiper -->
    <div class="test-section">
        <h2 class="test-title t-fs-24">2. 썸네일 네비게이션 (gallery_swiper_thumbnail)</h2>
        
        <div class="gallery-swiper-thumbnail" id="testThumbnail1">
            <div class="swiper swiper-main">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <img src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?w=800" alt="시설 1">
                    </div>
                    <div class="swiper-slide">
                        <img src="https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?w=800" alt="시설 2">
                    </div>
                    <div class="swiper-slide">
                        <img src="https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=800" alt="시설 3">
                    </div>
                    <div class="swiper-slide">
                        <img src="https://images.unsplash.com/photo-1512678080530-7760d81faba6?w=800" alt="시설 4">
                    </div>
                </div>
            </div>
            <div class="swiper swiper-thumbs">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <img src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?w=200" alt="썸네일 1">
                    </div>
                    <div class="swiper-slide">
                        <img src="https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?w=200" alt="썸네일 2">
                    </div>
                    <div class="swiper-slide">
                        <img src="https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=200" alt="썸네일 3">
                    </div>
                    <div class="swiper-slide">
                        <img src="https://images.unsplash.com/photo-1512678080530-7760d81faba6?w=200" alt="썸네일 4">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 테스트 3: Masonry -->
    <div class="test-section">
        <h2 class="test-title t-fs-24">3. 핀터레스트형 (gallery_grid_masonry)</h2>
        
        <div class="gallery-grid-masonry" id="testMasonry1">
            <div class="masonry-item">
                <img src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?w=400&h=300" alt="이미지 1">
            </div>
            <div class="masonry-item">
                <img src="https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?w=400&h=500" alt="이미지 2">
            </div>
            <div class="masonry-item">
                <img src="https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=400&h=400" alt="이미지 3">
            </div>
            <div class="masonry-item">
                <img src="https://images.unsplash.com/photo-1512678080530-7760d81faba6?w=400&h=350" alt="이미지 4">
            </div>
            <div class="masonry-item">
                <img src="https://images.unsplash.com/photo-1631248055466-0b1336bf5e82?w=400&h=450" alt="이미지 5">
            </div>
            <div class="masonry-item">
                <img src="https://images.unsplash.com/photo-1538108149393-fbbd81895907?w=400&h=300" alt="이미지 6">
            </div>
        </div>
    </div>

    <!-- 테스트 4: 3x3 Grid -->
    <div class="test-section">
        <h2 class="test-title t-fs-24">4. 3x3 그리드 (gallery_grid_3x3)</h2>
        
        <div class="gallery-grid-3x3" id="testGrid3x3">
            <div class="grid-item">
                <img src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?w=400" alt="이미지 1">
            </div>
            <div class="grid-item">
                <img src="https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?w=400" alt="이미지 2">
            </div>
            <div class="grid-item">
                <img src="https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=400" alt="이미지 3">
            </div>
            <div class="grid-item">
                <img src="https://images.unsplash.com/photo-1512678080530-7760d81faba6?w=400" alt="이미지 4">
            </div>
            <div class="grid-item">
                <img src="https://images.unsplash.com/photo-1631248055466-0b1336bf5e82?w=400" alt="이미지 5">
            </div>
            <div class="grid-item">
                <img src="https://images.unsplash.com/photo-1538108149393-fbbd81895907?w=400" alt="이미지 6">
            </div>
            <div class="grid-item">
                <img src="https://images.unsplash.com/photo-1585421514284-efb74c2b69ba?w=400" alt="이미지 7">
            </div>
            <div class="grid-item">
                <img src="https://images.unsplash.com/photo-1571772996211-2f02c9727629?w=400" alt="이미지 8">
            </div>
            <div class="grid-item">
                <img src="https://images.unsplash.com/photo-1526256262350-7da7584cf5eb?w=400" alt="이미지 9">
            </div>
        </div>
    </div>

    <!-- 테스트 5: 좌측 제목 -->
    <div class="test-section">
        <h2 class="test-title t-fs-24">5. 좌측 제목 + 우측 슬라이드 (gallery_swiper_left_title)</h2>
        
        <div class="gallery-swiper-left-title" id="testLeftTitle1">
            <div class="text-area">
                <h2>병원 시설 안내</h2>
                <p>최신 의료 장비와 쾌적한 환경에서 편안한 진료를 받으실 수 있습니다.</p>
            </div>
            <div class="swiper-area">
                <div class="swiper">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <img src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?w=800" alt="시설 1">
                        </div>
                        <div class="swiper-slide">
                            <img src="https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?w=800" alt="시설 2">
                        </div>
                        <div class="swiper-slide">
                            <img src="https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=800" alt="시설 3">
                        </div>
                    </div>
                    <div class="swiper-pagination"></div>
                    <div class="swiper-button-prev"></div>
                    <div class="swiper-button-next"></div>
                </div>
            </div>
        </div>
    </div>

    <!-- 테스트 6: 우측 제목 -->
    <div class="test-section">
        <h2 class="test-title t-fs-24">6. 좌측 슬라이드 + 우측 제목 (gallery_swiper_right_title)</h2>
        
        <div class="gallery-swiper-right-title" id="testRightTitle1">
            <div class="swiper-area">
                <div class="swiper">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <img src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?w=800" alt="시설 1">
                        </div>
                        <div class="swiper-slide">
                            <img src="https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?w=800" alt="시설 2">
                        </div>
                        <div class="swiper-slide">
                            <img src="https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=800" alt="시설 3">
                        </div>
                    </div>
                    <div class="swiper-pagination"></div>
                    <div class="swiper-button-prev"></div>
                    <div class="swiper-button-next"></div>
                </div>
            </div>
            <div class="text-area">
                <h2>진료 프로세스</h2>
                <p>체계적인 진료 시스템으로 최상의 의료 서비스를 제공합니다.</p>
            </div>
        </div>
    </div>

    <!-- 테스트 7: 텍스트 페이지네이션 (상단) -->
    <div class="test-section">
        <h2 class="test-title t-fs-24">7. 텍스트 페이지네이션 상단 (gallery_swiper_text_pagination_top)</h2>
        
        <div class="gallery-swiper-text-pagination-top" id="testTextTop1">
            <div class="text-pagination-top">
                <div class="text-bullet active" data-index="0">
                    <span class="bullet-number">1</span>
                    <span class="bullet-text">접수데스크</span>
                </div>
                <div class="text-bullet" data-index="1">
                    <span class="bullet-number">2</span>
                    <span class="bullet-text">대기실</span>
                </div>
                <div class="text-bullet" data-index="2">
                    <span class="bullet-number">3</span>
                    <span class="bullet-text">상담실</span>
                </div>
                <div class="text-bullet" data-index="3">
                    <span class="bullet-number">4</span>
                    <span class="bullet-text">진료실</span>
                </div>
            </div>
            <div class="swiper">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <img src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?w=800" alt="데스크">
                    </div>
                    <div class="swiper-slide">
                        <img src="https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?w=800" alt="대기실">
                    </div>
                    <div class="swiper-slide">
                        <img src="https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=800" alt="상담실">
                    </div>
                    <div class="swiper-slide">
                        <img src="https://images.unsplash.com/photo-1512678080530-7760d81faba6?w=800" alt="진료실">
                    </div>
                </div>
                <div class="swiper-button-prev"></div>
                <div class="swiper-button-next"></div>
            </div>
        </div>
    </div>

    <!-- 테스트 8: 텍스트 페이지네이션 (하단) -->
    <div class="test-section">
        <h2 class="test-title t-fs-24">8. 텍스트 페이지네이션 하단 (gallery_swiper_text_pagination_bottom)</h2>
        
        <div class="gallery-swiper-text-pagination-bottom" id="testTextBottom1">
            <div class="swiper">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <img src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?w=800" alt="1단계">
                    </div>
                    <div class="swiper-slide">
                        <img src="https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?w=800" alt="2단계">
                    </div>
                    <div class="swiper-slide">
                        <img src="https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=800" alt="3단계">
                    </div>
                    <div class="swiper-slide">
                        <img src="https://images.unsplash.com/photo-1512678080530-7760d81faba6?w=800" alt="4단계">
                    </div>
                </div>
                <div class="swiper-button-prev"></div>
                <div class="swiper-button-next"></div>
            </div>
            <div class="text-pagination-bottom">
                <div class="text-bullet active" data-index="0">
                    <span class="bullet-number">1</span>
                    <span class="bullet-text">정밀진단</span>
                </div>
                <div class="text-bullet" data-index="1">
                    <span class="bullet-number">2</span>
                    <span class="bullet-text">맞춤치료</span>
                </div>
                <div class="text-bullet" data-index="2">
                    <span class="bullet-number">3</span>
                    <span class="bullet-text">사후관리</span>
                </div>
                <div class="text-bullet" data-index="3">
                    <span class="bullet-number">4</span>
                    <span class="bullet-text">안심케어</span>
                </div>
            </div>
        </div>
    </div>

    <!-- 테스트 9: 썸네일 + 텍스트 -->
    <div class="test-section">
        <h2 class="test-title t-fs-24">9. 썸네일 + 텍스트 (gallery_swiper_thumbnail_text)</h2>
        
        <div class="gallery-swiper-thumbnail-text" id="testThumbnailText1">
            <div class="swiper swiper-main">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <img src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?w=800" alt="시설 1">
                        <div class="slide-caption">최신 장비를 갖춘 진료실</div>
                    </div>
                    <div class="swiper-slide">
                        <img src="https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?w=800" alt="시설 2">
                        <div class="slide-caption">쾌적한 대기 공간</div>
                    </div>
                    <div class="swiper-slide">
                        <img src="https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=800" alt="시설 3">
                        <div class="slide-caption">프라이빗 상담실</div>
                    </div>
                    <div class="swiper-slide">
                        <img src="https://images.unsplash.com/photo-1512678080530-7760d81faba6?w=800" alt="시설 4">
                        <div class="slide-caption">첨단 의료 장비</div>
                    </div>
                </div>
            </div>
            <div class="swiper swiper-thumbs-text">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <img src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?w=200" alt="썸네일 1">
                        <div class="thumb-title">진료실</div>
                    </div>
                    <div class="swiper-slide">
                        <img src="https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?w=200" alt="썸네일 2">
                        <div class="thumb-title">대기실</div>
                    </div>
                    <div class="swiper-slide">
                        <img src="https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=200" alt="썸네일 3">
                        <div class="thumb-title">상담실</div>
                    </div>
                    <div class="swiper-slide">
                        <img src="https://images.unsplash.com/photo-1512678080530-7760d81faba6?w=200" alt="썸네일 4">
                        <div class="thumb-title">장비</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 테스트 10: 이미지 캡션형 -->
    <div class="test-section">
        <h2 class="test-title t-fs-24">10. 이미지 캡션형 (gallery_swiper_caption)</h2>
        
        <div class="gallery-swiper-caption" id="testCaption1">
            <div class="swiper">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <div class="slide-image">
                            <img src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?w=800" alt="시설 1">
                        </div>
                        <div class="slide-caption-text">최신 시설로 구비된 쾌적한 진료 환경입니다.</div>
                    </div>
                    <div class="swiper-slide">
                        <div class="slide-image">
                            <img src="https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?w=800" alt="시설 2">
                        </div>
                        <div class="slide-caption-text">편안한 대기 공간에서 여유롭게 진료를 기다리실 수 있습니다.</div>
                    </div>
                    <div class="swiper-slide">
                        <div class="slide-image">
                            <img src="https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=800" alt="시설 3">
                        </div>
                        <div class="slide-caption-text">프라이버시가 보장되는 독립된 상담 공간을 제공합니다.</div>
                    </div>
                </div>
                <div class="swiper-pagination"></div>
                <div class="swiper-button-prev"></div>
                <div class="swiper-button-next"></div>
            </div>
        </div>
    </div>

    <!-- Swiper JS -->
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    
    <!-- Gallery JS -->
    <script src="/page/gallery.js"></script>
    
    <!-- 초기화 -->
    <script>
        initSwiperBasic('testSwiper1');
        initSwiperThumbnail('testThumbnail1');
        initGridMasonry('testMasonry1');
        initGrid3x3('testGrid3x3');
        initSwiperLeftTitle('testLeftTitle1');
        initSwiperRightTitle('testRightTitle1');
        initSwiperTextPaginationTop('testTextTop1');
        initSwiperTextPaginationBottom('testTextBottom1');
        initSwiperThumbnailText('testThumbnailText1');
        initSwiperCaption('testCaption1');
        
        console.log('✅ 모든 갤러리 초기화 완료 (10가지 타입)');
    </script>
</body>
</html>