<?php
// 패럴렉스 데이터 가져오기
if (!defined('_GNUBOARD_')) {
    include_once($_SERVER['DOCUMENT_ROOT'] . '/_common.php');
}
$parallax_table = 'dm_parallax_items';

// 테이블 존재 확인
$table_check = sql_query("SHOW TABLES LIKE '{$parallax_table}'", false);
if (!$table_check || sql_num_rows($table_check) == 0) {
    return;
}

// 섹션 제목 가져오기
$section_sql = "SELECT section_title FROM {$parallax_table} LIMIT 1";
$section_result = sql_query($section_sql, false);
$section_title = "특별한 진료 시스템";
if ($section_result && sql_num_rows($section_result) > 0) {
    $section_row = sql_fetch_array($section_result);
    if (!empty($section_row['section_title'])) {
        $section_title = $section_row['section_title'];
    }
}

// 노출 가능한 항목만 가져오기
$sql = "SELECT * FROM {$parallax_table} WHERE is_visible = 1 ORDER BY display_order ASC, id ASC";
$result = sql_query($sql, false);

if (!$result || sql_num_rows($result) == 0) {
    return;
}

$items = [];
while ($row = sql_fetch_array($result)) {
    $items[] = $row;
}

$totalItems = count($items);
if ($totalItems == 0) return;
?>

<!-- GSAP 라이브러리 -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js"></script>

<!-- ID 변경: special-parallax-db -->
<section id="special-parallax-db" class="parallax-scroll-fixed flex-column">
    <div class="p-header u-mb-48 text-center">
        <h2 class="t-fs-52"><?= htmlspecialchars($section_title) ?></h2>
    </div>

    <div class="p-wrapper u-mt-48">
        <div class="p-content u-gap-40">
            <!-- 좌측: 번호 -->
            <div class="p-left-box text-center">
                <?php foreach ($items as $index => $item): ?>
                    <div class="p-item p-num c-fs-24 <?= $index === 0 ? 'active' : '' ?>" data-index="<?= $index ?>">
                        <strong><?= htmlspecialchars($item['number']) ?></strong>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- 중앙: 이미지 -->
            <div class="p-center-box">
                <?php foreach ($items as $index => $item): ?>
                    <div class="p-item p-img <?= $index === 0 ? 'active' : '' ?>" data-index="<?= $index ?>">
                        <?php if ($item['image']): ?>
                            <img src="<?= htmlspecialchars($item['image']) ?>" 
                                 alt="<?= htmlspecialchars($item['title']) ?>">
                        <?php else: ?>
                            <div style="width: 100%; height: 100%; background: #222; display: flex; align-items: center; justify-content: center; color: #666;">
                                이미지 없음
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- 우측: 텍스트 -->
            <div class="p-right-box">
                <?php foreach ($items as $index => $item): ?>
                    <div class="p-item p-text <?= $index === 0 ? 'active' : '' ?>" data-index="<?= $index ?>">
                        <h3 class="t-fs-32"><?= htmlspecialchars($item['title']) ?></h3>
                        <p><?= nl2br(htmlspecialchars($item['description'])) ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- 도트 네비게이션 -->
    <div class="p-dots">
        <?php foreach ($items as $index => $item): ?>
            <div class="dot <?= $index === 0 ? 'active' : '' ?>" data-index="<?= $index ?>"></div>
        <?php endforeach; ?>
    </div>
</section>

<style>
/* 패럴렉스 - 높이 고정 */
.parallax-scroll-fixed {
  position: relative;
  width: 100%;
  height: 100vh;
  background: #000;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  margin: 0 auto;
  padding: 0 var(--sp-20);
}

.p-header {
  width: 100%;
  text-align: center;
  margin-bottom: 48px;
}

.p-wrapper {
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
}

.p-content {
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  height: 500px;
  gap: 40px;
  width: 100%;
}

/* 공통 아이템 설정 */
.p-left-box,
.p-center-box,
.p-right-box {
  position: relative;
  height: 100%;
}

.p-left-box {
  flex: 0 0 150px;
}

.p-center-box {
  flex: 0 0 800px;
  background: #111;
  border-radius: 24px;
  overflow: hidden;
}

.p-right-box {
  flex: 0 0 200px;
}

.p-item {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 100%;
  opacity: 0;
  visibility: hidden;
  pointer-events: none;
  transition: opacity 0.5s ease, visibility 0.5s ease;
  z-index: 0;
}

.p-item.active {
  opacity: 1;
  visibility: visible;
  pointer-events: auto;
  z-index: 1;
}

.p-item > * {
  color: #fff;
}

.p-img {
  top: 0;
  left: 0;
  transform: none;
  height: 100%;
}

.p-img img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

/* 도트 네비게이션 */
.p-dots {
  position: absolute;
  bottom: 40px;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  gap: 12px;
  z-index: 10;
}

.dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.3);
  cursor: pointer;
  transition: all 0.3s ease;
}

.dot.active {
  background: #fff;
  width: 30px;
  border-radius: 5px;
}

/* 모바일 전용 (768px 이하) */
@media (max-width: 768px) {
  .parallax-scroll-fixed {
    height: auto;
    min-height: 100vh;
    padding: 40px var(--sp-20);
  }

  .p-header {
    margin-bottom: 30px;
  }

  .p-header h2 {
    font-size: 24px;
  }

  .p-content {
    flex-direction: column;
    height: auto;
    gap: 20px;
  }

  .p-left-box {
    order: 1;
    height: 60px;
    width: 100%;
    flex: 0 0 60px;
  }

  .p-left-box .p-item {
    top: 50%;
  }

  .p-center-box {
    order: 2;
    height: 300px;
    width: 100%;
    flex: 0 0 300px;
  }

  .p-right-box {
    order: 3;
    height: 150px;
    width: 100%;
    flex: 0 0 150px;
  }

  .p-right-box .p-item {
    top: 50%;
  }

  .p-num {
    font-size: 28px;
    text-align: center;
  }

  .p-text {
    text-align: center;
    padding: 0 20px !important;
  }

  .p-text h3 {
    font-size: 22px;
  }

  .p-text p {
    font-size: 14px;
  }

  .p-img img {
    aspect-ratio: 1/1;
  }

  .p-dots {
    position: relative;
    bottom: auto;
    margin-top: 30px;
  }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    if (typeof gsap === 'undefined') return;
    
    gsap.registerPlugin(ScrollTrigger);

    // ID 변경
    const section = document.querySelector('#special-parallax-db');
    if (!section) return;

    const nums = section.querySelectorAll('.p-num');
    const imgs = section.querySelectorAll('.p-img');
    const txts = section.querySelectorAll('.p-text');
    const dots = section.querySelectorAll('.dot');
    const totalItems = <?= $totalItems ?>;
    
    if (totalItems === 0) return;

    let currentIndex = 0;
    let isScrolling = false;

    // 초기화 함수
    function activateIndex(index) {
        nums.forEach((el, i) => el.classList.toggle('active', i === index));
        imgs.forEach((el, i) => el.classList.toggle('active', i === index));
        txts.forEach((el, i) => el.classList.toggle('active', i === index));
        dots.forEach((el, i) => el.classList.toggle('active', i === index));
    }

    // 마우스 휠 이벤트로 제어
    section.addEventListener('wheel', (e) => {
        if (isScrolling) {
            e.preventDefault();
            return;
        }
        
        // 경계에서는 페이지 스크롤 허용
        if ((e.deltaY > 0 && currentIndex === totalItems - 1) || 
            (e.deltaY < 0 && currentIndex === 0)) {
            return;
        }
        
        e.preventDefault();
        isScrolling = true;

        if (e.deltaY > 0 && currentIndex < totalItems - 1) {
            currentIndex++;
            activateIndex(currentIndex);
        } else if (e.deltaY < 0 && currentIndex > 0) {
            currentIndex--;
            activateIndex(currentIndex);
        }

        setTimeout(() => {
            isScrolling = false;
        }, 600);
    }, { passive: false });

    // 도트 클릭
    dots.forEach((dot, idx) => {
        dot.addEventListener('click', () => {
            currentIndex = idx;
            activateIndex(idx);
        });
    });
});
</script>