<!DOCTYPE html>
<html lang="ko">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>5가지 헤더 타입 - 탭 형식</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="/css/setting.css">
    <style>
        body {
            font-family: "Pretendard", -apple-system, BlinkMacSystemFont, system-ui, sans-serif;
        }

        /* 탭 컨트롤 영역 */
        .tab-controls {
            background: var(--gray-100);
            border-bottom: 2px solid var(--gray-300);
            position: sticky;
            top: 0;
            z-index: var(--z-sticky);
        }

        .tab-btn {
            background: transparent;
            border: none;
            padding: var(--sp-16) var(--sp-24);
            cursor: pointer;
            color: var(--c-color);
            font-weight: 500;
            transition: all 0.3s;
            border-bottom: 3px solid transparent;
            white-space: nowrap;
        }

        .tab-btn:hover {
            background: var(--gray-200);
            color: var(--main-color);
        }

        .tab-btn.active {
            color: var(--main-color);
            border-bottom-color: var(--main-color);
            background: var(--white);
        }

        .tab-content-wrapper {
            display: none;
        }

        .tab-content-wrapper.active {
            display: block;
        }

        /* 헤더 공통 스타일 */
        .demo-header {
            background: var(--white);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            position: relative;
        }

        .header-container {
            height: 80px;
        }

        .logo {
            font-weight: 700;
            color: var(--main-color);
        }

        /* 1번: Flyout 타입 */
        .header-flyout .menu {
            list-style: none;
            padding: 0;
            margin: 0;
            width: 100%;
            max-width: 1200px;
            /* display: flex;
            gap: var(--sp-32); */
        }

        .header-flyout .menu>li {
            position: relative;
            padding: var(--sp-10) 0;
        }

        .header-flyout .menu>li>a {
            text-decoration: none;
            color: var(--t-color);
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: var(--sp-4);
            transition: color 0.3s;
        }

        .header-flyout .menu>li:hover>a {
            color: var(--main-color);
        }

        .header-flyout .submenu {
            position: absolute;
            top: 100%;
            left: 0;
            background: var(--white);
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12);
            list-style: none;
            padding: var(--sp-12) 0;
            margin: 0;
            width: 100%;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s;
            border-radius: var(--sp-8);
        }

        .header-flyout .menu>li:hover .submenu {
            opacity: 1;
            visibility: visible;
        }

        .header-flyout .submenu li a {
            display: block;
            padding: var(--sp-12) var(--sp-20);
            color: var(--c-color);
            text-decoration: none;
            transition: all 0.3s;
        }

        .header-flyout .submenu li:hover {
            background: var(--main-color);
        }

        .header-flyout .submenu li:hover a {
            color: var(--white);
            padding-left: var(--sp-24);
        }

        /* 2번: 3단 Flyout 타입 */
        .header-flyout-3level .menu {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
            width: auto;
            max-width: 1200px;
            background-color: var(--main-color);
        }

        .header-flyout-3level .menu>li {
            position: relative;

        }

        .header-flyout-3level .menu>li>a {
            text-decoration: none;
            color: var(--white);
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: var(--sp-4);
            transition: color 0.3s;
        }

        .header-flyout-3level .menu>li:hover>a {
            color: var(--point);
        }

        .header-flyout-3level .submenu {
            position: absolute;
            top: calc(100% + var(--sp-20));
            left: 0;
            background: var(--main-color);
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12);
            list-style: none;

            margin: 0;

            opacity: 0;
            visibility: hidden;
            transition: all 0.3s;
            border-radius: var(--sp-8);

        }

        .header-flyout-3level .menu>li:hover>.submenu {
            opacity: 1;
            visibility: visible;
        }

        .header-flyout-3level .submenu li {
            position: relative;
            height: var(--sp-40);
        }

        .header-flyout-3level .submenu li a {
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: var(--white);
            text-decoration: none;
            transition: all 0.3s;
            font-weight: 600;
            line-height: 1.5;

        }

        .header-flyout-3level .submenu li:hover {
            background: var(--main-color);
        }

        .header-flyout-3level .submenu li:hover>a {
            color: var(--point);
        }

        .header-flyout-3level .submenu-level3 {
            position: absolute;
            top: 0;
            left: 120%;
            background: var(--main-color);
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12);
            list-style: none;
            margin: 0;
            width: max-content;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s;
            border-radius: var(--sp-20);
        }

        .header-flyout-3level .submenu li:hover .submenu-level3 {
            opacity: 1;
            visibility: visible;
        }

        /* 3번: 메가메뉴 타입 - 좌우 정렬 완벽 버전 */
        .header-mega .header-container {
            position: relative;
            max-width: 1920px;
            margin: 0 auto;
            padding: 0 60px;
        }

        .header-mega .header-wrapper {
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 100%;
            gap: 40px;
        }

        .header-mega .logo {
            flex-shrink: 0;
            width: 180px;
            /* 로고 고정 너비 */
        }

        .header-mega .logo a {
            display: block;
            width: 100%;
        }

        .header-mega .logo a img {
            width: 100%;
        }

        .header-mega .menu-wrapper {
            flex: 1;
            display: flex;
            justify-content: space-between;
            position: relative;
            height: 100%;
        }

        .header-mega .menu {
            list-style: none;
            padding: 0;
            margin: 0;
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 0;
            width: 100%;
            max-width: 1200px;
            height: 100%;
        }

        .header-mega .menu>li {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100%;
            border-bottom: 3px solid transparent;
            transition: all 0.3s;
            position: relative;
        }

        .header-mega .menu>li>a {
            text-decoration: none;
            color: var(--t-color);
            font-weight: 500;
            transition: color 0.3s;
            white-space: nowrap;
            padding: 0 10px;
            text-align: center;
        }

        .header-mega .menu>li:hover {
            border-bottom-color: var(--main-color);
        }

        .header-mega .menu>li:hover>a {
            color: var(--main-color);
        }

        .header-mega .menu>li.active {
            /* border-bottom-color: var(--blue); */
            border-bottom: 3px solid var(--blue);
        }

        .header-mega .menu>li.active>a {
            color: var(--blue);
        }

        .header-mega .promo-slider {
            flex-shrink: 0;
            width: auto;
            /* 슬라이더 고정 너비 */
        }

        .header-mega .megamenu {
            position: fixed;
            top: 140px;
            left: 0;
            width: 100vw;
            background: var(--white);
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12);
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s;
            z-index: 1000;
        }

        .header-mega .menu-wrapper:hover+.promo-slider+.megamenu,
        .header-mega .megamenu:hover {
            opacity: 1;
            visibility: visible;
        }

        /* 핵심: 메가메뉴 내부 구조를 헤더와 동일하게 */
        .header-mega .megamenu-content {
            max-width: 1920px;
            margin: 0 auto;
            padding: 0 60px var(--sp-40) 60px;
            /* 헤더와 동일한 좌우 패딩 */
            display: flex;
            gap: 40px;
            /* 헤더와 동일한 gap */
        }

        /* 로고 자리 (빈 공간) */
        .header-mega .megamenu-content::before {
            content: '';
            width: 180px;
            /* 로고와 동일한 너비 */
            flex-shrink: 0;
        }

        /* 메뉴 컬럼들 */
        .header-mega .megamenu-columns {
            flex: 1;
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            max-width: 1200px;
            /* gap: var(--sp-30); */
        }

        /* 슬라이더 자리 (빈 공간) */
        .header-mega .megamenu-content::after {
            content: '';
            width: 240px;
            /* 슬라이더와 동일한 너비 */
            flex-shrink: 0;
        }

        .header-mega .megamenu-column {
            opacity: 0.3;
            transition: opacity 0.3s;
        }

        .header-mega .megamenu-column.active {
            background-color: var(--light);
        }

        .header-mega .megamenu-column.active {
            opacity: 1;
        }

        .header-mega .megamenu-column h4 {
            font-weight: 700;
            margin-bottom: var(--sp-16);
            color: var(--main-color);
            white-space: nowrap;
            text-align: center;
        }

        .header-mega .megamenu-column ul {
            list-style: none;
            padding: 0;
            padding-top: var(--sp-16);
            margin: 0;
        }

        .header-mega .megamenu-column li {
            height: var(--sp-40);
        }

        .header-mega .megamenu-column li a {
            display: block;
            padding: 0;
            color: var(--c-color);
            text-decoration: none;
            transition: all 0.3s;
            white-space: nowrap;
            text-align: center;
        }

        .header-mega .megamenu-column li a:hover {
            color: var(--main-color);
            transform: translateX(5px);
        }

        /* 4번: 4:6 메가메뉴 타입 */
        .header-mega-46 .menu {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
            gap: var(--sp-32);
        }

        .header-mega-46 .menu>li {
            position: relative;
            padding: var(--sp-20) 0;
        }

        .header-mega-46 .menu>li>a {
            text-decoration: none;
            color: var(--t-color);
            font-weight: 500;
            transition: color 0.3s;
        }

        .header-mega-46 .menu>li:hover>a {
            color: var(--main-color);
        }

        .header-mega-46 .megamenu {
            position: fixed;
            /* absolute → fixed로 변경 */
            top: 165px;
            /* 헤더 높이만큼 */
            left: 0;
            /* 50% → 0으로 변경 */
            transform: none;
            /* translateX(-50%) 제거 */
            width: 100vw;
            background: var(--white);
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12);
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s;
        }

        .header-mega-46 .menu>li:hover .megamenu {
            opacity: 1;
            visibility: visible;
        }

        .header-mega-46 .megamenu-content {
            max-width: 1400px;
            margin: 0 auto;
            padding: var(--sp-40) var(--sp-24);
            display: grid;
            grid-template-columns: 40% 60%;
            gap: var(--sp-40);
        }

        .header-mega-46 .megamenu-left ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .header-mega-46 .megamenu-left li a {
            display: block;
            padding: var(--sp-16) var(--sp-20);
            color: var(--c-color);
            text-decoration: none;
            border-radius: var(--sp-8);
            transition: all 0.3s;
            font-weight: 500;
        }

        .header-mega-46 .megamenu-left li a:hover,
        .header-mega-46 .megamenu-left li a.active {
            background: var(--gray-100);
            color: var(--main-color);
        }

        .header-mega-46 .megamenu-right {
            background: var(--gray-100);
            padding: var(--sp-24);
            border-radius: var(--sp-12);
        }

        .header-mega-46 .submenu-detail {
            display: none;
        }

        .header-mega-46 .submenu-detail.active {
            display: block;
        }

        .header-mega-46 .submenu-detail h5 {
            color: var(--main-color);
            margin-bottom: var(--sp-20);
            font-weight: 700;
        }

        .header-mega-46 .submenu-detail ul {
            list-style: none;
            padding: 0;
            margin: 0;
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: var(--sp-12);
        }

        .header-mega-46 .submenu-detail li a {
            display: block;
            padding: var(--sp-10);
            color: var(--c-color);
            text-decoration: none;
            border-radius: var(--sp-4);
            transition: all 0.3s;
        }

        .header-mega-46 .submenu-detail li a:hover {
            color: var(--main-color);
            background: var(--white);
        }

        /* 5번: 슬라이드 포함 헤더 */
        .header-slide .menu {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
            gap: var(--sp-32);
        }

        .header-slide .menu li a {
            text-decoration: none;
            color: var(--t-color);
            font-weight: 500;
            padding: var(--sp-20) 0;
            display: block;
            transition: color 0.3s;
        }

        .header-slide .menu li a:hover {
            color: var(--main-color);
        }

        .promo-slider {
            width: max-content;
            height: var(--sp-48);
            overflow: hidden;
            position: relative;
            background: var(--light);
            border-radius: var(--sp-12);
        }

        .promo-content {
            animation: slideUp 10s infinite;
        }

        .promo-item {
            height: var(--sp-48);
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--dark);
            font-weight: 700;
            padding: 0 var(--sp-20);
            text-align: center;
        }

        @keyframes slideUp {

            0%,
            30% {
                transform: translateY(0);
            }

            33%,
            63% {
                transform: translateY(-48px);
            }

            66%,
            96% {
                transform: translateY(-96px);
            }

            100% {
                transform: translateY(0);
            }
        }

        /* 모바일 헤더 */
        .mobile-header {
            display: none;
            padding: var(--sp-16) 0;
        }

        .mobile-header .logo {
            font-size: 1.25rem;
        }

        .mobile-header .phone-link {
            color: var(--main-color);
            text-decoration: none;
            font-size: 1.5rem;
        }

        .hamburger-btn {
            background: none;
            border: none;
            color: var(--t-color);
            font-size: 1.5rem;
            cursor: pointer;
            padding: 0;
        }

        /* Offcanvas 메뉴 */
        .offcanvas-menu .menu {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .offcanvas-menu .menu li {
            border-bottom: 1px solid var(--gray-200);
        }

        .offcanvas-menu .menu li a {
            display: block;
            padding: var(--sp-16) var(--sp-20);
            color: var(--t-color);
            text-decoration: none;
            transition: all 0.3s;
        }

        .offcanvas-menu .menu li a:hover {
            background: var(--gray-100);
            color: var(--main-color);
        }

        .offcanvas-menu .submenu {
            list-style: none;
            padding-left: var(--sp-20);
            background: var(--gray-100);
        }

        .offcanvas-menu .submenu li a {
            padding: var(--sp-12) var(--sp-20);
        }

        /* 데모 영역 */
        .demo-section {
            padding: var(--sp-60) 0;
            min-height: 60vh;
        }

        /* 반응형 */
        @media (max-width: 991px) {
            .desktop-menu {
                display: none !important;
            }

            .mobile-header {
                display: block !important;
            }

            .tab-controls {
                overflow-x: auto;
                white-space: nowrap;
            }

            .tab-btn {
                padding: var(--sp-12) var(--sp-16);
                font-size: 0.875rem;
            }
        }

        .header-dark-flyout {
            background: var(--dark);
            /* #2c2c2c */
            box-shadow: 0 2px 12px rgba(0, 0, 0, 0.3);
        }

        .header-dark-flyout .header-container {
            height: 80px;
        }

        /* ─── 로고 영역 ─── */
        .hdf-logo__link {
            display: flex;
            align-items: center;
            gap: var(--sp-12);
            text-decoration: none;
        }

        .hdf-logo__img {
            height: 40px;
            width: auto;
        }

        .hdf-logo__text {
            display: flex;
            flex-direction: column;
        }

        .hdf-logo__name {
            color: var(--white);
            font-weight: 700;
            font-size: clamp(1rem, 0.2vw + 0.9rem, 1.125rem);
            /* ~t-fs-18 범위 */
            line-height: 1.3;
        }

        .hdf-logo__sub {
            color: var(--gray-500);
            /* #adb5bd */
            font-size: 0.625rem;
            /* 10px */
            letter-spacing: 0.08em;
            line-height: 1.4;
        }

        /* ─── 상위 메뉴 리스트 ─── */
        .hdf-menu {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
            align-items: center;
            gap: var(--sp-8);
            /* 메뉴 간 간격 */
        }

        /* 각 메뉴 <li> */
        .hdf-menu__item {
            position: relative;
            /* submenu 기준점 */
        }

        /* 메뉴 링크 */
        .hdf-menu__link {
            display: flex;
            align-items: center;
            gap: var(--sp-4);
            text-decoration: none;
            color: var(--white);
            font-weight: 500;
            font-size: clamp(0.9375rem, 0.1vw + 0.9rem, 1rem);
            padding: var(--sp-10) var(--sp-14);
            border-radius: var(--sp-6);
            white-space: nowrap;
            transition: color 0.3s, background 0.3s;
        }

        .hdf-menu__link:hover {
            color: var(--point);
            /* #EDC643 — hover 시 골든 */
            background: rgba(255, 255, 255, 0.06);
        }

        /* 활성 메뉴 — 골든 포인트색 */
        .hdf-menu__item--active .hdf-menu__link {
            color: var(--point);
            /* #EDC643 */
            font-weight: 600;
        }

        /* 드롭다운 아이콘 ▾ */
        .hdf-menu__arrow {
            font-size: 0.7em;
            opacity: 0.6;
            transition: transform 0.25s, opacity 0.25s;
            font-style: normal;
        }

        .hdf-menu__item:hover .hdf-menu__arrow {
            transform: rotate(180deg);
            opacity: 1;
        }


        /* ─── 드롭다운 (submenu) ─── */
        .hdf-submenu {
            position: absolute;
            top: calc(100% + 36px);
            /* gap 없이 바로 아래 (마우스 leave 방지) */
            left: 50%;
            transform: translateX(-50%) translateY(-4px);

            /* 숨김 초기상태 */
            opacity: 0;
            visibility: hidden;
            pointer-events: none;

            /* 등장 트랜지션 */
            transition: opacity 0.25s ease, transform 0.25s ease, visibility 0.25s;

            /* 스타일 */
            background: #484848;
            border-radius: var(--sp-8);
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.4);
            list-style: none;
            padding: var(--sp-6) 0 var(--sp-10);
            margin: 0;
            min-width: 160px;
            z-index: var(--z-header);
            /* 1000 */
        }

        /* ★ 투명 간격 영역 — 상위 메뉴와 submenu 사이 마우스 경로 막음 */
        .hdf-submenu::before {
            content: '';
            position: absolute;
            top: -8px;
            left: 0;
            right: 0;
            height: 8px;
        }

        /* hover 시 등장 */
        .hdf-menu__item:hover .hdf-submenu {
            opacity: 1;
            visibility: visible;
            pointer-events: auto;
            transform: translateX(-50%) translateY(0);
        }

        /* 하위 메뉴 링크 기본 */
        .hdf-submenu li a {
            display: block;
            padding: var(--sp-6) var(--sp-20);
            color: var(--white);
            /* #dee2e6 — 밝은 회색 텍스트 */
            text-decoration: none;
            white-space: nowrap;
            font-size: clamp(0.875rem, 0.08vw + 0.84rem, 0.9375rem);
            transition: color 0.2s, background 0.2s;
            text-align: center;
            border-radius: var(--sp-6);
            width: calc(100% - 20px);
            margin: 0 auto;
        }

        .hdf-submenu li a:hover {
            color: var(--dark);
            background: var(--white)
        }



        /* ─── 우측 홍보 배너 (pill) ─── */
        .hdf-promo {
            display: flex;
            align-items: center;
            gap: var(--sp-10);
            text-decoration: none;
            color: var(--white);
            font-size: clamp(0.8125rem, 0.08vw + 0.78rem, 0.875rem);
            font-weight: 500;
            white-space: nowrap;
            padding: var(--sp-10) var(--sp-20);
            border: 1.5px solid var(--gray-500);
            /* 둘레 테두리 */
            border-radius: 999px;
            /* pill */
            transition: border-color 0.3s, background 0.3s;
        }

        .hdf-promo:hover {
            border-color: var(--point);
            background: rgba(237, 198, 67, 0.08);
        }

        .hdf-promo__icon {
            width: 20px;
            height: 20px;
            flex-shrink: 0;
        }

        #mobileMenu1 ul {
            padding-left: 0;
        }


        #mobileMenu1 .offcanvas-header {
            border-bottom: 1px solid var(--light);
        }

        #mobileMenu1 .offcanvas-menu .menu li a {
            display: block;
            padding: var(--sp-16) var(--sp-20);
            color: var(--dark);
            text-decoration: none;
            font-size: var(--sp-26);
            font-weight: 500;
            transition: all 0.3s;
        }

        #mobileMenu1 .offcanvas-menu .submenu li {
            background-color: var(--light);
        }

        #mobileMenu1 .offcanvas-menu .submenu li a {
            color: var(--dark);
            font-size: var(--sp-24);
            font-weight: 500;
        }

        #mobileMenu1 [data-bs-toggle="collapse"] i {
            transition: transform 0.3s ease;
        }

        #mobileMenu1 [data-bs-toggle="collapse"][aria-expanded="true"] i {
            transform: rotate(180deg);
        }

        #mobileMenu2 {
            background-color: var(--main-color);
        }

        #mobileMenu2 ul {
            padding-left: 0;
        }


        #mobileMenu2 .offcanvas-menu .menu li a {
            display: block;
            padding: var(--sp-16) var(--sp-20);
            color: var(--white);
            text-decoration: none;
            font-size: var(--sp-26);
            font-weight: 500;
            transition: all 0.3s;
            display: flex;
            justify-content: center;
            background-color: var(--main-color);
            gap: var(--sp-14);
        }

        #mobileMenu2 .offcanvas-menu .submenu li {
            /* background-color: var(--light); */
        }

        #mobileMenu2 .offcanvas-menu .menu li {
            border: none;
        }

        #mobileMenu2 .offcanvas-menu .submenu li a {
            color: var(--white);
            font-size: var(--sp-24);
            font-weight: 500;
        }

        #mobileMenu2 [data-bs-toggle="collapse"] img {
            transition: transform 0.3s ease;
        }

        #mobileMenu2 [data-bs-toggle="collapse"][aria-expanded="true"] img {
            transform: rotate(180deg);
        }

        #mobileMenu5.offcanvas-dark {
            background-color: #2d2d2d;
            color: white;
        }

        #mobileMenu5 .offcanvas-header {
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        /* 모바일 메뉴 리스트 */
        #mobileMenu5 .mobile-menu-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        #mobileMenu5 .mobile-menu-item {
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        /* 메인 메뉴 링크 */
        #mobileMenu5 .mobile-menu-link {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: var(--sp-24) var(--sp-28) var(--sp-24)  0;
            color: white;
            text-decoration: none;
            font-weight: 600;
            font-size: var(--sp-30);
            transition: background 0.3s;
        }

        #mobileMenu5 .mobile-menu-link:hover {
            background: var(--dark);
            color: white;
        }

        #mobileMenu5 .mobile-menu-link i {
            transition: transform 0.3s ease;
            font-size: 1rem;
        }

        #mobileMenu5 .mobile-menu-link[aria-expanded="true"] i {
            transform: rotate(180deg);
        }

        /* 서브메뉴 */
        #mobileMenu5 .mobile-submenu {
            list-style: none;
            padding: 0;
            margin: 0;
            background: var(--dark)
        }

        #mobileMenu5 .mobile-submenu-link {
            display: block;
            padding: var(--sp-12) var(--sp-20) var(--sp-12) 0;
            color: #bebebe;
            text-decoration: none;
            font-size: clamp(0.875rem, 0.08vw + 0.84rem, 0.9375rem);
            transition: all 0.3s;
        }

        #mobileMenu5 .mobile-submenu-link:hover {
            background: rgba(255, 255, 255, 0.05);
            color: white;
            padding-left: var(--sp-44);
        }
        #mobileMenu5 {
            width: 80%!important;
        }
    </style>
</head>

<body class="u-pretendard">

    <!-- 탭 컨트롤 -->
    <div class="tab-controls">
        <div class="container">
            <div class="d-flex">
                <button class="tab-btn active" onclick="switchTab(1)">
                    <i class="bi bi-1-circle-fill me-2"></i>Flyout
                </button>
                <button class="tab-btn" onclick="switchTab(2)">
                    <i class="bi bi-2-circle-fill me-2"></i>3단 Flyout
                </button>
                <button class="tab-btn" onclick="switchTab(3)">
                    <i class="bi bi-3-circle-fill me-2"></i>메가메뉴
                </button>
                <button class="tab-btn" onclick="switchTab(4)">
                    <i class="bi bi-4-circle-fill me-2"></i>4:6 메가메뉴
                </button>
                <button class="tab-btn" onclick="switchTab(5)">
                    <i class="bi bi-5-circle-fill me-2"></i>슬라이드
                </button>
            </div>
        </div>
    </div>

    <!-- 1번: Flyout 타입 -->
    <div class="tab-content-wrapper active" id="tab1">
        <header class="demo-header header-flyout">
            <!-- 데스크탑 메뉴 -->
            <div class="u-1920 header-container desktop-menu">
                <div class="d-flex justify-content-between align-items-center h-100 u-px-60 u-gap-60">
                    <div class="logo t-fs-24">
                        <a href="/">
                            <img src="/images/logo_ex.png" alt="LOGO">
                        </a>
                    </div>
                    <ul class="menu u-gap-30 g-auto-flow">
                        <li>
                            <a href="#" class="t-fs-18 fw-600 text-center justify-content-center">
                                마음담은치과 소개 </i>
                            </a>
                            <ul class="submenu">
                                <li><a href="#" class="c-fs-16 text-center">일반진료</a></li>
                                <li><a href="#" class="c-fs-16 text-center">임플란트</a></li>
                                <li><a href="#" class="c-fs-16 text-center">교정치료</a></li>
                                <li><a href="#" class="c-fs-16 text-center">심미치료</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#" class="t-fs-18 fw-600 text-center justify-content-center">
                                치료사례 </i>
                            </a>
                            <ul class="submenu">
                                <li><a href="#" class="c-fs-16 text-center">인사말</a></li>
                                <li><a href="#" class="c-fs-16 text-center">의료진소개</a></li>
                                <li><a href="#" class="c-fs-16 text-center">시설안내</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#" class="t-fs-18 fw-600 text-center justify-content-center">
                                임플란트 </i>
                            </a>
                            <ul class="submenu">
                                <li><a href="#" class="c-fs-16 text-center">인사말</a></li>
                                <li><a href="#" class="c-fs-16 text-center">의료진소개</a></li>
                                <li><a href="#" class="c-fs-16 text-center">시설안내</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#" class="t-fs-18 fw-600 text-center justify-content-center">
                                소아진료 </i>
                            </a>
                            <ul class="submenu">
                                <li><a href="#" class="c-fs-16 text-center">인사말</a></li>
                                <li><a href="#" class="c-fs-16 text-center">의료진소개</a></li>
                                <li><a href="#" class="c-fs-16 text-center">시설안내</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#" class="t-fs-18 fw-600 text-center justify-content-center">
                                통증 경감 시스템 </i>
                            </a>
                            <ul class="submenu">
                                <li><a href="#" class="c-fs-16 text-center">인사말</a></li>
                                <li><a href="#" class="c-fs-16 text-center">의료진소개</a></li>
                                <li><a href="#" class="c-fs-16 text-center">시설안내</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#" class="t-fs-18 fw-600 text-center justify-content-center">
                                고객센터 </i>
                            </a>
                            <ul class="submenu">
                                <li><a href="#" class="c-fs-16 text-center">공지사항</a></li>
                                <li><a href="#" class="c-fs-16 text-center">자주묻는질문</a></li>
                                <li><a href="#" class="c-fs-16 text-center">온라인상담</a></li>
                            </ul>
                        </li>
                        <li><a href="#" class="t-fs-18 fw-600 text-center justify-content-center">오시는길</a></li>
                    </ul>
                    <!-- 슬라이더 -->
                    <div class="promo-slider rounded-full">
                        <div class="promo-content">
                            <div class="promo-item c-fs-18 fw-500 rounded-full u-gap-4"><img src="/images/tg.svg" alt="">보건복지부인증 통합치의학과 전문의</div>
                            <div class="promo-item c-fs-18 fw-500 rounded-full u-gap-4"><img src="/images/tg.svg" alt="">20년 경력의 통합치의학과 전문의</div>
                            <div class="promo-item c-fs-18 fw-500 rounded-full u-gap-4"><img src="/images/tg.svg" alt="">보건복지부인증 첨단 장비 완비</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 모바일 헤더 -->
            <div class="header-container mobile-header">
                <div class="d-flex justify-content-between align-items-center u-p-20">

                    <div class="logo t-fs-24">
                        <a href="/">
                            <img src="/images/logo_ex.png" alt="LOGO">
                        </a>
                    </div>
                    <!-- <a href="tel:032-123-4567" class="phone-link">
                        <i class="bi bi-telephone-fill"></i>
                    </a> -->
                    <button class="hamburger-btn" data-bs-toggle="offcanvas" data-bs-target="#mobileMenu1">
                        <i class="bi bi-list"></i>
                    </button>
                </div>
            </div>
        </header>

        <!-- 모바일 Offcanvas -->
        <div class="offcanvas offcanvas-start" id="mobileMenu1">
            <div class="offcanvas-header u-px-20 u-py-40 justify-content-end">
                <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
            </div>
            <div class="offcanvas-body offcanvas-menu u-p-0">
                <ul class="menu">
                    <li>
                        <a href="#" class="u-py-16 u-px-32" data-bs-toggle="collapse" data-bs-target="#submenu1-1">
                            진료안내 <i class="bi bi-chevron-down float-end"></i>
                        </a>
                        <ul class="submenu collapse" id="submenu1-1">
                            <li><a href="#" class="u-py-16 u-px-32">일반진료</a></li>
                            <li><a href="#" class="u-py-16 u-px-32">임플란트</a></li>
                            <li><a href="#" class="u-py-16 u-px-32">교정치료</a></li>
                            <li><a href="#" class="u-py-16 u-px-32">심미치료</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="#" class="u-py-16 u-px-32" data-bs-toggle="collapse" data-bs-target="#submenu1-2">
                            병원소개 <i class="bi bi-chevron-down float-end"></i>
                        </a>
                        <ul class="submenu collapse" id="submenu1-2">
                            <li><a href="#" class="u-py-16 u-px-32">인사말</a></li>
                            <li><a href="#" class="u-py-16 u-px-32">의료진소개</a></li>
                            <li><a href="#" class="u-py-16 u-px-32">시설안내</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="#" class="u-py-16 u-px-32" data-bs-toggle="collapse" data-bs-target="#submenu1-3">
                            고객센터 <i class="bi bi-chevron-down float-end"></i>
                        </a>
                        <ul class="submenu collapse" id="submenu1-3">
                            <li><a href="#" class="u-py-16 u-px-32">공지사항</a></li>
                            <li><a href="#" class="u-py-16 u-px-32">자주묻는질문</a></li>
                            <li><a href="#" class="u-py-16 u-px-32">온라인상담</a></li>
                        </ul>
                    </li>
                    <li><a href="#" class="u-py-16 u-px-32">오시는길</a></li>
                </ul>
            </div>
        </div>

        <div class="demo-section">
            <div class="container">
                <div class="u-text-center">
                    <h2 class="t-fs-40 u-mb-16">1번: Flyout 타입</h2>
                    <p class="c-fs-18 u-c-muted">메뉴에 마우스를 올리면 드롭다운 메뉴가 나타납니다.</p>
                </div>
            </div>
        </div>
    </div>

    <!-- 2번: 3단 Flyout 타입 -->
    <div class="tab-content-wrapper" id="tab2">
        <header class="demo-header2 header-flyout-3level">
            <!-- 데스크탑 메뉴 -->
            <div class="u-1920 header-container desktop-menu u-my-20">
                <div class="d-flex justify-content-between align-items-center h-100 u-px-60 u-gap-60">
                    <div class="logo t-fs-24">
                        <a href="/">
                            <img src="/images/logo_ex.png" alt="LOGO">
                        </a>
                    </div>
                    <ul class="menu u-gap-20 g-auto-flow u-px-20 rounded-full">
                        <li>
                            <a href="#" class="t-fs-18 fw-500 u-p-20">
                                진료안내 </i>
                            </a>
                            <ul class="submenu rounded-20 u-py-16 u-px-20">
                                <li>
                                    <a href="#" class="c-fs-16 text-center fw-600 u-lh-15 d-flex align-center u-gap-40 w-max h-100">
                                        일반진료 <img src="/images/arrow_right.svg" alt="">
                                    </a>
                                    <ul class="submenu-level3 u-px-20 u-py-10">
                                        <li><a href="#" class="c-fs-16 text-center fw-600 u-lh-15 d-flex align-center u-gap-40 h-100">충치치료</a></li>
                                        <li><a href="#" class="c-fs-16 text-center fw-600 u-lh-15 d-flex align-center u-gap-40 h-100">신경치료</a></li>
                                        <li><a href="#" class="c-fs-16 text-center fw-600 u-lh-15 d-flex align-center u-gap-40 h-100">잇몸치료</a></li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="#" class="c-fs-16 text-center fw-600 u-lh-15 d-flex align-center u-gap-40 w-max h-100">
                                        임플란트 <img src="/images/arrow_right.svg" alt="">
                                    </a>
                                    <ul class="submenu-level3 u-px-20 u-py-10">
                                        <li><a href="#" class="c-fs-16 text-center fw-600 u-lh-15 d-flex align-center u-gap-40 h-100">일반임플란트</a></li>
                                        <li><a href="#" class="c-fs-16 text-center fw-600 u-lh-15 d-flex align-center u-gap-40 h-100">네비게이션임플란트</a></li>
                                        <li><a href="#" class="c-fs-16 text-center fw-600 u-lh-15 d-flex align-center u-gap-40 h-100">뼈이식임플란트</a></li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="#" class="c-fs-16 text-center fw-600 u-lh-15 d-flex align-center u-gap-40 w-max h-100">
                                        교정치료 <img src="/images/arrow_right.svg" alt="">
                                    </a>
                                    <ul class="submenu-level3 u-px-20 u-py-10">
                                        <li><a href="#" class="c-fs-16 text-center fw-600 u-lh-15 d-flex align-center u-gap-40 h-100">투명교정</a></li>
                                        <li><a href="#" class="c-fs-16 text-center fw-600 u-lh-15 d-flex align-center u-gap-40 h-100">설측교정</a></li>
                                        <li><a href="#" class="c-fs-16 text-center fw-600 u-lh-15 d-flex align-center u-gap-40 h-100">부분교정</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="#" class="t-fs-18 fw-500 u-p-20">
                                병원소개 </i>
                            </a>
                            <ul class="submenu w-max  u-gap-40  u-py-16 u-px-20">
                                <li><a href="#" class="c-fs-16 text-center fw-600 u-lh-15 d-flex align-center u-gap-40 h-100">인사말</a></li>
                                <li><a href="#" class="c-fs-16 text-center fw-600 u-lh-15 d-flex align-center u-gap-40 h-100">의료진소개</a></li>
                                <li><a href="#" class="c-fs-16 text-center fw-600 u-lh-15 d-flex align-center u-gap-40 h-100">시설안내</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#" class="t-fs-18 fw-500 u-p-20">
                                하하하 </i>
                            </a>
                            <ul class="submenu w-max  u-gap-40  u-py-16 u-px-20">
                                <li><a href="#" class="c-fs-16 text-center fw-600 u-lh-15 d-flex align-center u-gap-40 h-100">인사말</a></li>
                                <li><a href="#" class="c-fs-16 text-center fw-600 u-lh-15 d-flex align-center u-gap-40 h-100">의료진소개</a></li>
                                <li><a href="#" class="c-fs-16 text-center fw-600 u-lh-15 d-flex align-center u-gap-40 h-100">시설안내</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#" class="t-fs-18 fw-500 u-p-20">
                                라라라라라라라 </i>
                            </a>
                            <ul class="submenu w-max  u-gap-40  u-py-16 u-px-20">
                                <li><a href="#" class="c-fs-16 text-center fw-600 u-lh-15 d-flex align-center u-gap-40 h-100">인사말</a></li>
                                <li><a href="#" class="c-fs-16 text-center fw-600 u-lh-15 d-flex align-center u-gap-40 h-100">의료진소개</a></li>
                                <li><a href="#" class="c-fs-16 text-center fw-600 u-lh-15 d-flex align-center u-gap-40 h-100">시설안내</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#" class="t-fs-18 fw-500 u-p-20">
                                가갸가가거고고구 </i>
                            </a>
                            <ul class="submenu w-max  u-gap-40  u-py-16 u-px-20">
                                <li><a href="#" class="c-fs-16 text-center fw-600 u-lh-15 d-flex align-center u-gap-40 h-100">인사말</a></li>
                                <li><a href="#" class="c-fs-16 text-center fw-600 u-lh-15 d-flex align-center u-gap-40 h-100">의료진소개</a></li>
                                <li><a href="#" class="c-fs-16 text-center fw-600 u-lh-15 d-flex align-center u-gap-40 h-100">시설안내</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#" class="t-fs-18 fw-500 u-p-20">
                                으아라라라아마 </i>
                            </a>
                            <ul class="submenu w-max  u-gap-40  u-py-16 u-px-20">
                                <li><a href="#" class="c-fs-16 text-center fw-600 u-lh-15 d-flex align-center u-gap-40 h-100">인사말</a></li>
                                <li><a href="#" class="c-fs-16 text-center fw-600 u-lh-15 d-flex align-center u-gap-40 h-100">의료진소개</a></li>
                                <li><a href="#" class="c-fs-16 text-center fw-600 u-lh-15 d-flex align-center u-gap-40 h-100">시설안내</a></li>
                            </ul>
                        </li>
                        <li><a href="#" class="t-fs-18 fw-500 u-p-20">오시는길</a></li>
                    </ul>
                    <div class="promo-slider rounded-full">
                        <div class="promo-content">
                            <div class="promo-item c-fs-18 fw-500 rounded-full u-gap-4"><img src="/images/tg.svg" alt="">보건복지부인증 통합치의학과 전문의</div>
                            <div class="promo-item c-fs-18 fw-500 rounded-full u-gap-4"><img src="/images/tg.svg" alt="">20년 경력의 통합치의학과 전문의</div>
                            <div class="promo-item c-fs-18 fw-500 rounded-full u-gap-4"><img src="/images/tg.svg" alt="">보건복지부인증 첨단 장비 완비</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 모바일 헤더 -->
            <div class="header-container mobile-header">
                <div class="d-flex justify-content-between align-items-center u-p-20">

                    <div class="logo t-fs-24">
                        <a href="/">
                            <img src="/images/logo_ex.png" alt="LOGO">
                        </a>
                    </div>
                    <button class="hamburger-btn" data-bs-toggle="offcanvas" data-bs-target="#mobileMenu2">
                        <i class="bi bi-list"></i>
                    </button>
                    <!-- <a href="tel:032-123-4567" class="phone-link">
                        <i class="bi bi-telephone-fill"></i>
                    </a> -->
                </div>
            </div>
        </header>

        <!-- 모바일 Offcanvas -->
        <div class="offcanvas offcanvas-end" id="mobileMenu2">
            <div class="offcanvas-header u-px-20 u-py-40">
                <h5 class="offcanvas-title t-fs-20">메뉴</h5>
                <button type="button" class="btn-close" data-bs-dismiss="offcanvas" style="filter: invert(1)"></button>
            </div>
            <div class="offcanvas-body offcanvas-menu u-p-0">
                <ul class="menu">
                    <li>
                        <a href="#" data-bs-toggle="collapse" data-bs-target="#submenu2-1">
                            진료안내 <img src="/images/round_down.svg" alt="">
                        </a>
                        <ul class="submenu collapse" id="submenu2-1">

                            <li><a href="#">충치치료</a></li>
                            <li><a href="#">신경치료</a></li>
                            <li><a href="#">잇몸치료</a></li>


                            <li><a href="#">일반임플란트</a></li>
                            <li><a href="#">네비게이션임플란트</a></li>
                            <li><a href="#">뼈이식임플란트</a></li>

                        </ul>
                    </li>
                    <li>
                        <a href="#" data-bs-toggle="collapse" data-bs-target="#submenu2-2">
                            병원소개 <img src="/images/round_down.svg" alt="">
                        </a>
                        <ul class="submenu collapse" id="submenu2-2">
                            <li><a href="#">인사말</a></li>
                            <li><a href="#">의료진소개</a></li>
                        </ul>
                    </li>
                    <li><a href="#">오시는길</a></li>
                </ul>
            </div>
        </div>

        <div class="demo-section">
            <div class="container">
                <div class="u-text-center">
                    <h2 class="t-fs-40 u-mb-16">2번: 3단 Flyout 타입</h2>
                    <p class="c-fs-18 u-c-muted">하위메뉴에 마우스를 올리면 우측으로 3단 메뉴가 나타납니다.</p>
                </div>
            </div>
        </div>
    </div>

    <!-- 3번: 메가메뉴 타입 -->
    <div class="tab-content-wrapper" id="tab3">
        <header class="demo-header header-mega">
            <!-- 데스크탑 메뉴 -->
            <div class="header-container desktop-menu">
                <div class="header-wrapper">
                    <!-- 로고 -->
                    <div class="logo t-fs-24">
                        <a href="/">
                            <img src="/images/logo_ex.png" alt="LOGO">
                        </a>
                    </div>

                    <!-- 메뉴 래퍼 -->
                    <div class="menu-wrapper">
                        <ul class="menu">
                            <li><a href="#" class="t-fs-18 fw-600">마음담은치과 소개</a></li>
                            <li><a href="#" class="t-fs-18 fw-600">치료사례</a></li>
                            <li><a href="#" class="t-fs-18 fw-600">임플란트</a></li>
                            <li><a href="#" class="t-fs-18 fw-600">소아치료</a></li>
                            <li><a href="#" class="t-fs-18 fw-600">통증 경감 시스템</a></li>
                            <li><a href="#" class="t-fs-18 fw-600">자연치아 살리기</a></li>
                            <li><a href="#" class="t-fs-18 fw-600">사후관리</a></li>
                        </ul>
                    </div>

                    <!-- 슬라이더 -->
                    <div class="promo-slider rounded-full">
                        <div class="promo-content">
                            <div class="promo-item c-fs-18 fw-500 rounded-full u-gap-4"><img src="/images/tg.svg" alt="">보건복지부인증 통합치의학과 전문의</div>
                            <div class="promo-item c-fs-18 fw-500 rounded-full u-gap-4"><img src="/images/tg.svg" alt="">20년 경력의 통합치의학과 전문의</div>
                            <div class="promo-item c-fs-18 fw-500 rounded-full u-gap-4"><img src="/images/tg.svg" alt="">보건복지부인증 첨단 장비 완비</div>
                        </div>
                    </div>
                </div>

                <!-- 메가메뉴 -->
                <div class="megamenu">
                    <div class="megamenu-content">
                        <div class="megamenu-columns">
                            <div class="megamenu-column">

                                <ul>
                                    <li><a href="#" class="c-fs-16 text-center">의료진 소개</a></li>
                                    <li><a href="#" class="c-fs-16 text-center">진료안내</a></li>
                                    <li><a href="#" class="c-fs-16 text-center">장비소개</a></li>
                                    <li><a href="#" class="c-fs-16 text-center">오시는 길</a></li>
                                </ul>
                            </div>
                            <div class="megamenu-column">

                                <ul>
                                    <li><a href="#" class="c-fs-16 text-center">3D 디지털 임플란트</a></li>
                                    <li><a href="#" class="c-fs-16 text-center">고난이도 임플란트</a></li>
                                    <li><a href="#" class="c-fs-16 text-center">네비게이션 임플란트</a></li>
                                    <li><a href="#" class="c-fs-16 text-center">발치 즉시 임플란트</a></li>
                                </ul>
                            </div>
                            <div class="megamenu-column">

                                <ul>
                                    <li><a href="#" class="c-fs-16 text-center">일반임플란트</a></li>
                                    <li><a href="#" class="c-fs-16 text-center">네비게이션임플란트</a></li>
                                    <li><a href="#" class="c-fs-16 text-center">뼈이식임플란트</a></li>
                                    <li><a href="#" class="c-fs-16 text-center">전악임플란트</a></li>
                                </ul>
                            </div>
                            <div class="megamenu-column">

                                <ul>
                                    <li><a href="#" class="c-fs-16 text-center">소아충치치료</a></li>
                                    <li><a href="#" class="c-fs-16 text-center">소아불소도포</a></li>
                                    <li><a href="#" class="c-fs-16 text-center">소아교정</a></li>
                                    <li><a href="#" class="c-fs-16 text-center">치아홈메우기</a></li>
                                </ul>
                            </div>
                            <div class="megamenu-column">

                                <ul>
                                    <li><a href="#" class="c-fs-16 text-center">무통마취</a></li>
                                    <li><a href="#" class="c-fs-16 text-center">수면치료</a></li>
                                    <li><a href="#" class="c-fs-16 text-center">레이저치료</a></li>
                                    <li><a href="#" class="c-fs-16 text-center">디지털장비</a></li>
                                </ul>
                            </div>
                            <div class="megamenu-column">

                                <ul>
                                    <li><a href="#" class="c-fs-16 text-center">충치치료</a></li>
                                    <li><a href="#" class="c-fs-16 text-center">잇몸치료</a></li>
                                    <li><a href="#" class="c-fs-16 text-center">신경치료</a></li>
                                    <li><a href="#" class="c-fs-16 text-center">턱 관절 치료</a></li>
                                </ul>
                            </div>
                            <div class="megamenu-column">

                                <ul>
                                    <li><a href="#" class="c-fs-16 text-center">정기검진</a></li>
                                    <li><a href="#" class="c-fs-16 text-center">스케일링</a></li>
                                    <li><a href="#" class="c-fs-16 text-center">보증제도</a></li>
                                    <li><a href="#" class="c-fs-16 text-center">유지관리</a></li>
                                    <li><a href="#" class="c-fs-16 text-center">기타 일반진료</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 모바일 헤더 -->
            <div class="header-container mobile-header">
                <div class="d-flex justify-content-between align-items-center">

                    <div class="logo t-fs-24">
                        <a href="/">
                            <img src="/images/logo_ex.png" alt="LOGO">
                        </a>
                    </div>
                    <button class="hamburger-btn" data-bs-toggle="offcanvas" data-bs-target="#mobileMenu3">
                        <i class="bi bi-list"></i>
                    </button>
                    <!-- <a href="tel:032-123-4567" class="phone-link">
                        <i class="bi bi-telephone-fill"></i>
                    </a> -->
                </div>
            </div>
        </header>

        <!-- 모바일 Offcanvas -->
        <div class="offcanvas offcanvas-start" id="mobileMenu3">
            <div class="offcanvas-header u-px-20 u-py-16">
                <h5 class="offcanvas-title t-fs-20">메뉴</h5>
                <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
            </div>
            <div class="offcanvas-body offcanvas-menu u-p-0">
                <ul class="menu">
                    <li>
                        <a href="#" data-bs-toggle="collapse" data-bs-target="#submenu3-1">
                            진료안내 <i class="bi bi-chevron-down float-end"></i>
                        </a>
                        <ul class="submenu collapse" id="submenu3-1">
                            <li><a href="#">일반진료</a></li>
                            <li><a href="#">임플란트</a></li>
                            <li><a href="#">교정치료</a></li>
                            <li><a href="#">심미치료</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="#" data-bs-toggle="collapse" data-bs-target="#submenu3-2">
                            병원소개 <i class="bi bi-chevron-down float-end"></i>
                        </a>
                        <ul class="submenu collapse" id="submenu3-2">
                            <li><a href="#">인사말</a></li>
                            <li><a href="#">의료진소개</a></li>
                        </ul>
                    </li>
                    <li><a href="#">오시는길</a></li>
                </ul>
            </div>
        </div>

        <div class="demo-section">
            <div class="container">
                <div class="u-text-center">
                    <h2 class="t-fs-40 u-mb-16">3번: 메가메뉴 타입</h2>
                    <p class="c-fs-18 u-c-muted">화면 전체 너비(100vw)의 메가메뉴가 나타납니다.</p>
                </div>
            </div>
        </div>
    </div>

    <!-- 4번: 4:6 메가메뉴 타입 -->
    <div class="tab-content-wrapper" id="tab4">
        <header class="demo-header header-mega-46">
            <!-- 데스크탑 메뉴 -->
            <div class="header-container desktop-menu">
                <div class="d-flex justify-content-between align-items-center">
                    <div class="logo t-fs-24">인천스마일치과</div>
                    <ul class="menu">
                        <li>
                            <a href="#" class="t-fs-18 fw-500">진료안내</a>
                            <div class="megamenu">
                                <div class="megamenu-content">
                                    <div class="megamenu-left">
                                        <ul>
                                            <li><a href="#" class="submenu-trigger c-fs-14" data-target="general">일반진료</a></li>
                                            <li><a href="#" class="submenu-trigger c-fs-14" data-target="implant">임플란트</a></li>
                                            <li><a href="#" class="submenu-trigger c-fs-14" data-target="orthodontics">교정치료</a></li>
                                            <li><a href="#" class="submenu-trigger c-fs-14" data-target="cosmetic">심미치료</a></li>
                                        </ul>
                                    </div>
                                    <div class="megamenu-right">
                                        <div class="submenu-detail active" id="general">
                                            <h5 class="t-fs-20">일반진료</h5>
                                            <ul>
                                                <li><a href="#" class="c-fs-16 text-center">충치치료</a></li>
                                                <li><a href="#" class="c-fs-16 text-center">신경치료</a></li>
                                                <li><a href="#" class="c-fs-16 text-center">잇몸치료</a></li>
                                                <li><a href="#" class="c-fs-16 text-center">사랑니발치</a></li>
                                                <li><a href="#" class="c-fs-16 text-center">스케일링</a></li>
                                                <li><a href="#" class="c-fs-16 text-center">불소도포</a></li>
                                            </ul>
                                        </div>
                                        <div class="submenu-detail" id="implant">
                                            <h5 class="t-fs-20">임플란트</h5>
                                            <ul>
                                                <li><a href="#" class="c-fs-16 text-center">일반임플란트</a></li>
                                                <li><a href="#" class="c-fs-16 text-center">네비게이션임플란트</a></li>
                                                <li><a href="#" class="c-fs-16 text-center">뼈이식임플란트</a></li>
                                                <li><a href="#" class="c-fs-16 text-center">전악임플란트</a></li>
                                                <li><a href="#" class="c-fs-16 text-center">즉시임플란트</a></li>
                                                <li><a href="#" class="c-fs-16 text-center">미니임플란트</a></li>
                                            </ul>
                                        </div>
                                        <div class="submenu-detail" id="orthodontics">
                                            <h5 class="t-fs-20">교정치료</h5>
                                            <ul>
                                                <li><a href="#" class="c-fs-16 text-center">투명교정</a></li>
                                                <li><a href="#" class="c-fs-16 text-center">설측교정</a></li>
                                                <li><a href="#" class="c-fs-16 text-center">부분교정</a></li>
                                                <li><a href="#" class="c-fs-16 text-center">소아교정</a></li>
                                                <li><a href="#" class="c-fs-16 text-center">성인교정</a></li>
                                                <li><a href="#" class="c-fs-16 text-center">재교정</a></li>
                                            </ul>
                                        </div>
                                        <div class="submenu-detail" id="cosmetic">
                                            <h5 class="t-fs-20">심미치료</h5>
                                            <ul>
                                                <li><a href="#" class="c-fs-16 text-center">라미네이트</a></li>
                                                <li><a href="#" class="c-fs-16 text-center">올세라믹</a></li>
                                                <li><a href="#" class="c-fs-16 text-center">치아미백</a></li>
                                                <li><a href="#" class="c-fs-16 text-center">잇몸성형</a></li>
                                                <li><a href="#" class="c-fs-16 text-center">치아성형</a></li>
                                                <li><a href="#" class="c-fs-16 text-center">골드크라운</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li>
                            <a href="#" class="t-fs-18 fw-500">병원소개</a>
                            <div class="megamenu">
                                <div class="megamenu-content">
                                    <div class="megamenu-left">
                                        <ul>
                                            <li><a href="#" class="submenu-trigger2 c-fs-14" data-target="intro">병원안내</a></li>
                                            <li><a href="#" class="submenu-trigger2 c-fs-14" data-target="staff">의료진</a></li>
                                        </ul>
                                    </div>
                                    <div class="megamenu-right">
                                        <div class="submenu-detail active" id="intro">
                                            <h5 class="t-fs-20">병원안내</h5>
                                            <ul>
                                                <li><a href="#" class="c-fs-16 text-center">인사말</a></li>
                                                <li><a href="#" class="c-fs-16 text-center">시설안내</a></li>
                                                <li><a href="#" class="c-fs-16 text-center">장비소개</a></li>
                                                <li><a href="#" class="c-fs-16 text-center">오시는길</a></li>
                                            </ul>
                                        </div>
                                        <div class="submenu-detail" id="staff">
                                            <h5 class="t-fs-20">의료진</h5>
                                            <ul>
                                                <li><a href="#" class="c-fs-16 text-center">의료진소개</a></li>
                                                <li><a href="#" class="c-fs-16 text-center">진료시간</a></li>
                                                <li><a href="#" class="c-fs-16 text-center">예약안내</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li><a href="#" class="c-fs-16">오시는길</a></li>
                    </ul>
                </div>
            </div>

            <!-- 모바일 헤더 -->
            <div class="header-container mobile-header">
                <div class="d-flex justify-content-between align-items-center">
                    <button class="hamburger-btn" data-bs-toggle="offcanvas" data-bs-target="#mobileMenu4">
                        <i class="bi bi-list"></i>
                    </button>
                    <div class="logo">인천스마일치과</div>
                    <a href="tel:032-123-4567" class="phone-link">
                        <i class="bi bi-telephone-fill"></i>
                    </a>
                </div>
            </div>
        </header>

        <!-- 모바일 Offcanvas -->
        <div class="offcanvas offcanvas-start" id="mobileMenu4">
            <div class="offcanvas-header u-px-20 u-py-16">
                <h5 class="offcanvas-title t-fs-20">메뉴</h5>
                <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
            </div>
            <div class="offcanvas-body offcanvas-menu u-p-0">
                <ul class="menu">
                    <li>
                        <a href="#" data-bs-toggle="collapse" data-bs-target="#submenu4-1">
                            진료안내 <i class="bi bi-chevron-down float-end"></i>
                        </a>
                        <ul class="submenu collapse" id="submenu4-1">
                            <li><a href="#">일반진료</a></li>
                            <li><a href="#">임플란트</a></li>
                            <li><a href="#">교정치료</a></li>
                            <li><a href="#">심미치료</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="#" data-bs-toggle="collapse" data-bs-target="#submenu4-2">
                            병원소개 <i class="bi bi-chevron-down float-end"></i>
                        </a>
                        <ul class="submenu collapse" id="submenu4-2">
                            <li><a href="#">인사말</a></li>
                            <li><a href="#">의료진소개</a></li>
                        </ul>
                    </li>
                    <li><a href="#">오시는길</a></li>
                </ul>
            </div>
        </div>

        <div class="demo-section">
            <div class="container">
                <div class="u-text-center">
                    <h2 class="t-fs-40 u-mb-16">4번: 4:6 메가메뉴 타입</h2>
                    <p class="c-fs-18 u-c-muted">좌측 카테고리에 마우스를 올리면 우측에 상세 메뉴가 나타납니다.</p>
                </div>
            </div>
        </div>
    </div>

    <!-- 5번: 슬라이드 포함 헤더 -->
    <div class="tab-content-wrapper" id="tab5">
        <header class="demo-header header-dark-flyout">
            <!-- 데스크탑 메뉴 -->
            <div class="header-container desktop-menu">
                <div class="d-flex justify-content-between align-items-center h-100 u-px-60 u-gap-60">

                    <!-- LOGO (이미지 + 텍스트) -->
                    <div class="hdf-logo">
                        <a href="/" class="hdf-logo__link">
                            <img src="/images/logo_ex.png" alt="LOGO" class="hdf-logo__img">
                        </a>
                    </div>

                    <!-- 메뉴 -->
                    <ul class="hdf-menu">
                        <li class="hdf-menu__item hdf-menu__item--active">
                            <a href="#" class="hdf-menu__link">마음담은치과 소개 <i class="hdf-menu__arrow">▾</i></a>
                            <ul class="hdf-submenu">
                                <li><a href="#">의료진 소개</a></li>
                                <li><a href="#">진료안내</a></li>
                                <li><a href="#">장비소개</a></li>
                                <li><a href="#">오시는 길</a></li>
                            </ul>
                        </li>
                        <li class="hdf-menu__item">
                            <a href="#" class="hdf-menu__link">치료사례 <i class="hdf-menu__arrow">▾</i></a>
                            <ul class="hdf-submenu">
                                <li><a href="#">3D 디지털 임플란트</a></li>
                                <li><a href="#">고난이도 임플란트</a></li>
                                <li><a href="#">네비게이션 임플란트</a></li>
                                <li><a href="#">발치 즉시 임플란트</a></li>
                            </ul>
                        </li>
                        <li class="hdf-menu__item">
                            <a href="#" class="hdf-menu__link">임플란트 <i class="hdf-menu__arrow">▾</i></a>
                            <ul class="hdf-submenu">
                                <li><a href="#">일반임플란트</a></li>
                                <li><a href="#">네비게이션임플란트</a></li>
                                <li><a href="#">뼈이식임플란트</a></li>
                                <li><a href="#">전악임플란트</a></li>
                            </ul>
                        </li>
                        <li class="hdf-menu__item">
                            <a href="#" class="hdf-menu__link">소아진료 <i class="hdf-menu__arrow">▾</i></a>
                            <ul class="hdf-submenu">
                                <li><a href="#">소아충치치료</a></li>
                                <li><a href="#">소아불소도포</a></li>
                                <li><a href="#">소아교정</a></li>
                                <li><a href="#">치아홈메우기</a></li>
                            </ul>
                        </li>
                        <li class="hdf-menu__item">
                            <a href="#" class="hdf-menu__link">통증 경감 시스템 <i class="hdf-menu__arrow">▾</i></a>
                            <ul class="hdf-submenu">
                                <li><a href="#">무통마취</a></li>
                                <li><a href="#">수면치료</a></li>
                                <li><a href="#">레이저치료</a></li>
                                <li><a href="#">디지털장비</a></li>
                            </ul>
                        </li>
                        <li class="hdf-menu__item">
                            <a href="#" class="hdf-menu__link">자연치아 살리기 <i class="hdf-menu__arrow">▾</i></a>
                            <ul class="hdf-submenu">
                                <li><a href="#">충치치료</a></li>
                                <li><a href="#">잇몸치료</a></li>
                                <li><a href="#">신경치료</a></li>
                                <li><a href="#">턱 관절 치료</a></li>
                            </ul>
                        </li>
                        <li class="hdf-menu__item">
                            <a href="#" class="hdf-menu__link">사후관리 <i class="hdf-menu__arrow">▾</i></a>
                            <ul class="hdf-submenu">
                                <li><a href="#">정기검진</a></li>
                                <li><a href="#">스케일링</a></li>
                                <li><a href="#">보증제도</a></li>
                                <li><a href="#">유지관리</a></li>
                                <li><a href="#">기타 일반진료</a></li>
                            </ul>
                        </li>
                    </ul>

                    <!-- 우측 홍보 배너 (pill) -->
                    <a href="#" class="hdf-promo">
                        <img src="/images/tg.svg" alt="" class="hdf-promo__icon">
                        <span class="hdf-promo__text">보건복지부인증 통합치의학과 전문의</span>
                    </a>
                </div>
            </div>

            <!-- 모바일 헤더 -->
            <div class="header-container mobile-header">
                <div class="d-flex justify-content-between align-items-center h-100 u-p-20">
                    
                       <div class="logo t-fs-24">
                        <a href="/">
                            <img src="/images/logo_ex.png" alt="LOGO">
                        </a>
                    </div>
                    <button class="hamburger-btn" data-bs-toggle="offcanvas" data-bs-target="#mobileMenu5" style="filter: invert(1);">
                        <i class="bi bi-list"></i>
                    </button>
                    <!-- <a href="tel:032-123-4567" class="phone-link">
                        <i class="bi bi-telephone-fill"></i>
                    </a> -->
                </div>
            </div>
        </header>

        <!-- 모바일 Offcanvas (기존 유지) -->
        <div class="offcanvas offcanvas-end offcanvas-dark" id="mobileMenu5">
            <div class="offcanvas-header u-px-20 u-py-40">
                <h5 class="offcanvas-title t-fs-20 text-white"></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas"></button>
            </div>
            <div class="offcanvas-body u-px-40">
                <ul class="mobile-menu-list">
                    <li class="mobile-menu-item">
                        <a href="#" class="mobile-menu-link" data-bs-toggle="collapse" data-bs-target="#submenu5-1">
                            <span>마음담은치과</span>
                            <i class="bi bi-chevron-down"></i>
                        </a>
                        <ul class="mobile-submenu collapse show" id="submenu5-1">
                            <li><a href="#" class="mobile-submenu-link">의료진 소개</a></li>
                            <li><a href="#" class="mobile-submenu-link">진료안내</a></li>
                            <li><a href="#" class="mobile-submenu-link">장비소개</a></li>
                            <li><a href="#" class="mobile-submenu-link">오시는길</a></li>
                        </ul>
                    </li>
                    <li class="mobile-menu-item">
                        <a href="#" class="mobile-menu-link" data-bs-toggle="collapse" data-bs-target="#submenu5-2">
                            <span>치료사례</span>
                            <i class="bi bi-chevron-down"></i>
                        </a>
                        <ul class="mobile-submenu collapse show" id="submenu5-2">
                            <li><a href="#" class="mobile-submenu-link">치료사례</a></li>
                        </ul>
                    </li>
                    <li class="mobile-menu-item">
                        <a href="#" class="mobile-menu-link" data-bs-toggle="collapse" data-bs-target="#submenu5-3">
                            <span>임플란트</span>
                            <i class="bi bi-chevron-down"></i>
                        </a>
                        <ul class="mobile-submenu collapse show" id="submenu5-3">
                            <li><a href="#" class="mobile-submenu-link">3D 디지털 임플란트</a></li>
                            <li><a href="#" class="mobile-submenu-link">고난이도 임플란트</a></li>
                            <li><a href="#" class="mobile-submenu-link">네비게이션 임플란트</a></li>
                            <li><a href="#" class="mobile-submenu-link">발치 즉시 임플란트</a></li>
                        </ul>
                    </li>
                    <li class="mobile-menu-item">
                        <a href="#" class="mobile-menu-link" data-bs-toggle="collapse" data-bs-target="#submenu5-4">
                            <span>소아진료</span>
                            <i class="bi bi-chevron-down"></i>
                        </a>
                        <ul class="mobile-submenu collapse show" id="submenu5-4">
                            <li><a href="#" class="mobile-submenu-link">소아진료</a></li>
                        </ul>
                    </li>
                    <li class="mobile-menu-item">
                        <a href="#" class="mobile-menu-link" data-bs-toggle="collapse" data-bs-target="#submenu5-5">
                            <span>통증 경감 시스템</span>
                            <i class="bi bi-chevron-down"></i>
                        </a>
                        <ul class="mobile-submenu collapse show" id="submenu5-5">
                            <li><a href="#" class="mobile-submenu-link">통증 경감 시스템</a></li>
                        </ul>
                    </li>
                    <li class="mobile-menu-item">
                        <a href="#" class="mobile-menu-link" data-bs-toggle="collapse" data-bs-target="#submenu5-6">
                            <span>자연치아 살리기</span>
                            <i class="bi bi-chevron-down"></i>
                        </a>
                        <ul class="mobile-submenu collapse show" id="submenu5-6">
                            <li><a href="#" class="mobile-submenu-link">충치치료</a></li>
                            <li><a href="#" class="mobile-submenu-link">잇몸치료</a></li>
                            <li><a href="#" class="mobile-submenu-link">신경치료</a></li>
                            <li><a href="#" class="mobile-submenu-link">턱 관절 치료</a></li>
                            <li><a href="#" class="mobile-submenu-link">기타 일반진료</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>



        <div class="demo-section">
            <div class="container">
                <div class="u-text-center">
                    <h2 class="t-fs-40 u-mb-16">5번: Dark Flyout 헤더</h2>
                    <p class="c-fs-18 u-c-muted">Dark 배경 + 포인트색 활성 메뉴 + 드롭다운</p>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // 화살표 아이콘 회전
    const collapseToggles = document.querySelectorAll('[data-bs-toggle="collapse"]');
    
    collapseToggles.forEach(toggle => {
        const targetId = toggle.getAttribute('data-bs-target');
        const targetElement = document.querySelector(targetId);
        
        if (targetElement) {
            // 초기 상태 설정
            const icon = toggle.querySelector('i');
            if (icon) {
                // 닫혀있으면 아래, 열려있으면 위
                if (targetElement.classList.contains('show')) {
                    icon.style.transform = 'rotate(180deg)';
                } else {
                    icon.style.transform = 'rotate(0deg)';
                }
            }
            
            // 열릴 때 - 위로 (180도)
            targetElement.addEventListener('show.bs.collapse', function() {
                const icon = toggle.querySelector('i');
                if (icon) {
                    icon.style.transform = 'rotate(180deg)';
                }
            });
            
            // 닫힐 때 - 아래로 (0도)
            targetElement.addEventListener('hide.bs.collapse', function() {
                const icon = toggle.querySelector('i');
                if (icon) {
                    icon.style.transform = 'rotate(0deg)';
                }
            });
        }
    });
});
</script>
    <script>
        // 3번 메가메뉴 - 호버 인터랙션
        document.addEventListener('DOMContentLoaded', function() {
            const headerMega = document.querySelector('.header-mega');
            if (!headerMega) return;

            const menuItems = headerMega.querySelectorAll('.menu > li');
            const megamenuColumns = headerMega.querySelectorAll('.megamenu-column');
            const megamenu = headerMega.querySelector('.megamenu');
            const menuWrapper = headerMega.querySelector('.menu-wrapper');

            // 각 메뉴 항목에 호버 이벤트
            menuItems.forEach((menuItem, index) => {
                menuItem.addEventListener('mouseenter', function() {
                    // 모든 메뉴에서 active 제거
                    menuItems.forEach(item => item.classList.remove('active'));

                    // 현재 메뉴에 active 추가
                    this.classList.add('active');

                    // 모든 컬럼에서 active 제거
                    megamenuColumns.forEach(col => col.classList.remove('active'));

                    // 해당 인덱스의 컬럼에 active 추가
                    if (megamenuColumns[index]) {
                        megamenuColumns[index].classList.add('active');
                    }
                });
            });

            // 메뉴 wrapper에 마우스 올리면 메가메뉴 표시
            let megamenuTimeout;

            menuWrapper.addEventListener('mouseenter', function() {
                clearTimeout(megamenuTimeout);
                megamenu.style.opacity = '1';
                megamenu.style.visibility = 'visible';
            });

            menuWrapper.addEventListener('mouseleave', function() {
                megamenuTimeout = setTimeout(() => {
                    if (!megamenu.matches(':hover')) {
                        megamenu.style.opacity = '0';
                        megamenu.style.visibility = 'hidden';
                        // active 클래스 모두 제거
                        menuItems.forEach(item => item.classList.remove('active'));
                        megamenuColumns.forEach(col => col.classList.remove('active'));
                    }
                }, 100);
            });

            // 메가메뉴 자체에 마우스 있을 때는 유지
            megamenu.addEventListener('mouseenter', function() {
                clearTimeout(megamenuTimeout);
                this.style.opacity = '1';
                this.style.visibility = 'visible';
            });

            megamenu.addEventListener('mouseleave', function() {
                this.style.opacity = '0';
                this.style.visibility = 'hidden';
                // active 클래스 모두 제거
                menuItems.forEach(item => item.classList.remove('active'));
                megamenuColumns.forEach(col => col.classList.remove('active'));
            });

            // 메가메뉴 컬럼에 마우스 올렸을 때도 해당 컬럼 활성화
            megamenuColumns.forEach((column, index) => {
                column.addEventListener('mouseenter', function() {
                    // 모든 메뉴와 컬럼에서 active 제거
                    menuItems.forEach(item => item.classList.remove('active'));
                    megamenuColumns.forEach(col => col.classList.remove('active'));

                    // 해당 메뉴와 컬럼 활성화
                    if (menuItems[index]) {
                        menuItems[index].classList.add('active');
                    }
                    this.classList.add('active');
                });
            });
        });
    </script>
    <script>
        // 탭 전환 함수
        function switchTab(tabNumber) {
            // 모든 탭 버튼과 콘텐츠 비활성화
            document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
            document.querySelectorAll('.tab-content-wrapper').forEach(content => content.classList.remove('active'));

            // 선택된 탭 활성화
            event.target.closest('.tab-btn').classList.add('active');
            document.getElementById('tab' + tabNumber).classList.add('active');
        }

        // 4번 헤더 - 4:6 메가메뉴 호버 효과
        document.querySelectorAll('.submenu-trigger').forEach(trigger => {
            trigger.addEventListener('mouseenter', function() {
                const target = this.getAttribute('data-target');
                const parent = this.closest('.megamenu-content');

                // 모든 좌측 링크 비활성화
                parent.querySelectorAll('.submenu-trigger').forEach(link => {
                    link.classList.remove('active');
                });

                // 현재 링크 활성화
                this.classList.add('active');

                // 모든 우측 콘텐츠 숨기기
                parent.querySelectorAll('.submenu-detail').forEach(detail => {
                    detail.classList.remove('active');
                });

                // 선택된 콘텐츠 표시
                parent.querySelector('#' + target).classList.add('active');
            });
        });

        document.querySelectorAll('.submenu-trigger2').forEach(trigger => {
            trigger.addEventListener('mouseenter', function() {
                const target = this.getAttribute('data-target');
                const parent = this.closest('.megamenu-content');

                // 모든 좌측 링크 비활성화
                parent.querySelectorAll('.submenu-trigger2').forEach(link => {
                    link.classList.remove('active');
                });

                // 현재 링크 활성화
                this.classList.add('active');

                // 모든 우측 콘텐츠 숨기기
                parent.querySelectorAll('.submenu-detail').forEach(detail => {
                    detail.classList.remove('active');
                });

                // 선택된 콘텐츠 표시
                parent.querySelector('#' + target).classList.add('active');
            });
        });

        // 모바일 메뉴 collapse 방지
        document.querySelectorAll('.offcanvas-menu .menu > li > a').forEach(link => {
            link.addEventListener('click', function(e) {
                if (this.getAttribute('data-bs-toggle') === 'collapse') {
                    e.preventDefault();
                }
            });
        });
    </script>
</body>

</html>