<?php
// 비포애프터 좌우 비교 (전체 화면)
if (!defined('_GNUBOARD_')) {
    include_once($_SERVER['DOCUMENT_ROOT'] . '/_common.php');
}

$ba_table = 'dm_beforeafter';

// 테이블 존재 확인
$table_check = sql_query("SHOW TABLES LIKE '{$ba_table}'", false);
if (!$table_check || sql_num_rows($table_check) == 0) {
    return;
}

// 로그인 여부 확인
$is_logged_in = isset($_SESSION['ss_mb_id']) && $_SESSION['ss_mb_id'];

// 노출 가능한 데이터만 가져오기
$sql = "SELECT * FROM {$ba_table} WHERE is_visible = 1 ORDER BY display_order ASC, id DESC";
$result = sql_query($sql, false);

if (!$result || sql_num_rows($result) == 0) {
    return;
}
?>

<!-- SweetAlert2 CDN -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<!-- 비포애프터 좌우 비교 섹션 -->
<section class="u-py-80" style="background: var(--bg-soft);">
    <div class="container" style="max-width: 100%; padding: 0 var(--sp-40);">
        
        <!-- 헤더 -->
        <div class="text-center u-mb-60" data-aos="fade-up">
            <div class="u-txt-main fw-700 c-fs-14 u-mb-10">BEFORE & AFTER</div>
            <h2 class="t-fs-48 fw-900 u-mb-16">치료 전후 비교</h2>
            <p class="c-fs-18 u-txt-muted">실제 치료 케이스를 통해 결과를 확인하세요</p>
        </div>

        <!-- 케이스 목록 -->
        <div class="d-flex flex-column" style="gap: var(--sp-60);">
            <?php while ($ba = sql_fetch_array($result)): ?>
                <div class="ba-fullwidth-item">
                    <!-- 상단: 정보 -->
                    <div class="text-center u-mb-32">
                        <?php if ($ba['treatment_category']): ?>
                            <span class="u-badge u-badge-main u-mb-12"><?= htmlspecialchars($ba['treatment_category']) ?></span>
                        <?php endif; ?>
                        <h3 class="t-fs-32 fw-900 u-txt-title u-mb-12"><?= htmlspecialchars($ba['title']) ?></h3>
                        <?php if ($ba['treatment_period']): ?>
                            <p class="c-fs-16 u-txt-muted">⏱️ <?= htmlspecialchars($ba['treatment_period']) ?></p>
                        <?php endif; ?>
                    </div>

                    <!-- 이미지 좌우 배치 (전체 화면) -->
                    <div class="ba-fullwidth-images">
                        <div class="ba-fullwidth-box">
                            <div class="ba-fullwidth-label">치료 전</div>
                            <?php if ($ba['image_before']): ?>
                                <img src="<?= htmlspecialchars($ba['image_before']) ?>" alt="Before" class="obj-cover">
                            <?php endif; ?>
                        </div>

                        <div class="ba-fullwidth-box" onclick="handleImageClick(<?= $ba['id'] ?>, <?= $is_logged_in ? 'true' : 'false' ?>)">
                            <div class="ba-fullwidth-label">치료 후</div>
                            <?php if ($ba['image_after']): ?>
                                <img src="<?= htmlspecialchars($ba['image_after']) ?>" alt="After" class="obj-cover">
                            <?php endif; ?>
                            
                            <!-- 블러 오버레이 -->
                            <?php if (!$is_logged_in): ?>
                                <div class="ba-blur">
                                    <div class="ba-lock">🔒</div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- 로그인 후 표시 정보 -->
                    <?php if ($is_logged_in): ?>
                    <div class="u-mt-40 u-pt-40 text-center" style="border-top: 1px solid var(--gray-200); max-width: 800px; margin-left: auto; margin-right: auto;">
                        <?php if ($ba['patient_age'] || $ba['patient_gender']): ?>
                            <p class="c-fs-15 u-txt-body u-mb-16">
                                👤 <?= htmlspecialchars($ba['patient_age']) ?> <?= htmlspecialchars($ba['patient_gender']) ?>
                            </p>
                        <?php endif; ?>
                        <?php if ($ba['description']): ?>
                            <p class="c-fs-16 u-txt-body" style="line-height: 1.8; white-space: pre-wrap;">
                                <?= nl2br(htmlspecialchars($ba['description'])) ?>
                            </p>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
</section>

<style>
/* 전체 폭 좌우 비교 */
.ba-fullwidth-images {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: var(--sp-20);
}

.ba-fullwidth-box {
    position: relative;
    aspect-ratio: 4 / 3;
    border-radius: var(--sp-16);
    overflow: hidden;
    background: var(--gray-100);
}

.ba-fullwidth-box img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.ba-fullwidth-label {
    position: absolute;
    top: var(--sp-16);
    left: var(--sp-16);
    padding: var(--sp-12) var(--sp-24);
    background: rgba(0, 0, 0, 0.8);
    color: var(--white);
    border-radius: var(--sp-12);
    font-size: 14px;
    font-weight: 700;
    z-index: 5;
}

.ba-blur {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.3);
    backdrop-filter: blur(15px);
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    z-index: 10;
}

.ba-lock {
    font-size: 48px;
    animation: ba-pulse 2s infinite;
}

@keyframes ba-pulse {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.1); }
}

/* 반응형 */
@media (max-width: 768px) {
    .ba-fullwidth-images {
        grid-template-columns: 1fr;
    }
}
</style>

<script>
// 이미지 클릭 처리
function handleImageClick(id, isLoggedIn) {
    if (!isLoggedIn) {
        Swal.fire({
            icon: 'warning',
            title: '로그인이 필요합니다',
            html: '의료법 제56조에 따라<br>치료 결과는 회원에게만 공개됩니다',
            confirmButtonText: '로그인하기',
            confirmButtonColor: '#007bff',
            showCancelButton: true,
            cancelButtonText: '취소'
        }).then((result) => {
            if (result.isConfirmed) {
                location.href = '/bbs/login.php';
            }
        });
    }
}
</script>