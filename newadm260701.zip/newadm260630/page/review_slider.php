<?php
// 그누보드 연결
if (!defined('_GNUBOARD_')) {
    include_once('../newadm/_common.php');
}

// 리뷰 데이터 조회
$review_table = 'dm_review';
$review_sql = "SELECT * FROM {$review_table} WHERE is_visible = 1 ORDER BY display_order ASC, id DESC LIMIT 20";
$review_result = sql_query($review_sql);

if (!$review_result) {
    return;
}

$reviews = array();
while ($row = sql_fetch_array($review_result)) {
    $reviews[] = $row;
}

if (empty($reviews)) {
    return;
}
?>

<!-- GSAP 로드 -->
<script>
    (function() {
        if (typeof gsap === 'undefined') {
            var s1 = document.createElement('script');
            s1.src = 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js';
            document.head.appendChild(s1);

            var s2 = document.createElement('script');
            s2.src = 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollTrigger.min.js';
            document.head.appendChild(s2);
        }
    })();
</script>

<style>
    .review-section {
        overflow: hidden;
        position: relative;
    }

    .review-section::before {
        content: '';
        position: absolute;
        top: -50%;
        right: -10%;
        width: var(--sp-500);
        height: var(--sp-500);
        background: radial-gradient(circle, rgba(0, 123, 255, 0.03) 0%, transparent 70%);
        border-radius: 50%;
    }

    .review-slider-wrapper {
        padding-left: calc((100vw - 1400px) / 2 + var(--sp-20));
    }

    .review-track {
        width: max-content;
        will-change: transform;
    }

    .review-card {
        width: 20vw;
        box-shadow: 0 var(--sp-20) var(--sp-60) rgba(0, 0, 0, 0.08);
        border: 1px solid rgba(0, 0, 0, 0.05);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        max-width: 320px;
    }

    .review-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: var(--sp-5);
        background: linear-gradient(90deg, var(--main-color), var(--btn-main-active));
        opacity: 0;
        transition: opacity 0.3s ease;
    }

    .review-card:hover {
        transform: translateY(calc(var(--sp-8) * -1));
        box-shadow: 0 var(--sp-30) var(--sp-80) rgba(0, 123, 255, 0.15);
    }

    .review-card:hover::before {
        opacity: 1;
    }

    .review-category {
        background: #e7f3ff;
        color: var(--main-color);
        border-radius: var(--sp-20);
    }

    .review-star {
        width: var(--sp-16);
        height: var(--sp-16);
        line-height: 1;
    }

    .review-text {
        min-height: var(--sp-140);
        line-height: var(--lh-175);
        color: var(--c-color);
    }

    .review-text::before {
        content: '"';
        position: absolute;
        left: 0;
        top: calc(var(--sp-10) * -1);
        font-size: var(--sp-60);
        color: var(--gray-200);
        font-family: Georgia, serif;
        line-height: 1;
    }

    .review-avatar {
        width: var(--sp-32);
        height: var(--sp-32);
    }

    .review-text img {
    max-width: 100%;
    height: auto;
    border-radius: var(--sp-8);
    margin: var(--sp-16) 0;
    display: block;
}

.review-text p {
    margin: 0 0 var(--sp-12) 0;
}

    @media (max-width: 1240px) {
        .review-slider-wrapper {
            padding-left: var(--sp-20);
        }
    }

    @media (max-width: 768px) {
        .review-card {
            width: var(--sp-320);
        }

        .review-track {
            gap: var(--sp-20);
        }
    }
</style>

<!-- 리뷰 슬라이더 섹션 -->
<section class="review-section u-py-80" id="review">
    <div class="text-center u-mb-40">
        <div class="u-txt-main fw-700 c-fs-14 u-mb-10">REVIEW</div>
        <h2 class="t-fs-40">환자 리얼 후기</h2>
        <p class="c-fs-20 fw-500 u-txt-muted u-mt-20">
            실제 내원 환자분들이 남겨주신 소중한 기록입니다
        </p>
    </div>

    <div class="review-slider-wrapper">
        <div class="review-track d-flex u-gap-32">
            <?php foreach ($reviews as $review): ?>
                <div class="review-card u-bg-white rounded-8 u-p-32 u-relative">

                    <?php if (!empty($review['category'])): ?>
                        <div class="review-category d-inline-block u-px-16 u-py-4 u-mb-16 fw-700 c-fs-12 rounded-4">
                            <?php echo htmlspecialchars($review['category']); ?>
                        </div>
                    <?php endif; ?>

                    <!-- 별점 -->
                    <div class="d-flex align-items-center justify-content-start u-gap-4 u-mb-12">
                        <?php for ($i = 1; $i <= 5; $i++): ?>
                            <span class="review-star c-fs-20" style="color: <?php echo ($i <= $review['rating']) ? 'var(--accent-color)' : 'var(--gray-300)'; ?>;">★</span>
                        <?php endfor; ?>
                    </div>

                    <!-- 리뷰 내용 -->
                  <div class="review-text u-relative u-pl-20 u-mb-32 c-fs-18">
    <?php echo htmlspecialchars_decode($review['content'], ENT_QUOTES); ?>
</div>

                    <!-- 사용자 정보 -->
                    <div class="d-flex align-items-center u-gap-16 u-pt-24">
                        <div class="review-avatar d-flex align-items-center justify-content-center rounded-full fw-700 c-fs-16 u-txt-white" style="background: <?php echo htmlspecialchars($review['avatar_color']); ?>;">
                            <?php echo htmlspecialchars(mb_substr($review['author_initial'], 0, 1)); ?>
                        </div>
                        <div class="u-flex-1">
                            <div class="fw-700 c-fs-16 u-mb-4" style="color: var(--t-color);">
                                <?php echo htmlspecialchars($review['author_initial']); ?> 님
                            </div>
                            <div class="c-fs-12 u-txt-muted">
                                <?php echo $review['review_date']; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<script>
    (function() {
        var initReviewSlider = function() {
            if (typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined') {
                setTimeout(initReviewSlider, 100);
                return;
            }

            if (!gsap.plugins.scrollTrigger) {
                gsap.registerPlugin(ScrollTrigger);
            }

            var track = document.querySelector(".review-track");
            var section = document.querySelector(".review-section");

            if (!track || !section) return;

            var getScrollAmount = function() {
                var trackWidth = track.scrollWidth;
                var windowWidth = window.innerWidth;
                // 마지막 카드까지 완전히 보이도록
                return -(trackWidth - windowWidth);
            };

            gsap.to(track, {
                x: getScrollAmount,
                ease: "none",
                scrollTrigger: {
                    id: "review-slider",
                    trigger: section,
                    start: "top top",
                    end: function() {
                        // 스크롤 길이를 3배로 늘림 (2배에서 3배로)
                        return "+=" + (track.scrollWidth * 3);
                    },
                    scrub: 1, // 0.5 → 1 (더 천천히)
                    pin: true,
                    pinSpacing: true,
                    anticipatePin: 1,
                    invalidateOnRefresh: true,
                    refreshPriority: -1
                }
            });

            var cards = document.querySelectorAll('.review-card');
            cards.forEach(function(card) {
                card.addEventListener('mouseenter', function() {
                    gsap.to(card, {
                        scale: 1.02,
                        duration: 0.3,
                        ease: "power2.out"
                    });
                });
                card.addEventListener('mouseleave', function() {
                    gsap.to(card, {
                        scale: 1,
                        duration: 0.3,
                        ease: "power2.out"
                    });
                });
            });

            window.addEventListener('resize', function() {
                ScrollTrigger.refresh();
            });
        };

        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', initReviewSlider);
        } else {
            initReviewSlider();
        }
    })();
</script>