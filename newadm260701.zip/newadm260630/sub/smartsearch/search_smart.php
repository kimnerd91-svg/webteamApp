<?php

/**
 * search_smart.php  —  통합검색 결과 페이지
 * ---------------------------------------------------------------------------
 * search_index.json을 읽어 검색어와 매칭 → 매크로 답변(타이핑) + 위키 설명
 * + 진료 페이지 링크박스 + FAQ 일부 + 연관진료를 보여준다.
 *
 * 배치 위치: /sub/smartsearch/search_smart.php  (두 단계 위가 루트)
 * 접속:      /sub/smartsearch/search_smart.php?q=스케일링
 * 색인 갱신: /sub/smartsearch/build_index.php (관리자)
 * ---------------------------------------------------------------------------
 */

header('X-Robots-Tag: noindex, nofollow', true); // 검색 결과 페이지는 색인 제외

@chdir(dirname(__FILE__) . '/../..');  // /sub/smartsearch/ → 루트
include_once('./_common.php');

// tail.php 배너 기본값 (다른 진료 페이지와 동일)
$banner_settings = ['effect' => 'slide', 'loop' => 1, 'speed' => 600, 'autoplay_delay' => 3000];

// ── 색인 로드 ──
$INDEX = [];
$index_file = G5_DATA_PATH . '/search_index.json';
if (is_file($index_file)) {
  $j = json_decode(@file_get_contents($index_file), true);
  if (!empty($j['items']) && is_array($j['items'])) $INDEX = $j['items'];
}

// ── 검색어 ──
$q = isset($_GET['q']) ? trim((string) $_GET['q']) : '';

// ── 매칭 ──
function ss_norm($s)
{
  return preg_replace('/\s+/u', '', mb_strtolower($s, 'UTF-8'));
}

// 표현 정규화: 공백 제거 + 통증/감각어 어간 통일. (부위어는 ss_match에서 동의어 그룹으로 처리)
function ss_canon($s)
{
  $s = ss_norm($s);
  $map = [
    '아파요' => '아파',
    '아픕니다' => '아파',
    '아픔' => '아파',
    '아프' => '아파',
    '쑤셔' => '아파',
    '쑤시' => '아파',
    '욱신거려' => '욱신',
    '욱신거' => '욱신',
    '찌릿' => '욱신',
    '시려요' => '시려',
    '시린' => '시려',
    '시림' => '시려',
    '시리' => '시려',
  ];
  foreach ($map as $from => $to) {
    $s = str_replace($from, $to, $s);
  }
  return $s;
}

// 부위어 동의어 그룹: 한 그룹 안의 단어는 서로 같은 것으로 취급.
$GLOBALS['SS_SYN_GROUPS'] = [
  ['이', '이빨', '치아', '어금니', '앞니', '윗니', '아랫니', '잇빨'],
];

// 부분일치 + 부위어 동의어 치환까지 고려한 매칭.
// 검색어/단서를 동의어 그룹의 대표어로 환원한 뒤 양방향 부분일치.
function ss_match($nq, $cue)
{
  if ($nq === '' || $cue === '') return false;
  $orig_len = mb_strlen($nq);   // 동의어 환원 전 원본 길이로 과매칭 판정
  // 동의어 그룹: 그룹 내 모든 표기를 대표어(첫 단어)로 환원
  foreach ($GLOBALS['SS_SYN_GROUPS'] as $grp) {
    $rep = $grp[0];
    for ($i = 1; $i < count($grp); $i++) {
      $nq = str_replace($grp[$i], $rep, $nq);
      $cue = str_replace($grp[$i], $rep, $cue);
    }
  }
  if (mb_strpos($nq, $cue) !== false) return true;              // 검색어 ⊃ 단서
  if ($orig_len >= 2 && mb_strpos($cue, $nq) !== false) return true; // 단서 ⊃ 검색어(원본 2글자+)
  return false;
}

function ss_find($index, $path)
{
  foreach ($index as $it) if ($it['path'] === $path) return $it;
  return null;
}

$nq        = $q !== '' ? ss_norm($q) : '';
$matches   = [];   // 키워드 정확 매칭 결과
$mode      = 'none'; // exact | suggest | none

// 1) 키워드 정확 매칭 (가장 긴 키워드 우선)
if ($nq !== '' && $INDEX) {
  foreach ($INDEX as $item) {
    $score = 0;
    foreach ($item['keywords'] as $kw) {
      $nk = ss_norm($kw);
      if ($nk !== '' && mb_strpos($nq, $nk) !== false) {
        $score = max($score, mb_strlen($nk));
      }
    }
    if ($score > 0) {
      $item['_score'] = $score;
      $matches[] = $item;
    }
  }
  usort($matches, function ($a, $b) {
    return $b['_score'] <=> $a['_score'];
  });
}

// 2) 증상 추론 (정확 매칭이 없을 때) — "턱이 아파요" 같은 자연어 문장 대응
$suggest_items = [];   // 추론된 후보 진료들
$suggest_label = '';   // 추론된 증상 분류명
if (!$matches && $nq !== '') {
  // 증상규칙·통증어를 DB(dm_ss_symptom)에서 로드.
  // (구버전 search_symptoms.php는 smartsearch_manager로 완전 이관 — 파일 의존 제거됨)
  $SY = ['_pain_words' => [], 'rules' => []];
  if (function_exists('sql_query')) {
    $pw = sql_fetch("SELECT cue_any FROM dm_ss_symptom WHERE kind='painwords' LIMIT 1");
    if ($pw && !empty($pw['cue_any'])) {
      $d = json_decode($pw['cue_any'], true);
      if (is_array($d)) {
        $SY['_pain_words'] = $d;
      }
    }
    $rq = sql_query("SELECT cue_any, with_pain, paths, label FROM dm_ss_symptom WHERE kind='rule' ORDER BY sort, id");
    if ($rq) {
      while ($rr = sql_fetch_array($rq)) {
        $any = json_decode($rr['cue_any'] ?? '', true);
        if (!is_array($any)) $any = [];
        $pth = json_decode($rr['paths'] ?? '', true);
        if (!is_array($pth)) $pth = [];
        if (!$any) continue;
        $SY['rules'][] = ['any' => $any, 'with' => !empty($rr['with_pain']), 'paths' => $pth, 'label' => $rr['label'] ?? ''];
      }
    }
  }

  $pain_words = $SY['_pain_words'] ?? [];
  $has_pain = false;
  $nq_canon = ss_canon($q);
  foreach ($pain_words as $pw) {
    if (ss_match($nq_canon, ss_canon($pw))) {
      $has_pain = true;
      break;
    }
  }

  $rule_scores = []; // path => score
  $labels      = [];
  foreach (($SY['rules'] ?? []) as $rule) {
    $hit = false;
    foreach (($rule['any'] ?? []) as $cue) {
      if (ss_match($nq_canon, ss_canon($cue))) {
        $hit = true;
        break;
      }
    }
    if (!$hit) continue;
    // 'with' 규칙은 통증어가 함께 있어야 강한 가중치
    $weight = 2;
    if (!empty($rule['with'])) $weight = $has_pain ? 3 : 1;
    $rank = 0;
    foreach (($rule['paths'] ?? []) as $p) {
      $add = $weight + (count($rule['paths']) - $rank) * 0.1; // 앞 경로 우대
      $rule_scores[$p] = ($rule_scores[$p] ?? 0) + $add;
      $rank++;
    }
    if (!empty($rule['label'])) $labels[] = $rule['label'];
  }
  arsort($rule_scores);
  foreach (array_keys($rule_scores) as $p) {
    $it = ss_find($INDEX, $p);
    if ($it) {
      $it['_score'] = $rule_scores[$p];
      $suggest_items[] = $it;
    }
    if (count($suggest_items) >= 4) break;
  }
  $suggest_label = $labels ? $labels[0] : '';
}

// 3) 모드 판정
if ($matches) {
  // 정확 매칭이 있어도, 점수 1위와 2위가 같으면(애매) suggest로 본다
  if (count($matches) >= 2 && $matches[0]['_score'] === $matches[1]['_score']) {
    $mode = 'suggest';
    $suggest_items = array_slice($matches, 0, 4);
  } elseif ($matches[0]['_score'] <= 2 && count($matches) >= 2) {
    // 1위 매칭이 짧은 단서(2글자 이하)면 확정으로 보지 않고 후보 안내로.
    // 예: "이가 아파요"의 짧은 부위어가 한 진료에만 걸려도 단독 확정하지 않음.
    $mode = 'suggest';
    $suggest_items = array_slice($matches, 0, 4);
  } else {
    $mode = 'exact';
  }
} elseif ($suggest_items) {
  $mode = 'suggest';
}

$primary = ($mode === 'exact') ? $matches[0] : null;

// 연관진료(정확 매칭 모드): 다른 매칭 + 인덱스의 related 합쳐 중복 제거(최대 4)
$related_items = [];
if ($primary) {
  $seen = [$primary['path'] => true];
  foreach (array_slice($matches, 1) as $m) {
    if (!isset($seen[$m['path']])) {
      $related_items[] = $m;
      $seen[$m['path']] = true;
    }
  }
  foreach (($primary['related'] ?? []) as $rp) {
    if (isset($seen[$rp])) continue;
    $it = ss_find($INDEX, $rp);
    if ($it) {
      $related_items[] = $it;
      $seen[$rp] = true;
    }
  }
  $related_items = array_slice($related_items, 0, 4);
}

// ── 매크로 문장 (진료명 슬롯) ──
$site = $cf_site_name ?: '저희 치과';  // 그누보드 설정의 사이트명을 사용, 없을 때만 이 기본값
$site_phrase = ($cf_site_name ? '저희 ' . $site : $site);  // 사이트명 있으면 '저희 OO치과', 없으면 '저희 치과'
$templates = [
  '{name}에 관한 정보를 찾고 계시는군요. 아래에서 확인해 보세요.',
  '{name}에 대해 안내해 드릴게요.',
  $site_phrase . '에서는 {name} 진료를 제공하고 있습니다.',
  '{name}, 잘 찾아오셨어요. 핵심만 간단히 정리해 드렸습니다.',
  '{name} 관련 정보를 모아봤어요.',
];
$macro = $primary ? str_replace('{name}', $primary['name'], $templates[array_rand($templates)]) : '';

// 추론(suggest) 모드용 친화적 안내 문장 — 여러 진료가 후보일 때 "골라보세요" 톤
$suggest_templates = [
  "'{q}'은(는) 여러 진료와 관련될 수 있어요. 이 중 어디에 가까우신가요? 눌러서 확인해 보세요.",
  "'{q}' 증상은 아래 진료들과 관련 있을 수 있어요. 가장 가까운 항목을 선택해 보세요.",
  "'{q}'만으로는 하나로 좁히기 어려워요. 아래 중 본인 상황에 가까운 진료를 눌러보세요.",
];
$suggest_macro = ($mode === 'suggest')
  ? str_replace('{q}', $q, $suggest_templates[array_rand($suggest_templates)])
  : '';

// 페이지 타이틀
$g5['title'] = $q !== '' ? "'{$q}' 검색 결과" : '통합검색';

include_once(G5_PATH . '/head_sub.php');
include_once(G5_PATH . '/head.php');

$e = function ($s) {
  return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
};
?>
<main class="u-pretendard" id="smartSearch" style="min-height:80vh">
  <section class="u-py-150 u-py-80-sm">
    <div class="ss-wrap">
      <div class="ss-brand"><?= $e($site) ?></div>
      <div class="ss-lead">무엇이 궁금하세요?</div>

      <form class="ss-form" method="get" action="">
        <input type="text" name="q" value="<?= $e($q) ?>" placeholder="예: 스케일링, 또는 '스케일링 받은 지 오래됐어요'" autocomplete="off" autofocus>
        <button type="submit">검색</button>
      </form>

      <?php if ($q === ''): ?>
        <div class="ss-pop">
          <?php foreach (['스케일링', '신경치료', '사랑니', '임플란트', '치아미백'] as $pop): ?>
            <a class="ss-chip" href="?q=<?= urlencode($pop) ?>"><?= $e($pop) ?></a>
          <?php endforeach; ?>
        </div>

      <?php elseif ($mode === 'suggest'): ?>
        <!-- 추론 제안: 애매한 질문/증상 문장 -->
        <div class="ss-answer ss-seq" id="ssAnswer" data-text="<?= $e($suggest_macro) ?>"><?= $e($suggest_macro) ?></div>

        <?php if ($suggest_label): ?>
          <p class="ss-summary ss-seq" style="animation-delay:.05s">관련 키워드: <b><?= $e($suggest_label) ?></b></p>
        <?php endif; ?>

        <div class="ss-suggest ss-seq" style="animation-delay:.1s">
          <?php foreach ($suggest_items as $i => $s): ?>
            <a class="ss-sug-card" href="<?= $e($s['url']) ?>" style="animation-delay:<?= 0.12 + $i * 0.06 ?>s">
              <span class="ss-sug-ic">🦷</span>
              <span class="ss-sug-body">
                <span class="ss-sug-name"><?= $e($s['name']) ?></span>
                <?php if (!empty($s['summary'])): ?>
                  <span class="ss-sug-desc"><?= $e(mb_substr($s['summary'], 0, 60, 'UTF-8')) ?><?= mb_strlen($s['summary'], 'UTF-8') > 60 ? '…' : '' ?></span>
                <?php endif; ?>
              </span>
              <span class="ss-arrow">→</span>
            </a>
          <?php endforeach; ?>
        </div>

        <p style="color:var(--gray-500);font-size:13px;text-align:center;margin-top:22px">
          찾으시는 게 없다면 <b><?= $e($site) ?></b>에 직접 문의해 주세요. 정확한 상태는 진료를 통해 확인하실 수 있습니다.
        </p>

      <?php elseif ($mode === 'none'): ?>
        <div class="ss-empty">
          <?php if (mb_strlen($q) <= 1): ?>
            한 글자만으로는 찾기 어려워요.<br>
            증상을 문장으로 적어주시면 더 정확히 안내해 드려요. (예: 치아가 빠졌어요, 어금니가 시려요)
          <?php else: ?>
            '<b><?= $e($q) ?></b>'에 딱 맞는 진료를 찾지 못했어요.<br>
            아래 검색어로 다시 시도하시거나, 증상을 편하게 적어보세요. (예: 치아가 빠졌어요)
          <?php endif; ?>
          <div class="ss-pop" style="justify-content:center">
            <?php foreach (['스케일링', '신경치료', '임플란트', '사랑니', '잇몸치료'] as $pop): ?>
              <a class="ss-chip" href="?q=<?= urlencode($pop) ?>"><?= $e($pop) ?></a>
            <?php endforeach; ?>
          </div>
        </div>

      <?php else: ?>
        <!-- 1) 매크로 답변 (JS가 타이핑) -->
        <div class="ss-answer ss-seq" id="ssAnswer" data-text="<?= $e($macro) ?>"><?= $e($macro) ?></div>

        <!-- 2) 위키 일반 설명 -->
        <?php if (!empty($primary['wiki']['text'])): ?>
          <div class="ss-card ss-wiki ss-seq" style="animation-delay:.05s">
            <span class="ss-tag">위키백과 · 일반 설명</span>
            <p><?= $e($primary['wiki']['text']) ?></p>
            <?php if (!empty($primary['wiki']['url'])): ?>
              <div class="ss-src">출처: <a href="<?= $e($primary['wiki']['url']) ?>" target="_blank" rel="noopener">위키백과 — <?= $e($primary['wiki']['title'] ?? '문서') ?></a></div>
            <?php endif; ?>
          </div>
        <?php endif; ?>

        <!-- 2-1) 사전 용어 풀이 (dm_dict 연동) -->
        <?php if (!empty($primary['dict_terms']) && is_array($primary['dict_terms'])): ?>
          <div class="ss-card ss-dict ss-seq" style="animation-delay:.08s">
            <span class="ss-tag">용어 풀이</span>
            <?php foreach ($primary['dict_terms'] as $dt): if (empty($dt['definition'])) continue; ?>
              <div class="ss-dict-row">
                <b class="ss-dict-term"><?= $e($dt['term']) ?></b>
                <span class="ss-dict-def"><?= $e($dt['definition']) ?></span>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>

        <!-- 3) 진료 페이지 링크박스 -->
        <a class="ss-proc ss-seq" style="animation-delay:.12s" href="<?= $e($primary['url']) ?>">
          <span class="ss-ic">🦷</span>
          <span>
            <span class="ss-k"><?= $e($site) ?>의<?= $primary['category'] ? ' · ' . $e($primary['category']) : '' ?></span><br>
            <span class="ss-t"><?= $e($primary['name']) ?></span>
          </span>
          <span class="ss-arrow">→</span>
        </a>
        <?php if (!empty($primary['summary'])): ?>
          <p class="ss-summary"><?= $e($primary['summary']) ?></p>
        <?php endif; ?>

        <!-- 4) FAQ 일부 -->
        <?php if (!empty($primary['faqs'])): ?>
          <div class="ss-faqhead ss-seq" style="animation-delay:.18s">
            <h3>자주 묻는 질문</h3>
            <a href="<?= $e($primary['url']) ?>">전체 FAQ 보기 →</a>
          </div>
          <?php foreach (array_slice($primary['faqs'], 0, 3) as $i => $f): ?>
            <div class="ss-faq ss-seq" style="animation-delay:<?= 0.2 + $i * 0.05 ?>s">
              <button type="button" class="ss-q"><span><?= $e($f['q']) ?></span><span class="ss-pm">+</span></button>
              <div class="ss-a">
                <p><?= $e($f['a']) ?></p>
              </div>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>

        <!-- 5) 연관진료 -->
        <?php if ($related_items): ?>
          <div class="ss-faqhead ss-seq" style="animation-delay:.3s;margin-top:30px">
            <h3>이런 진료도 찾으시나요?</h3>
          </div>
          <div class="ss-related ss-seq" style="animation-delay:.32s">
            <?php foreach ($related_items as $r): ?>
              <a class="ss-chip" href="<?= $e($r['url']) ?>"><?= $e($r['name']) ?></a>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>

        <p style="color:var(--gray-500);font-size:13px;text-align:center;margin-top:24px">
          더 궁금한 점은 <a href="<?= $e($primary['url']) ?>" style="color:var(--ss-pine)"><?= $e($primary['name']) ?> 페이지</a>에서 전체 내용을 확인하세요.
        </p>
      <?php endif; ?>
    </div>
  </section>

</main>

<script>
  (function() {
    // 매크로 타이핑 효과 (JS 꺼져 있어도 텍스트는 이미 보임)
    var el = document.getElementById('ssAnswer');
    if (el) {
      var text = el.getAttribute('data-text') || el.textContent;
      el.textContent = '';
      var cur = document.createElement('span');
      cur.className = 'ss-cursor';
      el.appendChild(cur);
      var i = 0;
      (function tick() {
        if (i < text.length) {
          cur.insertAdjacentText('beforebegin', text[i++]);
          setTimeout(tick, 45);
        } else {
          setTimeout(function() {
            cur.remove();
          }, 600);
        }
      })();
    }
    // FAQ 아코디언
    document.querySelectorAll('#smartSearch .ss-faq').forEach(function(item) {
      var q = item.querySelector('.ss-q'),
        a = item.querySelector('.ss-a');
      q.addEventListener('click', function() {
        var open = item.classList.toggle('open');
        a.style.maxHeight = open ? a.scrollHeight + 'px' : '0';
      });
    });
  })();
</script>

<?php include_once(G5_PATH . '/tail.php'); ?>