<?php
/**
 * dict.php  —  치과 용어사전 (사용자 프론트)
 * ---------------------------------------------------------------------------
 * dm_dict를 ㄱ~ㅎ / A~Z 색인으로 보여주는 용어사전 페이지.
 *   - 관리: /newadm 또는 smartsearch 폴더의 dict_manager.php
 *   - 데이터: dm_dict (term, initial, definition, wiki_text, wiki_url, synonyms, related)
 * 배치: /sub/smartsearch/dict.php (두 단계 위가 루트)
 * 접속: /sub/smartsearch/dict.php           → 전체(색인)
 *       /sub/smartsearch/dict.php?ini=ㄱ     → 초성 필터
 *       /sub/smartsearch/dict.php?q=임플란트 → 검색
 *       /sub/smartsearch/dict.php?term=임플란트 → 특정 용어 상세
 * ---------------------------------------------------------------------------
 */

@chdir(dirname(__FILE__) . '/../..');   // /sub/smartsearch/ → 루트
include_once('./_common.php');

$banner_settings = ['effect' => 'slide', 'loop' => 1, 'speed' => 600, 'autoplay_delay' => 3000];

$T = 'dm_dict';
$INITIALS = ['ㄱ','ㄴ','ㄷ','ㄹ','ㅁ','ㅂ','ㅅ','ㅇ','ㅈ','ㅊ','ㅋ','ㅌ','ㅍ','ㅎ'];
$ALPHA    = range('A','Z');

$q    = trim((string)($_GET['q'] ?? ''));
$ini  = trim((string)($_GET['ini'] ?? ''));
$term = trim((string)($_GET['term'] ?? ''));

function dd_e($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function dd_arr($json){ $a = json_decode($json ?? '', true); return is_array($a) ? $a : []; }
function dd_esc($s){ return function_exists('sql_real_escape_string') ? sql_real_escape_string($s) : addslashes($s); }

// ── 진료 경로 → 진료명 매핑 (related 표시용, search_index.json 활용) ──
$PATH_NAME = [];
$idxf = G5_DATA_PATH . '/search_index.json';
if (is_file($idxf)) {
    $j = json_decode(@file_get_contents($idxf), true);
    if (!empty($j['items'])) foreach ($j['items'] as $it) {
        if (!empty($it['path'])) $PATH_NAME[$it['path']] = ['name'=>$it['name'] ?? $it['path'], 'url'=>$it['url'] ?? $it['path']];
    }
}

// ── 데이터 조회 ──
$detail = null;      // 단일 용어 상세
$list   = [];        // 목록
$mode   = 'index';   // index | list | search | detail

if ($term !== '') {
    $mode = 'detail';
    $detail = sql_fetch("SELECT * FROM `{$T}` WHERE term='".dd_esc($term)."' LIMIT 1");
    if (!$detail) $mode = 'index';
}
elseif ($q !== '') {
    $mode = 'search';
    $qe = dd_esc($q);
    // 용어명 + 정의 + 유의어(JSON 텍스트)에서 검색
    $r = sql_query("SELECT * FROM `{$T}`
        WHERE term LIKE '%{$qe}%' OR definition LIKE '%{$qe}%' OR synonyms LIKE '%{$qe}%'
        ORDER BY (term LIKE '{$qe}%') DESC, term ASC LIMIT 100");
    if ($r) while ($row = sql_fetch_array($r)) $list[] = $row;
}
elseif ($ini !== '') {
    $mode = 'list';
    $r = sql_query("SELECT * FROM `{$T}` WHERE initial='".dd_esc($ini)."' ORDER BY term ASC");
    if ($r) while ($row = sql_fetch_array($r)) $list[] = $row;
}
else {
    // index 모드: 전체 용어(간단 목록)
    $r = sql_query("SELECT id,term,initial,definition FROM `{$T}` ORDER BY term ASC LIMIT 300");
    if ($r) while ($row = sql_fetch_array($r)) $list[] = $row;
}

// 초성별 개수 (탭 비활성화용 — 모든 모드 공통)
$counts = [];
$cr = sql_query("SELECT initial, COUNT(*) c FROM `{$T}` GROUP BY initial");
if ($cr) while ($row = sql_fetch_array($cr)) $counts[$row['initial']] = (int)$row['c'];

$site = (isset($config) && !empty($config['cf_title'])) ? $config['cf_title'] : '';
$g5['title'] = '치과 용어사전' . ($q !== '' ? " — '{$q}' 검색" : '');

include_once(G5_PATH . '/head_sub.php');
include_once(G5_PATH . '/head.php');
?>

<main class="dd-wrap u-pretendard">

<section class="u-py-150 u-py-80-sm">
  <div class="dd-head">
    <h1>치과 용어사전</h1>
    <p>치과 진료에서 자주 쓰이는 용어를 쉽게 풀어 설명합니다.</p>
    <form class="dd-search" method="get" action="">
      <input type="text" name="q" value="<?= dd_e($q) ?>" placeholder="용어를 검색해 보세요 (예: 임플란트, 신경치료)" aria-label="용어 검색">
      <button type="submit" aria-label="검색"><span class="material-symbols-outlined">search</span></button>
    </form>
  </div>

  <?php if ($mode === 'detail'): ?>
    <!-- ── 용어 상세 ── -->
    <a class="dd-back" href="?ini=<?= urlencode($detail['initial']) ?>"><span class="material-symbols-outlined" style="font-size:18px;">arrow_back</span>목록으로</a>
    <div class="dd-detail">
      <h2 class="dterm"><?= dd_e($detail['term']) ?></h2>
      <?php $syn = dd_arr($detail['synonyms']); if ($syn): ?>
        <p class="dsyn">다른 표현: <?= dd_e(implode(', ', $syn)) ?></p>
      <?php endif; ?>

      <?php if (!empty($detail['definition'])): ?>
        <div class="ddef"><?= nl2br(dd_e($detail['definition'])) ?></div>
      <?php endif; ?>
      <?php if (!empty($detail['wiki_text']) && $detail['wiki_text'] !== $detail['definition']): ?>
        <p class="dmore"><?= nl2br(dd_e($detail['wiki_text'])) ?></p>
      <?php endif; ?>
      <?php if (!empty($detail['wiki_url'])): ?>
        <p class="dsrc">참고: <a href="<?= dd_e($detail['wiki_url']) ?>" target="_blank" rel="noopener"><?= dd_e($detail['wiki_title'] ?: '위키백과') ?></a></p>
      <?php endif; ?>

      <?php
        $rel = dd_arr($detail['related']);
        $rel_show = [];
        foreach ($rel as $rp) { if (isset($PATH_NAME[$rp])) $rel_show[] = $PATH_NAME[$rp]; }
      ?>
      <?php if ($rel_show): ?>
        <div class="dd-rel">
          <h3>이 용어와 관련된 진료</h3>
          <div class="dd-rel-list">
            <?php foreach ($rel_show as $rs): ?>
              <a href="<?= dd_e($rs['url']) ?>">🦷 <?= dd_e($rs['name']) ?> <span style="opacity:.6;">→</span></a>
            <?php endforeach; ?>
          </div>
        </div>
      <?php endif; ?>
    </div>

  <?php else: ?>
    <!-- ── 색인 탭 (ㄱ~ㅎ + A~Z) ── -->
    <div class="dd-tabs">
      <a class="dd-tab <?= ($ini===''&&$q==='')?'active':'' ?>" href="?">전체</a>
      <?php foreach ($INITIALS as $c): $has = !empty($counts[$c]); ?>
        <a class="dd-tab <?= $ini===$c?'active':'' ?> <?= $has?'':'off' ?>" href="?ini=<?= urlencode($c) ?>"><?= dd_e($c) ?></a>
      <?php endforeach; ?>
      <?php foreach ($ALPHA as $c): $has = !empty($counts[$c]); if(!$has && $ini!==$c) continue; ?>
        <a class="dd-tab <?= $ini===$c?'active':'' ?> <?= $has?'':'off' ?>" href="?ini=<?= urlencode($c) ?>"><?= dd_e($c) ?></a>
      <?php endforeach; ?>
    </div>

    <?php if ($mode === 'search'): ?>
      <p class="dd-sec-h">'<?= dd_e($q) ?>' 검색 결과 <?= count($list) ?>건</p>
    <?php elseif ($mode === 'list'): ?>
      <p class="dd-sec-h"><?= dd_e($ini) ?> · <?= count($list) ?>개 용어</p>
    <?php endif; ?>

    <?php if (!$list): ?>
      <div class="dd-empty">
        <?php if ($mode==='search'): ?>'<?= dd_e($q) ?>'에 해당하는 용어가 없어요.<?php else: ?>등록된 용어가 없습니다.<?php endif; ?>
      </div>
    <?php else: ?>
      <div class="dd-grid">
        <?php foreach ($list as $row): ?>
          <a class="dd-card" href="?term=<?= urlencode($row['term']) ?>">
            <div class="t"><?= dd_e($row['term']) ?></div>
            <?php if (!empty($row['definition'])): ?>
              <div class="d"><?= dd_e($row['definition']) ?></div>
            <?php endif; ?>
          </a>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

  <?php endif; ?>
</section>
</main>

<?php include_once(G5_PATH . '/tail.php'); ?>
