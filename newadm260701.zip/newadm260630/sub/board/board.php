<?php
chdir(dirname(__FILE__) . '/..');
include_once('./_common.php');

$wr_id    = isset($_GET['wr_id'])    ? (int)$_GET['wr_id']                               : 0;
$bo_table = isset($_GET['bo_table']) ? preg_replace('/[^a-z0-9_]/i','', $_GET['bo_table']) : 'column';
if (!$wr_id) { header('Location: /'); exit; }

$write_table = $g5['write_prefix'] . $bo_table;
$post = sql_fetch("SELECT * FROM {$write_table} WHERE wr_id = {$wr_id} AND wr_is_comment = 0");
if (!$post) { header('Location: /'); exit; }

if (empty($_SESSION['viewed_column_'.$wr_id])) {
    sql_query("UPDATE {$write_table} SET wr_hit = wr_hit + 1 WHERE wr_id = {$wr_id}");
    $_SESSION['viewed_column_'.$wr_id] = true;
    $post['wr_hit'] = (int)$post['wr_hit'] + 1;
}

$prev = sql_fetch("SELECT wr_id,wr_subject FROM {$write_table} WHERE wr_is_comment=0 AND wr_id>{$wr_id} ORDER BY wr_id ASC LIMIT 1");
$next = sql_fetch("SELECT wr_id,wr_subject FROM {$write_table} WHERE wr_is_comment=0 AND wr_id<{$wr_id} ORDER BY wr_id DESC LIMIT 1");
$date = $post['wr_datetime'] ? date('Y.m.d', strtotime($post['wr_datetime'])) : '';

$editor_type = $post['wr_1'] ?? '';
$raw_content = stripslashes($post['wr_content'] ?? '');
if (!$editor_type) {
    $probe = json_decode($raw_content, true);
    $editor_type = (is_array($probe) && isset($probe['rows'])) ? 'builder' : 'editor';
}

$PAD_MAP = ['default'=>'8px 10px','sm'=>'4px 8px','md'=>'12px 16px','lg'=>'20px 24px','xl'=>'32px 36px'];

function pb_style(array $s=[], array $extra=[]): string {
    $css=[];
    if (!empty($s['fontSize']))     $css[]='font-size:'.(int)$s['fontSize'].'px';
    if (!empty($s['fontWeight']))   $css[]='font-weight:'.(int)$s['fontWeight'];
    if (!empty($s['textAlign']))    $css[]='text-align:'.$s['textAlign'];
    if (!empty($s['color']))        $css[]='color:'.$s['color'];
    if (!empty($s['lineHeight']))   $css[]='line-height:'.$s['lineHeight'];
    if (isset($s['letterSpacing'])) $css[]='letter-spacing:'.(float)$s['letterSpacing'].'px';
    foreach ($extra as $k=>$v)      $css[]=$k.':'.$v;
    return $css ? ' style="'.implode(';',$css).'"' : '';
}

function pb_block(array $block, array $padMap): string {
    $d=$block['data']??[]; $s=$d['style']??[]; $bg=$d['bgColor']??''; $pd=$d['padding']??'default';
    $we=[]; if($bg) $we['background']=$bg; if(!empty($padMap[$pd])) $we['padding']=$padMap[$pd];
    $wA=$we?' style="'.implode(';',array_map(fn($k,$v)=>"$k:$v",array_keys($we),$we)).'"':'';
    $si=pb_style($s);
    switch($block['type']??''){
        case 'paragraph': return '<p class="pb-p"'.$wA.'><span'.$si.'>'.($d['text']??'').'</span></p>';
        case 'h2': return '<h2 class="pb-h2"'.$wA.$si.'>'.($d['text']??'').'</h2>';
        case 'h3': return '<h3 class="pb-h3"'.$wA.$si.'>'.($d['text']??'').'</h3>';
        case 'h4': return '<h4 class="pb-h4"'.$wA.$si.'>'.($d['text']??'').'</h4>';
        case 'quote': return '<blockquote class="pb-quote"'.$wA.'><span'.$si.'>'.($d['text']??'').'</span></blockquote>';
        case 'warning': return '<div class="pb-warning"'.$wA.'><p class="pb-warning-title">'.($d['title']??'').'</p><p'.$si.'>'.($d['text']??'').'</p></div>';
        case 'image':
            if(empty($d['url']))return'';
            $alt=htmlspecialchars($d['alt']??''); $br=isset($d['borderRadius'])?'border-radius:'.(int)$d['borderRadius'].'px;':'';
            return '<figure class="pb-image"'.$wA.'><img src="'.$d['url'].'" alt="'.$alt.'" loading="lazy" style="max-width:100%;height:auto;display:block;'.$br.'">'.($alt?'<figcaption class="pb-caption">'.$alt.'</figcaption>':'').'</figure>';
        case 'list':
            $items=$d['items']??[]; if(!$items)return'';
            return '<ul class="pb-list"'.$wA.'>'.implode('',array_map(fn($it)=>'<li'.$si.'>'.$it.'</li>',$items)).'</ul>';
        case 'delimiter': return '<div class="pb-delimiter"><span>&bull; &bull; &bull;</span></div>';
        case 'table':
            $rows=$d['rows']??[]; if(!$rows)return'';
            $h='<div class="pb-table-wrap"'.$wA.'><table class="pb-table">';
            foreach($rows as $ri=>$row){$h.='<tr>';foreach($row as $cell){$tag=$ri===0?'th':'td';$h.="<{$tag}{$si}>{$cell}</{$tag}>";}$h.='</tr>';}
            return $h.'</table></div>';
        case 'button': return '<div class="pb-button-wrap"'.$wA.'><a href="#" class="pb-button"'.$si.'>'.($d['text']??'버튼').'</a></div>';
        default: return '';
    }
}

function render_builder(string $raw, array $padMap): array {
    $data=json_decode($raw,true);
    if(!$data||empty($data['rows'])) return ['html'=>'<div class="pb-legacy">'.stripslashes($raw).'</div>','toc'=>[]];
    $html='<div class="pb-root">'; $toc=[];
    foreach($data['rows'] as $ri=>$row){
        $cols=$row['columns']??[]; if(!$cols)continue;
        $h2text='';
        foreach($cols as $col){foreach($col['blocks']??[] as $b){if($b['type']==='h2'){$h2text=strip_tags($b['data']['text']??'');break 2;}}}
        $secId=trim($row['sectionId']??'');
        if(!$secId&&$h2text) $secId='sec-'.$ri;
        if($secId){ $label=$h2text?:'섹션 '.($ri+1); $toc[]=['id'=>$secId,'label'=>$label]; }
        $idAttr=$secId?' id="'.htmlspecialchars($secId).'"':'';
        $html.='<div class="pb-row"'.$idAttr.'>';
        foreach($cols as $col){
            $span=isset($col['span'])?(int)$col['span']:12;
            $html.='<div class="pb-col pb-col-'.$span.'">';
            foreach($col['blocks']??[] as $block){$r=pb_block($block,$padMap);if($r)$html.=$r;}
            $html.='</div>';
        }
        $html.='</div>';
    }
    $html.='</div>';
    return ['html'=>$html,'toc'=>$toc];
}

function render_editor(string $html): array {
    if(!$html) return ['html'=>'','toc'=>[]];
    $toc=[]; $count=[];
    $result=preg_replace_callback('/<h2([^>]*)>(.*?)<\/h2>/is',function($m)use(&$toc,&$count){
        $attrs=$m[1]; $inner=$m[2]; $text=strip_tags($inner);
        if(preg_match('/\bid=["\']([^"\']+)["\']/',$attrs,$im)){$id=$im[1];}
        else{
            $slug=preg_replace('/[^a-z0-9가-힣\-_]/u','-',preg_replace('/\s+/','-',mb_strtolower(trim($text))));
            $slug=trim($slug,'-')?:'section'; $base=$slug;
            if(isset($count[$base])){$count[$base]++;$slug=$base.'-'.$count[$base];}else{$count[$base]=0;}
            $id=$slug; $attrs.=' id="'.htmlspecialchars($id).'"';
        }
        $toc[]=['id'=>$id,'label'=>$text];
        return '<h2'.$attrs.'>'.$inner.'</h2>';
    },$html);
    return ['html'=>'<div class="pb-legacy">'.$result.'</div>','toc'=>$toc];
}

if($editor_type==='builder') $rendered=render_builder($raw_content,$PAD_MAP);
else $rendered=render_editor($raw_content);
$content_html=$rendered['html'];
$toc_items=$rendered['toc'];

include_once(G5_PATH . '/head_sub.php');
include_once(G5_PATH . '/head.php');
?>
<main class="u-pretendard column">
    <div class="intro d-flex justify-content-center align-items-center flex-column u-gap-20">
        <h6 class="t-fs-20 fw-700 u-lh-14 u-ls-10 u-txt-white">서울다온치과 칼럼</h6>
        <h2 class="t-fs-46 fw-700 u-lh-14 u-ls-15 u-txt-white">원장님 칼럼</h2>
        <p class="c-fs-22 fw-400 u-lh-16 u-ls-10 text-center u-txt-gray-300 u-mt-10">치과 전문의가 전하는 구강 건강 이야기</p>
    </div>
    <div class="content u-py-120 u-1440">
        <!-- aside + 본문영역 flex row -->
        <div class="board-page-wrap">

            <!-- 좌측 목차 (TOC) -->
            <?php if (!empty($toc_items)): ?>
            <aside class="col-toc" id="col-toc">
                <div class="col-toc-inner">
                    <p class="col-toc-title">목차</p>
                    <ul class="col-toc-list">
                        <?php foreach ($toc_items as $item): ?>
                        <li>
                            <a href="#<?php echo htmlspecialchars($item['id']); ?>"
                               class="col-toc-link"
                               data-target="<?php echo htmlspecialchars($item['id']); ?>">
                                <?php echo htmlspecialchars($item['label']); ?>
                            </a>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </aside>
            <?php endif; ?>

            <!-- 우측: 제목 + 본문 + 이전다음 -->
            <div class="board-main u-bt-1 u-bb-1 u-solid u-bc-dark<?php echo empty($toc_items)?' board-main-full':''; ?>">

                <!-- 헤더 -->
                <div class="content_head text-start u-py-30 u-px-20">
                    <span class="c-fs-16 fw-500 u-lh-15 u-ls-10 u-txt-sub">원장님 칼럼</span>
                    <h5 class="t-fs-28 fw-500 u-lh-14 u-ls-10 u-txt-dark"><?php echo htmlspecialchars($post['wr_subject']??''); ?></h5>
                    <div class="d-flex justify-content-between align-items-center">
                        <div class="d-flex u-gap-20">
                            <span class="d-flex u-gap-4 u-txt-gray-500 c-fs-16 fw-400 u-lh-15 u-ls-10">
                                <strong class="t-fs-16 fw-500 u-lh-15 u-ls-10 u-txt-dark">작성자</strong>관리자
                            </span>
                            <span>|</span>
                            <span class="d-flex u-gap-4 u-txt-gray-500 c-fs-16 fw-400 u-lh-15 u-ls-10">
                                <strong class="t-fs-16 fw-500 u-lh-15 u-ls-10 u-txt-dark">조회</strong>
                                <?php echo number_format((int)$post['wr_hit']); ?>
                            </span>
                        </div>
                        <div><p class="c-fs-16 u-txt-gray-500 fw-400 u-lh-15"><?php echo $date; ?></p></div>
                    </div>
                </div>

                <!-- 본문 -->
                <div class="content_body u-bt-1 u-bc-gray-200 u-solid u-py-60 u-px-40">
                    <article class="col-article">
                        <?php echo $content_html; ?>
                    </article>
                </div>

                <!-- 이전/다음 -->
                <div class="content_tail">
                <div class="d-flex align-items-center u-bt-1 u-bc-gray-200 u-solid u-gap-20">
                    <div class="w-max d-flex u-gap-10 align-items-center u-bg-gray-100 u-py-14 u-px-40">
                        <h4 class="t-fs-22 fw-400 u-lh-16 u-ls-10 u-txt-dark"><span class="material-symbols-outlined">keyboard_arrow_up</span>다음글</h4>
                    </div>
                    <div>
                        <?php if($next): ?>
                        <a href="/sub/column.php?wr_id=<?php echo (int)$next['wr_id']; ?>&bo_table=<?php echo $bo_table; ?>" class="c-fs-16 u-txt-gray-700 fw-400 u-lh-14 u-ls-10 text-decoration-none"><?php echo htmlspecialchars($next['wr_subject']??''); ?></a>
                        <?php else: ?><p class="c-fs-16 u-txt-gray-700 fw-400 u-lh-14 u-ls-10">다음글이 없습니다.</p><?php endif; ?>
                    </div>
                </div>
                <div class="d-flex align-items-center u-gap-20">
                    <div class="w-max d-flex u-gap-10 align-items-center u-bg-gray-100 u-py-14 u-px-40">
                        <h4 class="t-fs-22 fw-400 u-lh-16 u-ls-10 u-txt-dark"><span class="material-symbols-outlined">keyboard_arrow_down</span>이전글</h4>
                    </div>
                    <div>
                        <?php if($prev): ?>
                        <a href="/sub/column.php?wr_id=<?php echo (int)$prev['wr_id']; ?>&bo_table=<?php echo $bo_table; ?>" class="c-fs-16 u-txt-gray-700 fw-400 u-lh-14 u-ls-10 text-decoration-none"><?php echo htmlspecialchars($prev['wr_subject']??''); ?></a>
                        <?php else: ?><p class="c-fs-16 u-txt-gray-700 fw-400 u-lh-14 u-ls-10">이전글이 없습니다.</p><?php endif; ?>
                    </div>
                </div><!-- /content_tail -->
            </div><!-- /board-main -->
        </div><!-- /board-page-wrap -->
    </div><!-- /content -->
</main>

<style>
/* ── 전체 레이아웃 ── */
.board-page-wrap{display:flex;align-items:flex-start}
.col-toc{width:220px;flex-shrink:0;position:sticky;top:80px;align-self:flex-start;border-right:1.5px solid var(--gray-200,#e9e9e9)}
.col-toc-inner{padding:40px 20px}
.col-toc-title{font-size:11px;font-weight:800;letter-spacing:1.2px;text-transform:uppercase;color:var(--sub-color,#25456B);margin-bottom:14px;padding-bottom:10px;border-bottom:1.5px solid var(--light,#F0F3F6)}
.col-toc-list{list-style:none;padding:0;margin:0;display:flex;flex-direction:column;gap:2px}
.col-toc-link{display:block;font-size:13px;font-weight:500;color:var(--gray-700,#707070);text-decoration:none;padding:6px 10px;border-radius:7px;border-left:2.5px solid transparent;line-height:1.5;transition:all .18s;word-break:keep-all}
.col-toc-link:hover{background:var(--light,#F0F3F6);color:var(--main-color,#000136)}
.col-toc-link.toc-active{background:var(--light,#F0F3F6);color:var(--main-color,#000136);border-left-color:var(--point,#FABE00);font-weight:700}
.board-main{flex:1;min-width:0}
.col-article{width:100%}

.pb-root{width:100%}
.pb-row{display:flex;flex-wrap:wrap;gap:24px;margin-bottom:32px;scroll-margin-top:120px}
.pb-row:last-child{margin-bottom:0}
.pb-col{flex:1;min-width:0}
.pb-col-1{flex:1}.pb-col-2{flex:2}.pb-col-3{flex:3}.pb-col-4{flex:4}
.pb-col-5{flex:5}.pb-col-6{flex:6}.pb-col-7{flex:7}.pb-col-8{flex:8}
.pb-col-9{flex:9}.pb-col-10{flex:10}.pb-col-11{flex:11}.pb-col-12{flex:12}
.pb-p{margin:0 0 .65em;font-size:16px;line-height:1.75;color:var(--dark,#2c2c2c);word-break:keep-all}
.pb-p:last-child{margin-bottom:0}
.pb-h2{font-size:clamp(20px,2.4vw,28px);font-weight:800;color:var(--main-color,#000136);line-height:1.3;letter-spacing:-0.5px;margin:0 0 12px;word-break:keep-all}
.pb-h3{font-size:clamp(17px,1.9vw,22px);font-weight:700;color:var(--sub-color,#25456B);line-height:1.35;letter-spacing:-0.3px;margin:0 0 10px;word-break:keep-all}
.pb-h4{font-size:clamp(15px,1.5vw,18px);font-weight:700;color:var(--dark,#2c2c2c);line-height:1.4;margin:0 0 8px;word-break:keep-all}
.pb-quote{border-left:4px solid var(--sub-color2,#99B5D7);background:var(--light,#F0F3F6);border-radius:0 8px 8px 0;padding:14px 20px;margin:0 0 16px;font-style:italic;color:var(--sub-color,#25456B);font-size:15px;line-height:1.7}
.pb-warning{background:var(--light2,#FFFBF5);border:1.5px solid var(--point,#FABE00);border-radius:10px;padding:16px 20px;margin:0 0 16px}
.pb-warning-title{font-weight:800;font-size:14px;color:var(--point2,#DD9700);margin-bottom:6px}
.pb-image{margin:0 0 16px}.pb-image img{width:100%;height:auto;display:block}
.pb-caption{font-size:12px;color:var(--gray-600,#969696);text-align:center;margin-top:6px;line-height:1.5}
.pb-list{padding-left:22px;margin:0 0 16px}
.pb-list li{font-size:15px;line-height:1.75;color:var(--dark,#2c2c2c);margin-bottom:5px}
.pb-list li:last-child{margin-bottom:0}
.pb-delimiter{text-align:center;padding:16px 0;color:var(--gray-400,#bbbbbb);font-size:18px;letter-spacing:10px;margin:0 0 16px}
.pb-table-wrap{overflow-x:auto;margin:0 0 16px;-webkit-overflow-scrolling:touch}
.pb-table{width:100%;border-collapse:collapse;font-size:14px;color:var(--dark,#2c2c2c)}
.pb-table th,.pb-table td{border:1.5px solid var(--gray-300,#dedede);padding:8px 12px;line-height:1.5}
.pb-table th{background:var(--light,#F0F3F6);font-weight:700;color:var(--sub-color,#25456B);text-align:center}
.pb-table tr:hover td{background:#fafbfd}
.pb-button-wrap{margin:0 0 16px}
.pb-button{display:inline-flex;align-items:center;justify-content:center;padding:12px 28px;border-radius:8px;background:linear-gradient(135deg,var(--main-color,#000136),var(--sub-color,#25456B));color:#fff!important;font-size:15px;font-weight:700;text-decoration:none!important;transition:opacity .2s,transform .2s;letter-spacing:-0.3px}
.pb-button:hover{opacity:.88;transform:translateY(-1px)}
.pb-legacy{line-height:1.75;color:var(--dark,#2c2c2c)}
.pb-legacy img{max-width:100%;height:auto;border-radius:4px}
.pb-legacy h2{font-size:clamp(20px,2.4vw,28px);font-weight:800;color:var(--main-color,#000136);margin:0 0 12px;scroll-margin-top:120px}
.pb-legacy h3{font-size:clamp(17px,1.9vw,22px);font-weight:700;color:var(--sub-color,#25456B);margin:0 0 10px;scroll-margin-top:120px}

@media(max-width:1024px){.col-toc{width:180px}}
@media(max-width:768px){
    .board-page-wrap{flex-direction:column}
    .col-toc{width:100%;position:static;border-right:none;border-bottom:1.5px solid var(--gray-200,#e9e9e9)}
    .col-toc-inner{padding:20px 16px}
    .col-toc-list{flex-direction:row;flex-wrap:wrap;gap:6px}
    .col-toc-link{padding:5px 10px;border-left:none;border-bottom:2px solid transparent;border-radius:20px;font-size:12px;background:var(--light,#F0F3F6)}
    .col-toc-link.toc-active{border-bottom-color:var(--point,#FABE00);background:var(--light,#F0F3F6)}
    .pb-row{gap:16px;margin-bottom:20px}
    [class*="pb-col-"]{flex:0 0 100%!important}
}
</style>

<script>
(function(){
    var links=document.querySelectorAll('.col-toc-link');
    if(!links.length)return;
    var targets=[].slice.call(links).map(function(l){return document.getElementById(l.dataset.target);}).filter(Boolean);
    if(!targets.length)return;
    var activeIdx=-1;
    function setActive(i){if(i===activeIdx)return;activeIdx=i;links.forEach(function(l){l.classList.remove('toc-active');});if(i>=0)links[i].classList.add('toc-active');}
    function onScroll(){var sy=window.scrollY+window.innerHeight*0.25,best=-1;for(var i=0;i<targets.length;i++){if(targets[i].offsetTop<=sy)best=i;}setActive(best);}
    window.addEventListener('scroll',onScroll,{passive:true});
    onScroll();
    links.forEach(function(link,i){link.addEventListener('click',function(e){e.preventDefault();if(!targets[i])return;var offset=targets[i].getBoundingClientRect().top+window.scrollY-100;window.scrollTo({top:offset,behavior:'smooth'});});});
})();
</script>

<?php include_once(G5_PATH . '/tail.php'); ?>