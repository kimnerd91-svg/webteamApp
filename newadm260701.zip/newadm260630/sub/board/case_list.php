<?php
chdir(dirname(__FILE__) . '/../..');
include_once('./_common.php');

if (isset($_POST['action']) && $_POST['action'] === 'simple_join') {
    $mb_name  = sql_real_escape_string(trim($_POST['mb_name']  ?? ''));
    $mb_hp    = sql_real_escape_string(preg_replace('/[^0-9]/', '', trim($_POST['mb_hp'] ?? '')));
    $mb_email = sql_real_escape_string(trim($_POST['mb_email'] ?? ''));
    if ($mb_name && $mb_hp && $mb_email) {
        $exists = sql_fetch("SELECT mb_id FROM {$g5['member_table']} WHERE mb_hp = '{$mb_hp}'");
        if (!$exists) {
            $mb_id       = 'u' . $mb_hp;
            $mb_password = get_encrypt_string(substr(md5(uniqid()), 0, 8));
            sql_query("INSERT INTO {$g5['member_table']} SET
                mb_id='{$mb_id}', mb_password='{$mb_password}',
                mb_name='{$mb_name}', mb_email='{$mb_email}', mb_hp='{$mb_hp}',
                mb_level=2, mb_datetime='" . G5_TIME_YMDHIS . "',
                mb_email_certify='" . G5_TIME_YMDHIS . "',
                mb_certify='phone', mb_login_ip='{$_SERVER['REMOTE_ADDR']}'");
        }
    }
    // 가입 후 이동할 목적지 (case_view 등). 없으면 현재 페이지로.
    $redirect_to = $_POST['redirect_to'] ?? '';
    // 보안: 내부 경로(/로 시작, // 아님)만 허용
    if (!preg_match('#^/(?!/)#', $redirect_to)) {
        $redirect_to = $_SERVER['REQUEST_URI'];
    }
    header('Location: ' . $redirect_to);
    exit;
}

function safe_sql_query($q)
{
    return function_exists('sql_query') ? sql_query($q) : false;
}
function safe_sql_fetch_array($r)
{
    return function_exists('sql_fetch_array') ? sql_fetch_array($r) : false;
}

$cat_map = [];
$tab_labels = [];
$_cr = @sql_query("SELECT * FROM dm_ba_category ORDER BY sort ASC, id ASC");
if ($_cr) while ($_crow = sql_fetch_array($_cr)) {
    $cat_map[$_crow['name']]      = $_crow['tab_id'];
    $tab_labels[$_crow['tab_id']] = $_crow['name'];
}

if (isset($_GET['check_member'])) {
    $chk = sql_real_escape_string($_GET['mb_id'] ?? '');
    $ok  = $chk ? sql_fetch("SELECT mb_id FROM {$g5['member_table']} WHERE mb_id='{$chk}'") : false;
    header('Content-Type: application/json');
    echo json_encode(['ok' => !empty($ok)]);
    exit;
}

if (isset($_GET['ajax_load'])) {
    $offset = (int)$_GET['offset'];
    $tab    = $_GET['tab'] ?? 'all';
    $limit  = 12;
    if ($tab === 'all') {
        $result = sql_query("SELECT * FROM dm_beforeafter WHERE is_visible=1 ORDER BY display_order ASC, id DESC LIMIT {$limit} OFFSET {$offset}");
    } else {
        $cat_name = sql_real_escape_string($tab_labels[$tab] ?? '');
        if (!$cat_name) {
            echo json_encode(['items' => [], 'has_more' => false]);
            exit;
        }
        $result = sql_query("SELECT * FROM dm_beforeafter WHERE is_visible=1 AND treatment_category='{$cat_name}' ORDER BY display_order ASC, id DESC LIMIT {$limit} OFFSET {$offset}");
    }
    $items = [];
    if ($result) while ($row = sql_fetch_array($result)) $items[] = $row;
    header('Content-Type: application/json');
    echo json_encode(['items' => $items, 'has_more' => count($items) === $limit]);
    exit;
}

$r_all = safe_sql_query("SELECT * FROM dm_beforeafter WHERE is_visible=1 ORDER BY display_order ASC, id DESC");
$all_rows = [];
$tab_bucket = [];
foreach ($tab_labels as $tid => $lbl) $tab_bucket[$tid] = [];
if ($r_all) while ($row = safe_sql_fetch_array($r_all)) {
    $all_rows[] = $row;
    $tid = $cat_map[$row['treatment_category'] ?? ''] ?? null;
    if ($tid && isset($tab_bucket[$tid])) $tab_bucket[$tid][] = $row;
}
$total_all = count($all_rows);
$existing_tabs = [];
$tab_counts = [];
foreach ($tab_labels as $tid => $lbl) {
    $existing_tabs[$tid] = $lbl;
    $tab_counts[$tid]    = count($tab_bucket[$tid]);
}
$review_all = array_slice($all_rows, 0, 12);
$review_tabs = [];
foreach ($existing_tabs as $tid => $lbl) $review_tabs[$tid] = array_slice($tab_bucket[$tid], 0, 12);

$init_tab = $_GET['cat'] ?? 'all';
if (isset($cat_map[$init_tab])) $init_tab = $cat_map[$init_tab];
if ($init_tab !== 'all' && !isset($existing_tabs[$init_tab])) $init_tab = 'all';

$is_logged_in = !empty($member['mb_id']);

function render_ba_card($row, $is_logged_in)
{
    $id       = (int)$row['id'];
    $title    = htmlspecialchars($row['title'] ?? '');
    $subtitle = htmlspecialchars($row['subtitle'] ?? '');
    $cat      = htmlspecialchars($row['treatment_category'] ?? '');
    $thumb    = htmlspecialchars(
        !empty($row['image_thumbnail']) ? $row['image_thumbnail']
            : (!empty($row['image_after'])  ? $row['image_after']
                : (!empty($row['image_before']) ? $row['image_before'] : '/images/defaultBF.png'))
    );
    $ov = $is_logged_in ? ' style="display:none;"' : '';
    ob_start(); ?>
    <div class="ba-card u-mb-100 u-mb-40-sm " data-id="<?= $id ?>">
        <div class="ba-thumb-wrap position-relative overflow-hidden u-mb-16">
            <img loading="lazy" class="ba-thumb-img" src="<?= $thumb ?>" alt="<?= $title ?>" onerror="this.src='/images/defaultBF.png'">
            <div class="overlay ba-overlay"
                onclick="baOpenJoin(<?= $id ?>)" <?= $ov ?>>
                <p class="u-txt-white u-mb-12" style="font-size:14px;font-weight:700;text-align:center;padding:0 20px;line-height:1.5;">로그인 후<br>케이스를 확인하세요</p>
                <span class="u-bg-sub u-txt-white c-fs-14 u-round-20 fw-700 u-py-8 u-px-20">간편 로그인하기 →</span>
            </div>
        </div>
        <div class="ba-card-info d-flex u-gap-40 align-items-center">
            <div class="ba-card-cat flex-shrink-0">
                <?php if ($cat): ?><span class="ba-cat-badge u-txt-dark c-fs-16 fw-400 u-lh-15 u-ls-10">#<?= $cat ?></span><?php endif; ?>
            </div>
            <div class="ba-card-text flex-1" style="min-width:0;">
                <p class="ba-card-title u-txt-dark c-fs-20 fw-600 u-lh-15 u-ls-10"><?= $title ?></p>
                <?php if ($subtitle): ?><p class="ba-card-subtitle c-fs-12 u-txt-gray-700 fw-300 u-lh-15 u-ls-10"><?= $subtitle ?></p><?php endif; ?>
            </div>
        </div>
    </div>
<?php return ob_get_clean();
}

function render_empty_tab()
{
    return '<div class="review-empty-tab w-100" style="min-height:300px;display:flex;justify-content:center;align-items:center;"><p class="u-txt-gray-500 c-fs-20 fw-400">등록된 케이스가 없습니다.</p></div>';
}

$js_init_tab = json_encode($init_tab);
$js_logged = (!empty($member['mb_id'])) ? 'true' : 'false';

include_once(G5_PATH . '/head_sub.php');
include_once(G5_PATH . '/head.php');
?>

<!-- [추가] 페이지 렌더 직후 즉시 localStorage 확인 → 가입자면 오버레이/모달 숨김 (깜빡임 방지) -->
<script>
    (function () {
        try {
            if (localStorage.getItem('dm_member_hp')) {
                document.documentElement.classList.add('dm-has-member');
            }
        } catch (e) {}
    })();

    // [추가] 가입자면 — 오버레이를 '제거'하고 카드 클릭 시 바로 글로 이동 (AJAX 기다리지 않음)
    function dmActivateCards(scope) {
        try { if (!localStorage.getItem('dm_member_hp')) return; } catch (e) { return; }
        (scope || document).querySelectorAll('.ba-card').forEach(function (card) {
            if (card._dmActivated) return;
            card._dmActivated = true;
            card.classList.add('dm-logged');
            // 오버레이 DOM 자체 제거 (클릭 가로채기 방지)
            var ov = card.querySelector('.ba-overlay');
            if (ov && ov.parentNode) ov.parentNode.removeChild(ov);
            // 카드 클릭 → 해당 글로
            var id = card.dataset.id;
            if (id) {
                card.style.cursor = 'pointer';
                card.addEventListener('click', function () {
                    location.href = '/sub/board/case_view.php?id=' + id;
                });
            }
        });
    }

    // DOM 준비되는 즉시 1차 실행 (초기 렌더 카드)
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () { dmActivateCards(document); });
    } else {
        dmActivateCards(document);
    }
</script>
<style>
    /* localStorage 가입자: 오버레이/모달 즉시 숨김 (서버 세션 없어도) */
    html.dm-has-member .ba-overlay { display: none !important; }
    html.dm-has-member #joinModal { display: none !important; }
</style>

<main class="u-pretendard case_list">
    <div class="u-fluid u-fluid-xl-sm u-py-80-sm u-px-20-sm">
        <h1 class="t-fs-46 fw-700 u-lh-14 u-ls-15 u-txt-dark text-center u-py-150 u-py-100-sm">임상증례</h1>
        <div class="">
            <h2 class="u-txt-dark t-fs-40 fw-700 u-lh-14 u-ls-15 u-mb-40">
                치과진료에 대한 다양한<br>
                궁금증과 치료 연구를 위한 <br class="d-block d-lg-none">증례 이야기
            </h2>
            <p class="u-txt-gray-700 fw-400 c-fs-20 u-lh-15 u-ls-10">*본 케이스는 56조 제 1항의 의료법을 준수하여 작성되었으며 실제 내원 환자분의 동의하에 공개된 치료과정의 사진이 포함되어 있습니다.<br>개인에 따라 진료 및 치료방법이 다르게 적용될 수 있으며, 효과와 부작용이 다르게 나타날수 있는점을 안내 드립니다.</p>
        </div>
    </div>

    <section id="sect01" class="u-py-150 u-py-80-sm">
        <div class="u-fluid u-fluid-xl-sm u-px-20-sm">
            <div class="tabs w-100 mx-auto u-mb-100">
                <ul class="w-100 g-cols-fit-12 g-flex-3 u-gap-20 mx-auto">
                    <?php if ($total_all > 0): ?>
                        <li><button type="button" class="review-tab-btn flex-1 u-b-solid u-bd-1 u-bc-gray-300 u-round-full c-fs-18 fw-500 u-lh-16 u-ls-15 w-100 u-txt-gray-500 u-py-16<?= $init_tab === 'all' ? ' active' : '' ?>" data-tab="all">전체</button></li>
                    <?php endif; ?>
                    <?php foreach ($existing_tabs as $tab_id => $label): ?>
                        <li><button type="button" class="review-tab-btn flex-1 u-b-solid u-bd-1 u-bc-gray-300 u-round-full c-fs-18 fw-500 u-lh-16 u-ls-15 w-100 u-txt-gray-500 u-py-16<?= $init_tab === $tab_id ? ' active' : '' ?>" data-tab="<?= $tab_id ?>"><?= htmlspecialchars($label) ?></button></li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <div class="tab-container u-mb-60">
                <?php
                $tab_configs = ['all' => [$review_all, $total_all]];
                foreach ($existing_tabs as $tab_id => $label) $tab_configs[$tab_id] = [$review_tabs[$tab_id], $tab_counts[$tab_id]];
                foreach ($tab_configs as $tab_id => [$data, $total]):
                    $has_more = $total > 12;
                    $is_active = ($init_tab === $tab_id);
                ?>
                    <div class="review-tab-contents<?= $is_active ? ' active' : '' ?>" id="tab-<?= $tab_id ?>">
                        <?php if (!empty($data)): foreach ($data as $rv) echo render_ba_card($rv, $is_logged_in);
                        else: echo render_empty_tab();
                        endif; ?>
                    </div>
                    <?php if ($has_more): ?>
                        <div id="lazyTrigger-<?= $tab_id ?>" class="lazy-trigger" data-tab="<?= $tab_id ?>" style="height:1px;margin-top:60px;"></div>
                        <div id="loadingSpinner-<?= $tab_id ?>" style="display:none;text-align:center;padding:40px 0;">
                            <div class="spinner-border" style="color:var(--sub-color);" role="status"></div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
       <!-- ============================================ -->
        <!-- 예약-->
        <!-- ============================================ -->
        
        <section id="ask" class="w-100 w-100-sm u-px-20-sm mx-auto u-py-150 u-py-80-sm" style="background-image: url('/images/yeyak_bg.png'); background-size: cover; background-position: center;">
            <div class="d-flex flex-column align-items-center justify-content-center u-gap-40">
                <div>

                    <h2 class="u-txt-white fw-700 t-fs-48 t-fs-48-sm u-lh-15 u-ls-15 text-center u-mb-20">
                        온라인으로 편안하게 <br class="d-block d-lg-none"> 상담&예약하세요
                    </h2>
                    <p class="u-txt-gray-300 c-fs-28 fw-400 u-lh-15 u-ls-10 text-center">
                        원하는 정보를 찾지 못하셨다면 네이버 예약이나 카카오톡 상담을 이용해주세요.
                    </p>
                </div>
                <div class="w-100-sm d-flex flex-column flex-lg-row u-gap-40 u-gap-20-sm justify-content-center align-items-center">

                    <a href="<?= htmlspecialchars($cf_naver_booking) ?>" class="w-100-sm d-flex align-items-center justify-content-center u-bg-naver text-center u-px-40 u-py-18 fw-600 t-fs-20 u-lh-16 u-ls-10 u-round-full u-gap-10 u-txt-white">
                        <img loading="lazy" src="/images/naver.svg" alt="네이버예약">
                        네이버 예약 <span class="material-symbols-outlined">
                            trending_flat
                        </span>
                    </a>
                    <a href="<?= htmlspecialchars($cf_kakao) ?>" class="w-100-sm d-flex align-items-center justify-content-center u-bg-kakao text-center u-px-40 u-py-18 fw-600 t-fs-20 u-lh-16 u-ls-10 u-round-full u-gap-10" style="color: #3F2623">
                        <img loading="lazy" src="/images/kakao.svg" alt="카카오예약">
                        카카오 상담 <span class="material-symbols-outlined">
                            trending_flat
                        </span>
                    </a>
                </div>

            </div>
        </section>
</main>

<style>
    .case_list #sect01 .review-tab-contents {
        display: none !important;
    }
    .case_list #sect01 .review-tab-contents.active {
        display: grid !important;
        grid-template-columns: repeat(3, 1fr);
        gap: 28px;
    }
    @media(max-width:992px) {
        .case_list #sect01 .review-tab-contents.active {
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
        }
    }
    @media(max-width:576px) {
        .case_list #sect01 .review-tab-contents.active {
            grid-template-columns: 1fr;
            gap: 20px;
        }
    }
    .ba-card { width: 100%; cursor: pointer; }
    .ba-thumb-wrap { aspect-ratio: 4 / 3; background: #f0f0f0; border-radius: 16px; overflow: hidden; }
    .ba-thumb-img { width: 100%; height: 100%; object-fit: cover; display: block; transition: transform 0.3s ease; }
    .ba-card:hover .ba-thumb-img { transform: scale(1.04); }
    .ba-card-info { padding: 12px 2px 0; }
    .ba-overlay {
        position: absolute; left: 0; bottom: 0; width: 100%; height: 100%;
        display: flex; flex-direction: column; justify-content: center; align-items: center;
        background-color: rgba(0, 0, 0, 0.25); cursor: pointer;
    }
    @media (hover: hover) {
        .ba-overlay { transform: translateY(100%); transition: transform 0.35s ease; will-change: transform; }
        .ba-thumb-wrap:hover .ba-overlay { transform: translateY(0); }
    }
    @media (hover: none) {
        .ba-overlay { display: none !important; }
    }
    .ba-card.dm-logged .ba-overlay { display: none !important; }
</style>

<script>
    var _BA_INIT_TAB = <?= $js_init_tab ?>;
    var _BA_LOGGED_IN = <?= $js_logged ?>;
    var _BA_LAZY_URL = location.pathname;
    var _BA_IS_TOUCH = window.matchMedia('(hover: none)').matches;

    // [추가] 클릭한 카드의 글 id 기억
    var _BA_TARGET_ID = null;

    function baOpenJoin(id) {
        _BA_TARGET_ID = id || null;
        // 이미 가입자면 모달 띄우지 말고 바로 해당 글로
        try {
            if (localStorage.getItem('dm_member_hp')) {
                if (_BA_TARGET_ID) { location.href = '/sub/board/case_view.php?id=' + _BA_TARGET_ID; return; }
            }
        } catch (e) {}
        try { if (_BA_TARGET_ID) sessionStorage.setItem('ba_target_id', _BA_TARGET_ID); } catch (e) {}
        var modal = document.getElementById('joinModal');
        if (modal) modal.classList.add('active');
    }

    function bindMobileCardTap(scope) {
        if (_BA_LOGGED_IN || !_BA_IS_TOUCH) return;
        (scope || document).querySelectorAll('#sect01 .ba-card').forEach(function(card) {
            if (card._mobileBound) return;
            card._mobileBound = true;
            card.style.cursor = 'pointer';
            card.addEventListener('click', function() {
                baOpenJoin(this.dataset.id);
            });
        });
    }

    document.addEventListener('DOMContentLoaded', function() {
        var tabBtns = document.querySelectorAll('#sect01 .review-tab-btn');
        var tabContents = document.querySelectorAll('#sect01 .review-tab-contents');
        var state = {};

        tabBtns.forEach(function(btn) {
            state[btn.dataset.tab] = { offset: 12, loading: false, done: false };
        });

        tabBtns.forEach(function(btn) {
            btn.addEventListener('click', function() {
                tabBtns.forEach(function(b) { b.classList.remove('active'); });
                this.classList.add('active');
                tabContents.forEach(function(c) { c.classList.remove('active'); });
                var t = document.getElementById('tab-' + this.dataset.tab);
                if (t) t.classList.add('active');
            });
        });

        function escHtml(s) {
            return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
        }

        function renderCard(row) {
            var id = row.id;
            var title = escHtml(row.title || '');
            var subtitle = escHtml(row.subtitle || '');
            var cat = escHtml(row.treatment_category || '');
            var thumb = row.image_thumbnail || row.image_after || row.image_before || '/images/defaultBF.png';
            var ov = _BA_LOGGED_IN ? 'style="display:none;"' : '';
            return '<div class="ba-card u-mb-100 u-mb-40-sm" data-id="' + id + '">' +
                '<div class="ba-thumb-wrap position-relative overflow-hidden u-mb-16">' +
                '<img loading="lazy" class="ba-thumb-img" src="' + thumb + '" alt="' + title + '" onerror="this.src=\'/images/defaultBF.png\'">' +
                '<div class="overlay ba-overlay" onclick="baOpenJoin(' + id + ')" ' + ov + '>' +
                '<p class="u-txt-white u-mb-12" style="font-size:14px;font-weight:700;text-align:center;padding:0 20px;line-height:1.5;">\uB85C\uADF8\uC778 \uD6C4<br>\uCF00\uC774\uC2A4\uB97C \uD655\uC778\uD558\uC138\uC694</p>' +
                '<span class="u-bg-point u-txt-white c-fs-14 u-round-20 fw-700 u-py-8 u-px-20">\uAC04\uD3B8 \uB85C\uADF8\uC778\uD558\uAE30 \u2192</span>' +
                '</div></div>' +
                '<div class="ba-card-info d-flex u-gap-40 align-items-center">' +
                '<div class="ba-card-cat flex-shrink-0">' + (cat ? '<span class="ba-cat-badge u-txt-dark c-fs-16 fw-400 u-lh-15 u-ls-10">#' + cat + '</span>' : '') + '</div>' +
                '<div class="ba-card-text flex-1" style="min-width:0;">' +
                '<p class="ba-card-title u-txt-dark c-fs-20 fw-600 u-lh-15 u-ls-10">' + title + '</p>' +
                (subtitle ? '<p class="ba-card-subtitle c-fs-12 u-txt-gray-700 fw-300 u-lh-15 u-ls-10">' + subtitle + '</p>' : '') +
                '</div></div></div>';
        }

        function loadMore(tab) {
            var s = state[tab];
            if (!s || s.loading || s.done) return;
            s.loading = true;
            var spinner = document.getElementById('loadingSpinner-' + tab);
            if (spinner) spinner.style.display = 'block';
            fetch(_BA_LAZY_URL + '?ajax_load=1&tab=' + tab + '&offset=' + s.offset)
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    if (spinner) spinner.style.display = 'none';
                    s.loading = false;
                    var grid = document.getElementById('tab-' + tab);
                    if (data.items.length > 0) {
                        var empty = grid.querySelector('.review-empty-tab');
                        if (empty) empty.remove();
                        data.items.forEach(function(row) {
                            grid.insertAdjacentHTML('beforeend', renderCard(row));
                        });
                        s.offset += data.items.length;

                        // 가입자면 lazy 카드도 오버레이 제거 + 클릭 이동 (통일 함수 사용)
                        dmActivateCards(grid);

                        bindMobileCardTap(grid);
                    }
                    if (!data.has_more) {
                        s.done = true;
                        var trigger = document.getElementById('lazyTrigger-' + tab);
                        if (trigger) trigger.remove();
                    }
                })
                .catch(function() {
                    if (spinner) spinner.style.display = 'none';
                    s.loading = false;
                });
        }

        document.querySelectorAll('#sect01 .lazy-trigger').forEach(function(trigger) {
            new IntersectionObserver(function(entries) {
                if (entries[0].isIntersecting) loadMore(trigger.dataset.tab);
            }, { rootMargin: '200px' }).observe(trigger);
        });

        bindMobileCardTap(document);
    });
</script>

<?php if (!$is_logged_in): ?>
    <div class="modal_overlay" id="joinModal">
        <div class="modal_box">
            <div class="modal_hd">
                <div>
                    <h3 class="modal_title">임상 증례 열람</h3>
                    <p class="modal_sub">간단한 정보 입력 후 전체 케이스를 확인하세요</p>
                </div>
                <button class="modal_close" onclick="document.getElementById('joinModal').classList.remove('active')">✕</button>
            </div>
            <form method="post" id="joinForm">
                <input type="hidden" name="action" value="simple_join">
                <input type="hidden" name="redirect_to" id="joinRedirectTo" value="">
                <div class="modal_bd">
                    <div class="form_group"><label>이름 *</label><input type="text" name="mb_name" placeholder="홍길동" required autocomplete="name"></div>
                    <div class="form_group"><label>전화번호 *</label><input type="tel" name="mb_hp" placeholder="010-0000-0000" required autocomplete="tel" oninput="this.value=this.value.replace(/[^0-9-]/g,'')"></div>
                    <div class="form_group"><label>이메일 *</label><input type="email" name="mb_email" placeholder="example@email.com" required autocomplete="email"></div>
                    <p class="modal_notice">입력하신 정보는 의료법 제56조 준수를 위한 열람 확인 목적으로만 사용되며 외부에 제공되지 않습니다.</p>
                </div>
                <div class="modal_ft">
                    <button type="button" class="btn_modal_cancel" onclick="document.getElementById('joinModal').classList.remove('active')">취소</button>
                    <button type="submit" class="btn_modal_submit u-bg-sub">확인 후 열람하기</button>
                </div>
            </form>
        </div>
    </div>
    <style>
        .modal_overlay { display: none; position: fixed; inset: 0; background: rgba(0, 0, 0, 0.3); z-index: 99999; align-items: center; justify-content: center; padding: 20px }
        .modal_overlay.active { display: flex }
        .modal_box { background: #fff; border-radius: 16px; width: 100%; max-width: 420px; overflow: hidden; animation: modal_in .25s ease; box-shadow: 0 20px 60px rgba(0, 0, 0, .2) }
        @keyframes modal_in { from { transform: translateY(-16px); opacity: 0 } to { transform: none; opacity: 1 } }
        .modal_hd { padding: 22px 24px; border-bottom: 1px solid #e8eaf0; display: flex; align-items: flex-start; justify-content: space-between; gap: 12px }
        .modal_title { font-size: 17px; font-weight: 700; color: #1a1a2e; margin-bottom: 3px }
        .modal_sub { font-size: 12px; color: #9999bb }
        .modal_close { background: none; border: none; font-size: 22px; cursor: pointer; color: #9999bb; flex-shrink: 0; line-height: 1 }
        .modal_close:hover { color: #1a1a2e }
        .modal_bd { padding: 22px 24px; display: flex; flex-direction: column; gap: 14px }
        .form_group label { display: block; font-size: 12px; font-weight: 700; color: #9999bb; margin-bottom: 6px }
        .form_group input { width: 100%; height: 44px; border: 1px solid #e8eaf0; border-radius: 8px; padding: 0 14px; font-size: 14px; background: #f5f6fa; font-family: inherit; transition: all .2s }
        .form_group input:focus { outline: none; background: #fff; box-shadow: 0 0 0 3px rgba(79, 70, 229, .1) }
        .modal_notice { font-size: 11px; color: #9999bb; line-height: 1.7; background: #f5f6fa; border-radius: 8px; padding: 10px 14px }
        .modal_ft { padding: 16px 24px; border-top: 1px solid #e8eaf0; display: grid; grid-template-columns: 1fr 2fr; gap: 10px }
        .btn_modal_cancel { padding: 12px; border-radius: 8px; background: #f5f6fa; color: #5c5c7a; border: 1px solid #e8eaf0; font-size: 14px; font-weight: 700; cursor: pointer; font-family: inherit }
        .btn_modal_submit { padding: 12px; border-radius: 8px; color: #fff; border: none; font-size: 14px; font-weight: 700; cursor: pointer; font-family: inherit; transition: all .2s }
        .btn_modal_submit:hover { background: #4338ca }
    </style>
    <script>
        document.getElementById('joinModal').addEventListener('click', function(e) {
            if (e.target === this) this.classList.remove('active');
        });
        // 가입 제출 — 원본 방식(일반 폼 POST). 서버가 INSERT 후 redirect_to 로 이동.
        document.getElementById('joinForm').addEventListener('submit', function() {
            var hp = (this.querySelector('[name=mb_hp]').value || '').replace(/[^0-9]/g, '');
            if (hp) localStorage.setItem('dm_member_hp', 'u' + hp);

            // 클릭했던 케이스 글로 이동하도록 목적지 지정
            var targetId = _BA_TARGET_ID;
            if (!targetId) {
                try { targetId = sessionStorage.getItem('ba_target_id'); } catch (e2) {}
            }
            if (targetId) {
                document.getElementById('joinRedirectTo').value = '/sub/board/case_view.php?id=' + targetId;
            }
            try { sessionStorage.removeItem('ba_target_id'); } catch (e3) {}
            // preventDefault 없음 → 폼이 정상 제출되어 서버가 INSERT 처리
        });
    </script>
<?php endif; ?>

<script>
    // 서버 회원 검증 — localStorage만 조작한 가짜를 거름
    // (진짜면 즉시실행 dmActivateCards 가 이미 카드 활성화함. 여기선 가짜일 때만 되돌림)
    document.addEventListener('DOMContentLoaded', function() {
        var _dmId = localStorage.getItem('dm_member_hp');
        if (!_dmId) return;
        fetch(location.pathname + '?check_member=1&mb_id=' + encodeURIComponent(_dmId))
            .then(function(r) { return r.json(); })
            .then(function(data) {
                if (!data.ok) {
                    // 가짜 → localStorage 제거하고 페이지 새로고침해 잠금 상태 복구
                    localStorage.removeItem('dm_member_hp');
                    document.documentElement.classList.remove('dm-has-member');
                    location.reload();
                    return;
                }
                // 진짜 회원 — 혹시 아직 활성화 안 된 카드 있으면 마저 처리
                if (typeof dmActivateCards === 'function') dmActivateCards(document);
            });
    });
</script>

<script type="application/ld+json">
    <?php
    $host       = 'https://' . $_SERVER['HTTP_HOST'];
    $page_url   = $host . strtok($_SERVER['REQUEST_URI'], '?');
    $clinic_ref = ['@id' => $host . '/#organization'];
 
    $absUrl = function ($path) use ($host) {
        if (!$path) return '';
        return (strpos($path, 'http') === 0) ? $path : $host . $path;
    };
 
    // 케이스 → ImageGallery 이미지 목록 (썸네일/after/before 순)
    $case_images = [];
    if (!empty($all_rows)) {
        foreach ($all_rows as $c) {
            $thumb = !empty($c['image_thumbnail']) ? $c['image_thumbnail']
                : (!empty($c['image_after']) ? $c['image_after']
                    : (!empty($c['image_before']) ? $c['image_before'] : ''));
            if (!$thumb) continue;
            $case_images[] = [
                '@type'       => 'ImageObject',
                'url'         => $absUrl($thumb),
                'name'        => ($c['title'] ?? '임상 케이스'),
                'description' => ($c['subtitle'] ?? ''),
            ];
        }
    }
 
    $schema = [
 
        // 1. BreadcrumbList
        [
            '@context' => 'https://schema.org',
            '@type'    => 'BreadcrumbList',
            '@id'      => $page_url . '#breadcrumb',
            'itemListElement' => [
                ['@type' => 'ListItem', 'position' => 1, 'name' => '홈',       'item' => $host . '/'],
                ['@type' => 'ListItem', 'position' => 2, 'name' => '임상케이스', 'item' => $page_url],
            ],
        ],
 
        // 2. MedicalWebPage
        [
            '@context'    => 'https://schema.org',
            '@type'       => 'MedicalWebPage',
            '@id'         => $page_url . '#webpage',
            'name'        => $cf_site_name . ' 임상케이스',
            'description' => $cf_site_name . '에서 실제로 진행한 치과 치료 임상 증례입니다. 의료법 제56조를 준수하여 작성되었으며, 실제 내원 환자분의 동의하에 치료 과정 사진이 공개되어 있습니다. 개인에 따라 진료 및 치료 방법, 효과와 부작용이 다르게 나타날 수 있습니다.',
            'url'         => $page_url,
            'inLanguage'  => 'ko-KR',
            'isPartOf'    => ['@id' => $host . '/#website'],
            'specialty'   => ['@type' => 'MedicalSpecialty', 'name' => 'Dentistry'],
            'audience'    => ['@type' => 'MedicalAudience', 'audienceType' => 'Patient'],
            'publisher'   => $clinic_ref,
            'breadcrumb'  => ['@id' => $page_url . '#breadcrumb'],
            'lastReviewed' => date('Y-m-d'),
            'reviewedBy'   => $clinic_ref,
        ],
    ];
 
    // 3. ImageGallery — 케이스 있을 때만
    if (!empty($case_images)) {
        $schema[] = [
            '@context'    => 'https://schema.org',
            '@type'       => 'ImageGallery',
            '@id'         => $page_url . '#cases',
            'name'        => $cf_site_name . ' 치료 전후 임상 사례',
            'description' => '실제 내원 환자분의 동의를 받아 게시한 치료 전후 임상 사례입니다. 결과는 개인마다 차이가 있을 수 있습니다.',
            'isPartOf'    => ['@id' => $page_url . '#webpage'],
            'image'       => $case_images,
        ];
    }
 
    echo json_encode($schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    ?>
</script>

<?php include_once(G5_PATH . '/tail.php'); ?>