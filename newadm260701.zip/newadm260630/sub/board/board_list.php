<?php
chdir(dirname(__FILE__) . '/..');
include_once('./_common.php');

/* ── 파라미터 ── */
$bo_table = isset($_GET['bo_table']) ? preg_replace('/[^a-z0-9_]/i', '', $_GET['bo_table']) : 'column';
$page     = max(1, (int)($_GET['page'] ?? 1));
$per_page = 9; // 한 페이지 카드 수 (3열 × 3행)
$offset   = ($page - 1) * $per_page;

$write_table = $g5['write_prefix'] . $bo_table;

/* ── 카테고리 필터 ── */
$cat_filter = isset($_GET['cat']) ? (int)$_GET['cat'] : 0;
$where      = "wr_is_comment = 0" . ($cat_filter ? " AND wr_10 = {$cat_filter}" : "");

/* ── 전체 개수 ── */
$total_row  = sql_fetch("SELECT COUNT(*) AS cnt FROM {$write_table} WHERE {$where}");
$total      = (int)($total_row['cnt'] ?? 0);
$total_page = max(1, (int)ceil($total / $per_page));

/* ── 글 목록 ── */
$posts = [];
$result = sql_query("SELECT wr_id, wr_subject, wr_content, wr_1, wr_datetime, wr_hit, wr_10
                     FROM {$write_table}
                     WHERE {$where}
                     ORDER BY wr_id DESC
                     LIMIT {$offset}, {$per_page}");
while ($row = sql_fetch_array($result)) {
    $posts[] = $row;
}

/* ── 카테고리 목록 (필터 탭용) ── */
$categories = [];
$cat_table  = $write_table . '_category';
$tc = sql_query("SHOW TABLES LIKE '{$cat_table}'", false);
if ($tc && sql_num_rows($tc) > 0) {
    $cr = sql_query("SELECT ca_id, ca_name FROM {$cat_table} ORDER BY ca_order, ca_id", false);
    while ($c = sql_fetch_array($cr)) $categories[] = $c;
}

/* ────────────────────────────────────────────────
   썸네일 추출 헬퍼
   빌더 JSON → 첫 번째 image 블록의 url
   에디터 HTML → 첫 번째 <img src="...">
──────────────────────────────────────────────── */
function extract_thumb(string $raw_content, string $editor_type): string {
    if ($editor_type === 'builder' || !$editor_type) {
        $data = json_decode(stripslashes($raw_content), true);
        if ($data && !empty($data['rows'])) {
            foreach ($data['rows'] as $row) {
                foreach ($row['columns'] ?? [] as $col) {
                    foreach ($col['blocks'] ?? [] as $block) {
                        if ($block['type'] === 'image' && !empty($block['data']['url'])) {
                            return $block['data']['url'];
                        }
                    }
                }
            }
        }
    }
    // 에디터 HTML 또는 폴백
    $html = stripslashes($raw_content);
    if (preg_match('/<img[^>]+src=["\']([^"\']+)["\'][^>]*>/i', $html, $m)) {
        return $m[1];
    }
    return '';
}

/* ────────────────────────────────────────────────
   요약 텍스트 추출
──────────────────────────────────────────────── */
function extract_summary(string $raw_content, string $editor_type, int $limit = 80): string {
    $text = '';
    if ($editor_type === 'builder' || !$editor_type) {
        $data = json_decode(stripslashes($raw_content), true);
        if ($data && !empty($data['rows'])) {
            foreach ($data['rows'] as $row) {
                foreach ($row['columns'] ?? [] as $col) {
                    foreach ($col['blocks'] ?? [] as $block) {
                        $t = $block['type'];
                        if (in_array($t, ['paragraph','h2','h3','h4','quote'])) {
                            $text .= strip_tags($block['data']['text'] ?? '') . ' ';
                        } elseif ($t === 'list') {
                            $text .= implode(' ', array_map('strip_tags', $block['data']['items'] ?? [])) . ' ';
                        }
                        if (mb_strlen($text) >= $limit) break 3;
                    }
                }
            }
        }
    } else {
        $text = strip_tags(stripslashes($raw_content));
    }
    $text = preg_replace('/\s+/', ' ', trim($text));
    return mb_strlen($text) > $limit ? mb_substr($text, 0, $limit) . '…' : $text;
}

include_once(G5_PATH . '/head_sub.php');
include_once(G5_PATH . '/head.php');
?>

<main class="u-pretendard board-list-page">

    <!-- 인트로 -->
    <!-- <div class="bl-intro d-flex justify-content-center align-items-center flex-column u-gap-20">
        <h6 class="t-fs-20 fw-700 u-lh-14 u-ls-10 u-txt-white">서울다온치과</h6>
        <h2 class="t-fs-46 fw-700 u-lh-14 u-ls-15 u-txt-white">원장님 칼럼</h2>
        <p class="c-fs-18 fw-400 u-lh-16 u-ls-10 text-center u-txt-gray-300 u-mt-10">치과 전문의가 전하는 구강 건강 이야기</p>
    </div> -->

    <div class="u-fluid u-fluid-xl-sm u-py-80">

        <!-- 카테고리 탭 -->
        <?php if (!empty($categories)): ?>
        <div class="bl-cats d-flex u-gap-10 u-mb-48 flex-wrap">
            <a href="?bo_table=<?= $bo_table ?>"
               class="bl-cat-btn<?= !$cat_filter ? ' active' : '' ?>">전체</a>
            <?php foreach ($categories as $cat): ?>
            <a href="?bo_table=<?= $bo_table ?>&cat=<?= $cat['ca_id'] ?>"
               class="bl-cat-btn<?= $cat_filter == $cat['ca_id'] ? ' active' : '' ?>">
                <?= htmlspecialchars($cat['ca_name']) ?>
            </a>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <!-- 카드 그리드 -->
        <?php if (empty($posts)): ?>
        <div class="bl-empty">
            <div class="bl-empty-ic">📄</div>
            <p>등록된 글이 없습니다.</p>
        </div>
        <?php else: ?>
        <div class="bl-grid">
            <?php foreach ($posts as $post):
                $thumb   = extract_thumb($post['wr_content'], $post['wr_1']);
                $summary = extract_summary($post['wr_content'], $post['wr_1']);
                $date    = $post['wr_datetime'] ? date('Y.m.d', strtotime($post['wr_datetime'])) : '';
                $url     = "/sub/board.php?wr_id={$post['wr_id']}&bo_table={$bo_table}";
            ?>
            <a href="<?= $url ?>" class="bl-card">
                <div class="bl-card-thumb">
                    <?php if ($thumb): ?>
                    <img src="<?= htmlspecialchars($thumb) ?>" alt="<?= htmlspecialchars($post['wr_subject']) ?>" loading="lazy">
                    <?php else: ?>
                    <div class="bl-card-thumb-empty">
                        <span>📝</span>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="bl-card-body">
                    <h3 class="bl-card-title"><?= htmlspecialchars($post['wr_subject']) ?></h3>
                    <?php if ($summary): ?>
                    <p class="bl-card-summary"><?= htmlspecialchars($summary) ?></p>
                    <?php endif; ?>
                    <div class="bl-card-meta">
                        <span class="bl-card-date"><?= $date ?></span>
                        <span class="bl-card-hit">조회 <?= number_format((int)$post['wr_hit']) ?></span>
                    </div>
                </div>
                <div class="bl-card-arrow">→</div>
            </a>
            <?php endforeach; ?>
        </div>

        <!-- 페이지네이션 -->
        <?php if ($total_page > 1): ?>
        <div class="bl-pagination d-flex justify-content-center u-gap-8 u-mt-60">
            <?php if ($page > 1): ?>
            <a href="?bo_table=<?= $bo_table ?>&page=<?= $page-1 ?><?= $cat_filter ? '&cat='.$cat_filter : '' ?>" class="bl-page-btn">←</a>
            <?php endif; ?>

            <?php
            $range = 2;
            $start = max(1, $page - $range);
            $end   = min($total_page, $page + $range);
            if ($start > 1): ?>
                <a href="?bo_table=<?= $bo_table ?>&page=1<?= $cat_filter ? '&cat='.$cat_filter : '' ?>" class="bl-page-btn">1</a>
                <?php if ($start > 2): ?><span class="bl-page-dots">…</span><?php endif; ?>
            <?php endif; ?>

            <?php for ($p = $start; $p <= $end; $p++): ?>
            <a href="?bo_table=<?= $bo_table ?>&page=<?= $p ?><?= $cat_filter ? '&cat='.$cat_filter : '' ?>"
               class="bl-page-btn<?= $p === $page ? ' active' : '' ?>"><?= $p ?></a>
            <?php endfor; ?>

            <?php if ($end < $total_page): ?>
                <?php if ($end < $total_page - 1): ?><span class="bl-page-dots">…</span><?php endif; ?>
                <a href="?bo_table=<?= $bo_table ?>&page=<?= $total_page ?><?= $cat_filter ? '&cat='.$cat_filter : '' ?>" class="bl-page-btn"><?= $total_page ?></a>
            <?php endif; ?>

            <?php if ($page < $total_page): ?>
            <a href="?bo_table=<?= $bo_table ?>&page=<?= $page+1 ?><?= $cat_filter ? '&cat='.$cat_filter : '' ?>" class="bl-page-btn">→</a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        <?php endif; ?>

    </div><!-- /u-fluid -->
</main>

<style>
/* ═══════════════════════════════
   인트로
═══════════════════════════════ */
.bl-intro {
    min-height: 280px;
    background: linear-gradient(160deg, var(--main-color, #000136) 0%, var(--sub-color, #25456B) 100%);
    padding: 60px 24px;
}

/* ═══════════════════════════════
   카테고리 탭
═══════════════════════════════ */
.bl-cats { border-bottom: 1.5px solid var(--gray-200, #e9e9e9); padding-bottom: 20px; }
.bl-cat-btn {
    display: inline-flex;
    align-items: center;
    padding: 7px 18px;
    border-radius: 30px;
    border: 1.5px solid var(--gray-300, #dedede);
    background: #fff;
    color: var(--gray-700, #707070);
    font-size: 13px;
    font-weight: 600;
    text-decoration: none;
    transition: all .18s;
    font-family: 'Pretendard', sans-serif;
}
.bl-cat-btn:hover { border-color: var(--sub-color, #25456B); color: var(--sub-color, #25456B); }
.bl-cat-btn.active {
    background: var(--main-color, #000136);
    border-color: var(--main-color, #000136);
    color: #fff;
}

/* ═══════════════════════════════
   카드 그리드
═══════════════════════════════ */
.bl-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 28px;
}

/* ── 카드 ── */
.bl-card {
    display: flex;
    flex-direction: column;
    background: #fff;
    border: 1.5px solid var(--gray-200, #e9e9e9);
    border-radius: 16px;
    overflow: hidden;
    text-decoration: none;
    color: inherit;
    transition: transform .22s, box-shadow .22s, border-color .22s;
    position: relative;
}
.bl-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 12px 40px rgba(0, 1, 54, .12);
    border-color: var(--sub-color2, #99B5D7);
}

/* 썸네일 */
.bl-card-thumb {
    width: 100%;
    aspect-ratio: 16 / 9;
    overflow: hidden;
    background: var(--light, #F0F3F6);
    flex-shrink: 0;
}
.bl-card-thumb img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform .35s;
    display: block;
}
.bl-card:hover .bl-card-thumb img { transform: scale(1.04); }
.bl-card-thumb-empty {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, var(--light, #F0F3F6), #dde6f5);
    font-size: 36px;
}

/* 카드 본문 */
.bl-card-body {
    padding: 20px 22px 14px;
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 8px;
}
.bl-card-title {
    font-size: 17px;
    font-weight: 700;
    color: var(--main-color, #000136);
    line-height: 1.4;
    letter-spacing: -0.3px;
    word-break: keep-all;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}
.bl-card-summary {
    font-size: 13px;
    color: var(--gray-600, #969696);
    line-height: 1.65;
    word-break: keep-all;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
    flex: 1;
}
.bl-card-meta {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-top: 4px;
}
.bl-card-date, .bl-card-hit {
    font-size: 11px;
    color: var(--gray-500, #aaaaaa);
    font-weight: 500;
}

/* 화살표 */
.bl-card-arrow {
    position: absolute;
    bottom: 18px;
    right: 20px;
    width: 30px;
    height: 30px;
    border-radius: 50%;
    background: var(--light, #F0F3F6);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 14px;
    color: var(--sub-color, #25456B);
    transition: all .2s;
    opacity: 0;
}
.bl-card:hover .bl-card-arrow {
    opacity: 1;
    background: var(--main-color, #000136);
    color: #fff;
    transform: translateX(3px);
}

/* ═══════════════════════════════
   빈 상태
═══════════════════════════════ */
.bl-empty {
    text-align: center;
    padding: 80px 20px;
    color: var(--gray-500, #aaaaaa);
}
.bl-empty-ic { font-size: 48px; margin-bottom: 16px; }
.bl-empty p  { font-size: 16px; }

/* ═══════════════════════════════
   페이지네이션
═══════════════════════════════ */
.bl-page-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 38px;
    height: 38px;
    padding: 0 10px;
    border-radius: 8px;
    border: 1.5px solid var(--gray-200, #e9e9e9);
    background: #fff;
    color: var(--gray-700, #707070);
    font-size: 14px;
    font-weight: 600;
    text-decoration: none;
    transition: all .15s;
    font-family: 'Pretendard', sans-serif;
}
.bl-page-btn:hover { border-color: var(--sub-color, #25456B); color: var(--sub-color, #25456B); }
.bl-page-btn.active {
    background: var(--main-color, #000136);
    border-color: var(--main-color, #000136);
    color: #fff;
}
.bl-page-dots { display:flex; align-items:center; color:var(--gray-400,#bbb); font-size:14px; padding: 0 4px; }

/* ═══════════════════════════════
   반응형
═══════════════════════════════ */
@media (max-width: 1024px) {
    .bl-grid { grid-template-columns: repeat(2, 1fr); gap: 20px; }
}
@media (max-width: 640px) {
    .bl-grid { grid-template-columns: 1fr; gap: 16px; }
    .bl-intro { min-height: 200px; padding: 40px 20px; }
}
</style>

<?php include_once(G5_PATH . '/tail.php'); ?>