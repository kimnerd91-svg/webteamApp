<?php
include_once('./_common.php'); // ⭐ 상대경로로 수정!
$dm_conf = sql_fetch("SELECT * FROM dm_config WHERE cf_id = 1");
include_once(G5_PATH.'/head_sub.php');
?>

<header class="main-header z-header blur-12 u-bd-b-1 u-bc-gray-900">
    <div class="container d-flex justify-content-between align-items-center u-p-20">
        <div class="logo fw-800 c-fs-24">
            <a href="<?=G5_URL?>" class="t-fs-28 fw-900 u-txt-main">
                <?php if (isset($dm_conf['cf_logo']) && $dm_conf['cf_logo']) { ?>
                    <img src="<?= G5_DATA_URL ?>/common/<?= $dm_conf['cf_logo'] ?>" alt="<?= $dm_conf['cf_site_name'] ?>" style="max-height:50px;">
                <?php } else { ?>
                    <?= $dm_conf['cf_site_name'] ?: 'LOGO' ?>
                <?php } ?>
            </a>
        </div>

        <nav class="d-none d-md-flex align-items-center u-gap-32">
            <a href="#hero" class="u-txt-white fw-600 c-fs-14">Home</a>
            <a href="#notice" class="u-txt-white fw-600 c-fs-14">Review</a>
            <a href="#gallery" class="u-txt-white fw-600 c-fs-14">Case</a>

            <?php if ($is_member) { ?>
                <span class="u-txt-white fw-600 c-fs-14"><?= $member['mb_nick'] ?>님</span>
                <a href="<?=G5_URL?>/plugin/social_login/logout.php" class="u-txt-gray-600 fw-600">로그아웃</a>
            <?php } else { ?>
                <a href="<?=G5_BBS_URL?>/login.php" class="u-txt-gray-600 fw-600">로그인</a>
            <?php } ?>

            <?php if ($is_admin == 'super') { ?>
                <a href="<?=G5_URL?>/newadm/" class="u-txt-main fw-700">관리자</a>
            <?php } ?>
        </nav>
    </div>
    
    <!-- 디버그 정보 -->
    <!-- <div style="position: fixed; top: 80px; right: 20px; background: rgba(0,0,0,0.9); color: #0f0; padding: 15px; border-radius: 8px; font-family: monospace; font-size: 12px; z-index: 99999; min-width: 250px;">
        <div style="color: #fff; font-weight: bold; margin-bottom: 10px; border-bottom: 1px solid #333; padding-bottom: 5px;">🔍 Login Debug</div>
        <div style="margin-bottom: 5px;">
            <span style="color: #888;">SESSION ID:</span> 
            <span style="color: <?= isset($_SESSION['ss_mb_id']) && $_SESSION['ss_mb_id'] ? '#0f0' : '#f00' ?>">
                <?= isset($_SESSION['ss_mb_id']) && $_SESSION['ss_mb_id'] ? $_SESSION['ss_mb_id'] : 'NULL' ?>
            </span>
        </div>
        <div style="margin-bottom: 5px;">
            <span style="color: #888;">Member ID:</span> 
            <span style="color: <?= $member['mb_id'] ? '#0f0' : '#f00' ?>">
                <?= $member['mb_id'] ?: 'NULL' ?>
            </span>
        </div>
        <div style="margin-bottom: 5px;">
            <span style="color: #888;">Nickname:</span> 
            <span style="color: #0ff;">
                <?= $member['mb_nick'] ?: 'NULL' ?>
            </span>
        </div>
        <div style="margin-bottom: 5px;">
            <span style="color: #888;">$is_member:</span> 
            <span style="color: <?= $is_member ? '#0f0' : '#f00' ?>; font-weight: bold;">
                <?= $is_member ? 'TRUE' : 'FALSE' ?>
            </span>
        </div>
        <div style="margin-bottom: 5px;">
            <span style="color: #888;">Login Type:</span> 
            <span style="color: #ff0;">
                <?php 
                if ($member['mb_id']) {
                    echo strpos($member['mb_id'], 'kakao_') === 0 ? 'KAKAO' : 'NORMAL';
                } else {
                    echo 'GUEST';
                }
                ?>
            </span>
        </div>
        <div style="margin-top: 10px; padding-top: 10px; border-top: 1px solid #333;">
            <span style="color: #888;">IP:</span> 
            <span style="color: #ccc; font-size: 11px;"><?= $_SERVER['REMOTE_ADDR'] ?></span>
        </div>
    </div> -->
</header>

<script type="text/javascript">
    (function() {
        var userLang = (navigator.language || navigator.userLanguage).toLowerCase();
        var target = 'ko';
        if (userLang.indexOf('ja') !== -1) target = 'ja';
        else if (userLang.indexOf('en') !== -1) target = 'en';

        var deleteCookie = function(name) {
            var domain = document.domain;
            var path = '/';
            document.cookie = name + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=" + path + ";";
            document.cookie = name + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=" + path + "; domain=" + domain + ";";
            document.cookie = name + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=" + path + "; domain=." + domain + ";";
        };

        if (target !== 'ko') {
            document.cookie = "googtrans=/ko/" + target + "; path=/;";
            document.cookie = "googtrans=/ko/" + target + "; domain=" + document.domain + "; path=/;";
        } else {
            deleteCookie('googtrans');
        }
    })();

    function googleTranslateElementInit() {
        new google.translate.TranslateElement({
            pageLanguage: 'ko',
            layout: google.translate.TranslateElement.InlineLayout.SIMPLE,
            autoDisplay: false
        }, 'google_translate_element');
    }
</script>
<script>AOS.init();</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

<style>
    .skiptranslate, .goog-te-banner-frame { display: none !important; }
    body { top: 0px !important; }
</style>
<div id="google_translate_element" style="display:none;"></div>