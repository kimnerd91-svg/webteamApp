<?php
/* ============================================================
 *  상담 폼 접수 핸들러 → dm_consult
 *  POST: name, phone, interest, call_time, inflow, content,
 *        agree_privacy(필수), agree_marketing(선택)
 * ============================================================ */
include_once('./_common.php');
header('Content-Type: application/json; charset=utf-8');

// dm_consult 테이블 보장 (관리자 페이지 먼저 안 열어도 작동하도록)
sql_query("
    CREATE TABLE IF NOT EXISTS `dm_consult` (
        `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `name`            VARCHAR(50)  NOT NULL DEFAULT '',
        `phone`           VARCHAR(30)  NOT NULL DEFAULT '',
        `interest`        VARCHAR(50)  NOT NULL DEFAULT '',
        `call_time`       VARCHAR(30)  NOT NULL DEFAULT '',
        `inflow`          VARCHAR(50)  NOT NULL DEFAULT '',
        `content`         TEXT,
        `agree_privacy`   TINYINT(1)   NOT NULL DEFAULT 0,
        `agree_at`        DATETIME     NULL DEFAULT NULL,
        `agree_marketing` TINYINT(1)   NOT NULL DEFAULT 0,
        `status`          VARCHAR(20)  NOT NULL DEFAULT 'new',
        `memo`            TEXT,
        `handler`         VARCHAR(50)  NOT NULL DEFAULT '',
        `handled_at`      DATETIME     NULL DEFAULT NULL,
        `is_read`         TINYINT(1)   NOT NULL DEFAULT 0,
        `reg_ip`          VARCHAR(50)  NOT NULL DEFAULT '',
        `created_at`      DATETIME     NOT NULL,
        PRIMARY KEY (`id`),
        KEY `idx_status`  (`status`),
        KEY `idx_created` (`created_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
", false);

// ── 입력값 ────────────────────────────────────────────────
$name      = isset($_POST['name'])      ? clean_xss_tags(trim($_POST['name']))      : '';
$phone     = isset($_POST['phone'])     ? clean_xss_tags(trim($_POST['phone']))     : '';
$interest  = isset($_POST['interest'])  ? clean_xss_tags(trim($_POST['interest']))  : '';
$call_time = isset($_POST['call_time']) ? clean_xss_tags(trim($_POST['call_time'])) : '';
$inflow    = isset($_POST['inflow'])    ? clean_xss_tags(trim($_POST['inflow']))    : '';
$content   = isset($_POST['content'])   ? clean_xss_tags(trim($_POST['content']))   : '';
$agree     = isset($_POST['agree_privacy'])   ? 1 : 0;
$agree_mk  = isset($_POST['agree_marketing']) ? 1 : 0;

// ── 검증 ──────────────────────────────────────────────────
if (!$name || !$phone) {
    echo json_encode(['res'=>'fail', 'msg'=>'이름과 연락처를 입력해주세요.'], JSON_UNESCAPED_UNICODE);
    exit;
}
// 연락처 숫자 최소 검증
if (strlen(preg_replace('/[^0-9]/', '', $phone)) < 9) {
    echo json_encode(['res'=>'fail', 'msg'=>'연락처를 정확히 입력해주세요.'], JSON_UNESCAPED_UNICODE);
    exit;
}
if (!$agree) {
    echo json_encode(['res'=>'fail', 'msg'=>'개인정보 수집·이용에 동의해주세요.'], JSON_UNESCAPED_UNICODE);
    exit;
}

// ── 저장 ──────────────────────────────────────────────────
$now = G5_TIME_YMDHIS;
$ip  = $_SERVER['REMOTE_ADDR'] ?? '';

$sql = " INSERT INTO `dm_consult` SET
            `name`            = '".sql_real_escape_string($name)."',
            `phone`           = '".sql_real_escape_string($phone)."',
            `interest`        = '".sql_real_escape_string($interest)."',
            `call_time`       = '".sql_real_escape_string($call_time)."',
            `inflow`          = '".sql_real_escape_string($inflow)."',
            `content`         = '".sql_real_escape_string($content)."',
            `agree_privacy`   = $agree,
            `agree_at`        = '$now',
            `agree_marketing` = $agree_mk,
            `status`          = 'new',
            `is_read`         = 0,
            `reg_ip`          = '".sql_real_escape_string($ip)."',
            `created_at`      = '$now' ";

if (sql_query($sql)) {
    echo json_encode(['res'=>'success', 'msg'=>'상담 신청이 접수되었습니다.'], JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode(['res'=>'fail', 'msg'=>'접수 중 오류가 발생했습니다. 잠시 후 다시 시도해주세요.'], JSON_UNESCAPED_UNICODE);
}
