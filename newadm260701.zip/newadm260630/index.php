<?php
/*
 * ============================================
 * 메인 페이지 index.php
 * ============================================
 */

define('CONFIG_TABLE', 'dm_config');
define('BANNER_TABLE', 'mainbanner');
define('POPUP_TABLE', 'dm_popup');
define('BOARD_PREFIX', 'g5_write_');
define('REVIEW_BOARD', 'review');
define('COLUMN_BOARD', 'column');

include_once('./_common.php');

// ============================================
// 사이트 설정 (cf_* 직접변수는 head_sub이 공급)
// ============================================
$site_config = sql_fetch("SELECT * FROM dm_config WHERE cf_id = 1") ?: [];

// ============================================
// 배너 설정 (메인 배너 자동 선택)
// ============================================
$banner_row = sql_fetch("SELECT * FROM mainbanner WHERE is_main = 1");
if (!$banner_row) {
    $banner_row = sql_fetch("SELECT * FROM mainbanner ORDER BY id ASC LIMIT 1");
}

$banner_images = [];
$banner_settings = [
    'autoplay_delay' => 3000,
    'effect'         => 'slide',
    'loop'           => 1,
    'speed'          => 600
];

if ($banner_row) {
    $banner_images = $banner_row['images'] ? json_decode($banner_row['images'], true) : [];
    if ($banner_row['settings']) {
        $banner_settings = json_decode($banner_row['settings'], true);
    }
}

if (empty($banner_images)) {
    $banner_images = [[
        'src'           => 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1920',
        'visible'       => true,
        'link'          => '',
        'text_settings' => [
            'title'         => 'Welcome to Our Site',
            'description'   => 'Please add banners in admin panel',
            'button_text'   => '',
            'button_link'   => '',
            'text_color'    => '#ffffff',
            'text_position' => 'center'
        ]
    ]];
}

// ============================================
// 슬라이드 데이터 (매니저 연결 — 유지)
// ============================================
$slide_tabs = [];
$r = sql_query("SELECT DISTINCT tab FROM dm_slide WHERE is_visible=1 AND tab!='' ORDER BY tab ASC");
while ($row = sql_fetch_array($r)) $slide_tabs[] = $row['tab'];

$slide_by_tab = [];
$r_all = sql_query("SELECT * FROM dm_slide WHERE is_visible=1 ORDER BY display_order ASC, id ASC");
while ($row = sql_fetch_array($r_all)) $slide_by_tab[$row['tab'] ?: '기타'][] = $row;

$slide_result = sql_query("SELECT * FROM dm_slide WHERE is_visible = 1 ORDER BY tab ASC, display_order ASC, id ASC");
$slides = [];
while ($row = sql_fetch_array($slide_result)) $slides[] = $row;

$tabs = [];
foreach ($slides as $s) {
    if ($s['tab'] && !in_array($s['tab'], $tabs)) $tabs[] = $s['tab'];
}
$grouped = [];
foreach ($slides as $s) {
    $grouped[$s['tab'] ?: '__none__'][] = $s;
}
$render_tabs = !empty($tabs) ? $tabs : ['__none__'];

// ============================================
// 의료진 데이터 (dm_doctors)
// ============================================
$doctors    = [];
$doc_result = sql_query("SELECT * FROM dm_doctors WHERE is_visible = 1 ORDER BY display_order ASC, id ASC");
if ($doc_result) {
    while ($d = sql_fetch_array($doc_result)) {
        $d['degree'] = $d['degree'] ? json_decode($d['degree'], true) : [];
        $doctors[] = $d;
    }
}
$doc_no_img = '/images/docThumb01.png';

// ============================================
// 팝업 HTML
// ============================================
$popup_html = '';
if (file_exists('./popup.php')) {
    ob_start();
    include_once('./popup.php');
    $popup_html = ob_get_clean();
}

// ============================================
// 리뷰 데이터 (dm_review) — 흐르는 띠 2줄로 분배
// ============================================
$reviews = [];
$res = sql_query("SELECT * FROM dm_review WHERE is_visible = 1 ORDER BY display_order ASC, id DESC");
while ($row = sql_fetch_array($res)) $reviews[] = $row;

$half = ceil(count($reviews) / 2);
$row1 = array_slice($reviews, 0, $half);
$row2 = array_slice($reviews, $half) ?: $row1;

// ── 별점 HTML (반별 지원) ──
if (!function_exists('renderStarsHtml')) {
function renderStarsHtml(float $rating): string
{
    $html = '<div style="display:flex; gap:2px;">';
    for ($i = 1; $i <= 5; $i++) {
        if ($rating >= $i) {
            $html .= '<img src="/images/star.svg" alt="★" style="width:18px; height:17px;">';
        } elseif ($rating >= $i - 0.5) {
            $html .= '<span style="position:relative; display:inline-block; width:18px; height:17px;">'
                . '<img src="/images/star.svg" alt="" style="width:18px; height:17px; filter:grayscale(1) opacity(0.3); position:absolute; top:0; left:0;">'
                . '<img src="/images/star.svg" alt="½★" style="width:18px; height:17px; position:absolute; top:0; left:0; clip-path:inset(0 50% 0 0);">'
                . '</span>';
        } else {
            $html .= '<img src="/images/star.svg" alt="☆" style="width:18px; height:17px; filter:grayscale(1) opacity(0.3);">';
        }
    }
    $html .= '</div>';
    return $html;
}
}

// ── 작성자 마스킹 (홍길동 → 홍**) ──
if (!function_exists('maskAuthor')) {
function maskAuthor(string $name): string
{
    if (preg_match('/[\x{AC00}-\x{D7A3}]/u', $name)) {
        $first = mb_substr($name, 0, 1, 'UTF-8');
        $rest  = str_repeat('*', mb_strlen($name, 'UTF-8') - 1);
        return $first . $rest;
    } else {
        $len   = strlen($name);
        $show  = min(3, $len);
        $rest  = str_repeat('*', max(0, $len - $show));
        return substr($name, 0, $show) . $rest;
    }
}
}

// ── 시간 12시간제 변환 (진료시간 출력용) ──
if (!function_exists('to12h')) {
    function to12h($time)
    {
        if (!$time) return '';
        list($h, $m) = explode(':', $time);
        $h = (int)$h;
        $suffix = $h < 12 ? '오전' : '오후';
        $h12 = $h % 12 ?: 12;
        return $suffix . ' ' . sprintf('%02d:%02d', $h12, $m);
    }
}

// ── 요일 영문 → 한글 변환 ──
if (!function_exists('to_korean_day')) {
    function to_korean_day($days)
    {
        if (!$days) return $days;
        $map = [
            'monday' => '월', 'tuesday' => '화', 'wendsday' => '수', 'wednesday' => '수',
            'thursday' => '목', 'friday' => '금', 'saturday' => '토', 'sunday' => '일',
        ];
        $parts = preg_split('/[,\s]+/', trim($days));
        $result = [];
        foreach ($parts as $d) {
            $d = strtolower(trim($d));
            $result[] = $map[$d] ?? $d;
        }
        return implode('', $result);
    }
}

// ============================================
// 비포애프터 데이터 (dm_beforeafter)
// ============================================
$ba_table = 'dm_beforeafter';
$ba_result = sql_query("SELECT * FROM {$ba_table} WHERE is_visible = 1 ORDER BY display_order DESC, id ASC LIMIT 2");
$ba_cases = [];
while ($ba_row = sql_fetch_array($ba_result)) {
    $ba_cases[] = $ba_row;
}
$ba_first = $ba_cases[0] ?? null;
$ba_is_logged_in = !empty($member['mb_id']);

// ============================================
// HEAD (head_sub이 cf_* 직접변수 + 전역 스키마 공급)
// ============================================
include_once(G5_PATH . '/head_sub.php');

$g5['title'] = '';
?>

<!-- 팝업 -->
<?= $popup_html ?>

<!-- ============================================ -->
<!-- 메인 콘텐츠 -->
<!-- ============================================ -->
<main class="u-pretendard main">
    <!-- 임시 페이지 -->
    <div class="imsi position-fixed w-100 vh-100" style="z-index: 99999;">
        <div class="w-100 h-100 d-none d-lg-flex justify-content-center align-items-center"
            style="background-image: url('/images/imsibg.png'); background-position: center; background-size: cover; padding:  0; overflow-y: scroll;">
            <img style="width: 100%;" src="/images/imsi.png" alt="">
        </div>
       <div class="w-100 d-flex d-lg-none position-relative justify-content-center align-items-start"
    style="height:100dvh; overflow-y:auto; -webkit-overflow-scrolling:touch;
           background-image:url('/images/imsimobg.png'); background-position:center top; background-size:cover; padding:0;">
    <img style="width:100%; height:auto; display:block;" src="/images/imsimo.png" alt="">
    <a href="tel:<?= preg_replace('/[^0-9]/', '', $cf_tel ?? '') ?>"
       class="w-100 d-block"
       style="position:absolute; bottom:0; left:0; height:10vh;"></a>
</div>
    </div>
</main>

<style>
    .imsi::-webkit-scrollbar {
        display: none!important;
    }
</style>

<?php include_once(G5_PATH . '/tail_sub.php'); ?>