<?php
include_once($_SERVER['DOCUMENT_ROOT'] . '/common.php');
include_once($_SERVER['DOCUMENT_ROOT'] . '/_common.php');

$dm_conf = sql_fetch("SELECT * FROM dm_config WHERE cf_id = 1");
$rest_api_key  = trim($dm_conf['cf_kakao_rest_key']);
$client_secret = trim($dm_conf['cf_kakao_client_secret']);
$redirect_uri = "https://" . $_SERVER['HTTP_HOST'] . "/plugin/social_login/callback.php"; // ⭐ 동적으로 변경

$code = isset($_GET['code']) ? $_GET['code'] : '';

if (!$code) {
    alert("인증 코드가 없습니다.", G5_URL);
}

// 토큰 요청
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://kauth.kakao.com/oauth/token");
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$params = [
    'grant_type'    => 'authorization_code',
    'client_id'     => $rest_api_key,
    'client_secret' => $client_secret,
    'redirect_uri'  => $redirect_uri,
    'code'          => $code
];
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
$response = curl_exec($ch);
curl_close($ch);

$token_data = json_decode($response, true);

if(isset($token_data['error'])) {
    alert("카카오 인증 실패", G5_BBS_URL."/login.php");
}

// 사용자 정보 가져오기
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://kapi.kakao.com/v2/user/me");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_HTTPHEADER, ["Authorization: Bearer " . $token_data['access_token']]);
$user_response = curl_exec($ch);
curl_close($ch);

$user_data = json_decode($user_response, true);

if (!isset($user_data['id'])) {
    alert("사용자 정보를 가져올 수 없습니다.", G5_BBS_URL."/login.php");
}

$kakao_id = $user_data['id'];
$mb_id = "kakao_" . $kakao_id;

// 닉네임 추출
$nickname = '카카오회원' . substr($kakao_id, -4);
if (isset($user_data['properties']['nickname'])) {
    $nickname = $user_data['properties']['nickname'];
} elseif (isset($user_data['kakao_account']['profile']['nickname'])) {
    $nickname = $user_data['kakao_account']['profile']['nickname'];
}

// 이메일 추출
$email = '';
if (isset($user_data['kakao_account']['email'])) {
    $email = $user_data['kakao_account']['email'];
}

// SQL Injection 방지
$nickname = addslashes($nickname);
$email = addslashes($email);

// 회원 확인
$sql = "SELECT * FROM {$g5['member_table']} WHERE mb_id = '{$mb_id}'";
$mb = sql_fetch($sql);

if (!$mb['mb_id']) {
    // 신규 회원가입
    $sql = "
        INSERT INTO {$g5['member_table']} SET 
        mb_id = '{$mb_id}',
        mb_name = '{$nickname}',
        mb_nick = '{$nickname}',
        mb_email = '{$email}',
        mb_password = '!',
        mb_level = '2',
        mb_datetime = '".G5_TIME_YMDHIS."',
        mb_today_login = '".G5_TIME_YMDHIS."',
        mb_login_ip = '{$_SERVER['REMOTE_ADDR']}',
        mb_open = '1',
        mb_open_date = '".G5_TIME_YMD."'
    ";
    sql_query($sql);
    
    $mb = sql_fetch("SELECT * FROM {$g5['member_table']} WHERE mb_id = '{$mb_id}'");
} else {
    // 로그인 시간 업데이트
    $sql = " UPDATE {$g5['member_table']} SET 
             mb_today_login = '".G5_TIME_YMDHIS."',
             mb_login_ip = '{$_SERVER['REMOTE_ADDR']}'
             WHERE mb_id = '{$mb_id}' ";
    sql_query($sql);
}

// ⭐ 세션 설정 (그누보드 함수 사용)
set_session('ss_mb_id', $mb_id);

// 자동 로그인 쿠키
$key = md5($_SERVER['SERVER_ADDR'] . $_SERVER['SERVER_SOFTWARE'] . $_SERVER['HTTP_USER_AGENT'] . $mb['mb_password']);
set_cookie('ck_mb_id', $mb_id, 86400 * 31);
set_cookie('ck_auto', $key, 86400 * 31);

// 메인으로 이동 (그누보드 함수 사용)
goto_url(G5_URL);
?>