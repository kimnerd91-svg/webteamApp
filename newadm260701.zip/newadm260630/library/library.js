/* ============================================================
   yido-ui.js — 바닐라 UI 유틸 번들 (라이브러리 0)
   half1126 사이트에서 훔쳐온 패턴 전부 통합 + 형님 환경용으로 정리.

   포함 모듈:
     [A] no-JS 게이트   : html.js 클래스 (점진적 향상)
     [B] 모션 엔진      : reveal / stagger / count / parallax / progress
     [C] autovideo      : 화면에 잘 보이는 N개만 재생(모바일2/PC4) + 카톡 폴백
     [D] before/after   : 네이티브 input range 슬라이더(접근성 공짜)

   공통:
     - prefers-reduced-motion / 데이터절약 / 2G 분기
     - IntersectionObserver 폴백
   사용: <script defer src="yido-ui.js"></script> (게이트는 head 인라인 권장, 하단 주석)
   ============================================================ */
(function () {
  "use strict";

  /* ===== 환경 감지 ===== */
  var mm = window.matchMedia;
  var reduce = mm && mm("(prefers-reduced-motion: reduce)").matches;
  var hasIO = "IntersectionObserver" in window;

  // 데이터 절약 / 느린 네트워크 → 영상 자동재생 생략(poster만)
  var conn = navigator.connection || navigator.webkitConnection;
  var saveData =
    conn && (conn.saveData || /2g/.test(conn.effectiveType || ""));

  function $all(sel, ctx) {
    return Array.prototype.slice.call((ctx || document).querySelectorAll(sel));
  }
  function clamp(n, a, b) { return Math.max(a, Math.min(b, n)); }
  function easeOut(t) { return 1 - Math.pow(1 - t, 3); }

  /* ============================================================
     [A] no-JS 게이트
     ── 진짜 효과는 head 최상단 인라인이 담당(하단 주석 참고).
        여기선 혹시 인라인을 못 넣은 경우의 보강용.
     ============================================================ */
  document.documentElement.classList.add("js");

  /* ============================================================
     [B] 모션 엔진 : reveal / stagger
     ============================================================ */
  function setupReveal() {
    var items = $all("[data-reveal]");
    $all("[data-stagger]").forEach(function (parent) {
      var step = parseInt(parent.getAttribute("data-stagger-step"), 10) || 80;
      Array.prototype.slice.call(parent.children).forEach(function (kid, i) {
        if (!kid.hasAttribute("data-reveal")) kid.setAttribute("data-reveal", "");
        if (!kid.hasAttribute("data-delay")) kid.setAttribute("data-delay", String(i * step));
        if (items.indexOf(kid) === -1) items.push(kid);
      });
    });
    if (!items.length) return;

    if (reduce || !hasIO) {
      items.forEach(function (el) { el.classList.add("is-revealed"); });
      return;
    }
    items.forEach(function (el) { el.classList.add("reveal-init"); });

    var io = new IntersectionObserver(function (entries, obs) {
      entries.forEach(function (e) {
        if (!e.isIntersecting) return;
        var el = e.target;
        var delay = parseInt(el.getAttribute("data-delay"), 10) || 0;
        if (delay) setTimeout(function () { el.classList.add("is-revealed"); }, delay);
        else el.classList.add("is-revealed");
        obs.unobserve(el);
      });
    }, { threshold: 0.15, rootMargin: "0px 0px -8% 0px" });

    items.forEach(function (el) { io.observe(el); });
  }

  /* ===== count up ===== */
  function setupCount() {
    var counters = $all("[data-count]");
    if (!counters.length) return;

    function run(el) {
      var target = parseFloat(el.getAttribute("data-count")) || 0;
      var suffix = el.getAttribute("data-count-suffix") || "";
      var dur = parseInt(el.getAttribute("data-count-dur"), 10) || 1400;
      var decimals = (String(target).split(".")[1] || "").length;
      if (reduce) { el.textContent = target.toFixed(decimals) + suffix; return; }
      var start = null;
      function frame(ts) {
        if (start === null) start = ts;
        var p = clamp((ts - start) / dur, 0, 1);
        el.textContent = (target * easeOut(p)).toFixed(decimals) + suffix;
        if (p < 1) requestAnimationFrame(frame);
        else el.textContent = target.toFixed(decimals) + suffix;
      }
      requestAnimationFrame(frame);
    }
    if (!hasIO) { counters.forEach(run); return; }
    var io = new IntersectionObserver(function (entries, obs) {
      entries.forEach(function (e) {
        if (!e.isIntersecting) return;
        run(e.target); obs.unobserve(e.target);
      });
    }, { threshold: 0.6 });
    counters.forEach(function (el) { io.observe(el); });
  }

  /* ===== parallax + progress (단일 rAF 루프) ===== */
  function setupScrollLoop() {
    var pEls = reduce ? [] : $all("[data-parallax]");
    var bar = document.querySelector(".scroll-progress");
    if (!pEls.length && !bar) return;

    var pData = pEls.map(function (el) {
      return { el: el, amt: parseFloat(el.getAttribute("data-parallax")) || 24 };
    });
    var ticking = false, vh = window.innerHeight;

    function update() {
      ticking = false;
      var y = window.pageYOffset || document.documentElement.scrollTop;
      if (bar) {
        var docH = document.documentElement.scrollHeight - window.innerHeight;
        bar.style.width = (docH > 0 ? clamp((y / docH) * 100, 0, 100) : 0) + "%";
      }
      for (var i = 0; i < pData.length; i++) {
        var r = pData[i].el.getBoundingClientRect();
        var off = (r.top + r.height / 2 - vh / 2) / vh;
        pData[i].el.style.transform =
          "translate3d(0," + (clamp(off, -1, 1) * pData[i].amt * -1).toFixed(1) + "px,0)";
      }
    }
    function onScroll() { if (!ticking) { ticking = true; requestAnimationFrame(update); } }
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", function () { vh = window.innerHeight; onScroll(); }, { passive: true });
    update();
  }

  /* ============================================================
     [C] autovideo : 잘 보이는 N개만 재생 + 카톡/인앱 폴백
     마크업: <video data-autovideo muted loop playsinline preload="none"
                    poster="...jpg"><source src="...mp4"></video>
     ============================================================ */
  function setupAutoVideo() {
    var vids = $all("video[data-autovideo]");
    if (!vids.length) return;

    /* 카톡·네이버 인앱브라우저는 poster/자동재생을 렌더 안 해 빈 박스만 뜸
       → 영상 요소 배경에 poster를 깔아 '사진'은 항상 보이게 (핵심 폴백) */
    $all("video[poster]").forEach(function (v) {
      var p = v.getAttribute("poster");
      if (p) {
        v.style.backgroundImage = "url(" + p + ")";
        v.style.backgroundSize = "cover";
        v.style.backgroundPosition = "center";
      }
    });

    // reduced-motion / 데이터절약 / 2G → 재생 안 함(poster 유지)
    if (reduce || saveData || !hasIO) return;

    var CAP = window.matchMedia("(max-width: 768px)").matches ? 2 : 4;
    var ratios = new Map();

    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) { ratios.set(e.target, e.intersectionRatio); });
      // 가시성 높은 순 정렬 → 상위 CAP개만 play
      var sorted = Array.prototype.slice.call(ratios.entries())
        .filter(function (x) { return x[1] > 0.1; })
        .sort(function (a, b) { return b[1] - a[1]; });
      var playSet = new Set(sorted.slice(0, CAP).map(function (x) { return x[0]; }));
      vids.forEach(function (v) {
        if (playSet.has(v)) {
          if (v.paused) { try { v.play(); } catch (err) {} }
        } else if (!v.paused) { v.pause(); }
      });
    }, { threshold: [0, 0.1, 0.25, 0.5, 0.75, 1] });

    vids.forEach(function (v) { ratios.set(v, 0); io.observe(v); });
  }

  /* ============================================================
     [D] before/after 슬라이더 (네이티브 range = 접근성 공짜)
     마크업:
       <figure class="ba">
         <img class="ba__after"  src="after.webp"  alt="치료 후">
         <img class="ba__before" src="before.webp" alt="치료 전">
         <input class="ba__range" type="range" min="0" max="100" value="50"
                aria-label="치료 전후 비교 슬라이더">
         <span class="ba__divider" aria-hidden="true"></span>
       </figure>
     ============================================================ */
  function setupBA() {
    $all(".ba").forEach(function (fig) {
      var range = fig.querySelector(".ba__range");
      if (!range) return;
      function apply() { fig.style.setProperty("--pos", range.value + "%"); }
      range.addEventListener("input", apply);
      range.addEventListener("change", apply);
      apply();
    });
  }

  /* ===== 부트 ===== */
  function init() {
    setupReveal();
    setupCount();
    setupScrollLoop();
    setupAutoVideo();
    setupBA();
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else { init(); }
})();

/* ============================================================
   ⚠️ no-JS 게이트는 <head> 최상단에 이 한 줄을 인라인으로 넣어야
      효과가 가장 빠릅니다(FOUC 방지):
      <script>document.documentElement.classList.add('js')</script>
   그리고 CSS에서 숨김 처리는 반드시 html.js 안에서만:
      html.js .reveal-init { opacity:0 }   ← JS 죽으면 그냥 다 보임
   ============================================================ */
