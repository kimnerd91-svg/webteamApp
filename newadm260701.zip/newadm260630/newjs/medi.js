// ==========================================
// 토스트 메시지 (전역 — DOMContentLoaded 밖)
// ==========================================
window.showToast = function (message, type) {
    type = type || 'default';
    var existingToast = document.querySelector('.toast-message');
    if (existingToast) existingToast.remove();

    var toast = document.createElement('div');
    toast.className = 'toast-message';
    if (type === 'success') toast.classList.add('success');
    if (type === 'error')   toast.classList.add('error');
    if (type === 'warning') toast.classList.add('warning');
    toast.textContent = message;

    document.body.appendChild(toast);
    setTimeout(function () { toast.classList.add('show'); }, 10);
    setTimeout(function () {
        toast.classList.remove('show');
        setTimeout(function () { toast.remove(); }, 300);
    }, 2500);
};


// ==========================================
// 스크롤 깊이 트래킹 (전역 — DOMContentLoaded 밖)
// ==========================================
var scrollTracked = { '25': false, '50': false, '75': false, '100': false };

window.addEventListener('scroll', function () {
    var scrollHeight = document.documentElement.scrollHeight - window.innerHeight;
    if (scrollHeight <= 0) return;
    var scrolled = (window.scrollY / scrollHeight) * 100;

    [25, 50, 75, 100].forEach(function (depth) {
        var key = String(depth);
        if (scrolled >= (depth === 100 ? 99 : depth) && !scrollTracked[key]) {
            scrollTracked[key] = true;
            if (typeof gtag !== 'undefined') {
                gtag('event', 'scroll_depth', {
                    depth: depth + '%',
                    page_location: window.location.href
                });
            }
        }
    });
});


document.addEventListener('DOMContentLoaded', function () {

    // ==========================================
    // 1. 스크롤 탑 버튼
    // ==========================================
    var scrollTopBtn  = document.getElementById('scrollTop');
    var scrollTopBtn2 = document.getElementById('scrollTop2');

    function handleScrollTop() {
        var show = window.scrollY > 300;
        if (scrollTopBtn) {
            scrollTopBtn.style.opacity       = show ? '1' : '0';
            scrollTopBtn.style.pointerEvents = show ? 'auto' : 'none';
        }
        if (scrollTopBtn2) {
            scrollTopBtn2.style.opacity       = show ? '1' : '0';
            scrollTopBtn2.style.pointerEvents = show ? 'auto' : 'none';
        }
    }
    window.addEventListener('scroll', handleScrollTop);

    if (scrollTopBtn)  scrollTopBtn.addEventListener('click',  function () { window.scrollTo({ top: 0, behavior: 'smooth' }); });
    if (scrollTopBtn2) scrollTopBtn2.addEventListener('click', function () { window.scrollTo({ top: 0, behavior: 'smooth' }); });


    // ==========================================
    // 2. 케이스 탭 전환 (tab-btn)
    // ==========================================
    var tabButtons  = document.querySelectorAll('.tab-btn');
    var tabContents = document.querySelectorAll('.tab-contents');

    tabButtons.forEach(function (button) {
        button.addEventListener('click', function () {
            tabButtons.forEach(function (btn) { btn.classList.remove('active'); });
            this.classList.add('active');

            tabContents.forEach(function (content) {
                content.classList.remove('active');
                content.style.display = 'none';
            });

            var tabId = this.getAttribute('data-tab');
            var targetTab = document.getElementById(tabId);
            if (targetTab) {
                targetTab.classList.add('active');
                targetTab.style.display = 'grid';
            }
        });
    });

    tabContents.forEach(function (content, index) {
        content.style.display = index === 0 ? 'grid' : 'none';
    });


    // ==========================================
    // 3. 진료 항목 탭 전환 (doc-btn)
    // ==========================================
    var docButtons = document.querySelectorAll('.doc-btn');

    docButtons.forEach(function (button) {
        button.addEventListener('click', function () {
            var targetTab = this.getAttribute('data-tab');

            document.querySelectorAll('.tab-content').forEach(function (content) {
                content.classList.remove('active');
            });
            document.querySelectorAll('.doc-btn').forEach(function (btn) {
                btn.classList.remove('active');
            });

            var targetEl = document.getElementById(targetTab);
            if (targetEl) targetEl.classList.add('active');
            document.querySelectorAll('[data-tab="' + targetTab + '"]').forEach(function (btn) {
                btn.classList.add('active');
            });
        });
    });



    // ==========================================
    // 7. 퀵메뉴 (필형 토글 + 외부 클릭 닫기)
    // ==========================================
    (function () {
        var pillItems  = document.querySelector('.quick_menu_pill-items');
        var pillToggle = document.getElementById('qm_pill_toggle');
        var pillTop    = document.getElementById('qm_pill_top');

        if (pillToggle) {
            pillToggle.onclick = function () {
                pillItems.classList.toggle('active');
                pillToggle.classList.toggle('active');
                if (typeof gtag !== 'undefined') gtag('event', 'click_quick_menu', { event_category: 'engagement', event_label: 'pill_toggle' });
            };
        }

        if (pillTop) {
            pillTop.onclick = function () {
                window.scrollTo({ top: 0, behavior: 'smooth' });
                if (typeof gtag !== 'undefined') gtag('event', 'click_quick_menu', { event_category: 'engagement', event_label: 'pill_top' });
            };
        }

        var allLinks = document.querySelectorAll('.qm-circle-item, .qm-bar-item, .qm-bar-fixed-item');
        for (var i = 0; i < allLinks.length; i++) {
            allLinks[i].onclick = function (e) {
                var has = this.getAttribute('data-has');
                if (has === '0' && this.href && this.href.indexOf('#') !== -1) {
                    e.preventDefault();
                    alert('링크가 설정되지 않았습니다.');
                    return false;
                }
            };
        }

        document.addEventListener('click', function (e) {
            var pillMenu = document.getElementById('quick_menu_pill');
            if (pillMenu && !pillMenu.contains(e.target) && pillItems && pillItems.classList.contains('active')) {
                pillItems.classList.remove('active');
                if (pillToggle) pillToggle.classList.remove('active');
            }
        });
    })();


    // ==========================================
    // 8. SD 팝업 + 백드랍
    // ==========================================
    var sdBtn    = document.getElementById('SD');
    var sdPopup  = document.getElementById('SD-popup');
    var sdCancel = document.getElementById('SD-cancel');

    var sdBackdrop = document.createElement('div');
    sdBackdrop.id = 'sd-backdrop';
    Object.assign(sdBackdrop.style, { display: 'none', position: 'fixed', inset: '0', backgroundColor: 'rgba(0,0,0,0.5)', zIndex: '998' });
    document.body.appendChild(sdBackdrop);

    window.openSdPopup = function () {
        if (sdPopup) sdPopup.style.display = 'block';
        if (window.innerWidth <= 640) sdBackdrop.style.display = 'block';
    };
    window.closeSdPopup = function () {
        if (sdPopup) sdPopup.style.display = 'none';
        sdBackdrop.style.display = 'none';
    };

    if (sdBtn)    sdBtn.addEventListener('click', function (e) { e.stopPropagation(); sdPopup.style.display === 'block' ? closeSdPopup() : openSdPopup(); });
    if (sdCancel) sdCancel.addEventListener('click', function () { closeSdPopup(); });
    sdBackdrop.addEventListener('click', function () { closeSdPopup(); });
    document.addEventListener('click', function (e) {
        if (sdPopup && sdBtn && !sdPopup.contains(e.target) && !sdBtn.contains(e.target)) closeSdPopup();
    });


    // ==========================================
    // 9. 문의 드롭다운 + AJAX 폼 제출
    // ==========================================
    document.querySelectorAll('.custom-select-wrap').forEach(function (wrap) {
        var trigger = wrap.querySelector('.custom-select-trigger');
        var options = wrap.querySelector('.custom-select-options');
        var label   = wrap.querySelector('.custom-select-label');
        var arrow   = wrap.querySelector('.custom-select-arrow');
        var hidden  = document.getElementById('inquiry_type_value');

        if (!trigger) return;

        trigger.addEventListener('click', function (e) {
            e.stopPropagation();
            var isOpen = options.style.display === 'block';
            options.style.display = isOpen ? 'none' : 'block';
            arrow.style.transform = isOpen ? 'rotate(0deg)' : 'rotate(180deg)';
        });

        options.querySelectorAll('.custom-option').forEach(function (option) {
            option.addEventListener('click', function (e) {
                e.stopPropagation();
                if (hidden) hidden.value = option.dataset.value;
                label.textContent = option.textContent.trim();
                label.classList.remove('u-txt-gray-500');
                options.querySelectorAll('.custom-option').forEach(function (o) { o.classList.remove('selected'); });
                option.classList.add('selected');
                options.style.display = 'none';
                arrow.style.transform = 'rotate(0deg)';
            });
        });
    });

    document.addEventListener('click', function () {
        document.querySelectorAll('.custom-select-options').forEach(function (opt) { opt.style.display = 'none'; });
        document.querySelectorAll('.custom-select-arrow').forEach(function (a)   { a.style.transform  = 'rotate(0deg)'; });
    });

    window.submitInquiry = function (f) {
        var inquiryType = f.elements['inquiry_type'];
        if (!inquiryType || !inquiryType.value) { window.showToast('문의 분야를 선택해주세요.', 'warning'); return false; }
        if (!f.wr_name.value.trim())             { window.showToast('성함을 입력해주세요.', 'warning');    return false; }
        if (!f.wr_1.value.trim())                { window.showToast('연락처를 입력해주세요.', 'warning');  return false; }

        var submitBtn = f.querySelector('button[type="submit"]');
        submitBtn.disabled = true;
        submitBtn.innerText = '전송 중...';

        fetch('/ajax.inquiry_update.php', { method: 'POST', body: new FormData(f) })
            .then(function (res) {
                return res.text().then(function (text) {
                    try { return JSON.parse(text); } catch (e) { throw new Error('서버 내부 오류가 발생했습니다.'); }
                });
            })
            .then(function (data) {
                if (data.res === 'success') {
                    if (typeof gtag !== 'undefined') gtag('event', 'generate_lead', { event_category: 'conversion', event_label: 'inquiry_submit', inquiry_type: inquiryType.value, value: 1 });
                    var modal = document.getElementById('inquiryModal');
                    if (modal && typeof bootstrap !== 'undefined') bootstrap.Modal.getInstance(modal)?.hide();
                    f.reset();
                    window.showToast('문의가 정상적으로 접수되었습니다. 🎉', 'success');
                    setTimeout(function () { closeSdPopup(); }, 300);
                } else {
                    if (typeof gtag !== 'undefined') gtag('event', 'form_error', { event_category: 'error', event_label: 'inquiry_submit_fail' });
                    window.showToast(data.msg || '문의 접수에 실패했습니다.', 'error');
                }
            })
            .catch(function (error) {
                if (typeof gtag !== 'undefined') gtag('event', 'form_error', { event_category: 'error', event_label: 'inquiry_submit_error' });
                window.showToast(error.message || '오류가 발생했습니다.', 'error');
            })
            .finally(function () {
                submitBtn.disabled = false;
                submitBtn.innerText = '문의하기';
            });

        return false;
    };


});