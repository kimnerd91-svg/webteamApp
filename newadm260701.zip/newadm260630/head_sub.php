<?php
if (!defined('_GNUBOARD_')) exit;

// ============================================
// dm_config 사이트 설정 조회
// ============================================
// 조회 실패 시 빈 배열로 폴백. 개별 키 방어는 아래 전역변수 할당부의 ?? '' 가 담당.
$dm_conf = @sql_fetch("SELECT * FROM dm_config WHERE cf_id = 1");
if (!$dm_conf) $dm_conf = [];

// ============================================
// 전역 변수로 꺼내기 (모든 페이지에서 바로 사용 가능)
// ============================================

// 기본 정보
$cf_site_name        = $dm_conf['cf_site_name']        ?? '';
$cf_title            = $dm_conf['cf_title']            ?? '';
$cf_description      = $dm_conf['cf_description']      ?? '';
$cf_tel              = $dm_conf['cf_tel']              ?? '';
$cf_address          = $dm_conf['cf_address']          ?? '';
$cf_ceo_name         = $dm_conf['cf_ceo_name']         ?? '';
$cf_company_name     = $dm_conf['cf_company_name']     ?? '';
$cf_business_number  = $dm_conf['cf_business_number']  ?? '';

// 진료시간
$cf_open_time        = $dm_conf['cf_open_time']        ?? '';
$cf_close_time       = $dm_conf['cf_close_time']       ?? '';
$cf_sat_open         = $dm_conf['cf_sat_open']         ?? '';
$cf_sat_close        = $dm_conf['cf_sat_close']        ?? '';
$cf_night_days       = $dm_conf['cf_night_days']       ?? '';
$cf_night_open       = $dm_conf['cf_night_open']       ?? '';
$cf_night_close      = $dm_conf['cf_night_close']      ?? '';
$cf_lunch_open       = $dm_conf['cf_lunch_open']       ?? '';
$cf_lunch_close      = $dm_conf['cf_lunch_close']      ?? '';

// 법적
$cf_privacy_policy   = $dm_conf['cf_privacy_policy']   ?? '';
$cf_terms            = $dm_conf['cf_terms']            ?? '';

// 소셜 로그인
$cf_social_login_use = $dm_conf['cf_social_login_use'] ?? 0;

// 이미지 URL (G5_DATA_URL 조합)
$cf_logo    = !empty($dm_conf['cf_logo'])
    ? G5_DATA_URL . '/common/' . $dm_conf['cf_logo']
    : '';
$cf_favicon = !empty($dm_conf['cf_favicon'])
    ? G5_DATA_URL . '/common/' . $dm_conf['cf_favicon']
    : '';
$cf_og      = !empty($dm_conf['cf_og_image'])
    ? G5_DATA_URL . '/common/' . $dm_conf['cf_og_image']
    : '';

// 스크립트
$cf_ga_id            = $dm_conf['cf_ga_id']            ?? '';
$cf_add_script       = $dm_conf['cf_add_script']       ?? '';
$cf_add_body_script  = $dm_conf['cf_add_body_script']  ?? '';

// 외부 링크
$cf_blog             = $dm_conf['cf_blog']             ?? '';
$cf_kakao            = $dm_conf['cf_kakao']            ?? '';
$cf_naver_booking    = $dm_conf['cf_naver_booking']    ?? '';
$cf_naver_talk       = $dm_conf['cf_naver_talk']       ?? '';
$cf_instagram        = $dm_conf['cf_instagram']        ?? '';
$cf_youtube          = $dm_conf['cf_youtube']          ?? '';

// 주소
$cf_address_base     = $dm_conf['cf_address_base']     ?? '';
$cf_address_detail   = $dm_conf['cf_address_detail']   ?? '';
$cf_address_add      = $dm_conf['cf_address_add']      ?? '';

// 추적/인증
// [변경] cf_ga4_property_id 제거 — cf_ga_id 하나로 통합
// [변경] GSC·Naver: DB에 전체 <meta> 태그가 저장되므로 stripslashes만 적용 후 그대로 출력
$cf_gtm_id             = $dm_conf['cf_gtm_id']             ?? '';
$cf_gsc_verification   = stripslashes($dm_conf['cf_gsc_verification']   ?? '');
$cf_naver_verification = stripslashes($dm_conf['cf_naver_verification'] ?? '');

// GEO / 스키마
$cf_founded_year     = $dm_conf['cf_founded_year']     ?? '';
$cf_expertise        = $dm_conf['cf_expertise']        ?? '';
$cf_global_faq       = $dm_conf['cf_global_faq']       ?? '';

// 지역 (cascading 셀렉트) — addressRegion / addressLocality 소스
$cf_sido             = $dm_conf['cf_sido']             ?? '';
$cf_sigungu          = $dm_conf['cf_sigungu']          ?? '';

// 기타
$cf_city             = $dm_conf['cf_city']             ?? '';  // 레거시 폴백
$cf_lat              = $dm_conf['cf_lat']              ?? '';
$cf_lng              = $dm_conf['cf_lng']              ?? '';

// 사이트 상태 (dev/live 노인덱스 토글)
$cf_site_status      = $dm_conf['cf_site_status']      ?? 'dev';

// ============================================
// dm_page_seo 통합 조회 (seo_title · seo_desc · og_image · schema_json 한 번에)
// - page_seo_manager.php에서 경로별로 입력한 메타·스키마를 현재 경로로 1회 조회
// - 페이지가 $g5['title']/$page_description을 직접 지정했으면 그게 우선, 없으면 psm 값 주입
// - 우선순위: 페이지 직접 지정 > dm_page_seo > 전역(cf_title/cf_description)
// - 경로 정규화 규칙: pathname + (id 파라미터 있으면 ?id=값만). page_seo_manager와 동일해야 매칭됨
// - column.php(칼럼 상세)는 자체 동적 스키마/메타를 쓰므로 psm 스킵 (중복 방지)
// ============================================
$__pseo_row = null;
if (!defined('G5_IS_ADMIN')) {
    $__pseo_path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    $__is_column = (strpos($__pseo_path, '/column.php') !== false);
    if (!$__is_column) {
        if (isset($_GET['id']) && $_GET['id'] !== '') {
            $__pseo_path .= '?id=' . preg_replace('/[^0-9A-Za-z_-]/', '', $_GET['id']);
        }
        $__pseo_key = sql_escape_string($__pseo_path);
        $__pseo_row = @sql_fetch("SELECT seo_title, seo_desc, og_image, schema_json FROM dm_page_seo WHERE path = '{$__pseo_key}' LIMIT 1");

        if ($__pseo_row) {
            // title: 페이지가 $g5['title']을 직접 지정 안 했을 때만 psm seo_title 주입
            // (빈 문자열로 미리 set 돼 있어도 채워지도록 empty 체크)
            if (empty($g5['title']) && !empty(trim($__pseo_row['seo_title'] ?? ''))) {
                $g5['title'] = trim($__pseo_row['seo_title']);
            }
            // description: 페이지가 직접 지정 안 했을 때만 psm seo_desc 주입
            if (empty($page_description) && !empty(trim($__pseo_row['seo_desc'] ?? ''))) {
                $page_description = trim($__pseo_row['seo_desc']);
            }
            // og_image: 페이지가 직접 지정 안 했을 때만 psm og_image 주입
            if (empty($page_og_image) && !empty(trim($__pseo_row['og_image'] ?? ''))) {
                $page_og_image = trim($__pseo_row['og_image']);
            }
        }
    }
}

// ============================================
// 테마 head_sub.php 위임 처리 (그누보드 표준)
// ============================================
if (!defined('G5_IS_ADMIN') && defined('G5_THEME_PATH') && is_file(G5_THEME_PATH . '/head_sub.php')) {
    require_once(G5_THEME_PATH . '/head_sub.php');
    return;
}

$g5_debug['php']['begin_time'] = $begin_time = get_microtime();

if (empty($g5['title'])) {
    $g5['title']    = $cf_title;
    $g5_head_title  = $g5['title'];
} else {
    $g5_head_title = $g5['title'];
}

$g5['title']    = strip_tags($g5['title']);
$g5_head_title  = strip_tags($g5_head_title);

$g5['lo_location'] = addslashes($g5['title']);
if (!$g5['lo_location'])
    $g5['lo_location'] = addslashes(clean_xss_tags($_SERVER['REQUEST_URI']));
$g5['lo_url'] = addslashes(clean_xss_tags($_SERVER['REQUEST_URI']));
if (strstr($g5['lo_url'], '/' . G5_ADMIN_DIR . '/') || $is_admin == 'super') $g5['lo_url'] = '';

// ===== 메타/OG 최종 확정 (페이지 > dm_page_seo > 전역) =====
$meta_description = !empty($page_description) ? $page_description : $cf_description;
$og_title        = !empty($g5['title']) ? $g5['title'] : ($dm_conf['cf_site_name'] ?? $cf_title);
$og_description  = !empty($page_description) ? $page_description : $cf_description;
$og_image_final  = !empty($page_og_image) ? $page_og_image : $cf_og;

// ===== 다국어 버퍼링 시작 =====
$lang = $_GET['lang'] ?? 'ko';
$allowed_langs = ['ko', 'en', 'ja', 'zh'];
if (!in_array($lang, $allowed_langs)) $lang = 'ko';
if ($lang !== 'ko') ob_start();
// ================================
?>
<!doctype html>
<html lang="ko">

<head>
    <meta charset="utf-8">
    <!-- [library] no-JS 게이트 — JS 살아있을 때만 html.js 부여(reveal 등 숨김처리는 html.js 안에서만 동작).
         CSS·라이브러리보다 먼저 와야 FOUC 방지. library.js 미사용 사이트에 있어도 무해(클래스만 추가). -->
    <script>document.documentElement.classList.add('js')</script>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <?php
    if (defined('G5_IS_ADMIN') || $cf_site_status !== 'live'):
    ?>
    <meta name="robots" content="noindex, nofollow">
    <?php else: ?>
    <meta name="robots" content="index, follow">
    <?php endif; ?>
    <?php if (!empty($cf_gsc_verification)): ?>
    <meta name="google-site-verification" content="<?= htmlspecialchars($cf_gsc_verification) ?>">
    <?php endif; ?>
    <?php if (!empty($cf_naver_verification)): ?>
    <meta name="naver-site-verification" content="<?= htmlspecialchars($cf_naver_verification) ?>">
    <?php endif; ?>
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">
    <meta property="og:url" content="https://<?php echo $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>">
<meta property="og:site_name" content="<?php echo htmlspecialchars($dm_conf['cf_site_name'] ?? $cf_title); ?>">

    <?php if (!defined('G5_IS_ADMIN')): ?>
<meta name="description" content="<?php echo htmlspecialchars($meta_description); ?>">
        <meta property="og:type" content="website">
<meta property="og:title" content="<?php echo htmlspecialchars($og_title); ?>">
        <meta property="og:description" content="<?php echo htmlspecialchars($og_description); ?>">
        <?php if ($og_image_final): ?>
            <meta property="og:image" content="<?php echo htmlspecialchars($og_image_final); ?>">
        <?php endif; ?>
        <?php if ($cf_favicon): ?>
            <link rel="shortcut icon" href="<?php echo $cf_favicon; ?>" type="image/x-icon">
        <?php endif; ?>
    <?php endif; ?>

    <?php if (!empty($cf_gtm_id)): ?>
    <!-- Google Tag Manager -->
    <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','<?= htmlspecialchars($cf_gtm_id) ?>');</script>
    <!-- End Google Tag Manager -->
    <?php endif; ?>

    <?php if ($cf_ga_id): ?>
        <!-- Google Analytics 4 -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo $cf_ga_id; ?>"></script>
        <script>
            window.dataLayer = window.dataLayer || [];

            function gtag() {
                dataLayer.push(arguments);
            }
            gtag('js', new Date());
            gtag('config', '<?php echo $cf_ga_id; ?>');
        </script>
    <?php endif; ?>

    <?php if (trim($cf_add_script) !== ''): ?>
        <?php echo "\n    " . stripslashes($cf_add_script) . "\n"; ?>
    <?php endif; ?>
    <?php
// ============================================
// 페이지별 스키마 출력 (dm_page_seo.schema_json)
// - 위에서 이미 조회한 $__pseo_row 재사용 (중복 쿼리 없음)
// - 전역 Dentist/WebSite는 위 cf_add_script가 이미 뿌리므로 여기선 중복 출력하지 않음
// ============================================
if (!defined('G5_IS_ADMIN') && $__pseo_row && !empty(trim($__pseo_row['schema_json'] ?? ''))) {
    echo "\n    " . stripslashes($__pseo_row['schema_json']) . "\n";
}
?>
    <?php
// 공통 FAQ 스키마 자동 삽입
$cf_global_faq_raw = $dm_conf['cf_global_faq'] ?? '';
if (!empty(trim($cf_global_faq_raw))) {
    $faq_items = json_decode($cf_global_faq_raw, true);
    // ... FAQ schema 렌더링
}
?>

    <title><?php echo $g5_head_title; ?></title>

    <?php if (!defined('G5_IS_ADMIN')): ?>
        <link rel="canonical" href="<?php
            if (!empty($page_canonical)) {
                // 페이지가 직접 지정한 canonical 우선 (예: column.php의 ?id= 포함 URL)
                echo htmlspecialchars($page_canonical, ENT_QUOTES);
            } else {
                $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
                $host     = htmlspecialchars($_SERVER['HTTP_HOST'], ENT_QUOTES);
                $path     = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
                echo $protocol . '://' . $host . $path;
            }
        ?>">
    <?php endif; ?>

    <script>
        var g5_url       = "<?php echo G5_URL ?>";
        var g5_bbs_url   = "<?php echo G5_BBS_URL ?>";
        var g5_is_member = "<?php echo isset($is_member) ? $is_member : ''; ?>";
        var g5_is_admin  = "<?php echo isset($is_admin)  ? $is_admin  : ''; ?>";
        var g5_is_mobile = "<?php echo G5_IS_MOBILE ?>";
    </script>

    <!-- ========================================== -->
    <!-- CSS -->
    <!-- ========================================== -->
    <?php
    // [성능/LCP] 첫 배너 이미지 preload + fetchpriority=high
    // - index.php가 head_sub include(306줄) 전에 $banner_images를 채워두므로 그대로 활용.
    // - 배너 파일명은 매번 바뀌지만, 현재 첫 배너를 실시간으로 읽어 preload → 항상 최신.
    // - PC/모바일 배너를 media 쿼리로 분기. 영상 배너(type=video)는 제외.
    // - background-image라 태그에 fetchpriority를 못 주므로 preload로 우선순위 부여(LCP 직격).
    if (!empty($banner_images[0]) && (($banner_images[0]['type'] ?? 'image') !== 'video')) {
        $__bn_web = $banner_images[0]['src']        ?? '';
        $__bn_mob = $banner_images[0]['src_mobile'] ?? '';
        if ($__bn_web !== '') {
            echo '    <link rel="preload" as="image" fetchpriority="high" href="' . htmlspecialchars($__bn_web, ENT_QUOTES) . '" media="(min-width:993px)">' . "\n";
        }
        if ($__bn_mob !== '') {
            echo '    <link rel="preload" as="image" fetchpriority="high" href="' . htmlspecialchars($__bn_mob, ENT_QUOTES) . '" media="(max-width:992px)">' . "\n";
        } elseif ($__bn_web !== '') {
            // 모바일 전용 배너가 없으면 PC 배너를 모바일에도 preload
            echo '    <link rel="preload" as="image" fetchpriority="high" href="' . htmlspecialchars($__bn_web, ENT_QUOTES) . '" media="(max-width:992px)">' . "\n";
        }
    }
    ?>
    <!-- [성능] 외부 CDN preconnect — DNS+TLS 핸드셰이크를 미리 시작해 직렬 지연 단축 -->
    <link rel="preconnect" href="https://cdn.jsdelivr.net" crossorigin>
    <link rel="preconnect" href="https://cdnjs.cloudflare.com" crossorigin>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="dns-prefetch" href="https://unpkg.com">
    <link rel="dns-prefetch" href="https://ssl.daumcdn.net">

    <!-- 1. Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/admin.css?ver=1">

    <!-- 2. SETTING.CSS -->
    <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/setting.css">

    <!-- 3. BASE_CORE.CSS — admin.css에 병합됨 (제거) -->

    <!-- 4. 외부 라이브러리 CSS -->
    <!-- ⚠️ AOS는 library.js 모션엔진으로 대체 가능. 신규/리뉴얼 사이트는 아래 AOS를 주석처리하고
         library.css 주석을 풀 것. (Swiper는 슬라이더라 library.js에 대체 기능 없음 → 슬라이더 쓰면 유지) -->
    <link rel="stylesheet" href="https://unpkg.com/aos@2.3.1/dist/aos.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">

    <!-- [library] 바닐라 UI 번들 스타일 — reveal/parallax/progress/autovideo/before-after/필름그레인.
         GSAP·AOS 대체용. 쓸 때 아래 주석을 풀 것. (JS는 하단 [library] 블록과 세트로 활성화) -->
    <!-- <link rel="stylesheet" href="<?php echo G5_URL; ?>/library/library.css"> -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined&display=swap">
    <!-- [성능] Pretendard dynamic-subset: 실제 쓰인 글자의 서브셋 woff2만 로드.
         전체 5종(약 4.5MB) → 수백KB. font-family 이름은 "Pretendard" 그대로라 CSS 무수정. -->
    <link rel="stylesheet" as="style" crossorigin href="https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/dist/web/static/pretendard-dynamic-subset.min.css">
    <!-- [성능] 손글씨체(원장명 장식용) dynamic-subset: 교보(woff 2MB 통짜) 대체.
         나눔손글씨 미래나무, 쓰인 글자만 로드 → 2MB가 수KB로. font-family "NanumMiRaeNaMu". -->
    <link rel="stylesheet" as="style" crossorigin href="https://cdn.jsdelivr.net/gh/fonts-archive/NanumMiRaeNaMu/subsets/NanumMiRaeNaMu-dynamic-subset.css">

    <!-- 5. 그누보드 관리자 CSS -->
    <?php if (defined('G5_IS_ADMIN')): ?>
        <link rel="stylesheet" href="<?php echo G5_ADMIN_URL; ?>/css/admin.css?ver=<?php echo G5_CSS_VER; ?>">
    <?php endif; ?>

    <!-- 6. 커스텀 CSS -->
    <!-- 레이아웃 핵심(렌더 차단 유지) -->
    <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/index.css">
    <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/header.css">
    <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/sub.css">
    <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/general.css">
     <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/smartsearch.css">
    <!-- [성능] 진료별 특화 CSS: 비동기 로드(렌더 비차단).
         사이트마다 사용 페이지가 달라 모두 유지하되, 첫 화면을 막지 않도록 onload로 적용.
         JS 미지원 환경 대비 <noscript> 폴백 포함. -->
    <?php
    $async_css = ['implant', 'natural', 'pain', 'simmi', 'orthodontics', 'children'];
    foreach ($async_css as $__css):
        $__href = G5_URL . '/css/' . $__css . '.css';
    ?>
    <link rel="stylesheet" href="<?php echo $__href; ?>" media="print" onload="this.media='all';this.onload=null;">
    <noscript><link rel="stylesheet" href="<?php echo $__href; ?>"></noscript>
    <?php endforeach; ?>
        <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/tail.css">
        <!-- [성능] 교보손글씨(2MB woff) → 손편지체 dynamic-subset 강제.
             각 사이트 sub.css의 .kyobo는 사이트마다 내용이 달라 직접 못 고치므로,
             공용 head에서 커스텀 CSS 전부 뒤에 오버라이드(동일 명시도+important, 나중 규칙 우선).
             → sub.css 무수정으로 전 사이트에 손편지체 적용, 교보는 호출 0 = 다운로드 0. -->
        <style>.kyobo{font-family:"NanumMiRaeNaMu"!important;}</style>
        <?php
        // [성능] 메인 배너 비디오 preload — 실제 비디오 파일이 있는 사이트에서만.
        // 공용 head라 비디오 안 쓰는 사이트(배경=이미지)에선 이 preload가
        // LCP 리소스보다 먼저 받아 렌더를 막는 부작용이 있어 조건부 처리.
        if (is_file(G5_PATH . '/images/pcvideo.mp4')):
        ?>
        <link rel="preload" as="video" href="/images/pcvideo.mp4">
        <?php endif; ?>

    <!-- ========================================== -->
    <!-- JS -->
    <!-- ========================================== -->
    <script src="<?php echo G5_JS_URL ?>/jquery-1.12.4.min.js"></script>
    <script src="<?php echo G5_JS_URL ?>/jquery-migrate-1.4.1.min.js"></script>
    <script src="/newjs/medi.js"></script>

    <!-- Bootstrap JS -->
    <!-- [defer] 독립 라이브러리 — 인라인 jQuery 의존 없음 -->
    <script defer src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI"
        crossorigin="anonymous"></script>

    <!-- ───────────────────────────────────────────────
         ⚠️ GSAP는 기본 주석처리됨(아래 GSAP 블록). 대체재 = library.js 모션엔진
            (reveal/stagger/parallax/.scroll-progress + count-up).
            GSAP가 필요한 페이지는 아래 GSAP 4줄 주석을 풀고, 본문 인라인 gsap.to를 살릴 것.
         ⚠️ AOS도 library.js로 대체 가능하나 호환 위해 살려둠. 신규/리뉴얼은 AOS 주석처리 + [library] 활성화 권장.
         ※ Swiper는 슬라이더 → library.js에 대체 기능 없음. 슬라이더 쓰면 유지.
         Swiper 는 defer 미적용 (의도적). 본문 인라인(new Swiper)이 직접 호출하므로
         defer 시 "not defined" 위험. 전환하려면 각 인라인을 DOMContentLoaded로 감싼 뒤 전수 테스트 필요.
    ─────────────────────────────────────────────── -->
    <!-- GSAP — [성능] 기본 주석처리(2026-06). GSAP 쓰는 페이지에서만 아래 4줄 주석을 풀 것.
         (또는 페이지별 $use_gsap 플래그로 조건 로드). 대체재=library.js 모션엔진. -->
    <!--
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollToPlugin.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/Flip.min.js"></script>
    -->

    <!-- Swiper -->
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

    <!-- AOS — [성능] defer 적용(렌더 차단 제거).
         본문 인라인의 AOS.init()은 typeof 가드가 있어 라이브러리보다 먼저 불려도 안 깨짐.
         단 그 경우 init이 누락될 수 있어, DOM 로드 완료 후 한 번 더 안전하게 init. -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
    window.addEventListener('DOMContentLoaded', function () {
        if (typeof AOS !== 'undefined') { AOS.init(); }
    });
    </script>

    <!-- [library] 바닐라 UI 번들 (라이브러리 0) — GSAP·AOS 대체용.
         모션엔진(data-reveal/data-stagger/data-count/data-parallax/.scroll-progress)
         + autovideo(카톡 인앱 poster 폴백) + before/after 슬라이더(.ba) 제공.
         CSS는 상단 [library] 블록과 세트로 함께 풀 것. defer라 jQuery 의존 없음.
         ※ 히어로/첫 섹션엔 data-reveal 빼기(LCP 영향). -->
    <!-- <script defer src="<?php echo G5_URL; ?>/library/library.js"></script> -->

    <!-- CKEditor — [성능] 에디터가 실제 뜨는 페이지에서만 로드(약 175KB 절감).
         글쓰기/수정/관리 경로 + 관리자에서만. 그 외(메인·진료·목록)에선 미로드.
         경로 패턴에 빠진 곳이 있으면 거기서 에디터가 안 뜨므로, 에디터 쓰는 경로는 아래에 추가. -->
    <?php
    $__uri_ck = $_SERVER['REQUEST_URI'] ?? '';
    $__need_ckeditor = defined('G5_IS_ADMIN')
        || preg_match('#(write|update|editor|modify|form|_form|column)#i', $__uri_ck);
    if ($__need_ckeditor):
    ?>
    <script defer src="https://cdn.ckeditor.com/ckeditor5/40.2.0/classic/ckeditor.js"></script>
    <?php endif; ?>

    <?php
    add_javascript('<script src="' . G5_JS_URL . '/common.js?ver=' . G5_JS_VER . '"></script>', 0);
    add_javascript('<script src="' . G5_JS_URL . '/wrest.js?ver='  . G5_JS_VER . '"></script>', 0);
    ?>

</head>

<body<?php echo isset($g5['body_script']) ? $g5['body_script'] : ''; ?>>
<?php if (!empty($cf_gtm_id)): ?>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=<?= htmlspecialchars($cf_gtm_id) ?>" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<?php endif; ?>