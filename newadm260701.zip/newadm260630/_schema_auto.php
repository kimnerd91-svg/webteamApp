<?php
/**
 * _schema_auto.php
 * dm_config 데이터를 기반으로 Schema.org JSON-LD를 자동 출력합니다.
 * 사용법: 사이트 <head> 안에서 include_once('_schema_auto.php'); 호출
 * 
 * 출력 스키마:
 *  - WebSite
 *  - LocalBusiness (주소/전화 있을 때) 또는 Organization
 */

if (!isset($dm_conf) || empty($dm_conf)) {
    // $dm_conf가 없을 경우 직접 조회
    if (function_exists('sql_fetch')) {
        $dm_conf = sql_fetch("SELECT * FROM dm_config WHERE cf_id = 1");
    }
}

if (empty($dm_conf)) return;

$site_url     = (!empty($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'];
$site_name    = !empty($dm_conf['cf_site_name'])    ? $dm_conf['cf_site_name']    : '';
$company_name = !empty($dm_conf['cf_company_name']) ? $dm_conf['cf_company_name'] : $site_name;
$description  = !empty($dm_conf['cf_description'])  ? $dm_conf['cf_description']  : '';
$tel          = !empty($dm_conf['cf_tel'])           ? $dm_conf['cf_tel']           : '';
$address      = !empty($dm_conf['cf_address'])       ? $dm_conf['cf_address']       : '';
$lat          = !empty($dm_conf['cf_lat'])           ? $dm_conf['cf_lat']           : '';
$lng          = !empty($dm_conf['cf_lng'])           ? $dm_conf['cf_lng']           : '';
$logo         = !empty($dm_conf['cf_logo'])          ? G5_DATA_URL . '/common/' . $dm_conf['cf_logo'] : '';
$instagram    = !empty($dm_conf['cf_instagram'])     ? $dm_conf['cf_instagram']     : '';
$blog         = !empty($dm_conf['cf_blog'])          ? $dm_conf['cf_blog']          : '';
$kakao        = !empty($dm_conf['cf_kakao'])         ? $dm_conf['cf_kakao']         : '';
$naver_talk   = !empty($dm_conf['cf_naver_talk'])    ? $dm_conf['cf_naver_talk']    : '';

// ─── WebSite 스키마 ────────────────────────────────────────
$website = [
    '@context' => 'https://schema.org',
    '@type'    => 'WebSite',
    'name'     => $site_name ?: $company_name,
    'url'      => $site_url,
];
if ($description) $website['description'] = $description;

// ─── LocalBusiness / Organization 스키마 ─────────────────
$has_local = $tel || $address;
$biz = [
    '@context' => 'https://schema.org',
    '@type'    => $has_local ? 'LocalBusiness' : 'Organization',
    'name'     => $company_name,
    'url'      => $site_url,
];
if ($description)  $biz['description'] = $description;
if ($tel)          $biz['telephone']   = $tel;
if ($logo)         $biz['logo']        = $logo;
if ($address) {
    $biz['address'] = [
        '@type'          => 'PostalAddress',
        'streetAddress'  => $address,
        'addressCountry' => 'KR',
    ];
}
if ($lat && $lng) {
    $biz['geo'] = [
        '@type'     => 'GeoCoordinates',
        'latitude'  => (float)$lat,
        'longitude' => (float)$lng,
    ];
}
$same_as = array_filter([$instagram, $blog, $kakao, $naver_talk], function($v) {
    return $v && $v !== '#' && strpos($v, 'http') === 0;
});
if ($same_as) $biz['sameAs'] = array_values($same_as);

// ─── 출력 ─────────────────────────────────────────────────
echo '<script type="application/ld+json">' . "\n";
echo json_encode($website, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
echo "\n</script>\n";

echo '<script type="application/ld+json">' . "\n";
echo json_encode($biz, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
echo "\n</script>\n";
