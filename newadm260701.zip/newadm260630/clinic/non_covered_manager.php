<?php
include_once('./_auth_check.php');   // clinic 게이트 (common.php 포함)
$is_admin = true;                    // 게이트 통과 = 관리 권한

$json_dir  = G5_DATA_PATH . '/content';
if (!is_dir($json_dir)) { @mkdir($json_dir, G5_DIR_PERMISSION); @chmod($json_dir, G5_DIR_PERMISSION); }
$json_file = $json_dir . '/non_covered.json';

if (isset($_POST['mode']) && $_POST['mode'] == 'update') {
    $data = json_decode(stripslashes($_POST['items_json']), true);
    if (!is_array($data)) $data = [];
    if (file_put_contents($json_file, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT))) {
        alert_toast('비급여 수가표가 저장되었습니다.', './non_covered_manager.php', 'success');
    } else {
        alert_toast('파일 저장에 실패했습니다. data 폴더의 쓰기 권한을 확인하세요.', 'error');
    }
}

$data_raw = file_exists($json_file) ? json_decode(file_get_contents($json_file), true) : [];
if (!is_array($data_raw)) $data_raw = [];
if (!empty($data_raw) && isset($data_raw[0]['name'])) $data_raw = [['category'=>'기본','items'=>$data_raw,'subcategories'=>[]]];
if (!empty($data_raw) && isset($data_raw[0]['category']) && !array_key_exists('subcategories', $data_raw[0])) {
    $data_raw = array_map(fn($c) => ['category'=>$c['category'],'items'=>[],'subcategories'=>[['subcategory'=>'기본','items'=>$c['items']??[]]]], $data_raw);
}
foreach ($data_raw as &$d) { if (!array_key_exists('items', $d)) $d['items'] = []; }
unset($d);
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>비급여 수가표 관리 · 병원 관리자</title>
<!-- xlsx/csv 파싱용. 서버에서 외부 CDN이 막혀 있으면 self-host 하세요. -->
<script src="https://cdn.sheetjs.com/xlsx-0.20.3/package/dist/xlsx.full.min.js"></script>
<style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Pretendard', 'Apple SD Gothic Neo', sans-serif; background: #f5f6fa; color: #1a1a2e; }
    #admin_wrapper { display: flex; min-height: 100vh; }
    .content_area { flex: 1; padding: 40px; overflow-x: hidden; }

    .page_header { margin-bottom: 28px; }
    .page_title  { font-size: 22px; font-weight: 700; color: #1a1a2e; }
    .page_sub    { font-size: 13px; color: #9999bb; margin-top: 4px; }

    .card { background: #fff; border-radius: 12px; box-shadow: 0 2px 12px rgba(0,0,0,0.06); border: 1px solid #e8eaf0; padding: 24px; margin-bottom: 20px; }
    .card_hd { display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px; }
    .card_title  { font-size: 15px; font-weight: 700; color: #1a1a2e; }

    .btn_major_add { padding: 9px 18px; background: #16a34a; color: #fff; border: none; border-radius: 8px; font-size: 13px; font-weight: 700; cursor: pointer; transition: all 0.2s; box-shadow: 0 4px 12px rgba(79,70,229,0.2); }
    .btn_major_add:hover { background: #15803d; }

    .table_wrap { overflow-x: auto; border: 1px solid #e8eaf0; border-radius: 10px; }
    #priceTable { width: 100%; border-collapse: collapse; min-width: 600px; }
    #priceTable th { background: #f5f6fa; padding: 12px 14px; font-size: 12px; font-weight: 700; color: #9999bb; text-align: center; border-bottom: 2px solid #e8eaf0; }
    #priceTable td { border: 1px solid #f5f6fa; vertical-align: middle; }

    .td-major { background: #dcfce7; font-weight: 800; font-size: 13px; text-align: center; padding: 10px 8px; min-width: 90px; color: #16a34a; }
    .td-minor { background: #f0fdf4; font-weight: 700; font-size: 12px; text-align: center; padding: 10px 8px; min-width: 90px; color: #166534; }
    .td-item  { padding: 8px 10px; }
    .td-action { background: #fafafa; padding: 7px 10px; }
    .td-center { text-align: center; }

    .inline-input { border: none; background: transparent; font-size: inherit; font-weight: inherit; color: inherit; text-align: center; width: 100%; padding: 2px 4px; border-bottom: 2px dashed #86efac; outline: none; }
    .inline-input:focus { border-bottom-color: #16a34a; background: #fff; border-radius: 4px; }

    .u-input { border: 1px solid #e8eaf0; border-radius: 7px; padding: 6px 10px; font-size: 13px; background: #f5f6fa; width: 100%; transition: all 0.2s; }
    .u-input:focus { outline: none; border-color: #16a34a; background: #fff; }

    .btn-add-inline { display: inline-flex; align-items: center; gap: 4px; border: 1px dashed #86efac; background: transparent; color: #166534; font-size: 12px; font-weight: 600; padding: 4px 10px; border-radius: 6px; cursor: pointer; white-space: nowrap; transition: all 0.2s; }
    .btn-add-inline:hover { border-color: #16a34a; color: #16a34a; background: #dcfce7; }
    .btn-add-inline.sub { border-color: #d1d5e0; color: #5c5c7a; }
    .btn-add-inline.sub:hover { border-color: #9999bb; background: #f5f6fa; color: #1a1a2e; }

    .btn-del { display: inline-flex; align-items: center; border: 1px solid #fca5a5; background: #fff; color: #ef4444; font-size: 12px; font-weight: 600; padding: 4px 10px; border-radius: 6px; cursor: pointer; white-space: nowrap; transition: all 0.2s; }
    .btn-del:hover { background: #ef4444; color: #fff; }

    .save_bar { display: flex; justify-content: flex-end; }
    .btn_save { padding: 13px 40px; background: #16a34a; color: #fff; border: none; border-radius: 9px; font-size: 15px; font-weight: 700; cursor: pointer; box-shadow: 0 4px 16px rgba(79,70,229,0.25); transition: all 0.2s; }
    .btn_save:hover { background: #15803d; transform: translateY(-1px); }

    /* ===== 엑셀 가져오기 ===== */
    .import-tabs { display: flex; gap: 8px; margin-bottom: 16px; }
    .imp-tab { padding: 8px 16px; border: 1px solid #e8eaf0; background: #f5f6fa; color: #5c5c7a; border-radius: 8px; font-size: 13px; font-weight: 700; cursor: pointer; transition: all 0.2s; }
    .imp-tab.active { background: #dcfce7; border-color: #86efac; color: #16a34a; }
    .imp-help { font-size: 12px; color: #9999bb; margin-bottom: 10px; line-height: 1.6; }
    .paste-area { width: 100%; min-height: 130px; border: 1px solid #e8eaf0; border-radius: 9px; padding: 12px 14px; font-size: 13px; font-family: 'D2Coding','Consolas',monospace; background: #f5f6fa; resize: vertical; outline: none; white-space: pre; overflow: auto; }
    .paste-area:focus { border-color: #16a34a; background: #fff; }
    #fileInput { font-size: 13px; }
    .btn-imp { margin-top: 12px; padding: 9px 20px; background: #16a34a; color: #fff; border: none; border-radius: 8px; font-size: 13px; font-weight: 700; cursor: pointer; transition: all 0.2s; }
    .btn-imp:hover { background: #15803d; }
    .btn-imp.ghost { background: #fff; color: #5c5c7a; border: 1px solid #e8eaf0; }
    .btn-imp.ghost:hover { background: #f5f6fa; color: #1a1a2e; }

    .prev-card { margin-top: 18px; border: 1px solid #e8eaf0; border-radius: 10px; padding: 18px; background: #fcfcff; }
    .hd-check { display: inline-flex; align-items: center; gap: 6px; font-size: 13px; font-weight: 600; color: #5c5c7a; margin-bottom: 14px; cursor: pointer; }
    .map-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(130px,1fr)); gap: 10px; margin-bottom: 16px; }
    .map-cell { display: flex; flex-direction: column; gap: 5px; font-size: 12px; font-weight: 700; color: #166534; }
    .map-cell select { padding: 7px 9px; border: 1px solid #e8eaf0; border-radius: 7px; font-size: 13px; background: #fff; color: #1a1a2e; font-weight: 500; outline: none; }
    .map-cell select:focus { border-color: #16a34a; }
    .prev-wrap { overflow-x: auto; border: 1px solid #e8eaf0; border-radius: 8px; margin-bottom: 6px; }
    .prev-tbl { border-collapse: collapse; width: 100%; min-width: 480px; }
    .prev-tbl td { border: 1px solid #eef0f6; padding: 6px 10px; font-size: 12px; color: #444; white-space: nowrap; max-width: 220px; overflow: hidden; text-overflow: ellipsis; }
    .prev-tbl tr.prev-head td { background: #dcfce7; font-weight: 700; color: #16a34a; }
    .imp-actions { display: flex; gap: 8px; margin-top: 16px; }
</style>
    <?php include_once('./_theme.php'); ?>
</head>
<body>
<div id="admin_wrapper">
    <?php include_once('./aside.php'); ?>

    <main class="content_area">
        <div class="page_header">
            <h2 class="page_title">비급여 수가표 관리</h2>
            <p class="page_sub">엑셀에서 가져오거나 직접 입력할 수 있습니다. 대분류 필수 / 소분류는 선택.</p>
        </div>

        <!-- ===== 엑셀 가져오기 ===== -->
        <div class="card">
            <div class="card_hd">
                <p class="card_title">엑셀에서 가져오기</p>
            </div>
            <div class="import-tabs">
                <button type="button" class="imp-tab active" data-tab="paste" onclick="impTab('paste')">붙여넣기</button>
                <button type="button" class="imp-tab" data-tab="file" onclick="impTab('file')">파일 업로드 (.xlsx / .csv)</button>
            </div>

            <div id="imp_paste" class="imp-pane">
                <p class="imp-help">엑셀·구글시트에서 표 영역을 드래그해 복사(Ctrl+C)한 뒤, 아래 칸을 클릭하고 붙여넣기(Ctrl+V) 하세요.</p>
                <textarea id="pasteArea" class="paste-area" placeholder="여기에 붙여넣기 (Ctrl+V) ..."></textarea>
                <br>
                <button type="button" class="btn-imp" onclick="doPaste()">미리보기 / 변환</button>
            </div>

            <div id="imp_file" class="imp-pane" style="display:none;">
                <p class="imp-help">.xlsx, .xls, .csv 파일을 선택하세요. (첫 번째 시트를 읽습니다)</p>
                <input type="file" id="fileInput" accept=".xlsx,.xls,.csv" onchange="doFile(this)">
            </div>

            <div id="imp_preview" style="display:none;"></div>
        </div>

        <form method="post" id="priceForm" onsubmit="return preSave()">
            <input type="hidden" name="mode" value="update">
            <input type="hidden" name="items_json" id="items_json">

            <div class="card">
                <div class="card_hd">
                    <p class="card_title">수가표 항목 관리</p>
                    <button type="button" onclick="addMajor()" class="btn_major_add">+ 대분류 추가</button>
                </div>
                <div class="table_wrap">
                    <table id="priceTable">
                        <thead>
                            <tr>
                                <th style="width:12%;">대분류</th>
                                <th style="width:12%;">소분류</th>
                                <th style="width:28%;">항목명</th>
                                <th style="width:17%;">가격 (원)</th>
                                <th style="width:19%;">비고</th>
                                <th style="width:12%;">삭제</th>
                            </tr>
                        </thead>
                        <tbody id="priceBody"></tbody>
                    </table>
                </div>
            </div>

            <div class="save_bar">
                <button type="submit" class="btn_save">수가표 저장</button>
            </div>
        </form>
    </main>
</div>

<script>
let D = <?= json_encode($data_raw) ?>;

/* ===================== 기존 렌더링/편집 ===================== */
function render() {
    const tbody = document.getElementById('priceBody');
    tbody.innerHTML = '';
    if (!D.length) {
        const tr=mktr(); const td=mktd(); td.colSpan=6; td.style.cssText='text-align:center;padding:48px;color:#9999bb;font-size:13px;';
        td.textContent='우측 상단 "대분류 추가" 버튼 또는 위 "엑셀에서 가져오기"로 시작하세요.'; tr.appendChild(td); tbody.appendChild(tr); return;
    }
    D.forEach((major, mi) => {
        const subs=major.subcategories||[]; const hasSub=subs.length>0; const directItems=major.items||[];
        let majorSpan;
        if (!hasSub) majorSpan=Math.max(directItems.length,1)+1;
        else majorSpan=subs.reduce((acc,s)=>acc+Math.max((s.items||[]).length,1)+1,0)+1;
        let firstMajor=true;
        function getMajorTd() {
            if (!firstMajor) return null; firstMajor=false;
            const td=mktd('td-major'); td.rowSpan=majorSpan;
            td.appendChild(mkInlineInput(major.category,'대분류명',`D[${mi}].category=this.value`)); return td;
        }
        if (!hasSub) {
            if (!directItems.length) {
                const tr=mktr(); appendIf(tr,getMajorTd());
                const tdE=mktd('td-item'); tdE.colSpan=4; tdE.style.cssText='text-align:center;color:#9999bb;font-size:12px;'; tdE.textContent='항목을 추가하세요.';
                tr.appendChild(tdE); tr.appendChild(mktd('td-item')); tbody.appendChild(tr);
            } else {
                directItems.forEach((item,ii)=>{
                    const tr=mktr(); appendIf(tr,getMajorTd());
                    const tdN=mktd('td-item'); tdN.colSpan=2; tdN.appendChild(mkFieldInput(item.name,'예: 임플란트',`D[${mi}].items[${ii}].name=this.value`)); tr.appendChild(tdN);
                    const tdP=mktd('td-item'); tdP.appendChild(mkFieldInput(item.price,'예: 1,500,000',`D[${mi}].items[${ii}].price=this.value`)); tr.appendChild(tdP);
                    const tdNo=mktd('td-item'); tdNo.appendChild(mkFieldInput(item.note,'비고',`D[${mi}].items[${ii}].note=this.value`)); tr.appendChild(tdNo);
                    const tdD=mktd('td-item td-center'); tdD.appendChild(mkDelBtn(`delDirectItem(${mi},${ii})`,'삭제')); tr.appendChild(tdD);
                    tbody.appendChild(tr);
                });
            }
            const trA=mktr(); const tdA=mktd('td-action'); tdA.colSpan=4;
            tdA.appendChild(mkAddBtn(`addDirectItem(${mi})`,'항목 추가'));
            const btnS=mkBtn('btn-add-inline sub',`addFirstSub(${mi})`,'소분류 추가'); btnS.style.marginLeft='8px'; tdA.appendChild(btnS);
            trA.appendChild(tdA);
            const tdDA=mktd('td-action td-center'); tdDA.appendChild(mkDelBtn(`delMajor(${mi})`,'대분류 삭제')); trA.appendChild(tdDA);
            tbody.appendChild(trA);
        } else {
            subs.forEach((sub,si)=>{
                const items=sub.items||[]; const subSpan=Math.max(items.length,1)+1; let firstSub=true;
                function getSubTd() {
                    if (!firstSub) return null; firstSub=false;
                    const td=mktd('td-minor'); td.rowSpan=subSpan;
                    td.appendChild(mkInlineInput(sub.subcategory,'소분류명',`D[${mi}].subcategories[${si}].subcategory=this.value`)); return td;
                }
                if (!items.length) {
                    const tr=mktr(); appendIf(tr,getMajorTd()); appendIf(tr,getSubTd());
                    const tdE=mktd('td-item'); tdE.colSpan=3; tdE.style.cssText='text-align:center;color:#9999bb;font-size:12px;'; tdE.textContent='항목을 추가하세요.';
                    tr.appendChild(tdE);
                    const tdD=mktd('td-item td-center'); tdD.appendChild(mkDelBtn(`delSub(${mi},${si})`,'삭제')); tr.appendChild(tdD);
                    tbody.appendChild(tr);
                } else {
                    items.forEach((item,ii)=>{
                        const tr=mktr(); appendIf(tr,getMajorTd()); appendIf(tr,getSubTd());
                        const tdN=mktd('td-item'); tdN.appendChild(mkFieldInput(item.name,'예: 임플란트',`D[${mi}].subcategories[${si}].items[${ii}].name=this.value`)); tr.appendChild(tdN);
                        const tdP=mktd('td-item'); tdP.appendChild(mkFieldInput(item.price,'예: 1,500,000',`D[${mi}].subcategories[${si}].items[${ii}].price=this.value`)); tr.appendChild(tdP);
                        const tdNo=mktd('td-item'); tdNo.appendChild(mkFieldInput(item.note,'비고',`D[${mi}].subcategories[${si}].items[${ii}].note=this.value`)); tr.appendChild(tdNo);
                        const tdD=mktd('td-item td-center'); tdD.appendChild(mkDelBtn(`delItem(${mi},${si},${ii})`,'삭제')); tr.appendChild(tdD);
                        tbody.appendChild(tr);
                    });
                }
                const trS=mktr(); appendIf(trS,getMajorTd());
                const tdS=mktd('td-action'); tdS.colSpan=4; tdS.appendChild(mkAddBtn(`addItem(${mi},${si})`,'항목 추가'));
                const dB=mkDelBtn(`delSub(${mi},${si})`,'소분류 삭제'); dB.style.marginLeft='8px'; tdS.appendChild(dB);
                trS.appendChild(tdS); trS.appendChild(mktd('td-action')); tbody.appendChild(trS);
            });
            const trA=mktr(); const tdA=mktd('td-action'); tdA.colSpan=5; tdA.appendChild(mkAddBtn(`addSub(${mi})`,'소분류 추가')); trA.appendChild(tdA);
            const tdD=mktd('td-action td-center'); tdD.appendChild(mkDelBtn(`delMajor(${mi})`,'대분류 삭제')); trA.appendChild(tdD);
            tbody.appendChild(trA);
        }
    });
}

function mktr(cls) { const t=document.createElement('tr'); if(cls) t.className=cls; return t; }
function mktd(cls) { const t=document.createElement('td'); if(cls) t.className=cls; return t; }
function appendIf(p,c) { if(c) p.appendChild(c); }
function mkInlineInput(val,ph,onchange) { const i=document.createElement('input'); i.className='inline-input'; i.value=val||''; i.placeholder=ph; i.setAttribute('onchange',onchange); return i; }
function mkFieldInput(val,ph,onchange) { const i=document.createElement('input'); i.className='u-input'; i.value=val||''; i.placeholder=ph; i.setAttribute('onchange',onchange); return i; }
function mkBtn(cls,onclick,html) { const b=document.createElement('button'); b.type='button'; b.className=cls; b.setAttribute('onclick',onclick); b.innerHTML=html; return b; }
function mkAddBtn(onclick,label) { return mkBtn('btn-add-inline',onclick,`<span style="font-size:13px;font-weight:700;">+</span> ${label}`); }
function mkDelBtn(onclick,label) { return mkBtn('btn-del',onclick,label); }

function addMajor() { D.push({category:'',items:[],subcategories:[]}); render(); }
function delMajor(mi) { if(confirm(`"${D[mi].category||'대분류'}" 전체를 삭제?`)) { D.splice(mi,1); render(); } }
function addDirectItem(mi) { D[mi].items.push({name:'',price:'',note:''}); render(); }
function delDirectItem(mi,ii) { if(confirm('항목을 삭제?')) { D[mi].items.splice(ii,1); render(); } }
function addFirstSub(mi) { const e=D[mi].items||[]; D[mi].subcategories.push({subcategory:'',items:e}); D[mi].items=[]; render(); }
function addSub(mi) { D[mi].subcategories.push({subcategory:'',items:[]}); render(); }
function delSub(mi,si) { if(confirm(`"${D[mi].subcategories[si].subcategory||'소분류'}"를 삭제?`)) { D[mi].subcategories.splice(si,1); if(!D[mi].subcategories.length) D[mi].items=[]; render(); } }
function addItem(mi,si) { D[mi].subcategories[si].items.push({name:'',price:'',note:''}); render(); }
function delItem(mi,si,ii) { if(confirm('항목을 삭제?')) { D[mi].subcategories[si].items.splice(ii,1); render(); } }
function preSave() { document.getElementById('items_json').value=JSON.stringify(D); return true; }

/* ===================== 엑셀 가져오기 ===================== */
let IMP = { rows: [], cols: 0 };

const KW = {
    cat:  ['대분류','분류','카테고리','구분','진료과목','과목','파트','part'],
    sub:  ['소분류','중분류','세부','종류','상세'],
    name: ['항목','내용','시술','진료명','명칭','품목','치료','서비스'],
    price:['가격','금액','수가','비용','요금','단가','진료비','price'],
    note: ['비고','메모','참고','설명','특이','기타']
};

function impTab(t) {
    document.querySelectorAll('.imp-tab').forEach(b=>b.classList.toggle('active', b.dataset.tab===t));
    document.getElementById('imp_paste').style.display = (t==='paste') ? 'block' : 'none';
    document.getElementById('imp_file').style.display  = (t==='file')  ? 'block' : 'none';
}

function esc(s) { return String(s).replace(/[&<>"]/g, m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m])); }

/* 붙여넣기(TSV) → 행렬 */
function parseClipboard(text) {
    text = String(text).replace(/\r\n?/g,'\n').replace(/\n+$/,'');
    if (!text.trim()) return [];
    const lines = text.split('\n');
    const hasTab = lines.some(l=>l.includes('\t'));
    if (hasTab) return lines.map(l=>l.split('\t'));
    // 탭이 없으면 CSV로 간주 (SheetJS 사용)
    if (typeof XLSX === 'undefined') { return lines.map(l=>l.split(',')); }
    const wb = XLSX.read(text, {type:'string'});
    return XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], {header:1, defval:''});
}

function doPaste() {
    const rows = parseClipboard(document.getElementById('pasteArea').value);
    if (!rows.length) { alert('붙여넣은 내용이 없습니다.'); return; }
    showPreview(rows.map(r=>r.map(c=>c==null?'':String(c))));
}

/* 파일(.xlsx/.csv) → 행렬 */
function doFile(input) {
    const file = input.files && input.files[0];
    if (!file) return;
    if (typeof XLSX === 'undefined') {
        alert('xlsx 라이브러리를 불러오지 못했습니다.\n외부 CDN이 차단된 환경이면 SheetJS를 서버에 직접 올려 주세요.\n(붙여넣기 방식은 라이브러리 없이도 동작합니다)');
        input.value=''; return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
        try {
            const wb = XLSX.read(new Uint8Array(e.target.result), {type:'array'});
            const sheet = wb.Sheets[wb.SheetNames[0]];
            const rows = XLSX.utils.sheet_to_json(sheet, {header:1, defval:''});
            const norm = rows.map(r=>(r||[]).map(c=>c==null?'':String(c)));
            if (!norm.length) { alert('읽을 데이터가 없습니다.'); return; }
            showPreview(norm);
        } catch (err) {
            alert('파일을 읽지 못했습니다: ' + err.message);
        } finally {
            input.value='';
        }
    };
    reader.readAsArrayBuffer(file);
}

/* 첫 행이 머리글인지 추정 */
function detectHeader(row) {
    if (!row) return false;
    const joined = row.map(c=>String(c||'')).join(' ');
    return Object.values(KW).some(arr=>arr.some(k=>joined.includes(k)));
}

/* 열 매핑 추정 */
function guessMapping(header) {
    const cols = IMP.cols, rows = IMP.rows;
    const g = {cat:-1, sub:-1, name:-1, price:-1, note:-1};
    if (header) {
        const h = (rows[0]||[]).map(c=>String(c||'').trim());
        for (const role in KW) {
            for (let i=0; i<cols; i++) {
                if (g[role]<0 && KW[role].some(k=>h[i] && h[i].includes(k))) g[role]=i;
            }
        }
    }
    const used = () => Object.values(g).filter(v=>v>=0);
    // 가격: 숫자 비중이 높은 열 자동 추정
    if (g.price<0) {
        for (let i=cols-1; i>=0; i--) {
            if (used().includes(i)) continue;
            const sample = rows.slice(header?1:0).map(r=>String(r[i]||'').trim()).filter(x=>x!=='');
            if (!sample.length) continue;
            const num = sample.filter(x=>/\d/.test(x) && /^[₩\s]*[\d][\d,\.~\-원만천백 ]*$/.test(x)).length;
            if (num/sample.length > 0.5) { g.price=i; break; }
        }
    }
    // 항목명: 비어있으면 사용되지 않은 첫 번째 열
    if (g.name<0) {
        for (let i=0; i<cols; i++) { if (!used().includes(i)) { g.name=i; break; } }
    }
    return g;
}

function showPreview(rows) {
    rows = rows.filter(r=>r.some(c=>String(c).trim()!==''));
    if (!rows.length) { alert('데이터가 없습니다.'); return; }
    IMP = { rows: rows, cols: Math.max(...rows.map(r=>r.length)) };
    renderPreview(detectHeader(rows[0]));
    document.getElementById('imp_preview').scrollIntoView({behavior:'smooth', block:'nearest'});
}

function renderPreview(header) {
    const cols = IMP.cols, rows = IMP.rows;
    const g = guessMapping(header);

    function colOpts(sel) {
        let o = '<option value="-1"'+(sel===-1?' selected':'')+'>(없음)</option>';
        for (let i=0; i<cols; i++) {
            const label = header ? (String(rows[0][i]||'').trim() || ('열 '+(i+1))) : ('열 '+(i+1));
            o += '<option value="'+i+'"'+(sel===i?' selected':'')+'>'+esc(label)+'</option>';
        }
        return o;
    }

    const roles = [['cat','대분류'],['sub','소분류'],['name','항목명'],['price','가격'],['note','비고']];
    let mapHtml = '<div class="map-grid">';
    roles.forEach(([k,lbl]) => {
        mapHtml += '<label class="map-cell"><span>'+lbl+'</span><select id="map_'+k+'">'+colOpts(g[k])+'</select></label>';
    });
    mapHtml += '</div>';

    const show = rows.slice(0, 9);
    let tbl = '<div class="prev-wrap"><table class="prev-tbl"><tbody>';
    show.forEach((r,ri) => {
        tbl += '<tr'+((header && ri===0) ? ' class="prev-head"' : '')+'>';
        for (let i=0; i<cols; i++) tbl += '<td>'+esc(String(r[i]??''))+'</td>';
        tbl += '</tr>';
    });
    tbl += '</tbody></table></div>';
    const more = rows.length>9 ? '<p class="imp-help">… 외 '+(rows.length-9)+'행</p>' : '';

    document.getElementById('imp_preview').innerHTML =
        '<div class="prev-card">'
      + '<label class="hd-check"><input type="checkbox" id="hasHeader" '+(header?'checked':'')+' onchange="reGuess()"> 첫 행을 머리글(제목)로 사용</label>'
      + mapHtml
      + tbl + more
      + '<div class="imp-actions">'
      +   '<button type="button" class="btn-imp" onclick="applyImport(false)">기존 표에 추가</button>'
      +   '<button type="button" class="btn-imp ghost" onclick="applyImport(true)">표 전체 교체</button>'
      +   '<button type="button" class="btn-imp ghost" onclick="cancelImport()">취소</button>'
      + '</div></div>';
    document.getElementById('imp_preview').style.display='block';
}

function reGuess() { renderPreview(document.getElementById('hasHeader').checked); }

/* 행렬 → D 구조 (병합셀 fill-down 처리) */
function buildFromRows(rows, map, hasHeader) {
    const data = hasHeader ? rows.slice(1) : rows;
    const get = (r, idx) => (idx>=0 && idx<r.length) ? String(r[idx]==null?'':r[idx]).trim() : '';
    let lastCat='', lastSub='';
    const cats = []; const catIdx = {};
    function cat(name) {
        if (!(name in catIdx)) { catIdx[name]=cats.length; cats.push({category:name, _rows:[]}); }
        return cats[catIdx[name]];
    }
    data.forEach(r => {
        let c = get(r, map.cat);
        let s = get(r, map.sub);
        const nm = get(r, map.name);
        const pr = get(r, map.price);
        const nt = get(r, map.note);
        if (c) { lastCat=c; lastSub=''; } else { c=lastCat; }   // 대분류 fill-down (바뀌면 소분류 초기화)
        if (s) { lastSub=s; } else { s=lastSub; }               // 소분류 fill-down
        if (!nm && !pr) return;                                 // 항목/가격 둘 다 없으면 건너뜀
        if (!c) c='기타';
        cat(c)._rows.push({sub:s, name:nm, price:pr, note:nt});
    });
    return cats.map(co => {
        const anySub = co._rows.some(r=>r.sub);
        if (!anySub) {
            return { category:co.category, items:co._rows.map(r=>({name:r.name,price:r.price,note:r.note})), subcategories:[] };
        }
        const subs=[]; const sIdx={};
        co._rows.forEach(r => {
            const sn = r.sub || '기본';
            if (!(sn in sIdx)) { sIdx[sn]=subs.length; subs.push({subcategory:sn, items:[]}); }
            subs[sIdx[sn]].items.push({name:r.name, price:r.price, note:r.note});
        });
        return { category:co.category, items:[], subcategories:subs };
    });
}

function applyImport(replace) {
    const header = document.getElementById('hasHeader').checked;
    const map = {
        cat:   parseInt(document.getElementById('map_cat').value, 10),
        sub:   parseInt(document.getElementById('map_sub').value, 10),
        name:  parseInt(document.getElementById('map_name').value, 10),
        price: parseInt(document.getElementById('map_price').value, 10),
        note:  parseInt(document.getElementById('map_note').value, 10)
    };
    if (map.name<0 && map.price<0) { alert('최소한 "항목명" 또는 "가격" 열은 지정해야 합니다.'); return; }
    const built = buildFromRows(IMP.rows, map, header);
    if (!built.length) { alert('변환된 항목이 없습니다. 열 매핑을 확인하세요.'); return; }

    const itemCnt = built.reduce((a,c)=>a + (c.items?c.items.length:0) + (c.subcategories||[]).reduce((b,s)=>b+(s.items?s.items.length:0),0), 0);

    if (replace) {
        if (D.length && !confirm('기존 표를 모두 지우고 새로 가져온 '+built.length+'개 대분류 / '+itemCnt+'개 항목으로 교체할까요?')) return;
        D = built;
    } else {
        if (!confirm('가져온 '+built.length+'개 대분류 / '+itemCnt+'개 항목을 기존 표에 추가할까요?')) return;
        D = D.concat(built);
    }
    render();
    cancelImport();
    document.getElementById('priceTable').scrollIntoView({behavior:'smooth', block:'start'});
}

function cancelImport() {
    const p = document.getElementById('imp_preview');
    p.style.display='none'; p.innerHTML='';
    document.getElementById('pasteArea').value='';
    const fi = document.getElementById('fileInput'); if (fi) fi.value='';
    IMP = { rows: [], cols: 0 };
}

window.onload = render;
</script>
</body>
</html>