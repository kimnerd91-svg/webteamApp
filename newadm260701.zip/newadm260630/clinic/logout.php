<?php
/**
 * /clinic/logout.php — 병원용 관리자 로그아웃
 * - clinic 자동로그인 쿠키(clinic_auto_login) + mb_memo 토큰 정리
 * - 세션 완전 파기 후 사이트 메인(/)으로 이동
 */
include_once($_SERVER['DOCUMENT_ROOT'] . '/common.php');

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// 자동 로그인 토큰 삭제 (DB + 쿠키) — clinic 전용 쿠키명
if (isset($_COOKIE['clinic_auto_login'])) {
    $token = sql_real_escape_string($_COOKIE['clinic_auto_login']);
    sql_query("UPDATE {$g5['member_table']} SET mb_memo = '' WHERE mb_memo = '{$token}'");
    setcookie('clinic_auto_login', '', time() - 3600, '/');
}

// 관리자/그누보드 세션 변수 개별 제거
unset($_SESSION['ss_mb_id']);
unset($_SESSION['adm_mb_id']);
unset($_SESSION['adm_mb_name']);
unset($_SESSION['adm_login_time']);

// ★ 세션 전체 비우기 + 세션 쿠키 제거 + 파기 (확실한 로그아웃)
$_SESSION = array();
if (ini_get('session.use_cookies')) {
    $p = session_get_cookie_params();
    setcookie(
        session_name(), '', time() - 42000,
        ($p['path'] ?: '/'), $p['domain'], $p['secure'], $p['httponly']
    );
}
session_destroy();
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>로그아웃</title>
    <style>
        body { margin:0; padding:0; background:#f5f6fa;
               font-family:'Pretendard','Apple SD Gothic Neo',-apple-system,BlinkMacSystemFont,sans-serif; }
        .toast-message {
            position:fixed; top:50%; left:50%; transform:translate(-50%,-50%);
            background:#16a34a; color:#fff; padding:18px 38px; border-radius:14px;
            font-size:15px; font-weight:700; box-shadow:0 12px 32px rgba(22,163,74,.25);
            z-index:9999; opacity:0; transition:opacity .3s ease;
            display:flex; align-items:center; gap:9px;
        }
        .toast-message.show { opacity:1; }
        .toast-message .dot { font-size:18px; }
    </style>
</head>
<body>
    <div id="toast" class="toast-message"><span class="dot">✓</span>로그아웃 되었습니다.</div>
    <script>
        const toast = document.getElementById('toast');
        setTimeout(() => { toast.classList.add('show'); }, 100);
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => { location.replace('/'); }, 300);
        }, 1400);
    </script>
</body>
</html>