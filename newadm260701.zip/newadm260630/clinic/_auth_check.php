<?php
/**
 * 병원용 관리자(/clinic) 인증 게이트
 * - 모든 clinic 페이지 상단에 include
 * - 허용: 병원계정(mb_is_clinic=1) 또는 최고관리자(Lv10, is_clinic=0)
 */
ini_set('session.gc_maxlifetime', 86400);
ini_set('session.cookie_lifetime', 86400);

// 그누보드 공통 로드 (DB·헬퍼)
include_once($_SERVER['DOCUMENT_ROOT'] . '/common.php');

// 캐시 방지
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");

// 병원계정 플래그 컬럼 보장 (세션당 1회)
if (empty($_SESSION['_clinic_col_ok'])) {
    sql_query("ALTER TABLE {$g5['member_table']} ADD COLUMN IF NOT EXISTS `mb_is_clinic` TINYINT(1) NOT NULL DEFAULT 0", false);
    $_SESSION['_clinic_col_ok'] = 1;
}

// 로그인 체크
if (!isset($_SESSION['adm_mb_id']) || !$_SESSION['adm_mb_id']) {
    echo "<script>alert('로그인이 필요합니다.'); location.href='/clinic/login.php';</script>";
    exit;
}

// 권한 재검증
$adm_sql = "SELECT mb_id, mb_name, mb_level, mb_is_clinic FROM {$g5['member_table']} WHERE mb_id = '".sql_real_escape_string($_SESSION['adm_mb_id'])."'";
$clinic_member = sql_fetch($adm_sql);

$is_clinic_user = !empty($clinic_member['mb_is_clinic']);
$is_super       = ($clinic_member['mb_level'] >= 10 && !$is_clinic_user);

// 병원계정도 아니고 최고관리자도 아니면 차단
if (!$clinic_member['mb_id'] || (!$is_clinic_user && !$is_super)) {
    unset($_SESSION['adm_mb_id'], $_SESSION['adm_mb_name'], $_SESSION['adm_login_time']);
    echo "<script>alert('접근 권한이 없습니다.'); location.href='/clinic/login.php';</script>";
    exit;
}

// 그누보드 세션 변수 설정
$_SESSION['ss_mb_id'] = $_SESSION['adm_mb_id'];
$member = $clinic_member;

// 편의 플래그: clinic 페이지에서 형님(super)인지 병원인지 구분용
$CLINIC_IS_SUPER = $is_super;
?>
