<?php
/**
 * 병원용 관리자(/clinic) 공통 디자인 토큰 + 컴포넌트 스타일
 * - clinic/index.php 의 가벼운 화이트 박스 톤을 기준
 * - 사이드바 = index 메뉴카드처럼 좌측 박스 스택 (다크 사이드바 아님)
 * - 포인트 컬러만 그린(#16a34a). 나머지는 index 중립 팔레트(#e8eaf0/#9999bb/#1a1a2e)
 * - 각 매니저 <head> 안에서 include:  include_once('./_theme.php');
 */
?>
<style id="clinic-theme">
:root{
  --c-main:#16a34a; --c-main-d:#15803d; --c-main-dd:#166534;
  --c-main-l:#dcfce7; --c-main-xl:#f0fdf4;
  --bg:#f5f6fa; --card:#fff; --border:#e8eaf0; --line:#f5f6fa;
  --text:#444466; --strong:#1a1a2e; --muted:#9999bb;
  --point:#FABE00; --danger:#dc2626; --danger-l:#fee2e2;
  --radius:14px; --shadow:0 2px 12px rgba(0,0,0,.06);
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'Pretendard','Apple SD Gothic Neo',sans-serif;background:var(--bg);color:var(--text);-webkit-font-smoothing:antialiased;}

#clinic_wrap,#admin_wrapper{display:flex;min-height:100vh;}
.content_area{flex:1;padding:40px 44px;overflow-x:hidden;min-width:0;}

/* ── 좌측 박스형 사이드바 (index 톤) ── */
.clinic_aside{width:224px;flex-shrink:0;padding:34px 16px 30px 28px;display:flex;flex-direction:column;gap:18px;position:sticky;top:0;align-self:flex-start;}
.ca_brand{padding:0 6px;}
.ca_brand .logo{font-size:12px;font-weight:800;letter-spacing:2px;color:var(--c-main);}
.ca_brand .who{margin-top:8px;font-size:17px;font-weight:800;color:var(--strong);line-height:1.3;}
.ca_brand .role{display:inline-block;margin-top:9px;font-size:11px;font-weight:700;padding:3px 10px;border-radius:20px;background:var(--c-main-l);color:var(--c-main-dd);}
.ca_nav{display:flex;flex-direction:column;gap:10px;}
.ca_nav a{display:flex;align-items:center;gap:11px;background:#fff;border:1px solid var(--border);border-radius:13px;padding:14px 15px;color:var(--strong);text-decoration:none;font-size:14px;font-weight:700;transition:box-shadow .15s,transform .05s,border-color .15s,background .15s;}
.ca_nav a .emo{font-size:20px;width:24px;text-align:center;}
.ca_nav a:hover{box-shadow:0 6px 18px rgba(0,0,0,.07);transform:translateY(-2px);border-color:#d6f0df;}
.ca_nav a.on{border-color:var(--c-main);background:var(--c-main-xl);color:var(--c-main-dd);box-shadow:0 4px 14px rgba(22,163,74,.12);}
.ca_nav a .nbadge{margin-left:auto;background:var(--point);color:#3a2d00;font-size:11px;font-weight:800;min-width:20px;height:20px;border-radius:20px;display:flex;align-items:center;justify-content:center;padding:0 6px;}
.ca_nav a.on .nbadge{background:var(--danger);color:#fff;}
.ca_foot{display:flex;flex-direction:column;gap:9px;padding:6px 6px 0;}
.ca_foot a{font-size:12.5px;color:var(--muted);text-decoration:none;}
.ca_foot a:hover{color:var(--c-main-d);}

/* ── header ── */
.page_header{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:14px;margin-bottom:24px;}
.page_title{font-size:24px;font-weight:800;color:var(--strong);}
.page_title small{display:block;font-size:13px;font-weight:600;color:var(--muted);margin-top:5px;}

/* ── buttons ── */
.c-btn{height:40px;padding:0 16px;border-radius:10px;font-size:13px;font-weight:700;cursor:pointer;border:1px solid var(--border);background:#fff;color:var(--text);transition:all .15s;display:inline-flex;align-items:center;gap:6px;text-decoration:none;}
.c-btn:hover{box-shadow:0 4px 14px rgba(0,0,0,.06);}
.c-btn-pri{background:var(--c-main);border-color:var(--c-main);color:#fff;}
.c-btn-pri:hover{background:var(--c-main-d);box-shadow:0 4px 14px rgba(22,163,74,.18);}
.c-btn-danger{color:#b91c1c;}
.c-btn-danger:hover{background:var(--danger-l);border-color:#fca5a5;color:var(--danger);box-shadow:none;}
.c-btn-sm{height:34px;padding:0 13px;font-size:12px;}

/* ── inputs ── */
.search_form{display:flex;gap:8px;flex-wrap:wrap;}
.search_input{height:40px;width:240px;border:1px solid var(--border);border-radius:10px;padding:0 14px;font-size:13px;background:#fff;transition:all .2s;}
.search_input:focus{outline:none;border-color:var(--c-main);box-shadow:0 0 0 3px rgba(22,163,74,.12);}
.filter_bar{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:16px;}
.f_sel,.f_date{height:40px;border:1px solid var(--border);border-radius:10px;padding:0 12px;font-size:13px;background:#fff;color:var(--text);font-family:inherit;}
.f_sel:focus,.f_date:focus{outline:none;border-color:var(--c-main);box-shadow:0 0 0 3px rgba(22,163,74,.12);}

/* ── stat cards (index 메뉴카드 톤) ── */
.stat_row{display:grid;grid-template-columns:repeat(auto-fit,minmax(132px,1fr));gap:14px;margin-bottom:22px;}
.stat{background:#fff;border:1px solid var(--border);border-radius:var(--radius);padding:18px 20px;transition:box-shadow .15s,transform .05s;}
.stat:hover{box-shadow:0 6px 20px rgba(0,0,0,.07);transform:translateY(-2px);}
.stat .n{font-size:26px;font-weight:800;color:var(--strong);}
.stat .l{font-size:12px;color:var(--muted);font-weight:600;margin-top:4px;}
.stat.hl{background:var(--c-main-xl);border-color:#bbf7d0;}
.stat.hl .n{color:var(--c-main-d);}

/* ── filter chips ── */
.chips{display:flex;gap:7px;flex-wrap:wrap;margin-bottom:16px;}
.chip{padding:7px 14px;border-radius:30px;border:1px solid var(--border);background:#fff;color:var(--text);font-size:12.5px;font-weight:700;text-decoration:none;transition:all .15s;}
.chip:hover{border-color:var(--c-main);color:var(--c-main-d);}
.chip.on{background:var(--c-main);border-color:var(--c-main);color:#fff;}

/* ── card + table ── */
.c-card{background:#fff;border-radius:var(--radius);box-shadow:var(--shadow);border:1px solid var(--border);overflow:hidden;}
.card_meta{padding:16px 20px;border-bottom:1px solid var(--border);font-size:13px;color:var(--muted);display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;}
.card_meta strong{color:var(--c-main-d);}
.table_wrap{overflow-x:auto;}
table.c-tbl{width:100%;border-collapse:collapse;min-width:760px;}
.c-tbl thead th{background:#f5f6fa;padding:12px 18px;font-size:12px;font-weight:700;color:var(--muted);text-align:left;border-bottom:2px solid var(--border);white-space:nowrap;}
.c-tbl tbody td{padding:14px 18px;border-bottom:1px solid var(--line);vertical-align:middle;font-size:14px;color:var(--text);}
.c-tbl tbody tr:last-child td{border-bottom:none;}
.c-tbl tbody tr:hover td{background:#fafafa;}
.c-tbl tbody tr.unread td{background:#fffdf3;}
.c-tbl tbody tr.unread:hover td{background:#fffbe8;}
.td_name{font-weight:800;color:var(--strong);}
.td_phone{font-size:12px;color:var(--muted);margin-top:2px;}
.td_date{font-size:12px;color:var(--muted);white-space:nowrap;}
.preview{max-width:260px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:13px;color:var(--muted);}
.cat_badge{display:inline-block;padding:3px 10px;background:var(--c-main-l);color:var(--c-main-dd);border-radius:20px;font-size:11px;font-weight:800;}
.dot_new{display:inline-block;width:7px;height:7px;border-radius:50%;background:var(--point);margin-right:6px;vertical-align:middle;}
.empty_row td{text-align:center;padding:56px;color:var(--muted);}
.td_actions{display:flex;gap:7px;justify-content:center;}

/* ── status badge ── */
.st{display:inline-block;padding:4px 11px;border-radius:20px;font-size:11px;font-weight:800;white-space:nowrap;}
.st-new{background:#fef3c7;color:#b45309;}
.st-contacted{background:#dbeafe;color:#1d4ed8;}
.st-booked{background:var(--c-main-l);color:var(--c-main-d);}
.st-hold{background:#f1f5f9;color:#64748b;}
.st-closed{background:#e2e8f0;color:#475569;}

/* ── modal ── */
.c-modal-overlay{display:none;position:fixed;inset:0;background:rgba(26,26,46,.5);z-index:10000;align-items:center;justify-content:center;padding:20px;}
.c-modal-overlay.active{display:flex;}
.c-modal-box{background:#fff;border-radius:16px;width:100%;max-width:540px;overflow:hidden;animation:cmodal .22s ease;max-height:92vh;display:flex;flex-direction:column;}
@keyframes cmodal{from{transform:translateY(-20px);opacity:0;}to{transform:translateY(0);opacity:1;}}
.cm_hd{padding:20px 24px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;}
.cm_hd h3{font-size:17px;font-weight:800;color:var(--strong);}
.cm_close{background:none;border:none;font-size:22px;cursor:pointer;color:var(--muted);line-height:1;}
.cm_close:hover{color:var(--strong);}
.cm_bd{padding:22px 24px;display:flex;flex-direction:column;gap:16px;overflow-y:auto;}
.cm_row label{display:block;font-size:11px;font-weight:800;color:var(--muted);margin-bottom:5px;letter-spacing:.3px;}
.cm_row .val{font-size:15px;font-weight:600;color:var(--strong);}
.cm_grid{display:grid;grid-template-columns:1fr 1fr;gap:14px;}
.cm_content{background:var(--bg);border-radius:10px;padding:14px 16px;font-size:14px;line-height:1.7;color:var(--text);white-space:pre-wrap;min-height:72px;}
.cm_sel,.cm_ta{width:100%;border:1px solid var(--border);border-radius:10px;font-size:14px;font-family:inherit;background:#fff;color:var(--strong);padding:10px 12px;}
.cm_sel:focus,.cm_ta:focus{outline:none;border-color:var(--c-main);box-shadow:0 0 0 3px rgba(22,163,74,.12);}
.cm_ta{min-height:84px;resize:vertical;line-height:1.6;}
.cm_ft{padding:16px 24px;border-top:1px solid var(--border);display:flex;gap:9px;flex-wrap:wrap;align-items:center;}
.cm_ft .grow{flex:1;}

/* ── toast ── */
.toast_msg{position:fixed;bottom:26px;left:50%;transform:translateX(-50%);background:var(--strong);color:#fff;padding:12px 24px;border-radius:50px;font-size:13px;font-weight:700;z-index:99999;opacity:0;transition:opacity .3s;pointer-events:none;}
.toast_msg.show{opacity:1;}

/* ── 모바일: 좌측 박스 → 상단 가로 박스 ── */
@media (max-width:880px){
  #clinic_wrap,#admin_wrapper{flex-direction:column;}
  .clinic_aside{width:auto;position:static;padding:20px 16px 4px;}
  .ca_nav{flex-direction:row;flex-wrap:wrap;}
  .ca_nav a{flex:1 1 132px;}
  .ca_foot{flex-direction:row;gap:16px;}
  .content_area{padding:22px 16px;}
}
</style>
