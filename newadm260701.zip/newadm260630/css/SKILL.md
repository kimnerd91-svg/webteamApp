---
name: setting-css
description: |
  메디앤메디 치과 사이트의 공용 유틸리티 CSS 프레임워크(setting.css)를 사용해 마크업/UI를 만들 때 사용한다.
  HTML 컴포넌트, 섹션, 카드, 버튼, 폼, 레이아웃 등 프론트 화면 요소를 작성하거나 수정할 때,
  새 인라인 스타일을 마구 쓰지 말고 이 프레임워크의 기존 유틸리티 클래스를 우선 활용하도록 강제한다.
  "setting.css", "유틸 클래스", "이 사이트 디자인 시스템으로", "클래스로 짜줘" 같은 요청에서 트리거.
---

# setting.css 유틸리티 프레임워크 작성 지침

이 프로젝트(그누보드5 + Bootstrap 5 + `setting.css`)의 화면을 만들 때 따르는 규칙과 클래스 레퍼런스다.
`setting.css`가 디자인 시스템의 source of truth이며, 정확한 값이 필요하면 항상 실제 `setting.css`를 grep해서 확인한다.

---

## 0. 핵심 작성 지침 (반드시 준수 — 사용자 규칙)

**스타일 적용 우선순위 (위에서부터 시도):**

1. **1순위 — setting.css 유틸 클래스.** 간격·타이포·컬러·보더 등은 거의 다 setting.css 유틸로 해결된다. 인라인 `style=""`나 새 CSS를 먼저 떠올리지 말고, 항상 setting.css 클래스로 가능한지 먼저 확인한다.
2. **2순위 — Bootstrap 클래스.** setting.css에 없는 것(특히 display·flex·정렬: `d-flex`, `justify-content-*`, `align-items-*`, `flex-column`, `row/col-*` 등)은 Bootstrap 클래스로 해결한다.
3. **3순위 — 새 CSS 제작.** setting.css와 Bootstrap 둘 다로 안 될 때만 새 CSS를 작성한다. 남발 금지 — 정말 안 될 때만. (애니메이션 / hover / 색상 전환(transition) 등 "상태 변화"는 유틸로 표현이 안 되므로 여기에 해당.)

**새 CSS를 작성할 때 추가 규칙:**

4. **별도로 작성한 CSS는 (a) 코드에 복사하기 좋게 정리하고, (b) 별도 CSS 파일로 분리해 둔다.** 예: `extra.css` 또는 컴포넌트명 css. HTML 안에 흩뿌리지 않는다.
5. **같은 프로젝트면 그 프로젝트에 이미 있는 추가 CSS를 재활용한다.** 매번 새로 만들지 말고 기존 보조 css에 누적/참조.
6. **새 class/id는 최소화한다.** 단, JS 스크립트에서 잡아야 하는 훅(예: `getElementById`, querySelector 타겟)이나 별도 CSS를 걸 앵커가 꼭 필요한 경우에만 새 클래스/id를 만든다. 그 외에는 만들지 않는다.

> 요약 흐름: **① setting.css 유틸 → ② Bootstrap 클래스 → ③ 둘 다 안 되면 새 CSS(복사용 정리 + 별도 파일 분리) → 새 class/id는 JS훅 등 필수일 때만.**

---

## 1. 프레임워크 구조 (중요 전제)

- **Bootstrap 5와 공존한다.** `d-flex`, `d-block`, `d-none`, `justify-content-*`, `align-items-*`, `flex-column`, `row`/`col-*` 같은 **display·flex·그리드 유틸은 Bootstrap에서 온다.** setting.css에는 이게 없다.
- **setting.css가 담당하는 것**: 컬러 토큰, 타이포(t-fs/c-fs), 폰트두께/줄간격/자간, 간격(margin/padding/gap), 컬러 유틸(글자/배경/보더), 보더/라운드/그림자, 버튼, 너비/비율/오브젝트핏, 스마트컬럼 그리드(g-*), 기타(opacity, z-index, blur 등).
- **반응형 접미사**: 클래스 뒤 `-sm` / `-md` / `-lg`를 붙이면 작은 화면용 오버라이드가 적용된다(예: `t-fs-80 t-fs-48-md`). 기본(접미사 없음)=PC, 접미사=태블릿/모바일 축소값. 정확한 브레이크포인트 px는 setting.css 미디어쿼리(주요 분기: 1440 / 1280 / 1024 / 992 / 768)를 직접 확인.

---

## 2. 컬러 토큰 (CSS 변수)

`var(--토큰)`으로 직접 쓰거나, 아래 컬러 유틸 클래스로 적용한다.

| 토큰 | 값 | 용도 |
|---|---|---|
| `--main-color` | #304F4E | 메인(딥그린) |
| `--sub-color` | #9BAB83 | 서브(세이지) |
| `--point` | #D7AC7A | 포인트(베이지골드) |
| `--point2` | #50ecc8 | 포인트2(민트) |
| `--light` / `--light2` | #F9FBF4 / #F6F4EC | 밝은 배경 |
| `--dark` | #2c2c2c | 어두운 텍스트 |
| `--white` / `--black` | #fff / #000 | |
| `--gray-100` ~ `--gray-900` | f8f8f8 → 2c2c2c | 9단계 그레이 |
| SNS | `--naver`,`--kakao`,`--kakaobrown`,`--youtube`,`--insta`,`--instaGradation` | SNS 버튼 |

별도 CSS를 쓸 때도 색은 하드코딩하지 말고 이 변수를 쓴다.

---

## 3. 타이포그래피

### 폰트 패밀리 유틸
`u-pretendard`(기본 본문), `u-notosans`, `u-notoserif`(세리프 강조), `u-montserrat`, `u-roboto`(영문/숫자), `u-maruburi`(감성 제목).

### 글자 크기 — 두 체계
- **`t-fs-{n}`** : 타이틀 시스템(제목용). 큰 범위(대략 10~80+), 크기별 line-height 자동.
- **`c-fs-{n}`** : 본문/콘텐츠 시스템(6~80). 가독성용 line-height.
- 둘 다 `-sm`/`-md`/`-lg` 반응형 변형 존재. 예: `class="t-fs-48 t-fs-32-md"`.
- 값은 2단위 등 촘촘하게 정의돼 있으니, 특정 px가 필요하면 setting.css에서 `t-fs-` / `c-fs-`를 grep해 가장 가까운 정의값을 쓴다.

### 폰트 두께 / 줄간격 / 자간
- `fw-100` ~ `fw-900` (100단위)
- `u-lh-1`, `u-lh-105`, `u-lh-11`, `u-lh-115`, `u-lh-12`, `u-lh-125`, `u-lh-13`, `u-lh-135` … (1.0~1.x, 소수점 제거 표기)
- `u-ls-0`, `u-ls-05`, `u-ls-10`, `u-ls-15` … (자간)

### 텍스트 컬러 / 정렬
- `u-txt-{토큰}` : `u-txt-main`, `u-txt-sub`, `u-txt-point`, `u-txt-dark`, `u-txt-white`, `u-txt-black`, `u-txt-gray-100`~`900` 등.
- 정렬(`text-center`/`text-left`/`text-right`)은 **Bootstrap** 사용.

---

## 4. 간격 (Margin / Padding) — 유동형

- 형식: `u-{속성}-{값}` , 값 범위 대략 **0~150**(촘촘한 단위). `-sm`/`-md`/`-lg` 반응형 변형 있음.
- margin: `u-m-*`(전체), `u-mt-*`,`u-mb-*`,`u-ml-*`,`u-mr-*`, `u-mx-*`(좌우), `u-my-*`(상하)
- padding: `u-p-*`, `u-pt-*`,`u-pb-*`,`u-pl-*`,`u-pr-*`, `u-px-*`, `u-py-*`
- 예: `u-mt-80 u-mt-40-md`, `u-px-24 u-py-16`
- 정확한 값 유무는 setting.css에서 해당 클래스 grep 확인(없으면 가장 가까운 값 사용).

---

## 5. Gap (flex/grid 자식 간격)

- `u-gap-*` : 전체 gap (0~150, 주로 2단위). `-sm/-md/-lg` 변형.
- `u-cgap-*` : column-gap(가로 전용). `u-cgap-10/12/16/...`
- `u-rgap-*` : row-gap(세로 전용).
- Bootstrap `d-flex`와 함께: `class="d-flex u-gap-12"`.

---

## 6. 스마트 컬럼 그리드 (g-*)

반응형으로 자동 줄바꿈되는 자체 그리드 시스템. `g-` 접두.
- 부모 정렬: `g-center`, `g-auto-flow` 등 (`-sm/-md/-lg` 변형 존재).
- `--g-flex` 변수 기반으로 한 줄당 개수 제어. `flex-1`, `flex-125` 등 flex 유틸과 조합.
- 단순 2~3단 레이아웃이면 Bootstrap `row/col`을 써도 되고, 이 사이트 톤에 맞추려면 g-* 사용. 정확한 사용법은 setting.css의 `[스마트 컬럼]` 섹션(1328줄 부근) 확인.

---

## 7. 보더 / 라운드 / 그림자

- 두께: `u-bd-1`,`u-bd-2`,`u-bd-3`,`u-bd-n`(none) / 방향별 `u-bt-*`(top),`u-bb-*`(bottom),`u-bl-*`,`u-br-*`
- 스타일: `u-b-solid`,`u-b-dashed`,`u-b-dotted`,`u-b-double`,`u-b-none`
- 색: `u-bc-{토큰}` (`u-bc-main`,`u-bc-gray-300`,`u-bc-point`…)
- 라운드: `u-round-{n}` (0~, `-sm/-md/-lg` 변형). 모서리 둥글기.
- 그림자: `shadow-soft`, `shadow-hard`
- 예: `class="u-bd-1 u-b-solid u-bc-gray-300 u-round-8"`

---

## 8. 버튼

기본 `u-btn`에 변형을 조합.
- 색상: `u-btn-main`, `u-btn-sub`, `u-btn-point`, `u-btn-accent`, `u-btn-success`, `u-btn-danger`, `u-btn-outline`(보더형)
- 너비/크기: `u-btn-full`(100%), `u-btn-lg`, `u-btn-sm`
- hover 시 살짝 떠오르는 transform 등은 클래스에 내장됨. 추가 hover 효과가 필요하면 별도 CSS(지침 2번)로.
- 예: `<a class="u-btn u-btn-main u-btn-lg">예약하기</a>`

---

## 9. 너비 / 높이 / 비율 / 이미지

- 너비: `w-100`(+`-sm/-md/-lg`), `w-max`, `w-min`, `w-fit`
- 높이: `h-100`(`-sm`), `h-fit`, `vh-100`(`-sm/-md`)
- 종횡비: `u-ratio`, `u-ratio-1-1`, `u-ratio-16-9` (+반응형). 카드 썸네일 등 비율 고정.
- 오브젝트핏: `u-obj-cover`, `u-obj-contain`
- 예: `<div class="u-ratio-16-9"><img class="w-100 u-obj-cover"></div>`

---

## 10. 기타 유틸

- 투명도: `u-op-0` ~ `u-op-10` (0~1.0)
- z-index: `z-header`, `z-modal`, `z-dropdown`, `z-minus`
- 블러: `u-blur-4`, `u-blur-12` (backdrop blur)
- 포인터: `u-pe-none`, `u-pe-auto`
- 기타: `no-drag`, `no-scrollbar`, `min-w-0`, `dot-dot`(말줄임 점 등)
- 체크박스 래퍼: `u-check`, `u-check-wrap`

---

## 11. 별도 CSS 작성 시 형식 (지침 4·5번 구체화)

상태변화/예외로 CSS를 따로 써야 할 때:

```css
/* extra.css 또는 컴포넌트.css 에 누적 — 복사해서 붙이기 좋게 */
/* [컴포넌트명] hover 색전환 */
.특정훅:hover { background: var(--point); color: var(--white); transition: .2s; }
```

- 색은 항상 `var(--토큰)` 사용(하드코딩 금지).
- HTML 인라인 `<style>` 남발 금지 → 별도 파일로.
- 훅 클래스/id는 그 CSS·JS에 꼭 필요한 최소 개수만.
- 같은 프로젝트에 보조 css가 이미 있으면 거기에 추가.

---

## 12. 작업 전 체크 (AI 셀프체크)

코드 내보내기 전에 확인:
- [ ] 간격/타이포/컬러/보더를 인라인 style 대신 **1순위 setting.css 유틸**로 처리했나?
- [ ] setting.css에 없는 display/flex/정렬 등은 **2순위 Bootstrap**으로 처리했나?
- [ ] 새 CSS는 **setting.css·Bootstrap 둘 다 안 될 때(3순위)만** 작성했나?
- [ ] 색은 `var(--토큰)` 또는 컬러 유틸로 썼나(하드코딩 X)?
- [ ] 새로 만든 별도 CSS는 별도 파일 + 복사용 정리 형태인가?
- [ ] 새 class/id가 JS훅/필수 앵커 외에 불필요하게 늘지 않았나?
- [ ] 정확한 클래스 값이 의심되면 실제 setting.css를 grep해 확인했나?
