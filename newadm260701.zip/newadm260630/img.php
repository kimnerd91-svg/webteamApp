<?php
/**
 * img.php - WebP 자동 변환 서버
 * 위치: /www/img.php
 */

$accept     = $_SERVER['HTTP_ACCEPT'] ?? '';
$supportsWebP = strpos($accept, 'image/webp') !== false;

$path = $_GET['src'] ?? '';
$path = '/' . ltrim(parse_url($path, PHP_URL_PATH), '/');
$abs  = realpath($_SERVER['DOCUMENT_ROOT'] . $path);

// 보안: document root 밖 접근 차단
if (!$abs || strpos($abs, realpath($_SERVER['DOCUMENT_ROOT'])) !== 0) {
    http_response_code(403); exit;
}

// 허용 확장자만 (gif는 동적 이미지이므로 변환 제외)
$ext = strtolower(pathinfo($abs, PATHINFO_EXTENSION));
$mime_map = ['jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png'];
if (!isset($mime_map[$ext])) {
    http_response_code(400); exit;
}

// 파일 존재 확인
if (!file_exists($abs)) {
    http_response_code(404); exit;
}

// WebP 미지원 브라우저 → 원본 그대로
if (!$supportsWebP) {
    header('Content-Type: ' . $mime_map[$ext]);
    header('Cache-Control: public, max-age=31536000');
    readfile($abs);
    exit;
}

// 캐시 경로: /www/data/webp_cache/images/xxx.webp
$cacheDir  = realpath($_SERVER['DOCUMENT_ROOT']) . '/data/webp_cache' . dirname($path);
$cacheFile = $cacheDir . '/' . pathinfo($abs, PATHINFO_FILENAME) . '.webp';

// 캐시 유효하면 바로 서빙
if (file_exists($cacheFile) && filemtime($cacheFile) >= filemtime($abs)) {
    header('Content-Type: image/webp');
    header('Cache-Control: public, max-age=31536000');
    readfile($cacheFile);
    exit;
}

// 캐시 폴더 생성
if (!is_dir($cacheDir)) {
    @mkdir($cacheDir, 0755, true);
}

// GD로 이미지 로드 (jpg/jpeg/png만)
$img = null;
switch ($ext) {
    case 'jpg':
    case 'jpeg':
        $img = @imagecreatefromjpeg($abs);
        break;
    case 'png':
        $img = @imagecreatefrompng($abs);
        if ($img) {
            // PNG 투명도 유지
            imagepalettetotruecolor($img);
            imagealphablending($img, true);
            imagesavealpha($img, true);
        }
        break;
}

// 변환 실패 시 원본 서빙
if (!$img) {
    header('Content-Type: ' . $mime_map[$ext]);
    header('Cache-Control: public, max-age=31536000');
    readfile($abs);
    exit;
}

// WebP 변환 후 캐시 저장
$quality = 82; // 0~100 (높을수록 고화질/용량 증가)
imagewebp($img, $cacheFile, $quality);
imagedestroy($img);

header('Content-Type: image/webp');
header('Cache-Control: public, max-age=31536000');
readfile($cacheFile);
exit;
