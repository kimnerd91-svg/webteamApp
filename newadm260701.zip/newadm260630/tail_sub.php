<?php
if (!defined('_GNUBOARD_')) exit;

if (!defined('G5_IS_ADMIN') && defined('G5_THEME_PATH') && is_file(G5_THEME_PATH.'/tail.sub.php')) {
    require_once(G5_THEME_PATH.'/tail.sub.php');
    return;
}
?>

<?php if ($is_admin == 'super') { ?><!-- <div style='float:left; text-align:center;'>RUN TIME : <?php echo get_microtime()-$begin_time; ?><br></div> --><?php } ?>

<?php run_event('tail_sub'); ?>

</body>
<?php
// ============================================================
// 상수 정의 (중복 방지)
// ============================================================
if (!defined('CONFIG_TABLE'))  define('CONFIG_TABLE',  'dm_config');
if (!defined('BANNER_TABLE'))  define('BANNER_TABLE',  'mainbanner');
if (!defined('POPUP_TABLE'))   define('POPUP_TABLE',   'dm_popup');
if (!defined('BOARD_PREFIX'))  define('BOARD_PREFIX',  'g5_write_');
if (!defined('REVIEW_BOARD'))  define('REVIEW_BOARD',  'review');
if (!defined('CASE_BOARD'))    define('CASE_BOARD',    'case');
if (!defined('BANNER_ID'))     define('BANNER_ID',     '4');

// ============================================================
// 공통 함수 (중복 방지)
// ============================================================
if (!function_exists('safe_sql_query')) {
    function safe_sql_query($query) {
        if (function_exists('sql_query')) return sql_query($query);
        global $connect_db;
        if ($connect_db) return mysqli_query($connect_db, $query);
        return false;
    }
}

if (!function_exists('safe_sql_fetch_array')) {
    function safe_sql_fetch_array($result) {
        if (function_exists('sql_fetch_array')) return sql_fetch_array($result);
        if ($result) return mysqli_fetch_assoc($result);
        return false;
    }
}

if (!function_exists('get_content_thumbnail')) {
    function get_content_thumbnail($content) {
        if (!$content) return null;
        $content = stripslashes($content);
        if (preg_match('/<img[^>]+src=["\']([^"\']+)["\'][^>]*>/i', $content, $match)) {
            return $match[1];
        }
        if (preg_match('/(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]+)/', $content, $match)) {
            return 'https://i.ytimg.com/vi/' . $match[1] . '/hqdefault.jpg';
        }
        return null;
    }
}

// ============================================================
// 데이터 로드
// ============================================================
$site_config = sql_fetch("SELECT * FROM " . CONFIG_TABLE . " WHERE cf_id = 1");
if (!$site_config) {
    $site_config = [
        'cf_title'       => '사이트 제목',
        'cf_description' => '사이트 설명',
        'cf_og_image'    => '',
    ];
}

$banner_row = sql_fetch("SELECT * FROM " . BANNER_TABLE . " WHERE id = '" . BANNER_ID . "'");

$banner_images   = [];
$banner_settings = [
    'autoplay_delay' => 3000,
    'effect'         => 'slide',
    'loop'           => 1,
    'speed'          => 600,
];

if ($banner_row) {
    $banner_images   = $banner_row['images']   ? json_decode($banner_row['images'],   true) : [];
    $banner_settings = $banner_row['settings'] ? json_decode($banner_row['settings'], true) : $banner_settings;
}

if (empty($banner_images)) {
    $banner_images = [[
        'src'     => 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1920',
        'visible' => true,
        'link'    => '',
    ]];
}

$review_result = safe_sql_query("SELECT * FROM " . BOARD_PREFIX . REVIEW_BOARD . " ORDER BY wr_datetime DESC LIMIT 3");
$case_result   = safe_sql_query("SELECT * FROM " . BOARD_PREFIX . CASE_BOARD   . " ORDER BY wr_datetime DESC LIMIT 6");

// 팝업
$popup_html = '';
if (file_exists('./popup.php')) {
    ob_start();
    include_once('./popup.php');
    $popup_html = ob_get_clean();
}
?>

<!-- 팝업 -->
<?= $popup_html ?>

<main id="content">

    <!-- 히어로 섹션 -->
    <section id="hero" class="hero-section">
        <div class="swiper mainSwiper h-100">
            <div class="swiper-wrapper">
                <?php
                $custom_texts = [
                    0 => ['title' => '첫 번째 슬라이드 제목<br>Invisible Design',  'desc' => '첫 번째 슬라이드에 대한 개별 설명입니다.', 'btn' => '자세히 보기'],
                    1 => ['title' => '두 번째는 다른 문구<br>Branding Identity',   'desc' => '브랜드 가치를 높이는 두 번째 설명입니다.',   'btn' => '포트폴리오'],
                    2 => ['title' => '세 번째 배너 텍스트<br>Creative Work',       'desc' => '마지막 슬라이드에 들어가는 문구입니다.',       'btn' => '문의하기'],
                ];
                foreach ($banner_images as $index => $img):
                    if (isset($img['visible']) && !$img['visible']) continue;
                    $text = $custom_texts[$index] ?? [
                        'title' => 'Great Design Should<br>Feel Invisible',
                        'desc'  => 'From logo to language, I build brands that connect and convert.',
                        'btn'   => 'Get in touch',
                    ];
                ?>
                <div class="swiper-slide g-center" style="background:#111;">
                    <img src="<?= htmlspecialchars($img['src']) ?>" alt="배너" class="slide-bg-img obj-cover">
                    <div class="slide-content u-mx-auto text-center">
                        <h1 class="t-fs-60 u-mb-24 keep-all" data-aos="fade-up"><?= $text['title'] ?></h1>
                        <p class="c-fs-20 u-txt-gray-300 u-mb-32"><?= htmlspecialchars($text['desc']) ?></p>
                        <?php if (!empty($img['link'])): ?>
                        <a href="<?= htmlspecialchars($img['link']) ?>" class="u-btn u-btn-main u-p-16 fw-bold rounded-full">
                            <?= htmlspecialchars($text['btn']) ?>
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <div class="swiper-pagination"></div>
        </div>
    </section>

    <!-- 리뷰 섹션 -->
    <section id="notice" class="u-p-40">
        <div class="container">
            <div class="text-center u-mb-40">
                <div class="u-txt-main fw-700 c-fs-14 u-mb-10">REVIEW</div>
                <h2 class="t-fs-40">고객리뷰</h2>
            </div>
            <div class="g-cols-1 u-gap-20">
                <?php
                $has_posts = false;
                while ($review = safe_sql_fetch_array($review_result)):
                    $has_posts  = true;
                    $thumbnail  = get_content_thumbnail($review['wr_content']) ?: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600';
                ?>
                <a href="/view_direct.php?bo_table=<?= REVIEW_BOARD ?>&wr_id=<?= $review['wr_id'] ?>" class="notice-item d-flex align-items-center u-p-24 u-gap-24 rounded-16">
                    <img src="<?= htmlspecialchars($thumbnail) ?>" alt="thumb" class="d-none d-sm-block obj-cover rounded-8" style="width:120px; height:80px;">
                    <div class="flex-grow-1 min-w-0">
                        <div class="u-txt-main fw-700 c-fs-12 u-mb-8">CUSTOMER REVIEW</div>
                        <div class="u-txt-white c-fs-20 fw-700 u-mb-4 dot-dot"><?= htmlspecialchars($review['wr_subject']) ?></div>
                        <div class="u-txt-muted c-fs-14"><?= substr($review['wr_datetime'], 0, 10) ?></div>
                    </div>
                </a>
                <?php endwhile; ?>
                <?php if (!$has_posts): ?>
                <div class="text-center u-p-40 u-txt-muted">등록된 리뷰가 없습니다.</div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- 진료 안내 섹션 -->
    <section class="u-p-40">
        <div class="container">
            <div class="text-center u-mb-40">
                <div class="u-txt-main fw-700 c-fs-14 u-mb-10">CLINIC</div>
                <h2 class="t-fs-40">진료 안내</h2>
            </div>
            <div class="expandable-grid" id="expandGrid">
                <div class="grid-item item-1" data-expand>
                    <div class="grid-item-bg" style="background-image:url('https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=800')"></div>
                    <div class="grid-item-content"><h3 class="grid-item-title">전립선 클리닉</h3><p class="grid-item-desc">전립선 건강을 위한 전문적인 진료와 치료를 제공합니다.</p></div>
                </div>
                <div class="grid-item item-2" data-expand>
                    <div class="grid-item-bg" style="background-image:url('https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800')"></div>
                    <div class="grid-item-content"><h3 class="grid-item-title">요도결석 클리닉</h3><p class="grid-item-desc">최신 장비를 활용한 정확한 진단과 효과적인 치료</p></div>
                </div>
                <div class="grid-item item-3" data-expand>
                    <div class="grid-item-bg" style="background-image:url('https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=800')"></div>
                    <div class="grid-item-content"><h3 class="grid-item-title">성병 클리닉</h3><p class="grid-item-desc">비밀보장과 신속한 검사 및 치료 프로그램</p></div>
                </div>
                <div class="grid-item item-4" data-expand>
                    <div class="grid-item-bg" style="background-image:url('https://images.unsplash.com/photo-1530497610245-94d3c16cda28?w=800')"></div>
                    <div class="grid-item-content"><h3 class="grid-item-title">배뇨장애 클리닉</h3><p class="grid-item-desc">배뇨 관련 모든 문제에 대한 종합 진료</p></div>
                </div>
                <div class="grid-item item-5" data-expand>
                    <div class="grid-item-bg" style="background-image:url('https://images.unsplash.com/photo-1576086213369-97a306d36557?w=800')"></div>
                    <div class="grid-item-content"><h3 class="grid-item-title">남성 클리닉</h3><p class="grid-item-desc">남성 건강의 모든 것을 책임집니다</p></div>
                </div>
                <div class="grid-item item-6" data-expand>
                    <div class="grid-item-bg" style="background-image:url('https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=800')"></div>
                    <div class="grid-item-content"><h3 class="grid-item-title">여성 클리닉</h3><p class="grid-item-desc">여성 비뇨기과 질환 전문 진료</p></div>
                </div>
            </div>
        </div>
    </section>

    <!-- 증례 섹션 -->
    <section id="gallery" class="u-p-40 u-bg-black">
        <div class="container">
            <div class="text-center u-mb-40">
                <div class="u-txt-main fw-700 c-fs-14 u-mb-10">CASE STUDY</div>
                <h2 class="t-fs-40">임상증례</h2>
            </div>
            <div class="g-cols-fit-5 u-gap-24">
                <?php
                $has_posts = false;
                while ($case = safe_sql_fetch_array($case_result)):
                    $has_posts = true;
                    $thumbnail = get_content_thumbnail($case['wr_content']) ?: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600';
                ?>
                <a href="/view_direct.php?bo_table=<?= CASE_BOARD ?>&wr_id=<?= $case['wr_id'] ?>" class="gallery-card rounded-20" style="overflow:hidden;">
                    <img src="<?= htmlspecialchars($thumbnail) ?>" alt="case" class="obj-cover" style="width:100%; height:250px;">
                    <div class="u-p-24">
                        <h3 class="c-fs-18 fw-700 u-mb-10 u-txt-white dot-dot"><?= htmlspecialchars($case['wr_subject']) ?></h3>
                        <div class="u-txt-muted c-fs-12"><?= htmlspecialchars($case['wr_name']) ?> · <?= substr($case['wr_datetime'], 0, 10) ?></div>
                    </div>
                </a>
                <?php endwhile; ?>
                <?php if (!$has_posts): ?>
                <div class="text-center u-p-40 u-txt-muted" style="grid-column:1/-1;">등록된 증례가 없습니다.</div>
                <?php endif; ?>
            </div>
        </div>
    </section>

</main>

<!-- Swiper 초기화 -->
<script>
const swiper = new Swiper('.mainSwiper', {
    effect:   '<?= $banner_settings['effect'] ?>',
    speed:    <?= (int)$banner_settings['speed'] ?>,
    loop:     <?= !empty($banner_settings['loop']) ? 'true' : 'false' ?>,
    autoplay: { delay: <?= (int)$banner_settings['autoplay_delay'] ?>, disableOnInteraction: false },
    pagination: { el: '.swiper-pagination', clickable: true },
    on: {
        init: function () { AOS.init({ duration: 1000, once: false }); },
        slideChangeTransitionEnd: function () {
            document.querySelectorAll('.swiper-slide [data-aos]').forEach(el => el.classList.remove('aos-animate'));
            setTimeout(() => {
                const active = document.querySelector('.swiper-slide-active [data-aos]');
                if (active) active.classList.add('aos-animate');
            }, 50);
        }
    }
});
</script>

<!-- 확장형 그리드 -->
<script>
(function () {
    class ExpandableGrid {
        constructor(selector) {
            this.grid  = document.querySelector(selector);
            if (!this.grid) return;
            this.items = this.grid.querySelectorAll('[data-expand]');
            this.init();
        }
        init() {
            this.items.forEach(item => {
                item.addEventListener('mouseenter', () => this.expand(item));
                item.addEventListener('mouseleave', () => this.reset());
            });
        }
        expand(target) {
            this.items.forEach(item => {
                gsap.to(item, { flex: item === target ? 3 : 0.5, duration: 1, ease: 'power2.out' });
                item.classList.toggle('collapsed', item !== target);
            });
        }
        reset() {
            this.items.forEach(item => {
                gsap.to(item, { flex: 1, duration: 1, ease: 'power2.out' });
                item.classList.remove('collapsed');
            });
        }
    }
    new ExpandableGrid('#expandGrid');
})();
</script>

<!-- ScrollTrigger -->
<script>
(function () {
    gsap.registerPlugin(ScrollTrigger);

    document.querySelectorAll('[data-scroll-text]').forEach(block => {
        gsap.to(block, {
            opacity: 1, y: 0, duration: 1, ease: 'power2.out',
            scrollTrigger: {
                trigger: block,
                start: 'top 80%',
                end: 'top 20%',
                toggleActions: 'play none none reverse',
            }
        });
    });

    gsap.to('.scroll-bg img', {
        scale: 1.2, ease: 'none',
        scrollTrigger: {
            trigger: '.scroll-text-section',
            start: 'top top', end: 'bottom top', scrub: 1,
        }
    });
})();
</script>

<script>AOS.init();</script>

<?php
// tail.php 만 include (tail_sub.php 는 현재 파일이므로 절대 포함하지 않음)
include_once(G5_PATH.'/tail.php');
echo html_end();
?>