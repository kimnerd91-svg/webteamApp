<?php
/**
 * NEW ADM - 관리자 공통 설정 파일
 */
ini_set('session.gc_maxlifetime', 86400);
ini_set('session.cookie_lifetime', 86400);

// 1. 그누보드 _common.php 로드
include_once($_SERVER['DOCUMENT_ROOT'] . '/common.php');

$is_admin = 'super';



// 2. 관리자 경로 정의
if (!defined('G5_NEWADM_PATH')) {
    define('G5_NEWADM_PATH', $_SERVER['DOCUMENT_ROOT'] . '/newadm');
}

// 3. 브라우저 캐시 방지
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// 4. 현재 실행 중인 파일 경로
$current_file = $_SERVER['PHP_SELF'];

// 5. 로그인 페이지 제외 목록
$skip_auth_pages = array(
    '/newadm/auth/login.php',
    '/newadm/auth/logout.php',
    '/newadm/auth/setup_admin.php', 
    '/newadm/auth/setup_admin_force.php',
    '/newadm/auth/create_super_admin.php',
    '/newadm/backup/db_backup_manager.php'
);

// 6. 로그인 체크 (제외 페이지가 아닌 경우에만)
if (!in_array($current_file, $skip_auth_pages)) {
    
    // 세션이 없으면 로그인 페이지로
   if (!isset($_SESSION['adm_mb_id']) || !$_SESSION['adm_mb_id']) {
    alert_toast('관리자 로그인이 필요합니다.', '/newadm/auth/login.php', 'error');
    exit;
}

// DB에서 권한 재검증
$adm_sql = "SELECT mb_id, mb_name, mb_level FROM {$g5['member_table']} WHERE mb_id = '{$_SESSION['adm_mb_id']}'";
$adm_member = sql_fetch($adm_sql);

if (!$adm_member['mb_id'] || $adm_member['mb_level'] < 10) {
    // 세션 삭제
    unset($_SESSION['adm_mb_id']);
    unset($_SESSION['adm_mb_name']);
    unset($_SESSION['adm_login_time']);
    
    alert_toast('관리자 권한이 없습니다. (Level 10 이상 필요)', '/newadm/login.php', 'error');
    exit;
}
    // 그누보드 관리자 변수 할당
    $_SESSION['ss_mb_id'] = $_SESSION['adm_mb_id'];
    $is_admin = 'super';
    $member = $adm_member;
}

?>