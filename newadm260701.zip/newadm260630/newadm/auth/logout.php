<?php
// 경로: newadm/member/logout.php (예시)

// 1. 그누보드 환경 로드 (루트의 common.php 호출)
include_once('../../common.php');

// 2. 세션 시작 (이미 common.php에서 시작되었을 수 있으나 안전하게 체크)
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// 3. 자동 로그인 토큰 삭제 (DB 및 쿠키)
if(isset($_COOKIE['adm_auto_login'])) {
    $token = sql_real_escape_string($_COOKIE['adm_auto_login']);
    
    // DB 내 해당 토큰 정보 초기화
    sql_query("UPDATE {$g5['member_table']} SET mb_memo = '' WHERE mb_memo = '{$token}'");
    
    // 쿠키 무효화
    setcookie('adm_auto_login', '', time() - 3600, '/');
}

// 4. 모든 관리자 및 그누보드 관련 세션 제거
unset($_SESSION['ss_mb_id']);
unset($_SESSION['adm_mb_id']);
unset($_SESSION['adm_mb_name']);
unset($_SESSION['adm_login_time']);

// 세션 파괴
session_destroy();

// 5. 토스트 메시지 표시 후 로그인 페이지로 이동
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>로그아웃</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        }
        
        .toast-message {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: #333;
            color: white;
            padding: 20px 40px;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 600;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
            z-index: 9999;
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        
        .toast-message.show {
            opacity: 1;
        }
    </style>
</head>
<body>
    <div id="toast" class="toast-message">로그아웃 되었습니다.</div>
    
    <script>
        // 토스트 메시지 표시
        const toast = document.getElementById('toast');
        
        // 페이지 로드 후 토스트 표시
        setTimeout(() => {
            toast.classList.add('show');
        }, 100);
        
        // 1.5초 후 로그인 페이지로 이동
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => {
                location.replace('./login.php');
            }, 300);
        }, 1500);
    </script>
</body>
</html>