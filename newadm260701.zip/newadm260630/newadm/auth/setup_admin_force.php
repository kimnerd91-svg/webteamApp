<?php
/**
 * 관리자 계정 강제 생성/비밀번호 재설정
 * admin 계정이 있으면 비밀번호만 재설정
 * 없으면 새로 생성
 */

include_once('./_common.php');

// admin 계정 존재 여부 확인
$check = sql_fetch("SELECT mb_id, mb_level FROM {$g5['member_table']} WHERE mb_id = 'admin'");

$mb_id = 'kimnerd91';
$mb_password = '0910';
$mb_password_hash = get_encrypt_string($mb_password);

if($check['mb_id']) {
    // 이미 admin 계정이 있으면 비밀번호만 재설정
    $result = sql_query("
        UPDATE {$g5['member_table']} 
        SET mb_password = '$mb_password_hash',
            mb_level = 10
        WHERE mb_id = 'admin'
    ");
    
    $action = '비밀번호 재설정';
} else {
    // admin 계정이 없으면 새로 생성
    $mb_name = '최고관리자';
    $mb_email = 'kimnerd91@gmail.com';
    $mb_level = 10;
    $mb_datetime = date('Y-m-d H:i:s');
    $mb_today_login = date('Y-m-d H:i:s');
    $mb_ip = $_SERVER['REMOTE_ADDR'];
    
    $result = sql_query(" 
        INSERT INTO {$g5['member_table']} SET
            mb_id = '$mb_id',
            mb_password = '$mb_password_hash',
            mb_name = '$mb_name',
            mb_nick = '$mb_name',
            mb_email = '$mb_email',
            mb_level = '$mb_level',
            mb_datetime = '$mb_datetime',
            mb_today_login = '$mb_today_login',
            mb_ip = '$mb_ip',
            mb_email_certify = '$mb_datetime',
            mb_mailling = '1',
            mb_open = '1'
    ");
    
    $action = '계정 생성';
}

if($result) {
    echo '
    <!DOCTYPE html>
    <html lang="ko">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>관리자 계정 '.($action).' 완료</title>
        <style>
            body {
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 20px;
            }
            .success-box {
                background: #fff;
                border-radius: 20px;
                padding: 50px;
                box-shadow: 0 20px 60px rgba(0,0,0,0.3);
                max-width: 500px;
                text-align: center;
            }
            .success-icon {
                font-size: 60px;
                margin-bottom: 20px;
            }
            h2 {
                color: #28a745;
                margin-bottom: 30px;
            }
            .info-box {
                background: #f8f9fa;
                padding: 20px;
                border-radius: 12px;
                margin: 20px 0;
                text-align: left;
            }
            .info-row {
                display: flex;
                justify-content: space-between;
                padding: 10px 0;
                border-bottom: 1px solid #e9ecef;
            }
            .info-row:last-child {
                border-bottom: none;
            }
            .info-label {
                font-weight: 600;
                color: #666;
            }
            .info-value {
                font-family: monospace;
                font-weight: 700;
                color: #007bff;
            }
            .warning {
                background: #fff3cd;
                border: 2px solid #ffc107;
                border-radius: 8px;
                padding: 15px;
                margin: 20px 0;
                color: #856404;
                font-size: 14px;
            }
            .btn {
                display: inline-block;
                padding: 15px 40px;
                background: #007bff;
                color: #fff;
                text-decoration: none;
                border-radius: 10px;
                font-weight: 700;
                margin-top: 20px;
                transition: all 0.3s;
            }
            .btn:hover {
                background: #0056b3;
                transform: translateY(-2px);
                box-shadow: 0 10px 20px rgba(0,123,255,0.3);
            }
        </style>
    </head>
    <body>
        <div class="success-box">
            <div class="success-icon">✅</div>
            <h2>관리자 '.$action.' 완료!</h2>
            
            <div class="info-box">
                <div class="info-row">
                    <span class="info-label">아이디</span>
                    <span class="info-value">admin</span>
                </div>
                <div class="info-row">
                    <span class="info-label">비밀번호</span>
                    <span class="info-value">pw1234</span>
                </div>
                <div class="info-row">
                    <span class="info-label">권한 레벨</span>
                    <span class="info-value">Level 10 (최고관리자)</span>
                </div>
            </div>
            
            <div class="warning">
                <strong>⚠️ 보안 경고</strong><br>
                로그인 후 즉시 비밀번호를 변경하세요!<br>
                이 파일(setup_admin_force.php)을 삭제하세요!
            </div>
            
            <a href="./login.php" class="btn">로그인 페이지로 이동</a>
        </div>
    </body>
    </html>
    ';
} else {
    echo '
    <div style="padding:40px; text-align:center; font-family:sans-serif;">
        <h2 style="color:#dc3545;">❌ 작업 실패</h2>
        <p>데이터베이스 오류가 발생했습니다.</p>
        <p style="color:#666; font-size:14px;">'.sql_error().'</p>
    </div>
    ';
}
?>