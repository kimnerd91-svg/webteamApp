<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include_once('./_common.php');
include_once('../head_sub.php');

$dm_conf = sql_fetch("SELECT cf_ga_id, cf_add_script, cf_gsc_verification, cf_naver_verification, cf_tel, cf_address, cf_sido FROM dm_config WHERE cf_id = 1");
$ga_id = $dm_conf['cf_ga_id'] ?? '';

if (session_status() == PHP_SESSION_NONE) session_start();
$admin = null;
if (isset($_SESSION['admin_id'])) {
    $admin = sql_fetch("SELECT mb_name, mb_level FROM g5_member WHERE mb_id = '{$_SESSION['admin_id']}'");
}
if (!$admin) $admin = ['mb_name' => '관리자', 'mb_level' => 10];

$today     = date('Y-m-d');
$yesterday = date('Y-m-d', strtotime("-1 days"));
$visit_today     = sql_fetch(" SELECT COUNT(*) as cnt FROM {$g5['visit_table']} WHERE vi_date = '{$today}' ");
$visit_yesterday = sql_fetch(" SELECT COUNT(*) as cnt FROM {$g5['visit_table']} WHERE vi_date = '{$yesterday}' ");
$visit_total     = sql_fetch(" SELECT COUNT(*) as cnt FROM {$g5['visit_table']} ");
$count_visit_today     = (int)$visit_today['cnt'];
$count_visit_yesterday = (int)$visit_yesterday['cnt'];
$count_visit_total     = (int)$visit_total['cnt'];
$diff       = $count_visit_today - $count_visit_yesterday;
$diff_text  = ($diff >= 0) ? '+'.number_format($diff) : number_format($diff);
$diff_up    = $diff >= 0;

// ============================================================
// GA4 Data API 설정
// ============================================================
$ga4_property_id   = '';  // GA4 Data API 미사용(대시보드 단순화). 방문 통계는 그누보드 visit 로그 기반.
$ga4_key_file_path = __DIR__ . '/ga4_service_account.json';

function ga4_base64url($data) {
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}
function ga4_get_access_token($key_file) {
    if (!file_exists($key_file)) return null;
    $key = json_decode(file_get_contents($key_file), true);
    if (empty($key['private_key']) || empty($key['client_email'])) return null;
    $now    = time();
    $header = ga4_base64url(json_encode(['alg'=>'RS256','typ'=>'JWT']));
    $claim  = ga4_base64url(json_encode([
        'iss'   => $key['client_email'],
        'scope' => 'https://www.googleapis.com/auth/analytics.readonly',
        'aud'   => 'https://oauth2.googleapis.com/token',
        'iat'   => $now,
        'exp'   => $now + 3600,
    ]));
    $sig_input = $header . '.' . $claim;
    $pkey = openssl_pkey_get_private($key['private_key']);
    if (!$pkey) return null;
    openssl_sign($sig_input, $sig, $pkey, 'SHA256');
    $jwt = $sig_input . '.' . ga4_base64url($sig);
    $ctx = stream_context_create(['http' => [
        'method'  => 'POST',
        'header'  => 'Content-Type: application/x-www-form-urlencoded',
        'content' => http_build_query(['grant_type'=>'urn:ietf:params:oauth:grant-type:jwt-bearer','assertion'=>$jwt]),
        'timeout' => 5,
        'ignore_errors' => true,
    ]]);
    $res = @file_get_contents('https://oauth2.googleapis.com/token', false, $ctx);
    $data = $res ? json_decode($res, true) : [];
    return $data['access_token'] ?? null;
}

function ga4_run_report($property_id, $token, $dimensions, $metrics, $date_range = ['startDate'=>'today','endDate'=>'today']) {
    $url  = "https://analyticsdata.googleapis.com/v1beta/properties/{$property_id}:runReport";
    $body = json_encode([
        'dateRanges' => [$date_range],
        'dimensions' => array_map(fn($d) => ['name'=>$d], $dimensions),
        'metrics'    => array_map(fn($m) => ['name'=>$m], $metrics),
        'limit'      => 50,
    ]);
    $ctx = stream_context_create(['http' => [
        'method'  => 'POST',
        'header'  => "Authorization: Bearer {$token}\r\nContent-Type: application/json",
        'content' => $body,
        'timeout' => 7,
        'ignore_errors' => true,
    ]]);
    $res = @file_get_contents($url, false, $ctx);
    return $res ? json_decode($res, true) : [];
}

$ga4_stats   = [];
$ga4_error   = '';
$ga4_enabled = !empty($ga4_property_id) && file_exists($ga4_key_file_path);

if ($ga4_enabled) {
    $ga4_token = ga4_get_access_token($ga4_key_file_path);
    if ($ga4_token) {
        $r_channel = ga4_run_report($ga4_property_id, $ga4_token, ['sessionDefaultChannelGroup'], ['sessions']);
        $ga4_channel = [];
        foreach ($r_channel['rows'] ?? [] as $row) {
            $ch  = $row['dimensionValues'][0]['value'] ?? 'Unassigned';
            $val = (int)($row['metricValues'][0]['value'] ?? 0);
            $label_map = ['Organic Search'=>'Organic 검색','Direct'=>'Direct','Referral'=>'Referral','Paid Search'=>'유료 검색','Organic Social'=>'SNS','Email'=>'이메일','Unassigned'=>'미분류'];
            $label = $label_map[$ch] ?? $ch;
            $ga4_channel[$label] = ($ga4_channel[$label] ?? 0) + $val;
        }
        arsort($ga4_channel);

        $r_browser = ga4_run_report($ga4_property_id, $ga4_token, ['deviceCategory', 'browser'], ['sessions']);
        $ga4_browser = ['desktop' => [], 'mobile' => [], 'tablet' => []];
        foreach ($r_browser['rows'] ?? [] as $row) {
            $dev = strtolower($row['dimensionValues'][0]['value'] ?? 'desktop');
            $br  = $row['dimensionValues'][1]['value'] ?? 'Etc';
            $val = (int)($row['metricValues'][0]['value'] ?? 0);
            if (!isset($ga4_browser[$dev])) $ga4_browser[$dev] = [];
            $ga4_browser[$dev][$br] = ($ga4_browser[$dev][$br] ?? 0) + $val;
        }
        foreach ($ga4_browser as &$bmap) arsort($bmap);
        unset($bmap);

        $ga4_stats = ['channel' => $ga4_channel, 'browser' => $ga4_browser];

        $r_sess = ga4_run_report($ga4_property_id, $ga4_token, ['date'], ['sessions'], ['startDate'=>'yesterday','endDate'=>'today']);
        $ga4_today_sess = 0; $ga4_yesterday_sess = 0;
        foreach ($r_sess['rows'] ?? [] as $row) {
            $d = $row['dimensionValues'][0]['value'];
            $v = (int)($row['metricValues'][0]['value'] ?? 0);
            if ($d === date('Ymd')) $ga4_today_sess = $v;
            else $ga4_yesterday_sess = $v;
        }
        $r_month = ga4_run_report($ga4_property_id, $ga4_token, [], ['sessions'], ['startDate'=>date('Y-m-01'),'endDate'=>'today']);
        $ga4_month_sess = (int)(($r_month['rows'][0]['metricValues'][0]['value'] ?? 0));
        $ga4_stats['sessions'] = ['today'=>$ga4_today_sess,'yesterday'=>$ga4_yesterday_sess,'month'=>$ga4_month_sess];
    } else {
        $ga4_error = '액세스 토큰 발급 실패 — 서비스 계정 키 파일을 확인하세요.';
    }
} else {
    $res_visit = sql_query(" SELECT vi_agent, vi_referer FROM {$g5['visit_table']} WHERE vi_date = '{$today}' ");
    $stats = ['path'=>['Organic'=>0,'Referral'=>0,'Direct'=>0],'PC'=>['Chrome'=>0,'Whale'=>0,'Edge'=>0,'Safari'=>0,'Etc'=>0],'Mobile'=>['Chrome'=>0,'Whale'=>0,'Safari'=>0,'Samsung'=>0,'Etc'=>0]];
    while ($row = sql_fetch_array($res_visit)) {
        $agent = $row['vi_agent']; $ref = trim($row['vi_referer']);
        if (preg_match('/(bot|crawler|spider|slurp|googlebot|yeti|baiduspider)/i', $agent)) continue;
        $device = preg_match('/(iPhone|Android|BlackBerry|Phone)/i', $agent) ? 'Mobile' : 'PC';
        if (stripos($agent,'Whale')!==false) $stats[$device]['Whale']++;
        elseif (stripos($agent,'Edg')!==false) $stats[$device]['Edge']++;
        elseif (stripos($agent,'SamsungBrowser')!==false) $stats[$device]['Samsung']++;
        elseif (stripos($agent,'Chrome')!==false) $stats[$device]['Chrome']++;
        elseif (stripos($agent,'Safari')!==false) $stats[$device]['Safari']++;
        else $stats[$device]['Etc']++;
        if (!$ref) $stats['path']['Direct']++;
        elseif (preg_match('/(naver\.com|google\.|daum\.net|bing\.com|zum\.com)/i', $ref)) $stats['path']['Organic']++;
        else $stats['path']['Referral']++;
    }
}

$count_board  = sql_fetch(" SELECT count(*) as cnt FROM {$g5['board_table']} ");
$count_member = sql_fetch(" SELECT count(*) as cnt FROM {$g5['member_table']} ");
$board_list   = sql_query(" SELECT bo_table FROM {$g5['board_table']} ");
$write_count  = 0;
while ($board = sql_fetch_array($board_list)) {
    $wt = $g5['write_prefix'] . $board['bo_table'];
    $chk = sql_query("SHOW TABLES LIKE '{$wt}'");
    if (sql_num_rows($chk) > 0) {
        $tmp = sql_fetch("SELECT COUNT(*) as cnt FROM {$wt} WHERE wr_is_comment = 0");
        $write_count += (int)($tmp['cnt'] ?? 0);
    }
}
$count_popup = sql_fetch(" SELECT count(*) as cnt FROM dm_popup WHERE nw_status = 1 ");

// ── SEO 상태 체크 ─────────────────────────────────────────
$doc_root = $_SERVER['DOCUMENT_ROOT'];
$robots_exists = file_exists($doc_root . '/robots.txt');
$robots_status = $robots_exists ? 'green' : 'red';
$robots_label  = $robots_exists ? '정상' : '파일 없음';

$sitemap_path   = $doc_root . '/sitemap.xml';
$sitemap_exists = file_exists($sitemap_path);
if ($sitemap_exists) {
    $sm_content = @file_get_contents($sitemap_path);
    preg_match_all('/<loc>/i', $sm_content, $sm_m);
    $sitemap_url_count = count($sm_m[0]);
    $expected = max(5, $write_count);
    if ($sitemap_url_count >= (int)($expected * 0.6)) {
        $sitemap_status = 'green'; $sitemap_label = $sitemap_url_count . '개 URL';
    } else {
        $sitemap_status = 'yellow'; $sitemap_label = $sitemap_url_count . '개 (일부만)';
    }
} else {
    $sitemap_status = 'red'; $sitemap_url_count = 0; $sitemap_label = '파일 없음';
}

// 구조화 데이터(스키마) 상태 — 스키마는 site_config(병원정보 기반 JS 생성) + PSM(dm_page_seo)에서 출력됨.
// cf_add_script만 보던 옛 방식 폐기. 실제 근거: ① 병원 핵심정보(주소·전화·지역) 입력 → 전역 Dentist 스키마 생성됨,
// ② dm_page_seo에 페이지 스키마가 쌓였는지.
$has_org_info = !empty(trim($dm_conf['cf_tel'] ?? '')) && (!empty(trim($dm_conf['cf_address'] ?? '')) || !empty(trim($dm_conf['cf_sido'] ?? '')));
$psm_count = 0;
$psm_chk = sql_query("SHOW TABLES LIKE 'dm_page_seo'");
if ($psm_chk && sql_num_rows($psm_chk) > 0) {
    $psm_row = sql_fetch("SELECT COUNT(*) AS cnt FROM dm_page_seo WHERE schema_json <> '' AND schema_json IS NOT NULL");
    $psm_count = (int)($psm_row['cnt'] ?? 0);
}
if ($has_org_info && $psm_count > 0) {
    $schema_status = 'green'; $schema_label = '전역 + 페이지 ' . $psm_count . '개';
} elseif ($has_org_info) {
    $schema_status = 'green'; $schema_label = '전역 스키마 생성됨';
} elseif ($psm_count > 0) {
    $schema_status = 'yellow'; $schema_label = '페이지만 (병원정보 입력 필요)';
} else {
    $schema_status = 'red'; $schema_label = '병원정보 입력 필요';
}

$gsc_set = !empty($dm_conf['cf_gsc_verification'] ?? '');
if ($gsc_set && $sitemap_exists) {
    $index_status = 'green'; $index_label = 'GSC 연결 · 사이트맵 있음';
} elseif ($gsc_set || $sitemap_exists) {
    $index_status = 'yellow';
    $index_label  = $gsc_set ? 'GSC 연결 · 사이트맵 없음' : 'GSC 미연결 · 사이트맵만';
} else {
    $index_status = 'red'; $index_label = 'GSC 미연결';
}
$site_domain = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'];
// ── Naver 서치어드바이저 인증 체크 ────────────────────────
$head_sub_path    = dirname(__DIR__) . '/head_sub.php';
$naver_in_head    = false;
if (file_exists($head_sub_path)) {
    $head_sub_content = @file_get_contents($head_sub_path);
    $naver_in_head    = stripos($head_sub_content, 'naver-site-verification') !== false;
}
$naver_in_config = stripos($dm_conf['cf_add_script'] ?? '', 'naver-site-verification') !== false;

if ($naver_in_head || $naver_in_config) {
    $naver_status = 'green';
    $naver_label  = $naver_in_head ? 'head_sub 등록' : 'site_config 등록';
} else {
    $naver_status = 'red';
    $naver_label  = '인증 코드 없음';
}

// ── 최근 게시물 (g5_column + dm_review) ──────────────────
$all_posts = [];

$col_chk = sql_query("SHOW TABLES LIKE 'g5_column'");
if (sql_num_rows($col_chk) > 0) {
    $col_res = sql_query("SELECT id, title, created_at FROM g5_column ORDER BY created_at DESC LIMIT 5");
    while ($c = sql_fetch_array($col_res)) {
        $all_posts[] = [
            'wr_subject'  => $c['title'] ?: '(제목 없음)',
            'wr_datetime' => $c['created_at'],
            'bo_subject'  => '원장님 칼럼',
            'link'        => '/sub/column.php?id=' . (int)$c['id'],
        ];
    }
}
$rev_chk = sql_query("SHOW TABLES LIKE 'dm_review'");
if (sql_num_rows($rev_chk) > 0) {
    $rev_res = sql_query("SELECT id, title, category, created_at FROM dm_review WHERE is_visible = 1 ORDER BY created_at DESC LIMIT 5");
    while ($r = sql_fetch_array($rev_res)) {
        $all_posts[] = [
            'wr_subject'  => $r['title'] ?: $r['category'] ?: '(제목 없음)',
            'wr_datetime' => $r['created_at'],
            'bo_subject'  => '후기',
            'link'        => '/sub/board/review_manager.php?id=' . (int)$r['id'],
        ];
    }
}
usort($all_posts, fn($a, $b) => strtotime($b['wr_datetime']) - strtotime($a['wr_datetime']));
$recent_posts = array_slice($all_posts, 0, 5);

// ── 진행중인 팝업 ─────────────────────────────────────────
$cur_time2    = date('Y-m-d H:i:s');
$popup_result = sql_query(" SELECT nw_id, nw_subject, nw_end_time, nw_img, nw_status FROM dm_popup WHERE nw_status = 1 AND nw_begin_time <= '{$cur_time2}' AND nw_end_time >= '{$cur_time2}' ORDER BY nw_id DESC LIMIT 5 ");
$active_popups = [];
while ($pp = sql_fetch_array($popup_result)) $active_popups[] = $pp;
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>대시보드</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Pretendard', 'Apple SD Gothic Neo', sans-serif; background: #f5f6fa; color: #1a1a2e; }
        #admin_wrapper { display: flex; min-height: 100vh; }
        .content_area { flex: 1; padding: 40px; overflow-x: hidden; }

        .page_header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 32px; }
        .welcome_txt { font-size: 20px; font-weight: 700; color: #1a1a2e; }
        .btn_manual { display: inline-flex; align-items: center; gap: 6px; padding: 9px 18px; background: #4f46e5; color: #fff; border-radius: 8px; font-size: 13px; font-weight: 700; text-decoration: none; box-shadow: 0 4px 12px rgba(79,70,229,0.25); transition: all 0.2s; }
        .btn_manual:hover { background: #4338ca; }
        .btn_manual .material-symbols-outlined { font-size: 16px; }

        .stat_grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 16px; margin-bottom: 28px; }
        .stat_card { background: #fff; border-radius: 12px; padding: 20px; display: flex; align-items: center; gap: 16px; box-shadow: 0 2px 12px rgba(0,0,0,0.06); border: 1px solid #e8eaf0; transition: all 0.2s; }
        .stat_card:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(0,0,0,0.1); }
        .stat_icon { width: 48px; height: 48px; border-radius: 10px; display: flex; align-items: center; justify-content: center; background: #ede9fe; flex-shrink: 0; }
        .stat_icon .material-symbols-outlined { font-size: 24px; color: #4f46e5; }
        .stat_icon.yellow { background: #fef3c7; } .stat_icon.yellow .material-symbols-outlined { color: #d97706; }
        .stat_icon.green  { background: #d1fae5; } .stat_icon.green  .material-symbols-outlined { color: #059669; }
        .stat_icon.gray   { background: #f5f6fa; } .stat_icon.gray   .material-symbols-outlined { color: #5c5c7a; }
        .stat_icon.red    { background: #fee2e2; } .stat_icon.red    .material-symbols-outlined { color: #dc2626; }
        .stat_label { font-size: 12px; color: #9999bb; margin-bottom: 3px; display: flex; align-items: center; gap: 5px; }
        .stat_value { font-size: 22px; font-weight: 700; color: #1a1a2e; }
        .stat_diff { font-size: 11px; font-weight: 700; margin-left: 4px; }
        .diff_up { color: #10b981; } .diff_dn { color: #ef4444; }

        .card { background: #fff; border-radius: 12px; box-shadow: 0 2px 12px rgba(0,0,0,0.06); border: 1px solid #e8eaf0; padding: 24px; margin-bottom: 24px; }
        .card_title { font-size: 16px; font-weight: 700; color: #1a1a2e; margin-bottom: 20px; }

        .quick_grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(120px, 1fr)); gap: 14px; }
        .quick_link { background: #f5f6fa; border-radius: 10px; padding: 18px 12px; display: flex; flex-direction: column; align-items: center; gap: 10px; text-decoration: none; color: #1a1a2e; font-size: 13px; font-weight: 600; border: 1px solid #e8eaf0; transition: all 0.2s; }
        .quick_link .material-symbols-outlined { font-size: 28px; color: #4f46e5; }
        .quick_link:hover { background: #4f46e5; color: #fff; transform: translateY(-2px); box-shadow: 0 6px 16px rgba(79,70,229,0.25); }
        .quick_link:hover .material-symbols-outlined { color: #fff; }

        .analysis_grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 16px; }
        .analysis_box { background: #f5f6fa; border-radius: 10px; padding: 20px; border: 1px solid #e8eaf0; }
        .analysis_label { font-size: 13px; font-weight: 700; color: #1a1a2e; margin-bottom: 16px; }
        .bar_row { margin-bottom: 12px; }
        .bar_info { display: flex; justify-content: space-between; font-size: 12px; color: #5c5c7a; margin-bottom: 5px; }
        .bar_bg { background: #e8eaf0; height: 5px; border-radius: 5px; overflow: hidden; }
        .bar_fill { height: 100%; border-radius: 5px; background: #4f46e5; transition: width 0.8s ease; }
        .bar_fill.orange { background: #f59e0b; }

        .ext_btns { display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 16px; }
        .ext_btn { display: inline-flex; align-items: center; gap: 6px; padding: 9px 18px; border-radius: 8px; font-size: 13px; font-weight: 700; text-decoration: none; transition: all 0.2s; }
        .ext_btn.purple { background: #4f46e5; color: #fff; }
        .ext_btn.gray   { background: #f5f6fa; color: #1a1a2e; border: 1px solid #e8eaf0; }
        .ext_btn:hover  { filter: brightness(1.1); transform: translateY(-1px); }
        .ext_btn .material-symbols-outlined { font-size: 16px; }

        .info_box { background: #f5f6fa; border-radius: 8px; padding: 16px 18px; font-size: 13px; color: #5c5c7a; line-height: 1.7; }
        .info_box strong { color: #4f46e5; }

        .dash_table { width: 100%; border-collapse: collapse; }
        .dash_table th { font-size: 11px; font-weight: 700; color: #9999bb; padding: 0 0 10px; text-align: left; border-bottom: 1px solid #e8eaf0; }
        .dash_table th.tc { text-align: center; }
        .dash_table td { padding: 11px 0; border-bottom: 1px solid #f5f5f5; font-size: 13px; vertical-align: middle; }
        .dash_table tbody tr:last-child td { border-bottom: none; }
        .dash_table .post_title { font-weight: 600; color: #1a1a2e; max-width: 260px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; display: block; }
        .dash_table .post_title:hover { color: #4f46e5; }
        .dash_table .board_badge { display: inline-block; background: #ede9fe; color: #4f46e5; font-size: 10px; font-weight: 700; padding: 2px 7px; border-radius: 20px; margin-left: 6px; vertical-align: middle; }
        .dash_table .post_date { font-size: 12px; color: #9999bb; white-space: nowrap; }
        .pop_thumb { width: 48px; height: 32px; object-fit: cover; border-radius: 6px; border: 1px solid #e8eaf0; display: block; }
        .pop_thumb_ph { width: 48px; height: 32px; background: #f5f6fa; border-radius: 6px; border: 1px solid #e8eaf0; display: flex; align-items: center; justify-content: center; font-size: 14px; }
        .pop_d_day { font-size: 11px; font-weight: 700; color: #ef4444; }
        .pop_d_safe { color: #10b981; }
        .dash_act { display: flex; gap: 6px; justify-content: center; }
        .dash_btn { padding: 5px 11px; border-radius: 6px; font-size: 11px; font-weight: 700; text-decoration: none; border: none; cursor: pointer; transition: all 0.15s; }
        .dash_btn.edit { background: #ede9fe; color: #4f46e5; }
        .dash_btn.edit:hover { background: #4f46e5; color: #fff; }
        .dash_btn.off  { background: #fee2e2; color: #dc2626; }
        .dash_btn.off:hover  { background: #dc2626; color: #fff; }
        .card_title_row { display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px; }
        .card_title_row .card_title { margin-bottom: 0; }
        .card_more { font-size: 12px; color: #4f46e5; font-weight: 700; text-decoration: none; }
        .card_more:hover { text-decoration: underline; }

        /* 신호등 */
        .seo_dot { width: 10px; height: 10px; border-radius: 50%; display: inline-block; flex-shrink: 0; }
        .seo_dot.green  { background: #10b981; box-shadow: 0 0 5px rgba(16,185,129,0.5); }
        .seo_dot.yellow { background: #f59e0b; box-shadow: 0 0 5px rgba(245,158,11,0.5); }
        .seo_dot.red    { background: #ef4444; box-shadow: 0 0 5px rgba(239,68,68,0.5); }
        .seo_val { font-size: 14px; font-weight: 700; color: #1a1a2e; }
        .seo_link { font-size: 11px; color: #4f46e5; font-weight: 700; text-decoration: none; display: block; margin-top: 4px; }
        .seo_link:hover { text-decoration: underline; }

        /* GA 미연결 배너 */
        .ga_banner { background: #fff7ed; border: 1px solid #fed7aa; border-radius: 10px; padding: 12px 18px; font-size: 13px; color: #92400e; display: flex; align-items: center; gap: 10px; margin-bottom: 28px; }
        .ga_banner a { color: #4f46e5; font-weight: 700; text-decoration: none; }
    </style>
</head>
<body>
<div id="admin_wrapper">
    <?php include_once('./aside.php'); ?>

    <main class="content_area">

        <div class="page_header">
            <p class="welcome_txt">환영합니다, <strong><?= htmlspecialchars($admin['mb_name']) ?></strong>님!</p>
            <a target="_blank" href="./howtouse.pdf" class="btn_manual">
                <span class="material-symbols-outlined">menu_book</span> 사용설명서
            </a>
        </div>

        <!-- 주요 통계 -->
        <div class="stat_grid">
            <div class="stat_card">
                <div class="stat_icon"><span class="material-symbols-outlined">group</span></div>
                <div><p class="stat_label">전체 회원</p><p class="stat_value"><?= number_format($count_member['cnt']) ?></p></div>
            </div>
            <?php
            $dot_map = ['green'=>'#10b981','yellow'=>'#f59e0b','red'=>'#ef4444'];
            $bg_map  = ['green'=>'#d1fae5','yellow'=>'#fef3c7','red'=>'#fee2e2'];
            $seo_cards = [
                ['label'=>'robots.txt',         'status'=>$robots_status, 'value'=>$robots_label,  'icon'=>'robot_2',      'sub'=>$robots_exists?'파일 보기':'',         'link'=>$site_domain.'/robots.txt'],
                ['label'=>'sitemap.xml',         'status'=>$sitemap_status,'value'=>$sitemap_label, 'icon'=>'travel_explore','sub'=>$sitemap_exists?'사이트맵 보기':'',    'link'=>$site_domain.'/sitemap.xml'],
                ['label'=>'구조화 데이터(스키마)','status'=>$schema_status, 'value'=>$schema_label,  'icon'=>'code',         'sub'=>$schema_status!=='green'?'자동생성':'', 'link'=>'/newadm/config/site_config.php'],
                ['label'=>'색인 연결',            'status'=>$index_status,  'value'=>$index_label,  'icon'=>'manage_search', 'sub'=>'GSC에서 확인',                        'link'=>'https://search.google.com/search-console?resource_id='.urlencode($site_domain)],
                 ['label'=>'Naver 서치어드바이저',  'status'=>$naver_status,   'value'=>$naver_label,   'icon'=>'verified_user', 'sub'=>$naver_status !== 'green' ? '등록하러 가기' : '', 'link'=>'https://searchadvisor.naver.com/console/board'],
            ];
            foreach ($seo_cards as $sc):
            ?>
            <div class="stat_card">
                <div class="stat_icon" style="background:<?= $bg_map[$sc['status']] ?>; flex-shrink:0;">
                    <span class="material-symbols-outlined" style="color:<?= $dot_map[$sc['status']] ?>;"><?= $sc['icon'] ?></span>
                </div>
                <div style="min-width:0;">
                    <p class="stat_label"><?= $sc['label'] ?> <span class="seo_dot <?= $sc['status'] ?>"></span></p>
                    <p class="seo_val"><?= htmlspecialchars($sc['value']) ?></p>
                    <?php if ($sc['sub']): ?>
                    <a href="<?= $sc['link'] ?>" target="_blank" class="seo_link">→ <?= $sc['sub'] ?></a>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- 최근 게시물 + 팝업 현황 -->
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:24px; margin-bottom:24px;">

            <div class="card" style="margin-bottom:0;">
                <div class="card_title_row">
                    <p class="card_title">최근 게시물</p>
                    <div style="display:flex;gap:10px;">
                        <a href="/newadm/board/column_admin.php" class="card_more">칼럼 →</a>
                        <a href="/newadm/board/review_manager.php" class="card_more">후기 →</a>
                    </div>
                </div>
                <?php if (!empty($recent_posts)): ?>
                <table class="dash_table">
                    <thead><tr><th>제목</th><th class="tc" style="width:100px;">작성일</th></tr></thead>
                    <tbody>
                    <?php foreach ($recent_posts as $post): ?>
                        <tr>
                            <td>
                                <a href="<?= $post['link'] ?>" target="_blank" class="post_title">
                                    <?= htmlspecialchars($post['wr_subject']) ?>
                                </a>
                                <span class="board_badge"><?= htmlspecialchars($post['bo_subject']) ?></span>
                            </td>
                            <td class="post_date" style="text-align:center;"><?= substr($post['wr_datetime'], 2, 14) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <?php else: ?>
                    <div style="text-align:center; padding:30px; color:#9999bb; font-size:13px;">등록된 게시물이 없습니다.</div>
                <?php endif; ?>
            </div>

            <div class="card" style="margin-bottom:0;">
                <div class="card_title_row">
                    <p class="card_title">진행중인 팝업</p>
                    <a href="/newadm/content/popup_manager.php" class="card_more">팝업 관리 →</a>
                </div>
                <?php if (!empty($active_popups)): ?>
                <table class="dash_table">
                    <thead><tr><th style="width:52px;"></th><th>제목</th><th class="tc" style="width:70px;">만료</th><th class="tc" style="width:90px;">관리</th></tr></thead>
                    <tbody>
                    <?php foreach ($active_popups as $pp):
                        $end_ts   = strtotime($pp['nw_end_time']);
                        $diff_sec = $end_ts - time();
                        $diff_day = ceil($diff_sec / 86400);
                        $d_class  = $diff_day <= 3 ? 'pop_d_day' : 'pop_d_day pop_d_safe';
                        $img_url  = $pp['nw_img'] ? G5_DATA_URL . '/popup/' . $pp['nw_img'] : '';
                    ?>
                        <tr>
                            <td><?php if ($img_url): ?><img src="<?= htmlspecialchars($img_url) ?>" class="pop_thumb" alt=""><?php else: ?><div class="pop_thumb_ph">🖼️</div><?php endif; ?></td>
                            <td><a href="/newadm/content/popup_form.php?nw_id=<?= $pp['nw_id'] ?>" class="post_title" style="max-width:160px;"><?= htmlspecialchars($pp['nw_subject']) ?></a></td>
                            <td style="text-align:center;"><span class="<?= $d_class ?>">D-<?= $diff_day ?></span></td>
                            <td>
                                <div class="dash_act">
                                    <a href="/newadm/content/popup_form.php?nw_id=<?= $pp['nw_id'] ?>" class="dash_btn edit">수정</a>
                                    <a href="/newadm/content/popup_update.php?mode=d&nw_id=<?= $pp['nw_id'] ?>" class="dash_btn off" onclick="return confirm('팝업을 삭제하시겠습니까?')">삭제</a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <?php else: ?>
                    <div style="text-align:center; padding:30px; color:#9999bb; font-size:13px;">진행중인 팝업이 없습니다.</div>
                <?php endif; ?>
            </div>
        </div>

        <!-- 바로가기 -->
        <div class="card">
            <p class="card_title">빠른 바로가기</p>
            <div class="quick_grid">
                <a href="/newadm/config/site_config.php" class="quick_link"><span class="material-symbols-outlined">settings</span>기본정보</a>
                <a href="/newadm/content/popup_manager.php" class="quick_link"><span class="material-symbols-outlined">campaign</span>팝업 관리</a>
                <a href="/newadm/member/member_manager.php" class="quick_link"><span class="material-symbols-outlined">group</span>회원 관리</a>
                <a href="/newadm/board/board_manager.php" class="quick_link"><span class="material-symbols-outlined">article</span>게시물 관리</a>
            </div>
        </div>

        <!-- 유입 분석 -->
        <div class="card">
            <p class="card_title">
                유입 경로 및 디바이스 분석 (오늘)
                <?php if ($ga4_enabled): ?>
                    <span style="font-size:11px;font-weight:500;color:#10b981;margin-left:8px;">● GA4 실제 데이터</span>
                <?php else: ?>
                    <span style="font-size:11px;font-weight:500;color:#f59e0b;margin-left:8px;">● Referer 추정값</span>
                <?php endif; ?>
            </p>

            <?php if ($ga4_error): ?>
                <div style="background:#fee2e2;border-radius:8px;padding:14px 16px;font-size:13px;color:#dc2626;margin-bottom:16px;">
                    ⚠️ GA4 연결 오류: <?= htmlspecialchars($ga4_error) ?>
                </div>
            <?php endif; ?>

            <?php if ($ga4_enabled && !empty($ga4_stats)): ?>
                <div class="analysis_grid">
                    <div class="analysis_box">
                        <p class="analysis_label">유입 채널</p>
                        <?php $total = array_sum($ga4_stats['channel']); foreach ($ga4_stats['channel'] as $nm => $v): $per = $total > 0 ? round($v/$total*100) : 0; ?>
                        <div class="bar_row">
                            <div class="bar_info"><span><?= htmlspecialchars($nm) ?></span><span><?= number_format($v) ?>세션 (<?= $per ?>%)</span></div>
                            <div class="bar_bg"><div class="bar_fill" style="width:<?= $per ?>%"></div></div>
                        </div>
                        <?php endforeach; ?>
                        <?php if (empty($ga4_stats['channel'])): ?><p style="font-size:12px;color:#9999bb;">오늘 데이터 없음</p><?php endif; ?>
                    </div>
                    <div class="analysis_box">
                        <p class="analysis_label">PC / 태블릿 브라우저</p>
                        <?php $desk = array_merge($ga4_stats['browser']['desktop']??[],$ga4_stats['browser']['tablet']??[]); arsort($desk); $total_d = array_sum($desk);
                        foreach ($desk as $br => $v): $per = $total_d > 0 ? round($v/$total_d*100) : 0; ?>
                        <div class="bar_row">
                            <div class="bar_info"><span><?= htmlspecialchars($br) ?></span><span><?= number_format($v) ?>건</span></div>
                            <div class="bar_bg"><div class="bar_fill" style="width:<?= $per ?>%"></div></div>
                        </div>
                        <?php endforeach; ?>
                        <?php if (empty($desk)): ?><p style="font-size:12px;color:#9999bb;">오늘 데이터 없음</p><?php endif; ?>
                    </div>
                    <div class="analysis_box">
                        <p class="analysis_label">모바일 브라우저</p>
                        <?php $mob = $ga4_stats['browser']['mobile']??[]; $total_m = array_sum($mob);
                        foreach ($mob as $br => $v): $per = $total_m > 0 ? round($v/$total_m*100) : 0; ?>
                        <div class="bar_row">
                            <div class="bar_info"><span><?= htmlspecialchars($br) ?></span><span><?= number_format($v) ?>건</span></div>
                            <div class="bar_bg"><div class="bar_fill orange" style="width:<?= $per ?>%"></div></div>
                        </div>
                        <?php endforeach; ?>
                        <?php if (empty($mob)): ?><p style="font-size:12px;color:#9999bb;">오늘 데이터 없음</p><?php endif; ?>
                    </div>
                </div>
            <?php else: ?>
                <div class="analysis_grid">
                    <div class="analysis_box">
                        <p class="analysis_label">유입 경로</p>
                        <?php $pt = array_sum($stats['path']); foreach ($stats['path'] as $nm => $v): $per = $pt > 0 ? round($v/$pt*100) : 0; ?>
                        <div class="bar_row"><div class="bar_info"><span><?= $nm ?></span><span><?= $v ?>명 (<?= $per ?>%)</span></div><div class="bar_bg"><div class="bar_fill" style="width:<?= $per ?>%"></div></div></div>
                        <?php endforeach; ?>
                    </div>
                    <div class="analysis_box">
                        <p class="analysis_label">PC 브라우저</p>
                        <?php $pt = array_sum($stats['PC']); foreach ($stats['PC'] as $nm => $v): $per = $pt > 0 ? round($v/$pt*100) : 0; ?>
                        <div class="bar_row"><div class="bar_info"><span><?= $nm ?></span><span><?= $v ?>건</span></div><div class="bar_bg"><div class="bar_fill" style="width:<?= $per ?>%"></div></div></div>
                        <?php endforeach; ?>
                    </div>
                    <div class="analysis_box">
                        <p class="analysis_label">모바일 브라우저</p>
                        <?php $pt = array_sum($stats['Mobile']); foreach ($stats['Mobile'] as $nm => $v): $per = $pt > 0 ? round($v/$pt*100) : 0; ?>
                        <div class="bar_row"><div class="bar_info"><span><?= $nm ?></span><span><?= $v ?>건</span></div><div class="bar_bg"><div class="bar_fill orange" style="width:<?= $per ?>%"></div></div></div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div style="margin-top:14px;font-size:12px;color:#9999bb;">GA4를 연결하면 더 정확한 데이터를 볼 수 있습니다.</div>
            <?php endif; ?>
        </div>

        <?php if ($ga_id): ?>
        <div class="card">
            <p class="card_title">Google Analytics</p>
            <div class="ext_btns">
                <a href="https://analytics.google.com" target="_blank" class="ext_btn purple"><span class="material-symbols-outlined">bar_chart</span>GA4 열기</a>
                <a href="https://tagmanager.google.com" target="_blank" class="ext_btn gray"><span class="material-symbols-outlined">sell</span>태그 관리자</a>
                <a href="https://search.google.com/search-console" target="_blank" class="ext_btn gray"><span class="material-symbols-outlined">search</span>Search Console</a>
            </div>
            <div class="info_box">측정 ID: <strong><?= htmlspecialchars($ga_id) ?></strong> — GA4 대시보드에서 실시간 데이터를 확인하세요.</div>
        </div>
        <?php endif; ?>

        <div class="card">
            <p class="card_title">최근 활동</p>
            <div class="info_box">
                최근 로그인: <?= date('Y-m-d H:i:s') ?><br>
                관리자 레벨: Level <?= $admin['mb_level'] ?><br>
                시스템 상태: <strong style="color:#10b981;">정상 운영중</strong>
            </div>
        </div>

    </main>
</div>
</body>
</html>