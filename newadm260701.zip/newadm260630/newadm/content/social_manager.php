<?php
include_once('../_common.php');
include_once('../_auth_check.php');
if (!$is_admin) { header('Location: /bbs/login.php?url='.urlencode($_SERVER['REQUEST_URI'])); exit; }
global $connect_db; $db = $connect_db;

/* ============================================================
   social_manager.php — 유튜브(RSS 자동) + 인스타(수동) 통합 소셜 매니저
   데이터: dm_social 한 테이블. 프론트는 social_render()로 single/grid/list/mixed 출력.
   ============================================================ */

// ── 테이블 자동 생성 ──
sql_query("CREATE TABLE IF NOT EXISTS `dm_social` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `platform` VARCHAR(20) NOT NULL DEFAULT 'youtube',   /* youtube / instagram */
    `source` VARCHAR(10) NOT NULL DEFAULT 'manual',      /* auto(rss) / manual */
    `title` VARCHAR(500) DEFAULT '',
    `url` VARCHAR(1000) DEFAULT '',
    `thumbnail` VARCHAR(1000) DEFAULT '',
    `video_id` VARCHAR(50) DEFAULT '',                   /* 유튜브 영상ID (사이트내 재생용) */
    `caption` TEXT,
    `pub_date` DATETIME DEFAULT NULL,
    `guid` VARCHAR(255) DEFAULT '',                      /* 자동수집 중복방지 */
    `is_visible` TINYINT(1) DEFAULT 1,
    `display_order` INT(11) DEFAULT 0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `platform` (`platform`),
    KEY `guid` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$dm_conf = sql_fetch("SELECT cf_youtube FROM dm_config WHERE cf_id = 1");
$cf_youtube = $dm_conf['cf_youtube'] ?? '';

// ── 공통 fetch (블로그 매니저 패턴) ──
function sm_fetch($url) {
    $ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0.0.0 Safari/537.36';
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER=>true, CURLOPT_FOLLOWLOCATION=>true, CURLOPT_TIMEOUT=>10,
            CURLOPT_MAXREDIRS=>5, CURLOPT_USERAGENT=>$ua, CURLOPT_SSL_VERIFYPEER=>false,
        ]);
        $body = curl_exec($ch); $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
        return ($code>=200 && $code<400) ? $body : false;
    }
    $ctx = stream_context_create(['http'=>['timeout'=>10,'user_agent'=>$ua]]);
    return @file_get_contents($url, false, $ctx);
}

// ── 채널 URL → channel_id 추출 (/channel/UC.. 직접, @핸들/커스텀은 페이지에서 추출) ──
function sm_resolve_channel_id($url) {
    if (preg_match('#youtube\.com/channel/(UC[\w-]+)#', $url, $m)) return $m[1];
    // @handle, /c/, /user/ 형태 → 페이지 HTML에서 channelId 추출
    $html = sm_fetch($url);
    if ($html && preg_match('#"channelId":"(UC[\w-]+)"#', $html, $m)) return $m[1];
    if ($html && preg_match('#<link rel="canonical" href="https://www\.youtube\.com/channel/(UC[\w-]+)">#', $html, $m)) return $m[1];
    return '';
}

// ============================================================
// AJAX
// ============================================================
if ($_SERVER['REQUEST_METHOD']==='POST' && !empty($_POST['action'])) {
    header('Content-Type: application/json; charset=utf-8');
    $a = $_POST['action'];

    // 유튜브 RSS 동기화
    if ($a === 'sync_youtube') {
        if (!$cf_youtube) { echo json_encode(['success'=>0,'message'=>'사이트 설정(cf_youtube)에 유튜브 채널 주소가 없습니다.']); exit; }
        $cid = sm_resolve_channel_id($cf_youtube);
        if (!$cid) { echo json_encode(['success'=>0,'message'=>'채널 ID를 찾지 못했습니다. 채널 URL을 확인하세요.']); exit; }

        $rss = "https://www.youtube.com/feeds/videos.xml?channel_id={$cid}";
        $xml_raw = sm_fetch($rss);
        if (!$xml_raw) { echo json_encode(['success'=>0,'message'=>'RSS 수집 실패']); exit; }
        $xml = @simplexml_load_string($xml_raw);
        if (!$xml) { echo json_encode(['success'=>0,'message'=>'RSS 파싱 실패']); exit; }

        $yt = $xml->children('http://www.youtube.com/xml/schemas/2015');
        $media_ns = 'http://search.yahoo.com/mrss/';
        $new = 0; $ord = 0;
        foreach ($xml->entry as $entry) {
            $ytc = $entry->children('http://www.youtube.com/xml/schemas/2015');
            $vid = (string)$ytc->videoId;
            if (!$vid) continue;
            $guid = 'yt_' . $vid;
            $exist = sql_fetch("SELECT id FROM dm_social WHERE guid='".sql_escape_string($guid)."' LIMIT 1");
            if ($exist) continue;

            $title = sql_escape_string((string)$entry->title);
            $link  = sql_escape_string((string)$entry->link['href']);
            $thumb = "https://i.ytimg.com/vi/{$vid}/hqdefault.jpg";
            $pub   = date('Y-m-d H:i:s', strtotime((string)$entry->published));
            sql_query("INSERT INTO dm_social (platform, source, title, url, thumbnail, video_id, pub_date, guid, display_order)
                       VALUES ('youtube','auto','$title','$link','$thumb','".sql_escape_string($vid)."','$pub','".sql_escape_string($guid)."', $ord)");
            $new++; $ord++;
        }
        echo json_encode(['success'=>1,'new'=>$new,'channel_id'=>$cid]); exit;
    }

    // 인스타 수동 추가 (이미지+링크+캡션)
    if ($a === 'add_instagram') {
        $title = sql_escape_string(trim($_POST['title'] ?? ''));
        $url   = sql_escape_string(trim($_POST['url'] ?? ''));
        $thumb = sql_escape_string(trim($_POST['thumbnail'] ?? ''));
        $cap   = sql_escape_string(trim($_POST['caption'] ?? ''));
        if (!$url || !$thumb) { echo json_encode(['success'=>0,'message'=>'링크와 이미지는 필수입니다.']); exit; }
        sql_query("INSERT INTO dm_social (platform, source, title, url, thumbnail, caption, pub_date)
                   VALUES ('instagram','manual','$title','$url','$thumb','$cap', NOW())");
        echo json_encode(['success'=>1]); exit;
    }

    if ($a === 'toggle') {
        $id=(int)$_POST['id']; $v=(int)$_POST['v'];
        sql_query("UPDATE dm_social SET is_visible=$v WHERE id=$id");
        echo json_encode(['success'=>1]); exit;
    }
    if ($a === 'delete') {
        $id=(int)$_POST['id'];
        sql_query("DELETE FROM dm_social WHERE id=$id");
        echo json_encode(['success'=>1]); exit;
    }
    echo json_encode(['success'=>0,'message'=>'unknown']); exit;
}

// 목록
$rows = [];
$r = sql_query("SELECT * FROM dm_social ORDER BY pub_date DESC, id DESC");
while ($row = sql_fetch_array($r)) $rows[] = $row;
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>소셜 관리</title>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'Pretendard','Apple SD Gothic Neo',sans-serif;background:#f5f6fa;color:#1a1a2e;}
#admin_wrapper{display:flex;min-height:100vh;}
.content_area{flex:1;padding:40px;overflow-x:hidden;display:flex;flex-direction:column;gap:20px;}
.page_header{display:flex;align-items:center;justify-content:space-between;}
.page_title{font-size:22px;font-weight:700;display:flex;align-items:center;gap:10px;}
.card{background:#fff;border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,.06);border:1px solid #e8eaf0;overflow:hidden;}
.card_hd{padding:14px 20px;border-bottom:1px solid #e8eaf0;display:flex;align-items:center;justify-content:space-between;gap:10px;}
.card_hd_title{font-size:14px;font-weight:700;display:flex;align-items:center;gap:6px;}
.card_hd_title .material-symbols-outlined{font-size:16px;color:#4f46e5;}
.card_body{padding:20px;}
.btn_primary{padding:9px 20px;background:#4f46e5;color:#fff;border:none;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer;transition:all .2s;display:inline-flex;align-items:center;gap:5px;font-family:inherit;}
.btn_primary:hover{background:#4338ca;}
.btn_primary:disabled{opacity:.5;cursor:not-allowed;}
.btn_neutral{padding:9px 16px;background:#f5f6fa;color:#5c5c7a;border:1px solid #e8eaf0;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer;transition:all .2s;display:inline-flex;align-items:center;gap:5px;font-family:inherit;}
.btn_neutral:hover{background:#e8eaf0;}
.btn_del{padding:5px 12px;background:#fee2e2;color:#dc2626;border:none;border-radius:6px;font-size:11px;font-weight:700;cursor:pointer;}
.btn_del:hover{background:#dc2626;color:#fff;}
.form_group{margin-bottom:14px;}
.form_group label{display:block;font-size:12px;font-weight:700;color:#9999bb;margin-bottom:5px;}
.form_input{width:100%;padding:9px 12px;border:1px solid #e8eaf0;border-radius:8px;font-size:13px;background:#f5f6fa;color:#1a1a2e;font-family:inherit;transition:all .2s;outline:none;}
.form_input:focus{border-color:#4f46e5;background:#fff;box-shadow:0 0 0 3px rgba(79,70,229,.1);}
textarea.form_input{resize:vertical;min-height:60px;line-height:1.6;}
.btn_row{display:flex;align-items:center;gap:10px;margin-top:6px;flex-wrap:wrap;}
.muted{color:#9999bb;font-size:12.5px;}
.info_box{background:#ede9fe;border-radius:10px;padding:14px 18px;font-size:13px;color:#4f46e5;line-height:1.7;}
.info_box code,.card_body code{background:#fff;border:1px solid #d6d0fb;padding:1px 6px;border-radius:4px;font-size:12px;color:#4f46e5;}
.cur_chan{font-size:12.5px;color:#5c5c7a;margin-bottom:12px;}
.cur_chan .none{color:#dc2626;font-weight:700;}
/* 폼 그리드 */
.ig_grid{display:grid;grid-template-columns:1fr 1fr;gap:14px;}
@media(max-width:680px){.ig_grid{grid-template-columns:1fr;}}
/* 테이블 */
.eq_table{width:100%;border-collapse:collapse;}
.eq_table thead tr{background:#fafafa;border-bottom:1px solid #e8eaf0;}
.eq_table th{padding:10px 14px;font-size:11px;font-weight:700;color:#9999bb;text-transform:uppercase;letter-spacing:.05em;text-align:left;}
.eq_table td{padding:11px 14px;border-bottom:1px solid #f5f5f5;font-size:13px;vertical-align:middle;}
.eq_table tbody tr:hover{background:#fafbff;}
.eq_table tbody tr:last-child td{border-bottom:none;}
.thumb{width:64px;height:40px;object-fit:cover;border-radius:6px;border:1px solid #e8eaf0;}
.ttl-cell{max-width:300px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:600;}
.badge{display:inline-flex;align-items:center;gap:3px;padding:3px 10px;border-radius:20px;font-size:11px;font-weight:700;}
.badge.youtube{background:#fee2e2;color:#dc2626;}
.badge.instagram{background:#fce7f3;color:#db2777;}
.src-badge{padding:2px 9px;border-radius:20px;font-size:11px;font-weight:700;background:#eef2ff;color:#4f46e5;}
.src-badge.manual{background:#f0fdf4;color:#059669;}
.empty_state{text-align:center;padding:48px;color:#9999bb;font-size:14px;}
/* 노출 토글 */
.switch{position:relative;display:inline-block;width:40px;height:22px;}
.switch input{opacity:0;width:0;height:0;}
.slider{position:absolute;cursor:pointer;inset:0;background:#d1d5e0;border-radius:11px;transition:.3s;}
.slider:before{position:absolute;content:'';height:16px;width:16px;left:3px;bottom:3px;background:#fff;border-radius:50%;transition:.3s;}
.switch input:checked+.slider{background:#4f46e5;}
.switch input:checked+.slider:before{transform:translateX(18px);}
/* 토스트 */
.toast{position:fixed;top:20px;right:20px;padding:12px 18px;border-radius:10px;font-size:13px;font-weight:600;display:flex;align-items:center;gap:7px;z-index:1000001!important;box-shadow:0 4px 16px rgba(0,0,0,.12);animation:tin .22s ease;}
.toast.ok{background:#f0fdf4;border:1px solid #bbf7d0;color:#059669;}
.toast.error{background:#fef2f2;border:1px solid #fecaca;color:#dc2626;}
@keyframes tin{from{opacity:0;transform:translateX(12px)}to{opacity:1;transform:none}}
.spin{animation:spin 1s linear infinite;}
@keyframes spin{to{transform:rotate(360deg);}}
</style>
</head>
<body>
<div id="admin_wrapper">
    <?php include_once('../aside.php'); ?>
    <main class="content_area">

        <div class="page_header">
            <h2 class="page_title">
                <span class="material-symbols-outlined" style="font-size:22px;color:#4f46e5;">share</span>
                소셜 관리
            </h2>
        </div>

        <!-- 안내 -->
        <div class="info_box">
            <strong>💡 사용법</strong> — 유튜브는 사이트 설정의 채널 주소(<code>cf_youtube</code>)에서 <b>자동 수집</b>, 인스타는 <b>수동 등록</b>합니다. 프론트에는 <code>social_render(['mode'=>'grid'])</code> 형태로 single/grid/list/mixed 출력됩니다.
        </div>

        <!-- ① 유튜브 자동 수집 -->
        <div class="card">
            <div class="card_hd">
                <span class="card_hd_title"><span class="material-symbols-outlined">smart_display</span>① 유튜브 자동 수집</span>
            </div>
            <div class="card_body">
                <p class="cur_chan">현재 채널: <?= $cf_youtube ? htmlspecialchars($cf_youtube) : '<span class="none">cf_youtube 미설정</span> — 사이트 설정에서 채널 URL 입력' ?></p>
                <div class="btn_row">
                    <button class="btn_primary" id="ytBtn" onclick="syncYT()"><span class="material-symbols-outlined" style="font-size:15px;">sync</span>최신 영상 가져오기</button>
                    <span id="ytStat" class="muted"></span>
                </div>
            </div>
        </div>

        <!-- ② 인스타 수동 등록 -->
        <div class="card">
            <div class="card_hd">
                <span class="card_hd_title"><span class="material-symbols-outlined">add_photo_alternate</span>② 인스타 수동 등록</span>
            </div>
            <div class="card_body">
                <div class="ig_grid">
                    <div class="form_group">
                        <label>게시물 링크 <span style="color:#dc2626;">*</span></label>
                        <input type="text" id="ig_url" class="form_input" placeholder="https://www.instagram.com/p/...">
                    </div>
                    <div class="form_group">
                        <label>이미지 URL <span style="color:#dc2626;">*</span></label>
                        <input type="text" id="ig_thumb" class="form_input" placeholder="이미지 주소">
                    </div>
                </div>
                <div class="form_group">
                    <label>제목 (선택)</label>
                    <input type="text" id="ig_title" class="form_input" placeholder="제목">
                </div>
                <div class="form_group">
                    <label>캡션 (선택)</label>
                    <textarea id="ig_caption" class="form_input" rows="2" placeholder="캡션"></textarea>
                </div>
                <div class="btn_row">
                    <button class="btn_primary" onclick="addIG()"><span class="material-symbols-outlined" style="font-size:15px;">add</span>인스타 카드 추가</button>
                    <span id="igStat" class="muted"></span>
                </div>
            </div>
        </div>

        <!-- ③ 등록된 콘텐츠 -->
        <div class="card">
            <div class="card_hd">
                <span class="card_hd_title"><span class="material-symbols-outlined">grid_view</span>③ 등록된 콘텐츠</span>
                <span class="muted"><?= count($rows) ?>개</span>
            </div>
            <?php if ($rows): ?>
            <table class="eq_table">
                <thead><tr><th>플랫폼</th><th>썸네일</th><th>제목</th><th>수집</th><th>노출</th><th style="text-align:center;">관리</th></tr></thead>
                <tbody>
                <?php foreach ($rows as $row): ?>
                    <tr id="srow-<?= $row['id'] ?>">
                        <td><span class="badge <?= $row['platform'] ?>"><?= $row['platform']==='youtube'?'▶ YouTube':'Instagram' ?></span></td>
                        <td><?php if($row['thumbnail']):?><img src="<?= htmlspecialchars($row['thumbnail']) ?>" class="thumb" alt=""><?php else:?><span class="muted">-</span><?php endif;?></td>
                        <td class="ttl-cell"><?= htmlspecialchars($row['title'] ?: $row['caption']) ?></td>
                        <td><span class="src-badge <?= $row['source']==='auto'?'':'manual' ?>"><?= $row['source']==='auto'?'자동':'수동' ?></span></td>
                        <td>
                            <label class="switch">
                                <input type="checkbox" <?= $row['is_visible']?'checked':'' ?> onchange="tog(<?= $row['id'] ?>,this.checked?1:0)">
                                <span class="slider"></span>
                            </label>
                        </td>
                        <td style="text-align:center;"><button class="btn_del" onclick="del(<?= $row['id'] ?>)">삭제</button></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php else: ?>
            <div class="empty_state">등록된 콘텐츠가 없습니다.</div>
            <?php endif; ?>
        </div>

    </main>
</div>

<script>
function post(d,cb){var f=new FormData();for(var k in d)f.append(k,d[k]);
  fetch(location.href,{method:'POST',body:f}).then(r=>r.json()).then(cb).catch(function(){showToast('통신 오류','error');});}

function syncYT(){
  var btn=document.getElementById('ytBtn'), ico=btn.querySelector('.material-symbols-outlined');
  document.getElementById('ytStat').textContent='수집 중…'; btn.disabled=true; if(ico)ico.classList.add('spin');
  post({action:'sync_youtube'},function(d){
    btn.disabled=false; if(ico)ico.classList.remove('spin');
    document.getElementById('ytStat').textContent = d.success?('✅ 새 영상 '+d.new+'개'):('❌ '+d.message);
    showToast(d.success?('새 영상 '+d.new+'개 수집'):(d.message||'수집 실패'), d.success?'ok':'error');
    if(d.success)setTimeout(function(){location.reload();},800);
  });
}

function addIG(){
  if(!ig_url.value.trim()||!ig_thumb.value.trim()){showToast('링크와 이미지는 필수입니다.','error');return;}
  post({action:'add_instagram',url:ig_url.value,thumbnail:ig_thumb.value,title:ig_title.value,caption:ig_caption.value},
  function(d){
    document.getElementById('igStat').textContent=d.success?'✅ 추가됨':('❌ '+d.message);
    showToast(d.success?'인스타 카드 추가됨':(d.message||'추가 실패'), d.success?'ok':'error');
    if(d.success)setTimeout(function(){location.reload();},600);
  });
}

function tog(id,v){post({action:'toggle',id:id,v:v},function(d){ if(d.success)showToast(v?'노출 ON':'노출 OFF','ok'); });}

function del(id){
  if(!confirm('삭제할까요?'))return;
  post({action:'delete',id:id},function(d){
    if(d.success){var r=document.getElementById('srow-'+id); if(r)r.remove(); showToast('삭제되었습니다.','ok');}
  });
}

function showToast(msg,type){
  var el=document.createElement('div');
  el.className='toast '+(type||'ok');
  el.innerHTML='<span class="material-symbols-outlined" style="font-size:16px;">'+(type==='error'?'error':'check_circle')+'</span>'+msg;
  document.body.appendChild(el);
  setTimeout(function(){el.remove();},3000);
}
</script>
</body>
</html>