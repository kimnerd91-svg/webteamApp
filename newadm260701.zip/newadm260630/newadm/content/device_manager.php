<?php
include_once('../_common.php');
include_once('../_auth_check.php');

if (isset($_FILES['eq_image']['name'])) {
    while (ob_get_level()) ob_end_clean();
    $upload_dir = G5_DATA_PATH . '/equipment/' . date('Ym');
    $upload_url = G5_DATA_URL  . '/equipment/' . date('Ym');
    if (!is_dir($upload_dir)) { @mkdir($upload_dir, G5_DIR_PERMISSION, true); @chmod($upload_dir, G5_DIR_PERMISSION); }
    $ext = strtolower(pathinfo($_FILES['eq_image']['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg','jpeg','png','gif','webp'])) { header('Content-Type: application/json'); echo json_encode(['success'=>0,'message'=>'이미지 파일만 업로드 가능합니다.']); exit; }
    $new_name = time().'_'.md5(uniqid()).'.'.$ext;
    if (move_uploaded_file($_FILES['eq_image']['tmp_name'], $upload_dir.'/'.$new_name)) { header('Content-Type: application/json'); echo json_encode(['success'=>1,'url'=>$upload_url.'/'.$new_name]); }
    else { header('Content-Type: application/json'); echo json_encode(['success'=>0,'message'=>'업로드 실패. 폴더 권한을 확인하세요.']); }
    exit;
}

sql_query("CREATE TABLE IF NOT EXISTS `dm_equipment` (`id` INT(11) NOT NULL AUTO_INCREMENT,`name` VARCHAR(255) NOT NULL,`category` VARCHAR(100) NOT NULL DEFAULT '',`description` TEXT,`main_text` TEXT DEFAULT NULL,`image_outer` TEXT DEFAULT NULL,`image_inner` TEXT DEFAULT NULL,`youtube_url` TEXT DEFAULT NULL,`tags` TEXT DEFAULT NULL,`display_order` INT(11) DEFAULT 0,`created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// 컬럼 추가 (없을 때만)
$col_chk = sql_query("SHOW COLUMNS FROM dm_equipment LIKE 'tags'");
if (sql_num_rows($col_chk) == 0) sql_query("ALTER TABLE dm_equipment ADD `tags` TEXT DEFAULT NULL AFTER `youtube_url`");
$col_main = sql_query("SHOW COLUMNS FROM dm_equipment LIKE 'main_text'");
if (sql_num_rows($col_main) == 0) sql_query("ALTER TABLE dm_equipment ADD `main_text` TEXT DEFAULT NULL AFTER `description`");

// VARCHAR(500) → TEXT 마이그레이션 (기존 설치 대응)
$col_outer = sql_fetch("SHOW COLUMNS FROM dm_equipment LIKE 'image_outer'");
if ($col_outer && stripos($col_outer['Type'], 'varchar') !== false) {
    sql_query("ALTER TABLE dm_equipment MODIFY `image_outer` TEXT DEFAULT NULL");
    sql_query("ALTER TABLE dm_equipment MODIFY `image_inner` TEXT DEFAULT NULL");
    sql_query("ALTER TABLE dm_equipment MODIFY `youtube_url` TEXT DEFAULT NULL");
    sql_query("ALTER TABLE dm_equipment MODIFY `tags` TEXT DEFAULT NULL");
}

if (isset($_GET['delete_id'])) { sql_query("DELETE FROM dm_equipment WHERE id=".(int)$_GET['delete_id']); alert_toast('장비가 삭제되었습니다.','./device_manager.php'); }

// ── JSON 내보내기 ──────────────────────────────────────────────
if (isset($_GET['action']) && $_GET['action'] === 'export_json') {
    $result = sql_query("SELECT name,category,description,main_text,image_outer,image_inner,youtube_url,tags,display_order FROM dm_equipment ORDER BY display_order ASC, id ASC");
    $data = [];
    while ($row = sql_fetch_array($result)) $data[] = $row;
    $filename = 'equipment_' . date('Ymd_His') . '.json';
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

// ── JSON 가져오기 ──────────────────────────────────────────────
if (isset($_POST['action']) && $_POST['action'] === 'import_json') {
    header('Content-Type: application/json');
    $raw = $_POST['json_data'] ?? '';
    $raw = base64_decode($raw);
    $items = json_decode($raw, true);
    if (!is_array($items)) { echo json_encode(['success'=>0,'message'=>'유효하지 않은 JSON 형식입니다.']); exit; }
    $inserted = 0; $skipped = 0;
    foreach ($items as $item) {
        $name = trim($item['name'] ?? '');
        if (!$name) { $skipped++; continue; }
        $esc_name = sql_real_escape_string($name);
        $esc_cat  = sql_real_escape_string(trim($item['category'] ?? ''));
        $chk = sql_query("SELECT id FROM dm_equipment WHERE name='{$esc_name}' AND category='{$esc_cat}' LIMIT 1");
        if (sql_num_rows($chk) > 0) { $skipped++; continue; }
        $description  = sql_real_escape_string(trim($item['description']  ?? ''));
        $main_text    = sql_real_escape_string(trim($item['main_text']    ?? ''));
        $image_outer  = '';
        $image_inner  = '';
        $youtube_url  = sql_real_escape_string(trim($item['youtube_url']  ?? ''));
        $tags         = sql_real_escape_string(trim($item['tags']         ?? ''));
        $display_order = (int)($item['display_order'] ?? 0);
        sql_query("INSERT INTO dm_equipment SET name='{$esc_name}',category='{$esc_cat}',description='{$description}',main_text='{$main_text}',image_outer='{$image_outer}',image_inner='{$image_inner}',youtube_url='{$youtube_url}',tags='{$tags}',display_order='{$display_order}',created_at=NOW()");
        $inserted++;
    }
    echo json_encode(['success'=>1,'inserted'=>$inserted,'skipped'=>$skipped]);
    exit;
}

if (isset($_POST['action']) && $_POST['action'] === 'add_equipment') {
    $name=sql_real_escape_string(stripslashes(trim($_POST['name']))); $category=sql_real_escape_string(stripslashes(trim($_POST['category'])));
    $description=sql_real_escape_string(stripslashes(trim($_POST['description']))); $main_text=sql_real_escape_string(stripslashes(trim($_POST['main_text'] ?? '')));
    $image_outer=sql_real_escape_string(stripslashes(trim($_POST['image_outer'])));
    $image_inner=sql_real_escape_string(stripslashes(trim($_POST['image_inner']))); $youtube_url=sql_real_escape_string(stripslashes(trim($_POST['youtube_url'])));
    $tags=sql_real_escape_string(stripslashes(trim($_POST['tags']))); $display_order=(int)$_POST['display_order'];
    sql_query("INSERT INTO dm_equipment SET name='{$name}',category='{$category}',description='{$description}',main_text='{$main_text}',image_outer='{$image_outer}',image_inner='{$image_inner}',youtube_url='{$youtube_url}',tags='{$tags}',display_order='{$display_order}',created_at=NOW()");
    alert_toast('장비가 추가되었습니다.','./device_manager.php','success');
}
if (isset($_POST['action']) && $_POST['action'] === 'update_equipment') {
    $id=(int)$_POST['id']; $name=sql_real_escape_string(stripslashes(trim($_POST['name']))); $category=sql_real_escape_string(stripslashes(trim($_POST['category'])));
    $description=sql_real_escape_string(stripslashes(trim($_POST['description']))); $main_text=sql_real_escape_string(stripslashes(trim($_POST['main_text'] ?? '')));
    $image_outer=sql_real_escape_string(stripslashes(trim($_POST['image_outer'])));
    $image_inner=sql_real_escape_string(stripslashes(trim($_POST['image_inner']))); $youtube_url=sql_real_escape_string(stripslashes(trim($_POST['youtube_url'])));
    $tags=sql_real_escape_string(stripslashes(trim($_POST['tags']))); $display_order=(int)$_POST['display_order'];
    sql_query("UPDATE dm_equipment SET name='{$name}',category='{$category}',description='{$description}',main_text='{$main_text}',image_outer='{$image_outer}',image_inner='{$image_inner}',youtube_url='{$youtube_url}',tags='{$tags}',display_order='{$display_order}' WHERE id={$id}");
    alert_toast('장비 정보가 수정되었습니다.','./device_manager.php','success');
}

$result = sql_query("SELECT * FROM dm_equipment ORDER BY display_order ASC, id ASC");
$equipments = [];
while ($row = sql_fetch_array($result)) $equipments[] = $row;
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>장비 관리</title>
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Pretendard', 'Apple SD Gothic Neo', sans-serif; background: #f5f6fa; color: #1a1a2e; }
        #admin_wrapper { display: flex; min-height: 100vh; }
        .content_area { flex: 1; padding: 40px; overflow-x: hidden; }

        .page_header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 28px; }
        .page_title  { font-size: 22px; font-weight: 700; }
        .btn_add { padding: 11px 22px; background: #4f46e5; color: #fff; border: none; border-radius: 9px; font-size: 13px; font-weight: 700; cursor: pointer; box-shadow: 0 4px 12px rgba(79,70,229,0.25); transition: all 0.2s; }
        .btn_add:hover { background: #4338ca; }

        .card { background: #fff; border-radius: 12px; box-shadow: 0 2px 12px rgba(0,0,0,0.06); border: 1px solid #e8eaf0; padding: 24px; margin-bottom: 24px; }

        .eq_grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 18px; }
        .eq_card { background: #fff; border-radius: 12px; border: 1px solid #e8eaf0; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.05); transition: all 0.2s; display: flex; flex-direction: column; }
        .eq_card:hover { transform: translateY(-3px); box-shadow: 0 8px 24px rgba(0,0,0,0.1); border-color: #c4b5fd; }
        .eq_thumb { width: 100%; aspect-ratio: 4/3; object-fit: cover; display: block; }
        .eq_thumb_ph { width: 100%; aspect-ratio: 4/3; background: #f5f6fa; display: flex; align-items: center; justify-content: center; color: #9999bb; font-size: 13px; }
        .eq_body { padding: 14px 16px; display: flex; flex-direction: column; flex: 1; }
        .eq_category { display: inline-block; background: #ede9fe; color: #4f46e5; font-size: 11px; font-weight: 700; padding: 3px 10px; border-radius: 20px; margin-bottom: 8px; }
        .eq_name { font-size: 15px; font-weight: 700; color: #1a1a2e; margin-bottom: 5px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .eq_desc { font-size: 12px; color: #9999bb; line-height: 1.5; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; margin-bottom: 8px; }
        .eq_main_text { font-size: 11px; color: #4f46e5; background: #ede9fe; border-radius: 6px; padding: 4px 8px; margin-bottom: 8px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
        .eq_tags { display: flex; flex-wrap: wrap; gap: 4px; margin-bottom: 12px; }
        .eq_tag  { background: #ede9fe; color: #4f46e5; font-size: 11px; font-weight: 600; padding: 2px 8px; border-radius: 20px; }
        .eq_actions { display: grid; grid-template-columns: 1fr 1fr; gap: 7px; margin-top: auto; padding-top: 12px; }
        .btn_eq_edit { padding: 8px; background: #4f46e5; color: #fff; border: none; border-radius: 7px; font-size: 12px; font-weight: 700; cursor: pointer; transition: all 0.2s; }
        .btn_eq_edit:hover { background: #4338ca; }
        .btn_eq_del  { padding: 8px; background: #fee2e2; color: #dc2626; border: none; border-radius: 7px; font-size: 12px; font-weight: 700; cursor: pointer; transition: all 0.2s; }
        .btn_eq_del:hover { background: #fecaca; }
        .empty_state { text-align: center; padding: 60px; color: #9999bb; font-size: 14px; }

        /* 모달 */
        .modal_overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.55); z-index: 10000; align-items: flex-start; justify-content: center; padding: 40px 20px; overflow-y: auto; }
        .modal_overlay.active { display: flex; }
        .modal_box { background: #fff; border-radius: 14px; width: 100%; max-width: 680px; overflow: hidden; animation: modal_in 0.25s ease; margin: auto; }
        @keyframes modal_in { from { transform: translateY(-20px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
        .modal_hd { padding: 20px 24px; border-bottom: 1px solid #e8eaf0; display: flex; align-items: center; justify-content: space-between; }
        .modal_hd h3 { font-size: 16px; font-weight: 700; }
        .modal_close { background: none; border: none; font-size: 20px; cursor: pointer; color: #9999bb; }
        .modal_bd { padding: 24px; display: flex; flex-direction: column; gap: 14px; max-height: 75vh; overflow-y: auto; }
        .form_grid2 { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
        .form_group label { display: block; font-size: 12px; font-weight: 700; color: #9999bb; margin-bottom: 6px; }
        .form_input { width: 100%; border: 1px solid #e8eaf0; border-radius: 8px; padding: 10px 14px; font-size: 14px; background: #f5f6fa; font-family: inherit; transition: all 0.2s; }
        .form_input:focus { outline: none; border-color: #4f46e5; background: #fff; box-shadow: 0 0 0 3px rgba(79,70,229,0.1); }
        textarea.form_input { resize: vertical; min-height: 80px; }

        .upload_zone { border: 2px dashed #e8eaf0; border-radius: 10px; padding: 20px; text-align: center; cursor: pointer; transition: all 0.2s; background: #f5f6fa; position: relative; min-height: 90px; display: flex; flex-direction: column; align-items: center; justify-content: center; }
        .upload_zone:hover, .upload_zone.dragover { border-color: #4f46e5; background: #ede9fe; }
        .upload_zone input[type="file"] { position: absolute; inset: 0; opacity: 0; cursor: pointer; width: 100%; height: 100%; }
        .upload_zone_icon { font-size: 22px; margin-bottom: 4px; pointer-events: none; }
        .upload_zone_text { font-size: 12px; color: #9999bb; pointer-events: none; }
        .upload_zone_text strong { color: #4f46e5; }
        .upload_preview { width: 100%; height: 100px; object-fit: cover; border-radius: 8px; margin-top: 8px; border: 1px solid #e8eaf0; display: none; }
        .upload_loading { display: none; font-size: 12px; color: #9999bb; margin-top: 6px; text-align: center; }

        .tag_preview_wrap { margin-top: 8px; display: flex; flex-wrap: wrap; gap: 6px; }
        .tag_chip { background: #ede9fe; color: #4f46e5; padding: 4px 10px; border-radius: 20px; font-size: 12px; font-weight: 600; }

        .modal_ft { padding: 16px 24px; border-top: 1px solid #e8eaf0; display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
        .btn_modal_cancel { padding: 12px; border-radius: 8px; background: #f5f6fa; color: #5c5c7a; border: 1px solid #e8eaf0; font-size: 14px; font-weight: 700; cursor: pointer; }
        .btn_modal_submit { padding: 12px; border-radius: 8px; background: #4f46e5; color: #fff; border: none; font-size: 14px; font-weight: 700; cursor: pointer; }
        .btn_modal_submit:hover { background: #4338ca; }
    </style>
</head>
<body>
<div id="admin_wrapper">
    <?php include_once('../aside.php'); ?>
    <main class="content_area">
        <div class="page_header">
            <h2 class="page_title">장비 관리</h2>
            <div style="display:flex;gap:10px;align-items:center;">
                <button onclick="location.href='?action=export_json'" class="btn_add" style="background:#059669;box-shadow:0 4px 12px rgba(5,150,105,0.25);">📤 JSON 내보내기</button>
                <button onclick="openImportModal()" class="btn_add" style="background:#0891b2;box-shadow:0 4px 12px rgba(8,145,178,0.25);">📥 JSON 가져오기</button>
                <button onclick="openAddModal()" class="btn_add">+ 새 장비 추가</button>
            </div>
        </div>

        <div class="card">
            <?php if (!empty($equipments)): ?>
            <div class="eq_grid">
                <?php foreach ($equipments as $eq): ?>
                <div class="eq_card">
                    <?php if ($eq['image_outer']): ?>
                    <img class="eq_thumb" src="<?= htmlspecialchars($eq['image_outer']) ?>" alt="<?= htmlspecialchars($eq['name']) ?>">
                    <?php else: ?>
                    <div class="eq_thumb_ph">이미지 없음</div>
                    <?php endif; ?>
                    <div class="eq_body">
                        <?php if ($eq['category']): ?><span class="eq_category"><?= htmlspecialchars($eq['category']) ?></span><?php endif; ?>
                        <div class="eq_name"><?= htmlspecialchars($eq['name']) ?></div>
                        <div class="eq_desc"><?= htmlspecialchars($eq['description']) ?></div>
                        <?php if (!empty($eq['main_text'])): ?>
                        <div class="eq_main_text">📌 <?= htmlspecialchars($eq['main_text']) ?></div>
                        <?php endif; ?>
                        <?php if ($eq['tags']): ?>
                        <div class="eq_tags">
                            <?php foreach (explode('#', $eq['tags']) as $tag): $tag = trim($tag); if (!$tag) continue; ?>
                            <span class="eq_tag">#<?= htmlspecialchars($tag) ?></span>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                        <div class="eq_actions">
                            <button type="button"onclick='openEditModal(<?= json_encode($eq, JSON_HEX_QUOT|JSON_HEX_TAG|JSON_HEX_APOS) ?>)' class="btn_eq_edit">수정</button>
                            <button type="button" onclick="if(confirm('정말 삭제하시겠습니까?')) location.href='?delete_id=<?= $eq['id'] ?>'" class="btn_eq_del">삭제</button>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <div class="empty_state">등록된 장비가 없습니다.</div>
            <?php endif; ?>
        </div>
    </main>
</div>

<!-- 추가 모달 -->
<div class="modal_overlay" id="addModal">
    <div class="modal_box">
        <div class="modal_hd"><h3>새 장비 추가</h3><button class="modal_close" onclick="closeModal('addModal')">✕</button></div>
        <form method="post" id="addForm">
            <input type="hidden" name="action" value="add_equipment">
            <input type="hidden" name="image_outer" id="add_outer_val">
            <input type="hidden" name="image_inner" id="add_inner_val">
            <div class="modal_bd">
                <div class="form_grid2">
                    <div class="form_group"><label>장비명 *</label><input type="text" name="name" class="form_input" placeholder="장비 이름" required></div>
                    <div class="form_group"><label>카테고리</label><input type="text" name="category" class="form_input" placeholder="예: CT, 레이저"></div>
                </div>
                <div class="form_grid2">
                    <div class="form_group">
                        <label>외부 이미지</label>
                        <div class="upload_zone" ondragover="event.preventDefault();this.classList.add('dragover')" ondragleave="this.classList.remove('dragover')" ondrop="handleDrop(event,'add_outer_val','add_outer_preview','add_outer_loading')">
                            <input type="file" accept="image/*" onchange="uploadImage(this.files[0],'add_outer_val','add_outer_preview','add_outer_loading')">
                            <div class="upload_zone_icon">🖼️</div>
                            <div class="upload_zone_text">클릭 또는 <strong>드래그</strong> 업로드</div>
                        </div>
                        <div class="upload_loading" id="add_outer_loading">⏳ 업로드 중...</div>
                        <img id="add_outer_preview" class="upload_preview">
                    </div>
                    <div class="form_group">
                        <label>내부 이미지</label>
                        <div class="upload_zone" ondragover="event.preventDefault();this.classList.add('dragover')" ondragleave="this.classList.remove('dragover')" ondrop="handleDrop(event,'add_inner_val','add_inner_preview','add_inner_loading')">
                            <input type="file" accept="image/*" onchange="uploadImage(this.files[0],'add_inner_val','add_inner_preview','add_inner_loading')">
                            <div class="upload_zone_icon">🏥</div>
                            <div class="upload_zone_text">클릭 또는 <strong>드래그</strong> 업로드</div>
                        </div>
                        <div class="upload_loading" id="add_inner_loading">⏳ 업로드 중...</div>
                        <img id="add_inner_preview" class="upload_preview">
                    </div>
                </div>
                <div class="form_grid2">
                    <div class="form_group"><label>유튜브 링크</label><input type="text" name="youtube_url" class="form_input" placeholder="https://youtube.com/..."></div>
                    <div class="form_group"><label>표시 순서</label><input type="number" name="display_order" class="form_input" value="0"></div>
                </div>
                <div class="form_group"><label>설명</label><textarea name="description" class="form_input" placeholder="장비 설명"></textarea></div>
                <div class="form_group">
                    <label>메인 텍스트 <span style="color:#9999bb;font-weight:400;">(선택 — 메인 페이지 표시용)</span></label>
                    <textarea name="main_text" id="add_main_text" class="form_input" placeholder="메인에 표시될 텍스트 (없으면 비워두세요)"></textarea>
                </div>
                <div class="form_group">
                    <label>해시태그</label>
                    <input type="text" name="tags" id="add_tags" class="form_input" placeholder="#임플란트 #CT (# 로 구분)">
                    <div class="tag_preview_wrap" id="add_tags_preview"></div>
                </div>
            </div>
            <div class="modal_ft">
                <button type="button" class="btn_modal_cancel" onclick="closeModal('addModal')">취소</button>
                <button type="submit" class="btn_modal_submit">추가하기</button>
            </div>
        </form>
    </div>
</div>

<!-- JSON 가져오기 모달 -->
<div class="modal_overlay" id="importModal">
    <div class="modal_box">
        <div class="modal_hd"><h3>📥 JSON으로 장비 일괄 추가</h3><button class="modal_close" onclick="closeModal('importModal')">✕</button></div>
        <div class="modal_bd" id="importModalBody" style="gap:16px;">
            <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:10px;padding:14px 16px;font-size:13px;color:#166534;line-height:1.7;">
                <strong>📌 JSON 형식 안내</strong><br>
                아래 구조의 배열을 넣으면 자동으로 장비가 추가됩니다.<br>
                같은 <strong>장비명 + 카테고리</strong> 조합은 중복 추가되지 않습니다.<br>
                <span style="color:#0891b2;">🖼️ 이미지 필드(image_outer/inner)는 가져올 때 무시되며, 추가 후 직접 업로드해주세요.</span>
            </div>
            <div style="background:#1e1e2e;border-radius:10px;padding:14px 16px;font-size:12px;color:#cdd6f4;font-family:monospace;line-height:1.8;overflow-x:auto;">
[<br>
&nbsp;&nbsp;{<br>
&nbsp;&nbsp;&nbsp;&nbsp;"name": "파노라마 X-ray",<br>
&nbsp;&nbsp;&nbsp;&nbsp;"category": "영상 진단",<br>
&nbsp;&nbsp;&nbsp;&nbsp;"description": "장비 설명",<br>
&nbsp;&nbsp;&nbsp;&nbsp;"main_text": "메인 표시 텍스트 (선택)",<br>
&nbsp;&nbsp;&nbsp;&nbsp;"image_outer": "https://...",<br>
&nbsp;&nbsp;&nbsp;&nbsp;"image_inner": "https://...",<br>
&nbsp;&nbsp;&nbsp;&nbsp;"youtube_url": "https://youtube.com/...",<br>
&nbsp;&nbsp;&nbsp;&nbsp;"tags": "#파노라마 #엑스레이",<br>
&nbsp;&nbsp;&nbsp;&nbsp;"display_order": 0<br>
&nbsp;&nbsp;}<br>
]
            </div>

            <!-- 드래그&드롭 존 -->
            <div id="import_drop_zone" class="upload_zone" style="min-height:110px;border-color:#0891b2;"
                ondragover="event.preventDefault();this.classList.add('dragover')"
                ondragleave="this.classList.remove('dragover')"
                ondrop="handleJsonDrop(event)">
                <input type="file" accept=".json,application/json" onchange="handleJsonFile(this.files[0])" id="import_file_input">
                <div class="upload_zone_icon">📄</div>
                <div class="upload_zone_text">JSON 파일을 <strong>드래그</strong> 하거나 <strong>클릭</strong>하여 선택</div>
            </div>

            <div id="import_file_info" style="display:none;background:#f0f9ff;border:1px solid #bae6fd;border-radius:10px;padding:12px 16px;font-size:13px;color:#0c4a6e;">
                <span id="import_file_name" style="font-weight:700;"></span>
                <span id="import_item_count" style="margin-left:10px;color:#0891b2;font-weight:600;"></span>
            </div>

            <div id="import_preview_wrap" style="display:none;">
                <div style="font-size:12px;font-weight:700;color:#9999bb;margin-bottom:8px;">미리보기 (최대 5개)</div>
                <div id="import_preview_list" style="display:flex;flex-direction:column;gap:6px;"></div>
            </div>

            <div id="import_error" style="display:none;background:#fef2f2;border:1px solid #fecaca;border-radius:10px;padding:12px 16px;font-size:13px;color:#dc2626;"></div>
        </div>
        <div class="modal_ft">
            <button type="button" class="btn_modal_cancel" onclick="closeModal('importModal')">취소</button>
            <button type="button" class="btn_modal_submit" id="btn_do_import" style="background:#0891b2;" onclick="doImport()" disabled>가져오기</button>
        </div>
    </div>
</div>

<!-- 수정 모달 -->
<div class="modal_overlay" id="editModal">
    <div class="modal_box">
        <div class="modal_hd"><h3>장비 수정</h3><button class="modal_close" onclick="closeModal('editModal')">✕</button></div>
        <form method="post" id="editForm">
            <input type="hidden" name="action" value="update_equipment">
            <input type="hidden" name="id" id="edit_id">
            <input type="hidden" name="image_outer" id="edit_outer_val">
            <input type="hidden" name="image_inner" id="edit_inner_val">
            <div class="modal_bd">
                <div class="form_grid2">
                    <div class="form_group"><label>장비명 *</label><input type="text" name="name" id="edit_name" class="form_input" required></div>
                    <div class="form_group"><label>카테고리</label><input type="text" name="category" id="edit_category" class="form_input"></div>
                </div>
                <div class="form_grid2">
                    <div class="form_group">
                        <label>외부 이미지</label>
                        <div class="upload_zone" ondragover="event.preventDefault();this.classList.add('dragover')" ondragleave="this.classList.remove('dragover')" ondrop="handleDrop(event,'edit_outer_val','edit_outer_preview','edit_outer_loading')">
                            <input type="file" accept="image/*" onchange="uploadImage(this.files[0],'edit_outer_val','edit_outer_preview','edit_outer_loading')">
                            <div class="upload_zone_icon">🖼️</div>
                            <div class="upload_zone_text">클릭 또는 <strong>드래그</strong> 교체</div>
                        </div>
                        <div class="upload_loading" id="edit_outer_loading">⏳ 업로드 중...</div>
                        <img id="edit_outer_preview" class="upload_preview">
                    </div>
                    <div class="form_group">
                        <label>내부 이미지</label>
                        <div class="upload_zone" ondragover="event.preventDefault();this.classList.add('dragover')" ondragleave="this.classList.remove('dragover')" ondrop="handleDrop(event,'edit_inner_val','edit_inner_preview','edit_inner_loading')">
                            <input type="file" accept="image/*" onchange="uploadImage(this.files[0],'edit_inner_val','edit_inner_preview','edit_inner_loading')">
                            <div class="upload_zone_icon">🏥</div>
                            <div class="upload_zone_text">클릭 또는 <strong>드래그</strong> 교체</div>
                        </div>
                        <div class="upload_loading" id="edit_inner_loading">⏳ 업로드 중...</div>
                        <img id="edit_inner_preview" class="upload_preview">
                    </div>
                </div>
                <div class="form_grid2">
                    <div class="form_group"><label>유튜브 링크</label><input type="text" name="youtube_url" id="edit_youtube_url" class="form_input"></div>
                    <div class="form_group"><label>표시 순서</label><input type="number" name="display_order" id="edit_display_order" class="form_input"></div>
                </div>
                <div class="form_group"><label>설명</label><textarea name="description" id="edit_description" class="form_input"></textarea></div>
                <div class="form_group">
                    <label>메인 텍스트 <span style="color:#9999bb;font-weight:400;">(선택 — 메인 페이지 표시용)</span></label>
                    <textarea name="main_text" id="edit_main_text" class="form_input" placeholder="메인에 표시될 텍스트 (없으면 비워두세요)"></textarea>
                </div>
                <div class="form_group">
                    <label>해시태그</label>
                    <input type="text" name="tags" id="edit_tags" class="form_input" placeholder="#임플란트 #CT (# 로 구분)">
                    <div class="tag_preview_wrap" id="edit_tags_preview"></div>
                </div>
            </div>
            <div class="modal_ft">
                <button type="button" class="btn_modal_cancel" onclick="closeModal('editModal')">취소</button>
                <button type="submit" class="btn_modal_submit">수정 완료</button>
            </div>
        </form>
    </div>
</div>

<script>
function closeModal(id) { document.getElementById(id).classList.remove('active'); }
// 모달 외부 클릭으로 닫히지 않음 — 오직 취소 버튼/X 버튼만으로 닫힘

// ── JSON 가져오기 ──────────────────────────────────────────────
let importJsonData = null;

function openImportModal() {
    importJsonData = null;
    document.getElementById('import_file_input').value = '';
    document.getElementById('import_file_info').style.display = 'none';
    document.getElementById('import_preview_wrap').style.display = 'none';
    document.getElementById('import_error').style.display = 'none';
    document.getElementById('btn_do_import').disabled = true;
    document.getElementById('importModal').classList.add('active');
}
function handleJsonDrop(e) {
    e.preventDefault(); e.currentTarget.classList.remove('dragover');
    const file = e.dataTransfer.files[0];
    if (file) handleJsonFile(file);
}
function handleJsonFile(file) {
    if (!file) return;
    document.getElementById('import_error').style.display = 'none';
    document.getElementById('import_preview_wrap').style.display = 'none';
    document.getElementById('import_file_info').style.display = 'none';
    document.getElementById('btn_do_import').disabled = true;
    importJsonData = null;
    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            const parsed = JSON.parse(e.target.result);
            if (!Array.isArray(parsed)) throw new Error('최상위가 배열([ ])이어야 합니다.');
            if (parsed.length === 0) throw new Error('데이터가 비어 있습니다.');
            parsed.forEach((item, i) => { if (!item.name || !item.name.trim()) throw new Error((i+1) + '번째 항목에 name 필드가 없습니다.'); });
            importJsonData = parsed;
            document.getElementById('import_file_name').textContent = file.name;
            document.getElementById('import_item_count').textContent = '총 ' + parsed.length + '개 장비';
            document.getElementById('import_file_info').style.display = 'block';
            const preview = parsed.slice(0, 5);
            document.getElementById('import_preview_list').innerHTML = preview.map(item =>
                `<div style="background:#f5f6fa;border-radius:8px;padding:10px 14px;font-size:13px;display:flex;gap:10px;align-items:center;">
                    <span style="font-weight:700;">${escHtml(item.name)}</span>
                    ${item.category ? `<span style="background:#ede9fe;color:#4f46e5;padding:2px 8px;border-radius:20px;font-size:11px;font-weight:700;">${escHtml(item.category)}</span>` : ''}
                    ${item.description ? `<span style="color:#9999bb;font-size:12px;">${escHtml(item.description.substring(0,40))}${item.description.length>40?'…':''}</span>` : ''}
                </div>`
            ).join('');
            document.getElementById('import_preview_wrap').style.display = 'block';
            document.getElementById('btn_do_import').disabled = false;
        } catch(err) {
            document.getElementById('import_error').textContent = '❌ JSON 파싱 오류: ' + err.message;
            document.getElementById('import_error').style.display = 'block';
        }
    };
    reader.readAsText(file, 'utf-8');
}
function escHtml(s) { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function doImport() {
    if (!importJsonData) return;
    const btn = document.getElementById('btn_do_import');
    btn.disabled = true; btn.textContent = '가져오는 중...';
    const fd = new FormData();
    fd.append('action', 'import_json');
    fd.append('json_data', btoa(unescape(encodeURIComponent(JSON.stringify(importJsonData)))));
    fetch('./device_manager.php', { method:'POST', body:fd })
        .then(r => r.json()).then(data => {
            if (data.success) {
                closeModal('importModal');
                alert(`✅ 완료!\n추가된 장비: ${data.inserted}개\n중복 건너뜀: ${data.skipped}개`);
                location.reload();
            } else {
                document.getElementById('import_error').textContent = '❌ ' + (data.message || '오류가 발생했습니다.');
                document.getElementById('import_error').style.display = 'block';
                btn.disabled = false; btn.textContent = '가져오기';
            }
        }).catch(() => {
            document.getElementById('import_error').textContent = '❌ 서버 통신 오류가 발생했습니다.';
            document.getElementById('import_error').style.display = 'block';
            btn.disabled = false; btn.textContent = '가져오기';
        });
}

function uploadImage(file, hiddenId, previewId, loadingId) {
    if (!file) return;
    document.getElementById(loadingId).style.display = 'block';
    document.getElementById(previewId).style.display = 'none';
    const fd = new FormData(); fd.append('eq_image', file);
    fetch('./device_manager.php', { method:'POST', body:fd })
        .then(r => r.json()).then(data => {
            document.getElementById(loadingId).style.display = 'none';
            if (data.success) { document.getElementById(hiddenId).value = data.url; document.getElementById(previewId).src = data.url; document.getElementById(previewId).style.display = 'block'; }
            else alert(data.message || '업로드 실패');
        }).catch(() => { document.getElementById(loadingId).style.display = 'none'; alert('업로드 중 오류'); });
}
function handleDrop(event, hiddenId, previewId, loadingId) {
    event.preventDefault(); event.currentTarget.classList.remove('dragover');
    const file = event.dataTransfer.files[0];
    if (file && file.type.startsWith('image/')) uploadImage(file, hiddenId, previewId, loadingId);
    else alert('이미지 파일만 업로드 가능합니다.');
}
function renderTags(inputId, previewId) {
    document.getElementById(inputId).addEventListener('input', function() {
        const tags = this.value.split('#').map(t => t.trim()).filter(t => t);
        document.getElementById(previewId).innerHTML = tags.map(t => `<span class="tag_chip">#${t}</span>`).join('');
    });
}
renderTags('add_tags','add_tags_preview');
renderTags('edit_tags','edit_tags_preview');

function openAddModal() {
    document.getElementById('addForm').reset();
    ['add_outer_val','add_inner_val'].forEach(id => document.getElementById(id).value='');
    ['add_outer_preview','add_inner_preview'].forEach(id => { document.getElementById(id).src=''; document.getElementById(id).style.display='none'; });
    ['add_outer_loading','add_inner_loading'].forEach(id => document.getElementById(id).style.display='none');
    document.getElementById('add_tags').value=''; document.getElementById('add_tags_preview').innerHTML='';
    document.getElementById('add_main_text').value='';
    document.getElementById('addModal').classList.add('active');
}
function unslash(s) { return (s || '').replace(/\\(.)/g, '$1'); }
function openEditModal(data) {
    document.getElementById('edit_id').value = data.id;
    document.getElementById('edit_name').value = unslash(data.name);
    document.getElementById('edit_category').value = unslash(data.category);
    document.getElementById('edit_description').value = unslash(data.description);
    document.getElementById('edit_main_text').value = unslash(data.main_text || '');
    document.getElementById('edit_youtube_url').value = unslash(data.youtube_url);
    document.getElementById('edit_display_order').value = data.display_order;
    document.getElementById('edit_outer_val').value = data.image_outer;
    document.getElementById('edit_inner_val').value = data.image_inner;
    const sp = (id, url) => { const el=document.getElementById(id); if(url){el.src=url;el.style.display='block';}else{el.src='';el.style.display='none';} };
    sp('edit_outer_preview', data.image_outer); sp('edit_inner_preview', data.image_inner);
    ['edit_outer_loading','edit_inner_loading'].forEach(id => document.getElementById(id).style.display='none');
    document.getElementById('edit_tags').value = unslash(data.tags || '');
    document.getElementById('edit_tags').dispatchEvent(new Event('input'));
    document.getElementById('editModal').classList.add('active');
}
</script>
</body>
</html>