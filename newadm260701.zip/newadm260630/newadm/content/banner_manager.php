<?php
/* ============================================================================
 * [ALT 연동 안내 — 프론트 배너 출력부에서 처리할 것]
 * alt 값은 mainbanner.images JSON 의 'alt' 키에 이미지마다 저장된다.
 * 실제 사이트 배너 슬라이더를 그리는 출력부(메인/테마 파일)의 <img> 에서
 * alt 속성을 $item['alt'] 값으로 채워야 SEO/접근성에 반영됨.
 *   - 출력 루프: foreach (json_decode(row.images, true) as item) { ... }
 *   - <img> 에 alt 추가:  alt 속성값 = htmlspecialchars(item['alt'] ?? '')
 *   - alt 는 웹/모바일 공용 (item['alt'] 하나 사용)
 * ========================================================================== */

if (!ob_get_level()) ob_start();   // 헤더 출력 충돌 방지 안전벨트
include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/_common.php');
include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/_auth_check.php');
// include_once($_SERVER['DOCUMENT_ROOT'] . '/head_sub.php');

// ============================================================
// 헬퍼 함수 (반드시 상단에 정의)
// ============================================================
function build_ts() {
    $allowed = '<p><br><span><strong><em><b><i><u><small><h1><h2><h3><h4><h5><h6><a><img>';
    $g  = function($k) { return isset($_POST[$k]) ? stripslashes(trim($_POST[$k])) : ''; };
    $gh = function($k) use ($allowed) { return isset($_POST[$k]) ? strip_tags(stripslashes(trim($_POST[$k])), $allowed) : ''; };
    return array(
        'web' => array(
            'subtitle'      => $gh('web_subtitle'),
            'title'         => $gh('web_title'),
            'description'   => $gh('web_description'),
            'button_text'   => $g('web_button_text'),
            'button_link'   => $g('web_button_link'),
            'text_color'    => $g('web_text_color')    ?: '#ffffff',
            'text_position' => $g('web_text_position') ?: 'left',
        ),
        'mobile' => array(
            'subtitle'      => $gh('mob_subtitle'),
            'title'         => $gh('mob_title'),
            'description'   => $gh('mob_description'),
            'button_text'   => $g('mob_button_text'),
            'button_link'   => $g('mob_button_link'),
            'text_color'    => $g('mob_text_color')    ?: '#ffffff',
            'text_position' => $g('mob_text_position') ?: 'left',
        ),
    );
}

function txFields($type, $scope = 'add') {
    $pfx      = ($scope === 'add') ? ($type . '_') : ('edit_' . $type . '_');
    $name_pfx = $type . '_';
    $html_note = '<small style="font-weight:400;color:#9b59b6">HTML 허용: &lt;br&gt; &lt;p&gt; &lt;span style=""&gt; &lt;strong&gt; &lt;img src="" style=""&gt; 등 가능</small>';
    ob_start();
?>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:4px">
  <div class="form-group" style="grid-column:1/-1">
    <label class="form-label">소제목 <?php echo $html_note; ?></label>
    <textarea name="<?php echo $name_pfx; ?>subtitle" id="<?php echo $pfx; ?>subtitle" class="u-input" rows="2" placeholder="예: 대한민국 100대 명의&#10;<br> 줄바꿈, <span style=&quot;color:#ffd700&quot;>강조색</span> 가능"></textarea>
  </div>
  <div class="form-group" style="grid-column:1/-1">
    <label class="form-label">제목 <?php echo $html_note; ?></label>
    <textarea style="min-height: 200px;" name="<?php echo $name_pfx; ?>title" id="<?php echo $pfx; ?>title" class="u-input" rows="3" placeholder="메인 제목&#10;<strong>굵게</strong>, <br> 줄바꿈, <span style=&quot;font-size:1.2em&quot;>크게</span> 등 가능"></textarea>
  </div>
  <div class="form-group" style="grid-column:1/-1">
    <label class="form-label">설명 문구 <?php echo $html_note; ?></label>
    <textarea style="min-height: 200px;" name="<?php echo $name_pfx; ?>description" id="<?php echo $pfx; ?>description" class="u-input" rows="3" placeholder="설명 문구&#10;<p>단락</p>, <br> 줄바꿈, <em>기울임</em> 등 가능"></textarea>
  </div>
  <div class="form-group">
    <label class="form-label">버튼 텍스트</label>
    <input type="text" name="<?php echo $name_pfx; ?>button_text" id="<?php echo $pfx; ?>button_text" class="u-input" placeholder="예: 자세히 보기">
  </div>
  <div class="form-group">
    <label class="form-label">버튼 링크</label>
    <input type="url" name="<?php echo $name_pfx; ?>button_link" id="<?php echo $pfx; ?>button_link" class="u-input" placeholder="https://...">
  </div>
  <div class="form-group">
    <label class="form-label">텍스트 색상</label>
    <div class="color-row">
      <input type="color" name="<?php echo $name_pfx; ?>text_color" id="<?php echo $pfx; ?>text_color" value="#ffffff" class="color-swatch"
             oninput="document.getElementById('<?php echo $pfx; ?>text_color_hex').value=this.value">
      <input type="text" id="<?php echo $pfx; ?>text_color_hex" value="#ffffff" class="u-input" readonly style="flex:1">
    </div>
  </div>
  <div class="form-group">
    <label class="form-label">텍스트 정렬</label>
    <select name="<?php echo $name_pfx; ?>text_position" id="<?php echo $pfx; ?>text_position" class="u-input">
      <option value="left">왼쪽</option>
      <option value="center">중앙</option>
      <option value="right">오른쪽</option>
    </select>
  </div>
</div>
<?php
    return ob_get_clean();
}

// ============================================================
// 테이블 자동 생성
// ============================================================
sql_query("CREATE TABLE IF NOT EXISTS `mainbanner` (
    `id`            INT(11) NOT NULL AUTO_INCREMENT,
    `name`          VARCHAR(255) DEFAULT NULL,
    `images`        LONGTEXT DEFAULT NULL,
    `settings`      LONGTEXT DEFAULT NULL,
    `text_settings` LONGTEXT DEFAULT NULL,
    `is_main`       TINYINT(1) DEFAULT 0,
    `created_at`    DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ============================================================
// 컬럼 자가치유 (구버전 테이블에 빠진 컬럼 자동 추가)
// ============================================================
$__need_cols = array(
    'name'          => "VARCHAR(255) DEFAULT NULL",
    'images'        => "LONGTEXT DEFAULT NULL",
    'settings'      => "LONGTEXT DEFAULT NULL",
    'text_settings' => "LONGTEXT DEFAULT NULL",
    'is_main'       => "TINYINT(1) DEFAULT 0",
    'created_at'    => "DATETIME DEFAULT NULL",
);
$__exist = array();
$__res = sql_query("SHOW COLUMNS FROM mainbanner");
while ($__c = sql_fetch_array($__res)) {
    $__exist[$__c['Field']] = true;
}
$__added = array();
foreach ($__need_cols as $__col => $__def) {
    if (!isset($__exist[$__col])) {
        sql_query("ALTER TABLE mainbanner ADD COLUMN `$__col` $__def");
        $__added[] = $__col;
    }
}
if (!empty($__added) && isset($_GET['migrate'])) {
    echo '<pre style="padding:20px;font-size:14px;background:#e8f5e9">';
    echo "추가된 컬럼: " . implode(', ', $__added) . "\n";
    echo "현재 컬럼 다시 확인 ↓\n";
    $__r2 = sql_query("SHOW COLUMNS FROM mainbanner");
    while ($__c2 = sql_fetch_array($__r2)) echo " - " . $__c2['Field'] . "\n";
    echo '</pre>';
    exit;
}

// ============================================================
// AJAX 처리
// ============================================================
if (isset($_POST['set_main_banner'])) {
    sql_query("UPDATE mainbanner SET is_main = 0");
    sql_query("UPDATE mainbanner SET is_main = 1 WHERE id = " . (int)$_POST['banner_id']);
    echo json_encode(array('success' => true, 'message' => '메인 배너로 설정되었습니다.'));
    exit;
}

if (isset($_POST['action']) && $_POST['action'] === 'reorder_images') {
    $bid  = (int)$_POST['banner_id'];
    $ord  = json_decode($_POST['order'], true);
    $row  = sql_fetch("SELECT images FROM mainbanner WHERE id = $bid");
    $imgs = json_decode($row['images'], true);
    if (!is_array($imgs)) $imgs = array();
    $re = array();
    foreach ($ord as $idx) {
        if (isset($imgs[$idx])) $re[] = $imgs[$idx];
    }
    foreach ($re as $i => &$img) $img['order'] = $i + 1;
    unset($img);
    $json = addslashes(json_encode($re, JSON_UNESCAPED_UNICODE));
    sql_query("UPDATE mainbanner SET images = '$json' WHERE id = $bid");
    ob_clean();
    echo json_encode(array('success' => true));
    exit;
}

// ============================================================
// POST 처리
// ============================================================
if (isset($_POST['action']) && $_POST['action'] === 'create_group') {
    $name = sql_real_escape_string(trim($_POST['banner_name']));
    $now  = date('Y-m-d H:i:s');
    sql_query("INSERT INTO mainbanner (name, created_at) VALUES ('$name', '$now')");
    alert_toast('배너 그룹이 생성되었습니다.', './banner_manager.php');
    exit;
}

if (isset($_POST['action']) && $_POST['action'] === 'update_settings') {
    $bid = (int)$_POST['banner_id'];
    $s   = addslashes(json_encode(array(
        'autoplay_delay' => (int)$_POST['autoplay_delay'],
        'effect'         => sql_real_escape_string($_POST['effect']),
        'loop'           => isset($_POST['loop']) ? 1 : 0,
        'speed'          => (int)$_POST['speed'],
    )));
    sql_query("UPDATE mainbanner SET settings = '$s' WHERE id = $bid");
    alert_toast('설정이 저장되었습니다.', "./banner_manager.php?edit=$bid");
    exit;
}

if (isset($_POST['action']) && $_POST['action'] === 'add_image') {
    $bid = (int)$_POST['banner_id'];
    $dir = $_SERVER['DOCUMENT_ROOT'] . '/data/banner/';
    if (!is_dir($dir)) mkdir($dir, 0755, true);

    $upload_errors = array(
        UPLOAD_ERR_INI_SIZE   => '파일이 너무 큽니다 (서버 upload_max_filesize 초과). php.ini 설정을 확인하세요.',
        UPLOAD_ERR_FORM_SIZE  => '파일이 너무 큽니다 (폼 MAX_FILE_SIZE 초과).',
        UPLOAD_ERR_PARTIAL    => '파일이 일부만 업로드됐습니다. 다시 시도하세요.',
        UPLOAD_ERR_NO_FILE    => '파일이 선택되지 않았습니다.',
        UPLOAD_ERR_NO_TMP_DIR => '서버 임시 폴더가 없습니다. 관리자에게 문의하세요.',
        UPLOAD_ERR_CANT_WRITE => '서버 디스크 쓰기 실패. 폴더 권한을 확인하세요.',
        UPLOAD_ERR_EXTENSION  => '서버 확장 기능이 업로드를 차단했습니다.',
    );

    if (!isset($_FILES['banner_image']) || $_FILES['banner_image']['error'] !== UPLOAD_ERR_OK) {
        $ec  = isset($_FILES['banner_image']) ? $_FILES['banner_image']['error'] : UPLOAD_ERR_NO_FILE;
        $msg = isset($upload_errors[$ec]) ? $upload_errors[$ec] : '알 수 없는 업로드 오류 (코드:' . $ec . ')';
        alert_toast('❌ 업로드 실패: ' . $msg, "./banner_manager.php?edit=$bid");
        exit;
    }

    $file          = $_FILES['banner_image'];
    $ext           = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $allowed_img   = array('jpg','jpeg','png','gif','webp');
    $allowed_video = array('mp4','webm','mov','ogg');
    $allowed       = array_merge($allowed_img, $allowed_video);
    $file_type     = in_array($ext, $allowed_video) ? 'video' : 'image';

    if (!in_array($ext, $allowed)) {
        alert_toast('❌ 허용되지 않는 파일 형식입니다: .' . $ext, "./banner_manager.php?edit=$bid");
        exit;
    }
    if (!is_writable($dir)) {
        alert_toast('❌ 업로드 폴더 쓰기 권한 없음: ' . $dir, "./banner_manager.php?edit=$bid");
        exit;
    }

    $fn = 'banner_' . time() . '_' . rand(1000,9999) . '.' . $ext;
    if (!move_uploaded_file($file['tmp_name'], $dir . $fn)) {
        alert_toast('❌ 파일 이동 실패. 서버 권한 또는 경로를 확인하세요.', "./banner_manager.php?edit=$bid");
        exit;
    }

    $row  = sql_fetch("SELECT images FROM mainbanner WHERE id = $bid");
    $imgs = json_decode($row['images'], true);
    if (!is_array($imgs)) $imgs = array();

    $fn_mob = '';
    if (isset($_FILES['banner_image_mobile']) && $_FILES['banner_image_mobile']['error'] === UPLOAD_ERR_OK) {
        $file_mob = $_FILES['banner_image_mobile'];
        $ext_mob  = strtolower(pathinfo($file_mob['name'], PATHINFO_EXTENSION));
        if (in_array($ext_mob, $allowed)) {
            $fn_mob = 'banner_mob_' . time() . '_' . rand(1000,9999) . '.' . $ext_mob;
            if (!move_uploaded_file($file_mob['tmp_name'], $dir . $fn_mob)) $fn_mob = '';
        }
    }

    $imgs[] = array(
        'src'             => '/data/banner/' . $fn,
        'type'            => $file_type,
        'src_mobile'      => $fn_mob ? '/data/banner/' . $fn_mob : '',
        'order'           => count($imgs) + 1,
        'visible'         => isset($_POST['visible']) ? 1 : 0,
        'alt'             => isset($_POST['alt']) ? trim($_POST['alt']) : '',
        'link'            => isset($_POST['link']) ? trim($_POST['link']) : '',
        'link_target'     => isset($_POST['link_target']) ? '_blank' : '_self',
        'start_date'      => (isset($_POST['start_date']) && trim($_POST['start_date'])) ? trim($_POST['start_date']) : null,
        'end_date'        => (isset($_POST['end_date'])   && trim($_POST['end_date']))   ? trim($_POST['end_date'])   : null,
        'overlay_color'   => isset($_POST['overlay_color']) ? trim($_POST['overlay_color']) : '#000000',
        'overlay_opacity' => isset($_POST['overlay_opacity']) ? (float)$_POST['overlay_opacity'] : 0,
        'text_settings'   => build_ts(),
    );
    $json = addslashes(json_encode($imgs, JSON_UNESCAPED_UNICODE));
    sql_query("UPDATE mainbanner SET images = '$json' WHERE id = $bid");
    alert_toast('✅ ' . ($file_type === 'video' ? '영상' : '이미지') . '가 추가되었습니다.', "./banner_manager.php?edit=$bid");
    exit;
}

if (isset($_POST['action']) && $_POST['action'] === 'update_image') {
    $bid = (int)$_POST['banner_id'];
    $idx = (int)$_POST['image_index'];
    $row  = sql_fetch("SELECT images FROM mainbanner WHERE id = $bid");
    $imgs = json_decode($row['images'], true);
    if (!is_array($imgs)) $imgs = array();
    if (!isset($imgs[$idx])) {
        alert_toast('이미지를 찾을 수 없습니다.', "./banner_manager.php?edit=$bid");
        exit;
    }
    $imgs[$idx]['visible']         = isset($_POST['visible']) ? 1 : 0;
    $imgs[$idx]['alt']             = isset($_POST['alt']) ? trim($_POST['alt']) : '';
    $imgs[$idx]['link']            = isset($_POST['link']) ? trim($_POST['link']) : '';
    $imgs[$idx]['link_target']     = isset($_POST['link_target']) ? '_blank' : '_self';
    $imgs[$idx]['start_date']      = (isset($_POST['start_date']) && trim($_POST['start_date'])) ? trim($_POST['start_date']) : null;
    $imgs[$idx]['end_date']        = (isset($_POST['end_date'])   && trim($_POST['end_date']))   ? trim($_POST['end_date'])   : null;
    $imgs[$idx]['overlay_color']   = isset($_POST['overlay_color'])   ? trim($_POST['overlay_color'])     : '#000000';
    $imgs[$idx]['overlay_opacity'] = isset($_POST['overlay_opacity']) ? (float)$_POST['overlay_opacity'] : 0;
    $imgs[$idx]['text_settings']   = build_ts();

    // ★ 웹 이미지 교체 (새 파일 선택 시에만)
    if (isset($_FILES['banner_image_web']) && $_FILES['banner_image_web']['error'] === UPLOAD_ERR_OK) {
        $dir2     = $_SERVER['DOCUMENT_ROOT'] . '/data/banner/';
        $file_web = $_FILES['banner_image_web'];
        $ext_web  = strtolower(pathinfo($file_web['name'], PATHINFO_EXTENSION));
        $allowed_web = array('jpg','jpeg','png','gif','webp','mp4','webm','mov','ogg');
        if (in_array($ext_web, $allowed_web)) {
            if (!empty($imgs[$idx]['src'])) {
                $old_web = $_SERVER['DOCUMENT_ROOT'] . $imgs[$idx]['src'];
                if (file_exists($old_web)) @unlink($old_web);
            }
            $fn_web = 'banner_' . time() . '_' . rand(1000,9999) . '.' . $ext_web;
            if (move_uploaded_file($file_web['tmp_name'], $dir2 . $fn_web)) {
                $imgs[$idx]['src']  = '/data/banner/' . $fn_web;
                $imgs[$idx]['type'] = in_array($ext_web, array('mp4','webm','mov','ogg')) ? 'video' : 'image';
            }
        }
    }

    // 모바일 이미지 교체 (새 파일 선택 시에만)
    if (isset($_FILES['banner_image_mobile']) && $_FILES['banner_image_mobile']['error'] === UPLOAD_ERR_OK) {
        $dir2     = $_SERVER['DOCUMENT_ROOT'] . '/data/banner/';
        $file_mob = $_FILES['banner_image_mobile'];
        $ext_mob  = strtolower(pathinfo($file_mob['name'], PATHINFO_EXTENSION));
        $allowed2 = array('jpg','jpeg','png','gif','webp');
        if (in_array($ext_mob, $allowed2)) {
            if (!empty($imgs[$idx]['src_mobile'])) {
                $old_mob = $_SERVER['DOCUMENT_ROOT'] . $imgs[$idx]['src_mobile'];
                if (file_exists($old_mob)) @unlink($old_mob);
            }
            $fn_mob = 'banner_mob_' . time() . '_' . rand(1000,9999) . '.' . $ext_mob;
            if (move_uploaded_file($file_mob['tmp_name'], $dir2 . $fn_mob)) {
                $imgs[$idx]['src_mobile'] = '/data/banner/' . $fn_mob;
            }
        }
    }
    // 모바일 이미지 삭제 요청
    if (isset($_POST['delete_mobile_img']) && $_POST['delete_mobile_img'] == '1') {
        if (!empty($imgs[$idx]['src_mobile'])) {
            $old_mob = $_SERVER['DOCUMENT_ROOT'] . $imgs[$idx]['src_mobile'];
            if (file_exists($old_mob)) @unlink($old_mob);
        }
        $imgs[$idx]['src_mobile'] = '';
    }
    $json = addslashes(json_encode($imgs, JSON_UNESCAPED_UNICODE));
    sql_query("UPDATE mainbanner SET images = '$json' WHERE id = $bid");
    alert_toast('수정되었습니다.', "./banner_manager.php?edit=$bid");
    exit;
}

// ============================================================
// GET 처리
// ============================================================
if (isset($_GET['delete_group'])) {
    $bid  = (int)$_GET['delete_group'];
    $row  = sql_fetch("SELECT images FROM mainbanner WHERE id = $bid");
    $imgs = json_decode($row['images'], true);
    if (is_array($imgs)) {
        foreach ($imgs as $img) {
            $f = $_SERVER['DOCUMENT_ROOT'] . $img['src'];
            if (file_exists($f)) @unlink($f);
            if (!empty($img['src_mobile'])) {
                $fm = $_SERVER['DOCUMENT_ROOT'] . $img['src_mobile'];
                if (file_exists($fm)) @unlink($fm);
            }
        }
    }
    sql_query("DELETE FROM mainbanner WHERE id = $bid");
    alert_toast('삭제되었습니다.', './banner_manager.php');
    exit;
}

if (isset($_GET['delete_image'])) {
    $bid  = (int)$_GET['banner_id'];
    $idx  = (int)$_GET['delete_image'];
    $row  = sql_fetch("SELECT images FROM mainbanner WHERE id = $bid");
    $imgs = json_decode($row['images'], true);
    if (is_array($imgs) && isset($imgs[$idx])) {
        $f = $_SERVER['DOCUMENT_ROOT'] . $imgs[$idx]['src'];
        if (file_exists($f)) @unlink($f);
        if (!empty($imgs[$idx]['src_mobile'])) {
            $fm = $_SERVER['DOCUMENT_ROOT'] . $imgs[$idx]['src_mobile'];
            if (file_exists($fm)) @unlink($fm);
        }
        array_splice($imgs, $idx, 1);
        foreach ($imgs as $i => &$img) $img['order'] = $i + 1;
        unset($img);
        $json = addslashes(json_encode($imgs, JSON_UNESCAPED_UNICODE));
        sql_query("UPDATE mainbanner SET images = '$json' WHERE id = $bid");
    }
    alert_toast('삭제되었습니다.', "./banner_manager.php?edit=$bid");
    exit;
}

// ============================================================
// 화면 데이터
// ============================================================
$banners_result = sql_query("SELECT * FROM mainbanner ORDER BY is_main DESC, created_at DESC");
$edit_mode      = isset($_GET['edit']);
$edit_id        = $edit_mode ? (int)$_GET['edit'] : 0;
$edit_banner    = null;
$edit_images    = array();
$edit_settings  = array('autoplay_delay' => 3000, 'effect' => 'slide', 'loop' => 1, 'speed' => 600);

if ($edit_mode) {
    $edit_banner = sql_fetch("SELECT * FROM mainbanner WHERE id = $edit_id");
    if (!$edit_banner) {
        alert_toast('배너를 찾을 수 없습니다.', './banner_manager.php');
        exit;
    }
    $edit_images = json_decode($edit_banner['images'], true);
    if (!is_array($edit_images)) $edit_images = array();
    $saved = json_decode($edit_banner['settings'], true);
    if (is_array($saved)) $edit_settings = $saved;
}

$no_img = "https://upload.wikimedia.org/wikipedia/commons/1/14/No_Image_Available.jpg";
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>배너 관리</title>
<script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js"></script>
<style>
@import url('https://cdn.jsdelivr.net/gh/orioncactus/pretendard/dist/web/static/pretendard.css');
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'Pretendard','Apple SD Gothic Neo',sans-serif;background:#f5f6fa;color:#1a1a2e;}
#admin_wrapper{display:flex;min-height:100vh;}
.content_area{flex:1;padding:40px;overflow-x:hidden;}
.card_custom{background:#fff;border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,0.06);border:1px solid #e8eaf0;padding:24px;margin-bottom:24px;}
.banner-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:20px;}
.banner-card{border:1px solid #e8eaf0;border-radius:12px;padding:20px;position:relative;transition:.2s;background:#fff;box-shadow:0 2px 10px rgba(0,0,0,.05);}
.banner-card:hover{border-color:#c4b5fd;box-shadow:0 8px 24px rgba(0,0,0,.08);}
.banner-card.main-banner{border-color:#4f46e5;background:linear-gradient(135deg,#f5f3ff,#ede9fe);}
.main-badge{position:absolute;top:-10px;right:-10px;background:#4f46e5;color:#fff;padding:5px 12px;border-radius:20px;font-size:11px;font-weight:700;box-shadow:0 4px 12px rgba(79,70,229,.4);animation:pulse 2s infinite;z-index:10;}
@keyframes pulse{0%,100%{box-shadow:0 0 0 0 rgba(79,70,229,.7)}50%{box-shadow:0 0 0 8px rgba(79,70,229,0)}}
.id-badge{display:inline-flex;align-items:center;gap:6px;background:#ede9fe;color:#4f46e5;padding:4px 10px;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer;transition:.2s;}
.id-badge:hover{background:#4f46e5;color:#fff;}
.btn_primary{padding:11px 22px;background:#4f46e5;color:#fff;border:none;border-radius:9px;font-size:13px;font-weight:700;cursor:pointer;box-shadow:0 4px 12px rgba(79,70,229,.25);transition:all .2s;text-decoration:none;display:inline-block;}
.btn_primary:hover{background:#4338ca;}
.btn_secondary{padding:9px 18px;background:#059669;color:#fff;border:none;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer;transition:all .2s;}
.btn_secondary:hover{background:#047857;}
.btn_neutral{padding:9px 18px;background:#f5f6fa;color:#5c5c7a;border:1px solid #e8eaf0;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer;transition:all .2s;text-decoration:none;display:inline-block;}
.btn_neutral:hover{background:#e8eaf0;}
.btn_danger{padding:9px 18px;background:#fee2e2;color:#dc2626;border:none;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer;transition:all .2s;}
.btn_danger:hover{background:#fecaca;}
.btn_sm_edit{padding:7px 14px;background:#4f46e5;color:#fff;border:none;border-radius:7px;font-size:12px;font-weight:700;cursor:pointer;transition:.2s;width:100%;}
.btn_sm_edit:hover{background:#4338ca;}
.btn_sm_del{padding:7px 14px;background:#fee2e2;color:#dc2626;border:none;border-radius:7px;font-size:12px;font-weight:700;cursor:pointer;transition:.2s;width:100%;}
.btn_sm_del:hover{background:#fecaca;}
.page_header{display:flex;align-items:center;justify-content:space-between;margin-bottom:24px;flex-wrap:wrap;gap:12px;}
.page_title{font-size:22px;font-weight:700;}
.section_title{font-size:15px;font-weight:700;margin-bottom:20px;padding-bottom:12px;border-bottom:1px solid #e8eaf0;}
#imageList{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:16px;}
.img-card{background:#fff;border:1px solid #e8eaf0;border-radius:12px;overflow:hidden;cursor:grab;transition:.2s;position:relative;}
.img-card:hover{border-color:#c4b5fd;box-shadow:0 6px 20px rgba(0,0,0,.08);}
.img-card-thumb{width:100%;height:160px;object-fit:cover;display:block;}
.img-card-body{padding:12px;}
.img-badge{position:absolute;top:8px;right:8px;background:#4f46e5;color:#fff;border-radius:20px;padding:3px 10px;font-size:11px;font-weight:700;z-index:5;}
.img-badge.off{background:#9999bb;}
.sortable-ghost{opacity:.4;border:2px dashed #4f46e5 !important;}
.add-grid { display:grid; grid-template-columns:1fr 1fr; gap:24px; }
@media(max-width:860px){ .add-grid { grid-template-columns:1fr; } }
.preview-wrap { position:sticky; top:20px; background:#000; border-radius:14px; overflow:hidden; aspect-ratio:16/9; display:flex; align-items:center; justify-content:center; min-height:200px; transition:.4s; }
.preview-wrap.mob { aspect-ratio:9/19; max-width:260px; margin:0 auto; }
.preview-bg { position:absolute; inset:0; background-size:cover; background-position:center; transition:.4s; }
.preview-overlay { position:absolute; inset:0; display:flex; flex-direction:column; justify-content:flex-end; padding:24px; pointer-events:none; }
.preview-overlay.pos-center { justify-content:center; align-items:center; text-align:center; }
.preview-overlay.pos-right  { align-items:flex-end; text-align:right; }
.prev-subtitle { font-size:12px; font-weight:600; margin-bottom:5px; opacity:.9; }
.prev-title    { font-size:20px; font-weight:800; line-height:1.3; margin-bottom:8px; }
.prev-desc     { font-size:11px; line-height:1.6; opacity:.85; margin-bottom:12px; }
.prev-btn      { display:inline-block; background:#4f46e5; color:#fff; padding:6px 16px; border-radius:8px; font-size:12px; font-weight:700; }
.prev-empty    { color:#666; font-size:13px; text-align:center; line-height:1.7; }
.view-sw { display:flex; background:#f5f6fa; border-radius:10px; padding:3px; gap:3px; width:fit-content; }
.view-sw button { padding:6px 14px; border-radius:8px; border:none; background:transparent; font-size:13px; font-weight:600; color:#5c5c7a; cursor:pointer; transition:.2s; }
.view-sw button.on { background:#fff; color:#4f46e5; box-shadow:0 2px 8px rgba(0,0,0,.1); }
.txt-tab-bar { display:flex; border-bottom:2px solid #e8eaf0; margin-bottom:14px; }
.txt-tab { padding:8px 20px; border:none; background:transparent; font-weight:600; font-size:13px; color:#9999bb; cursor:pointer; border-bottom:2px solid transparent; margin-bottom:-2px; transition:.2s; }
.txt-tab.on { color:#4f46e5; border-bottom-color:#4f46e5; }
.txt-panel { display:none; }
.txt-panel.on { display:block; }
.txt-box { background:#f5f6fa; border-radius:12px; padding:18px; border:2px dashed #d1d5e0; margin-top:16px; }
.upload-area { border:2px dashed #d1d5e0; border-radius:12px; padding:28px; text-align:center; cursor:pointer; transition:.2s; background:#f5f6fa; }
.upload-area:hover, .upload-area.on { border-color:#4f46e5; background:#f0f7ff; }
.upload-area input[type="file"] { display:none; }
.form-label{display:block;font-weight:700;font-size:12px;color:#9999bb;margin-bottom:6px;}
.u-input{width:100%;padding:10px 14px;border:1px solid #e8eaf0;border-radius:8px;font-size:14px;background:#f5f6fa;transition:.2s;box-sizing:border-box;font-family:inherit;color:#1a1a2e;}
.u-input:focus{outline:none;border-color:#4f46e5;background:#fff;box-shadow:0 0 0 3px rgba(79,70,229,.1);}
.form-group{margin-bottom:14px;}
.color-row{display:flex;align-items:center;gap:10px;}
.color-swatch{width:44px;height:44px;border-radius:8px;border:1px solid #e8eaf0;cursor:pointer;padding:2px;}
.bm-modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:9999;align-items:center;justify-content:center;}
.bm-modal.on{display:flex;}
.bm-box{background:#fff;border-radius:14px;padding:32px;max-width:880px;width:94%;max-height:92vh;overflow-y:auto;}
.modal-hd{display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;}
.modal-close{background:none;border:none;font-size:20px;cursor:pointer;color:#9999bb;}
.modal-close:hover{color:#1a1a2e;}
.modal-ft{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:16px;}
.toast-alert{position:fixed;top:20px;right:20px;background:#fff;padding:20px;border-radius:12px;box-shadow:0 8px 24px rgba(0,0,0,.12);z-index:10000;min-width:280px;animation:sIn .3s ease-out;border-left:4px solid #4f46e5;}
@keyframes sIn{from{transform:translateX(400px);opacity:0}to{transform:translateX(0);opacity:1}}
@keyframes sOut{from{transform:translateX(0);opacity:1}to{transform:translateX(400px);opacity:0}}
</style>
</head>
<body>
<div id="admin_wrapper">
<?php include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/aside.php'); ?>
<main class="content_area">

<?php if (!$edit_mode): ?>
<!-- ============ 그룹 목록 ============ -->
<div class="page_header">
  <h2 class="page_title">배너 그룹 관리</h2>
  <button onclick="openM('createModal')" class="btn_primary">+ 새 배너 그룹 생성</button>
</div>
<div class="card_custom">
  <div class="banner-grid">
  <?php
  $cnt = 0;
  while ($row = sql_fetch_array($banners_result)):
      $cnt++;
      $ri      = json_decode($row['images'], true);
      if (!is_array($ri)) $ri = array();
      $is_main = (bool)$row['is_main'];
  ?>
    <div class="banner-card <?php echo $is_main ? 'main-banner' : ''; ?>">
      <?php if ($is_main): ?><div class="main-badge">★ 메인</div><?php endif; ?>
      <h4 style="font-size:16px;font-weight:700;margin-bottom:8px;"><?php echo htmlspecialchars($row['name']); ?></h4>
      <div style="margin-bottom:10px;"><span class="id-badge" onclick="cpId(<?php echo $row['id']; ?>)"># <?php echo $row['id']; ?></span></div>
      <div style="display:flex;gap:4px;margin-bottom:10px;height:100px;overflow:hidden;border-radius:8px;">
        <?php
        $pv = array_slice(array_reverse($ri), 0, 3);
        if ($pv):
            foreach ($pv as $p):
        ?>
          <img src="<?php echo htmlspecialchars($p['src']); ?>" style="flex:1;width:0;height:100%;object-fit:cover;" onerror="this.src='<?php echo $no_img; ?>'">
        <?php endforeach;
            if (count($ri) > 3):
        ?>
          <div style="flex:.4;background:#f5f6fa;display:flex;align-items:center;justify-content:center;font-size:11px;color:#5c5c7a;">+<?php echo count($ri) - 3; ?></div>
        <?php endif; else: ?>
          <div style="width:100%;height:100%;background:#f5f5f5;display:flex;align-items:center;justify-content:center;color:#ccc;font-size:12px;">이미지 없음</div>
        <?php endif; ?>
      </div>
      <p style="font-size:13px;color:#9999bb;margin-bottom:14px;">이미지 <?php echo count($ri); ?>개</p>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;">
        <?php if (!$is_main): ?>
        <button onclick="setMain(<?php echo $row['id']; ?>)" class="btn_secondary" style="grid-column:1/-1;">메인으로 설정</button>
        <?php endif; ?>
        <a href="?edit=<?php echo $row['id']; ?>" class="btn_primary" style="text-align:center;">관리</a>
        <button onclick="if(confirm('삭제하시겠습니까?'))location.href='?delete_group=<?php echo $row['id']; ?>'" class="btn_neutral">삭제</button>
      </div>
    </div>
  <?php endwhile; ?>
  <?php if ($cnt === 0): ?><p style="text-align:center;color:#9999bb;padding:40px 0;font-size:14px;">배너 그룹이 없습니다.</p><?php endif; ?>
  </div>
</div>

<?php else: ?>
<!-- ============ 편집 모드 ============ -->
<div class="page_header">
  <h2 class="page_title"><?php echo htmlspecialchars($edit_banner['name']); ?></h2>
  <a href="./banner_manager.php" class="btn_neutral">← 목록으로</a>
</div>

<!-- Swiper 설정 -->
<div class="card_custom">
  <div class="section_title">⚙️ Swiper 설정</div>
  <form method="post" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:16px;align-items:end;">
    <input type="hidden" name="action" value="update_settings">
    <input type="hidden" name="banner_id" value="<?php echo $edit_id; ?>">
    <div class="form-group">
      <label class="form-label">Autoplay Delay (ms)</label>
      <input type="number" name="autoplay_delay" class="u-input" value="<?php echo (int)$edit_settings['autoplay_delay']; ?>" required>
      <small style="font-size:11px;color:#9999bb;">자동 넘김 시간 (기본 3000)</small>
    </div>
    <div class="form-group">
      <label class="form-label">전환 속도 (ms)</label>
      <input type="number" name="speed" class="u-input" value="<?php echo (int)$edit_settings['speed']; ?>" required>
    </div>
    <div class="form-group">
      <label class="form-label">Effect</label>
      <select name="effect" class="u-input">
        <?php foreach (array('slide','fade','cube','coverflow','flip') as $ef): ?>
        <option value="<?php echo $ef; ?>" <?php echo $edit_settings['effect'] === $ef ? 'selected' : ''; ?>><?php echo ucfirst($ef); ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-group">
      <label class="form-label">무한 반복</label>
      <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:13px;font-weight:600;margin-top:10px;">
        <input type="checkbox" name="loop" value="1" <?php echo $edit_settings['loop'] ? 'checked' : ''; ?>>
        Loop 활성화
      </label>
    </div>
    <div style="display:flex;align-items:flex-end;padding-bottom:4px;">
      <button type="submit" class="btn_primary" style="width:100%;">설정 저장</button>
    </div>
  </form>
</div>

<!-- ============ 이미지 추가 ============ -->
<div class="card_custom">
  <div class="section_title">➕ 이미지 추가</div>
  <form method="post" enctype="multipart/form-data">
    <input type="hidden" name="action" value="add_image">
    <input type="hidden" name="banner_id" value="<?php echo $edit_id; ?>">
    <div class="add-grid">
      <div>
        <div class="form-group">
          <label class="form-label">이미지 / 영상 파일 *</label>
          <div class="upload-area" id="uploadArea" onclick="document.getElementById('fileIn').click()">
            <input type="file" id="fileIn" name="banner_image" accept="image/*,video/mp4,video/webm,video/ogg,.mov" required onchange="onFile(this)">
            <div id="uploadPh">
              <div style="font-size:34px;margin-bottom:8px">🖼️</div>
              <div style="font-weight:700;font-size:15px;margin-bottom:4px">클릭하여 이미지 또는 영상 선택</div>
              <div style="font-size:12px;color:#9999bb">JPG · PNG · GIF · WEBP · MP4 · WEBM · MOV</div>
            </div>
            <div id="uploadOk" style="display:none;font-weight:700;font-size:14px;color:#4f46e5">
              ✅ <span id="uploadName"></span>
            </div>
          </div>
        </div>

        <div class="form-group" style="margin-top:12px">
          <label class="form-label">📱 모바일 이미지/영상 <small style="font-weight:400;color:#aaa">선택 안 하면 웹 파일 그대로 사용 (992px 이하)</small></label>
          <div class="upload-area" id="uploadAreaMob" onclick="document.getElementById('fileInMob').click()">
            <input type="file" id="fileInMob" name="banner_image_mobile" accept="image/*,video/mp4,video/webm,video/ogg,.mov" onchange="onFileMob(this)">
            <div id="uploadPhMob">
              <div style="font-size:24px;margin-bottom:6px">📱</div>
              <div style="font-weight:700;font-size:14px;margin-bottom:4px">모바일 파일 선택 (선택)</div>
              <div style="font-size:12px;color:#9999bb">JPG · PNG · GIF · WEBP · MP4 · WEBM · MOV</div>
            </div>
            <div id="uploadOkMob" style="display:none;font-weight:700;font-size:14px;color:#9b59b6">
              ✅ <span id="uploadNameMob"></span>
            </div>
          </div>
        </div>

        <div class="form-group" style="margin-top:12px;padding:16px;background:#fff8e1;border-radius:10px;border:2px dashed #ffc107">
          <label class="form-label">🎨 오버레이 설정 <small style="font-weight:400;color:#999">이미지/영상 위에 반투명 색상 레이어</small></label>
          <div style="display:flex;flex-wrap:wrap;gap:16px;margin-top:10px;align-items:flex-end">
            <div>
              <label class="form-label" style="font-size:11px">색상</label>
              <div class="color-row">
                <input type="color" name="overlay_color" id="add_overlay_color" value="#000000" class="color-swatch"
                       oninput="document.getElementById('add_overlay_color_hex').value=this.value;updateOverlayPreview('add')">
                <input type="text" id="add_overlay_color_hex" value="#000000" class="u-input" readonly style="width:80px;flex:none">
              </div>
            </div>
            <div style="flex:1;min-width:160px">
              <label class="form-label" style="font-size:11px">투명도 <span id="add_overlay_opacity_val">0</span>%</label>
              <input type="range" name="overlay_opacity" id="add_overlay_opacity" min="0" max="90" value="0" step="5"
                     style="width:100%;margin-top:6px"
                     oninput="document.getElementById('add_overlay_opacity_val').textContent=this.value;updateOverlayPreview('add')">
            </div>
            <div>
              <label class="form-label" style="font-size:11px">미리보기</label>
              <div id="add_overlay_sample" style="width:44px;height:44px;border-radius:8px;border:2px solid #ddd;background:transparent"></div>
            </div>
          </div>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
          <div class="form-group" style="grid-column:1/-1">
            <label class="form-label">배너 링크 URL</label>
            <input type="url" name="link" class="u-input" placeholder="https://example.com">
            <label class="form-label" style="margin-top:10px">이미지 대체텍스트 (alt) <span style="color:#9999bb;font-weight:400">— SEO·접근성</span></label>
            <input type="text" name="alt" class="u-input" placeholder="예: 임플란트 상담 안내 배너">
            <label class="u-check-wrap u-mt-8"><input type="checkbox" name="link_target" value="1" class="u-check"><span>새 창에서 열기 (target="_blank")</span></label>
          </div>
          <div class="form-group">
            <label class="form-label">노출 상태</label>
            <label class="u-check-wrap u-mt-10"><input type="checkbox" name="visible" value="1" class="u-check" checked><span>노출</span></label>
          </div>
          <div class="form-group">
            <label class="form-label">노출 시작일</label>
            <input type="date" name="start_date" class="u-input">
          </div>
          <div class="form-group">
            <label class="form-label">노출 종료일</label>
            <input type="date" name="end_date" class="u-input">
          </div>
        </div>

        <div class="txt-box">
          <div style="font-weight:700;font-size:15px;margin-bottom:14px">📝 텍스트 설정</div>
          <div class="txt-tab-bar">
            <button type="button" class="txt-tab on" onclick="txTab(this,'add','web')">🖥️ 웹</button>
            <button type="button" class="txt-tab"    onclick="txTab(this,'add','mob')">📱 모바일</button>
          </div>
          <div class="txt-panel on" id="add-p-web"><?php echo txFields('web', 'add'); ?></div>
          <div class="txt-panel"    id="add-p-mob"><?php echo txFields('mob', 'add'); ?></div>
        </div>
      </div>

      <div>
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;flex-wrap:wrap;gap:8px">
          <div style="font-weight:700;font-size:15px">👁️ 미리보기</div>
          <div class="view-sw">
            <button type="button" class="on" onclick="vSw(this,'add','web')" id="add-sw-web">🖥️ 웹</button>
            <button type="button"             onclick="vSw(this,'add','mob')" id="add-sw-mob">📱 모바일</button>
          </div>
        </div>
        <div class="preview-wrap" id="add-pw">
          <div class="preview-bg" id="add-bg"></div>
          <div class="preview-overlay" id="add-ov">
            <div class="prev-empty" id="add-ph">이미지를 선택하면<br>미리보기가 표시됩니다</div>
            <div id="add-ct" style="display:none">
              <div class="prev-subtitle" id="add-sub"></div>
              <div class="prev-title"    id="add-ttl"></div>
              <div class="prev-desc"     id="add-dsc"></div>
              <div class="prev-btn"      id="add-btn" style="display:none"></div>
            </div>
          </div>
        </div>
        <p style="font-size:11px;color:#b0b4c4;text-align:center;margin-top:8px">※ 실제 화면과 다를 수 있습니다</p>
      </div>
    </div>

    <button type="submit" class="btn_primary" style="width:100%;margin-top:20px;font-size:15px;padding:14px;">➕ 이미지 추가</button>
  </form>
</div>

<!-- ============ 등록된 이미지 ============ -->
<div class="card_custom">
  <div class="section_title">📸 등록된 이미지 (<?php echo count($edit_images); ?>개)</div>
  <?php if (count($edit_images) > 0): ?>
  <div id="imageList">
  <?php foreach ($edit_images as $i => $img):
      $ts  = isset($img['text_settings']) ? $img['text_settings'] : array();
      $web = isset($ts['web'])    ? $ts['web']    : $ts;
      $mob = isset($ts['mobile']) ? $ts['mobile'] : array();
  ?>
    <div class="img-card" data-index="<?php echo $i; ?>">
      <span class="img-badge <?php echo $img['visible'] ? '' : 'off'; ?>"><?php echo $img['visible'] ? '노출' : '비노출'; ?></span>
      <?php $is_video = (isset($img['type']) && $img['type'] === 'video'); ?>
      <?php if ($is_video): ?>
      <video class="img-card-thumb" src="<?php echo htmlspecialchars($img['src']); ?>" muted playsinline style="object-fit:cover;width:100%;height:160px;display:block;border-radius:10px 10px 0 0;" onerror="this.style.background='#eee'"></video>
      <span style="position:absolute;top:8px;right:8px;background:rgba(0,0,0,.65);color:#fff;border-radius:6px;padding:2px 8px;font-size:10px;font-weight:700">🎬 영상</span>
      <?php else: ?>
      <img class="img-card-thumb" src="<?php echo htmlspecialchars($img['src']); ?>" onerror="this.src='<?php echo $no_img; ?>'" alt="<?php echo htmlspecialchars($img['alt'] ?? ''); ?>">
      <?php endif; ?>
      <?php
        $ov_color   = isset($img['overlay_color'])   ? $img['overlay_color']   : '#000000';
        $ov_opacity = isset($img['overlay_opacity']) ? (float)$img['overlay_opacity'] : 0;
      ?>
      <?php if ($ov_opacity > 0): ?>
      <div style="position:absolute;top:36px;left:8px;background:<?php echo htmlspecialchars($ov_color); ?>;opacity:<?php echo $ov_opacity/100; ?>;width:20px;height:20px;border-radius:4px;border:1px solid rgba(255,255,255,.5);" title="오버레이: <?php echo $ov_color; ?> <?php echo $ov_opacity; ?>%"></div>
      <?php endif; ?>
      <?php if (!empty($img['src_mobile'])): ?>
      <span style="position:absolute;top:8px;left:8px;background:#9b59b6;color:#fff;border-radius:6px;padding:2px 8px;font-size:10px;font-weight:700">📱 모바일별도</span>
      <?php endif; ?>
      <div class="img-card-body">
        <?php if (!empty($web['title']) || !empty($web['subtitle'])): ?>
        <div style="padding:8px;background:#f5f6fa;border-radius:8px;margin-bottom:8px;font-size:12px">
          <div style="color:#b0b4c4;margin-bottom:3px">🖥️ 웹</div>
          <?php if (!empty($web['subtitle'])): ?><div style="color:#9999bb"><?php echo htmlspecialchars($web['subtitle']); ?></div><?php endif; ?>
          <?php if (!empty($web['title'])): ?><div style="font-weight:700"><?php echo htmlspecialchars(strip_tags(str_replace('<br>', "\n", $web['title']))); ?></div><?php endif; ?>
        </div>
        <?php endif; ?>
        <?php if (!empty($mob['title'])): ?>
        <div style="padding:8px;background:#f3e8ff;border-radius:8px;margin-bottom:8px;font-size:12px">
          <div style="color:#9333ea;margin-bottom:3px">📱 모바일</div>
          <div style="font-weight:700"><?php echo htmlspecialchars(strip_tags(str_replace('<br>', "\n", $mob['title']))); ?></div>
        </div>
        <?php endif; ?>
        <div style="font-size:11px;color:#b0b4c4;margin-bottom:10px">
          순서 <strong><?php echo $img['order']; ?></strong> · 링크 <?php echo $img['link'] ? '✅' . ((!empty($img['link_target']) && $img['link_target'] === '_blank') ? ' 새창' : '') : '없음'; ?>
          <?php if ($img['start_date'] || $img['end_date']): ?>
          · <?php echo $img['start_date'] ?: '∞'; ?> ~ <?php echo $img['end_date'] ?: '∞'; ?>
          <?php endif; ?>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px">
          <button onclick='openEdit(<?php echo $i; ?>, <?php echo json_encode($img, JSON_HEX_APOS | JSON_HEX_QUOT); ?>)'
                  class="btn_sm_edit">✏️ 수정</button>
          <button onclick="if(confirm('삭제하시겠습니까?'))location.href='?delete_image=<?php echo $i; ?>&banner_id=<?php echo $edit_id; ?>'"
                  class="btn_sm_del">🗑️ 삭제</button>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
  </div>
  <?php else: ?>
  <p style="text-align:center;color:#9999bb;padding:40px 0;font-size:14px;">등록된 이미지가 없습니다.</p>
  <?php endif; ?>
</div>

<?php endif; ?>
</main>
</div>

<!-- 생성 모달 -->
<div id="createModal" class="bm-modal">
  <div class="bm-box" style="max-width:460px">
    <div class="modal-hd">
      <span style="font-size:16px;font-weight:700;">새 배너 그룹 생성</span>
      <button onclick="closeM('createModal')" class="modal-close">✕</button>
    </div>
    <form method="post">
      <input type="hidden" name="action" value="create_group">
      <div class="form-group" style="margin-bottom:16px;">
        <label class="form-label">배너 그룹 이름</label>
        <input type="text" name="banner_name" class="u-input" placeholder="예: 메인 배너" required>
      </div>
      <div class="modal-ft">
        <button type="button" onclick="closeM('createModal')" class="btn_neutral">취소</button>
        <button type="submit" class="btn_primary">생성</button>
      </div>
    </form>
  </div>
</div>

<!-- 수정 모달 -->
<div id="editModal" class="bm-modal">
  <div class="bm-box">
    <div class="modal-hd">
      <span style="font-size:16px;font-weight:700;">이미지 수정</span>
      <button onclick="closeM('editModal')" class="modal-close">✕</button>
    </div>
    <form method="post" enctype="multipart/form-data">
      <input type="hidden" name="action" value="update_image">
      <input type="hidden" name="banner_id" value="<?php echo $edit_id; ?>">
      <input type="hidden" name="image_index" id="eIdx">
      <div class="add-grid">
        <div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px">
            <div class="form-group" style="grid-column:1/-1">
              <label class="form-label">배너 링크 URL</label>
              <input type="url" name="link" id="eLink" class="u-input">
              <label class="form-label" style="margin-top:10px">이미지 대체텍스트 (alt)</label>
              <input type="text" name="alt" id="eAlt" class="u-input" placeholder="예: 임플란트 상담 안내 배너">
              <label style="display:flex;align-items:center;gap:8px;margin-top:8px;font-size:13px;cursor:pointer;">
                <input type="checkbox" name="link_target" id="eLinkTarget" value="1">새 창에서 열기
              </label>
            </div>
            <div class="form-group">
              <label class="form-label">노출</label>
              <label style="display:flex;align-items:center;gap:8px;margin-top:10px;font-size:13px;cursor:pointer;">
                <input type="checkbox" name="visible" value="1" id="eVis">노출
              </label>
            </div>
            <div class="form-group">
              <label class="form-label">시작일</label>
              <input type="date" name="start_date" id="eSt" class="u-input">
            </div>
            <div class="form-group">
              <label class="form-label">종료일</label>
              <input type="date" name="end_date" id="eEd" class="u-input">
            </div>
          </div>

          <!-- ★ 웹 이미지 교체 -->
          <div class="form-group" style="margin-bottom:12px;padding:14px;background:#f0f7ff;border-radius:10px;border:1px solid #bfdbfe;">
            <label class="form-label">🖥️ 웹 이미지/영상 교체 <small style="font-weight:400;color:#9999bb;">선택 시에만 교체됩니다</small></label>
            <div id="edit-web-preview" style="display:none;width:100%;height:80px;background-size:cover;background-position:center;border-radius:8px;margin-bottom:8px;position:relative;"></div>
            <div class="upload-area" style="padding:16px" onclick="document.getElementById('eFileWeb').click()">
              <input type="file" id="eFileWeb" name="banner_image_web" accept="image/*,video/mp4,video/webm,video/ogg,.mov" onchange="onEditFileWeb(this)">
              <div style="font-size:13px;color:#5c5c7a">클릭하여 웹 이미지/영상 교체</div>
            </div>
          </div>

          <!-- 모바일 이미지 수정 -->
          <div class="form-group" style="margin-top:12px;padding:14px;background:#f5f6fa;border-radius:10px;border:1px solid #e8eaf0;">
            <label class="form-label">📱 모바일 이미지 <small style="font-weight:400;color:#9999bb;">없으면 웹 이미지 사용</small></label>
            <div id="edit-mob-none" style="font-size:12px;color:#9999bb;margin-bottom:8px">현재 모바일 이미지 없음</div>
            <div id="edit-mob-preview" style="display:none;width:100%;height:80px;background-size:cover;background-position:center;border-radius:8px;margin-bottom:8px;position:relative">
              <button type="button" onclick="delMobImg()" style="position:absolute;top:4px;right:4px;background:rgba(0,0,0,.6);color:#fff;border:none;border-radius:50%;width:22px;height:22px;cursor:pointer;font-size:12px;line-height:1">✕</button>
            </div>
            <input type="hidden" name="delete_mobile_img" id="eDelMob" value="0">
            <div class="upload-area" style="padding:16px" onclick="document.getElementById('eFileMob').click()">
              <input type="file" id="eFileMob" name="banner_image_mobile" accept="image/*,video/mp4,video/webm,video/ogg,.mov" onchange="onEditFileMob(this)">
              <div style="font-size:13px;color:#5c5c7a">클릭하여 모바일 이미지/영상 교체</div>
            </div>
          </div>

          <!-- 오버레이 설정 -->
          <div class="form-group" style="margin-top:12px;padding:16px;background:#fffbeb;border-radius:10px;border:1px solid #fde68a;">
            <label class="form-label">🎨 오버레이 설정</label>
            <div style="display:flex;flex-wrap:wrap;gap:16px;margin-top:10px;align-items:flex-end">
              <div>
                <label class="form-label" style="font-size:11px">색상</label>
                <div class="color-row">
                  <input type="color" name="overlay_color" id="edit_overlay_color" value="#000000" class="color-swatch"
                         oninput="document.getElementById('edit_overlay_color_hex').value=this.value;updateOverlayPreview('edit')">
                  <input type="text" id="edit_overlay_color_hex" value="#000000" class="u-input" readonly style="width:80px;flex:none">
                </div>
              </div>
              <div style="flex:1;min-width:160px">
                <label class="form-label" style="font-size:11px">투명도 <span id="edit_overlay_opacity_val">0</span>%</label>
                <input type="range" name="overlay_opacity" id="edit_overlay_opacity" min="0" max="90" value="0" step="5"
                       style="width:100%;margin-top:6px"
                       oninput="document.getElementById('edit_overlay_opacity_val').textContent=this.value;updateOverlayPreview('edit')">
              </div>
              <div>
                <label class="form-label" style="font-size:11px">미리보기</label>
                <div id="edit_overlay_sample" style="width:44px;height:44px;border-radius:8px;border:1px solid #e8eaf0;background:transparent"></div>
              </div>
            </div>
          </div>

          <div class="txt-box">
            <div style="font-weight:700;font-size:14px;margin-bottom:14px">📝 텍스트 설정</div>
            <div class="txt-tab-bar">
              <button type="button" class="txt-tab on" onclick="txTab(this,'edit','web')">🖥️ 웹</button>
              <button type="button" class="txt-tab"    onclick="txTab(this,'edit','mob')">📱 모바일</button>
            </div>
            <div class="txt-panel on" id="edit-p-web"><?php echo txFields('web', 'edit'); ?></div>
            <div class="txt-panel"    id="edit-p-mob"><?php echo txFields('mob', 'edit'); ?></div>
          </div>
        </div>
        <!-- 미리보기 -->
        <div>
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;flex-wrap:wrap;gap:8px">
            <div style="font-weight:700;font-size:14px">👁️ 미리보기</div>
            <div class="view-sw">
              <button type="button" class="on" onclick="vSw(this,'edit','web')" id="edit-sw-web">🖥️ 웹</button>
              <button type="button"             onclick="vSw(this,'edit','mob')" id="edit-sw-mob">📱 모바일</button>
            </div>
          </div>
          <div class="preview-wrap" id="edit-pw">
            <div class="preview-bg" id="edit-bg"></div>
            <div class="preview-overlay" id="edit-ov">
              <div id="edit-ct">
                <div class="prev-subtitle" id="edit-sub"></div>
                <div class="prev-title"    id="edit-ttl"></div>
                <div class="prev-desc"     id="edit-dsc"></div>
                <div class="prev-btn"      id="edit-btn" style="display:none"></div>
              </div>
            </div>
          </div>
          <p style="font-size:11px;color:#9999bb;text-align:center;margin-top:8px">※ 실제 화면과 다를 수 있습니다</p>
        </div>
      </div>
      <div class="modal-ft">
        <button type="button" onclick="closeM('editModal')" class="btn_neutral">취소</button>
        <button type="submit" class="btn_primary">저장</button>
      </div>
    </form>
  </div>
</div>

<script>
function openM(id)  { document.getElementById(id).classList.add('on'); }
function closeM(id) { document.getElementById(id).classList.remove('on'); }

function vSw(btn, scope, type) {
    btn.closest('.view-sw').querySelectorAll('button').forEach(function(b){ b.classList.remove('on'); });
    btn.classList.add('on');
    document.getElementById(scope + '-pw').classList.toggle('mob', type === 'mob');
    upPrev(scope);
}

function txTab(btn, scope, type) {
    btn.closest('.txt-tab-bar').querySelectorAll('.txt-tab').forEach(function(b){ b.classList.remove('on'); });
    btn.classList.add('on');
    document.querySelectorAll('[id^="' + scope + '-p-"]').forEach(function(p){ p.classList.remove('on'); });
    document.getElementById(scope + '-p-' + type).classList.add('on');
    var sw = document.getElementById(scope + '-sw-' + type);
    if (sw) {
        sw.closest('.view-sw').querySelectorAll('button').forEach(function(b){ b.classList.remove('on'); });
        sw.classList.add('on');
    }
    document.getElementById(scope + '-pw').classList.toggle('mob', type === 'mob');
    upPrev(scope);
}

function activeType(scope) {
    var p = document.querySelector('[id^="' + scope + '-p-"].on');
    return p ? p.id.replace(scope + '-p-', '') : 'web';
}

function upPrev(scope) {
    var t   = activeType(scope);
    var pfx = (scope === 'add') ? (t + '_') : ('edit_' + t + '_');
    var g   = function(id){ return document.getElementById(id); };

    var sub = (g(pfx + 'subtitle')      ? g(pfx + 'subtitle').value      : '') || '';
    var ttl = (g(pfx + 'title')         ? g(pfx + 'title').value         : '') || '';
    var dsc = (g(pfx + 'description')   ? g(pfx + 'description').value   : '') || '';
    var btn = (g(pfx + 'button_text')   ? g(pfx + 'button_text').value   : '') || '';
    var col = (g(pfx + 'text_color')    ? g(pfx + 'text_color').value    : '') || '#ffffff';
    var pos = (g(pfx + 'text_position') ? g(pfx + 'text_position').value : '') || 'left';

    var ov = g(scope + '-ov');
    if (!ov) return;

    ov.className = 'preview-overlay' + (pos === 'center' ? ' pos-center' : (pos === 'right' ? ' pos-right' : ''));

    var subEl = g(scope + '-sub'); if (subEl){ subEl.innerHTML = sub; subEl.style.color = col; subEl.style.display = sub ? '' : 'none'; }
    var ttlEl = g(scope + '-ttl'); if (ttlEl){ ttlEl.innerHTML = ttl; ttlEl.style.color = col; ttlEl.style.display = ttl ? '' : 'none'; }
    var dscEl = g(scope + '-dsc'); if (dscEl){ dscEl.innerHTML = dsc; dscEl.style.color = col; dscEl.style.display = dsc ? '' : 'none'; }
    var btnEl = g(scope + '-btn'); if (btnEl){ btnEl.textContent = btn; btnEl.style.display = btn ? '' : 'none'; }
    var ph = g(scope + '-ph'); if (ph) ph.style.display = 'none';
    var ct = g(scope + '-ct'); if (ct) ct.style.display = 'block';
}

function updateOverlayPreview(scope) {
    var color   = document.getElementById(scope + '_overlay_color');
    var opacity = document.getElementById(scope + '_overlay_opacity');
    var sample  = document.getElementById(scope + '_overlay_sample');
    if (!color || !opacity || !sample) return;
    var op = parseInt(opacity.value) / 100;
    sample.style.background = op > 0
        ? 'linear-gradient(135deg, ' + color.value + ', ' + color.value + ')'
        : 'transparent';
    sample.style.opacity = op > 0 ? op + 0.2 : 1;
    sample.style.border  = op > 0 ? '2px solid ' + color.value : '2px solid #ddd';
}

function onFile(input) {
    if (!input.files || !input.files[0]) return;
    var f = input.files[0];
    document.getElementById('uploadPh').style.display  = 'none';
    document.getElementById('uploadOk').style.display  = 'block';
    document.getElementById('uploadName').textContent  = f.name;
    document.getElementById('uploadArea').classList.add('on');

    var isVideo = f.type.indexOf('video') === 0;
    var bg = document.getElementById('add-bg');

    if (isVideo) {
        bg.style.backgroundImage = '';
        var existVid = document.getElementById('add-bg-video');
        if (!existVid) {
            existVid = document.createElement('video');
            existVid.id = 'add-bg-video';
            existVid.setAttribute('muted', '');
            existVid.setAttribute('autoplay', '');
            existVid.setAttribute('loop', '');
            existVid.setAttribute('playsinline', '');
            existVid.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;object-fit:cover;';
            bg.parentNode.insertBefore(existVid, bg);
        }
        existVid.src = URL.createObjectURL(f);
        existVid.style.display = 'block';
    } else {
        var ev = document.getElementById('add-bg-video');
        if (ev) ev.style.display = 'none';
        var r = new FileReader();
        r.onload = function(e) { bg.style.backgroundImage = 'url(' + e.target.result + ')'; };
        r.readAsDataURL(f);
    }
    var ph = document.getElementById('add-ph'); if (ph) ph.style.display = 'none';
    var ct = document.getElementById('add-ct'); if (ct) ct.style.display = 'block';
}

function onFileMob(input) {
    if (!input.files || !input.files[0]) return;
    var f = input.files[0];
    document.getElementById('uploadPhMob').style.display = 'none';
    document.getElementById('uploadOkMob').style.display = 'block';
    document.getElementById('uploadNameMob').textContent = f.name;
    document.getElementById('uploadAreaMob').classList.add('on');
}

// ★ 웹 이미지 교체 미리보기 (수정 모달)
function onEditFileWeb(input) {
    if (!input.files || !input.files[0]) return;
    var f = input.files[0];
    var isVideo = f.type.indexOf('video') === 0;
    var p = document.getElementById('edit-web-preview');
    if (!p) return;
    if (isVideo) {
        p.style.backgroundImage = '';
        p.style.background = '#222';
        p.style.display = 'block';
        p.innerHTML = '<span style="color:#fff;font-size:12px;display:flex;align-items:center;justify-content:center;height:100%">🎬 ' + f.name + '</span>';
    } else {
        var r = new FileReader();
        r.onload = function(e) {
            p.style.backgroundImage = 'url(' + e.target.result + ')';
            p.style.display = 'block';
            var bg = document.getElementById('edit-bg');
            if (bg) bg.style.backgroundImage = 'url(' + e.target.result + ')';
        };
        r.readAsDataURL(f);
    }
}

function onEditFileMob(input) {
    if (!input.files || !input.files[0]) return;
    var f = input.files[0];
    var isVideo = f.type.indexOf('video') === 0;
    if (isVideo) {
        var p = document.getElementById('edit-mob-preview');
        var n = document.getElementById('edit-mob-none');
        if (p) { p.style.backgroundImage = ''; p.style.background = '#222'; p.style.display = 'block'; p.innerHTML = '<span style="color:#fff;font-size:12px;display:flex;align-items:center;justify-content:center;height:100%">🎬 ' + f.name + '</span><button type="button" onclick="delMobImg()" style="position:absolute;top:4px;right:4px;background:rgba(0,0,0,.6);color:#fff;border:none;border-radius:50%;width:22px;height:22px;cursor:pointer;font-size:12px;line-height:1">✕</button>'; }
        if (n) n.style.display = 'none';
    } else {
        var r = new FileReader();
        r.onload = function(e) {
            var p = document.getElementById('edit-mob-preview');
            var n = document.getElementById('edit-mob-none');
            if (p) { p.style.backgroundImage = 'url(' + e.target.result + ')'; p.style.display = 'block'; }
            if (n) n.style.display = 'none';
        };
        r.readAsDataURL(f);
    }
    document.getElementById('eDelMob').value = '0';
}

function delMobImg() {
    document.getElementById('eDelMob').value = '1';
    var p = document.getElementById('edit-mob-preview');
    var n = document.getElementById('edit-mob-none');
    if (p) p.style.display = 'none';
    if (n) n.style.display = 'block';
    var fi = document.getElementById('eFileMob'); if (fi) fi.value = '';
}

function bindInputs(scope) {
    ['web', 'mob'].forEach(function(t) {
        var pfx = (scope === 'add') ? (t + '_') : ('edit_' + t + '_');
        ['subtitle','title','description','button_text','text_color','text_position'].forEach(function(f) {
            var el = document.getElementById(pfx + f);
            if (el) el.addEventListener('input', function(){ upPrev(scope); });
        });
    });
}
bindInputs('add');

function openEdit(idx, data) {
    var g  = function(id){ return document.getElementById(id); };
    var sv = function(id, v){ var el = g(id); if (el) el.value = v || ''; };

    g('eIdx').value          = idx;
    g('eLink').value         = data.link        || '';
    g('eLinkTarget').checked = data.link_target === '_blank';
    g('eSt').value           = data.start_date  || '';
    g('eEd').value           = data.end_date    || '';
    g('eVis').checked        = data.visible == 1;
    sv('eAlt', data.alt);

    var ovColor   = data.overlay_color   || '#000000';
    var ovOpacity = data.overlay_opacity || 0;
    sv('edit_overlay_color',   ovColor);
    var eoc = g('edit_overlay_color'); if (eoc) eoc.value = ovColor;
    sv('edit_overlay_color_hex', ovColor);
    var eoo = g('edit_overlay_opacity'); if (eoo) eoo.value = ovOpacity;
    var eov = g('edit_overlay_opacity_val'); if (eov) eov.textContent = ovOpacity;
    updateOverlayPreview('edit');

    var ts  = data.text_settings || {};
    var web = ts.web    || ts;
    var mob = ts.mobile || {};

    sv('edit_web_subtitle',      web.subtitle      || '');
    sv('edit_web_title',         web.title         || '');
    sv('edit_web_description',   web.description   || '');
    sv('edit_web_button_text',   web.button_text   || '');
    sv('edit_web_button_link',   web.button_link   || '');
    sv('edit_web_text_color',    web.text_color    || '#ffffff');
    sv('edit_web_text_position', web.text_position || 'left');
    sv('edit_mob_subtitle',      mob.subtitle      || '');
    sv('edit_mob_title',         mob.title         || '');
    sv('edit_mob_description',   mob.description   || '');
    sv('edit_mob_button_text',   mob.button_text   || '');
    sv('edit_mob_button_link',   mob.button_link   || '');
    sv('edit_mob_text_color',    mob.text_color    || '#ffffff');
    sv('edit_mob_text_position', mob.text_position || 'left');

    ['web','mob'].forEach(function(t){
        var c = g('edit_' + t + '_text_color'); var h = g('edit_' + t + '_text_color_hex');
        if (c && h) h.value = c.value;
    });

    // 웹 이미지 미리보기 초기화
    var webP = g('edit-web-preview');
    if (webP) { webP.style.display = 'none'; webP.style.backgroundImage = ''; }
    var eFileWeb = g('eFileWeb'); if (eFileWeb) eFileWeb.value = '';

    // 모바일 이미지 미리보기
    var mobSrc = data.src_mobile || '';
    var mobP = g('edit-mob-preview'); var mobN = g('edit-mob-none');
    if (mobSrc) {
        if (mobP) { mobP.style.backgroundImage = 'url(' + mobSrc + ')'; mobP.style.display = 'block'; }
        if (mobN) mobN.style.display = 'none';
    } else {
        if (mobP) mobP.style.display = 'none';
        if (mobN) mobN.style.display = 'block';
    }

    g('edit-bg').style.backgroundImage = 'url(' + data.src + ')';
    document.querySelectorAll('[id^="edit-p-"]').forEach(function(p){ p.classList.remove('on'); });
    g('edit-p-web').classList.add('on');
    document.querySelectorAll('#editModal .txt-tab').forEach(function(b, i){ b.classList.toggle('on', i === 0); });

    openM('editModal');
    bindInputs('edit');
    setTimeout(function(){ upPrev('edit'); }, 80);
}

var il = document.getElementById('imageList');
if (il) {
    new Sortable(il, {
        animation: 150,
        ghostClass: 'sortable-ghost',
        onEnd: function() {
            var items = document.querySelectorAll('.img-card');
            var ord   = Array.from(items).map(function(el){ return parseInt(el.dataset.index); });
            var fd    = new FormData();
            fd.append('action',    'reorder_images');
            fd.append('banner_id', '<?php echo $edit_id; ?>');
            fd.append('order',     JSON.stringify(ord));
            fetch('banner_manager.php', { method: 'POST', body: fd })
                .then(function(r){ return r.json(); })
                .then(function(d){ if (d.success) location.reload(); })
                .catch(console.error);
        }
    });
}

function setMain(id) {
    var t = document.createElement('div');
    t.className = 'toast-alert';
    t.innerHTML = '<div style="margin-bottom:12px"><h4 style="margin:0 0 5px;font-size:15px;font-weight:700">메인 배너 변경</h4><p style="margin:0;color:#666;font-size:13px">메인으로 설정하시겠습니까?</p></div><div style="display:flex;gap:8px"><button onclick="doSetMain(' + id + ',this)" class="u-btn u-btn-main u-px-14 u-py-7 rounded-8 fw-700" style="flex:1">확인</button><button onclick="rmToast(this)" class="u-btn u-btn-gray u-px-14 u-py-7 rounded-8 fw-600" style="flex:1">취소</button></div>';
    document.body.appendChild(t);
}
function doSetMain(id, btn) {
    btn.disabled = true; btn.textContent = '처리중...';
    var fd = new FormData();
    fd.append('set_main_banner', '1');
    fd.append('banner_id', id);
    fetch('banner_manager.php', { method: 'POST', body: fd })
        .then(function(r){ return r.json(); })
        .then(function(d){ if (d.success){ showToast(d.message, 'success'); setTimeout(function(){ location.reload(); }, 800); } });
}
function rmToast(btn) {
    var t = btn.closest('.toast-alert');
    t.style.animation = 'sOut .3s ease-out forwards';
    setTimeout(function(){ t.remove(); }, 300);
}

function cpId(id) {
    navigator.clipboard.writeText(String(id)).then(function(){ showToast('ID 복사됨 (' + id + ')', 'success'); });
}

function showToast(msg, type) {
    type = type || 'success';
    var old = document.querySelector('.toast-message'); if (old) old.remove();
    var t = document.createElement('div');
    t.className = 'toast-message';
    var bg = type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#f59e0b';
    t.style.cssText = 'position:fixed;bottom:20px;left:50%;transform:translateX(-50%);background:' + bg + ';color:#fff;padding:13px 26px;border-radius:12px;font-size:14px;font-weight:600;box-shadow:0 8px 24px rgba(0,0,0,.15);z-index:10000;transition:opacity .3s';
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(function(){ t.style.opacity = '0'; setTimeout(function(){ t.remove(); }, 300); }, 3000);
}
</script>
</body>
</html>