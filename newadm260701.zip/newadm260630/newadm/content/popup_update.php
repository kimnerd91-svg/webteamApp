<?php
// 에러 확인을 위해 일시적으로 켭니다. (운영 시에는 주석 처리 권장)
error_reporting(E_ALL);
ini_set('display_errors', '1');

// 1. 경로 설정: 서버 루트 기준 절대 경로로 _common.php 로드
// 파일 위치가 /newadm/content/ 폴더 안에 있다면 아래 경로가 가장 확실합니다.
include_once($_SERVER['DOCUMENT_ROOT'].'/newadm/_common.php');
include_once($_SERVER['DOCUMENT_ROOT'].'/newadm/_auth_check.php');

// 컬럼이 없으면 자동 추가
$columns = sql_query("SHOW COLUMNS FROM dm_popup LIKE 'nw_link'");
if (sql_num_rows($columns) == 0) {
    sql_query("ALTER TABLE `dm_popup` ADD `nw_link` VARCHAR(500) NULL DEFAULT '' AFTER `nw_img`");
    sql_query("ALTER TABLE `dm_popup` ADD `nw_target` VARCHAR(20) NOT NULL DEFAULT '_blank' AFTER `nw_link`");
}

// DELETE 모드는 GET으로 처리
if (isset($_GET['mode']) && $_GET['mode'] == 'd') {
    $nw_id = (int)$_GET['nw_id'];
    
    if ($nw_id) {
        // 파일 삭제
        $row = sql_fetch("SELECT nw_img FROM dm_popup WHERE nw_id = '$nw_id'");
        if ($row && $row['nw_img']) {
            $file_path = G5_DATA_PATH.'/popup/'.$row['nw_img'];
            if(file_exists($file_path)) {
                @unlink($file_path);
            }
        }
        
        // DB에서 완전 삭제
        sql_query("DELETE FROM dm_popup WHERE nw_id = '$nw_id'");
    }
    
    // 이동 경로 확인: 현재 폴더 내 manager 페이지로 이동
    goto_url('./popup_manager.php');
    exit;
}

// INSERT/UPDATE 모드는 POST로 처리
$nw_id = isset($_POST['nw_id']) ? (int)$_POST['nw_id'] : 0;
$mode = isset($_POST['mode']) ? $_POST['mode'] : '';
$nw_img = isset($_POST['nw_img_old']) ? $_POST['nw_img_old'] : ''; 

// 이미지 업로드 처리
if (isset($_FILES['nw_img_file']) && $_FILES['nw_img_file']['error'] == 0 && $_FILES['nw_img_file']['name']) {
    $dest_path = G5_DATA_PATH.'/popup';
    
    // 디렉토리 생성 및 권한 부여
    if (!is_dir($dest_path)) {
        @mkdir($dest_path, G5_DIR_PERMISSION, true);
        @chmod($dest_path, G5_DIR_PERMISSION);
    }

    // 파일명 보안 처리 (시간+고유값)
    $ext = strtolower(pathinfo($_FILES['nw_img_file']['name'], PATHINFO_EXTENSION));
    
    // 보안상 허용되는 이미지 확장자만 체크
    $allowed_ext = array('jpg', 'jpeg', 'png', 'gif', 'webp', 'svg');
    if (!in_array($ext, $allowed_ext)) {
        alert_toast("이미지 파일만 업로드 가능합니다. (jpg, png, gif, webp, svg)");
    }
    
    $filename = time() . '_' . uniqid() . '.' . $ext;
    
    if (move_uploaded_file($_FILES['nw_img_file']['tmp_name'], $dest_path.'/'.$filename)) {
        // 새 파일 업로드 성공 시 기존 파일 삭제
        if ($nw_img && file_exists($dest_path.'/'.$nw_img)) {
            @unlink($dest_path.'/'.$nw_img);
        }
        $nw_img = $filename;
    } else {
        alert_toast("파일 업로드에 실패했습니다.", "error");
    }
}

// SQL 데이터 정리 (XSS 방지 및 자료형 강제)
$nw_subject    = sql_escape_string(trim($_POST['nw_subject']));
$nw_status     = (int)$_POST['nw_status'];
$nw_begin_time = sql_escape_string(trim($_POST['nw_begin_time']));
$nw_end_time   = sql_escape_string(trim($_POST['nw_end_time']));
$nw_width      = (int)$_POST['nw_width'];
$nw_height     = (int)$_POST['nw_height'];
$nw_left       = (int)$_POST['nw_left'];
$nw_top        = (int)$_POST['nw_top'];

// 링크 필드 추가
$nw_link       = isset($_POST['nw_link']) ? sql_escape_string(trim($_POST['nw_link'])) : '';
$nw_target     = isset($_POST['nw_target']) ? sql_escape_string(trim($_POST['nw_target'])) : '_blank';

// URL 형식 검증 (입력된 경우에만)
if ($nw_link && !preg_match('/^https?:\/\//i', $nw_link)) {
    alert_toast("URL은 http:// 또는 https://로 시작해야 합니다.");
}

$sql_common = " nw_subject = '{$nw_subject}',
                nw_status = '{$nw_status}',
                nw_begin_time = '{$nw_begin_time}',
                nw_end_time = '{$nw_end_time}',
                nw_width = '{$nw_width}',
                nw_height = '{$nw_height}',
                nw_left = '{$nw_left}',
                nw_top = '{$nw_top}',
                nw_img = '{$nw_img}',
                nw_link = '{$nw_link}',
                nw_target = '{$nw_target}' ";

if ($mode == 'u' && $nw_id) {
    $sql = " UPDATE dm_popup SET $sql_common WHERE nw_id = '$nw_id' ";
    $msg = "팝업이 수정되었습니다.";
} else {
    $sql = " INSERT INTO dm_popup SET $sql_common ";
    $msg = "팝업이 등록되었습니다.";
}

sql_query($sql);

// 처리 완료 후 목록으로 이동
alert_toast($msg, './popup_manager.php');
?>