<?php
/**
 * dict_manager.php — 의학용어 사전 관리자 (독립, 공용)
 * ---------------------------------------------------------------------------
 * 목표: 치과 용어 위키(사전)의 데이터 토대 + 관리자.
 *   - 단일 테이블 dm_dict (초성은 컬럼 1개로 색인 — 테이블 분할 안 함)
 *   - [위키 가져오기] : ko.wikipedia REST + Action API(cURL)로 정의 자동 채움
 *   - ㄱ~ㅎ / A~Z 색인 + 검색 (사용자 위키페이지의 관리자판)
 *   - synonyms → 추후 smartsearch 유의어로 공급
 *   - 기존 search_supplement.php의 wiki 18건 마이그레이션
 * ---------------------------------------------------------------------------
 */

include_once('../_common.php');
include_once('./_auth_check.php');
if (!$is_admin) { header('Location: /bbs/login.php?url='.urlencode($_SERVER['REQUEST_URI'])); exit; }

global $connect_db;
$db = $connect_db;
$T = 'dm_dict';

mysqli_query($db, "CREATE TABLE IF NOT EXISTS `{$T}` (
    `id`         INT(11) NOT NULL AUTO_INCREMENT,
    `term`       VARCHAR(255) NOT NULL DEFAULT '',
    `initial`    VARCHAR(8)  NOT NULL DEFAULT '',   -- 색인 글자(ㄱ~ㅎ / A~Z / #)
    `definition` TEXT,                              -- 짧은 정의(REST extract)
    `wiki_title` VARCHAR(255) DEFAULT '',
    `wiki_text`  TEXT,                              -- 상세(Action extract)
    `wiki_url`   VARCHAR(500) DEFAULT '',
    `synonyms`   TEXT,                              -- JSON 배열(검색 유의어)
    `related`    TEXT,                              -- JSON 배열(연결 진료 경로)
    `sort`       INT(11) NOT NULL DEFAULT 0,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`), UNIQUE KEY `term` (`term`), KEY `initial` (`initial`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

function d_json($v){ return json_encode($v, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); }
function d_arr($s){ $d=json_decode($s??'',true); return is_array($d)?$d:[]; }
function d_out($v){ while(ob_get_level())ob_end_clean(); header('Content-Type: application/json; charset=utf-8'); echo json_encode($v,JSON_UNESCAPED_UNICODE); exit; }

// ── 초성 계산: 한글 첫 글자 → ㄱ~ㅎ, 영문 → 대문자, 그 외 → # ──
function d_initial($term) {
    $term = trim($term);
    if ($term === '') return '#';
    $ch = mb_substr($term, 0, 1, 'UTF-8');
    $code = mb_ord($ch, 'UTF-8');
    // 한글 음절 0xAC00~0xD7A3
    if ($code >= 0xAC00 && $code <= 0xD7A3) {
        $cho = intdiv($code - 0xAC00, 588);
        $LEAD = ['ㄱ','ㄲ','ㄴ','ㄷ','ㄸ','ㄹ','ㅁ','ㅂ','ㅃ','ㅅ','ㅆ','ㅇ','ㅈ','ㅉ','ㅊ','ㅋ','ㅌ','ㅍ','ㅎ'];
        // 쌍자음은 기본 자음으로 합침(ㄲ→ㄱ 등) — 색인 단순화
        $MAP  = ['ㄱ','ㄱ','ㄴ','ㄷ','ㄷ','ㄹ','ㅁ','ㅂ','ㅂ','ㅅ','ㅅ','ㅇ','ㅈ','ㅈ','ㅊ','ㅋ','ㅌ','ㅍ','ㅎ'];
        return $MAP[$cho] ?? 'ㄱ';
    }
    if (preg_match('/[A-Za-z]/', $ch)) return strtoupper($ch);
    if (preg_match('/[0-9]/', $ch))    return '#';
    return '#';
}

// mb_ord 폴백 (PHP 7.1 이하 대비)
if (!function_exists('mb_ord')) {
    function mb_ord($s, $enc='UTF-8') {
        $r = unpack('N', mb_convert_encoding($s, 'UCS-4BE', $enc));
        return $r[1] ?? 0;
    }
}

// ── 위키 cURL (REST + Action) ──
function d_fetch($url) {
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER=>true, CURLOPT_FOLLOWLOCATION=>true,
            CURLOPT_TIMEOUT=>15, CURLOPT_SSL_VERIFYPEER=>false, CURLOPT_SSL_VERIFYHOST=>0,
            CURLOPT_USERAGENT=>'DentalDictBot/1.0 (medical glossary)',
            CURLOPT_HTTPHEADER=>['Accept: application/json'],
        ]);
        $b=curl_exec($ch); $e=curl_error($ch); $c=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
        if ($b===false) return [null,'cURL: '.$e]; if ($c>=400) return [null,'HTTP '.$c]; return [$b,null];
    }
    $ctx=stream_context_create(['http'=>['timeout'=>15],'ssl'=>['verify_peer'=>false,'verify_peer_name'=>false]]);
    $b=@file_get_contents($url,false,$ctx); return $b===false?[null,'외부호출 차단']:[$b,null];
}

// ════════════════════════════════════════════════
//  전체 크롤 수집 (서버사이드: 크롤 → 본문 → Gemini 용어추출+정의 → DB)
//  AI 키는 dm_config.cf_gemini_key 공용 (page_seo_manager와 동일 키)
// ════════════════════════════════════════════════

// cf_gemini_key 컬럼 보장 + 로드
$gck = mysqli_query($db, "SHOW COLUMNS FROM `dm_config` LIKE 'cf_gemini_key'");
if ($gck && mysqli_num_rows($gck) == 0) {
    mysqli_query($db, "ALTER TABLE `dm_config` ADD `cf_gemini_key` varchar(255) DEFAULT ''");
}
$GEMINI_KEY = '';
$gkr = mysqli_query($db, "SELECT cf_gemini_key FROM dm_config WHERE cf_id=1");
if ($gkr && ($grow = mysqli_fetch_assoc($gkr))) $GEMINI_KEY = $grow['cf_gemini_key'] ?? '';

// 크롤 베이스 = 현재 접속 도메인 (경로 하드코딩 0)
$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$BASE   = $scheme . '://' . $_SERVER['HTTP_HOST'];

// HTML 페이지 fetch (d_fetch는 JSON 헤더라 별도)
function dd_fetch_html($url) {
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER=>true, CURLOPT_FOLLOWLOCATION=>true,
            CURLOPT_TIMEOUT=>20, CURLOPT_SSL_VERIFYPEER=>false, CURLOPT_SSL_VERIFYHOST=>0,
            CURLOPT_USERAGENT=>'DentalDictBot/1.0 (medical glossary)',
        ]);
        $b=curl_exec($ch); $e=curl_error($ch); $c=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
        if ($b===false) return [null,'cURL: '.$e]; if ($c>=400) return [null,'HTTP '.$c]; return [$b,null];
    }
    $ctx=stream_context_create(['http'=>['timeout'=>20],'ssl'=>['verify_peer'=>false,'verify_peer_name'=>false]]);
    $b=@file_get_contents($url,false,$ctx); return $b===false?[null,'외부호출 차단']:[$b,null];
}

// HTML → 본문 텍스트 (script/style/주석 제거)
function dd_page_text($html) {
    $html = preg_replace('#<script\b[^>]*>.*?</script>#is', ' ', $html);
    $html = preg_replace('#<style\b[^>]*>.*?</style>#is', ' ', $html);
    $html = preg_replace('#<!--.*?-->#s', ' ', $html);
    $txt  = html_entity_decode(strip_tags($html), ENT_QUOTES, 'UTF-8');
    $txt  = preg_replace('/\s+/u', ' ', $txt);
    return trim($txt);
}

// 사이트 메뉴 크롤 → 내부 .php 페이지 목록 (최대 50)
function dd_crawl_pages($BASE) {
    list($html, $err) = dd_fetch_html($BASE . '/');
    if ($err) return [null, $err];
    $pages = []; $seen = [];
    if ($html) {
        $doc = new DOMDocument();
        @$doc->loadHTML('<?xml encoding="utf-8" ?>' . $html);
        $bh = parse_url($BASE, PHP_URL_HOST);
        foreach ($doc->getElementsByTagName('a') as $a) {
            $href = $a->getAttribute('href'); if (!$href) continue;
            if (preg_match('#^https?://#i', $href)) {
                if (parse_url($href, PHP_URL_HOST) !== $bh) continue;
                $path = parse_url($href, PHP_URL_PATH) ?: '/';
            } else {
                if ($href[0]==='#' || stripos($href,'javascript:')===0 || stripos($href,'mailto:')===0 || stripos($href,'tel:')===0) continue;
                $path = parse_url($href, PHP_URL_PATH); if (!$path) continue;
                if ($path[0] !== '/') $path = '/'.$path;
            }
            $path = preg_replace('/#.*$/', '', $path);
            if (!preg_match('#\.php($|\?)#i', $path)) continue;                 // 실제 페이지만
            if (preg_match('#/(newadm|adm|bbs|admin|plugin|@)/#i', $path)) continue;  // 관리/게시판 제외
            if (isset($seen[$path])) continue; $seen[$path] = 1;
            $name = preg_replace('/\s+/u', ' ', trim($a->textContent));
            $pages[] = ['path'=>$path, 'name'=>mb_substr($name, 0, 40, 'UTF-8')];
            if (count($pages) >= 50) break;
        }
    }
    return [$pages, null];
}

// Gemini 2.5 Flash 서버 호출 (503/429 백오프 재시도)
function dd_gemini($key, $sys, $user) {
    if (!$key) return [null, 'API 키 없음'];
    $url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=' . urlencode($key);
    $payload = json_encode([
        'system_instruction'=>['parts'=>[['text'=>$sys]]],
        'contents'=>[['role'=>'user','parts'=>[['text'=>$user]]]],
        'generationConfig'=>['maxOutputTokens'=>8192,'temperature'=>0.2,'responseMimeType'=>'application/json']
    ], JSON_UNESCAPED_UNICODE);
    $attempt = 0;
    while ($attempt < 3) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER=>true, CURLOPT_POST=>true, CURLOPT_POSTFIELDS=>$payload,
            CURLOPT_HTTPHEADER=>['Content-Type: application/json'], CURLOPT_TIMEOUT=>60, CURLOPT_SSL_VERIFYPEER=>false,
        ]);
        $res=curl_exec($ch); $code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); $cerr=curl_error($ch); curl_close($ch);
        if ($res===false) return [null, 'cURL: '.$cerr];
        if ($code==503 || $code==429) { $attempt++; sleep(2); continue; }
        $j = json_decode($res, true);
        if (isset($j['error'])) return [null, $j['error']['message'] ?? 'Gemini 오류'];
        $txt = $j['candidates'][0]['content']['parts'][0]['text'] ?? '';
        $txt = preg_replace('/^```json?\s*/i', '', trim($txt));
        $txt = preg_replace('/```$/', '', trim($txt));
        return [trim($txt), null];
    }
    return [null, 'Gemini 혼잡(재시도 초과)'];
}

// 용어추출+정의 SYS (maker DEF_SYS 기조 · 의료법 56조 준수)
define('DD_COLLECT_SYS', '당신은 치과 웹사이트 본문에서 "환자가 모를 수 있는 치과·의료 전문 용어"만 골라 사전 표제어로 추출하고 각 정의를 작성합니다.
## 규칙
- 일반 단어(예약·진료·상담·병원·치료·문의·오시는길·이벤트 등 누구나 아는 말)는 제외. 진짜 전문 용어만.
- 사람이름·병원명·지명·메뉴명·버튼문구·전화번호는 제외.
- 각 용어 정의는 2~3문장, 환자 눈높이의 쉬운 말. 첫 문장은 "OOO은(는) ~이다" 정의형으로 자기완결.
- 의료광고법(제56조) 준수: 최고·유일·완벽·100%·무통·완치·부작용없음·단정적효과 표현 금지. "통증을 줄이기 위한", "개선을 기대할 수 있는", "정밀한" 등 중립표현 사용.
- 치과 맥락 우선(예: 임플란트=치과 임플란트).
- 한 페이지당 최대 12개. 진짜 전문 용어가 없으면 빈 배열 반환.
## 출력 JSON만 (코드펜스·설명 금지)
{"terms":[{"term":"용어","definition":"정의 2~3문장","synonyms":["환자가 검색창에 칠 법한 유의어·구어·오타 3~8개"]}]}');

$action = $_GET['action'] ?? '';

// ── [공용] Gemini 키 저장 → dm_config.cf_gemini_key ──
if ($action === 'save_key') {
    $d = json_decode(file_get_contents('php://input'), true) ?? [];
    $k = mysqli_real_escape_string($db, trim($d['key'] ?? ''));
    mysqli_query($db, "UPDATE dm_config SET cf_gemini_key='{$k}' WHERE cf_id=1");
    d_out(['ok'=>(mysqli_error($db)===''), 'err'=>mysqli_error($db)]);
}

// ── 사이트 메뉴 크롤 → 페이지 목록 ──
if ($action === 'crawl_pages') {
    list($pages, $err) = dd_crawl_pages($BASE);
    if ($err) d_out(['ok'=>false, 'err'=>'메뉴 크롤 실패 — '.$err]);
    d_out(['ok'=>true, 'pages'=>$pages, 'base'=>$BASE]);
}

// ── 페이지 1개 크롤 → 본문 → AI 용어추출+정의 → DB INSERT ──
if ($action === 'collect_page') {
    if (!$GEMINI_KEY) d_out(['ok'=>false, 'err'=>'Gemini 키가 저장되지 않았습니다(상단 입력칸에 넣으면 자동 저장).', 'added'=>0]);
    $path = $_GET['path'] ?? ''; if ($path==='') d_out(['ok'=>false, 'err'=>'path 없음', 'added'=>0]);
    if ($path[0] !== '/') $path = '/'.$path;
    list($html, $err) = dd_fetch_html($BASE . $path);
    if ($err) d_out(['ok'=>false, 'err'=>'크롤 실패 — '.$err, 'path'=>$path, 'added'=>0]);
    $text = dd_page_text($html);
    if (mb_strlen($text, 'UTF-8') < 80) d_out(['ok'=>true, 'path'=>$path, 'added'=>0, 'terms'=>[]]);  // 본문 빈약
    $text = mb_substr($text, 0, 6000, 'UTF-8');
    list($out, $gerr) = dd_gemini($GEMINI_KEY, DD_COLLECT_SYS, "페이지 경로: {$path}\n\n본문:\n".$text);
    if ($gerr) d_out(['ok'=>false, 'err'=>'AI 오류 — '.$gerr, 'path'=>$path, 'added'=>0]);
    $j = json_decode($out, true);
    $terms = (is_array($j) && isset($j['terms']) && is_array($j['terms'])) ? $j['terms'] : [];
    $added = 0; $names = [];
    foreach ($terms as $t) {
        $term = trim($t['term'] ?? ''); if ($term==='') continue;
        $def  = trim($t['definition'] ?? '');
        $syn  = (isset($t['synonyms']) && is_array($t['synonyms'])) ? $t['synonyms'] : [];
        $init = d_initial($term);
        $te = mysqli_real_escape_string($db, $term);
        $ie = mysqli_real_escape_string($db, $init);
        $de = mysqli_real_escape_string($db, $def);
        $se = mysqli_real_escape_string($db, d_json($syn));
        $re = mysqli_real_escape_string($db, d_json([$path]));
        mysqli_query($db, "INSERT INTO `{$T}` (term,initial,definition,synonyms,related)
            VALUES('{$te}','{$ie}','{$de}','{$se}','{$re}')
            ON DUPLICATE KEY UPDATE
              definition = IF(definition IS NULL OR definition='', VALUES(definition), definition),
              synonyms   = IF(synonyms   IS NULL OR synonyms='',   VALUES(synonyms),   synonyms)");
        if (mysqli_affected_rows($db) > 0) $added++;
        $names[] = $term;
    }
    d_out(['ok'=>true, 'path'=>$path, 'added'=>$added, 'terms'=>$names]);
}

// ── 위키에서 정의 가져오기 ──
if ($action === 'wiki') {
    $term = trim($_GET['term'] ?? '');
    if ($term==='') d_out(['ok'=>false,'err'=>'용어를 입력하세요']);
    $res = ['ok'=>true, 'definition'=>'', 'wiki_text'=>'', 'wiki_title'=>'', 'wiki_url'=>''];

    // REST: 짧은 정의
    list($b1,$e1) = d_fetch('https://ko.wikipedia.org/api/rest_v1/page/summary/'.rawurlencode($term));
    if (!$e1) {
        $j = json_decode($b1,true);
        if (!empty($j['extract'])) {
            $res['definition'] = $j['extract'];
            $res['wiki_title'] = $j['title'] ?? $term;
            $res['wiki_url']   = $j['content_urls']['desktop']['page'] ?? '';
        }
    }
    // Action: 상세 본문
    $u2='https://ko.wikipedia.org/w/api.php?'.http_build_query([
        'action'=>'query','format'=>'json','prop'=>'extracts','exintro'=>1,
        'explaintext'=>1,'redirects'=>1,'titles'=>$term,
    ]);
    list($b2,$e2) = d_fetch($u2);
    if (!$e2) {
        $j = json_decode($b2,true);
        $pages = $j['query']['pages'] ?? [];
        $pg = is_array($pages)?reset($pages):null;
        if ($pg && !isset($pg['missing']) && !empty($pg['extract'])) {
            $res['wiki_text'] = $pg['extract'];
            if (empty($res['wiki_title'])) $res['wiki_title'] = $pg['title'] ?? $term;
            if (empty($res['wiki_url']))   $res['wiki_url']   = 'https://ko.wikipedia.org/wiki/'.rawurlencode($pg['title'] ?? $term);
        }
    }
    if ($res['definition']==='' && $res['wiki_text']==='') {
        d_out(['ok'=>false,'err'=>'위키백과에서 "'.$term.'" 문서를 찾지 못했습니다(신조어·상품명일 수 있음)']);
    }
    d_out($res);
}

// ── 저장 ──
if ($action === 'save') {
    $d = json_decode(file_get_contents('php://input'),true) ?? [];
    $id   = (int)($d['id'] ?? 0);
    $term = trim($d['term'] ?? '');
    if ($term==='') d_out(['ok'=>false,'err'=>'용어를 입력하세요']);
    $init = d_initial($term);
    $term = mysqli_real_escape_string($db,$term);
    $ini  = mysqli_real_escape_string($db,$init);
    $def  = mysqli_real_escape_string($db, trim($d['definition'] ?? ''));
    $wt   = mysqli_real_escape_string($db, trim($d['wiki_title'] ?? ''));
    $wx   = mysqli_real_escape_string($db, trim($d['wiki_text'] ?? ''));
    $wu   = mysqli_real_escape_string($db, trim($d['wiki_url'] ?? ''));
    $syn  = mysqli_real_escape_string($db, d_json(array_values(array_filter(array_map('trim',$d['synonyms'] ?? [])))));
    $rel  = mysqli_real_escape_string($db, d_json(array_values(array_filter(array_map('trim',$d['related'] ?? [])))));

    if ($id) {
        $ok = mysqli_query($db, "UPDATE `{$T}` SET term='{$term}', initial='{$ini}', definition='{$def}',
            wiki_title='{$wt}', wiki_text='{$wx}', wiki_url='{$wu}', synonyms='{$syn}', related='{$rel}' WHERE id={$id}");
    } else {
        $ok = mysqli_query($db, "INSERT INTO `{$T}` (term,initial,definition,wiki_title,wiki_text,wiki_url,synonyms,related)
            VALUES('{$term}','{$ini}','{$def}','{$wt}','{$wx}','{$wu}','{$syn}','{$rel}')
            ON DUPLICATE KEY UPDATE initial='{$ini}',definition='{$def}',wiki_title='{$wt}',wiki_text='{$wx}',wiki_url='{$wu}',synonyms='{$syn}',related='{$rel}'");
        $id = mysqli_insert_id($db) ?: $id;
    }
    d_out(['ok'=>(bool)$ok,'err'=>$ok?'':mysqli_error($db),'id'=>$id,'initial'=>$init]);
}

if ($action === 'delete') {
    $id=(int)($_GET['id']??0); if($id) mysqli_query($db,"DELETE FROM `{$T}` WHERE id={$id}");
    d_out(['ok'=>true]);
}

// ── supplement wiki 마이그레이션 ──
if ($action === 'migrate') {
    $sup_file = ($_SERVER['DOCUMENT_ROOT'] ?? '') . ($_GET['sup'] ?? '/sub/smartsearch/search_supplement.php');
    if (!is_file($sup_file)) d_out(['ok'=>false,'err'=>'supplement 파일 없음: '.$sup_file]);
    $SUP = include($sup_file);
    if (!is_array($SUP)) d_out(['ok'=>false,'err'=>'배열 아님']);
    $n=0;
    foreach ($SUP as $path=>$v) {
        if (empty($v['wiki']) || empty($v['wiki']['title'])) continue;
        $term = trim($v['wiki']['title']);
        if ($term==='') continue;
        $init = mysqli_real_escape_string($db, d_initial($term));
        $t  = mysqli_real_escape_string($db, $term);
        $def= mysqli_real_escape_string($db, $v['wiki']['text'] ?? '');
        $wu = mysqli_real_escape_string($db, $v['wiki']['url'] ?? '');
        $syn= mysqli_real_escape_string($db, d_json($v['extra_keywords'] ?? []));
        $rel= mysqli_real_escape_string($db, d_json([$path]));  // 출처 진료경로
        mysqli_query($db, "INSERT INTO `{$T}` (term,initial,definition,wiki_title,wiki_url,synonyms,related)
            VALUES('{$t}','{$init}','{$def}','{$t}','{$wu}','{$syn}','{$rel}')
            ON DUPLICATE KEY UPDATE definition='{$def}', wiki_url='{$wu}'");
        $n++;
    }
    d_out(['ok'=>true,'count'=>$n]);
}

// ── 목록 로드 (검색·초성 필터) ──
$q   = trim($_GET['q'] ?? '');
$ini = trim($_GET['ini'] ?? '');
$where = '1=1';
if ($q !== '') {
    $qe = mysqli_real_escape_string($db, $q);
    $where .= " AND (term LIKE '%{$qe}%' OR synonyms LIKE '%{$qe}%' OR definition LIKE '%{$qe}%')";
}
if ($ini !== '') {
    $ie = mysqli_real_escape_string($db, $ini);
    $where .= " AND initial='{$ie}'";
}
$rows = [];
$r = mysqli_query($db, "SELECT * FROM `{$T}` WHERE {$where} ORDER BY term ASC");
if ($r) while ($x=mysqli_fetch_assoc($r)) $rows[]=$x;

// 초성별 카운트(색인 탭 뱃지)
$counts = [];
$cr = mysqli_query($db, "SELECT initial, COUNT(*) c FROM `{$T}` GROUP BY initial");
if ($cr) while ($x=mysqli_fetch_assoc($cr)) $counts[$x['initial']] = (int)$x['c'];
$total = array_sum($counts);

$INITIALS = ['ㄱ','ㄴ','ㄷ','ㄹ','ㅁ','ㅂ','ㅅ','ㅇ','ㅈ','ㅊ','ㅋ','ㅌ','ㅍ','ㅎ'];
$ALPHA = range('A','Z');
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>의학용어 사전 관리</title>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'Pretendard','Apple SD Gothic Neo',sans-serif;background:#f5f6fa;color:#1a1a2e;}
#admin_wrapper{display:flex;min-height:100vh;}
.content_area{flex:1;padding:40px;overflow-x:hidden;display:flex;flex-direction:column;gap:20px;}
.page_header{display:flex;align-items:center;justify-content:space-between;}
.page_title{font-size:22px;font-weight:700;display:flex;align-items:center;gap:10px;}
.card{background:#fff;border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,.06);border:1px solid #e8eaf0;overflow:hidden;}
.card_hd{padding:14px 20px;border-bottom:1px solid #e8eaf0;display:flex;align-items:center;justify-content:space-between;}
.card_hd_title{font-size:14px;font-weight:700;display:flex;align-items:center;gap:6px;}
.card_hd_title .material-symbols-outlined{font-size:16px;color:#4f46e5;}
.card_body{padding:20px;}
.btn_primary{padding:9px 20px;background:#4f46e5;color:#fff;border:none;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer;transition:.2s;display:inline-flex;align-items:center;gap:5px;font-family:inherit;}
.btn_primary:hover{background:#4338ca;} .btn_primary:disabled{opacity:.5;cursor:not-allowed;}
.btn_green{padding:9px 16px;background:#059669;color:#fff;border:none;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer;transition:.2s;display:inline-flex;align-items:center;gap:5px;font-family:inherit;}
.btn_green:hover{background:#047857;} .btn_green:disabled{opacity:.5;cursor:not-allowed;}
.btn_wiki{padding:7px 14px;background:#fff;color:#4f46e5;border:1px solid #c7d2fe;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer;display:inline-flex;align-items:center;gap:5px;font-family:inherit;}
.btn_wiki:hover{background:#eef2ff;} .btn_wiki:disabled{opacity:.5;cursor:not-allowed;}
.btn_neutral{padding:9px 16px;background:#f5f6fa;color:#5c5c7a;border:1px solid #e8eaf0;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer;display:inline-flex;align-items:center;gap:5px;font-family:inherit;}
.btn_del{padding:5px 10px;background:#fee2e2;color:#dc2626;border:none;border-radius:6px;font-size:11px;font-weight:700;cursor:pointer;}
.btn_sm{padding:6px 12px;font-size:12px;border-radius:7px;border:none;cursor:pointer;font-weight:700;font-family:inherit;display:inline-flex;align-items:center;gap:4px;}
.spin{animation:spin 1s linear infinite;} @keyframes spin{to{transform:rotate(360deg);}}
.form_input{width:100%;padding:9px 12px;border:1px solid #e8eaf0;border-radius:8px;font-size:13px;background:#f5f6fa;color:#1a1a2e;font-family:inherit;outline:none;transition:.2s;}
.form_input:focus{border-color:#4f46e5;background:#fff;box-shadow:0 0 0 3px rgba(79,70,229,.1);}
textarea.form_input{resize:vertical;min-height:60px;line-height:1.6;}
label.lab{display:block;font-size:11px;font-weight:700;color:#9999bb;margin-bottom:4px;}
/* 색인 바 */
.idx-bar{display:flex;flex-wrap:wrap;gap:5px;}
.idx-btn{min-width:34px;height:34px;padding:0 8px;border:1px solid #e8eaf0;border-radius:8px;background:#fff;font-size:14px;font-weight:700;color:#5c5c7a;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;gap:3px;font-family:inherit;}
.idx-btn:hover{background:#eef2ff;border-color:#c7d2fe;}
.idx-btn.active{background:#4f46e5;color:#fff;border-color:#4f46e5;}
.idx-btn.empty{opacity:.35;cursor:default;}
.idx-btn .cnt{font-size:10px;opacity:.7;}
/* 검색 */
.dsearch{display:flex;gap:8px;align-items:center;background:#fff;border:1px solid #e8eaf0;border-radius:999px;padding:5px 6px 5px 16px;max-width:420px;}
.dsearch input{flex:1;border:0;outline:0;font:inherit;font-size:14px;background:transparent;}
.dsearch button{flex:none;width:34px;height:34px;border:0;border-radius:50%;background:#4f46e5;color:#fff;display:grid;place-items:center;cursor:pointer;}
/* 용어 카드 */
.term-card{border:1px solid #e8eaf0;border-radius:10px;padding:16px;margin-bottom:12px;background:#fff;}
.term-card .tc-head{display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:12px;}
.term-card .tc-term{display:flex;align-items:center;gap:8px;}
.term-card .tc-ini{flex:none;width:28px;height:28px;border-radius:7px;background:#eef2ff;color:#4f46e5;font-weight:800;font-size:14px;display:grid;place-items:center;}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:12px;}
@media(max-width:720px){.grid2{grid-template-columns:1fr;}}
.chip{display:inline-flex;align-items:center;gap:4px;background:#eef2ff;color:#4f46e5;border-radius:20px;padding:3px 10px;font-size:12px;margin:2px;}
.chip button{background:none;border:none;color:#4f46e5;cursor:pointer;font-size:13px;line-height:1;padding:0;}
.wiki-note{font-size:11px;color:#9999bb;margin-top:3px;}
.toast{position:fixed;top:20px;right:20px;padding:12px 18px;border-radius:10px;font-size:13px;font-weight:600;display:flex;align-items:center;gap:7px;z-index:100001;box-shadow:0 4px 16px rgba(0,0,0,.12);animation:tin .22s ease;}
.toast.ok{background:#f0fdf4;border:1px solid #bbf7d0;color:#059669;} .toast.error{background:#fef2f2;border:1px solid #fecaca;color:#dc2626;}
@keyframes tin{from{opacity:0;transform:translateX(12px)}to{opacity:1;transform:none}}
.empty{text-align:center;padding:40px;color:#9999bb;font-size:14px;}
.modal-bd{display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:99999;align-items:center;justify-content:center;}
.modal-bd.show{display:flex;}
.modal-bx{background:#fff;border-radius:14px;padding:24px;width:100%;max-width:680px;max-height:88vh;overflow-y:auto;box-shadow:0 20px 60px rgba(0,0,0,.2);}
.modal-tt{font-size:16px;font-weight:700;margin-bottom:16px;display:flex;align-items:center;justify-content:space-between;}
.crawl-row{display:flex;align-items:center;gap:10px;padding:10px 12px;border:1px solid #e8eaf0;border-radius:8px;margin-bottom:6px;}
.hint{background:#ede9fe;border-radius:10px;padding:13px 16px;font-size:13px;color:#4f46e5;line-height:1.7;}
</style>
</head>
<body>
<div id="admin_wrapper">
    <?php include_once('../aside.php'); ?>
    <main class="content_area">

        <div class="page_header">
            <h2 class="page_title"><span class="material-symbols-outlined" style="font-size:22px;color:#4f46e5;">menu_book</span>의학용어 사전 <span style="font-size:13px;color:#9999bb;font-weight:400;">(<?= $total ?>개)</span></h2>
            <div style="display:flex;gap:8px;">
                <button class="btn_neutral" onclick="runMigrate()"><span class="material-symbols-outlined" style="font-size:14px;">database</span>기존 위키 가져오기</button>
                <button class="btn_primary" onclick="newTerm()"><span class="material-symbols-outlined" style="font-size:14px;">add</span>용어 추가</button>
            </div>
        </div>

        <div class="hint">
            <strong>💡 위키처럼</strong> — <b>[전체 크롤 수집]</b>으로 현재 사이트를 크롤해 본문 속 의료 용어를 AI가 자동 추출·정의해 사전에 채웁니다.
            개별로는 용어를 추가하고 <b>[위키 가져오기]</b>·<b>[AI 정의]</b>로 보강하세요.
            초성(ㄱ~ㅎ)·영문(A~Z) 색인과 검색으로 찾아보고, 유의어는 스마트서치 검색에도 연결됩니다.
        </div>

        <!-- AI 도구 바 -->
        <div class="card"><div class="card_body" style="display:flex;flex-wrap:wrap;gap:12px;align-items:center;">
            <div style="display:flex;align-items:center;gap:8px;flex:1;min-width:280px;">
                <span class="material-symbols-outlined" style="font-size:18px;color:#4f46e5;">smart_toy</span>
                <input type="password" id="apiKey" class="form_input" placeholder="Gemini API 키 (AIzaSy…) — 공용 저장(cf_gemini_key)" value="<?= htmlspecialchars($GEMINI_KEY) ?>" style="flex:1;max-width:340px;">
            </div>
            <button class="btn_green" onclick="crawlCollect()"><span class="material-symbols-outlined" style="font-size:14px;">travel_explore</span>전체 크롤 수집</button>
            <button class="btn_wiki" onclick="aiExpand()"><span class="material-symbols-outlined" style="font-size:14px;">hub</span>연관어 확장</button>
            <button class="btn_wiki" onclick="aiReviewAll()"><span class="material-symbols-outlined" style="font-size:14px;">fact_check</span>전체 검수·재작성</button>
            <span style="font-size:11px;color:#9999bb;">gemini-2.5-flash · 생성 1회 후 DB저장(검색은 호출 0)</span>
        </div></div>

        <!-- 검색 + 색인 -->
        <div class="card"><div class="card_body" style="display:flex;flex-direction:column;gap:14px;">
            <form class="dsearch" method="get">
                <input type="text" name="q" value="<?= htmlspecialchars($q) ?>" placeholder="용어·유의어·정의 검색">
                <button type="submit"><span class="material-symbols-outlined" style="font-size:18px;">search</span></button>
            </form>
            <div class="idx-bar">
                <a class="idx-btn <?= $ini===''&&$q===''?'active':'' ?>" href="?">전체 <span class="cnt"><?= $total ?></span></a>
                <?php foreach ($INITIALS as $I): $c=$counts[$I]??0; ?>
                    <a class="idx-btn <?= $ini===$I?'active':'' ?> <?= $c?'':'empty' ?>" <?= $c?'href="?ini='.urlencode($I).'"':'' ?>><?= $I ?><?php if($c):?><span class="cnt"><?= $c ?></span><?php endif;?></a>
                <?php endforeach; ?>
                <?php foreach ($ALPHA as $A): $c=$counts[$A]??0; if(!$c) continue; ?>
                    <a class="idx-btn <?= $ini===$A?'active':'' ?>" href="?ini=<?= $A ?>"><?= $A ?><span class="cnt"><?= $c ?></span></a>
                <?php endforeach; ?>
                <?php if (($counts['#']??0)>0): ?><a class="idx-btn <?= $ini==='#'?'active':'' ?>" href="?ini=%23">#<span class="cnt"><?= $counts['#'] ?></span></a><?php endif; ?>
            </div>
        </div></div>

        <!-- 용어 목록 -->
        <div class="card">
            <div class="card_hd"><span class="card_hd_title"><span class="material-symbols-outlined">list</span>
                <?= $q!==''?'"'.htmlspecialchars($q).'" 검색결과':($ini!==''?htmlspecialchars($ini).' 색인':'전체 용어') ?> (<?= count($rows) ?>)
            </span></div>
            <div class="card_body" id="termList">
                <?php if (empty($rows)): ?>
                <div class="empty"><?= $q!==''||$ini!==''?'해당 용어가 없습니다.':'등록된 용어가 없습니다. [용어 추가] 또는 [기존 위키 가져오기]로 시작하세요.' ?></div>
                <?php else: foreach ($rows as $w):
                    $syn=d_arr($w['synonyms']); $rel=d_arr($w['related']); ?>
                <div class="term-card" data-id="<?= (int)$w['id'] ?>">
                    <div class="tc-head">
                        <div class="tc-term">
                            <span class="tc-ini"><?= htmlspecialchars($w['initial']) ?></span>
                            <input class="form_input t-term" style="font-weight:700;font-size:15px;max-width:260px;" value="<?= htmlspecialchars($w['term']) ?>" placeholder="용어">
                        </div>
                        <div style="display:flex;gap:6px;flex:none;">
                            <button class="btn_wiki" onclick="fetchWiki(this)"><span class="material-symbols-outlined" style="font-size:14px;">travel_explore</span>위키 가져오기</button>
                            <button class="btn_wiki" style="color:#7c3aed;border-color:#ddd6fe;" onclick="aiDefine(this)"><span class="material-symbols-outlined" style="font-size:14px;">auto_awesome</span>AI 정의</button>
                            <button class="btn_del" onclick="delTerm(<?= (int)$w['id'] ?>,this)"><span class="material-symbols-outlined" style="font-size:12px;">delete</span></button>
                        </div>
                    </div>
                    <div style="margin-bottom:12px;">
                        <label class="lab">정의 (사전 본문 — 위키 요약 또는 직접 작성)</label>
                        <textarea class="form_input t-def" style="min-height:54px;"><?= htmlspecialchars($w['definition']) ?></textarea>
                    </div>
                    <div class="grid2">
                        <div>
                            <label class="lab">유의어·별칭 (검색 연결) — 쉼표/엔터</label>
                            <input class="form_input syn-input" placeholder="단어 Enter" onkeydown="chipAdd(event,this)">
                            <div class="syn-chips" style="margin-top:6px;"><?php foreach($syn as $s):?><span class="chip"><?= htmlspecialchars($s) ?><button onclick="chipDel(this)">×</button></span><?php endforeach;?></div>
                        </div>
                        <div>
                            <label class="lab">연결 진료 경로 — 쉼표/엔터</label>
                            <input class="form_input rel-input" placeholder="/sub/...php Enter" onkeydown="chipAdd(event,this)">
                            <div class="rel-chips" style="margin-top:6px;"><?php foreach($rel as $s):?><span class="chip"><?= htmlspecialchars($s) ?><button onclick="chipDel(this)">×</button></span><?php endforeach;?></div>
                        </div>
                    </div>
                    <div style="margin-top:12px;">
                        <label class="lab">위키 상세 / 출처 (선택)</label>
                        <div style="display:flex;gap:8px;margin-bottom:6px;">
                            <input class="form_input t-wtitle" style="flex:1;" placeholder="위키 문서명" value="<?= htmlspecialchars($w['wiki_title']) ?>">
                            <input class="form_input t-wurl" style="flex:1.6;" placeholder="https://ko.wikipedia.org/..." value="<?= htmlspecialchars($w['wiki_url']) ?>">
                        </div>
                        <textarea class="form_input t-wtext" style="min-height:46px;" placeholder="위키 상세 본문(선택)"><?= htmlspecialchars($w['wiki_text']) ?></textarea>
                        <div class="wiki-note">위키 텍스트는 CC BY-SA. 운영 전 검수 권장. 용어명과 위키 문서명은 다를 수 있습니다(예: 임플란트 → 이식물).</div>
                    </div>
                    <div style="margin-top:12px;text-align:right;">
                        <button class="btn_sm" style="background:#4f46e5;color:#fff;" onclick="saveTerm(this)"><span class="material-symbols-outlined" style="font-size:13px;">save</span>저장</button>
                    </div>
                </div>
                <?php endforeach; endif; ?>
            </div>
        </div>
    </main>
</div>

<script>
function toast(m,t){var e=document.createElement('div');e.className='toast '+(t||'ok');e.innerHTML='<span class="material-symbols-outlined" style="font-size:16px;">'+(t==='error'?'error':'check_circle')+'</span>'+m;document.body.appendChild(e);setTimeout(function(){e.remove();},3000);}
function escapeHtml(s){return (s||'').replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
function chipAdd(ev,input){if(ev.key!=='Enter'&&ev.key!==','){return;}ev.preventDefault();var v=input.value.trim().replace(/,$/,'');if(!v)return;var box=input.parentElement.querySelector('.syn-chips,.rel-chips');var c=document.createElement('span');c.className='chip';c.innerHTML=escapeHtml(v)+'<button onclick="chipDel(this)">×</button>';box.appendChild(c);input.value='';}
function chipDel(b){b.parentElement.remove();}
function chipsOf(card,sel){return [...card.querySelectorAll(sel+' .chip')].map(function(c){return c.firstChild.textContent.trim();});}

// 위키 가져오기
async function fetchWiki(btn){
    var card=btn.closest('.term-card');
    var term=card.querySelector('.t-term').value.trim();
    if(!term){toast('용어를 먼저 입력하세요','error');return;}
    var orig=btn.innerHTML; btn.disabled=true;
    btn.innerHTML='<span class="material-symbols-outlined spin" style="font-size:14px;">progress_activity</span>조회중';
    try{
        var r=await fetch('?action=wiki&term='+encodeURIComponent(term));var d=await r.json();
        if(!d.ok){toast(d.err||'실패','error');return;}
        if(d.definition) card.querySelector('.t-def').value=d.definition;
        if(d.wiki_text)  card.querySelector('.t-wtext').value=d.wiki_text;
        if(d.wiki_title) card.querySelector('.t-wtitle').value=d.wiki_title;
        if(d.wiki_url)   card.querySelector('.t-wurl').value=d.wiki_url;
        toast('위키 정의를 가져왔습니다'+(d.wiki_title&&d.wiki_title!==term?' (문서: '+d.wiki_title+')':''),'ok');
    }catch(e){toast('오류: '+e.message,'error');}
    finally{btn.disabled=false;btn.innerHTML=orig;}
}

async function saveTerm(btn){
    var card=btn.closest('.term-card');
    var body={
        id:parseInt(card.dataset.id)||0,
        term:card.querySelector('.t-term').value.trim(),
        definition:card.querySelector('.t-def').value.trim(),
        wiki_title:card.querySelector('.t-wtitle').value.trim(),
        wiki_url:card.querySelector('.t-wurl').value.trim(),
        wiki_text:card.querySelector('.t-wtext').value.trim(),
        synonyms:chipsOf(card,'.syn-chips'),
        related:chipsOf(card,'.rel-chips'),
    };
    if(!body.term){toast('용어를 입력하세요','error');return;}
    var r=await fetch('?action=save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    var d=await r.json();
    if(d.ok){card.dataset.id=d.id;card.querySelector('.tc-ini').textContent=d.initial;toast('저장됨','ok');}
    else toast('실패: '+(d.err||''),'error');
}

async function delTerm(id,btn){
    if(id&&!confirm('이 용어를 삭제할까요?'))return;
    if(id)await fetch('?action=delete&id='+id);
    btn.closest('.term-card').remove();
}

function newTerm(){
    var html='<div class="term-card" data-id="0">'
      +'<div class="tc-head"><div class="tc-term"><span class="tc-ini">?</span>'
      +'<input class="form_input t-term" style="font-weight:700;font-size:15px;max-width:260px;" placeholder="용어 입력"></div>'
      +'<div style="display:flex;gap:6px;flex:none;"><button class="btn_wiki" onclick="fetchWiki(this)"><span class="material-symbols-outlined" style="font-size:14px;">travel_explore</span>위키 가져오기</button>'
      +'<button class="btn_wiki" style="color:#7c3aed;border-color:#ddd6fe;" onclick="aiDefine(this)"><span class="material-symbols-outlined" style="font-size:14px;">auto_awesome</span>AI 정의</button>'
      +'<button class="btn_del" onclick="this.closest(\'.term-card\').remove()"><span class="material-symbols-outlined" style="font-size:12px;">delete</span></button></div></div>'
      +'<div style="margin-bottom:12px;"><label class="lab">정의 (사전 본문)</label><textarea class="form_input t-def" style="min-height:54px;"></textarea></div>'
      +'<div class="grid2"><div><label class="lab">유의어·별칭 — 쉼표/엔터</label><input class="form_input syn-input" placeholder="단어 Enter" onkeydown="chipAdd(event,this)"><div class="syn-chips" style="margin-top:6px;"></div></div>'
      +'<div><label class="lab">연결 진료 경로 — 쉼표/엔터</label><input class="form_input rel-input" placeholder="/sub/...php Enter" onkeydown="chipAdd(event,this)"><div class="rel-chips" style="margin-top:6px;"></div></div></div>'
      +'<div style="margin-top:12px;"><label class="lab">위키 상세 / 출처 (선택)</label>'
      +'<div style="display:flex;gap:8px;margin-bottom:6px;"><input class="form_input t-wtitle" style="flex:1;" placeholder="위키 문서명"><input class="form_input t-wurl" style="flex:1.6;" placeholder="https://ko.wikipedia.org/..."></div>'
      +'<textarea class="form_input t-wtext" style="min-height:46px;" placeholder="위키 상세 본문(선택)"></textarea></div>'
      +'<div style="margin-top:12px;text-align:right;"><button class="btn_sm" style="background:#4f46e5;color:#fff;" onclick="saveTerm(this)"><span class="material-symbols-outlined" style="font-size:13px;">save</span>저장</button></div></div>';
    var list=document.getElementById('termList');
    var emp=list.querySelector('.empty'); if(emp)emp.remove();
    list.insertAdjacentHTML('afterbegin',html);
    list.querySelector('.t-term').focus();
}

async function runMigrate(){
    if(!confirm('기존 search_supplement.php의 위키 데이터를 사전으로 가져옵니다.\n(원본은 삭제되지 않습니다)'))return;
    toast('가져오는 중...','ok');
    var r=await fetch('?action=migrate');var d=await r.json();
    if(d.ok){toast(d.count+'개 용어 가져옴','ok');setTimeout(function(){location.reload();},900);}
    else toast('실패: '+(d.err||''),'error');
}

/* ════════════════════════════════════════════════
   AI (Gemini 2.5 Flash) — maker.html 방식 재활용
   생성은 어드민에서 버튼 누를 때 1회만. 결과는 DB저장.
   ════════════════════════════════════════════════ */
var GEMINI_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=';

// API 키 — cf_gemini_key 공용(서버 prefill). 변경 시 DB 저장(page_seo_manager와 동일 키).
(function(){
    var el=document.getElementById('apiKey');
    el.addEventListener('change',function(){
        var k=this.value.trim();
        fetch('?action=save_key',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key:k})})
          .then(function(r){return r.json();})
          .then(function(d){ toast(d.ok?'API 키 저장됨 (공용)':'키 저장 실패', d.ok?'ok':'error'); })
          .catch(function(){ toast('키 저장 통신 오류','error'); });
    });
})();
function getKey(){ var k=document.getElementById('apiKey').value.trim(); if(!k){toast('Gemini API 키를 입력하세요','error');} return k; }

// 의료법 안전 정의 생성 SYS (maker REVIEW_SYS 기조 + 사전용)
var DEF_SYS = `당신은 대한민국 치과 전문 용어사전 편집자입니다. 환자가 읽는 사전 정의를 작성합니다.
## 규칙
- 2~3문장, 환자가 이해할 쉬운 말. 첫 문장은 "OOO은(는) ~이다" 정의형으로 자기완결.
- 의료광고법(제56조) 준수: 최고/유일/완벽/100%/무통/완치/부작용없음/단정적효과 표현 금지. 대신 "통증을 줄이기 위한", "개선을 기대할 수 있는", "정밀한" 등 중립표현.
- 특정 병원·가격·후기 언급 금지. 일반 의학정보 톤.
- 치과 맥락 우선(예: "임플란트"는 일반 이식물이 아니라 치과 임플란트로).
## 출력 JSON만 (설명·코드펜스 금지)
{"definition":"정의 2~3문장","synonyms":["환자가 검색창에 칠 법한 유의어·구어·오타 5~10개"]}`;

async function callGemini(sys, userText, jsonMode){
    var key=getKey(); if(!key) throw new Error('no key');
    var cfg = jsonMode ? {maxOutputTokens:8192, temperature:0.2, responseMimeType:'application/json'}
                       : {maxOutputTokens:8192, temperature:0.3};
    var res = await fetch(GEMINI_URL+key,{
        method:'POST', headers:{'Content-Type':'application/json'},
        body:JSON.stringify({
            system_instruction:{parts:[{text:sys}]},
            contents:[{role:'user',parts:[{text:userText}]}],
            generationConfig:cfg
        })
    });
    var data=await res.json();
    if(data.error) throw new Error(data.error.message);
    var txt=data.candidates?.[0]?.content?.parts?.[0]?.text || '';
    txt=txt.replace(/^```json?\n?/i,'').replace(/\n?```$/,'').trim();
    return txt;
}

// ① AI 정의 생성 (카드 1개)
async function aiDefine(btn){
    if(!getKey())return;
    var card=btn.closest('.term-card');
    var term=card.querySelector('.t-term').value.trim();
    if(!term){toast('용어를 먼저 입력하세요','error');return;}
    var orig=btn.innerHTML; btn.disabled=true;
    btn.innerHTML='<span class="material-symbols-outlined spin" style="font-size:14px;">progress_activity</span>생성중';
    try{
        var txt=await callGemini(DEF_SYS, '용어: '+term, true);
        var j=JSON.parse(txt);
        if(j.definition) card.querySelector('.t-def').value=j.definition;
        if(Array.isArray(j.synonyms)){
            var box=card.querySelector('.syn-chips');
            j.synonyms.forEach(function(s){
                s=(s||'').trim(); if(!s)return;
                var exist=[...box.querySelectorAll('.chip')].some(function(c){return c.firstChild.textContent.trim()===s;});
                if(exist)return;
                var c=document.createElement('span');c.className='chip';
                c.innerHTML=escapeHtml(s)+'<button onclick="chipDel(this)">×</button>';box.appendChild(c);
            });
        }
        toast('AI 정의 생성됨 (저장 눌러 반영)','ok');
    }catch(e){toast('생성 실패: '+e.message,'error');}
    finally{btn.disabled=false;btn.innerHTML=orig;}
}

// ② 연관어 확장 — 기존 용어 읽고 빠진 연관 치과용어 제안
var EXPAND_SYS = `당신은 치과 용어사전 큐레이터입니다. 이미 등록된 용어 목록을 보고, 사전에 있으면 좋은데 빠진 연관 치과 용어를 제안합니다.
## 규칙
- 이미 목록에 있는 용어는 절대 제외. 진짜 새로운 것만.
- 환자가 실제로 검색할 법한 치과 진료·증상·장비·재료 용어 위주.
- 너무 전문적이거나 마이너한 건 제외. 최대 20개.
## 출력 JSON만
{"terms":[{"term":"용어","reason":"왜 필요한지 짧게"}]}`;

async function aiExpand(){
    if(!getKey())return;
    var existing=[...document.querySelectorAll('.term-card .t-term')].map(function(i){return i.value.trim();}).filter(Boolean);
    if(!confirm('등록된 '+existing.length+'개 용어를 바탕으로 빠진 연관 용어를 AI가 제안합니다.\n(Gemini 1회 호출 ≈ 1원 미만)'))return;
    toast('연관어 분석 중...','ok');
    try{
        var txt=await callGemini(EXPAND_SYS, '이미 등록된 용어: '+(existing.join(', ')||'(없음)')+'\n\n빠진 연관 치과 용어를 제안하세요.', true);
        var j=JSON.parse(txt);
        if(!j.terms||!j.terms.length){toast('제안할 용어가 없습니다','error');return;}
        openExpandModal(j.terms);
    }catch(e){toast('확장 실패: '+e.message,'error');}
}

function openExpandModal(terms){
    var html='<div class="modal-bd show" id="expandModal"><div class="modal-bx">'
      +'<div class="modal-tt"><span>AI 연관어 제안 ('+terms.length+')</span><button onclick="document.getElementById(\'expandModal\').remove()" style="background:none;border:none;font-size:20px;color:#9999bb;cursor:pointer;">×</button></div>'
      +'<p style="font-size:12px;color:#6b7280;margin-bottom:12px;">추가할 용어를 체크하세요. [선택 추가] 시 빈 카드로 들어가고, 이후 [AI 정의]로 채울 수 있습니다.</p>';
    terms.forEach(function(t,i){
        html+='<label class="crawl-row" style="cursor:pointer;"><input type="checkbox" checked data-term="'+escapeHtml(t.term)+'" style="width:17px;height:17px;accent-color:#4f46e5;">'
          +'<div style="flex:1;"><div style="font-weight:700;font-size:13px;">'+escapeHtml(t.term)+'</div><div style="font-size:11px;color:#6b7280;">'+escapeHtml(t.reason||'')+'</div></div></label>';
    });
    html+='<div style="display:flex;justify-content:flex-end;gap:8px;margin-top:16px;"><button class="btn_neutral" onclick="document.getElementById(\'expandModal\').remove()">취소</button>'
      +'<button class="btn_primary" onclick="applyExpand()"><span class="material-symbols-outlined" style="font-size:14px;">add</span>선택 추가</button></div></div></div>';
    document.body.insertAdjacentHTML('beforeend',html);
}
function applyExpand(){
    var picks=[...document.querySelectorAll('#expandModal input:checked')].map(function(c){return c.dataset.term;});
    document.getElementById('expandModal').remove();
    var list=document.getElementById('termList');var emp=list.querySelector('.empty');if(emp)emp.remove();
    picks.forEach(function(term){ newTerm(); list.querySelector('.t-term').value=term; });
    toast(picks.length+'개 용어 카드 추가됨 (AI 정의·저장 진행하세요)','ok');
}

// ③ 전체 검수·재작성 — 기존 정의를 의료법·품질 점검 후 재작성
var REVIEW_SYS = `당신은 치과 용어사전 검수자입니다. 각 용어의 정의를 의료광고법·품질 기준으로 검수하고 필요시 재작성합니다.
## 기준
- 의료법 금지표현(최고/유일/완벽/100%/무통/완치/부작용없음/단정효과) → 중립표현으로 교정.
- 정의가 모호·부정확·너무 길면 2~3문장으로 재작성. 첫 문장 정의형 자기완결.
- 문제없으면 changed=false로 원문 유지.
## 출력 JSON만
{"results":[{"id":숫자, "changed":true/false, "definition":"교정된 정의(changed면)", "issue":"발견 문제 요약"}]}`;

async function aiReviewAll(){
    if(!getKey())return;
    var cards=[...document.querySelectorAll('.term-card')].filter(function(c){return parseInt(c.dataset.id)>0;});
    var items=cards.map(function(c){return {id:parseInt(c.dataset.id), term:c.querySelector('.t-term').value.trim(), definition:c.querySelector('.t-def').value.trim()};}).filter(function(x){return x.definition;});
    if(!items.length){toast('검수할 정의가 없습니다','error');return;}
    if(!confirm(items.length+'개 정의를 AI가 의료법·품질 검수하고 필요시 재작성합니다.\n(Gemini 1회 호출 ≈ 수원 이내)'))return;
    toast('전체 검수 중... ('+items.length+'개)','ok');
    try{
        var txt=await callGemini(REVIEW_SYS, JSON.stringify(items), true);
        var j=JSON.parse(txt);
        if(!j.results){toast('검수 결과 없음','error');return;}
        openReviewModal(j.results, cards);
    }catch(e){toast('검수 실패: '+e.message,'error');}
}

function openReviewModal(results, cards){
    var changed=results.filter(function(r){return r.changed;});
    var byId={}; cards.forEach(function(c){byId[c.dataset.id]=c;});
    window.__reviewResults=results; window.__reviewById=byId;
    var html='<div class="modal-bd show" id="reviewModal"><div class="modal-bx" style="max-width:760px;">'
      +'<div class="modal-tt"><span>전체 검수 결과 — 교정 제안 '+changed.length+'/'+results.length+'</span><button onclick="document.getElementById(\'reviewModal\').remove()" style="background:none;border:none;font-size:20px;color:#9999bb;cursor:pointer;">×</button></div>';
    if(!changed.length){ html+='<p style="color:#059669;font-weight:700;">✅ 모든 정의가 기준을 통과했습니다. 교정 제안 없음.</p>'; }
    else {
        html+='<p style="font-size:12px;color:#6b7280;margin-bottom:12px;">체크된 항목만 본문에 반영됩니다. 반영 후 각 카드 [저장]으로 DB 저장하세요.</p>';
        changed.forEach(function(r){
            var card=byId[r.id]; if(!card)return;
            var term=card.querySelector('.t-term').value.trim();
            var oldDef=card.querySelector('.t-def').value.trim();
            html+='<label class="crawl-row" style="cursor:pointer;align-items:flex-start;flex-direction:column;gap:6px;">'
              +'<div style="display:flex;gap:8px;align-items:center;"><input type="checkbox" checked data-id="'+r.id+'" style="width:17px;height:17px;accent-color:#4f46e5;"><b style="font-size:13px;">'+escapeHtml(term)+'</b>'
              +(r.issue?'<span style="font-size:11px;color:#d97706;">'+escapeHtml(r.issue)+'</span>':'')+'</div>'
              +'<div style="font-size:12px;color:#dc2626;text-decoration:line-through;padding-left:25px;">'+escapeHtml(oldDef)+'</div>'
              +'<div style="font-size:12px;color:#059669;padding-left:25px;" data-newdef="'+escapeHtml(r.definition)+'">'+escapeHtml(r.definition)+'</div></label>';
        });
    }
    html+='<div style="display:flex;justify-content:flex-end;gap:8px;margin-top:16px;"><button class="btn_neutral" onclick="document.getElementById(\'reviewModal\').remove()">닫기</button>';
    if(changed.length) html+='<button class="btn_primary" onclick="applyReview()"><span class="material-symbols-outlined" style="font-size:14px;">check</span>선택 반영</button>';
    html+='</div></div></div>';
    document.body.insertAdjacentHTML('beforeend',html);
}
function applyReview(){
    var picks=[...document.querySelectorAll('#reviewModal input:checked')];
    var n=0;
    picks.forEach(function(c){
        var id=c.dataset.id; var card=window.__reviewById[id]; if(!card)return;
        var newDef=c.closest('label').querySelector('[data-newdef]').getAttribute('data-newdef');
        card.querySelector('.t-def').value=newDef;
        card.style.outline='2px solid #fbbf24'; setTimeout(function(){card.style.outline='';},2000);
        n++;
    });
    document.getElementById('reviewModal').remove();
    toast(n+'개 정의 반영됨 — 각 카드 [저장]으로 DB저장하세요','ok');
}

/* ════════════════════════════════════════════════
   ④ 전체 크롤 수집 — 사이트 크롤 → 본문 → AI 용어추출+정의 → DB
   서버 액션(crawl_pages → collect_page) 순차 호출. 키는 cf_gemini_key 공용.
   ════════════════════════════════════════════════ */
async function crawlCollect(){
    var key=document.getElementById('apiKey').value.trim();
    if(!key){toast('상단에 Gemini API 키를 먼저 입력하세요','error');return;}
    if(!confirm('현재 사이트를 크롤해 본문에서 의료 용어를 AI가 자동 추출·정의하고 사전에 저장합니다.\n페이지 수만큼 Gemini를 호출합니다(보통 수십원 내외). 진행할까요?'))return;
    openCrawlModal();
    var pd;
    try{ var pr=await fetch('?action=crawl_pages'); pd=await pr.json(); }
    catch(e){ crawlLog('페이지 목록 오류: '+e.message,true); return; }
    if(!pd.ok){ crawlLog(pd.err||'크롤 실패',true); return; }
    var pages=pd.pages||[];
    if(!pages.length){ crawlLog('수집할 .php 페이지를 찾지 못했습니다. (메인 메뉴 링크 확인)',true); return; }
    crawlLog('발견 페이지 '+pages.length+'개. 수집 시작…');
    var total=pages.length, done=0, added=0;
    for(var i=0;i<pages.length;i++){
        setCrawlProgress(done,total,pages[i].path);
        try{
            var r=await fetch('?action=collect_page&path='+encodeURIComponent(pages[i].path));
            var d=await r.json();
            if(d.ok){
                added+=d.added||0;
                crawlLog('· '+pages[i].path+' → 신규 '+(d.added||0)+'개'
                    +((d.terms&&d.terms.length)?' ('+d.terms.slice(0,6).join(', ')+(d.terms.length>6?'…':'')+')':''));
            } else {
                crawlLog('· '+pages[i].path+' 실패: '+(d.err||''),true);
            }
        }catch(e){ crawlLog('· '+pages[i].path+' 오류: '+e.message,true); }
        done++; setCrawlProgress(done,total,'');
    }
    crawlLog('✅ 완료 — 신규 '+added+'개 용어 저장됨. 잠시 후 새로고침합니다.');
    setTimeout(function(){location.reload();},1800);
}
function openCrawlModal(){
    var html='<div class="modal-bd show" id="crawlModal"><div class="modal-bx" style="max-width:620px;">'
      +'<div class="modal-tt"><span>전체 크롤 수집</span><button onclick="document.getElementById(\'crawlModal\').remove()" style="background:none;border:none;font-size:20px;color:#9999bb;cursor:pointer;">×</button></div>'
      +'<div style="height:10px;background:#eef2ff;border-radius:6px;overflow:hidden;margin-bottom:6px;"><div id="crawlBar" style="height:100%;width:0;background:#4f46e5;transition:width .2s;"></div></div>'
      +'<div id="crawlStat" style="font-size:12px;color:#6b7280;margin-bottom:10px;">준비 중…</div>'
      +'<div id="crawlLog" style="max-height:300px;overflow-y:auto;font-size:12px;line-height:1.7;font-family:monospace;background:#fafbff;border:1px solid #e8eaf0;border-radius:8px;padding:10px;"></div>'
      +'<p style="font-size:11px;color:#9999bb;margin-top:10px;">※ 페이지가 많으면 수 분 걸릴 수 있어요. 창을 닫지 마세요.</p>'
      +'</div></div>';
    document.body.insertAdjacentHTML('beforeend',html);
}
function setCrawlProgress(done,total,cur){
    var bar=document.getElementById('crawlBar'), stat=document.getElementById('crawlStat');
    if(bar) bar.style.width=(total?Math.round(done/total*100):0)+'%';
    if(stat) stat.textContent=done+' / '+total+(cur?' — '+cur+' 분석 중…':(done>=total?' 완료':''));
}
function crawlLog(msg,err){
    var box=document.getElementById('crawlLog'); if(!box)return;
    var p=document.createElement('div'); if(err)p.style.color='#dc2626'; p.textContent=msg;
    box.appendChild(p); box.scrollTop=box.scrollHeight;
}

</script>
</body>
</html>
