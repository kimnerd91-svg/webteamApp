<?php
include_once('../_common.php');
include_once('./_auth_check.php');
if (!$is_admin) { header('Location: /bbs/login.php?url='.urlencode($_SERVER['REQUEST_URI'])); exit; }

// 그누보드 DB 핸들 확보 (PSM과 동일 패턴)
global $connect_db;
$db = $connect_db;

/* ============================================================
   다국어 매니저 v3  (1단계: 자동 마킹 + 크롤 적재)
   - 기존 v2(JSON파일/extractKorean)는 폐기. DB(dm_i18n) 방식으로 신규.
   - 언어 분리는 URL 쿼리방식(?lang=en). .htaccess 불필요.
   ============================================================ */

// ── Gemini 키: site_config(dm_config.cf_gemini_key) 공용 (PSM/dict_manager와 동일) ──
$col_gk = mysqli_fetch_assoc(mysqli_query($db, "SHOW COLUMNS FROM dm_config LIKE 'cf_gemini_key'"));
if (!$col_gk) { mysqli_query($db, "ALTER TABLE dm_config ADD `cf_gemini_key` VARCHAR(255) NULL DEFAULT ''"); }
$__gk = mysqli_fetch_assoc(mysqli_query($db, "SELECT cf_gemini_key, cf_langs FROM dm_config WHERE cf_id = 1"));
$GEMINI_KEY = trim($__gk['cf_gemini_key'] ?? '');
$SITE_LANGS = trim($__gk['cf_langs'] ?? 'ko');

// ── dm_i18n 테이블 자동 생성 ──
// site_id: 멀티사이트/SaaS 대비(현재 1 고정). i18n_key가 진짜 식별자.
mysqli_query($db, "CREATE TABLE IF NOT EXISTS `dm_i18n` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `site_id` INT NOT NULL DEFAULT 1,
    `i18n_key` VARCHAR(80) NOT NULL,
    `page_path` VARCHAR(255) DEFAULT '',
    `ko` TEXT,
    `en` TEXT,
    `ja` TEXT,
    `zh` TEXT,
    `ko_hash` CHAR(32) DEFAULT '',
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uq_site_key` (`site_id`, `i18n_key`)
) DEFAULT CHARSET=utf8mb4");

$SITE_ID = 1;

/* ============================================================
   AJAX 핸들러 (공통 출력 전에 처리)
   ============================================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['action'])) {
    header('Content-Type: application/json; charset=utf-8');
    $action = $_POST['action'];

    // ── 1) 크롤: 마킹된 URL 목록을 돌며 data-i18n 수집 → DB upsert ──
    if ($action === 'crawl') {
        $urls = array_filter(array_map('trim', explode("\n", $_POST['urls'] ?? '')));
        if (!$urls) { echo json_encode(['success'=>false,'message'=>'URL이 없습니다.']); exit; }

        $collected = 0; $inserted = 0; $updated = 0; $pages = 0; $errors = [];

        foreach ($urls as $url) {
            if (!preg_match('#^https?://#i', $url)) { $errors[] = "건너뜀(잘못된 URL): $url"; continue; }
            $html = @file_get_contents($url);
            if ($html === false) { $errors[] = "불러오기 실패: $url"; continue; }
            $pages++;
            $path = parse_url($url, PHP_URL_PATH) ?: '/';

            // data-i18n="key" 요소의 key + 내부 텍스트 추출
            $dom = new DOMDocument();
            libxml_use_internal_errors(true);
            $dom->loadHTML('<?xml encoding="utf-8" ?>' . $html);
            libxml_clear_errors();
            $xp = new DOMXPath($dom);
            $nodes = $xp->query('//*[@data-i18n]');

            foreach ($nodes as $node) {
                $key = trim($node->getAttribute('data-i18n'));
                $ko  = trim(preg_replace('/\s+/', ' ', $node->textContent));
                if ($key === '' || $ko === '') continue;
                $collected++;
                $hash = md5($ko);

                $keyE = mysqli_real_escape_string($db, $key);
                $koE  = mysqli_real_escape_string($db, $ko);
                $pE   = mysqli_real_escape_string($db, $path);

                // 이미 있으면: ko가 바뀐 경우에만 갱신(해시 비교) — 번역값(en/ja/zh)은 보존
                $row = mysqli_fetch_assoc(mysqli_query($db,
                    "SELECT id, ko_hash FROM dm_i18n WHERE site_id=$SITE_ID AND i18n_key='$keyE' LIMIT 1"));
                if ($row) {
                    if ($row['ko_hash'] !== $hash) {
                        mysqli_query($db, "UPDATE dm_i18n SET ko='$koE', ko_hash='$hash', page_path='$pE'
                                           WHERE id=" . (int)$row['id']);
                        $updated++;
                    }
                } else {
                    mysqli_query($db, "INSERT INTO dm_i18n (site_id, i18n_key, page_path, ko, ko_hash)
                                       VALUES ($SITE_ID, '$keyE', '$pE', '$koE', '$hash')");
                    $inserted++;
                }
            }
        }

        echo json_encode([
            'success'  => true,
            'pages'    => $pages,
            'collected'=> $collected,
            'inserted' => $inserted,
            'updated'  => $updated,
            'errors'   => $errors
        ]);
        exit;
    }

    // ── 2) 적재 현황: DB 통계 ──
    if ($action === 'stats') {
        $total = (int)(mysqli_fetch_row(mysqli_query($db, "SELECT COUNT(*) FROM dm_i18n WHERE site_id=$SITE_ID"))[0] ?? 0);
        $enDone = (int)(mysqli_fetch_row(mysqli_query($db, "SELECT COUNT(*) FROM dm_i18n WHERE site_id=$SITE_ID AND en<>'' AND en IS NOT NULL"))[0] ?? 0);
        echo json_encode(['success'=>true, 'total'=>$total, 'en_done'=>$enDone]);
        exit;
    }

    echo json_encode(['success'=>false, 'message'=>'알 수 없는 action']);
    exit;
}

?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>다국어 관리</title>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'Pretendard','Apple SD Gothic Neo',sans-serif;background:#f5f6fa;color:#1a1a2e;}
#admin_wrapper{display:flex;min-height:100vh;}
.content_area{flex:1;padding:40px;overflow-x:hidden;display:flex;flex-direction:column;gap:20px;}
.page_header{display:flex;align-items:center;justify-content:space-between;}
.page_title{font-size:22px;font-weight:700;display:flex;align-items:center;gap:10px;}
.card{background:#fff;border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,.06);border:1px solid #e8eaf0;overflow:hidden;}
.card_hd{padding:14px 20px;border-bottom:1px solid #e8eaf0;display:flex;align-items:center;justify-content:space-between;gap:10px;}
.card_hd_title{font-size:14px;font-weight:700;display:flex;align-items:center;gap:6px;}
.card_hd_title .material-symbols-outlined{font-size:16px;color:#4f46e5;}
.card_body{padding:20px;}
.btn_primary{padding:9px 20px;background:#4f46e5;color:#fff;border:none;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer;transition:all .2s;display:inline-flex;align-items:center;gap:5px;font-family:inherit;}
.btn_primary:hover{background:#4338ca;}
.btn_primary:disabled{opacity:.5;cursor:not-allowed;}
.btn_neutral{padding:9px 16px;background:#f5f6fa;color:#5c5c7a;border:1px solid #e8eaf0;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer;transition:all .2s;display:inline-flex;align-items:center;gap:5px;font-family:inherit;}
.btn_neutral:hover{background:#e8eaf0;}
.btn_refresh{padding:7px 14px;background:#fff;color:#4f46e5;border:1px solid #c7d2fe;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer;transition:all .2s;display:inline-flex;align-items:center;gap:5px;font-family:inherit;}
.btn_refresh:hover{background:#eef2ff;}
.btn_refresh .material-symbols-outlined{font-size:14px;}
.form_group{margin-bottom:14px;}
.form_group label{display:block;font-size:12px;font-weight:700;color:#9999bb;margin-bottom:5px;}
.form_input{width:100%;padding:9px 12px;border:1px solid #e8eaf0;border-radius:8px;font-size:13px;background:#f5f6fa;color:#1a1a2e;font-family:inherit;transition:all .2s;outline:none;}
.form_input:focus{border-color:#4f46e5;background:#fff;box-shadow:0 0 0 3px rgba(79,70,229,.1);}
textarea.form_input{resize:vertical;min-height:120px;line-height:1.6;font-family:ui-monospace,monospace;font-size:12.5px;}
.btn_row{display:flex;align-items:center;gap:10px;margin-top:12px;flex-wrap:wrap;}
.stat_txt{font-size:12.5px;color:#667;}
/* 안내 박스 */
.info_box{background:#ede9fe;border-radius:10px;padding:14px 18px;font-size:13px;color:#4f46e5;line-height:1.7;}
.guide_steps{margin:10px 0 0;padding-left:18px;font-size:12.5px;line-height:1.85;color:#5b54c9;}
.guide_steps>li{margin-bottom:6px;}
.guide_steps ul{margin:4px 0;padding-left:16px;font-size:12px;color:#7b74d6;}
.guide_note{margin-top:10px;font-size:12px;color:#b4520a;background:#fff6ec;border:1px solid #ffe0c2;border-radius:8px;padding:8px 12px;line-height:1.6;}
.info_box code,.card_body code{background:#fff;border:1px solid #d6d0fb;padding:1px 6px;border-radius:4px;font-size:12px;color:#4f46e5;}
/* 결과/현황 */
.result_box{background:#fafbff;border:1px solid #e8eaf0;border-radius:8px;padding:12px 14px;font-size:12.5px;line-height:1.7;color:#445;margin-top:12px;}
.stats_box{margin-top:14px;display:flex;gap:12px;flex-wrap:wrap;}
.stat_card{flex:1;min-width:140px;background:#fafbff;border:1px solid #e8eaf0;border-radius:10px;padding:14px 16px;}
.stat_card .lbl{font-size:11px;font-weight:700;color:#9999bb;margin-bottom:6px;}
.stat_card .num{font-size:22px;font-weight:800;color:#4f46e5;}
/* 토스트 */
.toast{position:fixed;top:20px;right:20px;padding:12px 18px;border-radius:10px;font-size:13px;font-weight:600;display:flex;align-items:center;gap:7px;z-index:1000001!important;box-shadow:0 4px 16px rgba(0,0,0,.12);animation:tin .22s ease;}
.toast.ok{background:#f0fdf4;border:1px solid #bbf7d0;color:#059669;}
.toast.error{background:#fef2f2;border:1px solid #fecaca;color:#dc2626;}
@keyframes tin{from{opacity:0;transform:translateX(12px)}to{opacity:1;transform:none}}
</style>
</head>
<body>
<div id="admin_wrapper">
    <?php include_once('../aside.php'); ?>
    <main class="content_area">

        <div class="page_header">
            <h2 class="page_title">
                <span class="material-symbols-outlined" style="font-size:22px;color:#4f46e5;">translate</span>
                다국어 관리
            </h2>
        </div>

        <!-- 안내 -->
        <div class="info_box">
            <strong>📘 사용 방법</strong> — 번역은 4단계입니다. <b>마킹 → 크롤 적재 → 번역 → 출력</b>. 이 화면은 1·2단계(마킹 + 적재)입니다.
            <ol class="guide_steps">
                <li><b>① 자동 마킹</b> — 페이지 HTML을 붙여넣고 [자동 마킹]을 누르면 한국어 텍스트마다 <code>data-i18n="키"</code>가 박힌 HTML이 나옵니다. 결과를 복사해 실제 페이지에 반영하세요.
                    <ul>
                        <li>같은 문장은 같은 키로 묶입니다(메뉴·푸터 반복 텍스트 자동 통합).</li>
                        <li>제외하려면 요소에 <code>data-no-i18n</code>을 다세요(전화·영문·숫자는 자동 제외).</li>
                        <li>이미 <code>data-i18n</code>이 있으면 건드리지 않습니다(여러 번 돌려도 안전).</li>
                    </ul>
                </li>
                <li><b>② 크롤 적재</b> — 마킹 반영한 페이지 URL을 한 줄에 하나씩 넣고 [크롤 적재]를 누르면 <code>data-i18n</code> 텍스트가 DB(<code>dm_i18n</code>)에 모입니다. 원문이 바뀐 항목만 갱신되고 기존 번역은 보존됩니다.</li>
                <li><b>③ 번역</b> (다음 단계) — 언어별(EN/JA/ZH) 편집 + Gemini 자동번역 + 의료법 검수.</li>
                <li><b>④ 출력</b> (다음 단계) — <code>?lang=en</code> 등에 따라 서버에서 치환(없으면 한국어 폴백).</li>
            </ol>
            <div class="guide_note">⚠️ <b>data-i18n 마킹이 없으면 크롤이 아무것도 못 모읍니다</b>(생텍스트는 스캔하지 않음). 반드시 ①을 먼저 하세요.</div>
        </div>

        <!-- ① 자동 마킹 -->
        <div class="card">
            <div class="card_hd">
                <span class="card_hd_title"><span class="material-symbols-outlined">code</span>① 자동 마킹 — HTML에 data-i18n 자동 삽입</span>
            </div>
            <div class="card_body">
                <div class="form_group">
                    <label>페이지 HTML 붙여넣기</label>
                    <textarea id="markInput" class="form_input" rows="8" placeholder="<section> ... 페이지 HTML 전체 또는 일부 ... </section>"></textarea>
                </div>
                <div class="btn_row">
                    <button class="btn_primary" onclick="runMark()"><span class="material-symbols-outlined" style="font-size:15px;">auto_fix_high</span>자동 마킹</button>
                    <span id="markStat" class="stat_txt"></span>
                </div>
                <div class="form_group" style="margin-top:18px;">
                    <label>결과 (복사해서 페이지 파일에 반영)</label>
                    <textarea id="markOutput" class="form_input" rows="8" readonly placeholder="마킹 결과가 여기에 나옵니다"></textarea>
                </div>
                <div class="btn_row">
                    <button class="btn_neutral" onclick="copyOut()"><span class="material-symbols-outlined" style="font-size:15px;">content_copy</span>결과 복사</button>
                </div>
            </div>
        </div>

        <!-- ② 크롤 적재 -->
        <div class="card">
            <div class="card_hd">
                <span class="card_hd_title"><span class="material-symbols-outlined">cloud_download</span>② 크롤 적재 — 마킹된 페이지 URL 수집</span>
                <button class="btn_refresh" onclick="loadStats()"><span class="material-symbols-outlined">refresh</span>현황 새로고침</button>
            </div>
            <div class="card_body">
                <div class="form_group">
                    <label>URL 목록 (한 줄에 하나)</label>
                    <textarea id="crawlUrls" class="form_input" rows="5" placeholder="https://example.com/&#10;https://example.com/about&#10;https://example.com/implant"></textarea>
                </div>
                <div class="btn_row">
                    <button class="btn_primary" onclick="runCrawl()"><span class="material-symbols-outlined" style="font-size:15px;">download</span>크롤 적재</button>
                    <span id="crawlStat" class="stat_txt"></span>
                </div>
                <div id="crawlResult" class="result_box" style="display:none;"></div>
                <div id="statsBox" class="stats_box"></div>
            </div>
        </div>

    </main>
</div>

<script>
/* ① 자동 마킹 — 브라우저 DOMParser */
var MARK_TAGS = ['H1','H2','H3','H4','H5','H6','P','LI','A','SPAN','BUTTON','TH','TD','FIGCAPTION','DT','DD','STRONG','EM','LABEL','BLOCKQUOTE','SUMMARY','CAPTION'];

function hasKorean(s){ return /[가-힣]/.test(s); }

function hashKey(str){
    var h = 5381, i = str.length;
    while(i) { h = (h * 33) ^ str.charCodeAt(--i); }
    var hex = (h >>> 0).toString(16);
    while (hex.length < 8) hex = '0' + hex;
    return 't-' + hex.slice(0, 8);
}

function runMark(){
    var raw = document.getElementById('markInput').value;
    if (!raw.trim()) { setStat('markStat', 'HTML을 붙여넣으세요.'); return; }

    var parser = new DOMParser();
    var docu = parser.parseFromString('<div id="__root">' + raw + '</div>', 'text/html');
    var root = docu.getElementById('__root');
    var marked = 0, reused = 0;
    var seen = {};

    MARK_TAGS.forEach(function(tag){
        var els = root.getElementsByTagName(tag);
        Array.prototype.slice.call(els).forEach(function(el){
            if (el.hasAttribute('data-i18n')) return;
            if (el.hasAttribute('data-no-i18n')) return;
            if (el.closest('[data-no-i18n]')) return;
            var hasElementChild = false;
            for (var i=0;i<el.children.length;i++){
                if (MARK_TAGS.indexOf(el.children[i].tagName) !== -1) { hasElementChild = true; break; }
            }
            if (hasElementChild) return;
            var txt = (el.textContent || '').replace(/\s+/g,' ').trim();
            if (!txt || !hasKorean(txt)) return;

            var key = hashKey(txt);
            if (seen[key]) reused++; else { seen[key] = true; }
            el.setAttribute('data-i18n', key);
            marked++;
        });
    });

    document.getElementById('markOutput').value = root.innerHTML;
    setStat('markStat', '✅ 마킹 ' + marked + '개 (고유 키 ' + Object.keys(seen).length + '개, 중복 통합 ' + reused + '개)');
    showToast('마킹 완료: ' + marked + '개', 'ok');
}

function copyOut(){
    var out = document.getElementById('markOutput');
    if (!out.value.trim()) { showToast('복사할 결과가 없습니다.', 'error'); return; }
    out.select();
    document.execCommand('copy');
    setStat('markStat', '복사됨 ✅');
    showToast('결과가 복사되었습니다.', 'ok');
}

/* ② 크롤 적재 */
function runCrawl(){
    var urls = document.getElementById('crawlUrls').value.trim();
    if (!urls) { setStat('crawlStat', 'URL을 입력하세요.'); return; }
    setStat('crawlStat', '크롤 중…');

    var fd = new FormData();
    fd.append('action', 'crawl');
    fd.append('urls', urls);

    fetch(location.href, { method:'POST', body:fd })
        .then(function(r){ return r.json(); })
        .then(function(d){
            if (!d.success) { setStat('crawlStat', '❌ ' + (d.message||'실패')); showToast(d.message||'크롤 실패', 'error'); return; }
            setStat('crawlStat', '✅ 완료');
            var box = document.getElementById('crawlResult');
            box.style.display = 'block';
            var html = '페이지 <b>' + d.pages + '</b>개 처리 · 수집 <b>' + d.collected + '</b>건 · '
                     + '신규 <b>' + d.inserted + '</b> · 갱신 <b>' + d.updated + '</b>';
            if (d.errors && d.errors.length) {
                html += '<br><span style="color:#b4520a;">' + d.errors.join('<br>') + '</span>';
            }
            box.innerHTML = html;
            showToast('크롤 적재 완료', 'ok');
            loadStats();
        })
        .catch(function(e){ setStat('crawlStat', '❌ 통신 오류'); showToast('통신 오류', 'error'); });
}

function loadStats(){
    var fd = new FormData();
    fd.append('action', 'stats');
    fetch(location.href, { method:'POST', body:fd })
        .then(function(r){ return r.json(); })
        .then(function(d){
            if (!d.success) return;
            document.getElementById('statsBox').innerHTML =
                '<div class="stat_card"><div class="lbl">총 적재 키</div><div class="num">' + d.total + '</div></div>' +
                '<div class="stat_card"><div class="lbl">영어 번역 완료</div><div class="num">' + d.en_done + '</div></div>';
        });
}

function setStat(id, msg){ document.getElementById(id).textContent = msg; }

function showToast(msg, type){
    var el = document.createElement('div');
    el.className = 'toast ' + (type || 'ok');
    el.innerHTML = '<span class="material-symbols-outlined" style="font-size:16px;">' + (type === 'error' ? 'error' : 'check_circle') + '</span>' + msg;
    document.body.appendChild(el);
    setTimeout(function(){ el.remove(); }, 3000);
}

loadStats();
</script>
</body>
</html>