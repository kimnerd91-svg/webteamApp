<?php
if (!defined('_GNUBOARD_')) exit;

// 1. DB에서 게시판 목록 추출
$dm_boards = array();
$sql = " select bo_table, bo_subject, bo_category_list from {$g5['board_table']} order by bo_order, bo_table ";
$result = sql_query($sql);

// column은 column_admin.php에서 전용 관리
$dm_exclude = ['column'];

while($row = sql_fetch_array($result)) {
    if (in_array($row['bo_table'], $dm_exclude)) continue;
    $dm_boards[$row['bo_table']] = array(
        'subject'    => $row['bo_subject'],
        'categories' => $row['bo_category_list'] ? explode('|', $row['bo_category_list']) : array()
    );
}

// 2. 현재 게시판 설정
$bo_table = isset($_REQUEST['bo_table']) ? clean_xss_tags($_REQUEST['bo_table']) : '';

// [중요] array_key_first() 대신 모든 PHP 버전에서 작동하는 방식 사용
if(!$bo_table && !empty($dm_boards)) {
    reset($dm_boards); // 포인터를 첫 번째로 이동
    $bo_table = key($dm_boards); // 첫 번째 키값 가져오기
}

// 3. 테이블명 및 ID 세팅
$dm_write_table = "";
if ($bo_table) {
    $dm_write_table = $g5['write_prefix'] . $bo_table;
}
$wr_id = isset($_REQUEST['wr_id']) ? (int)$_REQUEST['wr_id'] : 0;
?>