<?php
include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/_common.php');

// column은 column_admin.php 전용 — 접근 시 리다이렉트
if (!isset($_FILES['upload']['name']) && (($_POST['bo_table'] ?? '') === 'column' || ($_GET['bo_table'] ?? '') === 'column')) {
    header('Location: /newadm/column_admin.php');
    exit;
}

// [1] CKEditor 이미지 업로드 처리
if (isset($_FILES['upload']['name'])) {
    while (ob_get_level()) ob_end_clean();
    $upload_dir = G5_DATA_PATH . '/editor/' . date('Ym');
    $upload_url = G5_DATA_URL . '/editor/' . date('Ym');
    if (!is_dir($upload_dir)) { @mkdir($upload_dir, G5_DIR_PERMISSION, true); @chmod($upload_dir, G5_DIR_PERMISSION); }
    $filename = $_FILES['upload']['name'];
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) die(json_encode(["uploaded" => 0, "error" => ["message" => "이미지만 업로드 가능합니다."]]));
    $new_name = time() . '_' . md5($filename) . '.' . $ext;
    $dest_path = $upload_dir . '/' . $new_name;
    if (move_uploaded_file($_FILES['upload']['tmp_name'], $dest_path)) {
        header('Content-Type: application/json');
        echo json_encode(["uploaded" => 1, "fileName" => $new_name, "url" => $upload_url . '/' . $new_name]);
    } else {
        header('Content-Type: application/json');
        echo json_encode(["uploaded" => 0, "error" => ["message" => "파일 업로드 실패."]]);
    }
    exit;
}

// [2] DB 저장/수정 처리
if (isset($_POST['wr_subject']) && !empty($_POST['wr_subject'])) {
    $bo_table   = $_POST['bo_table'];
    $write_table = $g5['write_prefix'] . $bo_table;
    $wr_subject = sql_real_escape_string($_POST['wr_subject']);
    $wr_content = sql_real_escape_string($_POST['wr_content']);
    $category_id = isset($_POST['category_id']) ? (int)$_POST['category_id'] : 0;
    $wr_id      = (int)$_POST['wr_id'];
    $mode       = $_POST['mode'];
    if ($mode == 'modify' && $wr_id) {
        sql_query(" UPDATE $write_table SET wr_subject='$wr_subject', wr_content='$wr_content', wr_10='$category_id' WHERE wr_id='$wr_id' ");
        $redirect = ($bo_table == 'faq') ? "/newadm/board/faq_manager.php" : "/newadm/board/board_post_list.php?bo_table=".$bo_table;
        alert_toast("성공적으로 수정되었습니다.", $redirect, "success");
    } else {
        sql_query(" INSERT INTO $write_table SET wr_subject='$wr_subject', wr_content='$wr_content', wr_10='$category_id', wr_datetime='".G5_TIME_YMDHIS."', wr_option='html1', wr_num='-1' ");
        $redirect = ($bo_table == 'faq') ? "/newadm/board/faq_manager.php" : "/newadm/board/board_post_list.php?bo_table=".$bo_table;
        alert_toast("저장되었습니다.", $redirect, "success");
    }
    exit;
}

// [3] 화면 출력 준비
include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/_auth_check.php');
include_once('./direct_config.php');

$mode     = $_REQUEST['mode'] ?? 'write';
$wr_id    = $_REQUEST['wr_id'] ?? '';
$bo_table = $_REQUEST['bo_table'] ?? '';

if ($mode == 'modify' && $wr_id && $bo_table) {
    $write = sql_fetch(" select * from {$g5['write_prefix']}{$bo_table} where wr_id = '$wr_id' ");
}

$board_categories = [];
foreach ($dm_boards as $table => $data) {
    $category_table = $g5['write_prefix'] . $table . '_category';
    $table_check = sql_query("SHOW TABLES LIKE '{$category_table}'", false);
    if ($table_check && sql_num_rows($table_check) > 0) {
        $cat_result = sql_query("SELECT ca_id, ca_name FROM {$category_table} ORDER BY ca_order ASC, ca_id ASC", false);
        if ($cat_result) {
            $board_categories[$table] = [];
            while ($cat = sql_fetch_array($cat_result)) {
                $board_categories[$table][] = ['id' => $cat['ca_id'], 'name' => $cat['ca_name']];
            }
        }
    }
}

$title_prefix = ($bo_table == 'faq') ? 'FAQ' : '콘텐츠';
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title><?= ($mode == 'modify') ? $title_prefix.' 수정' : '새 '.$title_prefix.' 작성' ?></title>
    <script src="https://cdn.ckeditor.com/ckeditor5/40.0.0/classic/ckeditor.js"></script>
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Pretendard', 'Apple SD Gothic Neo', sans-serif; background: #f5f6fa; color: #1a1a2e; }
        #admin_wrapper { display: flex; min-height: 100vh; }
        .content_area { flex: 1; padding: 40px; overflow-x: hidden; }

        /* 페이지 타이틀 */
        .page_header { margin-bottom: 28px; }
        .page_title { font-size: 22px; font-weight: 700; color: #1a1a2e; }
        .page_sub { font-size: 14px; color: #9999bb; margin-top: 4px; }

        /* 폼 카드 */
        .form_card {
            background: #fff; border-radius: 12px;
            box-shadow: 0 2px 12px rgba(0,0,0,0.07);
            border: 1px solid #e8eaf0; padding: 32px;
            max-width: 960px;
        }

        .form_row { margin-bottom: 22px; }
        .form_row_2 { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 22px; }
        @media (max-width: 640px) { .form_row_2 { grid-template-columns: 1fr; } }

        label {
            display: block; font-size: 13px; font-weight: 700;
            color: #1a1a2e; margin-bottom: 8px;
        }
        label .req { color: #4f46e5; margin-left: 2px; }

        select, input[type="text"] {
            width: 100%; height: 46px;
            border: 1px solid #e8eaf0; border-radius: 8px;
            padding: 0 14px; font-size: 14px; color: #1a1a2e;
            background: #f5f6fa; transition: all 0.2s;
        }
        select:focus, input[type="text"]:focus {
            outline: none; border-color: #4f46e5; background: #fff;
            box-shadow: 0 0 0 3px rgba(79,70,229,0.1);
        }
        select:disabled { opacity: 0.6; cursor: not-allowed; }

        /* 카테고리 행 토글 */
        .category_row { display: none; }
        .category_row.active { display: block; }

        /* CKEditor */
        .editor_label { font-size: 13px; font-weight: 700; color: #1a1a2e; margin-bottom: 8px; }
        .ck-editor__editable { min-height: 460px !important; }

        /* 버튼 */
        .form_actions { display: flex; gap: 12px; margin-top: 28px; }
        .btn_cancel, .btn_submit {
            flex: 1; height: 48px; border-radius: 8px;
            font-size: 15px; font-weight: 700; cursor: pointer;
            border: none; transition: all 0.2s;
        }
        .btn_cancel { background: #f5f6fa; color: #5c5c7a; border: 1px solid #e8eaf0; }
        .btn_cancel:hover { background: #e8eaf0; color: #1a1a2e; }
        .btn_submit { background: #4f46e5; color: #fff; box-shadow: 0 4px 12px rgba(79,70,229,0.25); }
        .btn_submit:hover { background: #4338ca; transform: translateY(-1px); }
    </style>
</head>
<body>
<div id="admin_wrapper">
    <?php include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/aside.php'); ?>

    <div class="content_area">
        <div class="page_header">
            <h2 class="page_title"><?= ($mode == 'modify') ? $title_prefix.' 수정' : '새 '.$title_prefix.' 작성' ?></h2>
            <p class="page_sub">등록된 내용은 사이트에 즉시 반영됩니다.</p>
        </div>

        <div class="form_card">
            <form name="fwrite" id="fwrite" method="post" action="<?= $_SERVER['PHP_SELF'] ?>" onsubmit="return submitForm();">
                <input type="hidden" name="mode" value="<?= $mode ?>">
                <input type="hidden" name="wr_id" value="<?= $wr_id ?>">

                <div class="form_row_2">
                    <!-- 게시판 선택 -->
                    <div>
                        <label>게시판 분류 <span class="req">*</span></label>
                        <select name="bo_table" id="bo_table" required onchange="toggleCategory()" <?= ($mode == 'modify') ? 'disabled' : '' ?>>
                            <option value="">게시판을 선택하세요</option>
                            <?php foreach ($dm_boards as $table => $data): ?>
                            <option value="<?= $table ?>" <?= ($bo_table == $table) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($data['subject']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                        <?php if ($mode == 'modify'): ?>
                        <input type="hidden" name="bo_table" value="<?= $bo_table ?>">
                        <?php endif; ?>
                    </div>

                    <!-- 카테고리 -->
                    <div class="category_row" id="category_row">
                        <label>카테고리</label>
                        <select name="category_id" id="category_id">
                            <option value="">선택하세요</option>
                        </select>
                    </div>
                </div>

                <!-- 제목 -->
                <div class="form_row">
                    <label>제목 <span class="req">*</span></label>
                    <input type="text" name="wr_subject" id="wr_subject" placeholder="제목을 입력하세요" required value="<?= htmlspecialchars($write['wr_subject'] ?? '') ?>">
                </div>

                <!-- 에디터 -->
                <div class="form_row">
                    <p class="editor_label">상세 내용 <span class="req">*</span></p>
                    <div id="editor"><?= stripslashes($write['wr_content'] ?? '') ?></div>
                    <textarea name="wr_content" id="wr_content" style="display:none;"></textarea>
                </div>

                <div class="form_actions">
                    <button type="button" onclick="goBack()" class="btn_cancel">취소</button>
                    <button type="submit" class="btn_submit">
                        <?= ($mode == 'modify') ? '수정 완료' : '작성 완료' ?>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
let editorInstance;
const boardCategories = <?= json_encode($board_categories) ?>;
const savedCategoryId = "<?= $write['wr_10'] ?? '' ?>";
const currentBoTable  = "<?= $bo_table ?>";

ClassicEditor.create(document.querySelector('#editor'), {
    language: 'ko',
    ckfinder: { uploadUrl: '<?= $_SERVER['PHP_SELF'] ?>' },
    toolbar: ['heading','|','bold','italic','link','bulletedList','numberedList','imageUpload','undo','redo']
}).then(editor => { editorInstance = editor; });

function toggleCategory() {
    const boTable = document.getElementById('bo_table').value;
    const categoryRow = document.getElementById('category_row');
    const categorySelect = document.getElementById('category_id');
    categorySelect.innerHTML = '<option value="">선택하세요</option>';
    categoryRow.classList.remove('active');
    if (boTable && boardCategories[boTable] && boardCategories[boTable].length > 0) {
        categoryRow.classList.add('active');
        boardCategories[boTable].forEach(cat => {
            let opt = document.createElement('option');
            opt.value = cat.id; opt.text = cat.name;
            if (opt.value == savedCategoryId) opt.selected = true;
            categorySelect.appendChild(opt);
        });
    }
}

function submitForm() {
    if (!document.getElementById('bo_table').value) { alert('게시판을 선택해 주세요.'); return false; }
    document.getElementById('wr_content').value = editorInstance.getData();
    return true;
}

function goBack() {
    if (currentBoTable === 'faq') location.href = '/newadm/board/faq_manager.php';
    else history.back();
}

window.onload = toggleCategory;
</script>
</body>
</html>