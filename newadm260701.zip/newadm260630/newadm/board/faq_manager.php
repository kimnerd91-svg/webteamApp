<?php
include_once('../_common.php');
include_once('../_auth_check.php');

// ============================================================
// 테이블 자동 생성
// ============================================================
$chk = sql_query("SHOW TABLES LIKE 'dm_faq_group'");
if (sql_num_rows($chk) == 0) {
    sql_query("CREATE TABLE `dm_faq_group` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `name` varchar(255) NOT NULL,
        `description` varchar(500) NOT NULL DEFAULT '',
        `created_at` datetime NOT NULL DEFAULT NOW(),
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", false);
}
$chk2 = sql_query("SHOW TABLES LIKE 'dm_faq_item'");
if (sql_num_rows($chk2) == 0) {
    sql_query("CREATE TABLE `dm_faq_item` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `group_id` int(11) NOT NULL,
        `question` varchar(500) NOT NULL,
        `answer` text NOT NULL,
        PRIMARY KEY (`id`),
        KEY `group_id` (`group_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", false);
}

// ============================================================
// JSON 내보내기
// ============================================================
if (isset($_GET['action']) && $_GET['action'] === 'export_json') {
    $result = sql_query("SELECT id, name, description FROM dm_faq_group ORDER BY id ASC");
    $data = [];
    while ($group = sql_fetch_array($result)) {
        $items = [];
        $iResult = sql_query("SELECT question, answer FROM dm_faq_item WHERE group_id={$group['id']} ORDER BY id ASC");
        while ($item = sql_fetch_array($iResult)) $items[] = $item;
        $data[] = [
            'name'        => $group['name'],
            'description' => $group['description'],
            'items'       => $items,
        ];
    }
    $filename = 'faq_' . date('Ymd_His') . '.json';
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

// ============================================================
// JSON 가져오기
// ============================================================
if (isset($_POST['action']) && $_POST['action'] === 'import_json') {
    header('Content-Type: application/json');
    $raw    = $_POST['json_data'] ?? '';
    $raw    = base64_decode($raw); // G5 자동 이스케이프 우회
    $groups = json_decode($raw, true);
    if (!is_array($groups)) {
        echo json_encode(['success' => 0, 'message' => '유효하지 않은 JSON 형식입니다.']);
        exit;
    }
    $inserted_groups = 0;
    $inserted_items  = 0;
    $skipped_groups  = 0;
    $skipped_items   = 0;
    foreach ($groups as $group) {
        $name = trim($group['name'] ?? '');
        if (!$name) { $skipped_groups++; continue; }
        $esc_name = sql_real_escape_string($name);
        $esc_desc = sql_real_escape_string(trim($group['description'] ?? ''));

        // 중복 그룹명 체크 — 이미 있으면 그룹+아이템 모두 건너뜀
        $chk = sql_query("SELECT id FROM dm_faq_group WHERE name='{$esc_name}' LIMIT 1");
        if (sql_num_rows($chk) > 0) {
            $skipped_groups++;
            $skipped_items += count($group['items'] ?? []);
            continue; // ← 아이템 루프 진입 자체를 막음
        }

        sql_query("INSERT INTO dm_faq_group (name, description) VALUES ('{$esc_name}', '{$esc_desc}')");
        $group_id = sql_insert_id();
        $inserted_groups++;

        // 새 그룹의 아이템 삽입 — 질문 텍스트 중복도 이중 체크
        foreach (($group['items'] ?? []) as $item) {
            $question = sql_real_escape_string(trim($item['question'] ?? ''));
            $answer   = sql_real_escape_string(trim($item['answer']   ?? ''));
            if (!$question) { $skipped_items++; continue; }
            $dup = sql_query("SELECT id FROM dm_faq_item WHERE group_id={$group_id} AND question='{$question}' LIMIT 1");
            if (sql_num_rows($dup) > 0) { $skipped_items++; continue; }
            sql_query("INSERT INTO dm_faq_item (group_id, question, answer) VALUES ({$group_id}, '{$question}', '{$answer}')");
            $inserted_items++;
        }
    }
    echo json_encode([
        'success'         => 1,
        'inserted_groups' => $inserted_groups,
        'inserted_items'  => $inserted_items,
        'skipped_groups'  => $skipped_groups,
        'skipped_items'   => $skipped_items,
    ]);
    exit;
}

// ============================================================
// AJAX 처리
// ============================================================
if (isset($_POST['ajax_action'])) {
    header('Content-Type: application/json');
    $action = $_POST['ajax_action'];

    if ($action === 'save_group') {
        $id   = (int)($_POST['id'] ?? 0);
        $name = sql_real_escape_string(stripslashes(trim($_POST['name'] ?? '')));
        $desc = sql_real_escape_string(stripslashes(trim($_POST['description'] ?? '')));
        if (!$name) { echo json_encode(['success' => false, 'msg' => '그룹명을 입력하세요.']); exit; }
        if ($id) {
            sql_query("UPDATE dm_faq_group SET name='{$name}', description='{$desc}' WHERE id={$id}");
        } else {
            sql_query("INSERT INTO dm_faq_group (name, description) VALUES ('{$name}', '{$desc}')");
            $id = sql_insert_id();
        }
        echo json_encode(['success' => true, 'id' => $id]);
        exit;
    }

    if ($action === 'delete_group') {
        $id = (int)($_POST['id'] ?? 0);
        sql_query("DELETE FROM dm_faq_item WHERE group_id={$id}");
        sql_query("DELETE FROM dm_faq_group WHERE id={$id}");
        echo json_encode(['success' => true]);
        exit;
    }

    if ($action === 'save_item') {
        $id       = (int)($_POST['id'] ?? 0);
        $group_id = (int)($_POST['group_id'] ?? 0);
        $question = sql_real_escape_string(stripslashes(trim($_POST['question'] ?? '')));
        $answer   = sql_real_escape_string(stripslashes(trim($_POST['answer'] ?? '')));
        if (!$question) { echo json_encode(['success' => false, 'msg' => '질문을 입력하세요.']); exit; }
        if ($id) {
            sql_query("UPDATE dm_faq_item SET question='{$question}', answer='{$answer}' WHERE id={$id}");
        } else {
            sql_query("INSERT INTO dm_faq_item (group_id, question, answer) VALUES ({$group_id}, '{$question}', '{$answer}')");
            $id = sql_insert_id();
        }
        echo json_encode(['success' => true, 'id' => $id]);
        exit;
    }

    if ($action === 'delete_item') {
        $id = (int)($_POST['id'] ?? 0);
        sql_query("DELETE FROM dm_faq_item WHERE id={$id}");
        echo json_encode(['success' => true]);
        exit;
    }

    if ($action === 'get_items') {
        $group_id = (int)($_POST['group_id'] ?? 0);
        $result   = sql_query("SELECT * FROM dm_faq_item WHERE group_id={$group_id} ORDER BY id ASC");
        $items = [];
        while ($row = sql_fetch_array($result)) $items[] = $row;
        echo json_encode(['success' => true, 'items' => $items]);
        exit;
    }

    echo json_encode(['success' => false, 'msg' => 'unknown action']);
    exit;
}

// ============================================================
// 그룹 목록
// ============================================================
$groups = [];
$result = sql_query("SELECT g.*, (SELECT COUNT(*) FROM dm_faq_item WHERE group_id = g.id) as item_count FROM dm_faq_group g ORDER BY g.id ASC");
while ($row = sql_fetch_array($result)) $groups[] = $row;
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>FAQ 관리</title>
<style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Pretendard', 'Apple SD Gothic Neo', sans-serif; background: #f5f6fa; color: #1a1a2e; }
    #admin_wrapper { display: flex; min-height: 100vh; }
    .content_area { flex: 1; padding: 40px; overflow-x: hidden; }

    .page_header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 28px; }
    .page_title  { font-size: 22px; font-weight: 700; }
    .page_header_actions { display: flex; gap: 10px; align-items: center; }
    .btn_add { padding: 11px 22px; background: #4f46e5; color: #fff; border: none; border-radius: 9px; font-size: 13px; font-weight: 700; cursor: pointer; box-shadow: 0 4px 12px rgba(79,70,229,0.25); transition: all 0.2s; }
    .btn_add:hover { background: #4338ca; }
    .btn_export { padding: 11px 22px; background: #059669; color: #fff; border: none; border-radius: 9px; font-size: 13px; font-weight: 700; cursor: pointer; box-shadow: 0 4px 12px rgba(5,150,105,0.25); transition: all 0.2s; }
    .btn_export:hover { background: #047857; }
    .btn_import { padding: 11px 22px; background: #0891b2; color: #fff; border: none; border-radius: 9px; font-size: 13px; font-weight: 700; cursor: pointer; box-shadow: 0 4px 12px rgba(8,145,178,0.25); transition: all 0.2s; }
    .btn_import:hover { background: #0e7490; }

    .info_card { background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 12px; padding: 16px 20px; margin-bottom: 24px; font-size: 13px; color: #1e40af; }
    .info_card code { font-size: 13px; color: #4f46e5; }

    /* FAQ 그룹 카드 */
    .faq_group_card { background: #fff; border-radius: 12px; box-shadow: 0 2px 12px rgba(0,0,0,0.06); border: 1px solid #e8eaf0; margin-bottom: 16px; overflow: hidden; transition: all 0.2s; }
    .faq_group_card:hover { box-shadow: 0 4px 20px rgba(0,0,0,0.09); }

    .faq_group_header { display: flex; align-items: center; gap: 14px; padding: 18px 22px; cursor: pointer; user-select: none; transition: background 0.15s; }
    .faq_group_header:hover { background: #f5f6fa; }

    .group_id_badge { background: #4f46e5; color: #fff; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 700; white-space: nowrap; display: flex; align-items: center; gap: 6px; }
    .copy_id_btn { font-size: 11px; padding: 2px 8px; background: rgba(255,255,255,0.25); border: none; border-radius: 4px; cursor: pointer; color: #fff; transition: background 0.15s; }
    .copy_id_btn:hover { background: rgba(255,255,255,0.45); }

    .group_count_badge { background: #ede9fe; color: #4f46e5; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 700; white-space: nowrap; }

    .group_name { font-size: 15px; font-weight: 700; color: #1a1a2e; }
    .group_desc { font-size: 13px; color: #9999bb; margin-top: 3px; }
    .group_flex { flex: 1; min-width: 0; }

    .header_actions { display: flex; gap: 8px; position: relative; z-index: 2; }
    .btn_group_edit { padding: 7px 16px; background: #f5f6fa; color: #1a1a2e; border: 1px solid #e8eaf0; border-radius: 7px; font-size: 12px; font-weight: 700; cursor: pointer; transition: all 0.2s; }
    .btn_group_edit:hover { background: #e8eaf0; }
    .btn_group_del  { padding: 7px 16px; background: #fee2e2; color: #dc2626; border: none; border-radius: 7px; font-size: 12px; font-weight: 700; cursor: pointer; transition: all 0.2s; }
    .btn_group_del:hover { background: #fecaca; }

    .chevron { transition: transform 0.2s; font-size: 20px; color: #9999bb; pointer-events: none; }
    .chevron.open { transform: rotate(180deg); }

    /* FAQ 아이템 영역 */
    .faq_items_area { border-top: 1px solid #e8eaf0; display: none; }
    .faq_item_row { display: flex; align-items: flex-start; gap: 14px; padding: 16px 22px; border-bottom: 1px solid #f5f6fa; transition: background 0.15s; }
    .faq_item_row:last-child { border-bottom: none; }
    .faq_item_row:hover { background: #fafbff; }
    .q_text { font-size: 14px; font-weight: 700; color: #1a1a2e; }
    .a_text { font-size: 13px; color: #9999bb; margin-top: 5px; line-height: 1.6; white-space: pre-wrap; }
    .item_actions { display: flex; gap: 7px; flex-shrink: 0; }
    .btn_item_edit { padding: 6px 14px; background: #4f46e5; color: #fff; border: none; border-radius: 6px; font-size: 12px; font-weight: 700; cursor: pointer; transition: all 0.2s; }
    .btn_item_edit:hover { background: #4338ca; }
    .btn_item_del  { padding: 6px 14px; background: #fee2e2; color: #dc2626; border: none; border-radius: 6px; font-size: 12px; font-weight: 700; cursor: pointer; transition: all 0.2s; }
    .btn_item_del:hover { background: #fecaca; }

    .add_item_row { padding: 14px 22px; background: #f5f6fa; }
    .btn_add_item { padding: 9px 18px; background: #4f46e5; color: #fff; border: none; border-radius: 7px; font-size: 13px; font-weight: 700; cursor: pointer; transition: all 0.2s; box-shadow: 0 2px 8px rgba(79,70,229,0.2); }
    .btn_add_item:hover { background: #4338ca; }

    .empty_state { text-align: center; padding: 60px; color: #9999bb; font-size: 14px; }

    /* 모달 공통 */
    .modal_overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.55); z-index: 10000; align-items: flex-start; justify-content: center; padding: 40px 20px; overflow-y: auto; }
    .modal_overlay.active { display: flex; }
    .modal_box { background: #fff; border-radius: 14px; width: 100%; max-width: 560px; overflow: hidden; animation: modal_in 0.25s ease; margin: auto; }
    .modal_box.modal_lg { max-width: 680px; }
    @keyframes modal_in { from { transform: translateY(-20px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
    .modal_hd { padding: 20px 24px; border-bottom: 1px solid #e8eaf0; display: flex; align-items: center; justify-content: space-between; }
    .modal_hd h3 { font-size: 16px; font-weight: 700; }
    .modal_close { background: none; border: none; font-size: 20px; cursor: pointer; color: #9999bb; }
    .modal_bd { padding: 24px; display: flex; flex-direction: column; gap: 16px; max-height: 75vh; overflow-y: auto; }
    .modal_ft { padding: 16px 24px; border-top: 1px solid #e8eaf0; display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }

    .form_group label { display: block; font-size: 12px; font-weight: 700; color: #9999bb; margin-bottom: 6px; }
    .form_group label span { color: #dc2626; }
    .form_input { width: 100%; border: 1px solid #e8eaf0; border-radius: 8px; padding: 10px 14px; font-size: 14px; background: #f5f6fa; font-family: inherit; transition: all 0.2s; }
    .form_input:focus { outline: none; border-color: #4f46e5; background: #fff; box-shadow: 0 0 0 3px rgba(79,70,229,0.1); }
    textarea.form_input { resize: vertical; min-height: 100px; }

    .btn_modal_cancel { padding: 12px; border-radius: 8px; background: #f5f6fa; color: #5c5c7a; border: 1px solid #e8eaf0; font-size: 14px; font-weight: 700; cursor: pointer; }
    .btn_modal_submit { padding: 12px; border-radius: 8px; background: #4f46e5; color: #fff; border: none; font-size: 14px; font-weight: 700; cursor: pointer; }
    .btn_modal_submit:hover { background: #4338ca; }

    /* JSON 가져오기 전용 */
    .upload_zone { border: 2px dashed #e8eaf0; border-radius: 10px; padding: 20px; text-align: center; cursor: pointer; transition: all 0.2s; background: #f5f6fa; position: relative; min-height: 100px; display: flex; flex-direction: column; align-items: center; justify-content: center; }
    .upload_zone:hover, .upload_zone.dragover { border-color: #0891b2; background: #ecfeff; }
    .upload_zone input[type="file"] { position: absolute; inset: 0; opacity: 0; cursor: pointer; width: 100%; height: 100%; }
    .upload_zone_icon { font-size: 28px; margin-bottom: 6px; pointer-events: none; }
    .upload_zone_text { font-size: 13px; color: #9999bb; pointer-events: none; }
    .upload_zone_text strong { color: #0891b2; }
    .import_json_schema { background: #f5f6fa; border: 1px solid #e8eaf0; border-radius: 10px; padding: 14px 18px; font-size: 12px; color: #5c5c7a; line-height: 1.9; font-family: monospace; }
    .import_file_info { background: #f0f9ff; border: 1px solid #bae6fd; border-radius: 10px; padding: 12px 16px; font-size: 13px; color: #0c4a6e; display: none; }
    .import_preview_wrap { display: none; }
    .import_preview_label { font-size: 12px; font-weight: 700; color: #9999bb; margin-bottom: 8px; }
    .import_preview_list { display: flex; flex-direction: column; gap: 6px; }
    .import_preview_item { background: #f5f6fa; border-radius: 8px; padding: 10px 14px; font-size: 13px; }
    .import_preview_group { font-weight: 700; color: #1a1a2e; }
    .import_preview_badge { background: #ede9fe; color: #4f46e5; padding: 2px 8px; border-radius: 20px; font-size: 11px; font-weight: 700; margin-left: 8px; }
    .import_preview_q { color: #9999bb; font-size: 12px; margin-top: 4px; }
    .import_error { background: #fef2f2; border: 1px solid #fecaca; border-radius: 10px; padding: 12px 16px; font-size: 13px; color: #dc2626; display: none; }
</style>
</head>
<body>
<div id="admin_wrapper">
    <?php include_once('../aside.php'); ?>
    <main class="content_area">

        <div class="page_header">
            <h2 class="page_title">❓ FAQ 관리</h2>
            <div class="page_header_actions">
                <button type="button" class="btn_export" onclick="location.href='?action=export_json'">📤 JSON 내보내기</button>
                <button type="button" class="btn_import" onclick="openImportModal()">📥 JSON 가져오기</button>
                <button type="button" class="btn_add" onclick="openGroupModal()">+ FAQ 그룹 추가</button>
            </div>
        </div>

        <div class="info_card">
            📌 <strong>프론트에서 호출하는 방법</strong> — 아래 그룹 ID를 사용하세요<br>
            <code>$faq_result = sql_query("SELECT * FROM dm_faq_item WHERE group_id = <strong>그룹ID</strong> ORDER BY id ASC");</code>
        </div>

        <?php if (empty($groups)): ?>
        <div class="empty_state">등록된 FAQ 그룹이 없습니다.</div>
        <?php else: ?>
        <?php foreach ($groups as $g): ?>
        <div class="faq_group_card" id="group-row-<?= $g['id'] ?>">
            <div class="faq_group_header" onclick="toggleGroup(<?= $g['id'] ?>, event)">
                <span class="group_id_badge">
                    ID: <?= $g['id'] ?>
                    <button class="copy_id_btn" onclick="event.stopPropagation(); copyId(<?= $g['id'] ?>)">복사</button>
                </span>
                <div class="group_flex">
                    <div class="group_name"><?= htmlspecialchars($g['name']) ?></div>
                    <?php if ($g['description']): ?>
                    <div class="group_desc"><?= htmlspecialchars($g['description']) ?></div>
                    <?php endif; ?>
                </div>
                <span class="group_count_badge">Q&A <?= $g['item_count'] ?>개</span>
                <div class="header_actions" onclick="event.stopPropagation()">
                    <button type="button" class="btn_group_edit"
                        onclick="openGroupModal(<?= htmlspecialchars(json_encode($g), ENT_QUOTES) ?>)">수정</button>
                    <button type="button" class="btn_group_del"
                        onclick="deleteGroup(<?= $g['id'] ?>, '<?= htmlspecialchars($g['name'], ENT_QUOTES) ?>')">삭제</button>
                </div>
                <span class="chevron" id="chevron-<?= $g['id'] ?>">▾</span>
            </div>
            <div class="faq_items_area" id="items-area-<?= $g['id'] ?>">
                <div id="items-list-<?= $g['id'] ?>"></div>
                <div class="add_item_row">
                    <button type="button" class="btn_add_item" onclick="openItemModal(<?= $g['id'] ?>)">+ 질문 추가</button>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>

    </main>
</div>

<!-- 그룹 모달 -->
<div class="modal_overlay" id="groupModal">
    <div class="modal_box">
        <div class="modal_hd">
            <h3 id="groupModalTitle">FAQ 그룹 추가</h3>
            <button class="modal_close" onclick="closeModal('groupModal')">✕</button>
        </div>
        <div class="modal_bd">
            <input type="hidden" id="groupId" value="0">
            <div class="form_group">
                <label>그룹명 <span>*</span></label>
                <input type="text" id="groupName" class="form_input" placeholder="예: 임플란트 FAQ">
            </div>
            <div class="form_group">
                <label>설명</label>
                <input type="text" id="groupDesc" class="form_input" placeholder="간단한 설명 (선택)">
            </div>
        </div>
        <div class="modal_ft">
            <button type="button" class="btn_modal_cancel" onclick="closeModal('groupModal')">취소</button>
            <button type="button" class="btn_modal_submit" onclick="saveGroup()">저장</button>
        </div>
    </div>
</div>

<!-- 아이템 모달 -->
<div class="modal_overlay" id="itemModal">
    <div class="modal_box modal_lg">
        <div class="modal_hd">
            <h3 id="itemModalTitle">질문 추가</h3>
            <button class="modal_close" onclick="closeModal('itemModal')">✕</button>
        </div>
        <div class="modal_bd">
            <input type="hidden" id="itemId" value="0">
            <input type="hidden" id="itemGroupId" value="0">
            <div class="form_group">
                <label>질문 <span>*</span></label>
                <input type="text" id="itemQuestion" class="form_input" placeholder="질문을 입력하세요">
            </div>
            <div class="form_group">
                <label>답변</label>
                <textarea id="itemAnswer" class="form_input" rows="6" placeholder="답변을 입력하세요"></textarea>
            </div>
        </div>
        <div class="modal_ft">
            <button type="button" class="btn_modal_cancel" onclick="closeModal('itemModal')">취소</button>
            <button type="button" class="btn_modal_submit" onclick="saveItem()">저장</button>
        </div>
    </div>
</div>

<!-- JSON 가져오기 모달 -->
<div class="modal_overlay" id="importModal">
    <div class="modal_box modal_lg">
        <div class="modal_hd">
            <h3>📥 JSON 가져오기</h3>
            <button class="modal_close" onclick="closeModal('importModal')">✕</button>
        </div>
        <div class="modal_bd">

            <!-- JSON 형식 안내 -->
            <div class="form_group">
                <label>JSON 형식 안내</label>
                <div class="import_json_schema">
                    [<br>
                    &nbsp;&nbsp;{<br>
                    &nbsp;&nbsp;&nbsp;&nbsp;"name": "그룹명",<br>
                    &nbsp;&nbsp;&nbsp;&nbsp;"description": "그룹 설명 (선택)",<br>
                    &nbsp;&nbsp;&nbsp;&nbsp;"items": [<br>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{ "question": "질문 내용", "answer": "답변 내용" }<br>
                    &nbsp;&nbsp;&nbsp;&nbsp;]<br>
                    &nbsp;&nbsp;}<br>
                    ]
                </div>
            </div>

            <!-- 드래그&드롭 존 -->
            <div class="form_group">
                <label>JSON 파일 선택</label>
                <div id="import_drop_zone" class="upload_zone"
                    ondragover="event.preventDefault();this.classList.add('dragover')"
                    ondragleave="this.classList.remove('dragover')"
                    ondrop="handleJsonDrop(event)">
                    <input type="file" accept=".json,application/json" id="import_file_input"
                        onchange="handleJsonFile(this.files[0])">
                    <div class="upload_zone_icon">📄</div>
                    <div class="upload_zone_text">JSON 파일을 <strong>드래그</strong> 하거나 <strong>클릭</strong>하여 선택</div>
                </div>
            </div>

            <!-- 파일 정보 -->
            <div class="import_file_info" id="import_file_info">
                <span id="import_file_name" style="font-weight:700;"></span>
                <span id="import_item_count" style="margin-left:10px;color:#0891b2;font-weight:600;"></span>
            </div>

            <!-- 미리보기 -->
            <div class="import_preview_wrap" id="import_preview_wrap">
                <div class="import_preview_label">미리보기 (최대 3개 그룹)</div>
                <div class="import_preview_list" id="import_preview_list"></div>
            </div>

            <!-- 오류 -->
            <div class="import_error" id="import_error"></div>

        </div>
        <div class="modal_ft">
            <button type="button" class="btn_modal_cancel" onclick="closeModal('importModal')">취소</button>
            <button type="button" class="btn_modal_submit" id="btn_do_import"
                style="background:#0891b2;" onclick="doImport()" disabled>가져오기</button>
        </div>
    </div>
</div>

<script>
const AJAX_URL   = './faq_manager.php';
const openGroups = {};

// ── 모달 ──
function closeModal(id) { document.getElementById(id).classList.remove('active'); }


// ── 그룹 토글 ──
async function toggleGroup(groupId, event) {
    if (event.target.closest('.header_actions') || event.target.closest('.copy_id_btn')) return;

    const area    = document.getElementById('items-area-' + groupId);
    const chevron = document.getElementById('chevron-' + groupId);

    if (openGroups[groupId]) {
        area.style.display = 'none';
        chevron.classList.remove('open');
        openGroups[groupId] = false;
        return;
    }

    await loadItems(groupId);
    area.style.display = 'block';
    chevron.classList.add('open');
    openGroups[groupId] = true;
}

// ── 아이템 목록 렌더 ──
async function loadItems(groupId) {
    const res  = await ajax({ ajax_action: 'get_items', group_id: groupId });
    const list = document.getElementById('items-list-' + groupId);

    if (!res.items || res.items.length === 0) {
        list.innerHTML = '<div class="empty_state" style="padding:30px;">등록된 질문이 없습니다.</div>';
        return;
    }

    list.innerHTML = res.items.map(item => `
        <div class="faq_item_row" id="item-row-${item.id}">
            <div style="flex:1;min-width:0;">
                <div class="q_text">Q. ${esc(item.question)}</div>
                <div class="a_text">${esc(item.answer)}</div>
            </div>
            <div class="item_actions">
                <button type="button" class="btn_item_edit"
                    data-action="edit"
                    data-id="${item.id}"
                    data-group="${groupId}"
                    data-question="${esc(item.question)}"
                    data-answer="${esc(item.answer)}">수정</button>
                <button type="button" class="btn_item_del"
                    data-action="delete"
                    data-id="${item.id}"
                    data-group="${groupId}">삭제</button>
            </div>
        </div>
    `).join('');

    list.addEventListener('click', function(e) {
        const btn = e.target.closest('[data-action]');
        if (!btn) return;
        const { action, id, group, question, answer } = btn.dataset;
        if (action === 'edit') {
            openItemModal(group, { id, question, answer });
        } else if (action === 'delete') {
            deleteItem(id, group);
        }
    }, { once: false });
}

// ── 그룹 모달 ──
function openGroupModal(group) {
    document.getElementById('groupId').value   = group ? group.id : 0;
    document.getElementById('groupName').value = group ? group.name : '';
    document.getElementById('groupDesc').value = group ? group.description : '';
    document.getElementById('groupModalTitle').textContent = group ? 'FAQ 그룹 수정' : 'FAQ 그룹 추가';
    document.getElementById('groupModal').classList.add('active');
}

async function saveGroup() {
    const id   = document.getElementById('groupId').value;
    const name = document.getElementById('groupName').value.trim();
    if (!name) { alert('그룹명을 입력하세요.'); return; }
    const res = await ajax({
        ajax_action: 'save_group', id, name,
        description: document.getElementById('groupDesc').value,
    });
    if (res.success) {
        closeModal('groupModal');
        location.reload();
    } else {
        alert(res.msg || '저장 실패');
    }
}

async function deleteGroup(id, name) {
    if (!confirm(`"${name}" 그룹을 삭제하면 하위 질문도 모두 삭제됩니다.\n정말 삭제하시겠습니까?`)) return;
    const res = await ajax({ ajax_action: 'delete_group', id });
    if (res.success) document.getElementById('group-row-' + id).remove();
}

// ── 아이템 모달 ──
function openItemModal(groupId, item) {
    document.getElementById('itemId').value       = item ? item.id : 0;
    document.getElementById('itemGroupId').value  = groupId;
    document.getElementById('itemQuestion').value = item ? item.question : '';
    document.getElementById('itemAnswer').value   = item ? item.answer : '';
    document.getElementById('itemModalTitle').textContent = (item && item.id) ? '질문 수정' : '질문 추가';
    document.getElementById('itemModal').classList.add('active');
}

async function saveItem() {
    const groupId  = document.getElementById('itemGroupId').value;
    const question = document.getElementById('itemQuestion').value.trim();
    if (!question) { alert('질문을 입력하세요.'); return; }
    const res = await ajax({
        ajax_action: 'save_item',
        id:       document.getElementById('itemId').value,
        group_id: groupId,
        question,
        answer: document.getElementById('itemAnswer').value,
    });
    if (res.success) {
        closeModal('itemModal');
        await loadItems(groupId);
    } else {
        alert(res.msg || '저장 실패');
    }
}

async function deleteItem(id, groupId) {
    if (!confirm('질문을 삭제하시겠습니까?')) return;
    const res = await ajax({ ajax_action: 'delete_item', id });
    if (res.success) await loadItems(groupId);
}

// ── JSON 가져오기 ──
let importJsonData = null;

function openImportModal() {
    importJsonData = null;
    document.getElementById('import_file_input').value = '';
    document.getElementById('import_file_info').style.display    = 'none';
    document.getElementById('import_preview_wrap').style.display = 'none';
    document.getElementById('import_error').style.display        = 'none';
    document.getElementById('btn_do_import').disabled = true;
    document.getElementById('btn_do_import').textContent = '가져오기';
    document.getElementById('importModal').classList.add('active');
}

function handleJsonDrop(e) {
    e.preventDefault();
    e.currentTarget.classList.remove('dragover');
    const file = e.dataTransfer.files[0];
    if (file) handleJsonFile(file);
}

function handleJsonFile(file) {
    if (!file) return;
    // 초기화
    document.getElementById('import_error').style.display        = 'none';
    document.getElementById('import_preview_wrap').style.display = 'none';
    document.getElementById('import_file_info').style.display    = 'none';
    document.getElementById('btn_do_import').disabled = true;
    importJsonData = null;

    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            const parsed = JSON.parse(e.target.result);
            if (!Array.isArray(parsed))        throw new Error('최상위가 배열([ ])이어야 합니다.');
            if (parsed.length === 0)           throw new Error('데이터가 비어 있습니다.');
            parsed.forEach((g, i) => {
                if (!g.name || !g.name.trim()) throw new Error((i + 1) + '번째 항목에 name 필드가 없습니다.');
            });
            importJsonData = parsed;

            // 파일 정보
            const totalItems = parsed.reduce((s, g) => s + (g.items ? g.items.length : 0), 0);
            document.getElementById('import_file_name').textContent  = file.name;
            document.getElementById('import_item_count').textContent =
                `총 ${parsed.length}개 그룹 / ${totalItems}개 질문`;
            document.getElementById('import_file_info').style.display = 'block';

            // 미리보기 (최대 3개 그룹)
            const preview = parsed.slice(0, 3);
            document.getElementById('import_preview_list').innerHTML = preview.map(g => {
                const itemCount  = g.items ? g.items.length : 0;
                const firstQ     = g.items && g.items[0] ? escHtml(g.items[0].question) : '';
                return `<div class="import_preview_item">
                    <div>
                        <span class="import_preview_group">${escHtml(g.name)}</span>
                        <span class="import_preview_badge">Q&A ${itemCount}개</span>
                        ${g.description ? `<span style="color:#9999bb;font-size:12px;margin-left:8px;">${escHtml(g.description)}</span>` : ''}
                    </div>
                    ${firstQ ? `<div class="import_preview_q">Q. ${firstQ}${itemCount > 1 ? ' 외 ' + (itemCount - 1) + '개' : ''}</div>` : ''}
                </div>`;
            }).join('');
            document.getElementById('import_preview_wrap').style.display = 'block';
            document.getElementById('btn_do_import').disabled = false;

        } catch (err) {
            document.getElementById('import_error').textContent = '❌ JSON 파싱 오류: ' + err.message;
            document.getElementById('import_error').style.display = 'block';
        }
    };
    reader.readAsText(file, 'utf-8');
}

function doImport() {
    if (!importJsonData) return;
    const btn = document.getElementById('btn_do_import');
    btn.disabled = true;
    btn.textContent = '가져오는 중...';

    const fd = new FormData();
    fd.append('action', 'import_json');
    fd.append('json_data', btoa(unescape(encodeURIComponent(JSON.stringify(importJsonData)))));

    fetch('./faq_manager.php', { method: 'POST', body: fd })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                closeModal('importModal');
                alert(
                    `✅ 가져오기 완료!\n` +
                    `추가된 그룹: ${data.inserted_groups}개\n` +
                    `추가된 질문: ${data.inserted_items}개\n` +
                    `건너뜀 (중복 그룹): ${data.skipped_groups}개\n` +
                    `건너뜀 (중복/빈 질문): ${data.skipped_items}개`
                );
                location.reload();
            } else {
                document.getElementById('import_error').textContent = '❌ ' + (data.message || '오류가 발생했습니다.');
                document.getElementById('import_error').style.display = 'block';
                btn.disabled = false;
                btn.textContent = '가져오기';
            }
        })
        .catch(() => {
            document.getElementById('import_error').textContent = '❌ 서버 통신 오류가 발생했습니다.';
            document.getElementById('import_error').style.display = 'block';
            btn.disabled = false;
            btn.textContent = '가져오기';
        });
}

// ── 공통 AJAX ──
async function ajax(data) {
    const body = new URLSearchParams(data);
    const res  = await fetch(AJAX_URL, { method: 'POST', body });
    return res.json();
}

// ── ID 복사 ──
function copyId(id) {
    navigator.clipboard.writeText(String(id)).then(() => {
        alert('ID ' + id + ' 복사됨!');
    });
}

function esc(str) {
    return String(str || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function escHtml(str) { return esc(str); }
</script>
