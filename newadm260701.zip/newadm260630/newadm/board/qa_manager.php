<?php
include_once('../_common.php');
include_once('../_auth_check.php');

$bo_table   = "qa";
$write_table = $g5['write_prefix'] . $bo_table;

if (isset($_GET['del_id'])) {
    $wr_id = (int)$_GET['del_id'];
    sql_query(" DELETE FROM {$write_table} WHERE wr_id = '$wr_id' ");
    alert_toast('상담 내역이 삭제되었습니다.', './qa_manager.php');
}

$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$where  = " WHERE 1=1 ";
if ($search) {
    $s = sql_real_escape_string($search);
    $where .= " AND (wr_name LIKE '%$s%' OR wr_content LIKE '%$s%' OR wr_1 LIKE '%$s%') ";
}

$sql         = " SELECT * FROM {$write_table} $where ORDER BY wr_datetime DESC LIMIT 0, 50 ";
$result      = sql_query($sql);
$total_count = sql_num_rows($result);
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>상담 문의 관리</title>
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Pretendard', 'Apple SD Gothic Neo', sans-serif; background: #f5f6fa; color: #1a1a2e; }
        #admin_wrapper { display: flex; min-height: 100vh; }
        .content_area { flex: 1; padding: 40px; overflow-x: hidden; }

        .page_header { display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 14px; margin-bottom: 28px; }
        .page_title  { font-size: 22px; font-weight: 700; color: #1a1a2e; }

        .search_form { display: flex; gap: 8px; }
        .search_input {
            height: 40px; width: 280px; border: 1px solid #e8eaf0; border-radius: 8px;
            padding: 0 14px; font-size: 13px; background: #fff; transition: all 0.2s;
        }
        .search_input:focus { outline: none; border-color: #4f46e5; box-shadow: 0 0 0 3px rgba(79,70,229,0.1); }
        .search_btn {
            height: 40px; padding: 0 18px; background: #4f46e5; color: #fff;
            border: none; border-radius: 8px; font-size: 13px; font-weight: 700; cursor: pointer; transition: all 0.2s;
        }
        .search_btn:hover { background: #4338ca; }

        .card { background: #fff; border-radius: 12px; box-shadow: 0 2px 12px rgba(0,0,0,0.06); border: 1px solid #e8eaf0; overflow: hidden; }
        .card_meta { padding: 16px 20px; border-bottom: 1px solid #e8eaf0; font-size: 13px; color: #9999bb; }
        .card_meta strong { color: #4f46e5; }

        .table_wrap { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; min-width: 680px; }
        thead th { background: #f5f6fa; padding: 12px 18px; font-size: 12px; font-weight: 700; color: #9999bb; text-align: left; border-bottom: 2px solid #e8eaf0; }
        tbody td { padding: 14px 18px; border-bottom: 1px solid #f5f6fa; vertical-align: middle; font-size: 14px; color: #444466; }
        tbody tr:last-child td { border-bottom: none; }
        tbody tr:hover td { background: #fafafa; }

        .cat_badge { display: inline-block; padding: 3px 10px; background: #ede9fe; color: #4f46e5; border-radius: 20px; font-size: 11px; font-weight: 700; }
        .td_name { font-weight: 700; color: #1a1a2e; }
        .td_phone { font-size: 12px; color: #9999bb; margin-top: 2px; }
        .agree_badge { display: inline-block; margin-top: 4px; padding: 2px 8px; border-radius: 5px; font-size: 11px; font-weight: 700; background: #f5f6fa; color: #9999bb; }
        .agree_badge.on { background: #ede9fe; color: #4f46e5; }
        .preview { max-width: 240px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 13px; color: #9999bb; }
        .td_date { font-size: 12px; color: #9999bb; white-space: nowrap; }

        .td_actions { display: flex; gap: 7px; justify-content: center; }
        .btn_detail { padding: 6px 14px; background: #4f46e5; color: #fff; border: none; border-radius: 7px; font-size: 12px; font-weight: 700; cursor: pointer; transition: all 0.2s; }
        .btn_detail:hover { background: #4338ca; }
        .btn_del_row { padding: 6px 14px; background: #f5f6fa; color: #5c5c7a; border: 1px solid #e8eaf0; border-radius: 7px; font-size: 12px; font-weight: 700; text-decoration: none; transition: all 0.2s; }
        .btn_del_row:hover { background: #fee2e2; color: #dc2626; border-color: #fca5a5; }

        .empty_row td { text-align: center; padding: 56px; color: #9999bb; }

        /* 상세 모달 */
        .modal_overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.55); z-index: 10000; align-items: center; justify-content: center; }
        .modal_overlay.active { display: flex; }
        .modal_box { background: #fff; border-radius: 14px; width: 90%; max-width: 520px; overflow: hidden; animation: modal_in 0.25s ease; }
        @keyframes modal_in { from { transform: translateY(-24px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
        .modal_hd { padding: 22px 24px; border-bottom: 1px solid #e8eaf0; display: flex; align-items: center; justify-content: space-between; }
        .modal_hd h3 { font-size: 17px; font-weight: 700; color: #1a1a2e; }
        .modal_close { background: none; border: none; font-size: 22px; cursor: pointer; color: #9999bb; }
        .modal_close:hover { color: #1a1a2e; }
        .modal_bd { padding: 24px; display: flex; flex-direction: column; gap: 18px; }
        .modal_row label { display: block; font-size: 11px; font-weight: 700; color: #9999bb; margin-bottom: 5px; }
        .modal_row .val { font-size: 15px; font-weight: 600; color: #1a1a2e; }
        .modal_content_box { background: #f5f6fa; border-radius: 9px; padding: 14px 16px; font-size: 14px; line-height: 1.7; color: #444466; white-space: pre-wrap; min-height: 80px; }
        .modal_ft { padding: 16px 24px; border-top: 1px solid #e8eaf0; display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
        .btn_copy { padding: 11px; border-radius: 8px; font-size: 13px; font-weight: 700; cursor: pointer; border: 1px solid #e8eaf0; background: #f5f6fa; color: #1a1a2e; transition: all 0.2s; }
        .btn_copy:hover { background: #e8eaf0; }
        .btn_kakao { padding: 11px; border-radius: 8px; font-size: 13px; font-weight: 700; cursor: pointer; border: none; background: #FEE500; color: #3A1D1D; transition: all 0.2s; }
        .btn_kakao:hover { filter: brightness(0.95); }

        /* 토스트 */
        .toast_msg { position: fixed; bottom: 24px; left: 50%; transform: translateX(-50%); background: #1a1a2e; color: #fff; padding: 11px 24px; border-radius: 50px; font-size: 13px; font-weight: 600; z-index: 99999; opacity: 0; transition: opacity 0.3s; pointer-events: none; }
        .toast_msg.show { opacity: 1; }
    </style>
</head>
<body>
<div id="admin_wrapper">
    <?php include_once('../aside.php'); ?>

    <main class="content_area">
        <div class="page_header">
            <h2 class="page_title">상담 문의 관리</h2>
            <form method="get" class="search_form">
                <input type="text" name="search" class="search_input" placeholder="이름, 연락처, 내용 검색..." value="<?= htmlspecialchars($search) ?>">
                <button type="submit" class="search_btn">검색</button>
            </form>
        </div>

        <div class="card">
            <div class="card_meta">전체 <strong><?= $total_count ?></strong>건</div>
            <div class="table_wrap">
                <table>
                    <thead>
                        <tr>
                            <th>분류</th>
                            <th>문의자 / 연락처</th>
                            <th>문의 내용</th>
                            <th>문의일시</th>
                            <th style="text-align:center;">관리</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i = 0;
                        while ($row = sql_fetch_array($result)) {
                            $i++;
                            $summary = mb_strimwidth(strip_tags($row['wr_content']), 0, 50, '...', 'utf-8');
                            $safe    = htmlspecialchars(json_encode($row, JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8');
                        ?>
                        <tr>
                            <td><span class="cat_badge"><?= htmlspecialchars($row['ca_name'] ?: '문의') ?></span></td>
                            <td>
                                <div class="td_name"><?= htmlspecialchars($row['wr_name']) ?></div>
                                <div class="td_phone"><?= htmlspecialchars($row['wr_1']) ?></div>
                                <span class="agree_badge <?= $row['wr_2'] ? 'on' : '' ?>"><?= $row['wr_2'] ? htmlspecialchars($row['wr_2']) : '미동의' ?></span>
                            </td>
                            <td><div class="preview"><?= htmlspecialchars($summary) ?></div></td>
                            <td class="td_date"><?= substr($row['wr_datetime'], 0, 16) ?></td>
                            <td>
                                <div class="td_actions">
                                    <button type="button" onclick='viewInquiry(<?= $safe ?>)' class="btn_detail">상세보기</button>
                                    <a href="?del_id=<?= $row['wr_id'] ?>" onclick="return confirm('정말 삭제하시겠습니까?')" class="btn_del_row">삭제</a>
                                </div>
                            </td>
                        </tr>
                        <?php } ?>
                        <?php if ($i === 0): ?>
                        <tr class="empty_row"><td colspan="5">문의 내역이 없습니다.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</div>

<!-- 상세보기 모달 -->
<div class="modal_overlay" id="viewModal">
    <div class="modal_box">
        <div class="modal_hd">
            <h3>문의 상세 내용</h3>
            <button class="modal_close" onclick="closeModal()">✕</button>
        </div>
        <div class="modal_bd">
            <div class="modal_row">
                <label>분류 / 이름</label>
                <div class="val"><span id="v_cate"></span> <span id="v_name"></span>님</div>
            </div>
            <div class="modal_row">
                <label>연락처</label>
                <div class="val" id="v_tel"></div>
                <div style="font-size:12px; color:#9999bb; margin-top:4px;" id="v_agree"></div>
            </div>
            <div class="modal_row">
                <label>문의 내용</label>
                <div class="modal_content_box" id="v_content"></div>
            </div>
        </div>
        <div class="modal_ft">
            <button class="btn_copy" onclick="handleSmsClick()">📱 번호 복사 (문자)</button>
            <button class="btn_kakao" onclick="handleKakaoClick()">💬 카톡 상담</button>
        </div>
    </div>
</div>

<div class="toast_msg" id="toast"></div>

<script>
let currentData = null;

function showToast(msg) {
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 2200);
}

function handleSmsClick() {
    if (!currentData) return;
    const num = currentData.wr_1.replace(/[^0-9]/g, '');
    navigator.clipboard.writeText(num).then(() => showToast('전화번호가 복사되었습니다.')).catch(() => showToast('복사 실패'));
}

function handleKakaoClick() {
    if (!currentData) return;
    const num = currentData.wr_1.replace(/[^0-9]/g, '');
    navigator.clipboard.writeText(num).then(() => showToast('전화번호 복사 완료 — 카카오톡에서 검색해주세요.')).catch(() => showToast('복사 실패'));
}

window.viewInquiry = function(data) {
    currentData = data;
    document.getElementById('v_cate').textContent = '[' + (data.ca_name || '문의') + ']';
    document.getElementById('v_name').textContent = data.wr_name;
    document.getElementById('v_tel').textContent  = data.wr_1;
    document.getElementById('v_content').textContent = data.wr_content;
    document.getElementById('v_agree').textContent   = '수신동의: ' + (data.wr_2 || '기록없음');
    document.getElementById('viewModal').classList.add('active');
};

function closeModal() { document.getElementById('viewModal').classList.remove('active'); }
document.getElementById('viewModal').addEventListener('click', function(e) { if (e.target === this) closeModal(); });
</script>
</body>
</html>