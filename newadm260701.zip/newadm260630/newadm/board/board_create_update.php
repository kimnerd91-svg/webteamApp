<?php
include_once('../_common.php');

// 영문 숫자가 아닌 경우 bo_table 필터링
$bo_table = preg_replace('/[^a-z0-9_]/i', '', $_POST['bo_table']);
$bo_subject = sql_real_escape_string(trim($_POST['bo_subject']));

if (!$bo_table || !$bo_subject) {
    alert_toast('게시판 ID와 제목을 정확히 입력해주세요.');
}

// 1. 중복 확인
$row = sql_fetch(" SELECT count(*) as cnt FROM {$g5['board_table']} WHERE bo_table = '$bo_table' ");
if ($row['cnt']) {
    alert_toast('이미 사용 중인 게시판 ID(테이블명)입니다.');
}

// 2. g5_board 설정 테이블에 등록
$sql = " INSERT INTO {$g5['board_table']}
            SET bo_table = '$bo_table',
                bo_subject = '$bo_subject',
                bo_device = 'both',
                bo_skin = 'theme/basic',
                bo_mobile_skin = 'theme/basic',
                bo_use_search = '1',
                bo_list_level = '1',
                bo_read_level = '1',
                bo_write_level = '1',
                bo_reply_level = '1',
                bo_comment_level = '1',
                bo_page_rows = '15',
                bo_mobile_page_rows = '15',
                bo_new = '24',
                bo_hot = '100',
                bo_image_width = '600',
                bo_gallery_cols = '4',
                bo_gallery_width = '174',
                bo_gallery_height = '124',
                bo_table_width = '100',
                bo_insert_content = '',
                bo_use_sns = '0' ";
sql_query($sql);

// 3. 실제 게시글 저장용 테이블(g5_write_XXX) 생성
// 그누보드의 기본 스키마를 가져와서 테이블을 생성합니다.
$sql_create = " CREATE TABLE IF NOT EXISTS `{$g5['write_prefix']}{$bo_table}` (
                  `wr_id` int(11) NOT NULL AUTO_INCREMENT,
                  `wr_num` int(11) NOT NULL DEFAULT '0',
                  `wr_reply` varchar(10) NOT NULL,
                  `wr_parent` int(11) NOT NULL DEFAULT '0',
                  `wr_is_comment` tinyint(4) NOT NULL DEFAULT '0',
                  `wr_comment` int(11) NOT NULL DEFAULT '0',
                  `wr_comment_reply` varchar(5) NOT NULL,
                  `ca_name` varchar(255) NOT NULL,
                  `wr_option` set('html1','html2','secret','mail') NOT NULL,
                  `wr_subject` varchar(255) NOT NULL,
                  `wr_content` text NOT NULL,
                  `wr_link1` text NOT NULL,
                  `wr_link2` text NOT NULL,
                  `wr_link1_hit` int(11) NOT NULL DEFAULT '0',
                  `wr_link2_hit` int(11) NOT NULL DEFAULT '0',
                  `wr_hit` int(11) NOT NULL DEFAULT '0',
                  `wr_good` int(11) NOT NULL DEFAULT '0',
                  `wr_nogood` int(11) NOT NULL DEFAULT '0',
                  `mb_id` varchar(20) NOT NULL,
                  `wr_password` varchar(255) NOT NULL,
                  `wr_name` varchar(255) NOT NULL,
                  `wr_email` varchar(255) NOT NULL,
                  `wr_homepage` varchar(255) NOT NULL,
                  `wr_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
                  `wr_last` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
                  `wr_ip` varchar(255) NOT NULL,
                  `wr_facebook_user` varchar(255) NOT NULL,
                  `wr_twitter_user` varchar(255) NOT NULL,
                  `wr_1` varchar(255) NOT NULL,
                  `wr_2` varchar(255) NOT NULL,
                  `wr_3` varchar(255) NOT NULL,
                  `wr_4` varchar(255) NOT NULL,
                  `wr_5` varchar(255) NOT NULL,
                  `wr_6` varchar(255) NOT NULL,
                  `wr_7` varchar(255) NOT NULL,
                  `wr_8` varchar(255) NOT NULL,
                  `wr_9` varchar(255) NOT NULL,
                  `wr_10` varchar(255) NOT NULL,
                  PRIMARY KEY (`wr_id`),
                  KEY `wr_num_reply_parent` (`wr_num`,`wr_reply`,`wr_parent`),
                  KEY `wr_is_comment` (`wr_is_comment`,`wr_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4; ";
sql_query($sql_create);

// 4. 생성된 게시판으로 바로 글을 쓸 수 있도록 '새글' 테이블 연동 준비는 그누보드가 자동으로 수행함.

alert_toast($bo_subject.' 게시판이 성공적으로 생성되었습니다.', './board_manager.php', "success");
?>