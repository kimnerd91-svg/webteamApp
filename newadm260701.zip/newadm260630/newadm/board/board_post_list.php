<?php
include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/_common.php');
include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/_auth_check.php');
include_once(G5_LIB_PATH . '/thumbnail.lib.php');

// 카테고리 추가 처리
if (isset($_POST['add_category']) && $_POST['bo_table'] && $is_admin) {
    $bo_table = preg_replace('/[^a-z0-9_]/i', '', $_POST['bo_table']);
    $category_name = trim($_POST['category_name']);
    if ($category_name) {
        $category_table = $g5['write_prefix'] . $bo_table . '_category';
        sql_query("CREATE TABLE IF NOT EXISTS `{$category_table}` (`ca_id` int(11) NOT NULL AUTO_INCREMENT, `ca_name` varchar(255) NOT NULL, `ca_order` int(11) DEFAULT 0, `ca_datetime` datetime NOT NULL, PRIMARY KEY (`ca_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", false);
        sql_query("INSERT INTO {$category_table} (ca_name, ca_order, ca_datetime) VALUES ('$category_name', 0, NOW())");
        alert_toast('카테고리가 추가되었습니다.', "./board_post_list.php?bo_table=$bo_table");
        exit;
    }
}

// 카테고리 삭제 처리
if (isset($_GET['delete_category']) && $_GET['bo_table'] && $is_admin) {
    $bo_table = preg_replace('/[^a-z0-9_]/i', '', $_GET['bo_table']);
    $ca_id = (int)$_GET['delete_category'];
    $category_table = $g5['write_prefix'] . $bo_table . '_category';
    sql_query("DELETE FROM {$category_table} WHERE ca_id = '$ca_id'");
    alert_toast('카테고리가 삭제되었습니다.', "./board_post_list.php?bo_table=$bo_table");
    exit;
}

// 게시글 삭제 처리
if (isset($_GET['delete_wr_id']) && $_GET['bo_table']) {
    $delete_wr_id = (int)$_GET['delete_wr_id'];
    $bo_table = preg_replace('/[^a-z0-9_]/i', '', $_GET['bo_table']);
    if ($is_admin) {
        $write_table = $g5['write_prefix'] . $bo_table;
        sql_query(" DELETE FROM $write_table WHERE wr_id = '$delete_wr_id' ");
        sql_query(" DELETE FROM {$g5['board_new_table']} WHERE bo_table = '$bo_table' AND wr_id = '$delete_wr_id' ");
        sql_query(" DELETE FROM {$g5['board_file_table']} WHERE bo_table = '$bo_table' AND wr_id = '$delete_wr_id' ");
        alert_toast('삭제가 완료되었습니다.', "./board_post_list.php?bo_table=$bo_table");
        exit;
    }
}

$bo_table = preg_replace('/[^a-z0-9_]/i', '', $_GET['bo_table']);

// column은 column_admin.php 전용
if ($bo_table === 'column') {
    header('Location: /newadm/column_admin.php');
    exit;
}

$board = sql_fetch(" SELECT * FROM {$g5['board_table']} WHERE bo_table = '$bo_table' ");
if (!$board['bo_table']) alert_toast('게시판이 없습니다.');

// 카테고리 목록
$category_table = $g5['write_prefix'] . $bo_table . '_category';
$categories = [];
$has_category_table = false;
$table_check = sql_query("SHOW TABLES LIKE '{$category_table}'", false);
if ($table_check && sql_num_rows($table_check) > 0) {
    $has_category_table = true;
    $category_result = sql_query("SELECT * FROM {$category_table} ORDER BY ca_order ASC, ca_id ASC", false);
    if ($category_result) while ($cat = sql_fetch_array($category_result)) $categories[] = $cat;
}

$selected_category = isset($_GET['category']) ? (int)$_GET['category'] : 0;

// 게시글 목록
$write_table = $g5['write_prefix'] . $bo_table;
$where = " WHERE wr_is_comment = 0 ";
if ($selected_category > 0) $where .= " AND wr_10 = '$selected_category' ";
$result = sql_query(" SELECT * FROM $write_table $where ORDER BY wr_id DESC LIMIT 0, 12 ");
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($board['bo_subject']) ?> 관리</title>
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Pretendard', 'Apple SD Gothic Neo', sans-serif; background: #f5f6fa; color: #1a1a2e; }
        #admin_wrapper { display: flex; min-height: 100vh; }
        .content_area { flex: 1; padding: 40px; overflow-x: hidden; }

        /* 상단 헤더 */
        .page_header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 28px; }
        .page_title { font-size: 22px; font-weight: 700; color: #1a1a2e; }
        .btn_write {
            padding: 10px 20px; background: #4f46e5; color: #fff; border-radius: 8px;
            font-size: 13px; font-weight: 700; text-decoration: none;
            box-shadow: 0 4px 12px rgba(79,70,229,0.25); transition: all 0.2s;
        }
        .btn_write:hover { background: #4338ca; transform: translateY(-1px); }

        /* 카드 */
        .card { background: #fff; border-radius: 12px; box-shadow: 0 2px 12px rgba(0,0,0,0.07); border: 1px solid #e8eaf0; padding: 24px; margin-bottom: 24px; }
        .card_title { font-size: 15px; font-weight: 700; color: #1a1a2e; margin-bottom: 16px; }

        /* 카테고리 탭 */
        .category_tabs { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 16px; }
        .cat_tab {
            padding: 7px 16px; border-radius: 20px; font-size: 13px; font-weight: 600;
            text-decoration: none; background: #f5f6fa; color: #5c5c7a;
            border: 1px solid #e8eaf0; transition: all 0.2s; display: flex; align-items: center; gap: 6px;
        }
        .cat_tab:hover { background: #ede9fe; color: #4f46e5; border-color: #c4b5fd; }
        .cat_tab.active { background: #4f46e5; color: #fff; border-color: #4f46e5; }
        .cat_tab.active .del_cat { background: rgba(255,255,255,0.25); }
        .del_cat {
            width: 16px; height: 16px; border-radius: 50%; background: rgba(0,0,0,0.1);
            display: flex; align-items: center; justify-content: center;
            font-size: 10px; font-weight: 900; cursor: pointer; transition: all 0.2s;
        }
        .del_cat:hover { background: #ef4444; color: #fff; }

        /* 카테고리 추가 폼 */
        .cat_add_form { display: flex; gap: 10px; padding-top: 16px; border-top: 1px solid #e8eaf0; margin-top: 4px; }
        .cat_input {
            flex: 1; height: 40px; border: 1px solid #e8eaf0; border-radius: 8px;
            padding: 0 14px; font-size: 13px; background: #f5f6fa; transition: all 0.2s;
        }
        .cat_input:focus { outline: none; border-color: #4f46e5; background: #fff; box-shadow: 0 0 0 3px rgba(79,70,229,0.1); }
        .btn_cat_add {
            height: 40px; padding: 0 18px; background: #4f46e5; color: #fff;
            border: none; border-radius: 8px; font-size: 13px; font-weight: 700; cursor: pointer; transition: all 0.2s;
        }
        .btn_cat_add:hover { background: #4338ca; }

        /* 게시글 그리드 */
        .post_grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 20px; }

        .post_card {
            background: #fff; border-radius: 12px; border: 1px solid #e8eaf0;
            box-shadow: 0 2px 12px rgba(0,0,0,0.06); overflow: hidden;
            display: flex; flex-direction: column; transition: all 0.2s;
        }
        .post_card:hover { transform: translateY(-3px); box-shadow: 0 8px 24px rgba(0,0,0,0.1); }

        .thumb_wrap { position: relative; aspect-ratio: 16/9; background: #f5f6fa; overflow: hidden; }
        .thumb_wrap img { width: 100%; height: 100%; object-fit: cover; }

        .btn_del_post {
            position: absolute; top: 10px; right: 10px;
            width: 30px; height: 30px; border-radius: 7px;
            background: rgba(239,68,68,0.85); color: #fff; border: none;
            display: flex; align-items: center; justify-content: center;
            cursor: pointer; font-size: 14px; transition: all 0.2s; z-index: 2;
        }
        .btn_del_post:hover { background: #dc2626; transform: scale(1.1); }

        .post_body { padding: 18px; flex: 1; display: flex; flex-direction: column; gap: 6px; }

        .post_cat_badge {
            display: inline-block; padding: 3px 10px; background: #ede9fe;
            color: #4f46e5; border-radius: 20px; font-size: 11px; font-weight: 700;
        }
        .post_title {
            font-size: 15px; font-weight: 700; color: #1a1a2e;
            display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;
            line-height: 1.4;
        }
        .post_meta { font-size: 12px; color: #9999bb; margin-top: 2px; }

        .post_actions { display: flex; gap: 8px; margin-top: auto; padding-top: 12px; }
        .btn_view, .btn_edit {
            flex: 1; text-align: center; padding: 8px; border-radius: 7px;
            font-size: 13px; font-weight: 700; text-decoration: none; transition: all 0.2s;
        }
        .btn_view { background: #4f46e5; color: #fff; }
        .btn_view:hover { background: #4338ca; }
        .btn_edit { background: #f5f6fa; color: #5c5c7a; border: 1px solid #e8eaf0; }
        .btn_edit:hover { background: #e8eaf0; color: #1a1a2e; }

        .empty_state { text-align: center; padding: 60px 20px; color: #9999bb; font-size: 14px; }
    </style>
</head>
<body>
<div id="admin_wrapper">
    <?php include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/aside.php'); ?>

    <main class="content_area">

        <div class="page_header">
            <h2 class="page_title"><?= htmlspecialchars($board['bo_subject']) ?> 목록</h2>
            <a href="<?= G5_URL ?>/newadm/board/write_direct.php?mode=write&bo_table=<?= $bo_table ?>" target="_blank" class="btn_write">+ 새 글쓰기</a>
        </div>

        <!-- 카테고리 관리 -->
        <div class="card">
            <p class="card_title">카테고리 관리</p>
            <div class="category_tabs">
                <a href="?bo_table=<?= $bo_table ?>" class="cat_tab <?= $selected_category == 0 ? 'active' : '' ?>">전체</a>
                <?php foreach ($categories as $cat): ?>
                <a href="?bo_table=<?= $bo_table ?>&category=<?= $cat['ca_id'] ?>"
                   class="cat_tab <?= $selected_category == $cat['ca_id'] ? 'active' : '' ?>">
                    <?= htmlspecialchars($cat['ca_name']) ?>
                    <span class="del_cat" onclick="event.preventDefault(); delete_category(<?= $cat['ca_id'] ?>)">✕</span>
                </a>
                <?php endforeach; ?>
            </div>

            <form method="post" class="cat_add_form">
                <input type="hidden" name="bo_table" value="<?= $bo_table ?>">
                <input type="text" name="category_name" placeholder="새 카테고리 이름" required class="cat_input">
                <button type="submit" name="add_category" class="btn_cat_add">+ 추가</button>
            </form>
        </div>

        <!-- 게시글 목록 -->
        <?php
        $post_count = 0;
        ob_start();
        while ($row = sql_fetch_array($result)) {
            $post_count++;
            $img = "";
            $content = stripslashes($row['wr_content']);
            preg_match("/<img[^>]*src=[\"']?([^>\"' ]+)[\"']?[^>]*>/i", $content, $m);
            $tmp_img = $m[1] ?? "";
            if ($tmp_img) {
                if (preg_match("/^(http|https):/i", $tmp_img)) $img = $tmp_img;
                else if (substr($tmp_img, 0, 1) == '/') $img = G5_URL . $tmp_img;
                else $img = G5_URL . '/' . $tmp_img;
            }
            if (!$img) {
                $file = sql_fetch(" select bf_file from {$g5['board_file_table']} where bo_table = '$bo_table' and wr_id = '{$row['wr_id']}' and bf_type between 1 and 3 order by bf_no asc limit 1 ");
                if (isset($file['bf_file']) && $file['bf_file']) $img = G5_DATA_URL . '/file/' . $bo_table . '/' . $file['bf_file'];
            }
            if (!$img) $img = 'https://upload.wikimedia.org/wikipedia/commons/1/14/No_Image_Available.jpg';

            $cat_name = '';
            if ($has_category_table && !empty($row['wr_10'])) {
                $cat = sql_fetch("SELECT ca_name FROM {$category_table} WHERE ca_id = '{$row['wr_10']}'", false);
                if ($cat) $cat_name = $cat['ca_name'];
            }
        ?>
        <div class="post_card">
            <div class="thumb_wrap">
                <button class="btn_del_post" onclick="delete_post('<?= $row['wr_id'] ?>')" title="삭제">✕</button>
                <img src="<?= $img ?>" alt="썸네일">
            </div>
            <div class="post_body">
                <?php if ($cat_name): ?><span class="post_cat_badge"><?= htmlspecialchars($cat_name) ?></span><?php endif; ?>
                <p class="post_title"><?= htmlspecialchars(cut_str(strip_tags($row['wr_subject']), 50)) ?></p>
                <p class="post_meta"><?= htmlspecialchars($row['wr_name']) ?> · <?= substr($row['wr_datetime'], 0, 10) ?></p>
                <div class="post_actions">
                    <a href="<?= G5_URL ?>/view_direct.php?bo_table=<?= $bo_table ?>&wr_id=<?= $row['wr_id'] ?>" target="_blank" class="btn_view">보기</a>
                    <a href="<?= G5_URL ?>/newadm/board/write_direct.php?mode=modify&bo_table=<?= $bo_table ?>&wr_id=<?= $row['wr_id'] ?>" target="_blank" class="btn_edit">수정</a>
                </div>
            </div>
        </div>
        <?php } ?>
        <?php $cards_html = ob_get_clean(); ?>

        <?php if ($post_count > 0): ?>
        <div class="post_grid"><?= $cards_html ?></div>
        <?php else: ?>
        <div class="card"><p class="empty_state">등록된 게시글이 없습니다.</p></div>
        <?php endif; ?>

    </main>
</div>

<script>
function delete_post(wr_id) {
    if (confirm('정말 이 게시글을 삭제하시겠습니까?\n삭제된 데이터는 복구할 수 없습니다.')) {
        location.href = "?bo_table=<?= $bo_table ?>&delete_wr_id=" + wr_id;
    }
}
function delete_category(ca_id) {
    if (confirm('이 카테고리를 삭제하시겠습니까?\n카테고리만 삭제되며 게시글은 유지됩니다.')) {
        location.href = "?bo_table=<?= $bo_table ?>&delete_category=" + ca_id;
    }
}
</script>
</body>
</html>