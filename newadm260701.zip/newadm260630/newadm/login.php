<?php
include_once('./_common.php');

// 이미 로그인되어 있으면 메인으로
if ($is_member) {
    goto_url(G5_URL);
}

$url = isset($_REQUEST['url']) ? $_REQUEST['url'] : '';
?>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>로그인</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/setting.css">
    <link rel="stylesheet" href="/css/admin.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f8f9fa; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin:0; }
        .login-card { width: 100%; max-width: 400px; padding: 40px; background: #fff; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); }
        .input-wrapper { position: relative; margin-bottom: 15px; }
        .input-wrapper .material-symbols-outlined { position: absolute; left: 15px; top: 50%; transform: translateY(-50%); color: #adb5bd; }
        .u-input { width: 100%; padding: 12px 12px 12px 45px !important; border: 1px solid #ddd; border-radius: 8px; box-sizing: border-box; }
        .w-100 { width: 100%; }

        @media screen and (max-width: 768px) {
             .login-card {
                max-width: 90vw!important;
            }
        }
    </style>
</head>
<body>
    <div class="login-card">
        <h1 class="text-center fw-900 u-txt-main u-mb-32">LOGIN</h1>

        <form name="flogin" method="post" action="<?php echo G5_BBS_URL ?>/login_check.php">
            <input type="hidden" name="url" value="<?php echo $url ?>">
            
            <div class="input-wrapper">
                <span class="material-symbols-outlined">person</span>
                <input type="text" name="mb_id" class="u-input" placeholder="아이디" required>
            </div>
            <div class="input-wrapper">
                <span class="material-symbols-outlined">lock</span>
                <input type="password" name="mb_password" class="u-input" placeholder="비밀번호" required>
            </div>

            <label class="d-flex align-items-center u-gap-8 u-mb-20" style="cursor:pointer;">
                <input type="checkbox" name="auto_login" value="1">
                <span style="font-size: 14px; color: #666;">자동 로그인</span>
            </label>

            <button type="submit" class="u-btn u-bg-main u-txt-white w-100 u-py-12 rounded-8 fw-700 u-mb-12">로그인</button>
            
            <div class="d-flex justify-content-between">
                <a href="<?php echo G5_BBS_URL ?>/password_lost.php" style="font-size: 13px; color: #999;">비밀번호 찾기</a>
                <a href="<?php echo G5_BBS_URL ?>/register.php" style="font-size: 13px; color: var(--main-color); font-weight: 700;">회원가입</a>
            </div>
            
            <hr style="margin: 20px 0; border: none; border-top: 1px solid #eee;">
            
            <!-- 카카오 로그인 -->
            <a href="https://kauth.kakao.com/oauth/authorize?client_id=94abcbe921b539f87b652f9726923949&redirect_uri=https://kingdomdent.mycafe24.com/plugin/social_login/callback.php&response_type=code"
               class="u-btn w-100 d-flex align-items-center justify-content-center u-py-12 rounded-8 fw-700"
               style="background-color:#FEE500; color:#191919; height:45px; text-decoration:none;">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor" style="margin-right:8px;">
                    <path d="M12 3c-4.97 0-9 3.185-9 7.115 0 2.557 1.707 4.8 4.315 6.091l-1.097 4.024c-.042.155.143.284.271.191l4.755-3.155c.25.023.503.035.756.035 4.97 0 9-3.185 9-7.115S16.97 3 12 3z" />
                </svg>
                카카오 로그인
            </a>
        </form>
    </div>
</body>
</html>