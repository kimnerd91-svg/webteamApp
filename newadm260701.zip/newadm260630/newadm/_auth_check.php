<?php
/**
 * 관리자 인증 체크
 * 모든 관리자 페이지 상단에 include 필요
 */

// ⭐⭐⭐ 최우선: 로그인/셋업 페이지 체크 ⭐⭐⭐
$current_file = basename($_SERVER['PHP_SELF']);
$skip_auth_files = array('login.php', 'setup_admin.php');

if(in_array($current_file, $skip_auth_files)) {
    return; // 인증 체크 없이 즉시 종료
}

// 세션 시작 확인
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// 자동 로그인 쿠키 체크
if(!isset($_SESSION['adm_mb_id']) && isset($_COOKIE['adm_auto_login'])) {
    $token = $_COOKIE['adm_auto_login'];
    
    // 토큰으로 회원 찾기 (mb_memo에 저장된 토큰과 비교)
    $sql = " SELECT * FROM {$g5['member_table']} WHERE mb_memo = '".sql_real_escape_string($token)."' AND mb_level >= 10 ";
    $auto_login_user = sql_fetch($sql);
    
    if($auto_login_user['mb_id']) {
        // 자동 로그인 처리
        $_SESSION['adm_mb_id'] = $auto_login_user['mb_id'];
        $_SESSION['adm_mb_name'] = $auto_login_user['mb_name'];
        $_SESSION['adm_login_time'] = time();
    }
}

// 세션 타임아웃 체크 (24시간)
if(isset($_SESSION['adm_login_time'])) {
    $session_lifetime = 86400; // 24시간 (24 * 60 * 60)
    
    if(time() - $_SESSION['adm_login_time'] > $session_lifetime) {
        // 세션 만료
        unset($_SESSION['adm_mb_id']);
        unset($_SESSION['adm_mb_name']);
        unset($_SESSION['adm_login_time']);
        
        echo "<script>alert('로그인 세션이 만료되었습니다. 다시 로그인해주세요.'); location.href='./login.php';</script>";
        exit;
    } else {
        // 세션 시간 갱신
        $_SESSION['adm_login_time'] = time();
    }
}

// 로그인 체크 - 가장 중요!
// if(!isset($_SESSION['adm_mb_id']) || !$_SESSION['adm_mb_id']) {
//     echo "<script>alert('관리자 로그인이 필요합니다.'); location.href='./login.php';</script>";
//     exit;
// }

// 관리자 권한 체크
// $adm_sql = " SELECT mb_id, mb_name, mb_level FROM {$g5['member_table']} WHERE mb_id = '{$_SESSION['adm_mb_id']}' ";
// $adm_member = sql_fetch($adm_sql);

// if(!$adm_member['mb_id'] || $adm_member['mb_level'] < 10) {
//     unset($_SESSION['adm_mb_id']);
//     unset($_SESSION['adm_mb_name']);
//     unset($_SESSION['adm_login_time']);
    
//     echo "<script>alert('관리자 권한이 없습니다.'); location.href='./login.php';</script>";
//     exit;
// }

// 전역 변수로 관리자 정보 설정
$admin = $adm_member;

// ⭐ 그누보드 세션 및 권한 변수 강제 설정 ⭐
$_SESSION['ss_mb_id'] = $adm_member['mb_id'];
$is_admin = 'super';
$member = $adm_member;
?>