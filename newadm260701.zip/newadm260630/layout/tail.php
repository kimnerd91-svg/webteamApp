<?php
if (!defined('_GNUBOARD_')) exit;

// $conf 쿼리 제거 — head_sub.php의 $dm_conf / 전역변수 사용
$non_covered_file = G5_DATA_PATH . '/content/non_covered.json';
$non_covered = [];
if (file_exists($non_covered_file)) {
    $decoded_data = json_decode(file_get_contents($non_covered_file), true);
    if (is_array($decoded_data)) $non_covered = $decoded_data;
}
?>

<!-- 문의모달 -->
<?php
// ★ 여기서 true/false 로 껐다 켰다 ★
$use_consult_modal = true;   // 모달형 사용 여부 (전 페이지)
$use_consult_bar   = false;  // 막대형 사용 여부 (메인만)

$is_main = (basename($_SERVER['SCRIPT_NAME']) === 'index.php');

if (!empty($use_consult_modal)) include_once(G5_PATH . '/layout/consult_modal.php');
if ($is_main && !empty($use_consult_bar)) include_once(G5_PATH . '/layout/consult_bar.php');
?>

<!-- 푸터 -->
<footer class="footer u-bg-black u-pretendard u-px-0-sm u-pt-60 u-pb-60 u-pb-120-sm u-bt-1 u-bc-gray-700" id="footer02" style="background-color: #000;">
    <div class="u-fluid u-fluid-xl-sm">
        <div class="d-flex flex-column-reverse flex-lg-row justify-content-between align-items-start align-items-lg-center">
            <div>
                <p class="u-txt-white c-fs-18 fw-400 u-lh-16 u-ls-10">
                    <?= htmlspecialchars($dm_conf['cf_company_name'] ?? '') ?> |
                    <?= htmlspecialchars($dm_conf['cf_ceo_name'] ?? '') ?> |
                    <?= htmlspecialchars($dm_conf['cf_business_number'] ?? '') ?> |
                    대표전화 : <?= htmlspecialchars($dm_conf['cf_tel'] ?? '') ?> |
                </p>
                <p class="u-txt-white c-fs-18 fw-400 u-lh-16 u-ls-10">Copyright 2026. <?= htmlspecialchars($dm_conf['cf_company_name'] ?? '') ?> All rights reserved.</p>
                <div class="d-flex justify-content-start align-items-center u-gap-16 u-mt-30 u-txt-white fw-400 c-fs-14">
                    <a href="#" class="u-txt-white fw-400 c-fs-14" data-bs-toggle="modal" data-bs-target="#modalPrivacy">개인정보처리방침</a>
                    <a href="#" class="u-txt-white fw-400 c-fs-14" data-bs-toggle="modal" data-bs-target="#modalNonCovered">비급여 수가표</a>
                </div>
            </div>
            <div class="u-mb-40-sm">
                <img class="w-50-sm" src="/images/logogray.svg" alt="">
            </div>
        </div>
    </div>
</footer>


<!-- 이용약관 모달 -->
<div class="modal fade" id="modalProvision" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content rounded-24 border-0">
            <div class="modal-header u-p-24 u-bd-b-1">
                <p class="modal-title fw-700 t-fs-20">이용약관</p>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body u-p-32 c-fs-15 u-lh-160 u-txt-body" style="max-height: 60vh; overflow-y: auto;">
                <?php echo !empty($dm_conf['cf_terms'])
                    ? nl2br($dm_conf['cf_terms'])
                    : "등록된 이용약관이 없습니다."; ?>
            </div>
        </div>
    </div>
</div>


<!-- 개인정보처리방침 모달 -->
<div class="modal fade" id="modalPrivacy" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content rounded-24 border-0">
            <div class="modal-header u-p-24 u-bd-b-1">
                <p class="modal-title fw-700 t-fs-20 u-txt-main">개인정보처리방침</p>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body u-p-32 c-fs-15 u-lh-160 u-txt-body" style="max-height: 60vh; overflow-y: auto;">
                <?php echo !empty($dm_conf['cf_privacy_policy'])
                    ? nl2br($dm_conf['cf_privacy_policy'])
                    : "등록된 개인정보처리방침이 없습니다."; ?>
            </div>
        </div>
    </div>
</div>


<!-- 비급여 수가표 모달 -->
<div class="modal fade" id="modalNonCovered" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content rounded-16 u-bd-n shadow-soft">
            <div class="modal-header u-bg-soft">
                <p class="modal-title fw-700">비급여 수가표</p>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body u-p-20">
                <table class="u-table" style="width:100%;">
                    <thead class="u-bg-gray-100 u-txt-title">
                        <tr>
                            <th class="u-p-16" style="width:14%;">대분류</th>
                            <th class="u-p-16" style="width:14%;"></th>
                            <th class="u-p-16" style="width:30%;">항목명</th>
                            <th class="u-p-16" style="width:21%;">가격</th>
                            <th class="u-p-16" style="width:21%;">비고</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($non_covered)): ?>
                            <tr>
                                <td colspan="5" class="u-p-40 u-txt-center u-txt-muted">등록된 항목이 없습니다.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($non_covered as $major): ?>
                                <?php
                                $subs     = $major['subcategories'] ?? [];
                                $hasSub   = !empty($subs);
                                $dirItems = $major['items'] ?? [];

                                if (!$hasSub) {
                                    $majorSpan = max(count($dirItems), 1);
                                } else {
                                    $majorSpan = 0;
                                    foreach ($subs as $s) $majorSpan += max(count($s['items'] ?? []), 1);
                                    $majorSpan = max($majorSpan, 1);
                                }
                                $firstMajor = true;
                                ?>

                                <?php if (!$hasSub): ?>
                                    <?php if (empty($dirItems)): ?>
                                        <tr class="u-bd-b-1 u-bc-gray-100">
                                            <td class="u-p-16 fw-700 u-txt-center u-bg-gray-50 bigcate" rowspan="1" style="border-right:1px solid #e9ecef;vertical-align:middle;">
                                                <?= htmlspecialchars($major['category']) ?>
                                            </td>
                                            <td colspan="4" class="u-p-16 u-txt-center u-txt-muted">-</td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($dirItems as $item): ?>
                                            <tr class="u-bd-b-1 u-bc-gray-100">
                                                <?php if ($firstMajor): $firstMajor = false; ?>
                                                    <td class="u-p-16 fw-700 u-txt-center u-bg-gray-50 bigcate" rowspan="<?= $majorSpan ?>" style="border-right:1px solid #e9ecef;vertical-align:middle;">
                                                        <?= htmlspecialchars($major['category']) ?>
                                                    </td>
                                                <?php endif; ?>
                                                <td class="u-p-16 u-txt-center" colspan="2"><?= htmlspecialchars($item['name']) ?></td>
                                                <td class="u-p-16 u-txt-main u-txt-center"><?= htmlspecialchars($item['price']) ?>원</td>
                                                <td class="u-p-16 u-txt-gray-500 u-txt-center"><?= htmlspecialchars($item['note']) ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>

                                <?php else: ?>
                                    <?php foreach ($subs as $sub): ?>
                                        <?php
                                        $items   = $sub['items'] ?? [];
                                        $subSpan = max(count($items), 1);
                                        $firstSub = true;
                                        ?>
                                        <?php if (empty($items)): ?>
                                            <tr class="u-bd-b-1 u-bc-gray-100">
                                                <?php if ($firstMajor): $firstMajor = false; ?>
                                                    <td class="u-p-16 fw-700 u-txt-center u-bg-gray-50 bigcate" rowspan="<?= $majorSpan ?>" style="border-right:1px solid #e9ecef;vertical-align:middle;">
                                                        <?= htmlspecialchars($major['category']) ?>
                                                    </td>
                                                <?php endif; ?>
                                                <td class="u-p-16 fw-600 u-txt-center u-bg-soft smallcate" rowspan="1" style="border-right:1px solid #e9ecef;vertical-align:middle;">
                                                    <?= htmlspecialchars($sub['subcategory']) ?>
                                                </td>
                                                <td colspan="3" class="u-p-16 u-txt-center u-txt-muted">-</td>
                                            </tr>
                                        <?php else: ?>
                                            <?php foreach ($items as $item): ?>
                                                <tr class="u-bd-b-1 u-bc-gray-100">
                                                    <?php if ($firstMajor): $firstMajor = false; ?>
                                                        <td class="u-p-16 fw-700 u-txt-center u-bg-gray-50 bigcate" rowspan="<?= $majorSpan ?>" style="border-right:1px solid #e9ecef;vertical-align:middle;">
                                                            <?= htmlspecialchars($major['category']) ?>
                                                        </td>
                                                    <?php endif; ?>
                                                    <?php if ($firstSub): $firstSub = false; ?>
                                                        <td class="u-p-16 fw-600 u-txt-center u-bg-soft smallcate" rowspan="<?= $subSpan ?>" style="border-right:1px solid #e9ecef;vertical-align:middle;">
                                                            <?= htmlspecialchars($sub['subcategory']) ?>
                                                        </td>
                                                    <?php endif; ?>
                                                    <td class="u-p-16 u-txt-center"><?= htmlspecialchars($item['name']) ?></td>
                                                    <td class="u-p-16 u-txt-main u-txt-center"><?= htmlspecialchars($item['price']) ?>원</td>
                                                    <td class="u-p-16 u-txt-gray-500 u-txt-center"><?= htmlspecialchars($item['note']) ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                <?php endif; ?>

                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<!-- 퀵메뉴 (PC) -->
<div id="quick_menu_pill" class="u-pretendard d-none d-lg-none">
    <div class="quick_menu_pill-container">
        <div class="quick_menu_pill-items active">
            <ul class="u-gap-8 d-flex flex-column ">
                <li>
                    <?php if (!empty($cf_naver_booking)): ?>
                        <a href="<?= htmlspecialchars($cf_naver_booking) ?>" target="_blank" class="qm-bar-fixed-item u-bg-main">
                            <img src="/images/q01.svg" alt="네이버 예약 아이콘" />
                            <div class="qm-bar-fixed-item-text">
                                <p class="fw-500 c-fs-16 u-lh-14 u-ls-10 u-txt-white">네이버 예약</p>
                            </div>
                        </a>
                    <?php endif; ?>
                </li>
                <li>
                    <?php if (!empty($cf_kakao)): ?>
                        <a href="<?= htmlspecialchars($cf_kakao) ?>" target="_blank" class="qm-bar-fixed-item u-bg-main">
                            <img src="/images/q02.svg" alt="카카오톡 아이콘" />
                            <div class="qm-bar-fixed-item-text">
                                <p class="fw-500 c-fs-16 u-lh-14 u-ls-10">카톡 상담</p>
                            </div>
                        </a>
                    <?php endif; ?>
                </li>
                <li>
                    <?php if (!empty($cf_blog)): ?>
                        <a href="<?= htmlspecialchars($cf_blog) ?>" target="_blank" class="qm-bar-fixed-item u-bg-main">
                            <img src="/images/q03.svg" alt="네이버 블로그 아이콘" />
                            <div class="qm-bar-fixed-item-text">
                                <p class="fw-500 c-fs-16 u-lh-14 u-ls-10 u-txt-dark">블로그</p>
                            </div>
                        </a>
                    <?php endif; ?>
                </li>
                <li>
                    <?php if (!empty($cf_instagram)): ?>
                        <a href="<?= htmlspecialchars($cf_instagram) ?>" target="_blank" class="qm-bar-fixed-item u-bg-main">
                            <img src="/images/q04.svg" alt="인스타그램 아이콘" />
                            <div class="qm-bar-fixed-item-text">
                                <p class="fw-500 c-fs-16 u-lh-14 u-ls-10 u-txt-white">인스타그램</p>
                            </div>
                        </a>
                    <?php endif; ?>
                </li>
                <li>
                    <a href="/sub/info.php" target="_blank" class="qm-bar-fixed-item u-bg-main">
                        <img src="/images/q05.svg" alt="맵 핀모양 아이콘" />
                        <div class="qm-bar-fixed-item-text">
                            <p class="fw-500 c-fs-16 u-lh-14 u-ls-10 u-txt-white">오시는 길</p>
                        </div>
                    </a>
                </li>
                <!-- 통합검색 (스마트서치) -->
                <li>
                    <a href="javascript:void(0)" onclick="openSmartSearch()" class="qm-bar-fixed-item u-bg-main">
                        <span class="qm-search-ico" aria-hidden="true">
                            <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round">
                                <circle cx="11" cy="11" r="7"></circle>
                                <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                            </svg>
                        </span>
                        <div class="qm-bar-fixed-item-text">
                            <p class="fw-500 c-fs-16 u-lh-14 u-ls-10 u-txt-white">스마트서치</p>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#inquiryModal" class="qm-bar-fixed-item u-bg-main">
                        <span class="qm-search-ico" aria-hidden="true">
                            <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round">
                                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                            </svg>
                        </span>
                        <div class="qm-bar-fixed-item-text">
                            <p class="fw-500 c-fs-16 u-lh-14 u-ls-10 u-txt-white">빠른상담</p>
                        </div>
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <button type="button" id="qm_pill_toggle" class="qm-pill-toggle u-bg-sub u-mt-16-sm">
        <img class="w-100 w-50-sm" src="/images/quickLogo.svg" alt="치과로고" />
    </button>

    <button type="button" class="u-mt-8 u-mt-16-sm u-txt-gray-400 u-op-5 u-bd-n u-bg-sub" id="scrollTop">
        <span class="material-symbols-outlined c-fs-32 c-fs-44-sm u-txt-white">North</span>
    </button>
</div>

<!-- 퀵메뉴 (PC 2) -->
<div id="quick_menu_box" class="u-pretendard d-none d-lg-flex flex-column " style="z-index: 99;">
    <ul class="qm-box-list d-flex flex-column u-bg-white  u-py-20 u-pt-28 shadow-hard u-round-full">

        <?php if (!empty($cf_naver_booking)): ?>
            <li class="qm-box-item u-py-10 u-px-14">
                <a href="<?= htmlspecialchars($cf_naver_booking) ?>" target="_blank" class="qm-box-link">
                    <span class="qm-box-icon">
                        <img src="/images/qb01.svg" alt="네이버 예약 아이콘">
                    </span>
                    <span class="qm-box-label u-txt-dark c-fs-16 fw-500 u-lh-14 u-ls-20 text-center">네이버 예약</span>
                </a>
            </li>
        <?php endif; ?>

        <?php if (!empty($cf_kakao)): ?>
            <li class="qm-box-item u-py-10 u-px-14">
                <a href="<?= htmlspecialchars($cf_kakao) ?>" target="_blank" class="qm-box-link">
                    <span class="qm-box-icon">
                        <img src="/images/qb02.svg" alt="카카오톡 아이콘">
                    </span>
                    <span class="qm-box-label u-txt-dark c-fs-16 fw-500 u-lh-14 u-ls-20 text-center">카톡 상담</span>
                </a>
            </li>
        <?php endif; ?>

        <?php if (!empty($cf_blog)): ?>
            <li class="qm-box-item u-py-10 u-px-14">
                <a href="<?= htmlspecialchars($cf_blog) ?>" target="_blank" class="qm-box-link">
                    <span class="qm-box-icon">
                        <img src="/images/qb03.svg" alt="공식 블로그 아이콘">
                    </span>
                    <span class="qm-box-label u-txt-dark c-fs-16 fw-500 u-lh-14 u-ls-20 text-center">공식 블로그</span>
                </a>
            </li>
        <?php endif; ?>

        <!--        
            <li class="qm-box-item u-py-10 u-px-14">
                <a href="https://blog.naver.com/bestplant1208" target="_blank" class="qm-box-link">
                    <span class="qm-box-icon">
                        <img src="/images/qb03.svg" alt="닥터 블로그 아이콘">
                    </span>
                    <span class="qm-box-label u-txt-dark c-fs-16 fw-500 u-lh-14 u-ls-20 text-center">닥터 블로그</span>
                </a>
            </li> -->




        <?php if (!empty($cf_instagram)): ?>
            <li class="qm-box-item u-py-10 u-px-14">
                <a href="<?= htmlspecialchars($cf_instagram) ?>" target="_blank" class="qm-box-link">
                    <span class="qm-box-icon">
                        <img src="/images/qb05.svg" alt="인스타그램 아이콘">
                    </span>
                    <span class="qm-box-label u-txt-dark c-fs-16 fw-500 u-lh-14 u-ls-20 text-center">인스타그램</span>
                </a>
            </li>
        <?php endif; ?>

        <li class="qm-box-item u-py-10 u-px-14">
            <a href="/#location" class="qm-box-link">
                <span class="qm-box-icon">
                    <img src="/images/qb_location.svg" alt="오시는 길">
                </span>
                <span class="qm-box-label u-txt-dark c-fs-16 fw-500 u-lh-14 u-ls-20 text-center">오시는 길</span>
            </a>
        </li>

        <!-- 통합검색 (스마트서치) -->
        <li class="qm-box-item u-py-10 u-px-14">
            <a href="javascript:void(0)" onclick="openSmartSearch()" class="qm-box-link">
                <span class="qm-box-icon">
                    <svg viewBox="0 0 24 24" width="40" height="40" fill="none" stroke="var(--main-color)" stroke-width="2" stroke-linecap="round" aria-hidden="true">
                        <circle cx="11" cy="11" r="7"></circle>
                        <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                    </svg>
                </span>
                <span class="qm-box-label u-txt-dark c-fs-16 fw-500 u-lh-14 u-ls-20 text-center">스마트서치</span>
            </a>
        </li>

        <?php if (!empty($cf_tel)): ?>
            <li class="qm-box-item u-py-20 u-px-14 u-pb-28">
                <a href="tel:<?= preg_replace('/[^0-9]/', '', $cf_tel) ?>" class="qm-box-link">
                    <span class="qm-box-icon">
                        <img src="/images/qb06.svg" alt="전화 아이콘">
                    </span>
                    <span class="qm-box-label u-txt-dark c-fs-16 fw-500 u-lh-14 u-ls-20 text-center">전화상담<br><?= htmlspecialchars($cf_tel) ?></span>
                </a>
            </li>
        <?php endif; ?>

    </ul>
    <button type="button" class="u-mt-8 u-mt-16-sm u-txt-gray-400 u-bd-n u-bg-point" id="scrollUp">
        <span class="c-fs-32 c-fs-44-sm u-txt-white w-100 u-p-24">
            <img class="w-100" src="/images/top.svg" alt="">
        </span>
    </button>
</div>

<script>
    (function() {
        const btn = document.getElementById('scrollUp');
        const box = document.getElementById('quick_menu_box');
        if (!btn || !box) return;

        // 초기 상태 — 버튼 숨김, gap 0
        btn.style.opacity = '0';
        btn.style.visibility = 'hidden';
        btn.style.transform = 'translateY(20px)';
        btn.style.transition = 'opacity 0.35s ease, transform 0.35s ease, visibility 0.35s ease';
        box.style.gap = '0px';
        box.style.transition = 'gap 0.35s ease';

        window.addEventListener('scroll', function() {
            if (window.scrollY > 100) {
                // 버튼 등장 + gap 벌어짐
                btn.style.opacity = '1';
                btn.style.visibility = 'visible';
                btn.style.transform = 'translateY(0)';
                box.style.gap = 'var(--sp-15, 24px)';
            } else {
                // 버튼 사라짐 + gap 닫힘
                btn.style.opacity = '0';
                btn.style.visibility = 'hidden';
                btn.style.transform = 'translateY(20px)';
                box.style.gap = '0px';
            }
        });

        btn.addEventListener('click', function() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    })();
</script>


<style>
    #quick_menu_box {
        position: fixed;
        bottom: var(--sp-40);
        max-width: 105px;
        width: 100%;
        right: var(--sp-20);
        min-height: 450px;

    }

    #quick_menu_box .qm-box-item {
        border-bottom: 1px solid var(--gray-300);
    }

    #quick_menu_box .qm-box-item:last-child {
        border: none;
    }

    #quick_menu_box .qm-box-item a {
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        gap: var(--sp-8);

    }

    /* ── 스크롤탑 버튼 ── */
    #quick_menu_box #scrollUp {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 100%;
        max-width: 90px;
        aspect-ratio: 1 / 1;
        border-radius: 50%;
        border: none;
        cursor: pointer;
        margin: 8px auto 0;
        transition: opacity 0.2s, transform 0.2s;
    }

    #quick_menu_box #scrollUp:hover {
        opacity: 0.85;
        transform: translateY(-2px);
    }

    #quick_menu_box #scrollUp .material-symbols-outlined {
        font-size: 22px;
        line-height: 1;
    }

    .qm-box-icon img {
        width: 100%;
        max-width: 40px;
    }
</style>



<!-- 퀵메뉴 (모바일) -->
<div id="quick_menu_mobile" class="u-bg-white d-block d-lg-none position-fixed w-100 u-pretendard" style="bottom: 0; left: 0; z-index: 3">
    <!-- 모바일 통합검색 플로팅 버튼 (바 오른쪽 위에 살짝 띄움) -->
    <button type="button" onclick="openSmartSearch()" id="qm_mo_search" class="u-bg-main u-bd-n position-absolute d-flex align-items-center justify-content-center" aria-label="통합검색">
        <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" aria-hidden="true">
            <circle cx="11" cy="11" r="7"></circle>
            <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
        </svg>
    </button>
    <ul class="d-flex">
        <?php if (!empty($use_consult_modal)): ?>
            <!-- 빠른상담 ON → 전화문의 자리에 상담 버튼 -->
            <li class="flex-1 d-flex align-items-center justify-content-center">
                <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#inquiryModal" class="w-100 h-100 d-flex flex-column justify-content-center align-items-center">
                    <span class="material-symbols-outlined c-fs-32 u-mb-4-sm u-txt-dark">chat_bubble</span>
                    <p class="c-fs-14-sm fw-500 u-lh-15 u-txt-dark text-center">빠른상담</p>
                </a>
            </li>
        <?php else: ?>
            <!-- 빠른상담 OFF → 기존 전화문의 -->
            <li class="flex-1 d-flex align-items-center justify-content-center">
                <a href="tel:<?= preg_replace('/[^0-9]/', '', $cf_tel) ?>" class="w-100 h-100 d-flex flex-column justify-content-center align-items-center">
                    <img style="filter: hue-rotate(0deg);" class="w-max u-mb-4-sm" src="/images/tel.svg" alt="전화 아이콘">
                    <p class="c-fs-14-sm fw-500 u-lh-15 u-txt-dark text-center">전화문의</p>
                </a>
            </li>
        <?php endif; ?>
        <li class="flex-1 u-py-16-sm">
            <?php if (!empty($cf_naver_booking)): ?>
                <a href="<?= htmlspecialchars($cf_naver_booking) ?>" target="_blank" class="w-100 h-100 d-flex flex-column justify-content-center align-items-center">
                    <img class="w-max u-mb-4-sm" src="/images/naverMo.svg" alt="예약 아이콘" />
                    <div class="qm-bar-fixed-item-text">
                        <p class="c-fs-14-sm fw-500 u-lh-15 u-txt-dark text-center">예약</p>
                    </div>
                </a>
            <?php endif; ?>
        </li>
        <li class="flex-1 u-py-16-sm">
            <?php if (!empty($cf_kakao)): ?>
                <a href="<?= htmlspecialchars($cf_kakao) ?>" target="_blank" class="w-100 h-100 d-flex flex-column justify-content-center align-items-center">
                    <img class="w-max u-mb-4-sm" src="/images/kakaomo.svg" alt="카카오톡 아이콘" />
                    <div class="qm-bar-fixed-item-text">
                        <p class="c-fs-14-sm fw-500 u-lh-15 u-txt-dark text-center">카카오톡</p>
                    </div>
                </a>
            <?php endif; ?>
        </li>
        <li class="flex-1 u-py-16-sm">
            <?php if (!empty($cf_blog)): ?>
                <a href="<?= htmlspecialchars($cf_blog) ?>" target="_blank" class="w-100 h-100 d-flex flex-column justify-content-center align-items-center">
                    <img class="w-max u-mb-4-sm" src="/images/blogmo.svg" alt="네이버 블로그 아이콘" />
                    <div class="qm-bar-fixed-item-text">
                        <p class="c-fs-14-sm fw-500 u-lh-15 u-txt-dark text-center">블로그</p>
                    </div>
                </a>
            <?php endif; ?>
        </li>
        <li class="flex-1 u-py-16-sm">
            <button type="button" class="w-100 h-100 d-flex flex-column justify-content-center align-items-center u-bd-n u-bg-transparent" id="scrollTop2">
                <span class="material-symbols-outlined c-fs-32 c-fs-44-sm u-mb-4-sm u-txt-dark">North</span>
                <p class="c-fs-14-sm fw-500 u-lh-15 u-txt-dark text-center">TOP</p>
            </button>
        </li>
    </ul>
</div>

<!-- ════════════════════════════════════════════════
     통합검색(스마트서치) 모달 — 퀵메뉴 검색버튼이 호출
     검색 로직/자동완성은 search_box.php 기조 그대로, /data/search_suggest.json 사용
     색은 setting.css 변수 사용
═══════════════════════════════════════════════════ -->
<div id="ssModal" class="ss-modal" role="dialog" aria-modal="true" aria-label="통합검색" hidden>
    <div class="ss-modal-dim" onclick="closeSmartSearch()"></div>
    <div class="ss-modal-panel u-pretendard">
        <button type="button" class="ss-modal-close" onclick="closeSmartSearch()" aria-label="닫기">
            <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
                <line x1="6" y1="6" x2="18" y2="18"></line>
                <line x1="18" y1="6" x2="6" y2="18"></line>
            </svg>
        </button>
        <p class="ss-modal-lead">무엇이든 검색해보세요</p>
        <div class="ss-modal-searchwrap">
            <form class="ss-modal-form" method="get" action="/sub/smartsearch/search_smart.php" role="search" autocomplete="off">
                <span class="ss-modal-ico" aria-hidden="true">
                    <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
                        <circle cx="11" cy="11" r="7"></circle>
                        <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                    </svg>
                </span>
                <input type="text" id="ssModalInput" name="q" placeholder="증상을 문장으로 적어보세요 (예: 치아가 빠졌어요)" autocomplete="off" aria-label="통합검색" aria-expanded="false" aria-controls="ssModalPreview">
                <button type="submit" aria-label="검색">검색</button>
            </form>
            <div class="ss-modal-preview" id="ssModalPreview" role="listbox" hidden></div>
        </div>
        <p class="ss-modal-hint">예: 임플란트, 잇몸이 부었어요, 치아미백</p>
    </div>
</div>

<style>
    .ss-modal {
        position: fixed;
        inset: 0;
        z-index: var(--z-modal, 1050);
        display: flex;
        align-items: flex-start;
        justify-content: center;
        padding: 14vh 16px 16px
    }

    .ss-modal[hidden] {
        display: none
    }

    .ss-modal-dim {
        position: absolute;
        inset: 0;
        background: rgba(20, 24, 28, .5);
        backdrop-filter: blur(3px);
        -webkit-backdrop-filter: blur(3px)
    }

    .ss-modal-panel {
        position: relative;
        width: 100%;
        max-width: 560px;
        background: var(--white);
        border-radius: 24px;
        box-shadow: 0 30px 80px rgba(0, 0, 0, .28);
        padding: 34px 30px 28px;
        animation: ssPop .22s ease
    }

    @keyframes ssPop {
        from {
            transform: translateY(-12px);
            opacity: 0
        }

        to {
            transform: translateY(0);
            opacity: 1
        }
    }

    .ss-modal-close {
        position: absolute;
        top: 16px;
        right: 16px;
        width: 38px;
        height: 38px;
        border: 0;
        background: var(--gray-100);
        color: var(--gray-700);
        border-radius: 50%;
        display: grid;
        place-items: center;
        cursor: pointer;
        transition: .15s
    }

    .ss-modal-close:hover {
        background: var(--gray-200);
        color: var(--dark)
    }

    .ss-modal-lead {
        font-size: 22px;
        font-weight: 800;
        letter-spacing: -.02em;
        color: var(--dark);
        margin: 0 0 18px
    }

    .ss-modal-searchwrap {
        position: relative
    }

    .ss-modal-form {
        display: flex;
        align-items: center;
        gap: 8px;
        background: var(--light);
        border: 1px solid var(--gray-300);
        border-radius: 999px;
        padding: 6px 6px 6px 16px
    }

    .ss-modal-ico {
        flex: none;
        color: var(--main-color);
        display: grid;
        place-items: center
    }

    .ss-modal-form input {
        flex: 1;
        border: 0;
        outline: 0;
        background: transparent;
        font: inherit;
        font-size: 16px;
        color: var(--dark)
    }

    .ss-modal-form button {
        flex: none;
        border: 0;
        cursor: pointer;
        border-radius: 999px;
        background: var(--main-color);
        color: var(--white);
        font: inherit;
        font-weight: 700;
        padding: 11px 22px
    }

    .ss-modal-form button:hover {
        background: color-mix(in srgb, var(--main-color) 85%, #000)
    }

    .ss-modal-hint {
        margin: 14px 4px 0;
        font-size: 13px;
        color: var(--gray-500)
    }

    .ss-modal-preview {
        position: absolute;
        top: calc(100% + 8px);
        left: 0;
        right: 0;
        background: var(--white);
        border: 1px solid var(--gray-300);
        border-radius: 16px;
        box-shadow: 0 12px 28px rgba(0, 0, 0, .10);
        padding: 6px;
        z-index: 5;
        max-height: 340px;
        overflow-y: auto
    }

    .ss-modal-preview .gsp-item {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 10px 12px;
        border-radius: 10px;
        text-decoration: none;
        color: var(--dark);
        cursor: pointer
    }

    .ss-modal-preview .gsp-item:hover,
    .ss-modal-preview .gsp-item.active {
        background: var(--light2)
    }

    .ss-modal-preview .gsp-ic {
        flex: none;
        width: 26px;
        height: 26px;
        border-radius: 50%;
        display: grid;
        place-items: center;
        font-size: 14px;
        background: var(--light2)
    }

    .ss-modal-preview .gsp-body {
        flex: 1;
        min-width: 0
    }

    .ss-modal-preview .gsp-term {
        font-size: 14.5px;
        font-weight: 700;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis
    }

    .ss-modal-preview .gsp-term mark {
        background: var(--point);
        color: inherit;
        padding: 0 1px;
        border-radius: 2px
    }

    .ss-modal-preview .gsp-name {
        font-size: 12px;
        color: var(--gray-500);
        margin-top: 1px
    }

    .ss-modal-preview .gsp-tag {
        flex: none;
        font-size: 10.5px;
        font-weight: 700;
        padding: 2px 7px;
        border-radius: 999px
    }

    .ss-modal-preview .gsp-tag.kw {
        background: var(--light2);
        color: var(--main-color)
    }

    .ss-modal-preview .gsp-tag.sy {
        background: color-mix(in srgb, var(--point) 30%, #fff);
        color: var(--point)
    }

    .ss-modal-preview .gsp-empty {
        padding: 14px 12px;
        color: var(--gray-500);
        font-size: 13px;
        text-align: center
    }

    /* 모바일 통합검색 플로팅 버튼 — 하단바 오른쪽 위에 살짝 띄움 */
    #qm_mo_search {
        width: 52px;
        height: 52px;
        border-radius: 50%;
        right: 16px;
        top: -26px;
        /* 바 위로 절반 띄움 */
        box-shadow: 0 8px 20px rgba(0, 0, 0, .22);
        z-index: 5;
    }

    #qm_mo_search svg {
        display: block
    }

    #qm_mo_search:active {
        transform: scale(.95)
    }
</style>

<script>
    /* 통합검색 모달 + 자동완성 (search_box.php 로직 이식) */
    (function() {
        var modal = document.getElementById('ssModal');
        var input = document.getElementById('ssModalInput');
        var box = document.getElementById('ssModalPreview');
        if (!modal || !input || !box) return;
        var DATA = null,
            loaded = false,
            activeIdx = -1,
            items = [];

        function norm(s) {
            return (s || '').toLowerCase().replace(/\s+/g, '');
        }

        function canon(s) {
            s = norm(s);
            var map = {
                '아파요': '아파',
                '아픕니다': '아파',
                '아픔': '아파',
                '아프': '아파',
                '쑤셔': '아파',
                '쑤시': '아파',
                '욱신거려': '욱신',
                '욱신거': '욱신',
                '찌릿': '욱신',
                '시려요': '시려',
                '시린': '시려',
                '시림': '시려',
                '시리': '시려'
            };
            for (var k in map) {
                s = s.split(k).join(map[k]);
            }
            return s;
        }
        var SYN_GROUPS = [
            ['이', '이빨', '치아', '어금니', '앞니', '윗니', '아랫니', '잇빨']
        ];

        function smatch(nq, term) {
            var a = canon(nq),
                b = canon(term);
            var ol = a.length;
            for (var g = 0; g < SYN_GROUPS.length; g++) {
                var grp = SYN_GROUPS[g],
                    rep = grp[0];
                for (var i = 1; i < grp.length; i++) {
                    a = a.split(grp[i]).join(rep);
                    b = b.split(grp[i]).join(rep);
                }
            }
            if (b && a.indexOf(b) >= 0) return true;
            if (ol >= 2 && b.indexOf(a) >= 0) return true;
            return false;
        }
        async function load() {
            if (loaded) return;
            loaded = true;
            try {
                var r = await fetch('/data/search_suggest.json', {
                    cache: 'no-cache'
                });
                var j = await r.json();
                DATA = (j && j.items) ? j.items : [];
            } catch (e) {
                DATA = [];
            }
        }

        function escapeHtml(s) {
            return (s || '').replace(/[&<>"]/g, function(c) {
                return {
                    '&': '&amp;',
                    '<': '&lt;',
                    '>': '&gt;',
                    '"': '&quot;'
                } [c];
            });
        }

        function escapeReg(s) {
            return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        }

        function highlight(term, q) {
            var nq = norm(q),
                nt = norm(term),
                pos = nt.indexOf(nq);
            if (nq === '' || pos < 0) return escapeHtml(term);
            return escapeHtml(term).replace(new RegExp('(' + escapeReg(q.trim()) + ')', 'i'), '<mark>$1</mark>');
        }

        function hide() {
            box.hidden = true;
            box.innerHTML = '';
            activeIdx = -1;
            input.setAttribute('aria-expanded', 'false');
        }

        function setActive(n) {
            var els = box.querySelectorAll('.gsp-item');
            if (!els.length) return;
            if (n < 0) n = els.length - 1;
            if (n >= els.length) n = 0;
            els.forEach(function(e) {
                e.classList.remove('active');
            });
            els[n].classList.add('active');
            activeIdx = n;
            els[n].scrollIntoView({
                block: 'nearest'
            });
        }

        function render(q) {
            var nqRaw = norm(q);
            items = [];
            if (nqRaw.length >= 2 && DATA) {
                var seen = {};
                for (var i = 0; i < DATA.length; i++) {
                    var it = DATA[i];
                    if (smatch(q, it.term)) {
                        var key = it.name + '|' + it.term;
                        if (seen[key]) continue;
                        seen[key] = 1;
                        items.push(it);
                        if (items.length >= 8) break;
                    }
                }
            }
            activeIdx = -1;
            if (items.length === 0) {
                var len = norm(q).length;
                if (len === 1) {
                    box.innerHTML = '<div class="gsp-empty">한 글자만으로는 찾기 어려워요. 증상을 문장으로 적어보세요</div>';
                    box.hidden = false;
                    input.setAttribute('aria-expanded', 'true');
                } else if (len >= 2) {
                    box.innerHTML = '<div class="gsp-empty">엔터를 눌러 \'' + escapeHtml(q) + '\' 통합검색</div>';
                    box.hidden = false;
                    input.setAttribute('aria-expanded', 'true');
                } else {
                    hide();
                }
                return;
            }
            var html = '';
            items.forEach(function(it, idx) {
                var tag = it.type === 'symptom' ? '<span class="gsp-tag sy">증상</span>' : '<span class="gsp-tag kw">진료</span>';
                var ic = it.type === 'symptom' ? '💬' : '🦷';
                html += '<a class="gsp-item" data-idx="' + idx + '" href="' + escapeHtml(it.url) + '">' +
                    '<span class="gsp-ic">' + ic + '</span>' +
                    '<span class="gsp-body"><span class="gsp-term">' + highlight(it.term, q) + '</span>' +
                    '<span class="gsp-name">' + escapeHtml(it.name) + '</span></span>' + tag + '</a>';
            });
            box.innerHTML = html;
            box.hidden = false;
            input.setAttribute('aria-expanded', 'true');
        }

        var t = null;
        input.addEventListener('input', function() {
            var q = this.value;
            clearTimeout(t);
            t = setTimeout(function() {
                load().then(function() {
                    render(q);
                });
            }, 80);
        });
        input.addEventListener('keydown', function(e) {
            var els = box.querySelectorAll('.gsp-item');
            if (e.key === 'Escape') {
                closeSmartSearch();
                return;
            }
            if (box.hidden || !els.length) return;
            if (e.key === 'ArrowDown') {
                e.preventDefault();
                setActive(activeIdx + 1);
            } else if (e.key === 'ArrowUp') {
                e.preventDefault();
                setActive(activeIdx - 1);
            } else if (e.key === 'Enter') {
                if (activeIdx >= 0 && els[activeIdx]) {
                    e.preventDefault();
                    location.href = els[activeIdx].getAttribute('href');
                }
            }
        });

        // 전역 오픈/클로즈 (퀵메뉴 버튼 onclick="openSmartSearch()")
        window.openSmartSearch = function() {
            modal.hidden = false;
            document.body.style.overflow = 'hidden';
            load();
            setTimeout(function() {
                input.focus();
            }, 50);
        };
        window.closeSmartSearch = function() {
            modal.hidden = true;
            document.body.style.overflow = '';
            hide();
        };
    })();
</script>


<!-- 다음 지도 스크립트 -->

<script>
    AOS.init();
</script>


<script charset="UTF-8" src="https://ssl.daumcdn.net/dmaps/map_js_init/roughmapLoader.js"></script>
<script charset="UTF-8">
    new daum.roughmap.Lander({
        "timestamp": "1780535837766",
        "key": "2d4rav4thj74",
        "mapWidth": "640",
        "mapHeight": "360"
    }).render();
</script>

<?php include_once(G5_PATH . '/tail_sub.php'); ?>
</body>

</html>
<?php
// ===== 다국어 텍스트 치환 =====
if (isset($lang) && $lang !== 'ko') {
    $html = ob_get_clean();

    $page_key  = ltrim(str_replace(['.php', '/'], ['', '__'], $_SERVER['SCRIPT_NAME']), '__');
    $json_file = $_SERVER['DOCUMENT_ROOT'] . '/lang/' . $page_key . '.json';

    if (file_exists($json_file)) {
        $trans = json_decode(file_get_contents($json_file), true) ?: [];

        // 긴 문자열 먼저 치환 (짧은 문자열이 먼저 치환되면 중복 문제 생김)
        uksort($trans, function ($a, $b) {
            return mb_strlen($b) - mb_strlen($a);
        });

        foreach ($trans as $ko => $langs) {
            $translated = $langs[$lang] ?? '';
            if (!$translated) continue;
            // htmlspecialchars 된 버전 + 원본 버전 둘 다 치환
            $html = str_replace(htmlspecialchars($ko, ENT_QUOTES, 'UTF-8'), htmlspecialchars($translated, ENT_QUOTES, 'UTF-8'), $html);
            $html = str_replace($ko, $translated, $html);
        }
    }

    echo $html;
}
// ================================
?>