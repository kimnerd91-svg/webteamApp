<?php
include_once('./_common.php');
$dm_conf = sql_fetch("SELECT * FROM dm_config WHERE cf_id = 1");
include_once(G5_PATH . '/head_sub.php');

if (isset($dm_conf['cf_add_body_script']) && $dm_conf['cf_add_body_script']) {
    echo stripslashes($dm_conf['cf_add_body_script']) . "\n";
}

$nav_menus = [
    ['label' => '베스트플란트치과', 'href' => '/', 'children' => [
        // ['label' => '진료 철학',   'href' => '/sub/introduce.php'],
        //['label' => '둘러보기',   'href' => '/sub/interior.php'],
        // ['label' => '진료안내 / 오시는 길',   'href' => '/sub/info.php'],
        // ['label' => '임상증례',    'href' => '/sub/column_list.php'],
    ]],
    ['label' => '임플란트', 'href' => '/sub/implant/implant_highLevel.php', 'children' => [
        ['label' => '베스트플란트 임플란트',   'href' => '/sub/implant/implant_highLevel.php'],
        ['label' => '앞니 임플란트', 'href' => '/sub/implant/implant_FT.php'],
        ['label' => '상악동 거상술 & 뼈이식 임플란트',   'href' => '/sub/implant/implant_SL_BA.php'],
        ['label' => '임플란트 재수술', 'href' => '/sub/implant/implant_retreatment.php'],
        ['label' => '전체 임플란트', 'href' => '/sub/implant/implant_FA.php'],
        // ['label' => '임플란트 틀니', 'href' => '/sub/implant/implant_SO.php'],

    ]],
    ['label' => '충치치료', 'href' => '/sub/inlay.php', 'children' => [
        // ['label' => '고난이도 임플란트',   'href' => '/sub/implant/hl_01.php'],
        // ['label' => '네비게이션 임플란트', 'href' => '/sub/implant/navigation_implant.php'],
        // ['label' => '발치즉시 임플란트', 'href' => '/sub/implant/extraction_implant.php'],
        // ['label' => '의식하진정 임플란트', 'href' => '/sub/implant/csd_implant.php'],
    ]],
    ['label' => 'EMS 스케일링', 'href' => '/sub/ems_scale.php', 'children' => [
        // ['label' => '라미네이트', 'href' => '/sub/simmi/simmi_02.php'],
        // ['label' => '레진치료',   'href' => '/sub/simmi/simmi_03.php'],
        // ['label' => '잇몸성형',   'href' => '/sub//simmi/simmi_04.php'],
        // ['label' => '틀니치료',   'href' => '/sub/simmi/simmi_05.php'],
        // ['label' => '치아미백',   'href' => '/sub/simmi/simmi_01.php'],
    ]],
    ['label' => '퍼스널 미백', 'href' => '/sub/whitening.php', 'children' => [
        // ['label' => '충치치료',      'href' => '/sub/natural/natural_01.php'],
        // ['label' => '잇몸치료',      'href' => '/sub/natural/natural_02.php'],
        // ['label' => '신경치료',      'href' => '/sub/natural/natural_03.php'],
    ]],
    // ['label' => '충치치료', 'href' => '#', 'children' => [
    //     // ['label' => '사랑니발치',      'href' => '/sub/general/general_01.php'],
    //     // ['label' => '턱관절 치료',      'href' => '/sub/general/general_03.php'],
    //     // ['label' => '스케일링',      'href' => '/sub/general/general_02.php'],
    // ]],
    // ['label' => '임상증례', 'href' => '/sub/column_list.php', 'children' => [
    //     // ['label' => '소아진료', 'href' => '/sub/children/children_01.php'],
    // ]],
    ['label' => '통증 경감 시스템', 'href' => '/sub/painless_system.php', 'children' => [
        // ['label' => '의식하진정요법',                'href' => '/sub/pain/pain_01.php'],
        // ['label' => '단계별 통증 경감 시스템', 'href' => '/sub/pain/pain_02.php'],
    ]],
    ['label' => '임상케이스', 'href' => '/sub/board/case_list.php', 'children' => [
        // ['label' => '의식하진정요법',                'href' => '/sub/pain/pain_01.php'],
        // ['label' => '단계별 통증 경감 시스템', 'href' => '/sub/pain/pain_02.php'],
    ]],
    ['label' => '닥터 칼럼', 'href' => '/sub/column_list.php', 'children' => [
        // ['label' => '의식하진정요법',                'href' => '/sub/pain/pain_01.php'],
        // ['label' => '단계별 통증 경감 시스템', 'href' => '/sub/pain/pain_02.php'],
    ]],
];

$current_path = strtok($_SERVER['REQUEST_URI'], '?');
?>

<header class="u-pretendard position-fixed u-bg-white z-header w-100" id="site-header">

    <!-- ── PC 헤더 ── -->
    <div class="d-none d-xxl-flex w-100">

        <!-- 헤더 바 -->
        <div class="hd-bar d-flex align-items-stretch position-relative z-two u-bg-white w-100">

            <!-- 로고: 좌측 고정 공백 -->
            <div class="hd-side d-flex align-items-center u-px-32">
                <a href="/">
                    <?php if (!empty($dm_conf['cf_logo'])): ?>
                        <img src="<?= G5_DATA_URL ?>/common/<?= $dm_conf['cf_logo'] ?>" alt="<?= htmlspecialchars($dm_conf['cf_site_name']) ?>" style="max-height:40px; display:block;">
                    <?php else: ?>
                        <!-- 로고 삽입 위치 -->
                    <?php endif; ?>
                </a>
            </div>

            <!-- GNB: flex:1 채움 -->
            <nav class="hd-nav d-flex align-items-center justify-content-center  u-bc-gray-200" style="border-bottom-width: 0.5px!important;">
                <ul class="gnb d-flex align-items-stretch">
                    <?php foreach ($nav_menus as $i => $menu): ?>
                        <?php
                        $children = array_filter($menu['children'] ?? [], fn($c) => !empty($c['label']));
                        $has_children = !empty($children);
                        ?>
                        <li class="gnb-item position-relative<?= $current_path === $menu['href'] ? ' is-page-active' : '' ?>"
                            data-index="<?= $i ?>">
                            <a href="<?= htmlspecialchars($menu['href']) ?>"
                                class="gnb-link c-fs-16 fw-500 u-ls-10 u-txt-dark">
                                <?= htmlspecialchars($menu['label']) ?>
                            </a>
                            <?php if ($has_children): ?>
                            <div class="gnb-submenu u-bg-white u-round-8 shadow-hard" aria-hidden="true">
                                <?php foreach ($children as $child): ?>
                                    <a href="<?= htmlspecialchars($child['href']) ?>"
                                        class="gnb-submenu-link d-block c-fs-16 u-ls-10 u-txt-gray-700 u-py-10 u-px-24 keep-all<?= $current_path === $child['href'] ? ' is-active' : '' ?>">
                                        <?= htmlspecialchars($child['label']) ?>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </nav>

            <!-- 슬라이더 -->
            <div class="hd-side d-flex align-items-center justify-content-end u-px-32 u-bb- u-bc-gray-200">
                <div class="promo-slider">
    <div class="swiper promo-swiper">
        <div class="swiper-wrapper">
            <div class="swiper-slide promo-item">
                <img src="/images/call.svg" alt="" />
                <span class="u-txt-white fw-bold"><a href="tel:<?= htmlspecialchars($cf_tel) ?>" class="u-txt-white fw-bold"><?= htmlspecialchars($cf_tel) ?></a></span>
            </div>
            <div class="swiper-slide promo-item">
                <img src="/images/dk.svg" alt="" /> 단국대학교 치과병원
                <span class="u-txt-white fw-bold">외래교수</span>
            </div>
            <div class="swiper-slide promo-item">
                <img src="/images/medal_1.svg" alt="" />
                <span class="u-txt-white fw-bold"> 대표원장 책임진료</span>
            </div>
            <div class="swiper-slide promo-item">
                <img src="/images/imp.svg" alt="" />
                <span class="u-txt-white fw-bold"> 편안한 무주수 임플란트</span>
            </div>
            <div class="swiper-slide promo-item">
                <img src="/images/heart.svg" alt="" /> 치과 공포증
                <span class="u-txt-white fw-bold"> 통증 경감 시스템</span>
            </div>
            <div class="swiper-slide promo-item">
                <img class="u-mr-4" src="/images/park.svg" alt="" />
                <span class="u-txt-white fw-bold"> <a href="/#location" class="u-txt-white fw-bold">건물 내 넓은 주차 공간</a></span>
            </div>
        </div>
    </div>
</div>
                    <style>
                        /* ===== 기존 거 삭제 ===== */
                        /* .promo-content { animation: slideUp6 ... }  ← 삭제 */
                        /* @keyframes slideUp6 { ... }                 ← 삭제 */

                        /* ===== Swiper 버전 ===== */
                        .promo-slider {
                            width: max-content;
                            height: 2.5vw;
                            background: var(--sub);
                            border-radius: 999px;
                            overflow: hidden;
                        }

                        .promo-swiper {
                            height: 100%;
                            overflow: hidden;
                        }

                        .promo-swiper .swiper-wrapper {
                            height: 100%;
                        }

                        .promo-swiper .swiper-slide {
                            height: 2.5vw;
                            padding: 0 1.0417vw;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            color: #fff;
                            background-color: var(--sub-color);
                            box-sizing: border-box;
                            gap:var(--sp-8);
                        }

                        /* 모바일 — vw 너무 작아서 px 고정 */
                        @media (max-width: 992px) {

                            .promo-slider,
                            .promo-swiper .swiper-slide {
                                height: 36px;
                            }
                        }
                    </style>
                    <script>
             new Swiper('.promo-swiper', {
    direction: 'vertical',
    slidesPerView: 1,
    loop: true,
    //loopAdditionalSlides: 6,
    allowTouchMove: false,
    speed: 600,
    autoplay: { delay: 2000, disableOnInteraction: false },
    observer: true,
    observeParents: true,
});
                    </script>
              

            </div>
        </div>

        <!-- 오버레이 -->
        <!-- <div class="header-overlay" id="headerOverlay"></div> -->
    </div>

    <!-- ── 모바일 헤더 ── -->
    <div class="d-flex d-xxl-none justify-content-between u-bg-white align-items-center u-p-20">
        <a href="<?= G5_URL ?>">
            <?php if (!empty($dm_conf['cf_logo'])): ?>
                <img src="<?= G5_DATA_URL ?>/common/<?= $dm_conf['cf_logo'] ?>" alt="<?= htmlspecialchars($dm_conf['cf_site_name']) ?>" style="max-height:40px; display:block;">
            <?php endif; ?>
        </a>
        <button class="u-bd-n u-bg-white d-flex align-items-center justify-content-center u-txt-dark"
            data-bs-toggle="offcanvas" data-bs-target="#mobileMenuHeader" style="width:36px;height:36px;">
            <span class="material-symbols-outlined c-fs-28">menu</span>
        </button>
    </div>

    <!-- 모바일 Offcanvas -->
    <div class="offcanvas offcanvas-end u-bg-main" id="mobileMenuHeader">
        <div class="offcanvas-header justify-content-end u-py-24 u-px-20">
            <button type="button" class="u-bg-sub u-bd-n d-flex align-items-center justify-content-center"
                style="width:32px;height:32px;" data-bs-dismiss="offcanvas">
                <span class="material-symbols-outlined u-txt-white c-fs-22">close</span>
            </button>
        </div>
        <div class="offcanvas-body u-p-0">
            <ul style="list-style:none;margin:0;padding:0;">
                <?php foreach ($nav_menus as $idx => $menu): ?>
                    <?php $has_children = !empty(array_filter($menu['children'] ?? [], fn($c) => isset($c['label']))); ?>
                    <li>
                        <a href="<?= htmlspecialchars($menu['href']) ?>"
                            class="d-flex justify-content-between align-items-center u-px-30 u-py-14 t-fs-20 fw-400 u-ls-10 u-txt-white"
                            <?= $has_children ? 'data-bs-toggle="collapse" data-bs-target="#mob-sub-' . $idx . '"' : '' ?>>
                            <span><?= htmlspecialchars($menu['label']) ?></span>
                            <?php if ($has_children): ?>
                                <i class="bi bi-chevron-down c-fs-14"></i>
                            <?php endif; ?>
                        </a>
                        <?php if ($has_children): ?>
                            <ul class="collapse" id="mob-sub-<?= $idx ?>"
                                style="list-style:none;margin:0;padding:0;background:var(--sub-color);">
                                <?php foreach ($menu['children'] as $child): ?>
                                    <?php if (!isset($child['label'])) continue; ?>
                                    <li>
                                        <a href="<?= htmlspecialchars($child['href']) ?>"
                                            class="d-flex align-items-center u-px-30 u-py-10 c-fs-18 u-ls-10 u-txt-gray-300">
                                            <?= htmlspecialchars($child['label']) ?>
                                        </a>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>

</header>
<script>
    window.addEventListener('scroll', function() {
        var bar = document.querySelector('.hd-bar');
        if (!bar) return;
        if (window.scrollY > 0) {
            bar.classList.remove('u-bg-transparent');
            bar.classList.add('u-bg-main');
        } else {
            bar.classList.remove('u-bg-main');
            bar.classList.add('u-bg-transparent');
        }
    });
</script>
<script>
    (function() {
        // const overlay = document.getElementById('headerOverlay');
        const gnbItems = document.querySelectorAll('.gnb-item');
        let closeTimer = null;

        function openSubmenu(item) {
            clearTimeout(closeTimer);
            const submenu = item.querySelector('.gnb-submenu');
            if (!submenu) return;

            gnbItems.forEach(el => {
                el.classList.remove('is-open', 'is-hover');
                el.querySelector('.gnb-submenu')?.setAttribute('aria-hidden', 'true');
            });

            item.classList.add('is-open', 'is-hover');
            submenu.setAttribute('aria-hidden', 'false');
            // overlay?.classList.add('is-show');
        }

        function closeSubmenu() {
            closeTimer = setTimeout(() => {
                gnbItems.forEach(el => {
                    el.classList.remove('is-open', 'is-hover');
                    el.querySelector('.gnb-submenu')?.setAttribute('aria-hidden', 'true');
                });
                // overlay?.classList.remove('is-show');
            }, 120);
        }

        gnbItems.forEach(item => {
            const submenu = item.querySelector('.gnb-submenu');
            if (!submenu) return;

            item.addEventListener('mouseenter', () => openSubmenu(item));
            item.addEventListener('mouseleave', closeSubmenu);
            submenu.addEventListener('mouseenter', () => clearTimeout(closeTimer));
            submenu.addEventListener('mouseleave', closeSubmenu);
        });

        // overlay?.addEventListener('click', closeSubmenu);
    })();
</script>

<script>
    if (typeof AOS !== 'undefined' && !window.aosInitialized) {
        AOS.init();
        window.aosInitialized = true;
    }
</script>
<!-- <script>
const header = document.getElementById('site-header');

window.addEventListener('scroll', () => {
    if (window.scrollY === 0) {
        header.style.transform = 'translateY(-100%)';
    } else {
        header.style.transform = 'translateY(0)';
    }
});

if (window.scrollY === 0) header.style.transform = 'translateY(-100%)';
</script> -->

<script>
    const header = document.getElementById('site-header');

    const updateMargin = () => {
        const height = header.offsetHeight;
        document.documentElement.style.setProperty('--header-height', `${height}px`);
    };

    const headerBottom = document.querySelector('#site-header').getBoundingClientRect().bottom;
    document.documentElement.style.setProperty('--header-height', `${headerBottom}px`);

    updateMargin();
    window.addEventListener('resize', updateMargin);
</script>

<div id="google_translate_element" style="display:none;"></div>