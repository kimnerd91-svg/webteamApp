<?php
/* ============================================================
 *  상담 폼 막대형 (#consultBar)
 *  - 스타일: setting.css 유틸 + Bootstrap 우선, 상태/예외만 consult.css
 *  - 제출 → /consult_submit.php → dm_consult (모달과 동일 핸들러 공유)
 *  - consult.css 를 head 또는 공통 css에 1회 로드할 것
 *
 *  ※ 주석 [grep] 표시 클래스 = setting.css 실제 정의값 확인 필요
 *    (촘촘 단위라 없으면 가장 가까운 값으로 교체)
 * ============================================================ */
?>
<!-- consult.css 미로드 사이트라면 아래 1줄 주석 해제
<link rel="stylesheet" href="/consult.css"> -->

<div class="consult-bar u-pretendard u-bg-gray-100 u-round-14 u-px-26 u-py-22" id="consultBar">
  <!-- u-bg-gray-100[grep] / u-round-14[grep] / u-px-26 u-py-22[grep] -->
  <form id="consultBarForm" novalidate>

    <p class="cb-title c-fs-18 fw-800 u-txt-dark u-mb-14">
      상담, <strong class="u-txt-main">간편하고 빠르게.</strong>
    </p>

    <div class="d-flex align-items-end flex-wrap u-gap-22">
      <!-- u-gap-22[grep] -->
      <label class="cb-f flex-1 m-0">
        <input type="text" name="name" class="cb-input w-100 u-txt-dark" placeholder="이름" maxlength="20" required>
      </label>

      <label class="cb-f flex-1 m-0">
        <input type="tel" name="phone" class="cb-input w-100 u-txt-dark" placeholder="연락처 (숫자만)" maxlength="20" required inputmode="numeric">
      </label>

      <label class="cb-f flex-1 m-0">
        <select name="interest" class="cb-input cb-sel w-100 u-txt-dark">
          <option value="">질환명</option>
          <option>임플란트</option>
          <option>교정</option>
          <option>충치·신경</option>
          <option>보철</option>
          <option>심미</option>
          <option>검진·예방</option>
          <option>기타</option>
        </select>
      </label>

      <label class="cb-f flex-1 m-0">
        <select name="inflow" class="cb-input cb-sel w-100 u-txt-dark">
          <option value="">유입경로</option>
          <option>네이버 검색</option>
          <option>블로그</option>
          <option>지인 소개</option>
          <option>간판·길거리</option>
          <option>인스타·유튜브</option>
          <option>기타</option>
        </select>
      </label>

      <button type="submit" class="cb-submit u-btn u-btn-main u-btn-lg u-round-999" id="consultBarSubmit">신청</button>
      <!-- u-round-999[grep] 알약. 없으면 cb-submit 훅에서 border-radius 처리 -->
    </div>

    <div class="d-flex align-items-center flex-wrap u-gap-10 u-mt-12 position-relative">
      <label class="u-check d-flex align-items-center u-gap-8 m-0 c-fs-13 u-txt-gray-500">
        <!-- u-check[grep] / c-fs-13[grep] / u-txt-gray-500[grep] -->
        <input type="checkbox" name="agree_privacy" id="cbAgreePrivacy" required>
        <span>개인정보 수집·이용 동의</span>
      </label>
      <button type="button" class="cb-agree-toggle c-fs-13 u-txt-gray-500" id="cbAgreeToggle">자세히 보기</button>

      <div class="cb-agree-box c-fs-12 u-txt-gray-600 u-bg-white u-bd-1 u-b-solid u-bc-gray-300 u-round-8 u-px-14 u-py-12" id="cbPrivacyBox">
        <!-- u-bg-white / u-txt-gray-600 / c-fs-12 [grep] -->
        · 수집 항목: 이름, 연락처, 상담 내용<br>
        · 수집 목적: 상담 응대 및 예약 안내<br>
        · 보유 기간: 상담 완료 후 6개월 (또는 동의 철회 시 즉시 파기)<br>
        · 동의를 거부할 권리가 있으며, 거부 시 상담 신청이 제한됩니다.
      </div>
    </div>

    <p class="cb-msg c-fs-13 fw-600 u-mt-8" id="consultBarMsg"></p>
  </form>

  <!-- 완료 메시지 (막대 자리에 인라인 교체) -->
  <div class="cb-done d-flex align-items-center u-gap-12 c-fs-15 fw-600 u-txt-dark" id="consultBarDone">
    <span class="cb-done-ico u-btn-main d-flex align-items-center justify-content-center">✓</span>
    <span>상담 신청이 접수되었습니다. 빠른 시일 내 연락드리겠습니다.</span>
  </div>
</div>

<script>
(function () {
    var form = document.getElementById('consultBarForm');
    if (!form || form.dataset.bound) return;
    form.dataset.bound = '1';

    var msg     = document.getElementById('consultBarMsg');
    var btn     = document.getElementById('consultBarSubmit');
    var doneBox = document.getElementById('consultBarDone');

    // 연락처 자동 하이픈
    var phone = form.querySelector('input[name="phone"]');
    if (phone) {
        phone.addEventListener('input', function () {
            var v = this.value.replace(/[^0-9]/g, '').slice(0, 11);
            if (v.length > 7)      this.value = v.replace(/(\d{3})(\d{4})(\d{1,4})/, '$1-$2-$3');
            else if (v.length > 3) this.value = v.replace(/(\d{3})(\d{1,4})/, '$1-$2');
            else                   this.value = v;
        });
    }

    // 약관 토글
    var toggle = document.getElementById('cbAgreeToggle');
    var box    = document.getElementById('cbPrivacyBox');
    if (toggle && box) {
        toggle.addEventListener('click', function () { box.classList.toggle('open'); });
        document.addEventListener('click', function (e) {
            if (!box.contains(e.target) && e.target !== toggle) box.classList.remove('open');
        });
    }

    form.addEventListener('submit', function (e) {
        e.preventDefault();
        msg.textContent = '';

        var name  = form.name.value.trim();
        var tel   = form.phone.value.trim();
        var agree = document.getElementById('cbAgreePrivacy').checked;

        if (!name)  { msg.textContent = '이름을 입력해주세요.'; return; }
        if (tel.replace(/[^0-9]/g, '').length < 9) { msg.textContent = '연락처를 정확히 입력해주세요.'; return; }
        if (!agree) { msg.textContent = '개인정보 수집·이용에 동의해주세요.'; return; }

        btn.disabled = true;
        btn.textContent = '접수 중...';

        fetch('/consult_submit.php', { method: 'POST', body: new FormData(form) })
            .then(function (r) { return r.json(); })
            .then(function (res) {
                if (res.res === 'success') {
                    form.style.display = 'none';
                    doneBox.classList.add('show');
                    form.reset();
                    if (typeof gtag !== 'undefined') {
                        gtag('event', 'generate_lead', { event_category: 'consult', event_label: 'inquiry_bar' });
                    }
                } else {
                    msg.textContent = res.msg || '접수에 실패했습니다.';
                    btn.disabled = false;
                    btn.textContent = '신청';
                }
            })
            .catch(function () {
                msg.textContent = '통신 오류가 발생했습니다. 잠시 후 다시 시도해주세요.';
                btn.disabled = false;
                btn.textContent = '신청';
            });
    });
})();
</script>
