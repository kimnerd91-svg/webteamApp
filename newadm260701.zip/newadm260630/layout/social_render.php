<?php
/* ============================================================
   social_render.php — 소셜 콘텐츠 프론트 출력 헬퍼
   사용법(프론트 페이지에서):
     include_once $_SERVER['DOCUMENT_ROOT'].'/path/social_render.php';
     echo social_render(['mode'=>'grid', 'platform'=>'youtube', 'limit'=>6]);

   옵션:
     mode     : single | grid | list | mixed   (기본 grid)
     platform : youtube | instagram | ''(전체)  (기본 전체)
     ids      : [3,7,9]  특정 id만 (단독 배치 등). 지정 시 platform/limit 무시
     limit    : 개수 (기본 8)
     columns  : grid 열 수 (기본 3)

   ※ 유튜브는 클릭 시 사이트 내 모달에서 재생(임베드). 인스타는 새 탭으로 원문 이동.
   ※ 모달 마크업/스크립트는 페이지당 1회만 출력됨.
   ============================================================ */

if (!function_exists('social_render')) {

function social_render($opt = []) {
    $mode     = $opt['mode'] ?? 'grid';
    $platform = $opt['platform'] ?? '';
    $ids      = $opt['ids'] ?? [];
    $limit    = (int)($opt['limit'] ?? 8);
    $columns  = (int)($opt['columns'] ?? 3);

    // ── 데이터 조회 ──
    $where = "is_visible = 1";
    if (!empty($ids)) {
        $ids = array_map('intval', $ids);
        $where .= " AND id IN (" . implode(',', $ids) . ")";
    } elseif ($platform) {
        $where .= " AND platform = '" . sql_escape_string($platform) . "'";
    }
    $sql = "SELECT * FROM dm_social WHERE {$where} ORDER BY pub_date DESC, id DESC";
    if (empty($ids)) $sql .= " LIMIT {$limit}";

    $rows = [];
    $res = sql_query($sql);
    while ($row = sql_fetch_array($res)) $rows[] = $row;
    if (!$rows) return '';

    // ── 카드 1개 HTML ──
    $card = function($it) {
        $isYT  = ($it['platform'] === 'youtube');
        $thumb = htmlspecialchars($it['thumbnail'] ?? '');
        $title = htmlspecialchars($it['title'] ?: $it['caption'] ?: '');
        $url   = htmlspecialchars($it['url'] ?? '');
        $vid   = htmlspecialchars($it['video_id'] ?? '');

        if ($isYT) {
            // 유튜브 → 사이트 내 모달 재생
            $click = 'onclick="socialPlay(\'' . $vid . '\')"';
            $badge = '<span class="sc-badge sc-yt">▶</span>';
            $tag = 'button';
            $href = '';
        } else {
            // 인스타 → 새 탭 원문
            $click = '';
            $badge = '<span class="sc-badge sc-ig">IG</span>';
            $tag = 'a';
            $href = 'href="' . $url . '" target="_blank" rel="noopener"';
        }
        return "<{$tag} class=\"sc-card\" {$href} {$click} data-reveal=\"up\">"
             . "<div class=\"sc-thumb\"><img src=\"{$thumb}\" alt=\"{$title}\" loading=\"lazy\">{$badge}</div>"
             . "<div class=\"sc-meta\"><p class=\"sc-title\">{$title}</p></div>"
             . "</{$tag}>";
    };

    // ── 모드별 래퍼 ──
    ob_start();

    if ($mode === 'single') {
        // 단독 1개 (첫 항목) — 크게
        $it = $rows[0];
        echo '<div class="sc-single" data-stagger>';
        echo $card($it);
        echo '</div>';

    } elseif ($mode === 'list') {
        echo '<div class="sc-list" data-stagger data-stagger-step="80">';
        foreach ($rows as $it) {
            $isYT = ($it['platform']==='youtube');
            $thumb=htmlspecialchars($it['thumbnail']); $title=htmlspecialchars($it['title']?:$it['caption']);
            $vid=htmlspecialchars($it['video_id']); $url=htmlspecialchars($it['url']);
            $attr = $isYT ? 'onclick="socialPlay(\''.$vid.'\')"' : 'href="'.$url.'" target="_blank" rel="noopener"';
            $tag = $isYT ? 'button' : 'a';
            $badge = $isYT ? '<span class="sc-badge sc-yt">▶</span>' : '<span class="sc-badge sc-ig">IG</span>';
            echo "<{$tag} class=\"sc-list-item\" {$attr} data-reveal=\"left\">"
               . "<div class=\"sc-list-thumb\"><img src=\"{$thumb}\" loading=\"lazy\">{$badge}</div>"
               . "<p class=\"sc-list-title\">{$title}</p></{$tag}>";
        }
        echo '</div>';

    } else { // grid | mixed (둘 다 그리드, mixed는 플랫폼 혼합 그대로)
        echo '<div class="sc-grid" style="--sc-cols:' . max(1,$columns) . ';" data-stagger data-stagger-step="70">';
        foreach ($rows as $it) echo $card($it);
        echo '</div>';
    }

    // ── 모달 + 스타일 (페이지당 1회) ──
    if (!defined('SOCIAL_RENDER_ASSETS')) {
        define('SOCIAL_RENDER_ASSETS', true);
        ?>
        <div id="scModal" class="sc-modal" onclick="socialClose(event)">
          <div class="sc-modal-box">
            <button class="sc-modal-close" onclick="socialClose(event,true)">&times;</button>
            <div class="sc-modal-frame" id="scFrame"></div>
          </div>
        </div>
        <style>
        .sc-grid{display:grid;grid-template-columns:repeat(var(--sc-cols,3),1fr);gap:var(--sp-20,20px);}
        .sc-list{display:flex;flex-direction:column;gap:var(--sp-12,12px);}
        .sc-single{max-width:720px;margin:0 auto;}
        .sc-card{display:block;border:none;background:#fff;border-radius:var(--sp-16,16px);overflow:hidden;
                 box-shadow:0 4px 16px rgba(0,0,0,.08);cursor:pointer;text-align:left;padding:0;
                 transition:transform .2s,box-shadow .2s;width:100%;}
        .sc-card:hover{transform:translateY(-4px);box-shadow:0 10px 28px rgba(0,0,0,.14);}
        .sc-thumb{position:relative;aspect-ratio:16/9;overflow:hidden;}
        .sc-thumb img{width:100%;height:100%;object-fit:cover;display:block;}
        .sc-single .sc-thumb{aspect-ratio:16/9;}
        .sc-badge{position:absolute;top:10px;left:10px;font-size:12px;font-weight:800;padding:4px 9px;border-radius:20px;color:#fff;}
        .sc-yt{background:rgba(220,38,38,.92);}
        .sc-ig{background:linear-gradient(135deg,#f58529,#dd2a7b);}
        .sc-meta{padding:var(--sp-12,12px) var(--sp-16,14px);}
        .sc-title{font-size:14.5px;font-weight:700;color:#1a1a2e;line-height:1.5;word-break:keep-all;
                  display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;margin:0;}
        .sc-list-item{display:flex;align-items:center;gap:14px;background:#fff;border:1px solid #eef0f5;border-radius:12px;
                      padding:10px;cursor:pointer;text-decoration:none;width:100%;text-align:left;}
        .sc-list-item:hover{background:#f8f9ff;}
        .sc-list-thumb{position:relative;flex:0 0 120px;aspect-ratio:16/9;border-radius:8px;overflow:hidden;}
        .sc-list-thumb img{width:100%;height:100%;object-fit:cover;}
        .sc-list-title{font-size:14px;font-weight:600;color:#1a1a2e;margin:0;word-break:keep-all;}
        .sc-modal{display:none;position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,.8);align-items:center;justify-content:center;padding:20px;}
        .sc-modal.open{display:flex;}
        .sc-modal-box{position:relative;width:100%;max-width:900px;}
        .sc-modal-frame{position:relative;aspect-ratio:16/9;background:#000;border-radius:12px;overflow:hidden;}
        .sc-modal-frame iframe{width:100%;height:100%;border:0;}
        .sc-modal-close{position:absolute;top:-44px;right:0;background:none;border:none;color:#fff;font-size:36px;cursor:pointer;line-height:1;}
        @media(max-width:768px){.sc-grid{grid-template-columns:1fr 1fr;}.sc-list-thumb{flex-basis:96px;}}
        @media(max-width:480px){.sc-grid{grid-template-columns:1fr;}}
        </style>
        <script>
        function socialPlay(vid){
          if(!vid)return;
          var f=document.getElementById('scFrame');
          f.innerHTML='<iframe src="https://www.youtube.com/embed/'+vid+'?autoplay=1&rel=0" allow="autoplay;encrypted-media;fullscreen" allowfullscreen></iframe>';
          document.getElementById('scModal').classList.add('open');
          document.body.style.overflow='hidden';
        }
        function socialClose(e,force){
          if(force||e.target.id==='scModal'){
            document.getElementById('scModal').classList.remove('open');
            document.getElementById('scFrame').innerHTML='';
            document.body.style.overflow='';
          }
        }
        document.addEventListener('keydown',function(e){if(e.key==='Escape')socialClose(null,true);});
        </script>
        <?php
    }

    return ob_get_clean();
}

}
