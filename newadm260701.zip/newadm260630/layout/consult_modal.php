<?php
/* ============================================================
 *  상담 폼 모달 (#inquiryModal)
 *  - 전역 include 위치(footer.php 또는 quick.php 하단)에 1회 삽입
 *  - 기존 트리거 버튼 data-bs-target="#inquiryModal" 그대로 작동
 *  - 제출 → /consult_submit.php → dm_consult
 *  - 테마: 사이트 CSS 변수(--main-color, --point) 자동 적용
 * ============================================================ */
?>
<!-- ★ 기본 숨김(d-none). 모달을 쓰는 페이지에서 아래 div의 d-none 제거해야
     트리거 버튼(data-bs-target="#inquiryModal")이 정상 작동함 ★ -->
<div class="modal fade" id="inquiryModal" tabindex="-1" aria-labelledby="inquiryModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content consult-modal u-pretendard">

      <div class="cm-head">
        <div>
          <p class="cm-eyebrow">ONLINE CONSULT</p>
          <h3 class="cm-title" id="inquiryModalLabel">빠른 상담 신청</h3>
        </div>
        <button type="button" class="cm-close" data-bs-dismiss="modal" aria-label="닫기">&times;</button>
      </div>

      <div class="cm-body">
        <form id="consultForm" novalidate>
          <div class="cm-grid">
            <div class="cm-field">
              <label>이름 <span class="cm-req">*</span></label>
              <input type="text" name="name" placeholder="성함" maxlength="20" required>
            </div>
            <div class="cm-field">
              <label>연락처 <span class="cm-req">*</span></label>
              <input type="tel" name="phone" placeholder="010-0000-0000" maxlength="20" required inputmode="numeric">
            </div>
          </div>

          <div class="cm-grid">
            <div class="cm-field">
              <label>관심 진료</label>
              <select name="interest">
                <option value="">선택</option>
                <option>임플란트</option>
                <option>교정</option>
                <option>충치·신경</option>
                <option>보철</option>
                <option>심미</option>
                <option>검진·예방</option>
                <option>기타</option>
              </select>
            </div>
            <div class="cm-field">
              <label>희망 연락 시간대</label>
              <select name="call_time">
                <option value="">선택</option>
                <option>오전 (9~12시)</option>
                <option>오후 (12~18시)</option>
                <option>저녁 (18시 이후)</option>
                <option>아무때나</option>
              </select>
            </div>
          </div>

          <div class="cm-field">
            <label>어떻게 알게 되셨나요?</label>
            <select name="inflow">
              <option value="">선택</option>
              <option>네이버 검색</option>
              <option>블로그</option>
              <option>지인 소개</option>
              <option>간판·길거리</option>
              <option>인스타·유튜브</option>
              <option>기타</option>
            </select>
          </div>

          <div class="cm-field">
            <label>상담 내용</label>
            <textarea name="content" rows="3" placeholder="불편한 점이나 궁금한 점을 자유롭게 적어주세요."></textarea>
          </div>

          <!-- 개인정보 동의 -->
          <div class="cm-agree">
            <label class="cm-check">
              <input type="checkbox" name="agree_privacy" id="agreePrivacy" required>
              <span><strong>[필수]</strong> 개인정보 수집·이용 동의</span>
              <button type="button" class="cm-agree-toggle" onclick="document.getElementById('privacyBox').classList.toggle('open')">약관 보기</button>
            </label>
            <div class="cm-agree-box" id="privacyBox">
              · 수집 항목: 이름, 연락처, 상담 내용<br>
              · 수집 목적: 상담 응대 및 예약 안내<br>
              · 보유 기간: 상담 완료 후 6개월 (또는 동의 철회 시 즉시 파기)<br>
              · 동의를 거부할 권리가 있으며, 거부 시 상담 신청이 제한됩니다.
            </div>
            <label class="cm-check">
              <input type="checkbox" name="agree_marketing">
              <span>[선택] 안내·이벤트 문자 수신 동의</span>
            </label>
          </div>

          <p class="cm-msg" id="consultMsg"></p>
          <button type="submit" class="cm-submit" id="consultSubmit">상담 신청하기</button>
        </form>

        <!-- 완료 화면 -->
        <div class="cm-done" id="consultDone">
          <div class="cm-done-ico">✓</div>
          <h4>상담 신청이 접수되었습니다</h4>
          <p>빠른 시일 내 연락드리겠습니다. 감사합니다.</p>
          <button type="button" class="cm-submit" data-bs-dismiss="modal">확인</button>
        </div>
      </div>

    </div>
  </div>
</div>

<style>
.consult-modal { border: none; border-radius: 18px; overflow: hidden; box-shadow: 0 24px 60px rgba(0,0,0,.25); }
.consult-modal * { box-sizing: border-box; }
.consult-modal .cm-head {
    background: var(--main-color, #25456b); color: #fff;
    padding: 22px 26px; display: flex; align-items: flex-start; justify-content: space-between;
}
.consult-modal .cm-eyebrow { font-size: 11px; letter-spacing: .14em; font-weight: 700; color: var(--point, #FABE00); margin: 0 0 5px; }
.consult-modal .cm-title { font-size: 21px; font-weight: 800; margin: 0; line-height: 1.2; }
.consult-modal .cm-close { background: none; border: none; color: #fff; font-size: 28px; line-height: 1; cursor: pointer; opacity: .8; }
.consult-modal .cm-close:hover { opacity: 1; }

.consult-modal .cm-body { padding: 24px 26px 26px; max-height: 72vh; overflow-y: auto; }
.consult-modal .cm-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
.consult-modal .cm-field { margin-bottom: 14px; }
.consult-modal .cm-field label { display: block; font-size: 13px; font-weight: 700; color: #333; margin-bottom: 6px; }
.consult-modal .cm-req { color: #e0382d; }
.consult-modal .cm-field input,
.consult-modal .cm-field select,
.consult-modal .cm-field textarea {
    width: 100%; border: 1.5px solid #e4e7ee; border-radius: 10px;
    padding: 12px 14px; font-size: 14px; font-family: inherit; color: #1a1a2e; background: #fff;
    transition: border-color .15s, box-shadow .15s;
}
.consult-modal .cm-field textarea { resize: vertical; line-height: 1.6; }
.consult-modal .cm-field input:focus,
.consult-modal .cm-field select:focus,
.consult-modal .cm-field textarea:focus {
    outline: none; border-color: var(--main-color, #25456b);
    box-shadow: 0 0 0 3px color-mix(in srgb, var(--main-color, #25456b) 14%, transparent);
}

.consult-modal .cm-agree { background: #f7f8fb; border-radius: 12px; padding: 14px 16px; margin: 4px 0 18px; }
.consult-modal .cm-check { display: flex; align-items: center; gap: 8px; font-size: 13px; color: #444; cursor: pointer; margin: 0; font-weight: 400; }
.consult-modal .cm-check + .cm-check { margin-top: 10px; }
.consult-modal .cm-check input { width: 17px; height: 17px; accent-color: var(--main-color, #25456b); flex-shrink: 0; }
.consult-modal .cm-check strong { color: var(--main-color, #25456b); }
.consult-modal .cm-agree-toggle { margin-left: auto; background: none; border: none; font-size: 12px; color: #8a90a2; text-decoration: underline; cursor: pointer; padding: 0; }
.consult-modal .cm-agree-box { display: none; margin: 10px 0 4px; padding: 12px 14px; background: #fff; border: 1px solid #e4e7ee; border-radius: 8px; font-size: 12px; color: #667; line-height: 1.85; }
.consult-modal .cm-agree-box.open { display: block; }

.consult-modal .cm-msg { min-height: 18px; margin: 0 0 10px; font-size: 13px; font-weight: 600; color: #e0382d; text-align: center; }
.consult-modal .cm-submit {
    width: 100%; border: none; border-radius: 12px; padding: 15px;
    background: var(--main-color, #25456b); color: #fff; font-size: 16px; font-weight: 800;
    cursor: pointer; transition: filter .15s, transform .05s; font-family: inherit;
}
.consult-modal .cm-submit:hover { filter: brightness(1.08); }
.consult-modal .cm-submit:active { transform: translateY(1px); }
.consult-modal .cm-submit:disabled { opacity: .6; cursor: not-allowed; }

.consult-modal .cm-done { display: none; text-align: center; padding: 30px 10px 16px; }
.consult-modal .cm-done.show { display: block; }
.consult-modal .cm-done-ico {
    width: 64px; height: 64px; margin: 0 auto 18px; border-radius: 50%;
    background: var(--main-color, #25456b); color: #fff; font-size: 34px; font-weight: 700;
    display: flex; align-items: center; justify-content: center;
}
.consult-modal .cm-done h4 { font-size: 19px; font-weight: 800; color: #1a1a2e; margin: 0 0 8px; }
.consult-modal .cm-done p { font-size: 14px; color: #777; margin: 0 0 22px; line-height: 1.6; }

@media (max-width: 576px) {
    .consult-modal .cm-grid { grid-template-columns: 1fr; gap: 0; }
    .consult-modal .cm-title { font-size: 19px; }
}
</style>

<script>
(function () {
    var form = document.getElementById('consultForm');
    if (!form || form.dataset.bound) return;
    form.dataset.bound = '1';

    var msg     = document.getElementById('consultMsg');
    var btn     = document.getElementById('consultSubmit');
    var doneBox = document.getElementById('consultDone');

    // 연락처 자동 하이픈
    var phone = form.querySelector('input[name="phone"]');
    if (phone) {
        phone.addEventListener('input', function () {
            var v = this.value.replace(/[^0-9]/g, '').slice(0, 11);
            if (v.length > 7)      this.value = v.replace(/(\d{3})(\d{4})(\d{1,4})/, '$1-$2-$3');
            else if (v.length > 3) this.value = v.replace(/(\d{3})(\d{1,4})/, '$1-$2');
            else                   this.value = v;
        });
    }

    form.addEventListener('submit', function (e) {
        e.preventDefault();
        msg.textContent = '';

        var name  = form.name.value.trim();
        var tel   = form.phone.value.trim();
        var agree = document.getElementById('agreePrivacy').checked;

        if (!name)  { msg.textContent = '이름을 입력해주세요.'; return; }
        if (tel.replace(/[^0-9]/g, '').length < 9) { msg.textContent = '연락처를 정확히 입력해주세요.'; return; }
        if (!agree) { msg.textContent = '개인정보 수집·이용에 동의해주세요.'; return; }

        btn.disabled = true;
        btn.textContent = '접수 중...';

        fetch('/consult_submit.php', { method: 'POST', body: new FormData(form) })
            .then(function (r) { return r.json(); })
            .then(function (res) {
                if (res.res === 'success') {
                    form.style.display = 'none';
                    doneBox.classList.add('show');
                    form.reset();
                    if (typeof gtag !== 'undefined') {
                        gtag('event', 'generate_lead', { event_category: 'consult', event_label: 'inquiry_form' });
                    }
                } else {
                    msg.textContent = res.msg || '접수에 실패했습니다.';
                    btn.disabled = false;
                    btn.textContent = '상담 신청하기';
                }
            })
            .catch(function () {
                msg.textContent = '통신 오류가 발생했습니다. 잠시 후 다시 시도해주세요.';
                btn.disabled = false;
                btn.textContent = '상담 신청하기';
            });
    });

    // 모달 닫힐 때 폼 초기화 (다음 오픈 대비)
    var modalEl = document.getElementById('inquiryModal');
    if (modalEl) {
        modalEl.addEventListener('hidden.bs.modal', function () {
            form.style.display = '';
            doneBox.classList.remove('show');
            msg.textContent = '';
            btn.disabled = false;
            btn.textContent = '상담 신청하기';
            var pb = document.getElementById('privacyBox');
            if (pb) pb.classList.remove('open');
        });
    }
})();
</script>
