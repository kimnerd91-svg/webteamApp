<?php
// =============================================================
// parallax.php — 패럴럭스 섹션 프론트 출력 (신버전)
// 좌우 지그재그 레이아웃 + library.js 효과(data-reveal / data-parallax).
// 기존 dm_parallax_items 테이블 그대로 사용 (number/title/description/image).
// ※ library.js / library.css 가 로드돼 있어야 효과가 동작. (head_sub [library] 주석 해제)
// =============================================================
$parallax_table = 'dm_parallax_items';

$chk = sql_query("SHOW TABLES LIKE '{$parallax_table}'");
if (!$chk || sql_num_rows($chk) == 0) return;

$section_title = '특별한 진료 시스템';
$st_row = sql_fetch("SELECT section_title FROM {$parallax_table} LIMIT 1");
if ($st_row && !empty($st_row['section_title'])) $section_title = $st_row['section_title'];

$items = [];
$res = sql_query("SELECT * FROM {$parallax_table} WHERE is_visible = 1 ORDER BY display_order ASC, id ASC");
while ($row = sql_fetch_array($res)) $items[] = $row;
if (!$items) return;
?>
<section class="zz-section has-grain" aria-label="<?= htmlspecialchars($section_title) ?>">
  <div class="zz-inner">
    <header class="zz-head" data-reveal="up">
      <h2 class="zz-title"><?= htmlspecialchars($section_title) ?></h2>
    </header>

    <div class="zz-list">
      <?php foreach ($items as $i => $it):
        $num   = trim($it['number'] ?? '');
        $title = htmlspecialchars($it['title'] ?? '');
        $desc  = nl2br(htmlspecialchars($it['description'] ?? ''));
        $img   = $it['image'] ?? '';
        $flip  = ($i % 2 === 1); // 홀수 행은 좌우 반전(지그재그)
      ?>
      <article class="zz-row<?= $flip ? ' zz-flip' : '' ?>">
        <!-- 이미지: 스크롤 시 살짝 패럴럭스 -->
        <div class="zz-media" data-reveal="<?= $flip ? 'right' : 'left' ?>">
          <?php if ($img): ?>
            <div class="zz-media-inner" data-parallax="18">
              <img src="<?= htmlspecialchars($img) ?>" alt="<?= $title ?>" loading="lazy">
            </div>
          <?php else: ?>
            <div class="zz-media-inner zz-noimg" data-parallax="18"><span><?= $num ?: ($i+1) ?></span></div>
          <?php endif; ?>
        </div>

        <!-- 텍스트: 자식 순차 등장 -->
        <div class="zz-text" data-reveal="<?= $flip ? 'left' : 'right' ?>" data-stagger data-stagger-step="90">
          <?php if ($num): ?><span class="zz-num"><?= htmlspecialchars($num) ?></span><?php endif; ?>
          <h3 class="zz-row-title"><?= $title ?></h3>
          <p class="zz-desc"><?= $desc ?></p>
        </div>
      </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<style>
/* 좌우 지그재그 패럴럭스 — setting.css 토큰 사용, library.js가 reveal/parallax 구동 */
.zz-section { padding: var(--sp-80, 80px) 0; overflow: hidden; }
.zz-inner { max-width: 1200px; margin: 0 auto; padding: 0 var(--sp-20); }
.zz-head { text-align: center; margin-bottom: var(--sp-48, 56px); }
.zz-title { font-size: clamp(28px, 5vw, 52px); font-weight: 800; color: var(--main-color, #25456b); letter-spacing: -0.02em; }

.zz-list { display: flex; flex-direction: column; gap: var(--sp-64, 80px); }
.zz-row { display: grid; grid-template-columns: 1fr 1fr; align-items: center; gap: var(--sp-48, 56px); }
.zz-row.zz-flip .zz-media { order: 2; }
.zz-row.zz-flip .zz-text  { order: 1; }

.zz-media { border-radius: var(--sp-24, 24px); overflow: hidden; }
.zz-media-inner { width: 100%; aspect-ratio: 4 / 3; will-change: transform; }
.zz-media-inner img { width: 100%; height: 100%; object-fit: cover; display: block; transform: scale(1.06); }
.zz-noimg { display: flex; align-items: center; justify-content: center; background: linear-gradient(135deg, var(--main-color, #25456b), #3a6ea5); }
.zz-noimg span { font-size: clamp(48px, 10vw, 120px); font-weight: 900; color: rgba(255,255,255,0.85); }

.zz-text { padding: var(--sp-12); }
.zz-num { display: inline-block; font-size: clamp(28px, 4vw, 44px); font-weight: 900;
          color: var(--point, #d7ac7a); line-height: 1; margin-bottom: var(--sp-12); }
.zz-row-title { font-size: clamp(20px, 3vw, 30px); font-weight: 800; color: #1a1a2e; margin-bottom: var(--sp-16); word-break: keep-all; }
.zz-desc { font-size: clamp(14px, 1.6vw, 16.5px); line-height: 1.85; color: #4b5563; word-break: keep-all; }

@media (max-width: 768px) {
  .zz-row, .zz-row.zz-flip .zz-media, .zz-row.zz-flip .zz-text { grid-template-columns: 1fr; order: 0; }
  .zz-row { gap: var(--sp-20); }
  .zz-list { gap: var(--sp-40, 48px); }
}
</style>
