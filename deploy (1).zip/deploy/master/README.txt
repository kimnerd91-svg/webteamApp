이 폴더 밑에 배포할 실제 파일을 넣으세요.
현재 deploy.php가 기대하는 경로:
  master/board/column_admin.php
  master/hospital/place_manager.php
  master/board/schema_migrate.php   ← 이미 만들어져 있음, DB 컬럼 체크용

schema_migrate.php는 뭐하는 파일?
  - 사이트 파일들을 최신 버전으로 덮어써도, 그 사이트 DB가 옛날 스키마라
    새 코드가 필요로 하는 컬럼이 없을 수 있음
  - deploy.php가 파일 업로드 직후 이 스크립트를 자동으로 한 번 호출해서
    필요한 컬럼이 있는지 체크하고 없으면 자동으로 ALTER TABLE로 추가함
  - 컬럼 추가만 처리함. 컬럼명이 바뀐 경우(rename)나 삭제된 경우는
    별도로 확인 필요 — 걱정되면 먼저 audit 스크립트로 전체 사이트
    dm_config 컬럼 목록을 스캔해서 비교부터 하는 게 안전함
  - 새 기능 만들 때 컬럼이 하나 더 필요해지면
    schema_migrate.php 안에 ensure_column() 한 줄만 추가하면 됨
    (다른 파일들은 안 건드려도 됨)

새 파일을 배포 대상에 추가하려면:
  1. master/ 밑 알맞은 위치에 파일 업로드
  2. deploy.php 안의 $files 배열에 한 줄 추가

sites.php 채울 때 주의:
  - FTP 접속 host와 실제 사이트 도메인이 다르면 반드시 'domain' 필드도 채울 것
    (안 채우면 schema_migrate.php 자동 호출이 엉뚱한 주소로 나감)
