<?php
/* ─────────────────────────────────────────────
   schema_migrate.php
   newadm 전체 페이지가 필요로 하는 DB 컬럼을 한 곳에 모아서 체크/생성.
   deploy.php가 파일 배포 직후 자동으로 이 파일을 호출함
   (수동으로도 https://도메인/newadm/board/schema_migrate.php?token=... 로 실행 가능)

   새 기능 추가로 컬럼이 하나 더 필요해지면:
     이 파일 맨 아래 "여기에 컬럼 요구사항 추가" 구역에 ensure_column() 한 줄만 추가
   ───────────────────────────────────────────── */

$TOKEN = 'kimnerd91'; // deploy.php의 $TOKEN과 반드시 동일해야 함

if (($_GET['token'] ?? '') !== $TOKEN) {
    http_response_code(403);
    exit('forbidden');
}

header('Content-Type: text/plain; charset=utf-8');

/* ─────────────────────────────────────────────
   기존 newadm 부트스트랩(DB 연결) 불러오기
   실제 경로/파일명이 다르면 이 줄만 환경에 맞게 수정
   (sql_query, sql_fetch_array 등 그누보드 DB 함수를 쓸 수 있어야 함)
───────────────────────────────────────────── */
include_once(__DIR__ . '/../../_common.php');

/**
 * 테이블에 컬럼이 없으면 추가. 이미 있으면 아무것도 안 함 (몇 번 실행해도 안전).
 */
function ensure_column(string $table, string $column, string $definition): void
{
    $check = sql_query("SHOW COLUMNS FROM {$table} LIKE '{$column}'", false);
    if (!$check || mysqli_num_rows($check) === 0) {
        $ok = sql_query("ALTER TABLE {$table} ADD COLUMN {$column} {$definition}", false);
        echo $ok
            ? "  + added {$table}.{$column}\n"
            : "  ! FAILED to add {$table}.{$column} (테이블명 확인 필요)\n";
    } else {
        echo "  = {$table}.{$column} 이미 존재\n";
    }
}

/**
 * 테이블 자체가 없으면 생성. 이미 있으면 아무것도 안 함.
 */
function ensure_table(string $table, string $createSql): void
{
    $check = sql_query("SHOW TABLES LIKE '{$table}'", false);
    if (!$check || mysqli_num_rows($check) === 0) {
        $ok = sql_query($createSql, false);
        echo $ok ? "  + created table {$table}\n" : "  ! FAILED to create table {$table}\n";
    } else {
        echo "  = table {$table} 이미 존재\n";
    }
}

echo "======================================\n";
echo "schema migrate 시작 (" . date('Y-m-d H:i:s') . ")\n";
echo "======================================\n";

/* ─────────────────────────────────────────────
   여기에 컬럼/테이블 요구사항 추가
   (예시로 하나 넣어둠 — 실제 요구사항으로 교체/추가)
───────────────────────────────────────────── */
ensure_column('dm_config', 'cf_naver_place', "VARCHAR(255) DEFAULT ''");

// ensure_column('테이블명', '컬럼명', "타입 DEFAULT '기본값'");
// ensure_table('새테이블명', "CREATE TABLE 새테이블명 (...) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

echo "======================================\n";
echo "완료\n";
echo "======================================\n";
