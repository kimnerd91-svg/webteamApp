<?php
/* ─────────────────────────────────────────────
   병원별 FTP 접속정보
   노션에 정리된 정보를 이 형식으로 옮겨서 채우세요.
   이 파일은 절대 웹에서 직접 열리면 안 됩니다 (.htaccess로 차단됨, 유지할 것)

   각 항목:
     name     - 식별용 이름 (아무 값이나, 로그에 표시됨)
     host     - FTP 호스트 주소
     port     - FTP 포트 (보통 21, 생략 가능)
     user     - FTP 계정
     pass     - FTP 비밀번호
     basePath - newadm이 설치된 절대경로 (사이트마다 다를 수 있음, 예: /newadm)
     domain   - (선택) 실제 사이트 공개 도메인. FTP 호스트와 다르면 반드시 채울 것
                (schema_migrate.php 자동 호출 시 이 도메인으로 접속함)
───────────────────────────────────────────── */

return [
    // 예시 — 먼저 이 형태로 2~3곳만 채워서 테스트 후 전체 추가
    // [
    //     'name'     => 'A병원',
    //     'host'     => 'ftp.example.com',
    //     'port'     => 21,
    //     'user'     => 'ftp_user1',
    //     'pass'     => 'ftp_pass1',
    //     'basePath' => '/newadm',
    //     'domain'   => 'a-hospital.com',
    // ],
    // [
    //     'name'     => 'B병원',
    //     'host'     => 'ftp.example2.com',
    //     'port'     => 21,
    //     'user'     => 'ftp_user2',
    //     'pass'     => 'ftp_pass2',
    //     'basePath' => '/newadm',
    //     'domain'   => 'b-hospital.com',
    // ],
];
