<?php
/* ─────────────────────────────────────────────
   newadm 공통 파일 배포 스크립트
   사용법: 브라우저에서
     https://medintemplate.mycafe24.com/deploy/deploy.php?token=kimnerd91
   치면 master/ 안의 파일들을 sites.php에 등록된 모든 병원 FTP로 업로드함.
───────────────────────────────────────────── */

$TOKEN = 'kimnerd91'; // 필요하면 다른 값으로 교체

if (($_GET['token'] ?? '') !== $TOKEN) {
    http_response_code(403);
    exit('forbidden');
}

header('Content-Type: text/plain; charset=utf-8');

$sites = require __DIR__ . '/sites.php';

/* ─────────────────────────────────────────────
   배포할 파일 목록
   왼쪽: 이 서버(master 폴더) 기준 로컬 경로
   오른쪽: 각 병원 사이트에서의 상대 경로 (basePath 기준)
   → master 폴더에 파일 추가할 때마다 여기도 한 줄씩 추가
───────────────────────────────────────────── */
$files = [
    __DIR__ . '/master/board/column_admin.php'     => 'board/column_admin.php',
    __DIR__ . '/master/hospital/place_manager.php' => 'hospital/place_manager.php',
    __DIR__ . '/master/board/schema_migrate.php'   => 'board/schema_migrate.php',
];

// master에 실제로 존재하는 파일만 배포 대상으로 필터링 (없는 파일이면 스킵하고 알려줌)
$activeFiles = [];
foreach ($files as $local => $remote) {
    if (file_exists($local)) {
        $activeFiles[$local] = $remote;
    } else {
        echo "⚠ master에 파일 없음, 스킵: {$remote}\n";
    }
}

if (empty($activeFiles)) {
    exit("\n배포할 파일이 master 폴더에 하나도 없습니다. 파일을 넣고 다시 실행하세요.\n");
}

echo "======================================\n";
echo "배포 대상 파일 " . count($activeFiles) . "개 / 사이트 " . count($sites) . "곳\n";
echo "======================================\n\n";

$successCount = 0;
$failCount = 0;

foreach ($sites as $site) {
    $name = $site['name'] ?? $site['host'];

    $conn = @ftp_connect($site['host'], $site['port'] ?? 21, 15);
    if (!$conn) {
        echo "❌ {$name} — 접속 실패 (host/port 확인 필요)\n";
        $failCount++;
        continue;
    }

    if (!@ftp_login($conn, $site['user'], $site['pass'])) {
        echo "❌ {$name} — 로그인 실패 (계정/비번 확인 필요)\n";
        ftp_close($conn);
        $failCount++;
        continue;
    }

    // 카페24 등 공유호스팅은 대부분 패시브 모드 필요
    ftp_pasv($conn, true);

    $basePath = rtrim($site['basePath'] ?? '/newadm/', '/');
    $siteOk = true;

    foreach ($activeFiles as $local => $remote) {
        $remotePath = $basePath . '/' . $remote;

        // 원격 하위 디렉토리가 없으면 생성 시도 (예: board/, hospital/)
        $remoteDir = dirname($remotePath);
        ensure_remote_dir($conn, $remoteDir);

        if (@ftp_put($conn, $remotePath, $local, FTP_BINARY)) {
            echo "  ✅ {$name} - {$remote}\n";
        } else {
            echo "  ❌ {$name} - {$remote} 업로드 실패 (경로 확인: {$remotePath})\n";
            $siteOk = false;
        }
    }

    ftp_close($conn);
    $siteOk ? $successCount++ : $failCount++;

    // 파일 업로드가 끝난 직후, 그 사이트의 스키마 마이그레이션 스크립트 호출
    // (schema_migrate.php가 master/board/에 있고 deploy 대상 파일에 포함돼 있어야 함)
    if (!empty($site['schemaUrl'])) {
        $migrateUrl = rtrim($site['schemaUrl'], '/');
    } else {
        // domain을 따로 안 적었으면 host를 그대로 씀 (FTP호스트=실도메인인 경우만 정상 동작)
        $publicDomain = $site['domain'] ?? $site['host'];
        $migrateUrl = "https://{$publicDomain}/newadm/board/schema_migrate.php?token={$TOKEN}";
    }
    $migrateResult = @file_get_contents($migrateUrl);
    echo "  🔧 스키마 체크(" . $name . "): " . trim($migrateResult !== false ? $migrateResult : '(응답없음, URL 확인 필요)') . "\n";
}

echo "\n======================================\n";
echo "완료: 성공 {$successCount}곳 / 실패 {$failCount}곳\n";
echo "======================================\n";

/**
 * 원격 디렉토리가 없으면 생성. 이미 있으면 조용히 넘어감.
 */
function ensure_remote_dir($conn, string $dir): void
{
    if ($dir === '' || $dir === '.' || $dir === '/') return;

    $parts = explode('/', trim($dir, '/'));
    $path = '';
    foreach ($parts as $part) {
        if ($part === '') continue;
        $path .= '/' . $part;
        // 이미 존재하면 mkdir이 실패하지만(정상), 에러 무시하고 계속 진행
        @ftp_mkdir($conn, $path);
    }
}
