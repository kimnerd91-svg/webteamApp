<?php
/**
 * aside.php — 3개 모듈 공용 사이드바.
 * config/, hospital/, board/ 하위 파일들이 '../aside.php' 로 include 합니다.
 * (원본 newadm/aside.php와 동일한 include 관례를 그대로 유지)
 */
$current = $_SERVER['SCRIPT_NAME'];
$base    = defined('SAL_BASE_URL') ? SAL_BASE_URL : '';
function sal_active($needle, $current) { return strpos($current, $needle) !== false ? 'active' : ''; }
?>
<link rel="stylesheet" href="<?= $base ?>/assets/admin.css">
<aside class="sal_aside">
    <div class="sal_brand">사이트 관리자</div>
    <nav class="sal_nav">
        <a class="<?= sal_active('/index.php', $current) ?>" href="<?= $base ?>/index.php">대시보드</a>
        <a class="<?= sal_active('/config/site_config.php', $current) ?>" href="<?= $base ?>/config/site_config.php">사이트 설정</a>
        <a class="<?= sal_active('/hospital/page_seo_manager.php', $current) ?>" href="<?= $base ?>/hospital/page_seo_manager.php">SEO·스키마 관리</a>
        <a class="<?= sal_active('/board/column_admin.php', $current) ?>" href="<?= $base ?>/board/column_admin.php">칼럼 관리</a>
        <a class="<?= sal_active('/board/case_admin.php', $current) ?>" href="<?= $base ?>/board/case_admin.php">임상케이스 관리</a>
        <a class="<?= sal_active('/config/patch_installer.php', $current) ?>" href="<?= $base ?>/config/patch_installer.php">코드 패처</a>
        <a class="sal_logout" href="<?= $base ?>/logout.php">로그아웃</a>
    </nav>
</aside>
