<?php
/**
 * config.php
 * 이 관리자 패키지의 유일한 설정 파일입니다.
 * DB 접속 정보만 아래 4줄을 채우면 됩니다. (호스팅사 관리자 페이지 > DB 관리에서 확인)
 */

define('SAL_DB_HOST', 'localhost');      // DB 호스트 (보통 localhost)
define('SAL_DB_USER', 'your_db_user');   // DB 계정
define('SAL_DB_PASS', 'your_db_pass');   // DB 비밀번호
define('SAL_DB_NAME', 'your_db_name');   // DB 이름

// 아래는 보통 수정할 필요 없음
define('SAL_DB_CHARSET', 'utf8mb4');
