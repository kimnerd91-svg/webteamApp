<?php
/**
 * sub/case_list.php — 임상케이스(전/후 사진) 목록 페이지 (방문자용, 로그인 불필요)
 * db.php만 불러온다 — bootstrap.php(관리자 로그인 강제)를 쓰지 않는다.
 */
require_once __DIR__ . '/../inc/db.php';

$base      = defined('SAL_BASE_URL') ? SAL_BASE_URL : '';
$table     = 'sal_case';
$cat_table = 'sal_case_cat';

$cat_id   = (int)($_GET['cat_id'] ?? 0);
$page     = max(1, (int)($_GET['page'] ?? 1));
$per_page = 12;
$offset   = ($page - 1) * $per_page;

$cats = array();
$r = mysqli_query($connect_db, "SELECT c.*, (SELECT COUNT(*) FROM `{$table}` s WHERE s.cat_id = c.id AND s.visible = 1) as cnt
    FROM `{$cat_table}` c ORDER BY c.sort ASC, c.id ASC");
if ($r) while ($c = mysqli_fetch_assoc($r)) $cats[] = $c;

$where = "WHERE visible = 1" . ($cat_id ? " AND cat_id = {$cat_id}" : '');
$total = (int)(sql_fetch("SELECT COUNT(*) cnt FROM `{$table}` {$where}")['cnt'] ?? 0);
$total_pages = max(1, (int)ceil($total / $per_page));

$rows = array();
$list_r = mysqli_query($connect_db, "SELECT c.*, cc.name as cat_name FROM `{$table}` c
    LEFT JOIN `{$cat_table}` cc ON c.cat_id = cc.id
    {$where} ORDER BY c.id DESC LIMIT {$offset},{$per_page}");
if ($list_r) while ($row = mysqli_fetch_assoc($list_r)) $rows[] = $row;

$dm_conf = sql_fetch("SELECT cf_site_name FROM dm_config WHERE cf_id=1");
$site_name = $dm_conf['cf_site_name'] ?? $_SERVER['HTTP_HOST'];
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>임상케이스 | <?= htmlspecialchars($site_name) ?></title>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Pretendard','Apple SD Gothic Neo',sans-serif;background:#faf9f7;color:#1a1a2e;line-height:1.5}
.wrap{max-width:1440px;margin:0 auto;padding:56px 40px 100px}
h1{font-size:32px;font-weight:800;letter-spacing:-.6px;margin-bottom:10px;color:#141420}
.lead{color:#a8a8b3;font-size:14px;margin-bottom:34px}

.filters{display:flex;gap:9px;flex-wrap:wrap;margin-bottom:38px}
.filters a{padding:9px 18px;border-radius:999px;border:1px solid #ececef;background:#fff;color:#3d3d47;
  text-decoration:none;font-size:13px;font-weight:700;transition:.15s}
.filters a:hover{border-color:#2563eb;color:#2563eb}
.filters a.on{background:#141420;color:#fff;border-color:#141420}

.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:26px}
@media (max-width:980px){ .grid{grid-template-columns:repeat(2,1fr)} }
@media (max-width:640px){ .grid{grid-template-columns:1fr} .wrap{padding:36px 18px 70px} }

.card{position:relative;display:flex;flex-direction:column;aspect-ratio:3/4;text-decoration:none;color:inherit;
  background:#fff;border:1px solid #ececef;border-radius:20px;overflow:hidden;cursor:pointer;
  transition:box-shadow .25s,transform .25s,border-color .25s}
.card:hover{box-shadow:0 24px 50px -16px rgba(20,20,32,.16);transform:translateY(-4px);border-color:#e2e2ea}

.thumb{position:absolute;inset:0;z-index:0}
.thumb img{width:100%;height:100%;object-fit:cover;display:block;transition:transform .4s}
.card:hover .thumb img{transform:scale(1.045)}
.thumb .catlab{position:absolute;top:12px;left:12px;z-index:2;font-size:10.5px;font-weight:800;color:#141420;
  background:rgba(255,255,255,.94);backdrop-filter:blur(4px);padding:6px 13px;border-radius:999px;letter-spacing:.2px}
.thumb::after{content:'';position:absolute;inset:0;z-index:1;background:linear-gradient(180deg,transparent 40%,rgba(10,10,16,.68) 100%);
  opacity:0;transition:opacity .3s}
.card:hover .thumb::after{opacity:1}

.body{position:relative;z-index:1;margin-top:auto;background:#fff;padding:18px 20px 0;transition:background .3s}
.card:hover .body{background:transparent}
.body h3{font-size:15px;font-weight:800;margin-bottom:4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;
  color:#141420;transition:color .3s}
.card:hover .body h3{color:#fff}
.body p{font-size:12.5px;color:#a8a8b3;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-bottom:10px;
  transition:color .3s}
.card:hover .body p{color:#e5e5ea}
.body .hashtags{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:16px}
.body .hashtags span{font-size:10.5px;font-weight:700;color:#5a5a66;background:#eeeef1;padding:4px 10px;
  border-radius:999px;transition:background .3s,color .3s}
.card:hover .body .hashtags span{background:rgba(255,255,255,.92);color:#232329}

.stats{position:relative;z-index:1;display:grid;grid-template-columns:1fr 1fr 1fr;margin:0;padding:0 20px;
  background:#fff;border-top:1px solid #f1f1f4;max-height:70px;opacity:1;overflow:hidden;
  transition:max-height .25s ease,opacity .2s ease,background .3s ease}
.stats div{padding:13px 4px 16px;text-align:center;font-size:10.5px;color:#c2c2ca;font-weight:600}
.stats div b{display:block;font-size:12.5px;font-weight:800;color:#3d3d47;margin-top:3px}
.stats .view b{color:#2563eb}
.card:hover .stats{max-height:0;opacity:0;background:transparent}

.empty{color:#a8a8b3;font-size:13.5px;padding:80px 0;text-align:center}

.pager{display:flex;gap:7px;justify-content:center;margin-top:44px}
.pager a{width:36px;height:36px;display:flex;align-items:center;justify-content:center;border-radius:10px;
  border:1px solid #ececef;color:#3d3d47;text-decoration:none;font-size:13px;background:#fff;font-weight:700;
  transition:.15s}
.pager a:hover{border-color:#2563eb;color:#2563eb}
.pager a.on{background:#141420;color:#fff;border-color:#141420}

.disclaimer{display:flex;gap:12px;margin-top:48px;padding:18px 20px;background:#fff;border:1px solid #ececef;
  border-radius:14px;font-size:11.5px;color:#a8a8b3;line-height:1.8}
.disclaimer .ic{flex-shrink:0;width:18px;height:18px;border-radius:50%;background:#f0f0f4;color:#9a9aa8;
  display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:800}
</style>
</head>
<body>
<div class="wrap">
  <h1>임상케이스</h1>
  <p class="lead"><?= htmlspecialchars($site_name) ?>에서 진행한 치료 전/후 사례입니다.</p>

  <div class="filters">
    <a class="<?= !$cat_id ? 'on' : '' ?>" href="?">전체</a>
    <?php foreach ($cats as $c): if ((int)$c['cnt'] === 0 && (int)$c['id'] !== $cat_id) continue; ?>
      <a class="<?= $cat_id === (int)$c['id'] ? 'on' : '' ?>" href="?cat_id=<?= $c['id'] ?>"><?= htmlspecialchars($c['name']) ?></a>
    <?php endforeach; ?>
  </div>

  <?php if (!$rows): ?>
    <div class="empty">등록된 케이스가 없습니다.</div>
  <?php else: ?>
    <div class="grid">
      <?php foreach ($rows as $row): ?>
        <a class="card" href="./case_view.php?id=<?= $row['id'] ?>">
          <div class="thumb">
            <span class="catlab"><?= htmlspecialchars($row['cat_name'] ?: '미분류') ?></span>
            <img src="<?= htmlspecialchars($base . $row['image_before']) ?>" alt="">
          </div>
          <div class="body">
            <h3><?= htmlspecialchars($row['title']) ?></h3>
            <p><?= htmlspecialchars($row['subtitle']) ?></p>
            <?php if ($row['tags']): ?>
              <div class="hashtags">
                <?php foreach (array_slice(array_filter(array_map('trim', explode(',', $row['tags']))), 0, 3) as $tg): ?>
                  <span>#<?= htmlspecialchars($tg) ?></span>
                <?php endforeach; ?>
              </div>
            <?php endif; ?>
          </div>
          <div class="stats">
            <div>작성일<b><?= !empty($row['created_at']) ? date('Y.m.d', strtotime($row['created_at'])) : '-' ?></b></div>
            <div>조회<b><?= (int)$row['hit'] ?></b></div>
            <div class="view">
              <b>보기 →</b>
            </div>
          </div>
        </a>
      <?php endforeach; ?>
    </div>
    <?php if ($total_pages > 1): ?>
      <div class="pager">
        <?php for ($p = 1; $p <= $total_pages; $p++): ?>
          <a class="<?= $p === $page ? 'on' : '' ?>" href="?<?= $cat_id ? "cat_id={$cat_id}&" : '' ?>page=<?= $p ?>"><?= $p ?></a>
        <?php endfor; ?>
      </div>
    <?php endif; ?>
  <?php endif; ?>

  <div class="disclaimer">
    <span class="ic">i</span>
    <span>본 게시물은 실제 내원 환자분의 동의를 받아 게시한 치료 전후 임상 사례입니다. 개인에 따라 진료 및 치료 방법, 효과와 부작용이 다르게 나타날 수 있습니다.</span>
  </div>
</div>
</body>
</html>
