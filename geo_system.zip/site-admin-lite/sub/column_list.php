<?php
/**
 * sub/column_list.php — 칼럼 목록 페이지 (독립 프로젝트, 그누보드 setting.css 미사용)
 * 모든 스타일은 파일 하단 <style> 블록에 자체 포함 (외부 CSS 의존 없음)
 */
require_once __DIR__ . '/../inc/db.php';
require_once __DIR__ . '/../inc/auth.php';   // 로그인 강제(sal_require_login) 없이 상수·세션만 사용 — 공개 페이지

$base         = defined('SAL_BASE_URL') ? SAL_BASE_URL : '';
$table        = 'sal_column';
$cat_table    = 'sal_column_cat';
$column_path  = $base . '/sub';
$column_label = '칼럼';

$cat_id   = (int)($_GET['cat_id'] ?? 0);
$sel_tag  = trim($_GET['tag'] ?? '');
$page     = max(1, (int)($_GET['page'] ?? 1));
$per_page = 9;
$offset   = ($page - 1) * $per_page;

// 카테고리 목록 + 게시물 수
$cats = array();
$r = mysqli_query($connect_db, "SELECT c.*, (SELECT COUNT(*) FROM `{$table}` g WHERE g.cat_id = c.id) as cnt
    FROM `{$cat_table}` c ORDER BY c.sort ASC, c.id ASC");
if ($r) while ($c = mysqli_fetch_assoc($r)) $cats[] = $c;
$total_all = (int)(sql_fetch("SELECT COUNT(*) cnt FROM `{$table}`")['cnt'] ?? 0);

// 인기글 TOP10 (하단에서 5개만 slice)
$popular = array();
$pr = mysqli_query($connect_db, "SELECT id, title FROM `{$table}` ORDER BY hit DESC, id DESC LIMIT 10");
if ($pr) while ($p = mysqli_fetch_assoc($pr)) $popular[] = $p;

// 인기 태그 TOP10 (하단에서 5개만 slice)
$tag_count = array();
$tr = mysqli_query($connect_db, "SELECT tags FROM `{$table}` WHERE tags IS NOT NULL AND tags != ''");
if ($tr) while ($trow = mysqli_fetch_assoc($tr)) {
    foreach (array_filter(array_map('trim', explode(',', $trow['tags']))) as $tg) {
        if ($tg === '') continue;
        $tag_count[$tg] = ($tag_count[$tg] ?? 0) + 1;
    }
}
arsort($tag_count);
$top_tags = array_slice($tag_count, 0, 10, true); // tag => count

// WHERE (카테고리 + 태그 필터, 둘 다 지원)
$where_parts = array();
if ($cat_id) $where_parts[] = "cat_id = {$cat_id}";
if ($sel_tag) {
    $tag_esc = mysqli_real_escape_string($connect_db, $sel_tag);
    $where_parts[] = "tags LIKE '%{$tag_esc}%'";
}
$where = $where_parts ? 'WHERE ' . implode(' AND ', $where_parts) : '';

$total = (int)(sql_fetch("SELECT COUNT(*) cnt FROM `{$table}` {$where}")['cnt'] ?? 0);
$total_pages = max(1, (int)ceil($total / $per_page));

$rows = array();
$list_r = mysqli_query($connect_db, "SELECT g.*, c.name as cat_name
    FROM `{$table}` g LEFT JOIN `{$cat_table}` c ON g.cat_id = c.id
    {$where}
    ORDER BY g.id DESC LIMIT {$offset}, {$per_page}");
if ($list_r) while ($row = mysqli_fetch_assoc($list_r)) $rows[] = $row;

$dm_conf = sql_fetch("SELECT cf_site_name FROM dm_config WHERE cf_id=1");
$hospital_name = $dm_conf['cf_site_name'] ?? $_SERVER['HTTP_HOST'];

// ── 홈 레이아웃 여부: 필터/페이지 파라미터가 전혀 없을 때만 ──
$show_home_layout = !$cat_id && !$sel_tag && $page <= 1;

if ($show_home_layout) {
    // 최신글 스와이퍼 (카테고리 무관, 최신순 6개, 부족하면 반복해서 채움)
    $swiper_posts = array();
    $sw_r = mysqli_query($connect_db, "SELECT id, title, subtitle, thumbnail, cat_id, created_at FROM `{$table}` ORDER BY id DESC LIMIT 6");
    if ($sw_r) while ($row = mysqli_fetch_assoc($sw_r)) $swiper_posts[] = $row;
    if (!empty($swiper_posts) && count($swiper_posts) < 6) {
        $orig = $swiper_posts;
        while (count($swiper_posts) < 6) $swiper_posts = array_merge($swiper_posts, $orig);
        $swiper_posts = array_slice($swiper_posts, 0, 6);
    }

    $cat_name_map = array();
    foreach ($cats as $c) $cat_name_map[(int)$c['id']] = $c['name'];

    // 게시물 있는 카테고리 중 랜덤 최대 2개
    $cats_with_posts = array_values(array_filter($cats, function ($c) { return (int)$c['cnt'] > 0; }));
    shuffle($cats_with_posts);
    $shown_cats = array_slice($cats_with_posts, 0, 2);

    // 카테고리별 게시물: 1row(3) + LOAD MORE 시 최대 3row(9)
    $home_per_cat = 9;
    foreach ($shown_cats as $idx => $cat) {
        $cid = (int)$cat['id'];
        $cp_r = mysqli_query($connect_db, "SELECT id, title, subtitle, thumbnail, tags, created_at, hit
            FROM `{$table}` WHERE cat_id={$cid} ORDER BY id DESC LIMIT {$home_per_cat}");
        $cp_list = array();
        if ($cp_r) while ($row = mysqli_fetch_assoc($cp_r)) $cp_list[] = $row;
        $shown_cats[$idx]['posts'] = $cp_list;
    }
}

// 필터 상태 타이틀 (필터 레이아웃에서 사용)
$filtered_title = '전체';
if ($cat_id) {
    foreach ($cats as $c) { if ((int)$c['id'] === $cat_id) { $filtered_title = $c['name']; break; } }
} elseif ($sel_tag) {
    $filtered_title = '#' . $sel_tag;
}
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($column_label) ?> - <?= htmlspecialchars($hospital_name) ?></title>
<meta name="description" content="<?= htmlspecialchars($hospital_name) ?>의 <?= htmlspecialchars($column_label) ?> 목록입니다.">
<link rel="preconnect" href="https://fonts.googleapis.com">
</head>
<body>

<?php if ($show_home_layout): ?>

    <main class="sal-home">

        <!-- ── 최신글 스와이퍼 (카테고리 무관) ── -->
        <?php if (!empty($swiper_posts)): ?>
            <section class="sal-hero">
                <div class="sal-container sal-hero-head">
                    <h1 class="sal-h1"><?= htmlspecialchars($column_label) ?></h1>
                    <div class="sal-view-toggle" role="group" aria-label="보기 방식 전환">
                        <button type="button" class="sal-view-btn active" data-view="thumb">
                            <span class="material-symbols-outlined">grid_view</span> THUMB
                        </button>
                        <button type="button" class="sal-view-btn" data-view="list">
                            <span class="material-symbols-outlined">list</span> LIST
                        </button>
                    </div>
                </div>

                <div class="sal-swiper-wrap">
                    <div class="swiper sal-swiper">
                        <div class="swiper-wrapper">
                            <?php foreach ($swiper_posts as $sp):
                                $thumb = !empty($sp['thumbnail']) ? $sp['thumbnail'] : '/images/no_image.png';
                                $href  = $column_path . '/column.php?id=' . (int)$sp['id'];
                                $cname = $cat_name_map[(int)$sp['cat_id']] ?? '';
                            ?>
                                <div class="swiper-slide">
                                    <a class="sal-swiper-thumb" href="<?= $href ?>">
                                        <img src="<?= htmlspecialchars($thumb) ?>" alt="<?= htmlspecialchars($sp['title']) ?>">
                                    </a>
                                    <?php if ($cname): ?>
                                        <p class="sal-swiper-cat"><?= htmlspecialchars(mb_strtoupper($cname)) ?></p>
                                    <?php endif; ?>
                                    <a href="<?= $href ?>" class="sal-swiper-title-link">
                                        <h2 class="sal-swiper-title"><?= htmlspecialchars($sp['title']) ?></h2>
                                    </a>
                                    <?php if (!empty($sp['subtitle'])): ?>
                                        <p class="sal-swiper-sub"><?= htmlspecialchars($sp['subtitle']) ?></p>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <button type="button" class="sal-swiper-nav sal-swiper-prev" aria-label="이전">
                        <span class="material-symbols-outlined">arrow_back</span>
                    </button>
                    <button type="button" class="sal-swiper-nav sal-swiper-next" aria-label="다음">
                        <span class="material-symbols-outlined">arrow_forward</span>
                    </button>
                </div>
            </section>
        <?php endif; ?>

        <!-- ── 랜덤 카테고리 섹션 (최대 2개) ── -->
        <?php foreach ($shown_cats as $cat):
            $cid       = (int)$cat['id'];
            $cat_posts = $cat['posts'];
            if (empty($cat_posts)) continue;
        ?>
            <section class="sal-cat-section" data-cat-id="<?= $cid ?>">
                <div class="sal-cat-header">
                    <div class="sal-container sal-cat-header-inner">
                        <h2 class="sal-cat-title">
                            <?= htmlspecialchars($cat['name']) ?>
                            <sup><?= (int)$cat['cnt'] ?></sup>
                        </h2>
                        <a class="sal-cat-more" href="<?= $column_path ?>/column_list.php?cat_id=<?= $cid ?>">전체보기</a>
                    </div>
                </div>

                <div class="sal-container">
                    <div class="sal-grid">
                        <?php foreach ($cat_posts as $i => $row):
                            $tags   = array_filter(array_map('trim', explode(',', $row['tags'] ?? '')));
                            $thumb  = !empty($row['thumbnail']) ? $row['thumbnail'] : '/images/no_image.png';
                            $href   = $column_path . '/column.php?id=' . (int)$row['id'];
                            $hidden = $i >= 3 ? ' sal-hidden' : '';
                        ?>
                            <article class="sal-gcard<?= $hidden ?>">
                                <span class="sal-gcard-cat"><?= htmlspecialchars(mb_strtoupper($cat['name'])) ?></span>
                                <a class="sal-gcard-thumb" href="<?= $href ?>">
                                    <img src="<?= htmlspecialchars($thumb) ?>" alt="<?= htmlspecialchars($row['title']) ?>">
                                </a>
                                <?php if (!empty($tags)): ?>
                                    <p class="sal-gcard-tags">
                                        <?php foreach ($tags as $tag): ?>
                                            <a href="<?= $column_path ?>/column_list.php?tag=<?= urlencode($tag) ?>">#<?= htmlspecialchars($tag) ?></a>
                                        <?php endforeach; ?>
                                    </p>
                                <?php endif; ?>
                                <a href="<?= $href ?>" class="sal-gcard-title-link">
                                    <h3 class="sal-gcard-title"><?= htmlspecialchars($row['title']) ?></h3>
                                </a>
                                <?php if (!empty($row['subtitle'])): ?>
                                    <p class="sal-gcard-sub"><?= htmlspecialchars($row['subtitle']) ?></p>
                                <?php endif; ?>
                            </article>
                        <?php endforeach; ?>
                    </div>

                    <?php if (count($cat_posts) > 3): ?>
                        <div class="sal-load-more-wrap">
                            <button type="button" class="sal-load-more-btn">LOAD MORE</button>
                        </div>
                    <?php endif; ?>
                </div>
            </section>
        <?php endforeach; ?>

        <!-- ── 하단 인기태그 / 인기글 (top5, 가로배열) ── -->
        <section class="sal-container sal-bottom">
            <div class="sal-bottom-cols">
                <div class="sal-bottom-col">
                    <p class="sal-bottom-h">인기태그 TOP 5</p>
                    <ul class="sal-tag-cloud">
                        <?php foreach (array_slice($top_tags, 0, 5, true) as $tag => $cnt): ?>
                            <li><a href="<?= $column_path ?>/column_list.php?tag=<?= urlencode($tag) ?>">#<?= htmlspecialchars($tag) ?></a></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <div class="sal-bottom-col">
                    <p class="sal-bottom-h">인기글 TOP 5</p>
                    <ol class="sal-pop-list">
                        <?php foreach (array_slice($popular, 0, 5) as $i => $pp): ?>
                            <li><a href="<?= $column_path ?>/column.php?id=<?= (int)$pp['id'] ?>"><?= $i + 1 ?>. <?= htmlspecialchars($pp['title']) ?></a></li>
                        <?php endforeach; ?>
                    </ol>
                </div>
            </div>
        </section>

    </main>

<?php else: ?>

    <main class="sal-home sal-filtered">

        <section class="sal-hero">
            <div class="sal-container sal-hero-head">
                <h1 class="sal-h1"><?= htmlspecialchars($filtered_title) ?></h1>
                <div class="sal-view-toggle" role="group" aria-label="보기 방식 전환">
                    <button type="button" class="sal-view-btn active" data-view="thumb">
                        <span class="material-symbols-outlined">grid_view</span> THUMB
                    </button>
                    <button type="button" class="sal-view-btn" data-view="list">
                        <span class="material-symbols-outlined">list</span> LIST
                    </button>
                </div>
            </div>

            <div class="sal-container">
                <?php if (empty($rows)): ?>
                    <p class="sal-empty">등록된 글이 없습니다.</p>
                <?php else: ?>
                    <div class="sal-grid">
                        <?php foreach ($rows as $row):
                            $tags    = array_filter(array_map('trim', explode(',', $row['tags'] ?? '')));
                            $thumb   = !empty($row['thumbnail']) ? $row['thumbnail'] : '/images/no_image.png';
                            $href    = $column_path . '/column.php?id=' . (int)$row['id'];
                            $subtext = $row['subtitle'] ?: mb_substr(trim(preg_replace('/\s+/', ' ', strip_tags($row['content'] ?? ''))), 0, 80, 'UTF-8');
                        ?>
                            <article class="sal-gcard">
                                <span class="sal-gcard-cat"><?= htmlspecialchars(mb_strtoupper($filtered_title)) ?></span>
                                <a class="sal-gcard-thumb" href="<?= $href ?>">
                                    <img src="<?= htmlspecialchars($thumb) ?>" alt="<?= htmlspecialchars($row['title']) ?>">
                                </a>
                                <?php if (!empty($tags)): ?>
                                    <p class="sal-gcard-tags">
                                        <?php foreach ($tags as $tag): ?>
                                            <a href="<?= $column_path ?>/column_list.php?tag=<?= urlencode($tag) ?>">#<?= htmlspecialchars($tag) ?></a>
                                        <?php endforeach; ?>
                                    </p>
                                <?php endif; ?>
                                <a href="<?= $href ?>" class="sal-gcard-title-link">
                                    <h3 class="sal-gcard-title"><?= htmlspecialchars($row['title']) ?></h3>
                                </a>
                                <?php if ($subtext): ?>
                                    <p class="sal-gcard-sub"><?= htmlspecialchars($subtext) ?></p>
                                <?php endif; ?>
                            </article>
                        <?php endforeach; ?>
                    </div>

                    <?php if ($total_pages > 1): ?>
                        <div class="sal-pagi">
                            <?php for ($p = 1; $p <= $total_pages; $p++): ?>
                                <a href="?page=<?= $p ?><?= $cat_id ? '&cat_id=' . $cat_id : '' ?><?= $sel_tag ? '&tag=' . urlencode($sel_tag) : '' ?>" class="<?= $p === $page ? 'active' : '' ?>"><?= $p ?></a>
                            <?php endfor; ?>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </section>

        <!-- ── 하단 인기태그 / 인기글 (top5, 가로배열) ── -->
        <section class="sal-container sal-bottom">
            <div class="sal-bottom-cols">
                <div class="sal-bottom-col">
                    <p class="sal-bottom-h">인기태그 TOP 5</p>
                    <ul class="sal-tag-cloud">
                        <?php foreach (array_slice($top_tags, 0, 5, true) as $tag => $cnt): ?>
                            <li><a href="<?= $column_path ?>/column_list.php?tag=<?= urlencode($tag) ?>">#<?= htmlspecialchars($tag) ?></a></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <div class="sal-bottom-col">
                    <p class="sal-bottom-h">인기글 TOP 5</p>
                    <ol class="sal-pop-list">
                        <?php foreach (array_slice($popular, 0, 5) as $i => $pp): ?>
                            <li><a href="<?= $column_path ?>/column.php?id=<?= (int)$pp['id'] ?>"><?= $i + 1 ?>. <?= htmlspecialchars($pp['title']) ?></a></li>
                        <?php endforeach; ?>
                    </ol>
                </div>
            </div>
        </section>

    </main>

<?php endif; ?>

<!-- ── 스타일: setting.css 대신 값 자체를 여기 하단에 전부 포함 ── -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200">
<style>
:root{
    --main-color:#304F4E;
    --sub-color:#9BAB83;
    --point:#D7AC7A;
    --point2:#50ecc8;
    --light:#F9FBF4;
    --light2:#F6F4EC;
    --dark:#2c2c2c;
    --white:#fff;
    --gray-100:#f8f8f8;
    --gray-300:#e5e7eb;
    --gray-500:#6b7280;
    --gray-600:#4b5563;
}
*{box-sizing:border-box}
body{margin:0;font-family:'Pretendard',-apple-system,sans-serif;background:#fff;color:var(--dark)}

.sal-container{max-width:1280px;margin:0 auto;width:100%;padding:0 40px}
@media (max-width:768px){.sal-container{padding:0 20px}}

/* 히어로 (타이틀 + 토글) */
.sal-hero{padding-top:100px}
.sal-hero-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:40px}
.sal-h1{font-size:40px;font-weight:400;color:var(--dark);margin:0;font-family:Georgia,'Noto Serif KR',serif}
@media (max-width:768px){.sal-h1{font-size:28px}.sal-hero{padding-top:40px}.sal-hero-head{margin-bottom:24px}}

/* THUMB/LIST 토글 */
.sal-view-toggle{display:flex;border:1px solid var(--gray-300);border-radius:4px;overflow:hidden;flex-shrink:0}
.sal-view-btn{display:flex;align-items:center;gap:6px;padding:10px 20px;background:#fff;color:var(--gray-500);border:none;font-size:13px;font-weight:600;letter-spacing:.03em;cursor:pointer;transition:background .2s,color .2s}
.sal-view-btn .material-symbols-outlined{font-size:16px}
.sal-view-btn.active{background:var(--dark);color:#fff}
.sal-view-btn:not(.active):hover{background:var(--gray-100)}

/* 스와이퍼 */
.sal-swiper-wrap{position:relative;margin-bottom:100px}
.sal-swiper{padding:0 12vw}
@media (max-width:768px){.sal-swiper{padding:0 8vw}.sal-swiper-wrap{margin-bottom:60px}}
.sal-swiper .swiper-slide{opacity:.45;transition:opacity .3s}
.sal-swiper .swiper-slide-active{opacity:1}
.sal-swiper-thumb{display:block;aspect-ratio:4/3;border-radius:20px;overflow:hidden}
.sal-swiper-thumb img{width:100%;height:100%;object-fit:cover;display:block}
.sal-swiper-cat{color:var(--point);font-size:13px;font-weight:600;letter-spacing:.05em;margin:20px 0 8px}
.sal-swiper-title-link{text-decoration:none}
.sal-swiper-title{color:var(--dark);font-size:22px;font-weight:400;line-height:1.3;margin:0;font-family:Georgia,'Noto Serif KR',serif}
.sal-swiper-sub{color:var(--gray-500);font-size:14px;margin:8px 0 0}
.sal-swiper-nav{position:absolute;top:30%;transform:translateY(-50%);width:44px;height:44px;border-radius:50%;border:1px solid var(--gray-300);background:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer;z-index:2}
.sal-swiper-prev{left:12px}
.sal-swiper-next{right:12px}
@media (max-width:768px){.sal-swiper-nav{display:none}}

/* 카테고리 섹션 */
.sal-cat-section{margin-bottom:100px}
@media (max-width:768px){.sal-cat-section{margin-bottom:60px}}
.sal-cat-header{position:sticky;top:0;z-index:5;background:#fff;border-bottom:1px solid var(--gray-300);padding:24px 0;margin-bottom:40px}
.sal-cat-header-inner{display:flex;justify-content:space-between;align-items:center;padding:0}
.sal-cat-title{font-size:32px;font-weight:400;color:var(--dark);margin:0;font-family:Georgia,'Noto Serif KR',serif}
.sal-cat-title sup{font-size:14px;color:var(--gray-500);font-weight:400}
.sal-cat-more{font-size:13px;color:var(--gray-500);text-decoration:none;letter-spacing:.02em}
@media (max-width:768px){.sal-cat-title{font-size:24px}}

/* 그리드 (THUMB 모드) */
.sal-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:40px 30px}
@media (max-width:992px){.sal-grid{grid-template-columns:repeat(2,1fr)}}
@media (max-width:600px){.sal-grid{grid-template-columns:1fr}}
.sal-gcard.sal-hidden{display:none}

.sal-gcard-cat{display:none}
.sal-gcard-thumb{display:block;margin-bottom:24px;border-radius:20px;overflow:hidden;aspect-ratio:4/3}
.sal-gcard-thumb img{width:100%;height:100%;object-fit:cover;display:block}
.sal-gcard-tags{display:flex;flex-wrap:wrap;gap:4px;margin:0 0 16px}
.sal-gcard-tags a{font-size:13px;color:var(--gray-600);background:var(--gray-100);border-radius:8px;padding:4px 10px;text-decoration:none}
.sal-gcard-title-link{text-decoration:none}
.sal-gcard-title{color:var(--dark);font-size:20px;font-weight:400;line-height:1.3;margin:0 0 8px}
.sal-gcard-sub{color:var(--gray-500);font-size:14px;line-height:1.5;margin:0}

/* LOAD MORE */
.sal-load-more-wrap{text-align:center;margin-top:60px}
@media (max-width:768px){.sal-load-more-wrap{margin-top:40px}}
.sal-load-more-btn{padding:14px 40px;background:var(--main-color);color:#fff;border:none;border-radius:4px;font-size:13px;font-weight:600;letter-spacing:.05em;cursor:pointer;transition:background .2s}
.sal-load-more-btn:hover{background:var(--point)}
.sal-load-more-btn.sal-done{display:none}

/* 하단 인기태그/인기글 */
.sal-bottom{padding:60px 0;border-top:1px solid var(--gray-300)}
.sal-bottom-cols{display:flex;gap:60px}
@media (max-width:992px){.sal-bottom-cols{flex-direction:column;gap:40px}}
.sal-bottom-col{flex:1}
.sal-bottom-h{font-family:Georgia,'Noto Serif KR',serif;font-size:18px;font-weight:400;color:var(--dark);margin:0 0 20px}
.sal-tag-cloud{list-style:none;display:flex;flex-wrap:wrap;gap:10px;margin:0;padding:0}
.sal-tag-cloud a{font-size:13px;color:var(--gray-600);background:var(--gray-100);border-radius:8px;padding:6px 12px;text-decoration:none}
.sal-pop-list{list-style:none;margin:0;padding:0}
.sal-pop-list li{margin-bottom:10px}
.sal-pop-list a{color:var(--dark);font-size:14px;text-decoration:none}
.sal-pop-list a:hover{color:var(--main-color)}

/* pagination */
.sal-pagi{display:flex;justify-content:center;gap:6px;margin-top:60px}
.sal-pagi a{min-width:36px;height:36px;display:flex;align-items:center;justify-content:center;border-radius:4px;border:1px solid var(--gray-300);text-decoration:none;color:var(--gray-500);font-size:13px}
.sal-pagi a.active{background:var(--dark);border-color:var(--dark);color:#fff}

.sal-empty{color:var(--gray-500);padding:60px 0;text-align:center}

/* ── LIST 모드 ── */
.sal-view-list .sal-grid{display:block}
.sal-view-list .sal-gcard.sal-hidden{display:none}
.sal-view-list .sal-gcard{display:flex;align-items:center;gap:24px;padding:20px 0;border-top:1px solid var(--dark)}
.sal-view-list .sal-gcard:last-child{border-bottom:1px solid var(--dark)}
.sal-view-list .sal-gcard-thumb{display:none}
.sal-view-list .sal-gcard-sub{display:none}
.sal-view-list .sal-gcard-cat{display:block;order:1;flex:0 0 100px;color:var(--main-color);font-size:13px;font-weight:700;letter-spacing:.05em}
.sal-view-list .sal-gcard-title-link{order:2;flex:1 1 auto}
.sal-view-list .sal-gcard-title{order:2;font-size:16px;font-weight:700;margin-bottom:0}
.sal-view-list .sal-gcard-tags{order:3;flex:0 0 auto;margin-bottom:0}
</style>

<!-- ── Swiper CDN (프로젝트에 미로드 상태이므로 직접 추가) ── -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/11.0.5/swiper-bundle.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/11.0.5/swiper-bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {

    // ── THUMB / LIST 보기 전환 ──
    document.querySelectorAll('.sal-view-btn').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var view = btn.dataset.view;
            document.querySelectorAll('.sal-view-btn').forEach(function (b) { b.classList.remove('active'); });
            btn.classList.add('active');
            var main = document.querySelector('.sal-home');
            if (main) main.classList.toggle('sal-view-list', view === 'list');
        });
    });

    // ── 카테고리별 LOAD MORE ──
    document.querySelectorAll('.sal-load-more-btn').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var section = btn.closest('.sal-cat-section');
            if (!section) return;
            section.querySelectorAll('.sal-hidden').forEach(function (card) {
                card.classList.remove('sal-hidden');
            });
            btn.classList.add('sal-done');
        });
    });

    // ── 최신글 스와이퍼 초기화 ──
    if (typeof Swiper !== 'undefined' && document.querySelector('.sal-swiper')) {
        new Swiper('.sal-swiper', {
            slidesPerView: 1.4,
            centeredSlides: true,
            spaceBetween: 20,
            loop: true,
            autoplay: { delay: 3500, disableOnInteraction: false },
            navigation: {
                nextEl: '.sal-swiper-next',
                prevEl: '.sal-swiper-prev',
            },
            breakpoints: {
                768: { slidesPerView: 2.2, spaceBetween: 28 },
                992: { slidesPerView: 3, spaceBetween: 32 },
            },
        });
    }
});
</script>

</body>
</html>