<?php
/**
 * sub/case_view.php — 임상케이스 상세 페이지 (방문자용, 로그인 불필요)
 * db.php만 불러온다 — bootstrap.php(관리자 로그인 강제)를 쓰지 않는다.
 */
require_once __DIR__ . '/../inc/db.php';
if (session_status() === PHP_SESSION_NONE) session_start();

$base      = defined('SAL_BASE_URL') ? SAL_BASE_URL : '';
$table     = 'sal_case';
$cat_table = 'sal_case_cat';
$case_path = $base . '/sub';

$id = (int)($_GET['id'] ?? 0);
if (!$id) { header('Location: ' . $case_path . '/case_list.php'); exit; }

$post = sql_fetch("SELECT * FROM `{$table}` WHERE id={$id} AND visible=1");
if (!$post) { header('Location: ' . $case_path . '/case_list.php'); exit; }

$cat_name = '미분류';
if (!empty($post['cat_id'])) {
    $cat_row = sql_fetch("SELECT name FROM `{$cat_table}` WHERE id=" . (int)$post['cat_id']);
    if ($cat_row) $cat_name = $cat_row['name'];
}

// 조회수 (세션당 1회)
if (empty($_SESSION['viewed_case_' . $id])) {
    sql_query("UPDATE `{$table}` SET hit=hit+1 WHERE id={$id}");
    $_SESSION['viewed_case_' . $id] = true;
    $post['hit'] = (int)$post['hit'] + 1;
}

// 이전/다음 글 (공개된 것만)
$prev = sql_fetch("SELECT id,title FROM `{$table}` WHERE id > {$id} AND visible=1 ORDER BY id ASC  LIMIT 1");
$next = sql_fetch("SELECT id,title FROM `{$table}` WHERE id < {$id} AND visible=1 ORDER BY id DESC LIMIT 1");

$date = !empty($post['created_at']) ? date('Y.m.d', strtotime($post['created_at'])) : '';
$dm_conf = sql_fetch("SELECT cf_site_name FROM dm_config WHERE cf_id=1");
$site_name = $dm_conf['cf_site_name'] ?? $_SERVER['HTTP_HOST'];
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($post['title']) ?> | 임상케이스 | <?= htmlspecialchars($site_name) ?></title>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Pretendard','Apple SD Gothic Neo',sans-serif;background:#faf9f7;color:#1a1a2e;line-height:1.6}

.shell{max-width:1440px;margin:0 auto;padding:56px 40px 100px}

.split{display:grid;grid-template-columns:minmax(300px,380px) 1fr;gap:64px;align-items:start}
@media (max-width:980px){ .split{grid-template-columns:1fr;gap:32px} }

.left{position:sticky;top:40px}
@media (max-width:980px){ .left{position:static} }

.crumb{font-size:12.5px;color:#a8a8b3;margin-bottom:20px}
.crumb a{color:#a8a8b3;text-decoration:none}
.crumb a:hover{color:#6b6b76}

.cat{display:inline-block;font-size:12px;font-weight:800;color:#5a5a66;background:#eeeef1;
  border-radius:999px;padding:6px 14px;margin-bottom:18px}

h1{font-size:28px;font-weight:800;letter-spacing:-.5px;margin-bottom:16px;line-height:1.35;color:#141420}

.hashtags{display:flex;gap:7px;flex-wrap:wrap;margin-bottom:24px}
.hashtags span{font-size:12px;font-weight:700;color:#5a5a66;background:#eeeef1;border-radius:999px;padding:6px 12px}

.meta{display:flex;align-items:center;gap:10px;font-size:12.5px;color:#a8a8b3;padding-top:20px;
  border-top:1px solid #ececef}
.meta b{color:#3d3d47;font-weight:700}
.meta .dot{width:3px;height:3px;border-radius:50%;background:#d4d4dc}

.right{min-width:0}

.ba-slider{position:relative;width:100%;aspect-ratio:16/11;border-radius:18px;overflow:hidden;
  user-select:none;background:#ececef;box-shadow:0 1px 3px rgba(20,20,32,.06);margin-bottom:12px;cursor:ew-resize}
.ba-slider img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;display:block;pointer-events:none}
.ba-after{z-index:1}
.ba-before-wrap{position:absolute;inset:0;z-index:2;overflow:hidden;width:50%}
.ba-before-wrap img{width:var(--bw,100%);max-width:none}
.ba-topbar{position:absolute;top:0;left:0;right:0;z-index:5;display:flex;justify-content:space-between;
  padding:18px 22px;font-size:11px;font-weight:800;letter-spacing:1px;color:#fff;
  background:linear-gradient(180deg,rgba(0,0,0,.32),transparent);pointer-events:none}
.ba-divider{position:absolute;top:0;bottom:0;left:50%;width:2px;background:#fff;z-index:4;
  transform:translateX(-1px);pointer-events:none;box-shadow:0 0 10px rgba(0,0,0,.2)}
.ba-handle{position:absolute;top:50%;left:50%;width:46px;height:46px;border-radius:50%;background:#fff;
  transform:translate(-50%,-50%);z-index:6;display:flex;align-items:center;justify-content:center;gap:3px;
  box-shadow:0 6px 16px rgba(0,0,0,.18);cursor:ew-resize}
.ba-handle svg{width:8px;height:8px}
.hint{text-align:center;font-size:11.5px;color:#a8a8b3;margin:10px 0 32px}

.content{font-size:14.5px;color:#3d3d47;white-space:pre-wrap;line-height:1.9;margin-bottom:28px}

.disclaimer{display:flex;gap:11px;padding:16px 18px;background:#f2f1ee;border-radius:12px;
  font-size:11.5px;color:#9a9aa8;line-height:1.75;margin-bottom:28px}
.disclaimer .ic{flex-shrink:0;width:17px;height:17px;border-radius:50%;background:#e4e3e0;color:#8f8f9a;
  display:flex;align-items:center;justify-content:center;font-size:10.5px;font-weight:800}

.navrow{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:12px}
.navrow a{font-size:12.5px;color:#5a5a66;text-decoration:none;padding:14px 16px;border:1px solid #ececef;
  border-radius:12px;background:#fff;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;
  transition:.15s;font-weight:600}
.navrow a:hover{border-color:#2563eb;color:#2563eb}
.navrow .r{text-align:right}
.backbtn{display:inline-block;font-size:12.5px;color:#5a5a66;text-decoration:none;font-weight:700}
.backbtn:hover{color:#141420}
</style>
</head>
<body>
<div class="shell">
  <div class="split">
    <div class="left">
      <div class="crumb"><a href="./case_list.php">임상케이스</a></div>
      <span class="cat"><?= htmlspecialchars($cat_name) ?></span>
      <h1><?= htmlspecialchars($post['title']) ?></h1>

      <?php if ($post['tags']): ?>
        <div class="hashtags">
          <?php foreach (array_filter(array_map('trim', explode(',', $post['tags']))) as $tg): ?>
            <span>#<?= htmlspecialchars($tg) ?></span>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>

      <div class="meta">
        <span><?= htmlspecialchars($date) ?></span><span class="dot"></span>
        <span>조회 <b><?= (int)$post['hit'] ?></b></span>
      </div>
    </div>

    <div class="right">
      <div class="ba-slider" id="baSlider">
        <div class="ba-topbar"><span>BEFORE PROCEDURE</span><span>AFTER PROCEDURE</span></div>
        <img class="ba-after" src="<?= htmlspecialchars($base . $post['image_after']) ?>" alt="치료 후">
        <div class="ba-before-wrap" id="baBeforeWrap">
          <img id="baBeforeImg" src="<?= htmlspecialchars($base . $post['image_before']) ?>" alt="치료 전">
        </div>
        <div class="ba-divider" id="baDivider"></div>
        <div class="ba-handle" id="baHandle">
          <svg viewBox="0 0 8 12" fill="none"><path d="M6 1L1 6L6 11" stroke="#141420" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>
          <svg viewBox="0 0 8 12" fill="none"><path d="M2 1L7 6L2 11" stroke="#141420" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>
        </div>
      </div>
      <div class="hint">이미지를 좌우로 드래그하면 전/후를 비교할 수 있습니다</div>

      <?php if ($post['content']): ?>
        <div class="content"><?= nl2br(htmlspecialchars($post['content'])) ?></div>
      <?php endif; ?>

      <div class="disclaimer">
        <span class="ic">i</span>
        <span>본 게시물은 실제 내원 환자분의 동의를 받아 게시한 치료 전후 임상 사례입니다. 개인에 따라 진료 및 치료 방법, 효과와 부작용이 다르게 나타날 수 있습니다.</span>
      </div>

      <div class="navrow">
        <a href="<?= $prev ? './case_view.php?id=' . $prev['id'] : '#' ?>"><?= $prev ? '← ' . htmlspecialchars($prev['title']) : '' ?></a>
        <a class="r" href="<?= $next ? './case_view.php?id=' . $next['id'] : '#' ?>"><?= $next ? htmlspecialchars($next['title']) . ' →' : '' ?></a>
      </div>
      <a class="backbtn" href="./case_list.php">← 목록으로</a>
    </div>
  </div>
</div>

<script>
(function(){
  var slider = document.getElementById('baSlider');
  var wrap   = document.getElementById('baBeforeWrap');
  var img    = document.getElementById('baBeforeImg');
  var handle = document.getElementById('baHandle');
  var divider= document.getElementById('baDivider');
  var dragging = false;

  function setPos(pct){
    pct = Math.max(0, Math.min(100, pct));
    wrap.style.width = pct + '%';
    img.style.width  = (slider.offsetWidth) + 'px';
    handle.style.left = pct + '%';
    divider.style.left = pct + '%';
  }
  function fromEvent(e){
    var rect = slider.getBoundingClientRect();
    var x = (e.touches ? e.touches[0].clientX : e.clientX) - rect.left;
    setPos((x / rect.width) * 100);
  }
  handle.addEventListener('mousedown', function(e){ dragging = true; e.preventDefault(); });
  slider.addEventListener('mousedown', function(e){ dragging = true; fromEvent(e); });
  window.addEventListener('mousemove', function(e){ if (dragging) fromEvent(e); });
  window.addEventListener('mouseup', function(){ dragging = false; });

  handle.addEventListener('touchstart', function(){ dragging = true; }, {passive:true});
  slider.addEventListener('touchstart', function(e){ dragging = true; fromEvent(e); }, {passive:true});
  window.addEventListener('touchmove', function(e){ if (dragging) fromEvent(e); }, {passive:true});
  window.addEventListener('touchend', function(){ dragging = false; });

  window.addEventListener('resize', function(){ setPos(parseFloat(wrap.style.width) || 50); });
  setPos(50);
})();
</script>
</body>
</html>
