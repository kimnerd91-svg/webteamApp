<?php
/**
 * inc/auth.php
 * 원본 그누보드 _common.php / _auth_check.php 가 하던 일(세션 로그인 검사, 관리자 변수 세팅,
 * alert()/alert_toast() 헬퍼, G5_DATA_* 상수)을 자체 admin_users 테이블 기반으로 재구현.
 */

// ── 패키지 루트/URL 자동 감지 (uploads 저장 경로용) ─────────────
if (!defined('SAL_BASE_DIR')) define('SAL_BASE_DIR', dirname(__DIR__));
if (!defined('SAL_BASE_URL')) {
    $docroot = isset($_SERVER['DOCUMENT_ROOT']) ? str_replace('\\', '/', rtrim($_SERVER['DOCUMENT_ROOT'], '/')) : '';
    $base    = str_replace('\\', '/', SAL_BASE_DIR);
    $rel     = ($docroot !== '' && strpos($base, $docroot) === 0) ? substr($base, strlen($docroot)) : '';
    define('SAL_BASE_URL', $rel === '' ? '' : $rel);
}

if (session_status() === PHP_SESSION_NONE) {
    // 공유호스팅(카페24 등)은 서브폴더마다 시스템 세션 저장경로(tmp) 쓰기권한이
    // 막혀있는 경우가 있어 로그인 세션이 조용히 안 남는다 — 자체 폴더로 강제 지정.
    $sess_dir = SAL_BASE_DIR . '/data/sessions';
    if (!is_dir($sess_dir)) @mkdir($sess_dir, 0755, true);
    if (is_dir($sess_dir) && is_writable($sess_dir)) {
        session_save_path($sess_dir);
    }
    // 쿠키 경로도 서버 기본값(php.ini)에 기대지 않고 이 패키지 경로로 명시 고정
    // — 기본값이 다른 경로로 잡혀있으면 로그인 직후 리다이렉트된 다음 요청에서
    //   브라우저가 쿠키를 안 보내서 "로그인해도 다시 로그인 화면"처럼 보이는 원인이 됨.
    $cookie_path   = (SAL_BASE_URL === '' ? '/' : SAL_BASE_URL . '/');
    $cookie_secure = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    session_set_cookie_params(0, $cookie_path, '', $cookie_secure, true);
    session_start();
}

// ── 원본 코드 호환용 상수 (G5_DATA_PATH 등) ────────────────────
if (!defined('G5_DATA_PATH'))      define('G5_DATA_PATH', SAL_BASE_DIR . '/data');
if (!defined('G5_DATA_URL'))       define('G5_DATA_URL', SAL_BASE_URL . '/data');
if (!defined('G5_DIR_PERMISSION')) define('G5_DIR_PERMISSION', 0755);
if (!is_dir(G5_DATA_PATH . '/common')) @mkdir(G5_DATA_PATH . '/common', 0755, true);
if (!is_dir(G5_DATA_PATH . '/editor')) @mkdir(G5_DATA_PATH . '/editor', 0755, true);

/** 원본 gnuboard alert(): 메시지 후 지정 URL로 이동(없으면 뒤로가기) */
if (!function_exists('alert')) {
    function alert($msg, $url = '') {
        echo '<script>alert(' . json_encode((string)$msg, JSON_UNESCAPED_UNICODE) . ');';
        if ($url) {
            echo "location.replace(" . json_encode((string)$url, JSON_UNESCAPED_UNICODE) . ");";
        } else {
            echo 'history.back();';
        }
        echo '</script>';
        exit;
    }
}

/** 원본 커스텀 alert_toast(): 토스트 메시지 후 지정 URL로 이동 */
if (!function_exists('alert_toast')) {
    function alert_toast($msg, $url = '', $type = 'default') {
        echo "<style>
            .toast-message{position:fixed;bottom:40px;left:50%;transform:translateX(-50%) translateY(20px);
              background:rgba(255,255,255,.95);color:#333;padding:16px 32px;border-radius:12px;font-size:15px;
              font-weight:600;box-shadow:0 4px 12px rgba(0,0,0,.15);border:1px solid #e5e7eb;
              backdrop-filter:blur(10px);z-index:9999;opacity:0;transition:all .3s ease}
            .toast-message.show{opacity:1;transform:translateX(-50%) translateY(0)}
            .toast-message.success{border-left:4px solid #10b981;color:#059669}
            .toast-message.error{border-left:4px solid #ef4444;color:#dc2626}
            .toast-message.warning{border-left:4px solid #f59e0b;color:#d97706}
        </style>";
        echo "<div id='toast' class='toast-message " . htmlspecialchars($type) . "'>" . htmlspecialchars($msg) . "</div>";
        echo "<script>
            setTimeout(()=>document.getElementById('toast').classList.add('show'),100);
            setTimeout(()=>{
                document.getElementById('toast').classList.remove('show');
                setTimeout(()=>{";
        if ($url) echo "location.replace(" . json_encode((string)$url, JSON_UNESCAPED_UNICODE) . ");";
        echo "},300);
            },1500);
        </script>";
        exit;
    }
}

// ── admin_users 테이블 (없으면 생성 — install.php를 안 돌려도 로그인 화면에서 안내 가능) ──
sql_query("CREATE TABLE IF NOT EXISTS `admin_users` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `username` VARCHAR(100) NOT NULL,
    `password_hash` VARCHAR(255) NOT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", false);

// ── 로그인 상태 → 원본 코드가 참조하는 $is_admin / $member 세팅 ──
$is_admin = false;
$member   = array();

if (!empty($_SESSION['sal_admin_id'])) {
    $is_admin = true;
    $member   = array(
        'mb_id'    => $_SESSION['sal_admin_id'],
        'mb_name'  => $_SESSION['sal_admin_name'] ?? $_SESSION['sal_admin_id'],
        'mb_level' => 10,
    );
}

/**
 * 로그인 필수 페이지에서 최상단에 호출.
 * $redirect_to_login: 로그인 안 되어 있으면 이동할 login.php 상대경로 (기본: 한 단계 위 login.php)
 */
function sal_require_login($redirect_to_login = '../login.php') {
    global $is_admin;
    if (!$is_admin) {
        header('Location: ' . $redirect_to_login . '?url=' . urlencode($_SERVER['REQUEST_URI']));
        exit;
    }
}
