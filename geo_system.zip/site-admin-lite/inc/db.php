<?php
/**
 * inc/db.php
 * 원본(newadm)이 쓰던 그누보드 sql_* 헬퍼 함수들을 mysqli로 재구현.
 * 모듈 코드(site_config.php 등)를 원본 그대로 재사용하기 위한 호환 계층입니다.
 */

if (!defined('SAL_DB_HOST')) {
    require_once __DIR__ . '/../config.php';
}

$GLOBALS['connect_db'] = @mysqli_connect(SAL_DB_HOST, SAL_DB_USER, SAL_DB_PASS, SAL_DB_NAME);

if (!$GLOBALS['connect_db']) {
    http_response_code(500);
    die('DB 연결 실패: config.php의 DB 접속 정보를 확인하세요. (' . mysqli_connect_error() . ')');
}
mysqli_set_charset($GLOBALS['connect_db'], SAL_DB_CHARSET);

/** 원본 코드가 참조하는 $db / $connect_db 별칭 */
$connect_db = $GLOBALS['connect_db'];

/** SELECT 1건 조회 */
function sql_fetch($sql) {
    global $connect_db;
    $result = mysqli_query($connect_db, $sql);
    if (!$result) return array();
    $row = mysqli_fetch_assoc($result);
    return $row ? $row : array();
}

/** SELECT 결과 리소스에서 한 행씩 (while 루프용) */
function sql_fetch_array($result) {
    if (!$result) return false;
    return mysqli_fetch_assoc($result);
}

/** 쿼리 실행 (SELECT 리소스 또는 true/false 반환) */
function sql_query($sql, $die = true) {
    global $connect_db;
    $result = mysqli_query($connect_db, $sql);
    if (!$result && $die) {
        // 운영 중 흰 화면 방지 — 에러만 기록하고 false 반환
        error_log('SQL ERROR: ' . mysqli_error($connect_db) . ' | ' . $sql);
    }
    return $result;
}

/** 조회 결과 행 수 */
function sql_num_rows($result) {
    if (!$result) return 0;
    return mysqli_num_rows($result);
}

/** 마지막 에러 메시지 */
function sql_error() {
    global $connect_db;
    return mysqli_error($connect_db);
}

/** 이스케이프 (두 이름 다 원본에서 혼용되어 둘 다 정의) */
function sql_real_escape_string($str) {
    global $connect_db;
    return mysqli_real_escape_string($connect_db, (string)$str);
}
function sql_escape_string($str) {
    global $connect_db;
    return mysqli_real_escape_string($connect_db, (string)$str);
}
