<?php
/**
 * inc/bootstrap.php
 * 원본 파일들의 include_once('../_common.php'); include_once('./_auth_check.php');
 * 두 줄을 대체하는 단일 진입점. 이 한 줄만 include하면 DB 연결 + 로그인 검사까지 끝남.
 *
 * 사용처: config/site_config.php, config/site_config_update.php,
 *        hospital/page_seo_manager.php, board/column_admin.php, board/column_block_write.php
 * (전부 패키지 루트 기준 한 단계 아래 폴더에 있으므로 로그인 페이지는 '../login.php' 로 고정)
 */

header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Cache-Control: post-check=0, pre-check=0', false);
header('Pragma: no-cache');

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';

sal_require_login('../login.php');
