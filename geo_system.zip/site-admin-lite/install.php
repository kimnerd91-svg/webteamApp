<?php
/**
 * install.php
 * 최초 1회만 실행하는 설치 스크립트.
 *  1) 이 관리자가 쓰는 테이블(dm_config, dm_page_seo, sal_column, sal_column_cat, sal_case, sal_case_cat, admin_users)을 생성
 *  2) 관리자 계정 1개를 생성 (이미 계정이 있으면 계정 생성 폼은 막힘 — 보안)
 * 완료 후에는 이 파일을 서버에서 삭제하거나 접근 제한을 걸어두는 걸 권장합니다.
 */
require_once __DIR__ . '/inc/db.php';
require_once __DIR__ . '/inc/auth.php'; // admin_users 테이블 생성 + G5_DATA_* 상수까지 여기서 처리됨

// ── 나머지 테이블들 생성 (각 모듈 파일도 첫 실행 시 스스로 만들지만, 설치 단계에서 미리 만들어둠) ──
sql_query("CREATE TABLE IF NOT EXISTS `dm_config` (
    `cf_id` INT(11) NOT NULL,
    PRIMARY KEY (`cf_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", false);
sql_query("INSERT IGNORE INTO `dm_config` (`cf_id`) VALUES (1)", false);

// cf_platform: 이 사이트가 어떤 기존 시스템 위에 설치됐는지(cafe24=그누보드 계열 / medis / other)
// site_config.php의 가져오기·저장 write-back 로직이 이 값을 보고 어느 테이블을 건드릴지 결정함
$__plat_col = sql_query("SHOW COLUMNS FROM `dm_config` LIKE 'cf_platform'");
if (!$__plat_col || sql_num_rows($__plat_col) === 0) {
    sql_query("ALTER TABLE `dm_config` ADD `cf_platform` VARCHAR(20) DEFAULT ''", false);
}

sql_query("CREATE TABLE IF NOT EXISTS `dm_page_seo` (
    `id`          INT(11) NOT NULL AUTO_INCREMENT,
    `path`        VARCHAR(255) NOT NULL DEFAULT '',
    `seo_title`   VARCHAR(255) NOT NULL DEFAULT '',
    `seo_desc`    TEXT,
    `og_image`    VARCHAR(500) DEFAULT '',
    `schema_type` VARCHAR(255) DEFAULT '',
    `schema_json` LONGTEXT,
    `updated_at`  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `path` (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", false);

sql_query("CREATE TABLE IF NOT EXISTS `sal_column_cat` (
    `id`   INT(11) NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(100) NOT NULL DEFAULT '',
    `sort` INT(11) DEFAULT 0,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", false);
$chk = sql_fetch("SELECT COUNT(*) as cnt FROM `sal_column_cat`");
if ((int)($chk['cnt'] ?? 0) === 0) sql_query("INSERT INTO `sal_column_cat` (name,sort) VALUES('미분류',0)", false);

sql_query("CREATE TABLE IF NOT EXISTS `sal_column` (
    `id`          INT(11) NOT NULL AUTO_INCREMENT,
    `cat_id`      INT(11) DEFAULT 0,
    `title`       VARCHAR(500) NOT NULL DEFAULT '',
    `subtitle`    VARCHAR(500) NOT NULL DEFAULT '',
    `content`     LONGTEXT,
    `editor_type` VARCHAR(20) DEFAULT 'html',
    `thumbnail`   VARCHAR(500) DEFAULT '',
    `tags`        VARCHAR(500) DEFAULT '',
    `faq`         TEXT,
    `meta_desc`   TEXT,
    `treat_start` VARCHAR(100) DEFAULT '',
    `treat_end`   VARCHAR(100) DEFAULT '',
    `treat_side`  VARCHAR(500) DEFAULT '',
    `hit`         INT(11) DEFAULT 0,
    `created_at`  DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at`  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", false);

// ── 임상케이스(전/후 사진) 테이블 — column_admin.php와 별개 모듈 ──
sql_query("CREATE TABLE IF NOT EXISTS `sal_case_cat` (
    `id`   INT(11) NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(100) NOT NULL DEFAULT '',
    `sort` INT(11) DEFAULT 0,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", false);
$chk_cc = sql_fetch("SELECT COUNT(*) as cnt FROM `sal_case_cat`");
if ((int)($chk_cc['cnt'] ?? 0) === 0) sql_query("INSERT INTO `sal_case_cat` (name,sort) VALUES('미분류',0)", false);

sql_query("CREATE TABLE IF NOT EXISTS `sal_case` (
    `id`            INT(11) NOT NULL AUTO_INCREMENT,
    `cat_id`        INT(11) DEFAULT 0,
    `title`         VARCHAR(500) NOT NULL DEFAULT '',
    `subtitle`      VARCHAR(500) NOT NULL DEFAULT '',
    `content`       TEXT,
    `image_before`  VARCHAR(500) DEFAULT '',
    `image_after`   VARCHAR(500) DEFAULT '',
    `tags`          VARCHAR(500) DEFAULT '',
    `visible`       TINYINT(1) DEFAULT 1,
    `hit`           INT(11) DEFAULT 0,
    `created_at`    DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", false);

// ── 관리자 계정 생성 ──
$existing = sql_fetch("SELECT COUNT(*) as cnt FROM admin_users");
$admin_exists = !empty($existing['cnt']);

$platforms = array(
    'cafe24' => array('label' => '카페24 (그누보드 기반)', 'desc' => 'g5_config 등 그누보드 코어 테이블을 사용하는 사이트'),
    'medis'  => array('label' => 'Medis',                'desc' => 'md_config / md_br 등 Medis 코어 테이블을 사용하는 사이트'),
    'other'  => array('label' => '기타',                  'desc' => '위 둘 다 아니면 선택 — 이 관리자 자체 테이블만 사용'),
);

$msg = '';
if (!$admin_exists && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $u = trim($_POST['username'] ?? '');
    $p = (string)($_POST['password'] ?? '');
    $platform = isset($platforms[$_POST['platform'] ?? '']) ? $_POST['platform'] : 'other';
    if ($u === '' || strlen($p) < 4) {
        $msg = '아이디를 입력하고 비밀번호는 4자 이상으로 설정하세요.';
    } else {
        $hash = password_hash($p, PASSWORD_DEFAULT);
        sql_query("INSERT INTO admin_users (username, password_hash) VALUES ('" . sql_real_escape_string($u) . "', '" . sql_real_escape_string($hash) . "')");
        sql_query("UPDATE dm_config SET cf_platform = '" . sql_real_escape_string($platform) . "' WHERE cf_id = 1");
        header('Location: ./login.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>초기 설치</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0;font-family:-apple-system,'Pretendard',sans-serif}
  body{min-height:100vh;display:flex;align-items:center;justify-content:center;background:#f3f4f6}
  .box{width:420px;background:#fff;border-radius:16px;box-shadow:0 8px 30px rgba(0,0,0,.08);padding:36px}
  h1{font-size:18px;font-weight:800;margin-bottom:8px;color:#111827}
  p.sub{font-size:13px;color:#6b7280;margin-bottom:24px;line-height:1.6}
  label{display:block;font-size:13px;font-weight:600;color:#374151;margin-bottom:6px}
  input{width:100%;padding:11px 12px;border:1px solid #d1d5db;border-radius:8px;font-size:14px;margin-bottom:16px;outline:none}
  button{width:100%;padding:12px;border:none;border-radius:8px;background:#2563eb;color:#fff;font-weight:700;font-size:14px;cursor:pointer}
  .ok{background:#ecfdf5;color:#047857;font-size:13px;padding:12px;border-radius:8px;line-height:1.7}
  .err{background:#fef2f2;color:#dc2626;font-size:13px;padding:10px 12px;border-radius:8px;margin-bottom:16px}
  a.btn{display:inline-block;margin-top:16px;color:#2563eb;font-weight:700;font-size:13px;text-decoration:none}
  .plat_opt{display:block;border:1px solid #d1d5db;border-radius:8px;padding:10px 12px;margin-bottom:8px;cursor:pointer;font-size:13px}
  .plat_opt:has(input:checked){border-color:#2563eb;background:#eff6ff}
  .plat_opt input{width:auto;margin:0 8px 0 0;display:inline-block}
  .plat_opt small{display:block;color:#6b7280;margin-left:20px;font-size:11.5px}
</style>
</head>
<body>
  <div class="box">
    <h1>사이트 관리자 — 초기 설치</h1>
    <?php if ($admin_exists): ?>
      <p class="sub">필요한 테이블은 이미 준비되어 있고, 관리자 계정도 이미 생성되어 있습니다.</p>
      <div class="ok">설치가 이미 완료된 상태입니다. 보안을 위해 이 install.php 파일은 서버에서 삭제하는 걸 권장합니다.</div>
      <a class="btn" href="./login.php">로그인 페이지로 →</a>
      <a class="btn" href="./reset.php" style="color:#dc2626;margin-left:14px;">기존 데이터 초기화하고 새로 설치 →</a>
    <?php else: ?>
      <p class="sub">DB 테이블 생성이 끝났습니다. 이 사이트가 어떤 시스템 기반인지 고르고, 로그인할 계정을 하나 만드세요.</p>
      <?php if ($msg): ?><div class="err"><?= htmlspecialchars($msg) ?></div><?php endif; ?>
      <form method="post">
        <label>기존 사이트 플랫폼</label>
        <?php foreach ($platforms as $key => $p): ?>
          <label class="plat_opt">
            <input type="radio" name="platform" value="<?= htmlspecialchars($key) ?>" <?= $key === 'other' ? 'checked' : '' ?>>
            <?= htmlspecialchars($p['label']) ?>
            <small><?= htmlspecialchars($p['desc']) ?></small>
          </label>
        <?php endforeach; ?>

        <label style="margin-top:8px;">관리자 아이디</label>
        <input type="text" name="username" value="kimnerd91" required autofocus>
        <label>비밀번호 (4자 이상)</label>
        <input type="password" name="password" value="0910" required minlength="4">
        <button type="submit">관리자 계정 생성</button>
      </form>
      <p style="font-size:11.5px;color:#9ca3af;margin-top:10px;line-height:1.6">기본값이 미리 채워져 있습니다(kimnerd91 / 0910). 그대로 생성해도 되고, 원하는 값으로 바꿔도 됩니다 — 생성 후에는 이 폼이 다시 뜨지 않으니 실제 비밀번호는 기억해두세요.</p>
    <?php endif; ?>
  </div>
</body>
</html>
