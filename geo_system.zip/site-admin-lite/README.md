# site-admin-lite

`newadm260702.zip`(기존 관리자)에서 **site_config / page_seo_manager / column_admin(+column_block_write)** 3개 모듈만
그누보드(Gnuboard) 의존 없이 어느 PHP+MySQL 호스팅에도 올릴 수 있게 독립 포장한 버전입니다.

## 무엇이 바뀌었나

- 원본은 `../_common.php` → 그누보드 `common.php` → 회원(mb_level≥10) 인증까지 전부 그누보드 설치가 있어야 동작했음.
- 이 버전은 `inc/db.php`(mysqli 연결 + sql_query/sql_fetch 등 호환 함수) + `inc/auth.php`(자체 `admin_users` 테이블 기반 로그인)로
  그누보드 없이 동작하도록 대체함.
- 3개 모듈의 **업무 로직(HTML/JS/DB 쿼리)은 원본 그대로**이고, 상단 include 2~3줄과 하드코딩된 `/newadm`, `/bbs/login.php` 절대경로만
  상대경로(`../inc/bootstrap.php`, `../login.php`)로 바꿨습니다.

## 설치 방법

1. 이 폴더 전체를 원하는 사이트의 웹 루트(또는 원하는 서브폴더)에 업로드 (FTP).
2. `config.php`를 열어 DB 접속정보 4개(호스트/계정/비번/DB명)를 채움. 이 사이트가 이미 쓰는 DB를 그대로 넣으면
   `dm_config`, `dm_page_seo`, `sal_column`, `sal_column_cat` 테이블을 자동 생성/사용합니다(테이블명이 겹치지 않으면 새로 만듦).
3. 브라우저로 `/설치경로/install.php` 접속 → **이 사이트가 어떤 시스템 기반인지(카페24=그누보드 / Medis / 기타) 선택** 후
   관리자 계정(아이디/비번) 1개 생성. 이 선택값은 `dm_config.cf_platform`에 저장되고, 사이트 설정 화면의
   "가져오기"/저장 시 write-back이 어느 플랫폼 테이블을 건드릴지 결정하는 데 쓰입니다.
4. `/설치경로/login.php` 로 로그인 → 대시보드에서 메뉴 이용.

## 포함된 메뉴

- **사이트 설정** (`config/site_config.php`) — 사이트명/주소/전화/설명 등. 그누보드(g5_config)나 Medis(md_config/md_br)
  기반 사이트면 "기존 시스템에서 가져오기" 버튼으로 값을 채우고, 저장 시 원본 테이블에도 되돌려 써서(write-back)
  실제 화면(title/description)에 바로 반영되도록 함.
- **SEO·스키마 관리** (`hospital/page_seo_manager.php`) — 페이지별 title/description/OG/schema.org 관리.
  실제 화면에 반영되려면 대상 사이트의 컨트롤러 파일에 조회 코드를 심어야 함 (아래 "코드 패처" 참고).
- **칼럼 관리** (`board/column_admin.php`, `board/column_block_write.php`) — 칼럼 작성/수정/카테고리.
- **칼럼 공개 페이지** (`sub/column_list.php`, `sub/column.php`) — 방문자가 보는 목록/상세 페이지.
  Bootstrap 5 + setting.css 유틸리티 클래스 기반의 자체 마크업이며 어느 사이트에 심어도 동작합니다.
- **코드 패처** (`config/patch_installer.php`) — 대상 사이트의 특정 PHP 파일에 연동 코드를 자동 삽입 (자동 백업 포함).
  현재 프리셋: "Medis 페이지별 SEO override".
5. 설치가 끝나면 보안을 위해 `install.php`는 삭제하거나 서버 접근을 막아두세요.

## 폴더 구조

```
site-admin-lite/
├── config.php              ← DB 접속정보 (직접 수정)
├── install.php              ← 최초 1회 설치
├── login.php / logout.php
├── index.php                ← 대시보드
├── aside.php                 ← 3개 모듈 공용 사이드바
├── inc/
│   ├── db.php                ← mysqli 연결 + sql_* 호환 함수
│   ├── auth.php               ← 세션 로그인 검사, alert()/alert_toast(), G5_DATA_* 상수
│   └── bootstrap.php          ← 위 2개를 한 번에 불러오는 진입점
├── assets/admin.css
├── data/common, data/editor   ← 로고/파비콘/OG이미지, 칼럼 본문 이미지 업로드 저장 위치
├── config/site_config.php + site_config_update.php   ← 사이트 설정
├── hospital/page_seo_manager.php                      ← 페이지별 SEO/스키마 관리
└── board/column_admin.php + column_block_write.php    ← 칼럼 관리
```

## ⚠️ 반드시 알아야 할 것 — "관리자"와 "프론트엔드 출력"은 별개입니다

이 패키지는 **DB를 편집하는 백오피스(관리자 화면)** 입니다. 예를 들어 SEO 관리에서 특정 페이지의 title/description을
입력해 저장하면 `dm_page_seo` 테이블에 잘 들어갑니다. 하지만 그 값이 실제 방문자가 보는 페이지 `<head>`에 찍히려면,
**대상 사이트의 페이지 템플릿에도** "현재 경로로 dm_page_seo를 조회해서 `<title>`/`<meta>`를 출력하는" 코드가
있어야 합니다 (원본 사이트에서는 `head_sub.php` 같은 파일이 이 역할을 함). 마찬가지로 칼럼(`sal_column`)이 실제
목록/상세 페이지로 보이려면 대상 사이트에 그 페이지 템플릿이 따로 필요합니다.

즉 이 3개 관리자는 "쓰는 곳"이고, 그 값을 "보여주는 곳"(프론트엔드 템플릿)은 사이트마다 새로 붙여야 합니다.
필요하면 그 프론트엔드 출력용 스니펫도 만들어드릴 수 있습니다.

## 보안 체크리스트

- `admin_users` 비밀번호는 `password_hash()`로 저장됨(원문 저장 아님).
- `config.php`, `data/` 폴더는 외부에서 직접 다운로드되지 않도록 웹서버 설정(또는 `.htaccess`)으로 막는 걸 권장.
- `install.php`는 설치 후 삭제 권장.
