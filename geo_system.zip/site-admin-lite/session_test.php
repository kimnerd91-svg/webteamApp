<?php
/**
 * session_test.php — 로그인 세션이 실제로 유지되는지 바로 확인하는 진단 도구.
 * 문제 생기면 이 파일 열어서 새로고침 3번 해보면 원인이 세션인지 아닌지 바로 갈림.
 */
require_once __DIR__ . '/inc/auth.php';

$count = $_SESSION['sal_test_count'] ?? 0;
$count++;
$_SESSION['sal_test_count'] = $count;
?>
<!DOCTYPE html>
<html lang="ko">
<head><meta charset="UTF-8"><title>세션 진단</title>
<style>body{font-family:-apple-system,sans-serif;padding:40px;max-width:600px;margin:0 auto;line-height:1.8}
.box{background:#f9fafb;border:1px solid #e5e7eb;border-radius:12px;padding:20px 24px;margin-top:16px}
.big{font-size:32px;font-weight:800;color:#2563eb}
code{background:#eef2ff;padding:2px 8px;border-radius:6px;font-size:13px}</style>
</head>
<body>
<h1>세션 진단</h1>
<div class="box">
  <div class="big"><?= $count ?></div>
  <p>이 숫자는 새로고침할 때마다 1씩 늘어나야 정상입니다.</p>
</div>
<div class="box">
  <p><b>세션 ID:</b> <code><?= htmlspecialchars(session_id()) ?></code></p>
  <p><b>세션 저장경로:</b> <code><?= htmlspecialchars(session_save_path()) ?></code></p>
  <p><b>쿠키로 세션ID 수신됨:</b> <?= isset($_COOKIE[session_name()]) ? '✅ 예 (' . htmlspecialchars($_COOKIE[session_name()]) . ')' : '❌ 아니오 — 쿠키 자체가 안 옴' ?></p>
  <p><b>현재 로그인 상태:</b> <?= $is_admin ? '✅ 로그인됨 (' . htmlspecialchars($member['mb_id']) . ')' : '❌ 로그인 안 됨' ?></p>
</div>
<p style="margin-top:20px;color:#6b7280;font-size:13px;">
  새로고침(F5)을 3번 눌러보세요.<br>
  - 숫자가 계속 늘어나면 → 세션은 정상. 로그인 자체(비번 확인) 쪽 문제입니다.<br>
  - 숫자가 계속 1로 리셋되면 → 세션이 아예 유지가 안 되는 것 (서버 세션 저장 문제).<br>
  - "쿠키로 세션ID 수신됨"이 계속 ❌면 → 브라우저가 쿠키 자체를 저장/전송 안 하는 것(쿠키 설정 문제).
</p>
<p style="margin-top:16px;"><a href="./login.php">로그인 페이지로</a></p>
</body>
</html>
