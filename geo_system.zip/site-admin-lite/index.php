<?php
require_once __DIR__ . '/inc/db.php';
require_once __DIR__ . '/inc/auth.php';
sal_require_login('./login.php');

$col_count  = sql_fetch("SELECT COUNT(*) as cnt FROM sal_column");
$case_count = sql_fetch("SELECT COUNT(*) as cnt FROM sal_case");
$seo_count  = sql_fetch("SELECT COUNT(*) as cnt FROM dm_page_seo");
$base = SAL_BASE_URL;
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>사이트 관리자 — 대시보드</title>
<link rel="stylesheet" href="<?= $base ?>/assets/admin.css">
</head>
<body>
<div class="sal_layout">
    <?php include __DIR__ . '/aside.php'; ?>
    <main class="sal_main">
        <h1>대시보드</h1>
        <p class="sal_welcome">안녕하세요, <?= htmlspecialchars($member['mb_name'] ?? '') ?>님.</p>
        <div class="sal_cards">
            <a class="sal_card" href="<?= $base ?>/config/site_config.php">
                <h3>사이트 설정</h3>
                <p>사이트명, 주소/전화, 소셜, robots.txt·sitemap.xml 자동생성</p>
            </a>
            <a class="sal_card" href="<?= $base ?>/hospital/page_seo_manager.php">
                <h3>SEO·스키마 관리</h3>
                <p>페이지별 title/description/OG 이미지, schema.org JSON-LD</p>
                <span class="sal_badge"><?= (int)($seo_count['cnt'] ?? 0) ?>개 페이지 등록됨</span>
            </a>
            <a class="sal_card" href="<?= $base ?>/board/column_admin.php">
                <h3>칼럼 관리</h3>
                <p>칼럼 작성/수정/카테고리 관리</p>
                <span class="sal_badge"><?= (int)($col_count['cnt'] ?? 0) ?>개 칼럼</span>
            </a>
            <a class="sal_card" href="<?= $base ?>/board/case_admin.php">
                <h3>임상케이스 관리</h3>
                <p>치료 전/후 사진 케이스 등록·관리</p>
                <span class="sal_badge"><?= (int)($case_count['cnt'] ?? 0) ?>개 케이스</span>
            </a>
            <a class="sal_card" href="<?= $base ?>/config/patch_installer.php">
                <h3>코드 패처</h3>
                <p>기존 사이트 파일에 연동 코드를 버튼 클릭으로 자동 삽입 (자동 백업 포함)</p>
            </a>
        </div>
    </main>
</div>
</body>
</html>
