<?php
require_once __DIR__ . '/../inc/bootstrap.php';

// ============================================================
// 코드 패처: 대상 사이트의 특정 파일에 site-admin-lite 연동 스니펫을
// 버튼 클릭으로 자동 삽입. "앵커 문자열을 찾아 그 자리에 코드 삽입"
// 방식이라 사이트마다 손으로 FTP 열어서 붙여넣을 필요가 없음.
// 안전장치: 삽입 전 자동 백업, 중복삽입 방지 마커, 앵커 못 찾으면 중단.
// ============================================================

define('SAL_PATCH_MARK', '[site-admin-lite]');

$PRESETS = array(
    'medis_seo' => array(
        'label'  => 'Medis — 페이지별 SEO override (컨트롤러 파일용)',
        'desc'   => '$config["site_title"] / $config["description"]를 계산하는 컨트롤러(예: include/_top.php)에 붙입니다. dm_page_seo에 저장된 값이 있으면 그 페이지만 title/description을 덮어씁니다.',
        'anchor' => '$config["menu_seq"] = $MENU->menu[$origin_mc]["menu_seq"];',
        'snippet' => <<<'SNIP'
//====================== [site-admin-lite] 페이지별 SEO override [S] ======================//
$__sal_path = parse_url($_SERVER["REQUEST_URI"], PHP_URL_PATH);
$__sal_qs   = parse_url($_SERVER["REQUEST_URI"], PHP_URL_QUERY);
if ($__sal_qs) {
    parse_str($__sal_qs, $__sal_q);
    if (!empty($__sal_q["id"])) {
        $__sal_path .= "?id=" . preg_replace("/[^0-9A-Za-z_-]/", "", $__sal_q["id"]);
    }
}
$sqlString  = "Select * From dm_page_seo Where path = '" . str_replace("'", "\\'", $__sal_path) . "' Limit 1";
$__sal_seo  = sql_fetch($sqlString);
if ($__sal_seo) {
    if (!empty($__sal_seo["seo_title"])) $config["site_title"]  = $__sal_seo["seo_title"];
    if (!empty($__sal_seo["seo_desc"]))  $config["description"] = $__sal_seo["seo_desc"];
    if (!empty($__sal_seo["schema_json"])) $config["sal_schema_json"] = $__sal_seo["schema_json"];
}
//====================== [site-admin-lite] 페이지별 SEO override [E] ======================//

SNIP
    ),
);

function sal_resolve_path($rel) {
    $rel = '/' . ltrim(str_replace('..', '', $rel), '/');
    return rtrim($_SERVER['DOCUMENT_ROOT'], '/') . $rel;
}

// ── AJAX: 미리보기(앵커/패치여부 확인) ──
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'preview') {
    header('Content-Type: application/json; charset=utf-8');
    $rel = trim($_POST['target_path'] ?? '');
    $preset_key = $_POST['preset'] ?? '';
    $preset = $PRESETS[$preset_key] ?? null;
    if (!$preset) { echo json_encode(['success'=>false,'message'=>'프리셋을 찾을 수 없습니다.']); exit; }
    if ($rel === '') { echo json_encode(['success'=>false,'message'=>'경로를 입력하세요.']); exit; }

    $abs = sal_resolve_path($rel);
    if (!is_file($abs)) {
        echo json_encode(['success'=>false,'message'=>'파일을 찾을 수 없습니다: ' . $abs]);
        exit;
    }
    $content = file_get_contents($abs);
    $already = strpos($content, SAL_PATCH_MARK) !== false;
    $anchor_found = strpos($content, $preset['anchor']) !== false;
    $writable = is_writable($abs);

    echo json_encode(array(
        'success'       => true,
        'abs_path'      => $abs,
        'size'          => strlen($content),
        'already'       => $already,
        'anchor_found'  => $anchor_found,
        'writable'      => $writable,
    ));
    exit;
}

// ── AJAX: 실제 패치 적용 ──
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'apply') {
    header('Content-Type: application/json; charset=utf-8');
    $rel = trim($_POST['target_path'] ?? '');
    $preset_key = $_POST['preset'] ?? '';
    $preset = $PRESETS[$preset_key] ?? null;
    if (!$preset) { echo json_encode(['success'=>false,'message'=>'프리셋을 찾을 수 없습니다.']); exit; }

    $abs = sal_resolve_path($rel);
    if (!is_file($abs))    { echo json_encode(['success'=>false,'message'=>'파일을 찾을 수 없습니다.']); exit; }
    if (!is_writable($abs)) { echo json_encode(['success'=>false,'message'=>'파일 쓰기 권한이 없습니다.']); exit; }

    $content = file_get_contents($abs);
    if (strpos($content, SAL_PATCH_MARK) !== false) {
        echo json_encode(['success'=>false,'message'=>'이미 패치되어 있습니다(중복 방지를 위해 중단).']);
        exit;
    }
    if (strpos($content, $preset['anchor']) === false) {
        echo json_encode(['success'=>false,'message'=>'앵커 코드를 파일에서 찾지 못했습니다. 파일 구조가 예상과 달라 자동 삽입을 중단합니다.']);
        exit;
    }

    $backup_path = $abs . '.sal-bak-' . date('YmdHis');
    if (!copy($abs, $backup_path)) {
        echo json_encode(['success'=>false,'message'=>'백업 생성 실패 — 안전을 위해 중단합니다.']);
        exit;
    }

    $new_content = str_replace($preset['anchor'], $preset['snippet'] . $preset['anchor'], $content);
    $ok = @file_put_contents($abs, $new_content);

    if ($ok === false) {
        copy($backup_path, $abs);
        echo json_encode(['success'=>false,'message'=>'파일 쓰기 실패, 백업에서 자동 복원했습니다.']);
        exit;
    }

    echo json_encode(array('success' => true, 'message' => '패치 완료.', 'backup' => basename($backup_path)));
    exit;
}

// ── AJAX: 백업 목록 ──
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'list_backups') {
    header('Content-Type: application/json; charset=utf-8');
    $rel = trim($_POST['target_path'] ?? '');
    $abs = sal_resolve_path($rel);
    $dir = dirname($abs);
    $base = basename($abs);
    $backups = array();
    if (is_dir($dir)) {
        foreach (scandir($dir) as $f) {
            if (strpos($f, $base . '.sal-bak-') === 0) $backups[] = $f;
        }
    }
    rsort($backups);
    echo json_encode(array('success' => true, 'backups' => $backups));
    exit;
}

// ── AJAX: 백업으로 되돌리기 ──
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'restore') {
    header('Content-Type: application/json; charset=utf-8');
    $rel = trim($_POST['target_path'] ?? '');
    $backup_name = basename($_POST['backup'] ?? '');
    $abs = sal_resolve_path($rel);
    $backup_abs = dirname($abs) . '/' . $backup_name;
    if (!is_file($backup_abs)) { echo json_encode(['success'=>false,'message'=>'백업 파일을 찾을 수 없습니다.']); exit; }
    $ok = copy($backup_abs, $abs);
    echo json_encode(array('success' => (bool)$ok));
    exit;
}
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>코드 패처 — 사이트 관리자</title>
<link rel="stylesheet" href="<?= defined('SAL_BASE_URL') ? SAL_BASE_URL : '' ?>/assets/admin.css">
<style>
  .pi_wrap{max-width:820px}
  .pi_field{margin-bottom:16px}
  .pi_field label{display:block;font-size:13px;font-weight:700;margin-bottom:6px;color:#111827}
  .pi_field input[type=text], .pi_field select{width:100%;padding:10px 12px;border:1px solid #d1d5db;border-radius:8px;font-size:13.5px}
  .pi_hint{font-size:12px;color:#6b7280;margin-top:4px;line-height:1.5}
  .pi_status{display:flex;gap:10px;flex-wrap:wrap;margin:14px 0}
  .pi_badge{font-size:12px;font-weight:700;padding:5px 10px;border-radius:999px}
  .pi_ok{background:#ecfdf5;color:#047857}
  .pi_bad{background:#fef2f2;color:#dc2626}
  .pi_muted{background:#f3f4f6;color:#6b7280}
  .pi_btnrow{display:flex;gap:10px;margin-top:16px}
  .pi_btn{padding:10px 18px;border:none;border-radius:8px;font-weight:700;font-size:13.5px;cursor:pointer}
  .pi_btn.primary{background:#2563eb;color:#fff}
  .pi_btn.ghost{background:#f3f4f6;color:#374151}
  .pi_btn:disabled{opacity:.5;cursor:not-allowed}
  .pi_msg{margin-top:14px;padding:12px 14px;border-radius:8px;font-size:13px;display:none}
  .pi_msg.show{display:block}
  .pi_msg.success{background:#ecfdf5;color:#047857}
  .pi_msg.error{background:#fef2f2;color:#dc2626}
  .pi_backups{margin-top:20px}
  .pi_backups ul{list-style:none;padding:0;margin:8px 0 0}
  .pi_backups li{display:flex;justify-content:space-between;align-items:center;padding:8px 12px;background:#f9fafb;border-radius:8px;margin-bottom:6px;font-size:12.5px}
  .pi_snippet{background:#0d1117;color:#e6edf3;padding:14px;border-radius:8px;font-size:12px;overflow:auto;white-space:pre;margin-top:8px;max-height:260px}
</style>
</head>
<body>
<div class="sal_layout">
    <?php include __DIR__ . '/../aside.php'; ?>
    <main class="sal_main pi_wrap">
        <h1>코드 패처</h1>
        <p class="sal_welcome">기존 사이트의 특정 PHP 파일에 site-admin-lite 연동 코드를 자동으로 삽입합니다. 매번 FTP 열어서 직접 붙여넣을 필요 없이, 경로만 지정하고 버튼을 누르면 됩니다. 적용 전 항상 자동 백업을 만듭니다.</p>

        <div class="section_card" style="background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:20px;">
            <div class="pi_field">
                <label>연동 스니펫 선택</label>
                <select id="presetSelect">
                    <?php foreach ($PRESETS as $key => $p): ?>
                        <option value="<?= htmlspecialchars($key) ?>"><?= htmlspecialchars($p['label']) ?></option>
                    <?php endforeach; ?>
                </select>
                <div class="pi_hint" id="presetDesc"></div>
            </div>

            <div class="pi_field">
                <label>대상 파일 경로 (웹 루트 기준, 예: /include/_top.php)</label>
                <input type="text" id="targetPath" placeholder="/include/_top.php">
                <div class="pi_hint">웹사이트 최상위 폴더(document root)를 기준으로 한 경로입니다. 도메인이나 절대 서버 경로는 필요 없습니다.</div>
            </div>

            <div class="pi_btnrow">
                <button class="pi_btn ghost" id="btnPreview">미리보기 확인</button>
                <button class="pi_btn primary" id="btnApply" disabled>패치 적용</button>
            </div>

            <div class="pi_status" id="statusRow"></div>
            <div class="pi_msg" id="msgBox"></div>

            <div class="pi_snippet" id="snippetPreview" style="display:none;"></div>

            <div class="pi_backups" id="backupSection" style="display:none;">
                <strong style="font-size:13px;">백업 목록 (되돌리기)</strong>
                <ul id="backupList"></ul>
            </div>
        </div>
    </main>
</div>

<script>
var PRESETS = <?= json_encode($PRESETS, JSON_UNESCAPED_UNICODE) ?>;

var presetSelect = document.getElementById('presetSelect');
var presetDesc   = document.getElementById('presetDesc');
var targetPath   = document.getElementById('targetPath');
var btnPreview   = document.getElementById('btnPreview');
var btnApply     = document.getElementById('btnApply');
var statusRow    = document.getElementById('statusRow');
var msgBox       = document.getElementById('msgBox');
var snippetPreview = document.getElementById('snippetPreview');
var backupSection = document.getElementById('backupSection');
var backupList     = document.getElementById('backupList');

function updateDesc() {
    var p = PRESETS[presetSelect.value];
    presetDesc.textContent = p ? p.desc : '';
    snippetPreview.style.display = 'block';
    snippetPreview.textContent = p ? p.snippet : '';
}
presetSelect.addEventListener('change', updateDesc);
updateDesc();

function showMsg(text, type) {
    msgBox.className = 'pi_msg show ' + type;
    msgBox.textContent = text;
}

function badge(text, cls) {
    return '<span class="pi_badge ' + cls + '">' + text + '</span>';
}

btnPreview.addEventListener('click', function() {
    statusRow.innerHTML = '';
    msgBox.className = 'pi_msg';
    btnApply.disabled = true;

    var fd = new FormData();
    fd.append('action', 'preview');
    fd.append('target_path', targetPath.value);
    fd.append('preset', presetSelect.value);

    fetch('', { method: 'POST', body: fd })
        .then(function(r){ return r.json(); })
        .then(function(d){
            if (!d.success) {
                showMsg(d.message || '확인 실패', 'error');
                return;
            }
            var html = '';
            html += badge('파일 크기 ' + d.size + 'B', 'pi_muted');
            html += d.writable ? badge('쓰기 가능', 'pi_ok') : badge('쓰기 권한 없음', 'pi_bad');
            html += d.anchor_found ? badge('앵커 발견됨', 'pi_ok') : badge('앵커를 못 찾음', 'pi_bad');
            html += d.already ? badge('이미 패치됨', 'pi_bad') : badge('아직 패치 안 됨', 'pi_ok');
            statusRow.innerHTML = html;

            btnApply.disabled = !(d.writable && d.anchor_found && !d.already);

            loadBackups();
        })
        .catch(function(e){ showMsg('오류: ' + e.message, 'error'); });
});

btnApply.addEventListener('click', function() {
    if (!confirm('실제 서버 파일을 수정합니다. 계속할까요? (적용 전 자동 백업됩니다)')) return;
    btnApply.disabled = true;
    btnApply.textContent = '적용 중...';

    var fd = new FormData();
    fd.append('action', 'apply');
    fd.append('target_path', targetPath.value);
    fd.append('preset', presetSelect.value);

    fetch('', { method: 'POST', body: fd })
        .then(function(r){ return r.json(); })
        .then(function(d){
            if (d.success) {
                showMsg('✅ ' + d.message + ' (백업: ' + d.backup + ')', 'success');
            } else {
                showMsg('❌ ' + d.message, 'error');
            }
            btnApply.textContent = '패치 적용';
            loadBackups();
        })
        .catch(function(e){
            showMsg('오류: ' + e.message, 'error');
            btnApply.textContent = '패치 적용';
        });
});

function loadBackups() {
    var fd = new FormData();
    fd.append('action', 'list_backups');
    fd.append('target_path', targetPath.value);

    fetch('', { method: 'POST', body: fd })
        .then(function(r){ return r.json(); })
        .then(function(d){
            if (!d.success || !d.backups.length) {
                backupSection.style.display = 'none';
                return;
            }
            backupSection.style.display = 'block';
            backupList.innerHTML = '';
            d.backups.forEach(function(b) {
                var li = document.createElement('li');
                var span = document.createElement('span');
                span.textContent = b;
                var btn = document.createElement('button');
                btn.className = 'pi_btn ghost';
                btn.style.padding = '4px 10px';
                btn.style.fontSize = '11.5px';
                btn.textContent = '이 시점으로 되돌리기';
                btn.addEventListener('click', function() {
                    if (!confirm(b + ' 상태로 되돌릴까요?')) return;
                    var fd2 = new FormData();
                    fd2.append('action', 'restore');
                    fd2.append('target_path', targetPath.value);
                    fd2.append('backup', b);
                    fetch('', { method: 'POST', body: fd2 })
                        .then(function(r){ return r.json(); })
                        .then(function(d2){
                            showMsg(d2.success ? '✅ 되돌렸습니다.' : '❌ 되돌리기 실패', d2.success ? 'success' : 'error');
                        });
                });
                li.appendChild(span);
                li.appendChild(btn);
                backupList.appendChild(li);
            });
        });
}
</script>
</body>
</html>
