<?php
// ============ 설정 ============
$column_label = '원장님 칼럼';
$upload_dir   = '/uploads/column';
$table        = 'sal_column';
$cat_table    = 'sal_column_cat';
// ==============================

require_once __DIR__ . '/../inc/bootstrap.php';

// 패키지가 어디에 설치되든 공개 칼럼 페이지(sub/) 경로가 항상 맞도록 동적 계산
$column_path = (defined('SAL_BASE_URL') ? SAL_BASE_URL : '') . '/sub';

global $connect_db;
$db = $connect_db;

// ── 테이블 자동 생성 ─────────────────────────────────────
mysqli_query($db, "CREATE TABLE IF NOT EXISTS `{$cat_table}` (
    `id`   INT(11) NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(100) NOT NULL DEFAULT '',
    `sort` INT(11) DEFAULT 0,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$chk = mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) as cnt FROM `{$cat_table}`"));
if ((int)$chk['cnt'] === 0) mysqli_query($db, "INSERT INTO `{$cat_table}` (name,sort) VALUES('미분류',0)");

mysqli_query($db, "CREATE TABLE IF NOT EXISTS `{$table}` (
    `id`          INT(11) NOT NULL AUTO_INCREMENT,
    `cat_id`      INT(11) DEFAULT 0,
    `title`       VARCHAR(500) NOT NULL DEFAULT '',
    `subtitle`    VARCHAR(500) NOT NULL DEFAULT '',
    `content`     LONGTEXT,
    `editor_type` VARCHAR(20) DEFAULT 'html',
    `thumbnail`   VARCHAR(500) DEFAULT '',
    `tags`        VARCHAR(500) DEFAULT '',
    `faq`         TEXT,
    `meta_desc`   TEXT,
    `treat_start` VARCHAR(100) DEFAULT '',
    `treat_end`   VARCHAR(100) DEFAULT '',
    `treat_side`  VARCHAR(500) DEFAULT '',
    `hit`         INT(11) DEFAULT 0,
    `created_at`  DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at`  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$add_cols = [
    'cat_id'      => "ADD COLUMN `cat_id` INT(11) DEFAULT 0 AFTER `id`",
    'subtitle'    => "ADD COLUMN `subtitle` VARCHAR(500) DEFAULT '' AFTER `title`",
    'editor_type' => "ADD COLUMN `editor_type` VARCHAR(20) DEFAULT 'html' AFTER `content`",
    'meta_desc'   => "ADD COLUMN `meta_desc` TEXT AFTER `faq`",
    'treat_start' => "ADD COLUMN `treat_start` VARCHAR(100) DEFAULT '' AFTER `meta_desc`",
    'treat_end'   => "ADD COLUMN `treat_end` VARCHAR(100) DEFAULT '' AFTER `treat_start`",
    'treat_side'  => "ADD COLUMN `treat_side` VARCHAR(500) DEFAULT '' AFTER `treat_end`",
    'updated_at'  => "ADD COLUMN `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER `created_at`",
];
foreach ($add_cols as $col => $sql) {
    $c = mysqli_query($db, "SHOW COLUMNS FROM `{$table}` LIKE '{$col}'");
    if (mysqli_num_rows($c) === 0) mysqli_query($db, "ALTER TABLE `{$table}` {$sql}");
}

// ── 카테고리 목록 ─────────────────────────────────────────
function get_cats($db, $cat_table)
{
    $cats = [];
    $r = mysqli_query($db, "SELECT * FROM `{$cat_table}` ORDER BY sort ASC, id ASC");
    if ($r) while ($c = mysqli_fetch_assoc($r)) $cats[] = $c;
    return $cats;
}
$cats = get_cats($db, $cat_table);

// ── 외부 이미지 자동 재호스팅 ──────────────────────────────
// 저장 직전, 본문 안의 <img src="https://..."> 중 이 사이트 소유가 아닌 절대 URL을
// 실제로 다운로드해서 내 data/editor 폴더로 옮기고 src를 로컬 경로로 바꿔치기한다.
// (원본 서버가 나중에 사라지거나 막혀도 이미지가 안 깨지게 하기 위함)
// 주의: src가 슬래시 없는 상대경로("uploads/x.jpg")면 원래 어느 도메인 기준인지
// 알 수 없어 손댈 수 없다 — 이런 건 그대로 남는다(원본 쪽에서 절대경로로 고쳐야 함).
function rehost_external_images($content) {
    if (!$content || strpos($content, '<img') === false) return $content;
    $up_base = G5_DATA_PATH . '/editor/' . date('Ym');
    $up_url  = G5_DATA_URL . '/editor/' . date('Ym');
    if (!is_dir($up_base)) @mkdir($up_base, 0755, true);

    return preg_replace_callback('/(<img\b[^>]*\bsrc=["\'])([^"\']+)(["\'])/i', function ($m) use ($up_base, $up_url) {
        $src = $m[2];
        // 이미 이 사이트 자체 경로거나 base64면 건드리지 않음
        if (strpos($src, $up_url) !== false) return $m[0];
        if (stripos($src, 'data:') === 0) return $m[0];
        // http(s) 절대 URL만 재호스팅 대상 — 상대경로는 원본을 특정할 수 없어 그대로 둠
        if (!preg_match('~^https?://~i', $src)) return $m[0];

        $ctx  = stream_context_create(['http' => ['timeout' => 8, 'user_agent' => 'Mozilla/5.0'], 'https' => ['timeout' => 8]]);
        $data = @file_get_contents($src, false, $ctx);
        if (!$data) return $m[0];   // 다운로드 실패 시 원본 URL 유지(사이트는 안 죽게)

        $ext = strtolower(pathinfo(parse_url($src, PHP_URL_PATH) ?: '', PATHINFO_EXTENSION));
        if (!in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'gif'], true)) $ext = 'jpg';
        $fname = 'reh_' . time() . '_' . substr(md5($src), 0, 8) . '.' . $ext;
        if (@file_put_contents($up_base . '/' . $fname, $data) === false) return $m[0];

        return $m[1] . $up_url . '/' . $fname . $m[3];
    }, $content);
}

// ── HTML 파싱 헬퍼 ────────────────────────────────────────
function semantic_convert($tag, $inner, $node)
{
    $text = trim(strip_tags($inner));
    $len  = mb_strlen($text);
    $quote_chars = ['"', '"', "'", "「", "『"];
    foreach ($quote_chars as $q) {
        if (mb_substr($text, 0, 1) === $q) return 'blockquote';
    }
    if ($tag === 'p' && $len >= 10 && $len <= 120) {
        $stripped = preg_replace('/<(strong|em|b|i)[^>]*>.*?<\/(strong|em|b|i)>/i', '', $inner);
        if (trim(strip_tags($stripped)) === '') return 'blockquote';
    }
    if ($node) {
        $cls = strtolower($node->getAttribute('class') ?? '');
        foreach (['tip', 'warn', 'notice', 'box', 'callout', 'highlight', 'quote'] as $kw) {
            if (strpos($cls, $kw) !== false) return 'blockquote';
        }
    }
    if (in_array($tag, ['p', 'div']) && $len > 0 && $len <= 8) {
        $clean = preg_replace('/[\s\-·\.·\*\~_=]/u', '', $text);
        if ($clean === '') return 'hr';
    }
    if (in_array($tag, ['p', 'div', 'span']) && $len > 0 && $len <= 40) {
        $no_bold = preg_replace('/<(strong|b)[^>]*>.*?<\/(strong|b)>/i', '', $inner);
        if (trim(strip_tags($no_bold)) === '') return 'h3';
    }
    return $tag;
}

function normalize_node($node, $dom, $allowed)
{
    $html = '';
    foreach ($node->childNodes as $child) {
        if ($child->nodeType === XML_TEXT_NODE) {
            $t = trim($child->textContent);
            if ($t !== '') $html .= htmlspecialchars($t, ENT_QUOTES, 'UTF-8');
        } elseif ($child->nodeType === XML_ELEMENT_NODE) {
            $tag = strtolower($child->nodeName);
            if (!in_array($tag, $allowed)) {
                $html .= normalize_node($child, $dom, $allowed);
                continue;
            }
            if ($tag === 'img') {
                $src = $child->getAttribute('src');
                $alt = $child->getAttribute('alt');
                $attrs = '';
                if ($src) $attrs .= ' src="' . htmlspecialchars($src) . '"';
                if ($alt) $attrs .= ' alt="' . htmlspecialchars($alt) . '"';
                $html .= '<img' . $attrs . ' style="max-width:100%">';
                continue;
            }
            $attrs = '';
            if ($tag === 'a') {
                $href = $child->getAttribute('href');
                if ($href) $attrs .= ' href="' . htmlspecialchars($href) . '"';
            }
            $inner = normalize_node($child, $dom, $allowed);
            if (in_array($tag, ['h2', 'h3', 'h4', 'p', 'li', 'td', 'th'])) $inner = trim($inner);
            if ($inner === '' && !in_array($tag, ['br', 'hr'])) continue;
            $tag = semantic_convert($tag, $inner, $child);
            $html .= '<' . $tag . $attrs . '>' . $inner . '</' . $tag . '>';
        }
    }
    return $html;
}

// ── 공통 변수 ─────────────────────────────────────────────
$msg       = '';
$edit_post = null;
$action    = $_POST['action'] ?? ($_GET['action'] ?? '');
$id        = (int)($_GET['id'] ?? 0);

// ── 카테고리 추가 ─────────────────────────────────────────
if ($action === 'add_cat' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $cat_name = mysqli_real_escape_string($db, trim($_POST['cat_name'] ?? ''));
    if ($cat_name) {
        $ms = (int)(mysqli_fetch_assoc(mysqli_query($db, "SELECT MAX(sort) ms FROM `{$cat_table}`"))['ms'] ?? 0);
        mysqli_query($db, "INSERT INTO `{$cat_table}` (name,sort) VALUES('{$cat_name}'," . ($ms + 1) . ")");
        $msg = 'ok:카테고리가 추가되었습니다.';
    }
    $cats = get_cats($db, $cat_table);
}

// ── 카테고리 삭제 ─────────────────────────────────────────
if ($action === 'del_cat') {
    $cid = (int)($_GET['cat_id'] ?? 0);
    if ($cid) {
        $def = mysqli_fetch_assoc(mysqli_query($db, "SELECT id FROM `{$cat_table}` ORDER BY id ASC LIMIT 1"));
        $def_id = $def ? (int)$def['id'] : 0;
        mysqli_query($db, "UPDATE `{$table}` SET cat_id={$def_id} WHERE cat_id={$cid}");
        mysqli_query($db, "DELETE FROM `{$cat_table}` WHERE id={$cid}");
        $msg = 'ok:삭제되었습니다.';
    }
    $cats = get_cats($db, $cat_table);
}

// ── 이미지 단건 업로드 (base64 → 파일) ──────────────────
if ($action === 'upload_img' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    while (ob_get_level()) ob_end_clean();
    $up_base = G5_DATA_PATH . '/editor/' . date('Ym');
    $up_url  = G5_DATA_URL . '/editor/' . date('Ym');
    if (!is_dir($up_base)) @mkdir($up_base, 0755, true);
    if (!empty($_FILES['upload_b64']['name']) && $_FILES['upload_b64']['error'] === UPLOAD_ERR_OK) {
        $ext  = strtolower(pathinfo($_FILES['upload_b64']['name'], PATHINFO_EXTENSION));
        if (!$ext || $ext === 'tmp') $ext = 'jpg';
        $name = 'imp_' . time() . '_' . substr(md5(uniqid()), 0, 8) . '.' . $ext;
        if (move_uploaded_file($_FILES['upload_b64']['tmp_name'], $up_base . '/' . $name)) {
            header('Content-Type: application/json');
            echo json_encode(['url' => $up_url . '/' . $name]);
        } else {
            header('Content-Type: application/json');
            echo json_encode(['url' => '']);
        }
    } else {
        header('Content-Type: application/json');
        echo json_encode(['url' => '']);
    }
    exit;
}

// ── JS 처리 완료 HTML 저장 ─────────────────────────────
if ($action === 'import_html_processed' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    while (ob_get_level()) ob_end_clean();
    $cat_id       = (int)($_POST['import_cat_id'] ?? 0);
    $imp_title    = mysqli_real_escape_string($db, trim($_POST['import_title'] ?? ''));
    $imp_subtitle = mysqli_real_escape_string($db, trim($_POST['import_subtitle'] ?? ''));
    $imp_tags     = mysqli_real_escape_string($db, trim($_POST['import_tags'] ?? ''));
    $imp_content  = mysqli_real_escape_string($db, stripslashes($_POST['import_content'] ?? ''));
    $imp_thumb    = '';
    if (!empty($_FILES['import_thumb']['name']) && $_FILES['import_thumb']['error'] === UPLOAD_ERR_OK) {
        $up_t  = G5_DATA_PATH . '/editor/' . date('Ym');
        $up_tu = G5_DATA_URL . '/editor/' . date('Ym');
        if (!is_dir($up_t)) @mkdir($up_t, 0755, true);
        $te  = strtolower(pathinfo($_FILES['import_thumb']['name'], PATHINFO_EXTENSION));
        $tn  = 'thumb_' . time() . '_' . substr(md5(uniqid()), 0, 8) . '.' . $te;
        if (move_uploaded_file($_FILES['import_thumb']['tmp_name'], $up_t . '/' . $tn))
            $imp_thumb = mysqli_real_escape_string($db, $up_tu . '/' . $tn);
    }
    if (!$imp_title) $imp_title = '제목없음_' . date('YmdHis');
    $ok = mysqli_query($db, "INSERT INTO `{$table}` (cat_id,title,subtitle,content,thumbnail,tags,editor_type,created_at)
        VALUES({$cat_id},'{$imp_title}','{$imp_subtitle}','{$imp_content}','{$imp_thumb}','{$imp_tags}','html',NOW())");
    header('Content-Type: application/json');
    echo json_encode(['ok' => (bool)$ok, 'err' => $ok ? '' : mysqli_error($db)]);
    exit;
}

// ── HTML 파일 가져오기 ────────────────────────────────────
if ($action === 'import_html' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    ini_set('memory_limit', '512M');
    set_time_limit(120);

    if (!empty($_FILES['import_file']['name']) && $_FILES['import_file']['error'] === UPLOAD_ERR_OK) {
        $up_base = G5_DATA_PATH . '/editor/' . date('Ym');
        $up_url  = G5_DATA_URL . '/editor/' . date('Ym');
        if (!is_dir($up_base)) @mkdir($up_base, 0755, true);

        $tmp_file = $_FILES['import_file']['tmp_name'];
        $file_ext = strtolower(pathinfo($_FILES['import_file']['name'], PATHINFO_EXTENSION));
        $tmp_dir  = null;

        if ($file_ext === 'zip') {
            if (!class_exists('ZipArchive')) {
                $msg = 'error:서버에 ZipArchive 확장이 없습니다.';
            } else {
                $zip     = new ZipArchive();
                $tmp_dir = sys_get_temp_dir() . '/col_' . uniqid();
                mkdir($tmp_dir, 0755, true);
                if ($zip->open($tmp_file) === true) {
                    $zip->extractTo($tmp_dir);
                    $zip->close();
                    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($tmp_dir));
                    foreach ($it as $f) {
                        if ($f->isFile() && in_array(strtolower($f->getExtension()), ['html', 'htm'])) {
                            $tmp_file = $f->getPathname();
                            break;
                        }
                    }
                } else {
                    $msg = 'error:ZIP 파일을 열 수 없습니다.';
                }
            }
        }

        if (!$msg) {
            $html_raw = file_get_contents($tmp_file);
            $html_raw = mb_convert_encoding($html_raw, 'UTF-8', 'auto');
            ini_set('pcre.backtrack_limit', 10000000);
            foreach (['script', 'style', 'noscript', 'iframe', 'nav', 'header', 'footer'] as $t) {
                $html_raw = preg_replace('/<' . $t . '[^>]*>[\s\S]*?<\/' . $t . '>/i', '', $html_raw);
                if ($html_raw === null) {
                    $msg = 'error:HTML 파싱 실패 (preg_error: ' . preg_last_error() . ')';
                    break;
                }
            }
        }

        if (!$msg) {
            $dom = new DOMDocument('1.0', 'UTF-8');
            libxml_use_internal_errors(true);
            $dom->loadHTML(
                '<meta charset="utf-8">' . $html_raw,
                LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD | LIBXML_COMPACT
            );
            libxml_clear_errors();
            unset($html_raw);

            $import_title = '';
            $h1s = $dom->getElementsByTagName('h1');
            if ($h1s->length > 0) $import_title = trim($h1s->item(0)->textContent);
            if (!$import_title) {
                $ts = $dom->getElementsByTagName('title');
                if ($ts->length > 0) $import_title = trim($ts->item(0)->textContent);
            }

            $content_node = null;
            foreach (['article', 'main', 'body'] as $sel) {
                $nodes = $dom->getElementsByTagName($sel);
                if ($nodes->length > 0) {
                    $content_node = $nodes->item(0);
                    break;
                }
            }
            $allowed = [
                'h2',
                'h3',
                'h4',
                'p',
                'ul',
                'ol',
                'li',
                'blockquote',
                'strong',
                'em',
                'br',
                'img',
                'hr',
                'figure',
                'figcaption',
                'a',
                'table',
                'thead',
                'tbody',
                'tr',
                'th',
                'td'
            ];
            $import_content = $content_node ? normalize_node($content_node, $dom, $allowed) : '';
            $import_content = preg_replace('/<h1[^>]*>.*?<\/h1>/si', '', $import_content);
            $import_content = trim($import_content);

            $cat_id = (int)($_POST['import_cat_id'] ?? 0);
            $t_esc  = mysqli_real_escape_string($db, $import_title);
            $c_esc  = mysqli_real_escape_string($db, $import_content);

            if ($t_esc) {
                $result = mysqli_query($db, "INSERT INTO `{$table}` (cat_id,title,content,editor_type,created_at)
                VALUES({$cat_id},'{$t_esc}','{$c_esc}','html',NOW())");
                $msg = $result ? 'ok:HTML 파일을 성공적으로 가져왔습니다.' : 'error:DB 오류: ' . mysqli_error($db);
            } else {
                $fallback = pathinfo($_FILES['import_file']['name'], PATHINFO_FILENAME);
                $t_esc = mysqli_real_escape_string($db, $fallback);
                $result = mysqli_query($db, "INSERT INTO `{$table}` (cat_id,title,content,editor_type,created_at)
                VALUES({$cat_id},'{$t_esc}','{$c_esc}','html',NOW())");
                $msg = $result ? 'ok:저장 완료 (제목 미감지 → 파일명 사용)' : 'error:DB 오류: ' . mysqli_error($db);
            }
        }
    }
}

// ── 등록 ─────────────────────────────────────────────────
if ($action === 'insert' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $cat_id      = (int)($_POST['cat_id'] ?? 0);
    $title       = mysqli_real_escape_string($db, stripslashes(trim($_POST['title'] ?? '')));
    $subtitle    = mysqli_real_escape_string($db, stripslashes(trim($_POST['subtitle'] ?? '')));
    $content_raw = rehost_external_images(stripslashes($_POST['content'] ?? ''));
    $content     = mysqli_real_escape_string($db, $content_raw);
    $tags        = mysqli_real_escape_string($db, stripslashes(trim($_POST['tags'] ?? '')));
    $treat_start = mysqli_real_escape_string($db, trim($_POST['treat_start'] ?? ''));
    $treat_end   = mysqli_real_escape_string($db, trim($_POST['treat_end'] ?? ''));
    $treat_side  = mysqli_real_escape_string($db, stripslashes(trim($_POST['treat_side'] ?? '')));
    $faq_rows = [];
    for ($i = 0; $i < 5; $i++) {
        $q = trim($_POST['faq_q_' . $i] ?? '');
        $a = trim($_POST['faq_a_' . $i] ?? '');
        if ($q) $faq_rows[] = ['q' => $q, 'a' => $a];
    }
    $faq = mysqli_real_escape_string($db, json_encode($faq_rows, JSON_UNESCAPED_UNICODE));
    $thumb = '';
    if (!empty($_FILES['thumb_file']['name']) && $_FILES['thumb_file']['error'] === UPLOAD_ERR_OK) {
        $dir = $_SERVER['DOCUMENT_ROOT'] . $upload_dir . '/';
        if (!is_dir($dir)) mkdir($dir, 0755, true);
        $ext  = strtolower(pathinfo($_FILES['thumb_file']['name'], PATHINFO_EXTENSION));
        $name = 'col_' . time() . '_' . substr(md5(rand()), 0, 8) . '.' . $ext;
        if (move_uploaded_file($_FILES['thumb_file']['tmp_name'], $dir . $name))
            $thumb = mysqli_real_escape_string($db, $upload_dir . '/' . $name);
    }
    if (!$title) {
        $msg = 'error:제목을 입력해 주세요.';
    } else {
        mysqli_query($db, "INSERT INTO `{$table}`
            (cat_id,title,subtitle,content,thumbnail,tags,faq,treat_start,treat_end,treat_side,created_at)
            VALUES({$cat_id},'{$title}','{$subtitle}','{$content}','{$thumb}','{$tags}','{$faq}',
                   '{$treat_start}','{$treat_end}','{$treat_side}',NOW())");
        $msg = 'ok:등록되었습니다.';
    }
}

// ── 수정 ─────────────────────────────────────────────────
if ($action === 'update' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $eid         = (int)($_POST['id'] ?? 0);
    $cat_id      = (int)($_POST['cat_id'] ?? 0);
    $title       = mysqli_real_escape_string($db, stripslashes(trim($_POST['title'] ?? '')));
    $subtitle    = mysqli_real_escape_string($db, stripslashes(trim($_POST['subtitle'] ?? '')));
    $content_raw = rehost_external_images(stripslashes($_POST['content'] ?? ''));
    $content     = mysqli_real_escape_string($db, $content_raw);
    $tags        = mysqli_real_escape_string($db, stripslashes(trim($_POST['tags'] ?? '')));
    $treat_start = mysqli_real_escape_string($db, trim($_POST['treat_start'] ?? ''));
    $treat_end   = mysqli_real_escape_string($db, trim($_POST['treat_end'] ?? ''));
    $treat_side  = mysqli_real_escape_string($db, stripslashes(trim($_POST['treat_side'] ?? '')));
    $faq_rows = [];
    for ($i = 0; $i < 5; $i++) {
        $q = trim($_POST['faq_q_' . $i] ?? '');
        $a = trim($_POST['faq_a_' . $i] ?? '');
        if ($q) $faq_rows[] = ['q' => $q, 'a' => $a];
    }
    $faq = mysqli_real_escape_string($db, json_encode($faq_rows, JSON_UNESCAPED_UNICODE));
    $tsql = '';
    if (!empty($_FILES['thumb_file']['name']) && $_FILES['thumb_file']['error'] === UPLOAD_ERR_OK) {
        $dir = $_SERVER['DOCUMENT_ROOT'] . $upload_dir . '/';
        if (!is_dir($dir)) mkdir($dir, 0755, true);
        $ext  = strtolower(pathinfo($_FILES['thumb_file']['name'], PATHINFO_EXTENSION));
        $name = 'col_' . time() . '_' . substr(md5(rand()), 0, 8) . '.' . $ext;
        if (move_uploaded_file($_FILES['thumb_file']['tmp_name'], $dir . $name)) {
            $old = mysqli_fetch_assoc(mysqli_query($db, "SELECT thumbnail FROM `{$table}` WHERE id={$eid}"));
            if (!empty($old['thumbnail'])) @unlink($_SERVER['DOCUMENT_ROOT'] . $old['thumbnail']);
            $tn   = mysqli_real_escape_string($db, $upload_dir . '/' . $name);
            $tsql = ",thumbnail='{$tn}'";
        }
    }
    mysqli_query($db, "UPDATE `{$table}` SET
        cat_id={$cat_id},title='{$title}',subtitle='{$subtitle}',content='{$content}',
        tags='{$tags}',faq='{$faq}',treat_start='{$treat_start}',treat_end='{$treat_end}',treat_side='{$treat_side}'
        {$tsql} WHERE id={$eid}");
    $msg = 'ok:수정되었습니다.';
}

// ── 삭제 ─────────────────────────────────────────────────
if ($action === 'delete' && $id) {
    $old = mysqli_fetch_assoc(mysqli_query($db, "SELECT thumbnail FROM `{$table}` WHERE id={$id}"));
    if (!empty($old['thumbnail'])) @unlink($_SERVER['DOCUMENT_ROOT'] . $old['thumbnail']);
    mysqli_query($db, "DELETE FROM `{$table}` WHERE id={$id}");
    header("Location: ./column_admin.php?msg=" . urlencode('ok:삭제되었습니다.'));
    exit;
}

// ── 수정 폼 ──────────────────────────────────────────────
if ($action === 'edit' && $id) {
    $r = mysqli_query($db, "SELECT * FROM `{$table}` WHERE id={$id}");
    $edit_post = $r ? mysqli_fetch_assoc($r) : null;
}

if (!$msg && isset($_GET['msg'])) $msg = urldecode($_GET['msg']);

// ── 목록 ─────────────────────────────────────────────────
$page        = max(1, (int)($_GET['page'] ?? 1));
$per_page    = 15;
$offset      = ($page - 1) * $per_page;
$total       = (int)(mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) cnt FROM `{$table}`"))['cnt'] ?? 0);
$total_pages = max(1, ceil($total / $per_page));
$list_r      = mysqli_query($db, "SELECT g.id,g.title,g.created_at,g.hit,g.thumbnail,g.editor_type,c.name as cat_name
    FROM `{$table}` g LEFT JOIN `{$cat_table}` c ON g.cat_id=c.id
    ORDER BY g.id DESC LIMIT {$offset},{$per_page}");
$is_edit     = ($action === 'edit' && $edit_post);

$edit_faqs = [];
if ($is_edit && !empty($edit_post['faq'])) {
    $d = json_decode($edit_post['faq'], true);
    if (is_array($d)) $edit_faqs = $d;
}
?>
<!DOCTYPE html>
<html lang="ko">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>칼럼 관리</title>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet">
    <style>
        *,
        *::before,
        *::after {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Pretendard', 'Apple SD Gothic Neo', sans-serif;
            background: #f5f6fa;
            color: #1a1a2e;
        }

        #admin_wrapper {
            display: flex;
            min-height: 100vh;
        }

        .content_area {
            flex: 1;
            padding: 40px;
            overflow-x: hidden;
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .page_header {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .page_title {
            font-size: 22px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .count_badge {
            background: #ede9fe;
            color: #4f46e5;
            font-size: 12px;
            font-weight: 700;
            padding: 3px 12px;
            border-radius: 20px;
        }

        .card {
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 2px 12px rgba(0, 0, 0, .06);
            border: 1px solid #e8eaf0;
            overflow: hidden;
        }

        .card_hd {
            padding: 14px 20px;
            border-bottom: 1px solid #e8eaf0;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .card_hd_title {
            font-size: 14px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .card_hd_title .material-symbols-outlined {
            font-size: 16px;
            color: #4f46e5;
        }

        .card_body {
            padding: 20px;
        }

        .btn_primary {
            padding: 9px 20px;
            background: #4f46e5;
            color: #fff;
            border: none;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 700;
            cursor: pointer;
            transition: all .2s;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            font-family: inherit;
        }

        .btn_primary:hover {
            background: #4338ca;
        }

        .btn_neutral {
            padding: 9px 16px;
            background: #f5f6fa;
            color: #5c5c7a;
            border: 1px solid #e8eaf0;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all .2s;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            text-decoration: none;
            font-family: inherit;
        }

        .btn_neutral:hover {
            background: #e8eaf0;
        }

        .form_group {
            margin-bottom: 16px;
        }

        .form_group>label {
            display: block;
            font-size: 12px;
            font-weight: 700;
            color: #9999bb;
            margin-bottom: 6px;
        }

        .sub_label {
            display: block;
            font-size: 11px;
            color: #9999bb;
            margin-bottom: 4px;
        }

        .form_input {
            width: 100%;
            padding: 10px 14px;
            border: 1px solid #e8eaf0;
            border-radius: 8px;
            font-size: 14px;
            background: #f5f6fa;
            font-family: inherit;
            color: #1a1a2e;
            transition: all .2s;
        }

        .form_input:focus {
            outline: none;
            border-color: #4f46e5;
            background: #fff;
            box-shadow: 0 0 0 3px rgba(79, 70, 229, .1);
        }

        .form_grid2 {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
        }

        .th_wrap {
            display: grid;
            grid-template-columns: 1fr 148px;
            gap: 14px;
            align-items: start;
        }

        .th_lbl {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 9px 14px;
            background: #f5f6fa;
            border: 1px solid #e8eaf0;
            border-radius: 8px;
            font-size: 12px;
            font-weight: 700;
            color: #5c5c7a;
            cursor: pointer;
            transition: all .2s;
        }

        .th_lbl:hover {
            border-color: #4f46e5;
            color: #4f46e5;
            background: #ede9fe;
        }

        .th_lbl .material-symbols-outlined {
            font-size: 15px;
        }

        .th_name {
            display: block;
            font-size: 11px;
            color: #9999bb;
            margin-top: 5px;
        }

        .th_prev {
            width: 148px;
            height: 92px;
            border: 1px solid #e8eaf0;
            border-radius: 8px;
            overflow: hidden;
            background: #f5f6fa;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .th_prev img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .editor_shell {
            border: 1px solid #e8eaf0;
            border-radius: 8px;
            overflow: hidden;
        }

        .editor_shell:focus-within {
            border-color: #4f46e5;
            box-shadow: 0 0 0 3px rgba(79, 70, 229, .1);
        }

        .etoolbar {
            display: flex;
            flex-wrap: wrap;
            gap: 2px;
            padding: 8px;
            background: #f5f6fa;
            border-bottom: 1px solid #e8eaf0;
        }

        .sep {
            width: 1px;
            height: 22px;
            background: #e8eaf0;
            margin: 0 3px;
            align-self: center;
        }

        .etb {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 28px;
            height: 28px;
            padding: 0 5px;
            border: none;
            background: transparent;
            border-radius: 5px;
            cursor: pointer;
            font-size: 12.5px;
            font-family: inherit;
            font-weight: 500;
            color: #5c5c7a;
            transition: all .12s;
            gap: 3px;
        }

        .etb:hover {
            background: #ede9fe;
            color: #4f46e5;
        }

        .etb.etb-src-on {
            background: #4f46e5;
            color: #fff;
        }

        .etb.etb-src-on:hover {
            background: #4338ca;
            color: #fff;
        }

        .etb .material-symbols-outlined {
            font-size: 16px;
        }

        #ce-editor {
            min-height: 360px;
            padding: 16px 18px;
            outline: none;
            font-size: 15px;
            line-height: 1.8;
            color: #1a1a2e;
        }

        #ce-editor:empty::before {
            content: attr(data-placeholder);
            color: #9999bb;
            pointer-events: none;
        }

        #ce-editor h2 {
            font-size: 20px;
            font-weight: 700;
            margin: 28px 0 12px;
            padding-bottom: 8px;
            border-bottom: 2px solid #e8eaf0;
        }

        #ce-editor h3 {
            font-size: 17px;
            font-weight: 600;
            margin: 20px 0 10px;
        }

        #ce-editor p {
            margin: 0 0 12px;
        }

        #ce-editor ul,
        #ce-editor ol {
            padding-left: 22px;
            margin: 0 0 12px;
        }

        #ce-editor blockquote {
            border-left: 4px solid #4f46e5;
            margin: 16px 0;
            padding: 10px 16px;
            background: #ede9fe;
            border-radius: 0 6px 6px 0;
        }

        #ce-editor .related-link-box {
            display: block;
            border: 1px solid #e8eaf0;
            border-radius: 10px;
            overflow: hidden;
            text-decoration: none;
            margin: 16px 0;
            background: #f9fafb;
        }

        #ce-editor .related-link-box .rlb-body {
            padding: 12px 16px 8px;
        }

        #ce-editor .related-link-box .rlb-title {
            font-size: 14px;
            font-weight: 700;
            color: #1a1a2e;
            margin-bottom: 4px;
        }

        #ce-editor .related-link-box .rlb-desc {
            font-size: 12px;
            color: #6b7280;
        }

        #ce-editor .related-link-box .rlb-url {
            padding: 6px 16px;
            background: #f0f0f0;
            font-size: 11px;
            color: #4f46e5;
            border-top: 1px solid #e8eaf0;
        }

        hr.section_divider {
            border: none;
            border-top: 1px solid #e8eaf0;
            margin: 20px 0;
        }

        .section_title {
            font-size: 13px;
            font-weight: 700;
            color: #4f46e5;
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .faq_row {
            border: 1px solid #e8eaf0;
            border-radius: 8px;
            padding: 14px;
            background: #f5f6fa;
            margin-bottom: 10px;
        }

        .faq_label {
            font-size: 11px;
            font-weight: 700;
            color: #4f46e5;
            background: #ede9fe;
            padding: 2px 8px;
            border-radius: 20px;
            margin-bottom: 8px;
            display: inline-block;
        }

        .faq_row textarea {
            width: 100%;
            padding: 9px 12px;
            border: 1px solid #e8eaf0;
            border-radius: 7px;
            font-size: 13px;
            font-family: inherit;
            resize: vertical;
            min-height: 64px;
            outline: none;
            line-height: 1.6;
            color: #1a1a2e;
            background: #fff;
            margin-top: 6px;
        }

        .faq_row textarea:focus {
            border-color: #4f46e5;
        }

        .form_footer {
            display: flex;
            gap: 8px;
            justify-content: flex-end;
            margin-top: 16px;
        }

        .write-tabs {
            display: flex;
            gap: 0;
            border-bottom: 2px solid #e8eaf0;
            margin-bottom: 20px;
        }

        .write-tab-btn {
            padding: 10px 20px;
            border: none;
            background: transparent;
            font-size: 13px;
            font-weight: 700;
            color: #9999bb;
            cursor: pointer;
            border-bottom: 2px solid transparent;
            margin-bottom: -2px;
            font-family: inherit;
            transition: all .15s;
        }

        .write-tab-btn.active {
            color: #4f46e5;
            border-bottom-color: #4f46e5;
        }

        .write-panel {
            display: none;
        }

        .write-panel.active {
            display: block;
        }

        .import-zone {
            border: 2px dashed #e8eaf0;
            border-radius: 10px;
            padding: 32px;
            text-align: center;
            background: #f5f6fa;
            cursor: pointer;
            transition: all .2s;
            position: relative;
        }

        .import-zone:hover,
        .import-zone.dragover {
            border-color: #4f46e5;
            background: #ede9fe;
        }

        .import-zone input[type="file"] {
            position: absolute;
            inset: 0;
            opacity: 0;
            cursor: pointer;
            width: 100%;
            height: 100%;
        }

        .import-zone-icon {
            font-size: 32px;
            margin-bottom: 8px;
        }

        .import-zone-text {
            font-size: 13px;
            color: #9999bb;
        }

        .import-zone-text strong {
            color: #4f46e5;
        }

        .import-preview {
            margin-top: 12px;
            padding: 12px 16px;
            background: #f0fdf4;
            border: 1px solid #bbf7d0;
            border-radius: 8px;
            font-size: 13px;
            color: #166534;
            display: none;
        }

        .import-tip {
            background: #fffbf0;
            border: 1px solid #fde68a;
            border-radius: 8px;
            padding: 12px 16px;
            font-size: 12px;
            color: #854d0e;
            margin-bottom: 16px;
            line-height: 1.7;
        }

        .editor-select-bar {
            display: flex;
            gap: 10px;
            align-items: center;
            margin-bottom: 20px;
            padding: 14px;
            background: #f5f6fa;
            border-radius: 10px;
            border: 1px solid #e8eaf0;
        }

        .eq_table {
            width: 100%;
            border-collapse: collapse;
        }

        .eq_table thead tr {
            background: #fafafa;
            border-bottom: 1px solid #e8eaf0;
        }

        .eq_table th {
            padding: 10px 14px;
            font-size: 11px;
            font-weight: 700;
            color: #9999bb;
            text-transform: uppercase;
            letter-spacing: .05em;
            text-align: left;
        }

        .eq_table th.tc {
            text-align: center;
        }

        .eq_table td {
            padding: 12px 14px;
            border-bottom: 1px solid #f5f5f5;
            vertical-align: middle;
            font-size: 13px;
        }

        .eq_table tbody tr:last-child td {
            border-bottom: none;
        }

        .eq_table tbody tr:hover {
            background: #fafbff;
        }

        .eq_thumb {
            width: 52px;
            height: 34px;
            object-fit: cover;
            border-radius: 5px;
            border: 1px solid #e8eaf0;
        }

        .eq_nothumb {
            width: 52px;
            height: 34px;
            background: #f5f6fa;
            border-radius: 5px;
            border: 1px solid #e8eaf0;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .eq_nothumb .material-symbols-outlined {
            font-size: 14px;
            color: #9999bb;
        }

        .eq_title a {
            color: #1a1a2e;
            text-decoration: none;
            font-weight: 600;
        }

        .eq_title a:hover {
            color: #4f46e5;
        }

        .btn_edit {
            padding: 5px 10px;
            background: #4f46e5;
            color: #fff;
            border: none;
            border-radius: 6px;
            font-size: 11px;
            font-weight: 700;
            cursor: pointer;
            text-decoration: none;
            transition: all .2s;
            display: inline-flex;
            align-items: center;
            gap: 3px;
        }

        .btn_edit:hover {
            background: #4338ca;
        }

        .btn_del {
            padding: 5px 10px;
            background: #fee2e2;
            color: #dc2626;
            border: none;
            border-radius: 6px;
            font-size: 11px;
            font-weight: 700;
            cursor: pointer;
            transition: all .2s;
            display: inline-flex;
            align-items: center;
            gap: 3px;
        }

        .btn_del:hover {
            background: #fecaca;
        }

        .empty_state {
            text-align: center;
            padding: 48px;
            color: #9999bb;
            font-size: 14px;
        }

        .pager {
            display: flex;
            align-items: center;
            gap: 4px;
            justify-content: center;
            padding: 16px 0 4px;
        }

        .pager a,
        .pager span {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 32px;
            height: 32px;
            border-radius: 7px;
            font-size: 13px;
            text-decoration: none;
            border: 1px solid #e8eaf0;
            color: #9999bb;
        }

        .pager a:hover {
            background: #f5f6fa;
            color: #1a1a2e;
        }

        .pager .cur {
            background: #4f46e5;
            border-color: #4f46e5;
            color: #fff;
            font-weight: 700;
        }

        .cat_badge {
            background: #ede9fe;
            color: #4f46e5;
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 11px;
            font-weight: 700;
        }

        .cat_chip {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            background: #f5f6fa;
            border: 1px solid #e8eaf0;
            border-radius: 6px;
            padding: 3px 10px;
            font-size: 12px;
        }

        .cat_chip a {
            color: #dc2626;
            text-decoration: none;
            font-size: 14px;
            line-height: 1;
        }

        .tag-chip {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            background: #ede9fe;
            color: #4f46e5;
            border-radius: 20px;
            padding: 4px 12px;
            font-size: 12px;
            font-weight: 700;
        }

        .tag-chip::before {
            content: '#';
            opacity: .6;
        }

        .tag-chip .tag-del {
            background: none;
            border: none;
            color: #4f46e5;
            cursor: pointer;
            font-size: 14px;
            line-height: 1;
            padding: 0;
            opacity: .6;
        }

        .tag-chip .tag-del:hover {
            opacity: 1;
        }

        .loading-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.6);
            z-index: 99999;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 16px;
        }

        .loading-overlay.show {
            display: flex;
        }

        .loading-spin {
            width: 48px;
            height: 48px;
            border: 4px solid rgba(255, 255, 255, 0.2);
            border-top-color: #fff;
            border-radius: 50%;
            animation: spin .8s linear infinite;
        }

        @keyframes spin {
            to {
                transform: rotate(360deg)
            }
        }

        .toast {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 12px 18px;
            border-radius: 10px;
            font-size: 13px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 7px;
            z-index: 9999;
            box-shadow: 0 4px 16px rgba(0, 0, 0, .12);
            animation: tin .22s ease;
            max-width: 300px;
        }

        .toast.ok {
            background: #f0fdf4;
            border: 1px solid #bbf7d0;
            color: #059669;
        }

        .toast.error {
            background: #fef2f2;
            border: 1px solid #fecaca;
            color: #dc2626;
        }

        @keyframes tin {
            from {
                opacity: 0;
                transform: translateX(12px)
            }

            to {
                opacity: 1;
                transform: none
            }
        }

        #ce-editor hr {
            border: none;
            border-top: 1px solid #e8eaf0;
            margin: 24px 0;
        }

        #ce-editor table {
            width: 100%;
            border-collapse: collapse;
            margin: 16px 0;
            font-size: 13px;
        }

        #ce-editor th {
            background: #4f46e5;
            color: #fff;
            padding: 8px 10px;
            font-weight: 700;
            text-align: left;
        }

        #ce-editor td {
            padding: 8px 10px;
            border: 1px solid #e8eaf0;
        }

        #ce-editor tr:nth-child(even) td {
            background: #f9fafb;
        }

        #ce-editor figure {
            margin: 16px 0;
            text-align: center;
        }

        #ce-editor figcaption {
            font-size: 13px;
            color: #9ca3af;
            margin-top: 6px;
        }

        #ce-editor figcaption:empty::before {
            content: '이미지 설명 입력 (비우면 캡션 없음)';
            color: #c4b5fd;
        }
    </style>
</head>

<body>

    <?php if ($msg):
        list($type, $text) = explode(':', $msg, 2);
        echo "<div class='toast {$type}' id='toast'><span class='material-symbols-outlined'>" . ($type === 'ok' ? 'check_circle' : 'error') . "</span>" . htmlspecialchars($text) . "</div>";
    endif; ?>

    <div id="admin_wrapper">
        <?php include_once('../aside.php'); ?>
        <main class="content_area">

            <div class="page_header">
                <h2 class="page_title">
                    <span class="material-symbols-outlined" style="font-size:22px;color:#4f46e5;">article</span>
                    칼럼 관리
                    <span class="count_badge"><?= number_format($total) ?>편</span>
                </h2>
                <a href="<?= $column_path ?>/column_list.php" target="_blank" class="btn_neutral">
                    <span class="material-symbols-outlined" style="font-size:14px;">open_in_new</span>목록 보기
                </a>
            </div>

            <!-- 작성/수정 카드 -->
            <div class="card" id="write-card">
                <div class="card_hd">
                    <span class="card_hd_title">
                        <span class="material-symbols-outlined"><?= $is_edit ? 'edit' : 'add_circle' ?></span>
                        <?= $is_edit ? '칼럼 수정' : '새 칼럼 작성' ?>
                    </span>
                    <?php if ($is_edit): ?>
                        <a href="./column_admin.php" class="btn_neutral" style="font-size:12px;padding:5px 12px;">
                            <span class="material-symbols-outlined" style="font-size:13px;">close</span>취소
                        </a>
                    <?php endif; ?>
                </div>
                <div class="card_body">

                    <?php if (!$is_edit): ?>
                        <div class="write-tabs">
                            <button type="button" class="write-tab-btn active" data-tab="write">✏️ 직접 작성</button>
                            <button type="button" class="write-tab-btn" data-tab="import">📄 HTML 가져오기</button>
                        </div>
                    <?php endif; ?>

                    <!-- HTML 가져오기 패널 -->
                    <?php if (!$is_edit): ?>
                        <div class="write-panel" id="panel-import">
                            <form method="POST" action="./column_admin.php" enctype="multipart/form-data" id="importForm">
                                <input type="hidden" name="action" value="import_html">
                                <div class="form_group">
                                    <label>카테고리</label>
                                    <select name="import_cat_id" class="form_input">
                                        <?php foreach ($cats as $cat): ?>
                                            <option value="<?= (int)$cat['id'] ?>"><?= htmlspecialchars($cat['name']) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="form_group">
                                    <label>HTML / ZIP 파일</label>
                                    <div class="import-zone" id="importZone"
                                        ondragover="event.preventDefault();this.classList.add('dragover')"
                                        ondragleave="this.classList.remove('dragover')"
                                        ondrop="handleImportDrop(event)">
                                        <input type="file" name="import_file" id="importFile" accept=".html,.htm,.zip"
                                            onchange="onImportFile(this)">
                                        <div class="import-zone-icon">📄</div>
                                        <div class="import-zone-text">
                                            클릭 또는 <strong>드래그</strong> 업로드<br>
                                            <span style="font-size:11px;display:block;margin-top:4px;">.html / .htm / .zip 지원 · base64 이미지 자동 서버 저장</span>
                                        </div>
                                    </div>
                                    <div class="import-preview" id="importPreview"></div>
                                </div>

                                <div class="form_group">
                                    <label>부제목 <span style="font-size:10px;font-weight:400;color:#9999bb;margin-left:4px">선택</span></label>
                                    <input type="text" id="import_subtitle" class="form_input" placeholder="부제목을 입력하세요">
                                </div>

                                <div class="form_group">
                                    <label>태그 <span style="font-size:10px;font-weight:400;color:#9999bb;margin-left:4px">Enter로 추가</span></label>
                                    <input type="text" id="importTagInput" class="form_input" placeholder="#태그 입력 후 Enter" autocomplete="off" style="margin-bottom:10px;">
                                    <input type="hidden" id="import_tags_hidden">
                                    <div id="importTagList" style="display:flex;flex-wrap:wrap;gap:8px;min-height:32px;"></div>
                                </div>

                                <div class="form_group">
                                    <label>썸네일 이미지 <span style="font-size:10px;font-weight:400;color:#9999bb;margin-left:4px">선택</span></label>
                                    <div style="display:flex;gap:12px;align-items:center;">
                                        <label style="display:inline-flex;align-items:center;gap:6px;padding:9px 14px;background:#f5f6fa;border:1px solid #e8eaf0;border-radius:8px;font-size:12px;font-weight:700;color:#5c5c7a;cursor:pointer;">
                                            <span class="material-symbols-outlined" style="font-size:15px;">upload</span>파일 선택
                                            <input type="file" id="importThumb" accept="image/*" style="display:none"
                                                onchange="var n=document.getElementById('importThumbName');var p=document.getElementById('importThumbPrev');n.textContent=this.files[0]?.name||'';p.src=URL.createObjectURL(this.files[0]);p.style.display='block';">
                                        </label>
                                        <span id="importThumbName" style="font-size:11px;color:#9999bb;"></span>
                                        <img id="importThumbPrev" src="" alt="" style="width:80px;height:52px;object-fit:cover;border-radius:6px;border:1px solid #e8eaf0;display:none;">
                                    </div>
                                </div>

                                <div class="import-tip">
                                    <strong>💡 파싱 규칙</strong><br>
                                    · H1 → 칼럼 제목 &nbsp; · H2/H3/H4 → 소제목 유지<br>
                                    · 따옴표 시작 문장 / bold만 구성된 짧은 문장 → 인용구<br>
                                    · base64 인라인 이미지 → 서버에 자동 저장 후 URL 교체<br>
                                    · script, style, nav, header, footer 자동 제거
                                </div>

                                <!-- ★ 수정 1/3: 가져오기 패널 관련 링크 박스 HTML -->
                                <div class="form_group">
                                    <div class="section_title">
                                        <span class="material-symbols-outlined" style="font-size:15px;">link</span>
                                        관련 링크 박스 <span style="font-size:10px;font-weight:400;color:#9999bb;margin-left:4px">선택 — 저장 시 FAQ 위/아래에 자동 삽입</span>
                                    </div>
                                    <div style="display:flex;gap:8px;margin-bottom:10px;">
                                        <input type="text" id="importLinkUrlInput" class="form_input" placeholder="https://"
                                            style="flex:1;" onkeydown="if(event.key==='Enter'){event.preventDefault();fetchImportLinkMeta();}">
                                        <button type="button" class="btn_primary" onclick="fetchImportLinkMeta()" style="white-space:nowrap;">
                                            <span class="material-symbols-outlined" style="font-size:14px;">search</span>가져오기
                                        </button>
                                    </div>
                                    <div id="importLinkPreviewCard" style="display:none;border:1px solid #e8eaf0;border-radius:8px;overflow:hidden;background:#fff;margin-bottom:10px;">
                                        <div style="padding:12px 16px 10px;">
                                            <div id="ilpTitle" style="font-size:14px;font-weight:700;color:#1a1a2e;margin-bottom:4px;"></div>
                                            <div id="ilpDesc" style="font-size:12px;color:#6b7280;"></div>
                                        </div>
                                        <div id="ilpUrl" style="padding:6px 16px;background:#f5f6fa;font-size:11px;color:#4f46e5;border-top:1px solid #e8eaf0;word-break:break-all;"></div>
                                        <div style="padding:10px 16px;display:flex;gap:8px;align-items:center;border-top:1px solid #e8eaf0;">
                                            <select id="importLinkPosition" class="form_input" style="width:auto;padding:6px 10px;font-size:12px;">
                                                <option value="before">FAQ 위에 삽입</option>
                                                <option value="after">FAQ 아래에 삽입</option>
                                                <option value="end">본문 맨 끝에 삽입</option>
                                            </select>
                                            <button type="button" class="btn_neutral" onclick="resetImportLinkPreview()" style="font-size:12px;padding:7px 14px;">초기화</button>
                                        </div>
                                    </div>
                                </div>

                                <button type="button" class="btn_primary" onclick="processAndImport()">
                                    <span class="material-symbols-outlined" style="font-size:14px;">file_open</span>
                                    가져오기
                                </button>
                                <span id="import-status" style="display:block;margin-top:10px;font-size:13px;color:#9999bb;"></span>
                            </form>
                        </div>
                    <?php endif; ?>

                    <!-- 직접 작성 패널 -->
                    <div class="write-panel active" id="panel-write">

                        <div class="editor-select-bar">
                            <span class="material-symbols-outlined" style="font-size:16px;color:#4f46e5;">edit_note</span>
                            <span style="font-size:13px;font-weight:700;color:#5c5c7a;flex:1;">에디터 선택</span>
                            <span class="btn_neutral" style="font-size:12px;padding:6px 14px;background:#ede9fe;color:#4f46e5;border-color:#c4b5fd;">
                                <span class="material-symbols-outlined" style="font-size:13px;">text_fields</span>일반 에디터 (현재)
                            </span>
                            <a href="column_block_write.php<?= $is_edit ? '?mode=modify&id=' . (int)$edit_post['id'] : '' ?>"
                                class="btn_primary" style="font-size:12px;padding:6px 14px;">
                                <span class="material-symbols-outlined" style="font-size:13px;">dashboard</span>블록 에디터
                            </a>
                        </div>

                        <form method="POST" action="./column_admin.php" id="wform" enctype="multipart/form-data">
                            <input type="hidden" name="action" value="<?= $is_edit ? 'update' : 'insert' ?>">
                            <?php if ($is_edit): ?><input type="hidden" name="id" value="<?= (int)$edit_post['id'] ?>"><?php endif; ?>
                            <input type="hidden" name="content" id="content_hidden">

                            <div class="form_group">
                                <label>카테고리</label>
                                <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
                                    <select name="cat_id" class="form_input" style="flex:1;min-width:160px;">
                                        <?php foreach ($cats as $cat): ?>
                                            <option value="<?= (int)$cat['id'] ?>"
                                                <?= ($is_edit && (int)($edit_post['cat_id'] ?? 0) === (int)$cat['id']) ? 'selected' : '' ?>>
                                                <?= htmlspecialchars($cat['name']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <button type="button" class="btn_neutral" onclick="document.getElementById('addCatBox').style.display='flex'" style="white-space:nowrap;">
                                        <span class="material-symbols-outlined" style="font-size:14px;">add</span>추가
                                    </button>
                                </div>
                                <div id="addCatBox" style="display:none;margin-top:10px;gap:8px;align-items:center;">
                                    <input type="text" id="newCatName" class="form_input" placeholder="새 카테고리명" style="flex:1;">
                                    <button type="button" class="btn_primary" onclick="addCategory()">추가</button>
                                    <button type="button" class="btn_neutral" onclick="document.getElementById('addCatBox').style.display='none'">취소</button>
                                </div>
                                <?php if (count($cats) > 0): ?>
                                    <div style="margin-top:10px;display:flex;flex-wrap:wrap;gap:6px;">
                                        <?php foreach ($cats as $cat): ?>
                                            <span class="cat_chip">
                                                <?= htmlspecialchars($cat['name']) ?>
                                                <?php if ($cat['name'] !== '미분류'): ?>
                                                    <a href="./column_admin.php?action=del_cat&cat_id=<?= (int)$cat['id'] ?>"
                                                        onclick="return confirm('삭제 시 해당 글이 미분류로 이동됩니다.')">×</a>
                                                <?php endif; ?>
                                            </span>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <hr class="section_divider">

                            <div class="form_group">
                                <label>제목 *</label>
                                <input class="form_input" type="text" name="title" required placeholder="칼럼 제목"
                                    value="<?= htmlspecialchars($is_edit ? ($edit_post['title'] ?? '') : '') ?>">
                            </div>
                            <div class="form_group">
                                <label>부제목 <span style="font-size:10px;font-weight:400;color:#9999bb;margin-left:4px">선택</span></label>
                                <input class="form_input" type="text" name="subtitle" placeholder="부제목"
                                    value="<?= htmlspecialchars($is_edit ? ($edit_post['subtitle'] ?? '') : '') ?>">
                            </div>

                            <div class="form_group">
                                <label>태그 <span style="font-size:10px;font-weight:400;color:#9999bb;margin-left:4px">Enter로 추가</span></label>
                                <input class="form_input" type="text" id="tagInput" placeholder="#태그 입력 후 Enter" autocomplete="off" style="margin-bottom:10px;">
                                <input type="hidden" name="tags" id="tags_hidden" value="<?= htmlspecialchars($is_edit ? ($edit_post['tags'] ?? '') : '') ?>">
                                <div id="tagList" style="display:flex;flex-wrap:wrap;gap:8px;min-height:32px;"></div>
                            </div>

                            <div class="form_group">
                                <label>치료 정보 <span style="font-size:10px;font-weight:400;color:#9999bb;margin-left:4px">선택 — 입력 시 상세페이지에 노출</span></label>
                                <div class="form_grid2" style="margin-bottom:12px;">
                                    <div>
                                        <span class="sub_label">치료 시작일</span>
                                        <input class="form_input" type="text" name="treat_start" placeholder="예: 2024.01.15"
                                            value="<?= htmlspecialchars($is_edit ? ($edit_post['treat_start'] ?? '') : '') ?>">
                                    </div>
                                    <div>
                                        <span class="sub_label">치료 종료일</span>
                                        <input class="form_input" type="text" name="treat_end" placeholder="예: 2024.03.20"
                                            value="<?= htmlspecialchars($is_edit ? ($edit_post['treat_end'] ?? '') : '') ?>">
                                    </div>
                                </div>
                                <span class="sub_label">부작용 및 합병증</span>
                                <input class="form_input" type="text" name="treat_side" placeholder="예: 일시적 부종, 해당 없음"
                                    value="<?= htmlspecialchars($is_edit ? ($edit_post['treat_side'] ?? '') : '') ?>">
                            </div>

                            <hr class="section_divider">

                            <div class="form_group">
                                <label>썸네일 이미지</label>
                                <div class="th_wrap">
                                    <div>
                                        <label for="tfile" class="th_lbl">
                                            <span class="material-symbols-outlined">upload</span>파일 선택
                                        </label>
                                        <input type="file" id="tfile" name="thumb_file" accept="image/*" style="display:none">
                                        <span class="th_name" id="tname">선택된 파일 없음</span>
                                        <?php if ($is_edit && !empty($edit_post['thumbnail'])): ?>
                                            <p style="font-size:11px;color:#059669;margin-top:4px;">✓ 현재 이미지 있음</p>
                                        <?php endif; ?>
                                    </div>
                                    <div class="th_prev" id="tprev">
                                        <?php if ($is_edit && !empty($edit_post['thumbnail'])): ?>
                                            <img src="<?= htmlspecialchars($edit_post['thumbnail']) ?>">
                                        <?php else: ?>
                                            <span class="material-symbols-outlined" style="font-size:26px;color:#c4b5fd;">image</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <hr class="section_divider">

                            <div class="form_group">
                                <label>본문 *</label>
                                <div class="editor_shell">
                                    <div class="etoolbar">
                                        <select id="sel-h" onchange="setBlock(this.value);this.blur()"
                                            style="height:28px;border:1px solid #e8eaf0;border-radius:5px;font-size:12px;padding:0 6px;font-family:inherit;background:#f5f6fa;color:#5c5c7a;outline:none;cursor:pointer;min-width:78px;">
                                            <option value="p">본문</option>
                                            <option value="h2">제목 (H2)</option>
                                            <option value="h3">소제목 (H3)</option>
                                            <option value="blockquote">인용문</option>
                                        </select>
                                        <div class="sep"></div>
                                        <button type="button" class="etb" onclick="execCmd('bold')"><b>B</b></button>
                                        <button type="button" class="etb" onclick="execCmd('italic')"><i>I</i></button>
                                        <button type="button" class="etb" onclick="execCmd('underline')"><u>U</u></button>
                                        <div class="sep"></div>
                                        <button type="button" class="etb" onclick="execCmd('insertUnorderedList')"><span class="material-symbols-outlined">format_list_bulleted</span></button>
                                        <button type="button" class="etb" onclick="execCmd('insertOrderedList')"><span class="material-symbols-outlined">format_list_numbered</span></button>
                                        <div class="sep"></div>
                                        <button type="button" class="etb" onclick="insertLink()"><span class="material-symbols-outlined">link</span></button>
                                        <button type="button" class="etb" onclick="insertImg()"><span class="material-symbols-outlined">image</span></button>
                                        <button type="button" class="etb" onclick="insertHr()" title="구분선"><span class="material-symbols-outlined">horizontal_rule</span></button>
                                        <button type="button" class="etb" id="tableBtn" onclick="toggleTablePanel()" title="표 삽입"><span class="material-symbols-outlined">table_chart</span></button>
                                        <div class="sep"></div>
                                        <button type="button" class="etb" id="srcToggleBtn" onclick="toggleSource()"><span class="material-symbols-outlined">code</span><span id="srcToggleLabel">HTML</span></button>
                                        <span id="autosave-stat" style="margin-left:auto;align-self:center;font-size:11px;color:#9999bb;white-space:nowrap;"></span>
                                    </div>
                           <div id="ce-editor" contenteditable="true" data-placeholder="본문을 입력하세요."></div>
                                    <textarea id="ce-source" spellcheck="false" style="display:none;width:100%;min-height:360px;padding:16px 18px;border:none;outline:none;font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:13px;line-height:1.7;color:#1a1a2e;background:#fafafa;resize:vertical;box-sizing:border-box;"></textarea>
                                </div>

                                <!-- 표 삽입 패널 -->
                                <div id="tablePanel" style="display:none;margin-top:8px;padding:12px;border:1px solid #e8eaf0;border-radius:8px;background:#f9fafb;align-items:center;gap:10px;flex-wrap:wrap;">
                                    <span style="font-size:12px;color:#5c5c7a;">행</span>
                                    <input type="number" id="tblRows" value="3" min="1" max="30" class="form_input" style="width:60px;padding:5px 8px;">
                                    <span style="font-size:12px;color:#5c5c7a;">열</span>
                                    <input type="number" id="tblCols" value="3" min="1" max="10" class="form_input" style="width:60px;padding:5px 8px;">
                                    <label style="font-size:12px;color:#5c5c7a;display:flex;gap:4px;align-items:center;cursor:pointer;">
                                        <input type="checkbox" id="tblHeader" checked>첫 행 헤더</label>
                                    <button type="button" class="btn_primary" onclick="insertTable()" style="font-size:12px;padding:6px 14px;">삽입</button>
                                    <button type="button" class="btn_neutral" onclick="toggleTablePanel()" style="font-size:12px;padding:6px 12px;">닫기</button>
                                </div>
                                <!-- 글자수 / 읽기시간 -->
                                <div id="charStat" style="margin-top:6px;font-size:12px;color:#9999bb;text-align:right;">0자 · 약 1분</div>
                            </div>

                            <hr class="section_divider">

                            <div class="form_group">
                                <div class="section_title">
                                    <span class="material-symbols-outlined" style="font-size:15px;">help</span>
                                    FAQ <span style="font-size:10px;font-weight:400;color:#9999bb;margin-left:4px">선택</span>
                                </div>
                                <?php for ($fi = 0; $fi < 5; $fi++):
                                    $fq = htmlspecialchars($edit_faqs[$fi]['q'] ?? '');
                                    $fa = htmlspecialchars($edit_faqs[$fi]['a'] ?? '');
                                ?>
                                    <div class="faq_row">
                                        <span class="faq_label">Q<?= $fi + 1 ?></span>
                                        <input type="text" name="faq_q_<?= $fi ?>" class="form_input"
                                            placeholder="질문을 입력하세요" value="<?= $fq ?>" style="margin-top:6px;">
                                        <textarea name="faq_a_<?= $fi ?>" placeholder="답변을 입력하세요"><?= $fa ?></textarea>
                                    </div>
                                <?php endfor; ?>
                            </div>

                            <hr class="section_divider">

                            <div class="form_group">
                                <div class="section_title">
                                    <span class="material-symbols-outlined" style="font-size:15px;">link</span>
                                    관련 링크 박스
                                    <span style="font-size:10px;font-weight:400;color:#9999bb;margin-left:4px">URL 입력 → 자동 가져오기 → 저장 시 자동 삽입</span>
                                </div>
                                <div style="display:flex;gap:8px;margin-bottom:10px;">
                                    <input type="text" id="linkUrlInput" class="form_input" placeholder="https://" style="flex:1;"
                                        onkeydown="if(event.key==='Enter'){event.preventDefault();fetchLinkMeta();}">
                                    <button type="button" class="btn_primary" onclick="fetchLinkMeta()" style="white-space:nowrap;">
                                        <span class="material-symbols-outlined" style="font-size:14px;">search</span>가져오기
                                    </button>
                                </div>
                                <div id="linkPreviewCard" style="display:none;border:1px solid #e8eaf0;border-radius:8px;overflow:hidden;background:#fff;margin-bottom:10px;">
                                    <div style="padding:12px 16px 10px;">
                                        <div id="lpTitle" style="font-size:14px;font-weight:700;color:#1a1a2e;margin-bottom:4px;"></div>
                                        <div id="lpDesc" style="font-size:12px;color:#6b7280;"></div>
                                    </div>
                                    <div id="lpUrl" style="padding:6px 16px;background:#f5f6fa;font-size:11px;color:#4f46e5;border-top:1px solid #e8eaf0;word-break:break-all;"></div>
                                    <div style="padding:10px 16px;display:flex;gap:8px;align-items:center;border-top:1px solid #e8eaf0;">
                                        <select id="lpPosition" class="form_input" style="width:auto;padding:6px 10px;font-size:12px;">
                                            <option value="before">FAQ 위에 삽입</option>
                                            <option value="after">FAQ 아래에 삽입</option>
                                            <option value="end">본문 맨 끝에 삽입</option>
                                        </select>
                                        <button type="button" class="btn_primary" onclick="addLinkBox()" style="font-size:12px;padding:7px 16px;">
                                            <span class="material-symbols-outlined" style="font-size:13px;">add</span>추가
                                        </button>
                                        <button type="button" class="btn_neutral" onclick="resetLinkPreview()" style="font-size:12px;padding:7px 14px;">취소</button>
                                    </div>
                                </div>
                                <div id="linkBoxList" style="display:flex;flex-direction:column;gap:8px;"></div>
                                <input type="hidden" id="link_boxes_json" name="link_boxes_json" value="[]">
                            </div>

                            <div class="form_footer">
                                <button type="submit" class="btn_primary">
                                    <span class="material-symbols-outlined" style="font-size:14px"><?= $is_edit ? 'save' : 'send' ?></span>
                                    <?= $is_edit ? '수정 저장' : '등록하기' ?>
                                </button>
                            </div>
                        </form>

                    </div><!-- /panel-write -->
                </div>
            </div>

            <!-- 목록 -->
            <div class="card">
                <div class="card_hd">
                    <span class="card_hd_title"><span class="material-symbols-outlined">list</span>칼럼 목록</span>
                    <span style="font-size:12px;color:#9999bb;"><?= $page ?> / <?= $total_pages ?> 페이지</span>
                </div>
                <?php if ($total === 0): ?>
                    <div class="empty_state">등록된 칼럼이 없습니다.</div>
                <?php else: ?>
                    <table class="eq_table">
                        <thead>
                            <tr>
                                <th class="tc" width="48">No.</th>
                                <th width="68">썸네일</th>
                                <th>제목</th>
                                <th class="tc" width="80">카테고리</th>
                                <th class="tc" width="95">작성일</th>
                                <th class="tc" width="54">조회</th>
                                <th class="tc" width="110">관리</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = mysqli_fetch_assoc($list_r)): ?>
                                <tr>
                                    <td style="text-align:center;color:#9999bb;"><?= (int)$row['id'] ?></td>
                                    <td>
                                        <?php if (!empty($row['thumbnail'])): ?>
                                            <img src="<?= htmlspecialchars($row['thumbnail']) ?>" class="eq_thumb">
                                        <?php else: ?>
                                            <div class="eq_nothumb"><span class="material-symbols-outlined">image_not_supported</span></div>
                                        <?php endif; ?>
                                    </td>
                                    <td class="eq_title">
                                        <a href="<?= $column_path ?>/column.php?id=<?= (int)$row['id'] ?>" target="_blank">
                                            <?= htmlspecialchars($row['title']) ?>
                                        </a>
                                        <?php if (($row['editor_type'] ?? 'html') === 'builder'): ?>
                                            <span style="font-size:9px;background:#fef9c3;color:#854d0e;padding:1px 5px;border-radius:4px;margin-left:4px;font-weight:700;">블록</span>
                                        <?php endif; ?>
                                    </td>
                                    <td style="text-align:center;">
                                        <span class="cat_badge"><?= htmlspecialchars($row['cat_name'] ?? '미분류') ?></span>
                                    </td>
                                    <td style="text-align:center;color:#9999bb;font-size:12px;"><?= date('Y.m.d', strtotime($row['created_at'])) ?></td>
                                    <td style="text-align:center;color:#9999bb;font-size:12px;"><?= number_format((int)$row['hit']) ?></td>
                                    <td style="text-align:center;">
                                        <div style="display:flex;gap:5px;justify-content:center;">
                                            <?php if (($row['editor_type'] ?? 'html') === 'builder'): ?>
                                                <a class="btn_edit" href="column_block_write.php?mode=modify&id=<?= (int)$row['id'] ?>"
                                                    style="background:#059669;">
                                                    <span class="material-symbols-outlined" style="font-size:11px">dashboard</span>블록
                                                </a>
                                            <?php else: ?>
                                                <a class="btn_edit" href="./column_admin.php?action=edit&id=<?= (int)$row['id'] ?>#write-card">
                                                    <span class="material-symbols-outlined" style="font-size:11px">edit</span>수정
                                                </a>
                                            <?php endif; ?>
                                            <button class="btn_del" onclick="if(confirm('삭제하시겠습니까?'))location.href='./column_admin.php?action=delete&id=<?= (int)$row['id'] ?>'">
                                                <span class="material-symbols-outlined" style="font-size:11px">delete</span>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                    <?php if ($total_pages > 1): ?>
                        <div class="pager">
                            <?php if ($page > 1): ?>
                                <a href="?page=<?= $page - 1 ?>"><span class="material-symbols-outlined" style="font-size:14px">chevron_left</span></a>
                            <?php endif; ?>
                            <?php for ($p = max(1, $page - 4); $p <= min($total_pages, $page + 4); $p++): ?>
                                <?php if ($p === $page): ?><span class="cur"><?= $p ?></span>
                                <?php else: ?><a href="?page=<?= $p ?>"><?= $p ?></a><?php endif; ?>
                            <?php endfor; ?>
                            <?php if ($page < $total_pages): ?>
                                <a href="?page=<?= $page + 1 ?>"><span class="material-symbols-outlined" style="font-size:14px">chevron_right</span></a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>

        </main>
    </div>

    <!-- 로딩 오버레이 -->
    <div class="loading-overlay" id="loadingOverlay">
        <div class="loading-spin"></div>
        <p style="color:#fff;font-size:15px;font-weight:700;">HTML 파싱 중...</p>
        <p style="color:rgba(255,255,255,0.6);font-size:13px;">이미지 추출 및 변환 중입니다. 잠시 기다려주세요.</p>
    </div>

    <script>
        var ED = document.getElementById('ce-editor');
        <?php if ($is_edit && !empty($edit_post['content'])): ?>
            ED.innerHTML = <?= json_encode($edit_post['content']) ?>;
        <?php endif; ?>

        function execCmd(cmd, val) {
            if (isSourceMode) {
                return;
            }
            ED.focus();
            document.execCommand(cmd, false, val || null);
        }

        function insertLink() {
            var u = prompt('링크 URL:', 'https://');
            if (u) execCmd('createLink', u);
        }

        function insertImg() {
            var u = prompt('이미지 URL:');
            if (u) execCmd('insertImage', u);
        }

        // ── 위지윅 ↔ HTML 소스 토글 ──────────────────────────────
        var SRC = document.getElementById('ce-source');
        var isSourceMode = false;

        function toggleSource() {
            var label = document.getElementById('srcToggleLabel');
            var btn = document.getElementById('srcToggleBtn');
            if (!isSourceMode) {
                // 위지윅 → 소스: 현재 innerHTML을 textarea에 펼침
                SRC.value = ED.innerHTML;
                ED.style.display = 'none';
                SRC.style.display = 'block';
                isSourceMode = true;
                label.textContent = '위지윅';
                btn.classList.add('etb-src-on');
                SRC.focus();
            } else {
                // 소스 → 위지윅: textarea 값을 innerHTML로 반영
                ED.innerHTML = SRC.value;
                SRC.style.display = 'none';
                ED.style.display = 'block';
                isSourceMode = false;
                label.textContent = 'HTML';
                btn.classList.remove('etb-src-on');
                ED.focus();
            }
        }

        document.getElementById('wform').addEventListener('submit', function(e) {
            // 소스 모드 상태로 저장하는 경우, textarea 내용을 에디터에 먼저 반영
            if (isSourceMode) {
                ED.innerHTML = SRC.value;
            }
            var html = ED.innerHTML.trim();
            if (!html || html === '<br>') {
                e.preventDefault();
                alert('본문을 입력해 주세요.');
                ED.focus();
                return;
            }
            var parser = new DOMParser();
            var doc = parser.parseFromString(html, 'text/html');
            doc.querySelectorAll('a.related-link-box').forEach(function(a) {
                a.remove();
            });
            var cleanHtml = (doc.querySelector('body') || {
                innerHTML: html
            }).innerHTML;
            var boxes = _linkBoxes;
            if (boxes.length) {
                var beforeBoxes = boxes.filter(function(b) {
                    return b.position === 'before';
                });
                var afterBoxes = boxes.filter(function(b) {
                    return b.position === 'after';
                });
                var endBoxes = boxes.filter(function(b) {
                    return b.position === 'end';
                });

                function makeBox(box) {
                    return '<a href="' + escHtml(box.url) + '" class="related-link-box" target="_blank" rel="noopener">' +
                        '<div class="rlb-body"><div class="rlb-title">' + escHtml(box.title || '') + '</div>' +
                        '<div class="rlb-desc">' + escHtml(box.desc || '') + '</div></div>' +
                        '<div class="rlb-url">' + escHtml(box.url) + '</div></a>';
                }
                var faqMatch = cleanHtml.match(/([\s\S]*?)(<[^>]*faq[^>]*>[\s\S]*)/i);
                if (faqMatch) {
                    cleanHtml = faqMatch[1] + beforeBoxes.map(makeBox).join('') +
                        faqMatch[2] + afterBoxes.map(makeBox).join('') +
                        endBoxes.map(makeBox).join('');
                } else {
                    cleanHtml = cleanHtml + boxes.map(makeBox).join('');
                }
            }
            document.getElementById('content_hidden').value = cleanHtml;
        });

        document.getElementById('tfile').addEventListener('change', function() {
            if (!this.files[0]) return;
            document.getElementById('tname').textContent = this.files[0].name;
            var r = new FileReader();
            r.onload = function(e) {
                document.getElementById('tprev').innerHTML = '<img src="' + e.target.result + '" style="width:100%;height:100%;object-fit:cover">';
            };
            r.readAsDataURL(this.files[0]);
        });

        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.write-tab-btn').forEach(function(btn) {
                btn.addEventListener('click', function() {
                    document.querySelectorAll('.write-tab-btn').forEach(function(b) {
                        b.classList.remove('active');
                    });
                    document.querySelectorAll('.write-panel').forEach(function(p) {
                        p.classList.remove('active');
                    });
                    this.classList.add('active');
                    document.getElementById('panel-' + this.dataset.tab).classList.add('active');
                });
            });
        });

        function onImportFile(input) {
            var p = document.getElementById('importPreview');
            if (input.files[0]) {
                var kb = (input.files[0].size / 1024).toFixed(1);
                p.textContent = '✓ ' + input.files[0].name + ' (' + kb + ' KB)';
                p.style.display = 'block';
            }
        }

        function handleImportDrop(e) {
            e.preventDefault();
            e.currentTarget.classList.remove('dragover');
            var f = e.dataTransfer.files[0];
            if (f) {
                var inp = document.getElementById('importFile');
                var dt = new DataTransfer();
                dt.items.add(f);
                inp.files = dt.files;
                onImportFile(inp);
            }
        }

        function addCategory() {
            var name = document.getElementById('newCatName').value.trim();
            if (!name) {
                alert('카테고리명을 입력해주세요.');
                return;
            }
            var fd = new FormData();
            fd.append('action', 'add_cat');
            fd.append('cat_name', name);
            fetch('./column_admin.php', {
                    method: 'POST',
                    body: fd
                })
                .then(function() {
                    location.reload();
                });
        }

        // 태그 — 직접 작성
        (function() {
            var input = document.getElementById('tagInput');
            var list = document.getElementById('tagList');
            var hidden = document.getElementById('tags_hidden');
            if (!input) return;
            var tags = [];
            var existing = hidden.value.trim();
            if (existing) existing.split(',').forEach(function(t) {
                t = t.trim().replace(/^#/, '');
                if (t) {
                    tags.push(t);
                    renderChip(t);
                }
            });
            input.addEventListener('keydown', function(e) {
                if (e.key !== 'Enter') return;
                e.preventDefault();
                var val = input.value.trim().replace(/^#+/, '');
                if (!val || tags.indexOf(val) !== -1) {
                    input.value = '';
                    return;
                }
                tags.push(val);
                renderChip(val);
                sync();
                input.value = '';
            });

            function renderChip(tag) {
                var chip = document.createElement('span');
                chip.className = 'tag-chip';
                chip.textContent = tag;
                var del = document.createElement('button');
                del.type = 'button';
                del.className = 'tag-del';
                del.textContent = '×';
                del.onclick = function() {
                    tags.splice(tags.indexOf(tag), 1);
                    chip.remove();
                    sync();
                };
                chip.appendChild(del);
                list.appendChild(chip);
            }

            function sync() {
                hidden.value = tags.map(function(t) {
                    return '#' + t;
                }).join(',');
            }
        })();

        // 태그 — 가져오기
        (function() {
            var input = document.getElementById('importTagInput');
            var list = document.getElementById('importTagList');
            var hidden = document.getElementById('import_tags_hidden');
            if (!input) return;
            var tags = [];
            input.addEventListener('keydown', function(e) {
                if (e.key !== 'Enter') return;
                e.preventDefault();
                var val = input.value.trim().replace(/^#+/, '');
                if (!val || tags.indexOf(val) !== -1) {
                    input.value = '';
                    return;
                }
                tags.push(val);
                renderChip(val);
                sync();
                input.value = '';
            });

            function renderChip(tag) {
                var chip = document.createElement('span');
                chip.className = 'tag-chip';
                chip.textContent = tag;
                var del = document.createElement('button');
                del.type = 'button';
                del.className = 'tag-del';
                del.textContent = '×';
                del.onclick = function() {
                    tags.splice(tags.indexOf(tag), 1);
                    chip.remove();
                    sync();
                };
                chip.appendChild(del);
                list.appendChild(chip);
            }

            function sync() {
                hidden.value = tags.map(function(t) {
                    return '#' + t;
                }).join(',');
            }
        })();

        /* ── 블록 타입 적용 + 드롭다운 현재상태 반영 ───────────── */
        function setBlock(tag) {
            if (isSourceMode) return;
            ED.focus();
            document.execCommand('formatBlock', false, tag);
        }

        function syncBlockSelect() {
            if (isSourceMode) return;
            var sel = window.getSelection();
            if (!sel.rangeCount) return;
            var n = sel.anchorNode;
            while (n && n !== ED) {
                if (n.nodeType === 1) {
                    var t = n.tagName.toLowerCase();
                    if (['p', 'h2', 'h3', 'blockquote'].indexOf(t) > -1) {
                        document.getElementById('sel-h').value = t;
                        return;
                    }
                }
                n = n.parentNode;
            }
            document.getElementById('sel-h').value = 'p';
        }
        ['keyup', 'mouseup'].forEach(function(ev) {
            ED.addEventListener(ev, syncBlockSelect);
        });

        /* ── 자동저장 (localStorage 임시저장 + 이탈경고) ────────── */
        var DRAFT_KEY = 'column_draft_<?= $is_edit ? (int)$edit_post['id'] : 'new' ?>';
        var formSubmitting = false;
        var lastSaved = '';

        function collectDraft() {
            return JSON.stringify({
                title: (document.querySelector('[name=title]') || {}).value || '',
                subtitle: (document.querySelector('[name=subtitle]') || {}).value || '',
                content: isSourceMode ? SRC.value : ED.innerHTML,
                ts: Date.now()
            });
        }

        function saveDraft() {
            var cur = collectDraft();
            if (cur === lastSaved) return;
            try {
                localStorage.setItem(DRAFT_KEY, cur);
                lastSaved = cur;
                var s = document.getElementById('autosave-stat');
                if (s) {
                    s.textContent = '임시저장됨 · ' + new Date().toLocaleTimeString('ko-KR', {
                        hour: '2-digit',
                        minute: '2-digit'
                    });
                }
            } catch (e) {}
        }
        // 입력 시 디바운스 저장
        var saveTimer;

        function queueSave() {
            clearTimeout(saveTimer);
            saveTimer = setTimeout(saveDraft, 800);
        }
        ED.addEventListener('input', queueSave);
        ['title', 'subtitle'].forEach(function(nm) {
            var el = document.querySelector('[name=' + nm + ']');
            if (el) el.addEventListener('input', queueSave);
        });
        SRC.addEventListener('input', queueSave);
        setInterval(saveDraft, 15000); // 안전망: 15초마다

        // 페이지 진입 시 복원 제안
        (function restoreDraft() {
            var raw = localStorage.getItem(DRAFT_KEY);
            if (!raw) return;
            try {
                var d = JSON.parse(raw);
                var cur = ED.innerHTML.trim();
                // 현재 본문과 다를 때만 물어봄 (수정모드에서 이미 같으면 패스)
                if (!d.content || d.content.trim() === cur) return;
                var when = new Date(d.ts).toLocaleString('ko-KR');
                if (confirm('임시저장된 내용이 있습니다 (' + when + ')\n복원할까요?\n\n[취소] = 무시하고 새로 작성')) {
                    if (d.title) document.querySelector('[name=title]').value = d.title;
                    if (d.subtitle) document.querySelector('[name=subtitle]').value = d.subtitle;
                    ED.innerHTML = d.content;
                } else {
                    localStorage.removeItem(DRAFT_KEY);
                }
            } catch (e) {}
        })();

        // 저장(제출) 시 임시저장 비우기 + 이탈경고 해제
        document.getElementById('wform').addEventListener('submit', function() {
            formSubmitting = true;
            try {
                localStorage.removeItem(DRAFT_KEY);
            } catch (e) {}
        });

        // 안 저장하고 나가려 하면 경고
        window.addEventListener('beforeunload', function(e) {
            if (formSubmitting) return;
            var cur = isSourceMode ? SRC.value : ED.innerHTML;
            if (cur && cur.trim() && cur.trim() !== '<br>') {
                e.preventDefault();
                e.returnValue = '';
            }
        });

        // ── 공통 유틸
        function escHtml(s) {
            return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
        }

        // ── ★ 수정 2/3: 가져오기 패널 링크 박스 — 클라이언트 직접 fetch
        var _importLinkMeta = null;

        async function fetchImportLinkMeta() {
            var rawUrl = document.getElementById('importLinkUrlInput').value.trim();
            if (!rawUrl) {
                alert('URL을 입력해주세요.');
                return;
            }
            var url = rawUrl.startsWith('/') ? location.origin + rawUrl : rawUrl;
            try {
                var res = await fetch(url, {
                    credentials: 'same-origin'
                });
                if (!res.ok) {
                    alert('페이지 로드 실패: ' + res.status);
                    return;
                }
                var html = await res.text();
                var parser = new DOMParser();
                var doc = parser.parseFromString(html, 'text/html');
                var ogTitle = doc.querySelector('meta[property="og:title"]');
                var title = ogTitle ? ogTitle.getAttribute('content') : (doc.title || '');
                var ogDesc = doc.querySelector('meta[property="og:description"]');
                var desc = ogDesc ? ogDesc.getAttribute('content') : '';
                if (!desc) {
                    var md = doc.querySelector('meta[name="description"]');
                    if (md) desc = md.getAttribute('content') || '';
                }
                _importLinkMeta = {
                    title: title.trim(),
                    desc: desc.trim(),
                    url: rawUrl
                };
                document.getElementById('ilpTitle').textContent = _importLinkMeta.title || '(제목 없음)';
                document.getElementById('ilpDesc').textContent = _importLinkMeta.desc || '(설명 없음)';
                document.getElementById('ilpUrl').textContent = _importLinkMeta.url;
                document.getElementById('importLinkPreviewCard').style.display = 'block';
            } catch (e) {
                var msg = e.message || '';
                if (msg.includes('fetch') || msg.includes('CORS') || msg.includes('NetworkError'))
                    msg = '외부 도메인은 가져올 수 없습니다.';
                alert('오류: ' + msg);
            }
        }

        // ── ★ 수정 3/3: display='none' 방식으로
        function resetImportLinkPreview() {
            _importLinkMeta = null;
            document.getElementById('importLinkUrlInput').value = '';
            document.getElementById('importLinkPreviewCard').style.display = 'none';
        }

        // ── HTML 가져오기 처리 (JS 파싱 → 서버 저장)
        async function processAndImport() {
            var fileInput = document.getElementById('importFile');
            var catSel = document.querySelector('[name="import_cat_id"]');
            var subtitle = (document.getElementById('import_subtitle') || {
                value: ''
            }).value.trim();
            var tags = (document.getElementById('import_tags_hidden') || {
                value: ''
            }).value;

            function setStatus(msg, color) {
                var el = document.getElementById('import-status');
                if (el) {
                    el.style.color = color || '#4f46e5';
                    el.textContent = msg;
                }
            }
            if (!fileInput || !fileInput.files.length) {
                alert('파일을 먼저 선택해주세요.');
                return;
            }

            setStatus('파일 읽는 중...', '#4f46e5');
            document.getElementById('loadingOverlay').classList.add('show');

            try {
                var html = await fileInput.files[0].text();
                var parser = new DOMParser();
                var doc = parser.parseFromString(html, 'text/html');

                ['script', 'style', 'noscript', 'iframe', 'nav', 'header', 'footer', 'form', 'button', 'svg'].forEach(function(t) {
                    doc.querySelectorAll(t).forEach(function(el) {
                        el.remove();
                    });
                });

                var imgs = Array.from(doc.querySelectorAll('img'));
                for (var i = 0; i < imgs.length; i++) {
                    var img = imgs[i];
                    var src = (img.getAttribute('src') || '').replace(/^["'`\s]+|["'`;\s]+$/g, '').trim();
                    if (!src) {
                        img.parentNode && img.parentNode.removeChild(img);
                        continue;
                    }
                    if (src.startsWith('data:image/')) {
                        setStatus('이미지 업로드 중... (' + (i + 1) + '/' + imgs.length + ')', '#4f46e5');
                        try {
                            var blob = await (await fetch(src)).blob();
                            var ext = blob.type.split('/')[1].replace('jpeg', 'jpg') || 'jpg';
                            var fd = new FormData();
                            fd.append('action', 'upload_img');
                            fd.append('upload_b64', blob, 'img_' + Date.now() + '.' + ext);
                            var res = await fetch('./column_admin.php', {
                                method: 'POST',
                                body: fd
                            });
                            var data = await res.json();
                            if (data.url) {
                                img.setAttribute('src', data.url);
                                img.removeAttribute('style');
                            } else {
                                img.parentNode && img.parentNode.removeChild(img);
                            }
                        } catch (e) {
                            img.parentNode && img.parentNode.removeChild(img);
                        }
                    } else if (!src.startsWith('http') && !src.startsWith('/')) {
                        img.parentNode && img.parentNode.removeChild(img);
                    }
                }

                var title = (doc.querySelector('h1') || {
                        textContent: ''
                    }).textContent.trim() ||
                    (doc.querySelector('title') || {
                        textContent: ''
                    }).textContent.trim() ||
                    fileInput.files[0].name.replace(/\.[^.]+$/, '');
                var bodyEl = doc.querySelector('body');
                var cleaned = (bodyEl ? bodyEl.innerHTML : doc.documentElement.innerHTML)
                    .replace(/<h1[^>]*>[\s\S]*?<\/h1>/gi, '').trim();

                if (_importLinkMeta) {
                    var box = '<a href="' + _importLinkMeta.url + '" class="related-link-box" target="_blank" rel="noopener">' +
                        '<div class="rlb-body">' +
                        '<div class="rlb-title">' + escHtml(_importLinkMeta.title || '') + '</div>' +
                        '<div class="rlb-desc">' + escHtml(_importLinkMeta.desc || '') + '</div>' +
                        '</div>' +
                        '<div class="rlb-url">' + escHtml(_importLinkMeta.url) + '</div>' +
                        '</a>';
                    var pos = (document.getElementById('importLinkPosition') || {
                        value: 'before'
                    }).value;
                    var faqMatch = cleaned.match(/([\s\S]*?)(<[^>]*faq[^>]*>[\s\S]*)/i);
                    if (faqMatch && pos !== 'end') {
                        cleaned = pos === 'before' ?
                            faqMatch[1] + box + faqMatch[2] :
                            faqMatch[1] + faqMatch[2] + box;
                    } else {
                        cleaned = cleaned + box;
                    }
                }

                setStatus('저장 중...', '#4f46e5');
                var fd2 = new FormData();
                fd2.append('action', 'import_html_processed');
                fd2.append('import_cat_id', catSel ? catSel.value : '0');
                fd2.append('import_title', title);
                fd2.append('import_subtitle', subtitle);
                fd2.append('import_tags', tags);
                fd2.append('import_content', cleaned);
                var thumbInput = document.getElementById('importThumb');
                if (thumbInput && thumbInput.files[0]) fd2.append('import_thumb', thumbInput.files[0]);

                var res2 = await fetch('./column_admin.php', {
                    method: 'POST',
                    body: fd2
                });
                var data2 = await res2.json();

                document.getElementById('loadingOverlay').classList.remove('show');
                if (data2.ok) {
                    setStatus('✓ 완료!', '#059669');
                    setTimeout(function() {
                        location.href = './column_admin.php?msg=' + encodeURIComponent('ok:HTML 가져오기 완료!');
                    }, 500);
                } else {
                    setStatus('저장 실패: ' + (data2.err || '오류'), '#dc2626');
                }
            } catch (e) {
                document.getElementById('loadingOverlay').classList.remove('show');
                setStatus('오류: ' + e.message, '#dc2626');
            }
        }

        // ── 직접 작성 패널 링크 박스
        var _linkMeta = null;
        var _linkBoxes = [];

        <?php if ($is_edit && !empty($edit_post['content'])): ?>
                (function() {
                    var parser = new DOMParser();
                    var doc = parser.parseFromString(<?= json_encode($edit_post['content']) ?>, 'text/html');
                    doc.querySelectorAll('a.related-link-box').forEach(function(a) {
                        var title = (a.querySelector('.rlb-title') || {
                            textContent: ''
                        }).textContent;
                        var desc = (a.querySelector('.rlb-desc') || {
                            textContent: ''
                        }).textContent;
                        var url = a.getAttribute('href') || '';
                        if (url) _linkBoxes.push({
                            title: title,
                            desc: desc,
                            url: url,
                            position: 'after'
                        });
                    });
                    renderLinkBoxList();
                    syncLinkBoxJson();
                })();
        <?php endif; ?>

        async function fetchLinkMeta() {
            var rawUrl = document.getElementById('linkUrlInput').value.trim();
            if (!rawUrl) {
                alert('URL을 입력해주세요.');
                return;
            }
            var url = rawUrl.startsWith('/') ? location.origin + rawUrl : rawUrl;
            try {
                var res = await fetch(url, {
                    credentials: 'same-origin'
                });
                if (!res.ok) {
                    alert('페이지 로드 실패: ' + res.status);
                    return;
                }
                var html = await res.text();
                var parser = new DOMParser();
                var doc = parser.parseFromString(html, 'text/html');
                var ogTitle = doc.querySelector('meta[property="og:title"]');
                var title = ogTitle ? ogTitle.getAttribute('content') : (doc.title || '');
                var ogDesc = doc.querySelector('meta[property="og:description"]');
                var desc = ogDesc ? ogDesc.getAttribute('content') : '';
                if (!desc) {
                    var md = doc.querySelector('meta[name="description"]');
                    if (md) desc = md.getAttribute('content') || '';
                }
                _linkMeta = {
                    title: title.trim(),
                    desc: desc.trim(),
                    url: rawUrl
                };
                document.getElementById('lpTitle').textContent = _linkMeta.title || '(제목 없음)';
                document.getElementById('lpDesc').textContent = _linkMeta.desc || '(설명 없음)';
                document.getElementById('lpUrl').textContent = _linkMeta.url;
                document.getElementById('linkPreviewCard').style.display = 'block';
            } catch (e) {
                var msg = e.message || '';
                if (msg.includes('fetch') || msg.includes('CORS') || msg.includes('NetworkError'))
                    msg = '외부 도메인은 가져올 수 없습니다. 제목/설명을 직접 입력해주세요.';
                alert('오류: ' + msg);
            }
        }

        function addLinkBox() {
            if (!_linkMeta) return;
            var pos = (document.getElementById('lpPosition') || {
                value: 'after'
            }).value;
            _linkBoxes.push({
                title: _linkMeta.title || '',
                desc: _linkMeta.desc || '',
                url: _linkMeta.url,
                position: pos
            });
            renderLinkBoxList();
            syncLinkBoxJson();
            resetLinkPreview();
        }

        function removeLinkBox(idx) {
            _linkBoxes.splice(idx, 1);
            renderLinkBoxList();
            syncLinkBoxJson();
        }

        function renderLinkBoxList() {
            var list = document.getElementById('linkBoxList');
            if (!list) return;
            list.innerHTML = '';
            _linkBoxes.forEach(function(box, i) {
                var card = document.createElement('div');
                card.style.cssText = 'border:1px solid #e8eaf0;border-radius:8px;overflow:hidden;background:#fff;';
                card.innerHTML =
                    '<div style="padding:10px 14px 8px;">' +
                    '<div style="font-size:13px;font-weight:700;color:#1a1a2e;margin-bottom:3px;">' + escHtml(box.title || '(제목 없음)') + '</div>' +
                    '<div style="font-size:12px;color:#6b7280;">' + escHtml(box.desc || '') + '</div>' +
                    '</div>' +
                    '<div style="display:flex;align-items:center;padding:6px 14px;background:#f5f6fa;border-top:1px solid #e8eaf0;gap:8px;">' +
                    '<span style="font-size:11px;color:#4f46e5;flex:1;word-break:break-all;">' + escHtml(box.url) + '</span>' +
                    '<select onchange="_linkBoxes[' + i + '].position=this.value;syncLinkBoxJson();" style="font-size:11px;padding:3px 6px;border:1px solid #e8eaf0;border-radius:5px;">' +
                    '<option value="before"' + (box.position === 'before' ? ' selected' : '') + '>FAQ 위</option>' +
                    '<option value="after"' + (box.position === 'after' ? ' selected' : '') + '>FAQ 아래</option>' +
                    '<option value="end"' + (box.position === 'end' ? ' selected' : '') + '>맨 끝</option>' +
                    '</select>' +
                    '<button type="button" onclick="removeLinkBox(' + i + ')" style="background:#fee2e2;color:#dc2626;border:none;border-radius:5px;padding:3px 8px;font-size:11px;font-weight:700;cursor:pointer;">삭제</button>' +
                    '</div>';
                list.appendChild(card);
            });
        }

        function syncLinkBoxJson() {
            var el = document.getElementById('link_boxes_json');
            if (el) el.value = JSON.stringify(_linkBoxes);
        }

        function resetLinkPreview() {
            _linkMeta = null;
            document.getElementById('linkUrlInput').value = '';
            document.getElementById('linkPreviewCard').style.display = 'none';
        }

        var toast = document.getElementById('toast');
        if (toast) {
            setTimeout(function() {
                toast.style.transition = 'opacity .3s';
                toast.style.opacity = '0';
                setTimeout(function() {
                    toast.remove();
                }, 300);
            }, 3500);
        }
        /* ── 본문 이미지: 파일 업로드 → 캐럿 위치에 삽입 (URL prompt 대체) ── */
        var savedRange = null;

        function saveCeRange() {
            var sel = window.getSelection();
            if (sel.rangeCount && ED.contains(sel.anchorNode)) savedRange = sel.getRangeAt(0).cloneRange();
        }
        ['keyup', 'mouseup'].forEach(function(ev) {
            ED.addEventListener(ev, saveCeRange);
        });

        function insertImageAtCaret(url) {
            ED.focus();
            var sel = window.getSelection();
            if (savedRange) {
                sel.removeAllRanges();
                sel.addRange(savedRange);
            }
            document.execCommand('insertHTML', false,
                '<img src="' + url + '" style="max-width:100%" alt=""><p><br></p>');
            if (typeof queueSave === 'function') queueSave();
        }

        function uploadCeImage(file) {
            if (!file || file.type.indexOf('image') !== 0) return;
            var stat = document.getElementById('autosave-stat');
            if (stat) stat.textContent = '이미지 업로드 중…';
            var fd = new FormData();
            fd.append('action', 'upload_img');
            fd.append('upload_b64', file, file.name || 'paste.png');
            fetch('./column_admin.php', {
                    method: 'POST',
                    body: fd
                })
                .then(function(r) {
                    return r.json();
                })
                .then(function(d) {
                    if (stat) stat.textContent = '';
                    if (d && d.url) {
                        insertImageAtCaret(d.url);
                    } else {
                        alert('이미지 업로드 실패');
                    }
                })
                .catch(function() {
                    if (stat) stat.textContent = '';
                    alert('이미지 업로드 오류');
                });
        }

        // 툴바 이미지 버튼 → 파일 선택
        var _ceImgInput = document.createElement('input');
        _ceImgInput.type = 'file';
        _ceImgInput.accept = 'image/*';
        _ceImgInput.style.display = 'none';
        document.body.appendChild(_ceImgInput);
        _ceImgInput.addEventListener('change', function() {
            if (this.files[0]) uploadCeImage(this.files[0]);
            this.value = '';
        });

        function insertImg() {
            saveCeRange();
            _ceImgInput.click();
        }

        // 보너스: 붙여넣기 이미지 (스샷·복사한 사진)
        ED.addEventListener('paste', function(e) {
            var items = (e.clipboardData || {}).items || [];
            for (var i = 0; i < items.length; i++) {
                if (items[i].type.indexOf('image') === 0) {
                    e.preventDefault();
                    saveCeRange();
                    uploadCeImage(items[i].getAsFile());
                    return;
                }
            }
        });
        // 보너스: 드래그&드롭 이미지
        ED.addEventListener('dragover', function(e) {
            e.preventDefault();
        });
        ED.addEventListener('drop', function(e) {
            var f = e.dataTransfer && e.dataTransfer.files[0];
            if (f && f.type.indexOf('image') === 0) {
                e.preventDefault();
                try {
                    var r = document.caretRangeFromPoint(e.clientX, e.clientY);
                    if (r) savedRange = r;
                } catch (_) {}
                uploadCeImage(f);
            }
        });
        /* ── 구분선 ── */
        function insertHr() {
            if (isSourceMode) return;
            ED.focus();
            document.execCommand('insertHTML', false, '<hr><p><br></p>');
            if (typeof queueSave === 'function') queueSave();
        }

        /* ── 표 삽입 (행·열 지정 + 모바일 가로스크롤 래핑) ── */
        function toggleTablePanel() {
            var p = document.getElementById('tablePanel');
            p.style.display = (p.style.display === 'flex') ? 'none' : 'flex';
        }

        function insertTable() {
            if (isSourceMode) {
                alert('위지윅 모드에서 삽입하세요.');
                return;
            }
            var rows = Math.max(1, parseInt(document.getElementById('tblRows').value) || 3);
            var cols = Math.max(1, parseInt(document.getElementById('tblCols').value) || 3);
            var head = document.getElementById('tblHeader').checked;
            var h = '<div style="overflow-x:auto"><table>';
            var bodyStart = 0;
            if (head) {
                h += '<thead><tr>';
                for (var c = 0; c < cols; c++) h += '<th>제목' + (c + 1) + '</th>';
                h += '</tr></thead>';
                bodyStart = 1;
            }
            h += '<tbody>';
            for (var r = bodyStart; r < rows; r++) {
                h += '<tr>';
                for (var c2 = 0; c2 < cols; c2++) h += '<td>내용</td>';
                h += '</tr>';
            }
            h += '</tbody></table></div><p><br></p>';
            ED.focus();
            if (typeof savedRange !== 'undefined' && savedRange) {
                var s = window.getSelection();
                s.removeAllRanges();
                s.addRange(savedRange);
            }
            document.execCommand('insertHTML', false, h);
            toggleTablePanel();
            if (typeof queueSave === 'function') queueSave();
        }

        /* ── 이미지: figure+figcaption으로 삽입 (③의 insertImageAtCaret 덮어쓰기) ── */
        function insertImageAtCaret(url) {
            ED.focus();
            var sel = window.getSelection();
            if (typeof savedRange !== 'undefined' && savedRange) {
                sel.removeAllRanges();
                sel.addRange(savedRange);
            }
            document.execCommand('insertHTML', false,
                '<figure><img src="' + url + '" style="max-width:100%" alt=""><figcaption></figcaption></figure><p><br></p>');
            if (typeof queueSave === 'function') queueSave();
        }
        /* 저장 직전(capture): 빈 캡션 제거 — 본문 빌드 전에 실행돼야 해서 capture=true */
        document.getElementById('wform').addEventListener('submit', function() {
            ED.querySelectorAll('figure figcaption').forEach(function(fc) {
                if (fc.textContent.trim() === '') fc.parentNode.removeChild(fc);
            });
        }, true);

        /* ── 글자수 / 예상 읽기시간 ── */
        function updateCharStat() {
            var txt = (ED.innerText || ED.textContent || '').replace(/\s/g, '');
            var n = txt.length;
            var min = Math.max(1, Math.round(n / 500)); // 한국어 약 500자/분
            var el = document.getElementById('charStat');
            if (el) el.textContent = n.toLocaleString() + '자 · 약 ' + min + '분';
        }
        ED.addEventListener('input', updateCharStat);
        updateCharStat();
    </script>
</body>

</html>