<?php
// ============ 설정 ============
$case_label = '임상케이스';
$upload_dir = '/uploads/case';
$table      = 'sal_case';
$cat_table  = 'sal_case_cat';
// ==============================

require_once __DIR__ . '/../inc/bootstrap.php';

// 패키지가 어디에 설치되든 공개 케이스 페이지(sub/) 경로가 항상 맞도록 동적 계산
$case_path = (defined('SAL_BASE_URL') ? SAL_BASE_URL : '') . '/sub';

global $connect_db;
$db = $connect_db;

// ── 테이블 자동 생성 ─────────────────────────────────────
mysqli_query($db, "CREATE TABLE IF NOT EXISTS `{$cat_table}` (
    `id`   INT(11) NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(100) NOT NULL DEFAULT '',
    `sort` INT(11) DEFAULT 0,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$chk = mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) as cnt FROM `{$cat_table}`"));
if ((int)$chk['cnt'] === 0) mysqli_query($db, "INSERT INTO `{$cat_table}` (name,sort) VALUES('미분류',0)");

mysqli_query($db, "CREATE TABLE IF NOT EXISTS `{$table}` (
    `id`            INT(11) NOT NULL AUTO_INCREMENT,
    `cat_id`        INT(11) DEFAULT 0,
    `title`         VARCHAR(500) NOT NULL DEFAULT '',
    `subtitle`      VARCHAR(500) NOT NULL DEFAULT '',
    `content`       TEXT,
    `image_before`  VARCHAR(500) DEFAULT '',
    `image_after`   VARCHAR(500) DEFAULT '',
    `tags`          VARCHAR(500) DEFAULT '',
    `visible`       TINYINT(1) DEFAULT 1,
    `hit`           INT(11) DEFAULT 0,
    `created_at`    DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ── 카테고리 목록 ─────────────────────────────────────────
function case_cats($db, $cat_table) {
    $cats = [];
    $r = mysqli_query($db, "SELECT * FROM `{$cat_table}` ORDER BY sort ASC, id ASC");
    if ($r) while ($c = mysqli_fetch_assoc($r)) $cats[] = $c;
    return $cats;
}
$cats = case_cats($db, $cat_table);

// ── 이미지 업로드 헬퍼 ────────────────────────────────────
function case_upload($field, $upload_dir, $db) {
    if (empty($_FILES[$field]['name']) || $_FILES[$field]['error'] !== UPLOAD_ERR_OK) return null;
    $dir = $_SERVER['DOCUMENT_ROOT'] . $upload_dir . '/';
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    $ext  = strtolower(pathinfo($_FILES[$field]['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'gif'], true)) return null;
    $name = 'case_' . time() . '_' . substr(md5(rand()), 0, 8) . '.' . $ext;
    if (move_uploaded_file($_FILES[$field]['tmp_name'], $dir . $name))
        return mysqli_real_escape_string($db, $upload_dir . '/' . $name);
    return null;
}

$action = $_GET['action'] ?? 'list';
$id     = (int)($_GET['id'] ?? 0);
$msg    = '';

// ── 카테고리 추가/삭제 ────────────────────────────────────
if ($action === 'cat_add' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = mysqli_real_escape_string($db, trim($_POST['cat_name'] ?? ''));
    if ($name !== '') mysqli_query($db, "INSERT INTO `{$cat_table}` (name,sort) VALUES('{$name}',999)");
    header('Location: ./case_admin.php?msg=' . urlencode('ok:카테고리가 추가되었습니다.'));
    exit;
}
if ($action === 'cat_del' && $id) {
    mysqli_query($db, "UPDATE `{$table}` SET cat_id=0 WHERE cat_id={$id}");
    mysqli_query($db, "DELETE FROM `{$cat_table}` WHERE id={$id}");
    header('Location: ./case_admin.php?msg=' . urlencode('ok:카테고리가 삭제되었습니다.'));
    exit;
}

// ── 등록 ─────────────────────────────────────────────────
if ($action === 'insert' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $cat_id   = (int)($_POST['cat_id'] ?? 0);
    $title    = mysqli_real_escape_string($db, stripslashes(trim($_POST['title'] ?? '')));
    $subtitle = mysqli_real_escape_string($db, stripslashes(trim($_POST['subtitle'] ?? '')));
    $content  = mysqli_real_escape_string($db, stripslashes(trim($_POST['content'] ?? '')));
    $tags     = mysqli_real_escape_string($db, stripslashes(trim($_POST['tags'] ?? '')));
    $visible  = isset($_POST['visible']) ? 1 : 0;
    $img_b    = case_upload('image_before', $upload_dir, $db);
    $img_a    = case_upload('image_after', $upload_dir, $db);

    if (!$title) {
        $msg = 'error:제목을 입력해 주세요.';
    } elseif (!$img_b || !$img_a) {
        $msg = 'error:전/후 사진을 둘 다 올려주세요.';
    } else {
        mysqli_query($db, "INSERT INTO `{$table}`
            (cat_id,title,subtitle,content,image_before,image_after,tags,visible,created_at)
            VALUES({$cat_id},'{$title}','{$subtitle}','{$content}','{$img_b}','{$img_a}','{$tags}',{$visible},NOW())");
        $msg = 'ok:등록되었습니다.';
    }
}

// ── 수정 ─────────────────────────────────────────────────
if ($action === 'update' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $eid      = (int)($_POST['id'] ?? 0);
    $cat_id   = (int)($_POST['cat_id'] ?? 0);
    $title    = mysqli_real_escape_string($db, stripslashes(trim($_POST['title'] ?? '')));
    $subtitle = mysqli_real_escape_string($db, stripslashes(trim($_POST['subtitle'] ?? '')));
    $content  = mysqli_real_escape_string($db, stripslashes(trim($_POST['content'] ?? '')));
    $tags     = mysqli_real_escape_string($db, stripslashes(trim($_POST['tags'] ?? '')));
    $visible  = isset($_POST['visible']) ? 1 : 0;

    $extra = '';
    $img_b = case_upload('image_before', $upload_dir, $db);
    if ($img_b) {
        $old = mysqli_fetch_assoc(mysqli_query($db, "SELECT image_before FROM `{$table}` WHERE id={$eid}"));
        if (!empty($old['image_before'])) @unlink($_SERVER['DOCUMENT_ROOT'] . $old['image_before']);
        $extra .= ",image_before='{$img_b}'";
    }
    $img_a = case_upload('image_after', $upload_dir, $db);
    if ($img_a) {
        $old = mysqli_fetch_assoc(mysqli_query($db, "SELECT image_after FROM `{$table}` WHERE id={$eid}"));
        if (!empty($old['image_after'])) @unlink($_SERVER['DOCUMENT_ROOT'] . $old['image_after']);
        $extra .= ",image_after='{$img_a}'";
    }

    mysqli_query($db, "UPDATE `{$table}` SET
        cat_id={$cat_id},title='{$title}',subtitle='{$subtitle}',content='{$content}',
        tags='{$tags}',visible={$visible} {$extra} WHERE id={$eid}");
    $msg = 'ok:수정되었습니다.';
}

// ── 삭제 ─────────────────────────────────────────────────
if ($action === 'delete' && $id) {
    $old = mysqli_fetch_assoc(mysqli_query($db, "SELECT image_before,image_after FROM `{$table}` WHERE id={$id}"));
    if ($old) {
        if (!empty($old['image_before'])) @unlink($_SERVER['DOCUMENT_ROOT'] . $old['image_before']);
        if (!empty($old['image_after']))  @unlink($_SERVER['DOCUMENT_ROOT'] . $old['image_after']);
    }
    mysqli_query($db, "DELETE FROM `{$table}` WHERE id={$id}");
    header('Location: ./case_admin.php?msg=' . urlencode('ok:삭제되었습니다.'));
    exit;
}

// ── 공개여부 토글 ──────────────────────────────────────────
if ($action === 'toggle' && $id) {
    mysqli_query($db, "UPDATE `{$table}` SET visible = 1-visible WHERE id={$id}");
    header('Location: ./case_admin.php?msg=' . urlencode('ok:공개 상태가 변경되었습니다.'));
    exit;
}

// ── 수정 폼 데이터 ─────────────────────────────────────────
if ($action === 'edit' && $id) {
    $r = mysqli_query($db, "SELECT * FROM `{$table}` WHERE id={$id}");
    $edit_post = $r ? mysqli_fetch_assoc($r) : null;
}
if (!$msg && isset($_GET['msg'])) $msg = urldecode($_GET['msg']);

// ── 목록 ─────────────────────────────────────────────────
$page        = max(1, (int)($_GET['page'] ?? 1));
$per_page    = 12;
$offset      = ($page - 1) * $per_page;
$total       = (int)(mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) cnt FROM `{$table}`"))['cnt'] ?? 0);
$total_pages = max(1, ceil($total / $per_page));
$list_r      = mysqli_query($db, "SELECT c.id,c.title,c.subtitle,c.created_at,c.hit,c.visible,c.image_before,c.image_after,cc.name as cat_name
    FROM `{$table}` c LEFT JOIN `{$cat_table}` cc ON c.cat_id=cc.id
    ORDER BY c.id DESC LIMIT {$offset},{$per_page}");
$is_edit = ($action === 'edit' && !empty($edit_post));
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($case_label) ?> 관리</title>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Pretendard','Apple SD Gothic Neo',sans-serif;background:#f5f6fa;color:#1a1a2e}
.wrap{display:flex;min-height:100vh}
.main{flex:1;padding:32px 40px;max-width:1280px}
.main h1{font-size:20px;font-weight:800;margin-bottom:4px}
.sub{color:#6b7280;font-size:13px;margin-bottom:22px}
.toolbar{display:flex;gap:10px;align-items:center;margin-bottom:18px;flex-wrap:wrap}
.btn{display:inline-flex;align-items:center;gap:6px;background:#2563eb;color:#fff;border:none;border-radius:8px;
  padding:10px 16px;font-size:13.5px;font-weight:700;cursor:pointer;text-decoration:none}
.btn.gray{background:#fff;color:#374151;border:1px solid #d1d5db}
.btn.danger{background:#fef2f2;color:#dc2626;border:1px solid #fecaca}
.btn.sm{padding:6px 10px;font-size:12px}
.cat_chip{display:inline-flex;align-items:center;gap:6px;background:#fff;border:1px solid #e5e7eb;border-radius:999px;
  padding:5px 12px;font-size:12.5px;color:#374151}
.cat_chip a{color:#dc2626;text-decoration:none;font-weight:800}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:18px}
.card{background:#fff;border:1px solid #e5e7eb;border-radius:14px;overflow:hidden;position:relative}
.card.hidden{opacity:.55}
.ba{display:grid;grid-template-columns:1fr 1fr;height:150px}
.ba img{width:100%;height:100%;object-fit:cover;display:block}
.ba .lab{position:absolute;top:8px;font-size:10.5px;font-weight:800;background:rgba(0,0,0,.55);color:#fff;
  padding:2px 8px;border-radius:999px}
.ba .lab.b{left:8px}.ba .lab.a{left:calc(50% + 8px)}
.card_body{padding:14px 16px}
.card_body .cat{font-size:11px;font-weight:800;color:#2563eb;margin-bottom:4px}
.card_body h3{font-size:14.5px;font-weight:800;margin-bottom:4px;line-height:1.3}
.card_body p{font-size:12px;color:#6b7280;line-height:1.5;margin-bottom:10px;min-height:18px}
.card_actions{display:flex;gap:6px;justify-content:flex-end}
.badge_off{position:absolute;top:8px;right:8px;background:#111827;color:#fff;font-size:10.5px;font-weight:800;
  padding:3px 9px;border-radius:999px;z-index:2}
.msg{padding:12px 16px;border-radius:10px;font-size:13px;font-weight:700;margin-bottom:16px}
.msg.ok{background:#ecfdf5;color:#047857}
.msg.error{background:#fef2f2;color:#dc2626}
.pager{display:flex;gap:6px;margin-top:22px}
.pager a{width:32px;height:32px;display:flex;align-items:center;justify-content:center;border-radius:8px;
  border:1px solid #e5e7eb;color:#374151;text-decoration:none;font-size:12.5px}
.pager a.on{background:#2563eb;color:#fff;border-color:#2563eb}

/* 슬라이드인 패널 */
.panel_bg{position:fixed;inset:0;background:rgba(15,15,25,.45);display:none;z-index:50}
.panel_bg.on{display:block}
.panel{position:fixed;top:0;right:-460px;width:440px;max-width:92vw;height:100vh;background:#fff;z-index:51;
  transition:right .25s ease;overflow-y:auto;padding:26px 24px 40px;box-shadow:-8px 0 30px rgba(0,0,0,.12)}
.panel.on{right:0}
.panel h2{font-size:16.5px;font-weight:800;margin-bottom:18px}
.panel label{display:block;font-size:12.5px;font-weight:700;color:#374151;margin:14px 0 6px}
.panel input[type=text],.panel select,.panel textarea{width:100%;padding:10px 11px;border:1px solid #d1d5db;
  border-radius:8px;font-size:13.5px;outline:none;font-family:inherit}
.panel textarea{min-height:80px;resize:vertical}
.panel input[type=file]{width:100%;font-size:12.5px}
.imgprev{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px}
.imgprev img{width:100%;height:90px;object-fit:cover;border-radius:8px;border:1px solid #e5e7eb}
.chk_row{display:flex;align-items:center;gap:8px;margin-top:14px}
.chk_row input{width:auto}
.panel_actions{display:flex;gap:8px;margin-top:22px}
.panel_close{position:absolute;top:20px;right:20px;background:none;border:none;font-size:20px;cursor:pointer;color:#9ca3af}
.cat_manage{background:#f9fafb;border:1px solid #e5e7eb;border-radius:10px;padding:14px;margin-bottom:18px}
.cat_manage form{display:flex;gap:8px;margin-top:10px}
.cat_manage input[type=text]{flex:1;padding:8px 10px;border:1px solid #d1d5db;border-radius:8px;font-size:13px}
</style>
</head>
<body>
<div class="wrap">
<?php include __DIR__ . '/../aside.php'; ?>
<div class="main">
  <h1><?= htmlspecialchars($case_label) ?> 관리</h1>
  <p class="sub">치료 전/후 사진으로 구성된 임상 사례를 등록·관리합니다. (총 <?= $total ?>건)</p>

  <?php if ($msg): [$mtype, $mtext] = array_pad(explode(':', $msg, 2), 2, ''); ?>
    <div class="msg <?= htmlspecialchars($mtype) ?>"><?= htmlspecialchars($mtext) ?></div>
  <?php endif; ?>

  <div class="cat_manage">
    <div style="font-size:12.5px;font-weight:800;color:#374151;">카테고리</div>
    <div style="margin-top:8px;display:flex;gap:6px;flex-wrap:wrap;">
      <?php foreach ($cats as $c): ?>
        <span class="cat_chip"><?= htmlspecialchars($c['name']) ?>
          <?php if ($c['name'] !== '미분류'): ?>
            <a href="?action=cat_del&id=<?= $c['id'] ?>" onclick="return confirm('이 카테고리를 삭제할까요? (소속 케이스는 미분류로 이동)')">×</a>
          <?php endif; ?>
        </span>
      <?php endforeach; ?>
    </div>
    <form method="post" action="?action=cat_add">
      <input type="text" name="cat_name" placeholder="새 카테고리명 (예: 임플란트)" required>
      <button class="btn sm" type="submit">추가</button>
    </form>
  </div>

  <div class="toolbar">
    <button class="btn" onclick="openPanel()">+ 케이스 등록</button>
    <a class="btn gray" href="<?= htmlspecialchars($case_path) ?>/case_list.php" target="_blank">공개 목록 보기</a>
  </div>

  <div class="grid">
    <?php if (!$list_r || mysqli_num_rows($list_r) === 0): ?>
      <div style="color:#9ca3af;font-size:13px;padding:30px 0;">등록된 케이스가 없습니다.</div>
    <?php else: while ($row = mysqli_fetch_assoc($list_r)): ?>
      <div class="card <?= $row['visible'] ? '' : 'hidden' ?>">
        <?php if (!$row['visible']): ?><span class="badge_off">비공개</span><?php endif; ?>
        <div class="ba">
          <div style="position:relative"><span class="lab b">전</span><img src="<?= htmlspecialchars($row['image_before']) ?>" alt=""></div>
          <div style="position:relative"><span class="lab a">후</span><img src="<?= htmlspecialchars($row['image_after']) ?>" alt=""></div>
        </div>
        <div class="card_body">
          <div class="cat"><?= htmlspecialchars($row['cat_name'] ?: '미분류') ?></div>
          <h3><?= htmlspecialchars($row['title']) ?></h3>
          <p><?= htmlspecialchars($row['subtitle']) ?></p>
          <div class="card_actions">
            <a class="btn sm gray" href="?action=toggle&id=<?= $row['id'] ?>"><?= $row['visible'] ? '숨기기' : '공개하기' ?></a>
            <button class="btn sm gray" onclick='openPanel(<?= (int)$row['id'] ?>)'>수정</button>
            <a class="btn sm danger" href="?action=delete&id=<?= $row['id'] ?>" onclick="return confirm('삭제할까요? 되돌릴 수 없습니다.')">삭제</a>
          </div>
        </div>
      </div>
    <?php endwhile; endif; ?>
  </div>

  <?php if ($total_pages > 1): ?>
    <div class="pager">
      <?php for ($p = 1; $p <= $total_pages; $p++): ?>
        <a class="<?= $p === $page ? 'on' : '' ?>" href="?page=<?= $p ?>"><?= $p ?></a>
      <?php endfor; ?>
    </div>
  <?php endif; ?>
</div>
</div>

<!-- 등록/수정 슬라이드인 패널 -->
<div class="panel_bg" id="panelBg" onclick="closePanel()"></div>
<div class="panel" id="panel">
  <button class="panel_close" onclick="closePanel()">&times;</button>
  <h2 id="panelTitle">케이스 등록</h2>
  <form method="post" id="caseForm" enctype="multipart/form-data" action="?action=insert">
    <input type="hidden" name="id" id="f_id">
    <label>카테고리</label>
    <select name="cat_id" id="f_cat">
      <?php foreach ($cats as $c): ?><option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['name']) ?></option><?php endforeach; ?>
    </select>
    <label>제목 *</label>
    <input type="text" name="title" id="f_title" required placeholder="예: 앞니 라미네이트 케이스">
    <label>부제 (한 줄 요약)</label>
    <input type="text" name="subtitle" id="f_subtitle" placeholder="예: 변색·틈새 개선 사례">
    <label>설명</label>
    <textarea name="content" id="f_content" placeholder="치료 과정·기간 등 간단 설명 (선택)"></textarea>
    <label>태그 (쉼표로 구분)</label>
    <input type="text" name="tags" id="f_tags" placeholder="예: 라미네이트, 앞니, 변색">

    <label>전(before) 사진 <span id="f_b_req" style="color:#dc2626">*등록 시 필수</span></label>
    <input type="file" name="image_before" accept="image/*" id="f_image_before">
    <label>후(after) 사진 <span id="f_a_req" style="color:#dc2626">*등록 시 필수</span></label>
    <input type="file" name="image_after" accept="image/*" id="f_image_after">
    <div class="imgprev" id="f_preview"></div>

    <div class="chk_row">
      <input type="checkbox" name="visible" id="f_visible" checked>
      <label style="margin:0" for="f_visible">공개</label>
    </div>

    <div class="panel_actions">
      <button class="btn" type="submit" style="flex:1">저장</button>
      <button class="btn gray" type="button" onclick="closePanel()">취소</button>
    </div>
  </form>
</div>

<script>
<?php
$all_r = mysqli_query($db, "SELECT * FROM `{$table}`");
$all_cases = [];
if ($all_r) while ($row = mysqli_fetch_assoc($all_r)) $all_cases[$row['id']] = $row;
?>
const CASES = <?= json_encode($all_cases, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;

function openPanel(id) {
    const f = document.getElementById('caseForm');
    document.getElementById('f_preview').innerHTML = '';
    if (id && CASES[id]) {
        const c = CASES[id];
        document.getElementById('panelTitle').textContent = '케이스 수정';
        f.action = '?action=update';
        document.getElementById('f_id').value = c.id;
        document.getElementById('f_cat').value = c.cat_id;
        document.getElementById('f_title').value = c.title;
        document.getElementById('f_subtitle').value = c.subtitle;
        document.getElementById('f_content').value = c.content || '';
        document.getElementById('f_tags').value = c.tags || '';
        document.getElementById('f_visible').checked = !!(+c.visible);
        document.getElementById('f_b_req').style.display = 'none';
        document.getElementById('f_a_req').style.display = 'none';
        let prev = '';
        if (c.image_before) prev += `<img src="${c.image_before}" alt="전">`;
        if (c.image_after)  prev += `<img src="${c.image_after}" alt="후">`;
        document.getElementById('f_preview').innerHTML = prev;
    } else {
        document.getElementById('panelTitle').textContent = '케이스 등록';
        f.action = '?action=insert';
        f.reset();
        document.getElementById('f_id').value = '';
        document.getElementById('f_b_req').style.display = '';
        document.getElementById('f_a_req').style.display = '';
    }
    document.getElementById('panelBg').classList.add('on');
    document.getElementById('panel').classList.add('on');
}
function closePanel() {
    document.getElementById('panelBg').classList.remove('on');
    document.getElementById('panel').classList.remove('on');
}
</script>
</body>
</html>
