<?php
require_once __DIR__ . '/../inc/bootstrap.php';

global $connect_db;
$db = $connect_db;

$table           = 'sal_column';
$cat_table       = 'sal_column_cat';
$upload_dir_path = G5_DATA_PATH . '/editor/' . date('Ym');
$upload_url_path = G5_DATA_URL  . '/editor/' . date('Ym');

if (!empty($_FILES['image']['name'])) {
    while (ob_get_level()) ob_end_clean();
    if (!is_dir($upload_dir_path)) @mkdir($upload_dir_path, 0755, true);
    $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg','jpeg','png','gif','webp'])) {
        header('Content-Type: application/json');
        die(json_encode(["uploaded"=>0,"error"=>["message"=>"이미지만 업로드 가능합니다."]]));
    }
    $fname = time().'_'.md5(uniqid()).'.'.$ext;
    $ok = move_uploaded_file($_FILES['image']['tmp_name'], $upload_dir_path.'/'.$fname);
    header('Content-Type: application/json');
    echo json_encode($ok ? ["uploaded"=>1,"url"=>$upload_url_path.'/'.$fname] : ["uploaded"=>0]);
    exit;
}

if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['col_title'])) {
    $post_id = (int)($_POST['col_id'] ?? 0);
    $title   = mysqli_real_escape_string($db, trim(stripslashes($_POST['col_title'])));
    $content = mysqli_real_escape_string($db, stripslashes($_POST['col_content'] ?? ''));
    $cat_id    = (int)($_POST['col_cat_id'] ?? 0);
    $thumbnail = mysqli_real_escape_string($db, trim($_POST['col_thumbnail'] ?? ''));
    if (!$title) { header('Location: '.$_SERVER['PHP_SELF'].'?'.($post_id?"mode=modify&id=$post_id":'').'&err=1'); exit; }
    if ($post_id > 0) {
        mysqli_query($db,"UPDATE `{$table}` SET title='{$title}',content='{$content}',editor_type='builder',cat_id={$cat_id},thumbnail='{$thumbnail}' WHERE id={$post_id}");
    } else {
        mysqli_query($db,"INSERT INTO `{$table}` (cat_id,title,content,editor_type,thumbnail,created_at) VALUES({$cat_id},'{$title}','{$content}','builder','{$thumbnail}',NOW())");
    }
    header('Location: column_admin.php?msg='.urlencode('ok:저장되었습니다.')); exit;
}

// thumbnail 컬럼 없으면 자동 추가
$_tc = mysqli_query($db, "SHOW COLUMNS FROM `{$table}` LIKE 'thumbnail'");
if ($_tc && mysqli_num_rows($_tc) === 0) {
    mysqli_query($db, "ALTER TABLE `{$table}` ADD COLUMN `thumbnail` VARCHAR(512) DEFAULT '' AFTER `content`");
}
$mode   = $_GET['mode'] ?? 'write';
$col_id = (int)($_GET['id'] ?? 0);
$write  = [];
if ($mode === 'modify' && $col_id)
    $write = mysqli_fetch_assoc(mysqli_query($db,"SELECT * FROM `{$table}` WHERE id={$col_id}")) ?: [];

$cats = [];
$cr = mysqli_query($db,"SELECT * FROM `{$cat_table}` ORDER BY sort ASC, id ASC");
if ($cr) while ($c = mysqli_fetch_assoc($cr)) $cats[] = $c;

$existing_json = 'null';
$existing_thumbnail = htmlspecialchars($write['thumbnail'] ?? '');
if (!empty($write['content'])) {
    $d = json_decode($write['content'], true);
    if ($d && isset($d['rows'])) $existing_json = json_encode($d);
}
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= $mode==='modify'?'칼럼 수정':'새 칼럼 작성' ?></title>
<style>
:root{
  --bg:#0d1117;--sf:#161b22;--sf2:#21262d;--bd:#30363d;--bd2:#444c56;
  --tx:#e6edf3;--tx2:#8b949e;--tx3:#484f58;
  --ac:#f0b429;--ac2:#ffd166;--blue:#58a6ff;--red:#f85149;
  --cv:#f4f6fa;--card:#fff;--cbd:#e1e4e8;
}
*{box-sizing:border-box;margin:0;padding:0}
html,body{height:100%;font-family:'Pretendard',-apple-system,sans-serif;background:var(--bg);color:var(--tx);overflow:hidden}
#topbar{height:52px;background:var(--sf);border-bottom:1px solid var(--bd);display:flex;align-items:center;padding:0 14px;gap:8px;flex-shrink:0;z-index:100}
.tb-brand{font-size:11px;font-weight:800;color:var(--ac);letter-spacing:.5px;flex-shrink:0}
.tb-div{width:1px;height:18px;background:var(--bd2);flex-shrink:0}
.tb-cat{background:var(--sf2);border:1px solid var(--bd2);border-radius:7px;color:var(--tx);font-size:12px;padding:5px 9px;font-family:inherit;outline:none;cursor:pointer;flex-shrink:0}
.tb-cat option{background:var(--sf)}
.tb-title{flex:1;background:var(--sf2);border:1px solid var(--bd2);border-radius:7px;color:var(--tx);font-size:13px;font-weight:600;padding:5px 12px;font-family:inherit;outline:none;min-width:0;transition:border-color .15s}
.tb-title:focus{border-color:var(--ac)} .tb-title::placeholder{color:var(--tx3)}
.tb-btn{display:flex;align-items:center;gap:4px;padding:5px 11px;border-radius:7px;background:var(--sf2);border:1px solid var(--bd2);color:var(--tx2);font-size:11px;font-weight:700;cursor:pointer;font-family:inherit;transition:all .15s;white-space:nowrap;flex-shrink:0}
.tb-btn:hover{border-color:var(--bd);color:var(--tx)}
.tb-save{background:var(--ac);border-color:var(--ac);color:#000;font-weight:800}
.tb-save:hover{background:var(--ac2);border-color:var(--ac2)}
.tb-ghost{border-color:transparent;background:transparent;color:var(--tx3)}
.tb-ghost:hover{color:var(--tx2);background:var(--sf2);border-color:var(--bd)}
#app{display:flex;height:calc(100vh - 52px);overflow:hidden}
#canvas{width:100%;max-width:840px;display:flex;flex-direction:column;gap:4px;padding-bottom:120px}

/* ── 섹션 간격 & 드래그 ── */
.sec-wrap{display:flex;flex-direction:column;position:relative;border-radius:14px;transition:opacity .2s}
.sec-wrap.dragging{opacity:.35;pointer-events:none}
.sec-wrap.drag-over>.sec-card{border-color:var(--blue);box-shadow:0 0 0 2px rgba(88,166,255,.25)}
.drag-indicator{height:3px;border-radius:2px;background:var(--blue);margin:0 8px;opacity:0;transition:opacity .15s;pointer-events:none}
.drag-indicator.show{opacity:1}

/* ── 섹션 헤더 개선 ── */
.sec-card{background:var(--card);border:1.5px solid #dce3ed;border-radius:14px;overflow:hidden;transition:border-color .15s,box-shadow .15s;box-shadow:0 1px 4px rgba(37,69,107,.06)}
.sec-card:hover{border-color:#a8bcd4;box-shadow:0 2px 16px rgba(37,69,107,.1)}
.sec-head{display:flex;align-items:center;gap:6px;padding:8px 12px;background:linear-gradient(to bottom,#f8f9fb,#f3f5f9);border-bottom:1px solid #e8edf4;user-select:none}
.drag-handle{display:flex;align-items:center;padding:2px 3px;color:#c8d4e8;cursor:grab;font-size:14px;flex-shrink:0;border-radius:4px;transition:color .12s,background .12s;letter-spacing:-1px}
.drag-handle:hover{color:#8099be;background:#eef1f8}
.drag-handle:active{cursor:grabbing;color:#5a7a9a}
.sec-card:hover .slb span{background:#8099be}
.sec-lbl{font-size:9px;font-weight:700;color:#9090b0;letter-spacing:.4px;flex:1}
.sa{width:24px;height:24px;border:none;background:transparent;color:#b0bcd0;cursor:pointer;border-radius:5px;font-size:11px;display:flex;align-items:center;justify-content:center;transition:all .12s;font-family:inherit}

/* ── 블록 카드 드래그 ── */
.block-card{background:#fff;border:1.5px solid #e8eaf0;border-radius:10px;overflow:hidden;cursor:default;transition:border-color .15s,box-shadow .15s;box-shadow:0 1px 3px rgba(37,69,107,.04)}
.block-card:hover{border-color:#a8c0d8;box-shadow:0 2px 10px rgba(37,69,107,.09)}
.block-card.sel{border-color:var(--blue)!important;box-shadow:0 0 0 2px rgba(88,166,255,.2)!important}
.block-card.blk-dragging{opacity:.3;pointer-events:none}
.block-card.blk-drag-over{border-color:var(--blue);box-shadow:0 0 0 2px rgba(88,166,255,.2);background:#f4f8ff}
.bk-hd{display:flex;align-items:center;gap:5px;padding:5px 8px;border-bottom:1px solid #f0f3f8;user-select:none}
.bk-drag{display:flex;align-items:center;color:#d0d8e8;cursor:grab;font-size:12px;flex-shrink:0;padding:1px 2px;border-radius:3px;transition:color .12s;letter-spacing:-1px}
.bk-drag:hover{color:#8099be}
.bk-drag:active{cursor:grabbing}
.bk-nm{font-size:9px;font-weight:700;color:#8090b0;letter-spacing:.3px;flex:1;text-transform:uppercase}
.ba{width:18px;height:18px;border:none;background:transparent;color:#c0c8d8;cursor:pointer;border-radius:3px;font-size:10px;display:flex;align-items:center;justify-content:center;transition:all .12s;font-family:inherit}
.ba:hover{background:#e8f0ff;color:#25456b} .ba.del:hover{background:#ffe0e3;color:#c92a2a}

/* ── 컬럼 구분선 개선 ── */
.sec-body{display:flex;min-height:88px}
.sec-col{flex:1;min-height:88px;border-right:1px dashed #dde3f0;padding:10px 10px 8px;display:flex;flex-direction:column;gap:6px;position:relative}
.col-empty{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:none;opacity:.4;font-size:10px;color:#aabbd0;font-weight:600;gap:4px}

/* ── 추가 버튼 ── */
.add-zone{display:flex;align-items:center;gap:0;padding:4px 0;opacity:0;transition:opacity .15s}
.sec-wrap:hover .add-zone,.add-zone:hover{opacity:1} #bottom-add,.az-always{opacity:1!important;visibility:visible!important}
.add-line{flex:1;height:1px;background:linear-gradient(to right,transparent,#bdd0e8,transparent)}
.add-btn{display:flex;align-items:center;gap:4px;padding:4px 14px;border-radius:16px;border:1.5px solid #b8cce0;background:#fff;color:#5a7a9a;font-size:10px;font-weight:700;cursor:pointer;font-family:inherit;transition:all .15s;white-space:nowrap;flex-shrink:0;box-shadow:0 1px 4px rgba(37,69,107,.08)}
.add-btn:hover{border-color:var(--blue);color:var(--blue);background:#f0f6ff;box-shadow:0 2px 8px rgba(88,166,255,.15)}
.col-add{display:flex;align-items:center;justify-content:center;gap:4px;padding:5px;border-radius:8px;border:1.5px dashed #d4dde8;background:transparent;color:#8090b0;font-size:10px;font-weight:600;cursor:pointer;font-family:inherit;transition:all .15s;margin-top:2px}

/* ── 캔버스 스크롤바 ── */
#cwrap{flex:1;overflow-y:auto;background:#eef1f6;padding:24px 20px;display:flex;flex-direction:column;align-items:center}
#cwrap::-webkit-scrollbar{width:6px} #cwrap::-webkit-scrollbar-thumb{background:#c0ccd8;border-radius:3px}
#empty-hint{padding:0;min-height:340px;text-align:center;color:#8090b0;display:none;flex-direction:column;align-items:center;justify-content:center;gap:12px}
.eh-ic{font-size:36px;opacity:.4}
.eh-cta{display:inline-flex;align-items:center;gap:7px;margin-top:8px;padding:10px 24px;border-radius:24px;border:2px solid #b8cce0;background:#fff;color:#25456b;font-size:13px;font-weight:700;cursor:pointer;font-family:inherit;box-shadow:0 2px 12px rgba(37,69,107,.12);transition:all .2s}
.eh-cta:hover{border-color:var(--blue);background:#f0f6ff;box-shadow:0 4px 18px rgba(88,166,255,.2);transform:translateY(-1px)}
.eh-cta-ic{font-size:16px;font-weight:400}
#empty-hint h3{font-size:14px;font-weight:700;color:#666;margin:0}
#empty-hint p{font-size:12px;color:#999;line-height:1.7;margin:0}
.slb{display:flex;gap:2px;flex-shrink:0}
.slb span{height:12px;border-radius:2px;background:#c8d4e8;transition:background .15s}
.sec-card:hover .slb span{background:#8099be}
.sec-lbl{font-size:9px;font-weight:700;color:#9090b0;letter-spacing:.4px;flex:1}
.sec-acts{display:flex;gap:2px;opacity:0;transition:opacity .15s}
.sec-card:hover .sec-acts{opacity:1}
.sa:hover{background:#e8f0ff;color:#25456b} .sa.del:hover{background:#ffe0e3;color:#c92a2a}
.sec-col:last-child{border-right:none}
.bk-dot{width:6px;height:6px;border-radius:50%;flex-shrink:0}
.bk-nm{font-size:9px;font-weight:700;color:#8090b0;letter-spacing:.3px;flex:1;text-transform:uppercase}
.bk-acts{display:flex;gap:1px;opacity:0;transition:opacity .12s}
.block-card:hover .bk-acts,.block-card.sel .bk-acts{opacity:1}
.ba{width:18px;height:18px;border:none;background:transparent;color:#c0c8d8;cursor:pointer;border-radius:3px;font-size:10px;display:flex;align-items:center;justify-content:center;transition:all .12s;font-family:inherit}
.ba:hover{background:#e8f0ff;color:#25456b} .ba.del:hover{background:#ffe0e3;color:#c92a2a}
.bk-bd{padding:8px 10px}
.bk-bd [contenteditable]{outline:none;width:100%;color:#1a1a2e;font-family:'Pretendard',-apple-system,sans-serif;min-height:20px;line-height:1.7;-webkit-user-drag:none}
.bk-bd [contenteditable]:empty::before{content:attr(data-ph);color:#bbc8da;pointer-events:none}
.bt-h2 .bk-hd{background:#fff5f8} .bt-h2 .bk-dot{background:#f783ac}
.bt-h3 .bk-hd{background:#fff8fa} .bt-h3 .bk-dot{background:#faa2c1}
.bt-h4 .bk-hd{background:#fffafc} .bt-h4 .bk-dot{background:#fcc2d7}
.bt-paragraph .bk-hd{background:#f5f8ff} .bt-paragraph .bk-dot{background:#74c0fc}
.bt-quote .bk-hd{background:#fdf5ff} .bt-quote .bk-dot{background:#da77f2}
.bt-list .bk-hd{background:#f0fff8} .bt-list .bk-dot{background:#63e6be}
.bt-image .bk-hd{background:#fff8f0} .bt-image .bk-dot{background:#ffa94d}
.bt-warning .bk-hd{background:#fffdf0} .bt-warning .bk-dot{background:#FABE00}
.bt-delimiter .bk-hd{background:#f8fce8} .bt-delimiter .bk-dot{background:#a9e34b}
.bt-table .bk-hd{background:#f0f5ff} .bt-table .bk-dot{background:#4dabf7}
.bt-button .bk-hd{background:#f3f0ff} .bt-button .bk-dot{background:#9775fa}
.bt-faq .bk-hd{background:#f0fff8} .bt-faq .bk-dot{background:#40c057}
.faq-edit{display:flex;flex-direction:column;gap:6px}
.faq-item-e{background:#f8fafc;border:1px solid #e8eaf0;border-radius:6px;padding:8px 10px;display:flex;flex-direction:column;gap:4px;position:relative}
.faq-q-lbl{font-size:8px;font-weight:800;color:#2f9e44;letter-spacing:.5px;text-transform:uppercase;margin-bottom:2px}
.faq-q-inp{outline:none;font-family:'Pretendard',-apple-system,sans-serif;min-height:18px;color:#1a1a2e;font-size:13px;font-weight:700}
.faq-q-inp:empty::before{content:attr(data-ph);color:#bbc8da;pointer-events:none}
.faq-a-inp{outline:none;font-family:'Pretendard',-apple-system,sans-serif;min-height:28px;color:#555;font-size:13px;border-top:1px dashed #e8eaf0;padding-top:5px;margin-top:4px}
.faq-a-inp:empty::before{content:attr(data-ph);color:#bbc8da;pointer-events:none}
.faq-del-btn{position:absolute;top:6px;right:6px;font-size:9px;padding:2px 7px;border:1px dashed #fecdd3;border-radius:4px;background:transparent;color:#f43f5e;cursor:pointer;font-family:inherit}
.faq-del-btn:hover{background:#fff5f5}
.b-h2{font-size:20px;font-weight:800;color:#1a1a2e}
.b-h3{font-size:16px;font-weight:700;color:#1a1a2e}
.b-h4{font-size:14px;font-weight:700;color:#333}
.b-qt{border-left:3px solid #99b5d7;background:#f8fbff;border-radius:0 5px 5px 0;padding:8px 12px}
.b-wn{background:#fffbf0;border:1.5px solid #fabe00;border-radius:6px;padding:10px 12px}
.b-wn-t{font-weight:800;font-size:11px;color:#dd9700;margin-bottom:5px}
.b-dl{border:none;border-top:2px dashed #d0dce8;margin:4px 0}
.b-ul{list-style:disc;padding-left:18px}
.b-ul li{margin-bottom:2px}
.b-ul li [contenteditable]{font-size:13px;display:inline-block;min-width:40px}
.b-la{display:inline-flex;align-items:center;gap:3px;margin-top:6px;padding:2px 8px;border-radius:5px;border:1.5px dashed #c8d4e8;background:transparent;color:#8090b0;font-size:10px;cursor:pointer;font-family:inherit}
.b-la:hover{border-color:#63e6be;color:#087f5b}
.b-idrop{border:2px dashed #c8d4e8;border-radius:8px;padding:18px;text-align:center;cursor:pointer;color:#8090b0;font-size:12px;transition:all .15s;display:flex;flex-direction:column;align-items:center;gap:6px}
.b-idrop:hover{border-color:var(--ac);color:var(--ac)}
.b-iprev{max-width:100%;border-radius:5px;display:block;margin-bottom:4px}
.b-ialt{width:100%;padding:4px 8px;border:1px solid var(--cbd);border-radius:5px;font-size:10px;font-family:inherit;color:#555;outline:none;margin-top:4px}
.b-tbl{overflow-x:auto}
.b-tbl table{width:100%;border-collapse:collapse;font-size:11px}
.b-tbl td{border:1.5px solid var(--cbd);padding:4px 7px;min-width:40px}
.b-tbl td [contenteditable]{outline:none;min-height:16px}
.b-tbl tr:first-child td{background:#f4f7fc;font-weight:700}
.tbl-btns{display:flex;gap:3px;margin-top:4px;flex-wrap:wrap}
.tbl-btn{padding:2px 8px;border-radius:4px;border:1.5px dashed #c8d4e8;background:transparent;color:#8090b0;font-size:9px;cursor:pointer;font-family:inherit}
.tbl-btn:hover{border-color:#4dabf7;color:#1c7ed6}
.b-btn-el{display:inline-flex;padding:8px 18px;border-radius:7px;background:linear-gradient(135deg,#000136,#25456b);color:#fff;font-size:12px;font-weight:700;cursor:text}
.b-btn-el [contenteditable]{color:#fff;min-width:50px}
.b-anc{display:flex;align-items:center;gap:5px;margin-top:7px;padding-top:7px;border-top:1px dashed #eef0f4}
.b-anc label{font-size:9px;color:#8090b0;white-space:nowrap}
.b-anc input{flex:1;padding:3px 7px;border:1px solid #e0e4ea;border-radius:4px;font-size:10px;font-family:'Courier New',monospace;color:#25456b;outline:none}
.b-anc input:focus{border-color:var(--blue)}
.b-toc-tip{font-size:9px;background:#e8f4ff;color:#1c7ed6;padding:2px 6px;border-radius:4px;white-space:nowrap}
.col-add:hover{border-color:var(--blue);color:var(--blue);background:#f0f6ff}
#pk-overlay{display:none;position:fixed;inset:0;z-index:900;background:rgba(0,0,0,.3)}
#pk-overlay.open{display:block}
#pk-box{position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);background:#fff;border-radius:16px;box-shadow:0 10px 48px rgba(0,0,0,.22);padding:22px;width:560px;max-width:calc(100vw - 32px);max-height:80vh;overflow-y:auto;display:none;z-index:901;animation:pu .2s cubic-bezier(.34,1.56,.64,1)}
#pk-box.open{display:block}
@keyframes pu{from{opacity:0;transform:translate(-50%,-48%)}to{opacity:1;transform:translate(-50%,-50%)}}
.pk-hd{display:flex;align-items:center;justify-content:space-between;margin-bottom:16px}
.pk-title{font-size:11px;font-weight:800;color:#8090b0;letter-spacing:.8px;text-transform:uppercase}
.pk-close{border:none;background:none;font-size:16px;color:#b0bcd0;cursor:pointer} .pk-close:hover{color:#555}
.pk-sec{margin-bottom:18px}
.pk-sl{font-size:9px;font-weight:800;color:#b0bcd0;letter-spacing:1px;text-transform:uppercase;margin-bottom:10px}
.layout-grid{display:flex;gap:8px;flex-wrap:wrap}
.lo{display:flex;flex-direction:column;align-items:center;gap:6px;padding:12px 10px;border-radius:10px;border:1.5px solid #e8eaf0;background:#fafbfc;cursor:pointer;transition:all .15s;min-width:72px}
.lo:hover{border-color:var(--blue);background:#f0f6ff;transform:translateY(-2px);box-shadow:0 4px 12px rgba(88,166,255,.15)}
.lo-prev{display:flex;gap:2px;height:24px;width:52px}
.lo-col{flex:1;border-radius:3px;background:#c8d8e8;transition:background .15s}
.lo:hover .lo-col{background:#58a6ff;opacity:.7}
.lo-lbl{font-size:10px;font-weight:700;color:#555}
.block-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:6px}
.bo{display:flex;flex-direction:column;align-items:center;gap:5px;padding:12px 6px;border-radius:9px;border:1.5px solid #e8eaf0;background:#fafbfc;cursor:pointer;transition:all .15s;text-align:center}
.bo:hover{border-color:var(--blue);background:#f0f6ff;transform:translateY(-2px);box-shadow:0 3px 10px rgba(88,166,255,.12)}
.bo-ic{width:32px;height:32px;border-radius:7px;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:800;flex-shrink:0}
.bo-nm{font-size:10px;font-weight:700;color:#1a1a2e}
.bo-ds{font-size:8px;color:#8090b0;line-height:1.3}
#rp{width:216px;flex-shrink:0;background:var(--sf);border-left:1px solid var(--bd);display:flex;flex-direction:column;overflow:hidden}
.rp-hd{padding:10px 12px;border-bottom:1px solid var(--bd);display:flex;align-items:center;justify-content:space-between}
.rp-ht{font-size:9px;font-weight:800;letter-spacing:1px;text-transform:uppercase;color:var(--tx3)}
.rp-bg{font-size:9px;font-weight:700;padding:2px 7px;border-radius:10px;background:var(--sf2);border:1px solid var(--bd2);color:var(--tx2)}
.rp-bd{flex:1;overflow-y:auto}
.rp-bd::-webkit-scrollbar{width:3px} .rp-bd::-webkit-scrollbar-thumb{background:var(--bd2);border-radius:2px}
.rp-s{padding:10px 12px;border-bottom:1px solid var(--bd)}
.rp-st{font-size:9px;font-weight:700;letter-spacing:.8px;text-transform:uppercase;color:var(--tx3);margin-bottom:8px;display:flex;align-items:center;gap:5px}
.rp-st::after{content:'';flex:1;height:1px;background:var(--bd)}
.rp-r{display:flex;align-items:center;gap:6px;margin-bottom:7px}
.rp-r:last-child{margin-bottom:0}
.rp-l{font-size:10px;color:var(--tx2);min-width:32px}
.rp-n{width:50px;background:var(--sf2);border:1px solid var(--bd2);border-radius:5px;color:var(--tx);font-size:11px;padding:4px 6px;text-align:center;font-family:inherit;outline:none}
.rp-n:focus{border-color:var(--ac)}
.rp-sel{flex:1;background:var(--sf2);border:1px solid var(--bd2);border-radius:5px;color:var(--tx);font-size:10px;padding:4px 5px;font-family:inherit;outline:none;cursor:pointer}
.rp-sel option{background:var(--sf)}
.rp-ag,.rp-wg{display:flex;gap:2px;flex:1}
.rp-ab,.rp-wb{flex:1;height:24px;border-radius:4px;border:1px solid var(--bd2);background:var(--sf2);color:var(--tx3);font-size:10px;cursor:pointer;transition:all .12s;font-family:inherit;display:flex;align-items:center;justify-content:center}
.rp-ab:hover,.rp-wb:hover{border-color:var(--bd);color:var(--tx)}
.rp-ab.on,.rp-wb.on{background:#25456b;border-color:#25456b;color:#fff}
.rp-cw{display:flex;align-items:center;gap:5px;flex:1}
.rp-sw{width:20px;height:20px;border-radius:4px;border:1.5px solid var(--bd2);cursor:pointer;overflow:hidden;position:relative;flex-shrink:0}
.rp-sw input[type=color]{position:absolute;inset:-4px;width:calc(100%+8px);height:calc(100%+8px);border:none;cursor:pointer;opacity:0}
.rp-hx{flex:1;background:var(--sf2);border:1px solid var(--bd2);border-radius:5px;color:var(--tx);font-size:10px;padding:4px 6px;font-family:'Courier New',monospace;outline:none}
.rp-ab2{width:100%;padding:6px;border-radius:6px;border:1px solid var(--bd2);background:transparent;color:var(--tx2);font-size:11px;cursor:pointer;font-family:inherit;font-weight:600;transition:all .12s;margin-bottom:4px}
.rp-ab2:hover{background:var(--sf2);color:var(--tx)}
.rp-ab2.danger{border-color:rgba(248,81,73,.3);color:var(--red)} .rp-ab2.danger:hover{background:rgba(248,81,73,.08)}
.rp-em{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:20px;color:var(--tx3)}
.rp-em-ic{font-size:24px;margin-bottom:8px;opacity:.35}
.rp-em p{font-size:11px;line-height:1.7}
#toast{position:fixed;bottom:18px;left:50%;transform:translateX(-50%) translateY(60px);background:var(--sf);color:var(--tx);border:1px solid var(--bd2);border-radius:10px;padding:8px 16px;font-size:12px;font-weight:600;font-family:inherit;z-index:9999;transition:transform .3s cubic-bezier(.34,1.56,.64,1);display:flex;align-items:center;gap:6px;pointer-events:none;white-space:nowrap}
#toast.show{transform:translateX(-50%) translateY(0)}
#err-banner{display:none;background:#fee2e2;border-bottom:1px solid #fecaca;padding:8px 16px;font-size:12px;color:#dc2626;font-weight:600;text-align:center}
#err-banner.show{display:block}
/* 썸네일 패널 */
#tn-overlay{display:none;position:fixed;inset:0;z-index:800;background:rgba(0,0,0,.25)}
#tn-overlay.open{display:block}
#tn-panel{position:fixed;right:0;top:52px;width:280px;height:calc(100vh - 52px);background:var(--sf);border-left:1px solid var(--bd);display:flex;flex-direction:column;transform:translateX(100%);transition:transform .25s cubic-bezier(.4,0,.2,1);z-index:801}
#tn-panel.open{transform:translateX(0)}
.tn-head{padding:12px 14px;border-bottom:1px solid var(--bd);display:flex;align-items:center;justify-content:space-between;flex-shrink:0}
.tn-head-t{font-size:10px;font-weight:800;letter-spacing:1px;text-transform:uppercase;color:var(--tx3)}
.tn-close{border:none;background:none;color:var(--tx3);font-size:16px;cursor:pointer} .tn-close:hover{color:var(--tx)}
.tn-body{flex:1;overflow-y:auto;padding:16px;display:flex;flex-direction:column;gap:12px}
.tn-preview{width:100%;aspect-ratio:16/9;border-radius:10px;border:2px dashed var(--bd2);overflow:hidden;background:var(--sf2);display:flex;align-items:center;justify-content:center;position:relative;cursor:pointer;transition:border-color .15s}
.tn-preview:hover{border-color:var(--ac)}
.tn-preview img{width:100%;height:100%;object-fit:cover;display:block}
.tn-placeholder{display:flex;flex-direction:column;align-items:center;gap:8px;color:var(--tx3);pointer-events:none}
.tn-placeholder-ic{font-size:28px;opacity:.4}
.tn-placeholder span{font-size:10px;font-weight:600}
.tn-actions{display:flex;flex-direction:column;gap:6px}
.tn-btn{width:100%;padding:8px;border-radius:7px;border:1px solid var(--bd2);background:var(--sf2);color:var(--tx2);font-size:11px;font-weight:700;cursor:pointer;font-family:inherit;transition:all .15s;display:flex;align-items:center;justify-content:center;gap:5px}
.tn-btn:hover{border-color:var(--ac);color:var(--tx)}
.tn-btn.del{border-color:rgba(248,81,73,.3);color:var(--red)} .tn-btn.del:hover{background:rgba(248,81,73,.08)}
.tn-url-label{font-size:9px;font-weight:700;color:var(--tx3);letter-spacing:.5px;text-transform:uppercase}
.tn-url{width:100%;background:var(--sf2);border:1px solid var(--bd2);border-radius:5px;color:var(--tx2);font-size:10px;padding:5px 8px;font-family:'Courier New',monospace;outline:none;word-break:break-all}
.tn-hint{font-size:10px;color:var(--tx3);line-height:1.6;background:var(--sf2);border-radius:7px;padding:10px}
.tb-btn.tn-active{border-color:var(--ac);color:var(--ac);background:rgba(240,180,41,.08)}
</style>
</head>
<body>
<?php if (!empty($_GET['err'])): ?><div id="err-banner" class="show">⚠️ 제목을 입력해주세요.</div><?php endif; ?>
<form id="fwrite" method="post" action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>" style="display:none">
  <input type="hidden" name="col_id"      value="<?= $col_id ?>">
  <input type="hidden" name="col_cat_id"  id="f_cat">
  <input type="hidden" name="col_title"   id="f_title">
  <input type="hidden" name="col_content" id="f_content">
  <input type="hidden" name="col_thumbnail" id="f_thumbnail">
</form>
<div id="topbar">
  <span class="tb-brand">칼럼 편집기</span>
  <div class="tb-div"></div>
  <select class="tb-cat" id="tb_cat">
    <?php foreach ($cats as $cat): ?>
    <option value="<?= (int)$cat['id'] ?>" <?= (!empty($write['cat_id'])&&(int)$write['cat_id']===(int)$cat['id'])?'selected':'' ?>><?= htmlspecialchars($cat['name']) ?></option>
    <?php endforeach; ?>
  </select>
  <input class="tb-title" id="tb_title" type="text" placeholder="제목을 입력하세요 *" value="<?= htmlspecialchars($write['title']??'') ?>">
  <div class="tb-div"></div>
  <button class="tb-btn" id="tn-toggle-btn" onclick="toggleThumbnail()">🖼 썸네일</button>
  <button class="tb-btn" onclick="doPreview()">👁 미리보기</button>
  <button class="tb-btn tb-ghost" onclick="if(confirm('저장하지 않고 나가시겠어요?'))location.href='column_admin.php'">취소</button>
  <button class="tb-btn tb-save" onclick="doSave()"><?= $mode==='modify'?'✅ 수정 저장':'💾 저장' ?></button>
</div>
<div id="app">
  <div id="cwrap">
    <div id="canvas">
      <div id="empty-hint"><div class="eh-ic">✨</div><h3>섹션을 추가해 칼럼을 작성해보세요</h3><p>1단·2단·3단 레이아웃을 고르거나 바로 블록을 추가할 수 있습니다.</p><button class="eh-cta" onclick="openPicker(null)"><span class="eh-cta-ic">＋</span> 섹션 / 블록 추가</button></div>
      <div class="add-zone az-always" id="bottom-add" style="margin-top:12px;opacity:1!important">
        <div class="add-line"></div>
        <button class="add-btn" onclick="openPicker(null)" style="padding:6px 20px;font-size:11px;border-radius:20px">＋ 섹션 / 블록 추가</button>
        <div class="add-line"></div>
      </div>
    </div>
  </div>
  <div id="rp">
    <div class="rp-hd"><span class="rp-ht">속성</span><span class="rp-bg" id="rp-badge">—</span></div>
    <div class="rp-bd" id="rp-bd"><div class="rp-em"><div class="rp-em-ic">🖱️</div><p>블록을 클릭하면<br>속성이 표시됩니다</p></div></div>
  </div>
</div>
<div id="pk-overlay" onclick="closePicker()"></div>
<div id="pk-box">
  <div class="pk-hd"><span class="pk-title" id="pk-lbl">섹션 / 블록 추가</span><button class="pk-close" onclick="closePicker()">✕</button></div>
  <div id="pk-body"></div>
</div>
<div id="tn-overlay" onclick="closeThumbnail()"></div>
<div id="tn-panel">
  <div class="tn-head">
    <span class="tn-head-t">썸네일 설정</span>
    <button class="tn-close" onclick="closeThumbnail()">✕</button>
  </div>
  <div class="tn-body">
    <div class="tn-preview" id="tn-preview-wrap" onclick="trigTnUpload()">
      <div class="tn-placeholder" id="tn-placeholder"><div class="tn-placeholder-ic">🖼️</div><span>클릭하여 이미지 업로드</span></div>
      <img id="tn-img" src="" alt="썸네일" style="display:none">
    </div>
    <input type="file" id="tn-file" accept="image/*" style="display:none" onchange="doTnUpload(this)">
    <div class="tn-actions">
      <button class="tn-btn" onclick="trigTnUpload()">📤 이미지 업로드</button>
      <button class="tn-btn del" id="tn-del-btn" onclick="removeThumbnail()" style="display:none">🗑 썸네일 제거</button>
    </div>
    <div>
      <div class="tn-url-label" style="margin-bottom:5px">현재 URL</div>
      <div class="tn-url" id="tn-url-display">미설정</div>
    </div>
    <div class="tn-hint">💡 썸네일은 검색 결과, SNS 공유 시 대표 이미지로 사용됩니다. 권장 비율 16:9</div>
  </div>
</div>
<div id="toast"><span id="toast-msg"></span></div>
<script>
const UPLOAD_URL=<?= json_encode($_SERVER['PHP_SELF']) ?>;
const EXISTING=<?= $existing_json ?>;
const LAYOUTS=[
  {label:'1단',   cols:1, spans:[12],    prev:[1]},
  {label:'2단',   cols:2, spans:[6,6],   prev:[1,1]},
  {label:'좌넓',  cols:2, spans:[8,4],   prev:[2,1]},
  {label:'우넓',  cols:2, spans:[4,8],   prev:[1,2]},
  {label:'3단',   cols:3, spans:[4,4,4], prev:[1,1,1]},
];
const BT=[
  {type:'h2',        label:'대제목',   icon:'H2', bg:'#ffe0eb',fg:'#c2255c',desc:'목차 자동 포함'},
  {type:'h3',        label:'소제목',   icon:'H3', bg:'#ffe8f0',fg:'#d6336c',desc:''},
  {type:'h4',        label:'소소제목', icon:'H4', bg:'#fff0f5',fg:'#e64980',desc:''},
  {type:'paragraph', label:'본문',     icon:'¶',  bg:'#e8f4fd',fg:'#1971c2',desc:''},
  {type:'quote',     label:'인용구',   icon:'❝',  bg:'#f3e8fd',fg:'#7048e8',desc:''},
  {type:'image',     label:'이미지',   icon:'🖼', bg:'#fff4e0',fg:'#e67700',desc:''},
  {type:'list',      label:'목록',     icon:'≡',  bg:'#e8faee',fg:'#2f9e44',desc:''},
  {type:'warning',   label:'강조박스', icon:'!',  bg:'#fffbe0',fg:'#e67700',desc:''},
  {type:'delimiter', label:'구분선',   icon:'—',  bg:'#f4fadf',fg:'#5c940d',desc:''},
  {type:'table',     label:'표',       icon:'⊞',  bg:'#e8f3ff',fg:'#1864ab',desc:''},
  {type:'button',    label:'버튼',     icon:'▶',  bg:'#ede8ff',fg:'#5f3dc4',desc:''},
  {type:'faq',       label:'FAQ',      icon:'❓', bg:'#e8fff0',fg:'#2f9e44',desc:'접기/펼치기'},
];
let rows=[],selB=null,picCtx=null,idc=1;
const uid=()=>'u'+(idc++)+'_'+Math.random().toString(36).slice(2,5);

// Load
if(EXISTING&&EXISTING.rows){
  rows=EXISTING.rows.map(r=>({
    id:r.id||uid(), sectionId:r.sectionId||'', cols:r.columns.length,
    colSpans:r.columns.map(c=>c.span||Math.floor(12/r.columns.length)),
    columns:r.columns.map(c=>({blocks:(c.blocks||[]).map(b=>({...b,id:b.id||uid()}))}))
  }));
}

function openPicker(ctx){
  picCtx=ctx;
  const isBM=ctx!==null&&ctx&&ctx.colIdx!==undefined;
  document.getElementById('pk-lbl').textContent=isBM?'블록 추가':'섹션 / 블록 추가';
  let h='';
  if(!isBM){
    h+=`<div class="pk-sec"><div class="pk-sl">레이아웃 선택</div><div class="layout-grid">
      ${LAYOUTS.map(l=>`<div class="lo" onclick="addSection(${JSON.stringify(l).replace(/"/g,"'")})">
        <div class="lo-prev">${l.prev.map(f=>`<div class="lo-col" style="flex:${f}"></div>`).join('')}</div>
        <div class="lo-lbl">${l.label}</div></div>`).join('')}</div></div>`;
  }
  h+=`<div class="pk-sec"><div class="pk-sl">${isBM?'블록 선택':'블록 빠른 추가 (1단)'}</div>
    <div class="block-grid">${BT.map(bt=>`<div class="bo" onclick="pickBlock('${bt.type}')">
      <div class="bo-ic" style="background:${bt.bg};color:${bt.fg}">${bt.icon}</div>
      <div class="bo-nm">${bt.label}</div>${bt.desc?`<div class="bo-ds">${bt.desc}</div>`:''}</div>`).join('')}</div></div>`;
  document.getElementById('pk-body').innerHTML=h;
  document.getElementById('pk-box').classList.add('open');
  document.getElementById('pk-overlay').classList.add('open');
}
function closePicker(){
  document.getElementById('pk-box').classList.remove('open');
  document.getElementById('pk-overlay').classList.remove('open');
}
function addSection(layout){
  closePicker();
  const nr={id:uid(),sectionId:'',cols:layout.cols,colSpans:layout.spans,
    columns:Array.from({length:layout.cols},()=>({blocks:[]}))};
  if(picCtx&&picCtx.afterRowId){const i=rows.findIndex(r=>r.id===picCtx.afterRowId);rows.splice(i+1,0,nr);}
  else rows.push(nr);
  renderAll(); toast('✅ '+layout.label+' 섹션 추가됨');
}
function pickBlock(type){
  closePicker();
  if(picCtx===null){const r={id:uid(),sectionId:'',cols:1,colSpans:[12],columns:[{blocks:[mkBlock(type)]}]};rows.push(r);}
  else if(picCtx.colIdx!==undefined){
    const row=rows.find(r=>r.id===picCtx.rowId);if(!row)return;
    const col=row.columns[picCtx.colIdx];
    if(picCtx.afterIdx>=0)col.blocks.splice(picCtx.afterIdx+1,0,mkBlock(type));
    else col.blocks.push(mkBlock(type));
  } else if(picCtx.afterRowId){
    const r={id:uid(),sectionId:'',cols:1,colSpans:[12],columns:[{blocks:[mkBlock(type)]}]};
    const i=rows.findIndex(r2=>r2.id===picCtx.afterRowId);rows.splice(i+1,0,r);
  }
  renderAll(); toast('✅ '+(BT.find(b=>b.type===type)||{label:type}).label+' 추가됨');
}
function mkBlock(type){
  const id=uid();
  const def={
    paragraph:{text:'',style:{fontSize:15,fontWeight:400,textAlign:'left',color:'#1a1a2e',lineHeight:1.75}},
    h2:{text:'',sectionId:'',style:{fontSize:22,fontWeight:800,textAlign:'left',color:'#1a1a2e',lineHeight:1.3}},
    h3:{text:'',style:{fontSize:17,fontWeight:700,textAlign:'left',color:'#1a1a2e',lineHeight:1.35}},
    h4:{text:'',style:{fontSize:14,fontWeight:700,textAlign:'left',color:'#333',lineHeight:1.4}},
    quote:{text:'',style:{fontSize:15,fontWeight:400,textAlign:'left',color:'#25456b',lineHeight:1.7}},
    image:{url:'',alt:'',borderRadius:6},
    list:{items:[''],style:{fontSize:14,fontWeight:400,color:'#1a1a2e',lineHeight:1.65}},
    warning:{title:'',text:'',style:{fontSize:13}},
    delimiter:{},
    table:{rows:[['항목','내용'],['','']]},
    button:{text:'버튼 텍스트',href:'#',style:{fontSize:14,fontWeight:700}},
    faq:{items:[{q:'',a:''}]},
  };
  return {id,type,data:JSON.parse(JSON.stringify(def[type]||{text:''}))};
}
/* ═══ 섹션 드래그앤드롭 ═══ */
let dragRowId=null, dragOverRowId=null;
function onRowDragStart(e,rowId){
  syncAll();
  dragRowId=rowId;
  const sw=document.getElementById('sw-'+rowId);
  if(sw)setTimeout(()=>sw.classList.add('dragging'),0);
  e.dataTransfer.effectAllowed='move';
  e.dataTransfer.setData('text/plain','row:'+rowId);
}
function onRowDragOver(e,rowId){
  if(!dragRowId||dragRowId===rowId)return;
  e.preventDefault(); e.dataTransfer.dropEffect='move';
  if(dragOverRowId===rowId)return;
  clearRowDragOver();
  dragOverRowId=rowId;
  const sw=document.getElementById('sw-'+rowId);
  if(sw)sw.classList.add('drag-over');
  const di=document.getElementById('di-'+rowId);
  if(di)di.classList.add('show');
}
function onRowDragLeave(e,rowId){
  const sw=document.getElementById('sw-'+rowId);
  if(sw&&!sw.contains(e.relatedTarget)){
    sw.classList.remove('drag-over');
    const di=document.getElementById('di-'+rowId);
    if(di)di.classList.remove('show');
    if(dragOverRowId===rowId)dragOverRowId=null;
  }
}
function onRowDrop(e,targetRowId){
  e.preventDefault();
  if(!dragRowId||dragRowId===targetRowId)return;
  const fromIdx=rows.findIndex(r=>r.id===dragRowId);
  const toIdx=rows.findIndex(r=>r.id===targetRowId);
  if(fromIdx<0||toIdx<0)return;
  const [moved]=rows.splice(fromIdx,1);
  rows.splice(toIdx,0,moved);
  dragRowId=null; dragOverRowId=null;
  renderAll();
  toast('↕ 섹션 순서 변경됨');
}
function onRowDragEnd(e){
  clearRowDragOver();
  document.querySelectorAll('.sec-wrap.dragging').forEach(el=>el.classList.remove('dragging'));
  document.querySelectorAll('.drag-indicator.show').forEach(el=>el.classList.remove('show'));
  dragRowId=null; dragOverRowId=null;
}
function clearRowDragOver(){
  document.querySelectorAll('.sec-wrap.drag-over').forEach(el=>el.classList.remove('drag-over'));
}

/* ═══ 블록 드래그앤드롭 ═══ */
let dragBlk=null; // {blockId, rowId, colIdx, blockIdx}
function onBlkDragStart(e,bid,rid,ci,bi){
  syncAll();
  dragBlk={blockId:bid,rowId:rid,colIdx:ci,blockIdx:bi};
  setTimeout(()=>{const c=document.getElementById('bc-'+bid);if(c)c.classList.add('blk-dragging');},0);
  e.dataTransfer.effectAllowed='move';
  e.dataTransfer.setData('text/plain','blk:'+bid);
  e.stopPropagation();
}
function onBlkDragOver(e,bid){
  if(!dragBlk||dragBlk.blockId===bid)return;
  e.preventDefault(); e.stopPropagation();
  document.querySelectorAll('.block-card.blk-drag-over').forEach(el=>{if(el.id!=='bc-'+bid)el.classList.remove('blk-drag-over');});
  const c=document.getElementById('bc-'+bid);if(c)c.classList.add('blk-drag-over');
}
function onBlkDragLeave(e,bid){
  const c=document.getElementById('bc-'+bid);
  if(c&&!c.contains(e.relatedTarget))c.classList.remove('blk-drag-over');
}
function onBlkDrop(e,targetBid,targetRid,targetCi,targetBi){
  e.preventDefault(); e.stopPropagation();
  if(!dragBlk||dragBlk.blockId===targetBid)return;
  // 소스에서 블록 꺼내기
  const srcRow=rows.find(r=>r.id===dragBlk.rowId);
  if(!srcRow)return;
  const srcCol=srcRow.columns[dragBlk.colIdx];
  const srcBi=srcCol.blocks.findIndex(b=>b.id===dragBlk.blockId);
  if(srcBi<0)return;
  const [movedBlk]=srcCol.blocks.splice(srcBi,1);
  // 대상에 삽입
  const tgtRow=rows.find(r=>r.id===targetRid);
  if(!tgtRow)return;
  const tgtCol=tgtRow.columns[targetCi];
  const tgtBi=tgtCol.blocks.findIndex(b=>b.id===targetBid);
  tgtCol.blocks.splice(tgtBi,0,movedBlk);
  dragBlk=null;
  renderAll();
  toast('↕ 블록 순서 변경됨');
}
function onBlkDragEnd(e){
  document.querySelectorAll('.block-card.blk-dragging').forEach(el=>el.classList.remove('blk-dragging'));
  document.querySelectorAll('.block-card.blk-drag-over').forEach(el=>el.classList.remove('blk-drag-over'));
  dragBlk=null;
}

function renderAll(){
  const canvas=document.getElementById('canvas');
  document.getElementById('empty-hint').style.display=rows.length===0?'flex':'none'; if(rows.length===0)document.getElementById('empty-hint').style.flexDirection='column';
  canvas.querySelectorAll('.sec-wrap').forEach(el=>el.remove());
  const ba=document.getElementById('bottom-add');
  rows.forEach((row,ri)=>{
    const wrap=document.createElement('div');
    wrap.className='sec-wrap'; wrap.id='sw-'+row.id;
    wrap.innerHTML=`<div class="drag-indicator" id="di-${row.id}"></div>
      ${renderRowH(row,ri)}
      <div class="add-zone" id="az-${row.id}"><div class="add-line"></div>
      <button class="add-btn" onclick="openPicker({afterRowId:'${row.id}'})">＋ 추가</button>
      <div class="add-line"></div></div>`;
    canvas.insertBefore(wrap,ba);
  });
  ba.querySelector('.add-btn').onclick=()=>openPicker(null);
  rows.forEach((row,ri)=>row.columns.forEach((col,ci)=>col.blocks.forEach((b,bi)=>bindB(b,row.id,ci,bi))));
  if(selB){const c=document.getElementById('bc-'+selB.blockId);if(c)c.classList.add('sel');}
}
function renderRowH(row,ri){
  const ll=LAYOUTS.find(l=>l.cols===row.cols)||{label:row.cols+'단'};
  const slb=row.colSpans.map(s=>`<span style="flex:${s}"></span>`).join('');
  const cols=row.columns.map((col,ci)=>{
    const sp=row.colSpans[ci]||Math.floor(12/row.cols);
    const bh=col.blocks.length===0?`<div class="col-empty">비어 있음</div>`:
      col.blocks.map((b,bi)=>renderBH(b,row.id,ci,bi)).join('');
    return `<div class="sec-col" id="col-${row.id}-${ci}" style="flex:${sp}">${bh}
      <button class="col-add" onclick="openPicker({rowId:'${row.id}',colIdx:${ci},afterIdx:${col.blocks.length-1}})">＋ 블록 추가</button></div>`;
  }).join('');
  return `<div class="sec-card" id="sc-${row.id}"
    draggable="true"
    ondragstart="onRowDragStart(event,'${row.id}')"
    ondragover="onRowDragOver(event,'${row.id}')"
    ondragleave="onRowDragLeave(event,'${row.id}')"
    ondrop="onRowDrop(event,'${row.id}')"
    ondragend="onRowDragEnd(event)">
    <div class="sec-head">
      <div class="drag-handle" title="드래그하여 순서 변경">⠿⠿</div>
      <div class="slb">${slb}</div>
      <span class="sec-lbl">${ll.label} 섹션${row.sectionId?' · #'+row.sectionId:''}</span>
      <div class="sec-acts">
        <button class="sa del" onclick="event.stopPropagation();if(confirm('섹션 삭제?'))delRow('${row.id}')">🗑</button>
      </div></div>
    <div class="sec-body">${cols}</div></div>`;
}
function renderBH(block,rowId,ci,bi){
  const bt=BT.find(t=>t.type===block.type)||{label:block.type,bg:'#eee',fg:'#555'};
  const d=block.data,s=d.style||{};
  const ist=`font-size:${s.fontSize||15}px;font-weight:${s.fontWeight||400};text-align:${s.textAlign||'left'};color:${s.color||'#1a1a2e'};line-height:${s.lineHeight||1.7}`;
  let body='';
  switch(block.type){
    case 'h2':body=`<div class="b-h2" contenteditable="true" id="ce-${block.id}" data-ph="대제목 입력..." style="${ist}">${d.text||''}</div>
      <div class="b-anc"><label>📌 목차 ID</label><input id="anc-${block.id}" value="${d.sectionId||''}" placeholder="예: dental-implant" oninput="setSId('${block.id}','${rowId}',this.value)"><span class="b-toc-tip">목차 연동</span></div>`;break;
    case 'h3':body=`<div class="b-h3" contenteditable="true" id="ce-${block.id}" data-ph="소제목 입력..." style="${ist}">${d.text||''}</div>`;break;
    case 'h4':body=`<div class="b-h4" contenteditable="true" id="ce-${block.id}" data-ph="소소제목 입력..." style="${ist}">${d.text||''}</div>`;break;
    case 'paragraph':body=`<div contenteditable="true" id="ce-${block.id}" data-ph="본문을 입력하세요..." style="${ist}">${d.text||''}</div>`;break;
    case 'quote':body=`<div class="b-qt"><div contenteditable="true" id="ce-${block.id}" data-ph="인용문 입력..." style="${ist}">${d.text||''}</div></div>`;break;
    case 'image':body=d.url
      ?`<img class="b-iprev" src="${d.url}" alt="${d.alt||''}" style="border-radius:${d.borderRadius||6}px"><input class="b-ialt" id="alt-${block.id}" value="${d.alt||''}" placeholder="이미지 설명(alt)" oninput="setD('${block.id}','alt',this.value)"><button class="b-la" onclick="trigUp('${block.id}')">🔄 교체</button><input type="file" id="upf-${block.id}" accept="image/*" style="display:none" onchange="doUp('${block.id}',this)">`
      :`<div class="b-idrop" onclick="trigUp('${block.id}')"><div style="font-size:22px">🖼️</div><div>클릭하여 이미지 업로드</div></div><input type="file" id="upf-${block.id}" accept="image/*" style="display:none" onchange="doUp('${block.id}',this)">`;break;
    case 'list':body=`<ul class="b-ul" id="lst-${block.id}">${(d.items||['']).map((it,i)=>`<li><div contenteditable="true" id="li-${block.id}-${i}" data-ph="항목..." style="${ist}">${it}</div></li>`).join('')}</ul><button class="b-la" onclick="addLi('${block.id}','${rowId}',${ci},${bi})">+ 항목 추가</button>`;break;
    case 'warning':body=`<div class="b-wn"><div class="b-wn-t" contenteditable="true" id="wt-${block.id}" data-ph="제목">${d.title||''}</div><div contenteditable="true" id="wb-${block.id}" data-ph="내용 입력..." style="font-size:13px;color:#555;line-height:1.7">${d.text||''}</div></div>`;break;
    case 'delimiter':body=`<hr class="b-dl">`;break;
    case 'table':body=`<div class="b-tbl"><table id="tbl-${block.id}">${(d.rows||[]).map((r,ri)=>`<tr>${r.map((c,ci2)=>`<td><div contenteditable="true" id="td-${block.id}-${ri}-${ci2}">${c}</div></td>`).join('')}</tr>`).join('')}</table></div><div class="tbl-btns"><button class="tbl-btn" onclick="tblR('${block.id}','a')">+ 행</button><button class="tbl-btn" onclick="tblC('${block.id}')">+ 열</button><button class="tbl-btn" onclick="tblR('${block.id}','d')">− 행</button></div>`;break;
    case 'button':body=`<div style="padding:2px 0"><div class="b-btn-el"><div contenteditable="true" id="ce-${block.id}" data-ph="버튼 텍스트">${d.text||'버튼 텍스트'}</div></div></div><div style="display:flex;align-items:center;gap:6px;margin-top:6px"><label style="font-size:9px;color:#8090b0;white-space:nowrap">링크</label><input style="flex:1;padding:3px 7px;border:1px solid var(--cbd);border-radius:4px;font-size:10px;font-family:inherit;outline:none" id="bh-${block.id}" value="${d.href||'#'}" oninput="setD('${block.id}','href',this.value)"></div>`;break;
    case 'faq':body=`<div class="faq-edit">${(d.items||[{q:'',a:''}]).map((item,i)=>`<div class="faq-item-e" id="faqitem-${block.id}-${i}"><div class="faq-q-lbl">Q${i+1}</div><div contenteditable="true" class="faq-q-inp" id="fq-${block.id}-${i}" data-ph="질문을 입력하세요">${item.q||''}</div><div contenteditable="true" class="faq-a-inp" id="fa-${block.id}-${i}" data-ph="답변을 입력하세요">${item.a||''}</div><button class="faq-del-btn" onclick="event.stopPropagation();delFaqItem('${block.id}',${i},'${rowId}',${ci},${bi})">− 삭제</button></div>`).join('')}<button class="b-la" onclick="event.stopPropagation();addFaqItem('${block.id}','${rowId}',${ci},${bi})">＋ 질문 추가</button></div>`;break;
  }
  return `<div class="block-card bt-${block.type}" id="bc-${block.id}"
    draggable="true"
    onclick="selBlock('${block.id}','${rowId}',${ci},${bi})"
    ondragstart="onBlkDragStart(event,'${block.id}','${rowId}',${ci},${bi})"
    ondragover="onBlkDragOver(event,'${block.id}')"
    ondragleave="onBlkDragLeave(event,'${block.id}')"
    ondrop="onBlkDrop(event,'${block.id}','${rowId}',${ci},${bi})"
    ondragend="onBlkDragEnd(event)">
    <div class="bk-hd">
      <div class="bk-drag" title="드래그하여 순서 변경">⠿⠿</div>
      <div class="bk-dot" style="background:${bt.fg}"></div>
      <span class="bk-nm">${bt.label}</span>
      <div class="bk-acts">
        <button class="ba" onclick="event.stopPropagation();dupB('${block.id}','${rowId}',${ci},${bi})" title="복제">⧉</button>
        <button class="ba del" onclick="event.stopPropagation();if(confirm('삭제?'))delB('${block.id}','${rowId}',${ci})" title="삭제">🗑</button>
      </div></div>
    <div class="bk-bd" id="bb-${block.id}">${body}</div></div>`;
}
function bindB(block,rowId,ci,bi){
  const d=block.data;
  const ce=document.getElementById('ce-'+block.id);
  if(ce){ce.addEventListener('input',()=>d.text=ce.innerHTML);
    if(['h2','h3','h4'].includes(block.type))ce.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();const row=rows.find(r=>r.id===rowId);if(row){row.columns[ci].blocks.splice(bi+1,0,mkBlock('paragraph'));renderAll();}}});}
  const wt=document.getElementById('wt-'+block.id);const wb=document.getElementById('wb-'+block.id);
  if(wt)wt.addEventListener('input',()=>d.title=wt.innerHTML);
  if(wb)wb.addEventListener('input',()=>d.text=wb.innerHTML);
  if(block.type==='list')(d.items||[]).forEach((_,i)=>{const li=document.getElementById('li-'+block.id+'-'+i);if(li)li.addEventListener('input',()=>d.items[i]=li.innerHTML);});
  if(block.type==='table')(d.rows||[]).forEach((r,ri)=>r.forEach((_,tci)=>{const td=document.getElementById('td-'+block.id+'-'+ri+'-'+tci);if(td)td.addEventListener('input',()=>d.rows[ri][tci]=td.innerHTML);}));
  if(block.type==='faq')(d.items||[]).forEach((_,i)=>{
    const fq=document.getElementById('fq-'+block.id+'-'+i);
    const fa=document.getElementById('fa-'+block.id+'-'+i);
    if(fq)fq.addEventListener('input',()=>d.items[i].q=fq.innerHTML);
    if(fa)fa.addEventListener('input',()=>d.items[i].a=fa.innerHTML);
  });
}
function mvRow(id,dir){const i=rows.findIndex(r=>r.id===id);if(i<0)return;const ni=i+dir;if(ni<0||ni>=rows.length)return;[rows[i],rows[ni]]=[rows[ni],rows[i]];renderAll();}
function delRow(id){rows=rows.filter(r=>r.id!==id);if(selB&&!findB(selB.blockId)){selB=null;rpEm();}renderAll();}
function mvB(bid,rid,ci,dir){const row=rows.find(r=>r.id===rid);if(!row)return;const col=row.columns[ci];const i=col.blocks.findIndex(b=>b.id===bid);if(i<0)return;const ni=i+dir;if(ni<0||ni>=col.blocks.length)return;[col.blocks[i],col.blocks[ni]]=[col.blocks[ni],col.blocks[i]];renderAll();}
function delB(bid,rid,ci){const row=rows.find(r=>r.id===rid);if(!row)return;row.columns[ci].blocks=row.columns[ci].blocks.filter(b=>b.id!==bid);if(selB?.blockId===bid){selB=null;rpEm();}renderAll();}
function dupB(bid,rid,ci,bi){const row=rows.find(r=>r.id===rid);if(!row)return;const copy=JSON.parse(JSON.stringify(row.columns[ci].blocks[bi]));copy.id=uid();row.columns[ci].blocks.splice(bi+1,0,copy);renderAll();}
function addLi(bid,rid,ci,bi){const row=rows.find(r=>r.id===rid);if(!row)return;const block=row.columns[ci].blocks[bi];if(!block)return;block.data.items.push('');renderAll();setTimeout(()=>{const el=document.getElementById('li-'+bid+'-'+(block.data.items.length-1));if(el)el.focus();},30);}
function tblR(bid,act){const b=findB(bid);if(!b)return;if(act==='a'){const cols=(b.data.rows[0]||[]).length||2;b.data.rows.push(Array(cols).fill(''));}else if(b.data.rows.length>1)b.data.rows.pop();renderAll();}
function tblC(bid){const b=findB(bid);if(!b)return;b.data.rows=b.data.rows.map(r=>[...r,'']);renderAll();}
function addFaqItem(bid,rid,ci,bi){const row=rows.find(r=>r.id===rid);if(!row)return;const block=row.columns[ci].blocks[bi];if(!block)return;block.data.items.push({q:'',a:''});renderAll();}
function delFaqItem(bid,itemIdx,rid,ci,bi){const row=rows.find(r=>r.id===rid);if(!row)return;const block=row.columns[ci].blocks[bi];if(!block)return;if(block.data.items.length<=1){toast('⚠️ 최소 1개 이상 필요합니다');return;}block.data.items.splice(itemIdx,1);renderAll();}
function findB(id){for(const row of rows)for(const col of row.columns)for(const b of col.blocks)if(b.id===id)return b;return null;}
function setD(bid,key,val){const b=findB(bid);if(b)b.data[key]=val;}
function setSId(bid,rid,val){
  const clean=val.replace(/[^a-z0-9\-_가-힣]/gi,'').toLowerCase();
  const b=findB(bid);if(b)b.data.sectionId=clean;
  const row=rows.find(r=>r.id===rid);if(row)row.sectionId=clean;
  const inp=document.getElementById('anc-'+bid);if(inp&&inp.value!==clean)inp.value=clean;
  const lbl=document.querySelector('#sc-'+rid+' .sec-lbl');if(lbl&&row)lbl.textContent=(LAYOUTS.find(l=>l.cols===row.cols)||{label:row.cols+'단'}).label+' 섹션'+(clean?' · #'+clean:'');
}
function selBlock(bid,rid,ci,bi){
  selB={blockId:bid,rowId:rid,colIdx:ci,blockIdx:bi};
  document.querySelectorAll('.block-card').forEach(el=>el.classList.remove('sel'));
  const c=document.getElementById('bc-'+bid);if(c)c.classList.add('sel');
  const b=findB(bid);if(b)showRP(b);
}
function rpEm(){document.getElementById('rp-badge').textContent='—';document.getElementById('rp-bd').innerHTML='<div class="rp-em"><div class="rp-em-ic">🖱️</div><p>블록을 클릭하면<br>속성이 표시됩니다</p></div>';}
function showRP(block){
  const bt=BT.find(t=>t.type===block.type)||{};
  document.getElementById('rp-badge').textContent=bt.label||block.type;
  const d=block.data,s=d.style||{};
  const hs=['paragraph','h2','h3','h4','quote','list','button'].includes(block.type);
  let h='';
  if(hs){
    h+=`<div class="rp-s"><div class="rp-st">텍스트</div>
      <div class="rp-r"><span class="rp-l">크기</span><input type="number" class="rp-n" value="${s.fontSize||15}" min="10" max="72" oninput="apS('${block.id}','fontSize',parseInt(this.value)||15)"><span style="font-size:9px;color:var(--tx3)">px</span></div>
      <div class="rp-r"><span class="rp-l">굵기</span><div class="rp-wg">${[400,600,700,800].map(w=>`<button class="rp-wb${(s.fontWeight||400)==w?' on':''}" onclick="apS('${block.id}','fontWeight',${w});this.closest('.rp-wg').querySelectorAll('.rp-wb').forEach(b=>b.classList.remove('on'));this.classList.add('on')">${w}</button>`).join('')}</div></div>
      <div class="rp-r"><span class="rp-l">정렬</span><div class="rp-ag">${[['left','◀'],['center','●'],['right','▶']].map(([v,i])=>`<button class="rp-ab${(s.textAlign||'left')===v?' on':''}" onclick="apS('${block.id}','textAlign','${v}');this.closest('.rp-ag').querySelectorAll('.rp-ab').forEach(b=>b.classList.remove('on'));this.classList.add('on')">${i}</button>`).join('')}</div></div>
      <div class="rp-r"><span class="rp-l">색상</span><div class="rp-cw"><div class="rp-sw" style="background:${s.color||'#1a1a2e'}"><input type="color" value="${s.color||'#1a1a2e'}" oninput="apS('${block.id}','color',this.value);this.closest('.rp-sw').style.background=this.value;this.closest('.rp-cw').querySelector('.rp-hx').value=this.value"></div><input type="text" class="rp-hx" value="${s.color||'#1a1a2e'}" maxlength="7" oninput="if(/^#[0-9a-fA-F]{6}$/.test(this.value)){apS('${block.id}','color',this.value);this.previousElementSibling.style.background=this.value}"></div></div>
      <div class="rp-r"><span class="rp-l">줄간격</span><select class="rp-sel" onchange="apS('${block.id}','lineHeight',parseFloat(this.value))">${[1.2,1.4,1.5,1.6,1.7,1.75,1.8,2.0].map(v=>`<option value="${v}"${(s.lineHeight||1.7)==v?' selected':''}>${v}</option>`).join('')}</select></div></div>`;
  }
  if(block.type==='image')h+=`<div class="rp-s"><div class="rp-st">이미지</div><div class="rp-r"><span class="rp-l">모서리</span><input type="number" class="rp-n" value="${d.borderRadius||6}" min="0" max="50" oninput="setD('${block.id}','borderRadius',parseInt(this.value)||0);const img=document.querySelector('#bc-${block.id} .b-iprev');if(img)img.style.borderRadius=this.value+'px'"><span style="font-size:9px;color:var(--tx3)">px</span></div><button class="rp-ab2" onclick="trigUp('${block.id}')">🖼 이미지 업로드/교체</button></div>`;
  h+=`<div class="rp-s"><div class="rp-st">작업</div><button class="rp-ab2" onclick="if(selB){dupB(selB.blockId,selB.rowId,selB.colIdx,selB.blockIdx)}">⧉ 복제</button><button class="rp-ab2 danger" onclick="if(selB&&confirm('삭제?')){delB(selB.blockId,selB.rowId,selB.colIdx)}">🗑 삭제</button></div>`;
  document.getElementById('rp-bd').innerHTML=h;
}
function apS(bid,prop,val){const b=findB(bid);if(!b)return;b.data.style=b.data.style||{};b.data.style[prop]=val;const ce=document.getElementById('ce-'+bid);if(!ce)return;if(prop==='fontSize')ce.style.fontSize=val+'px';else ce.style[prop]=val;}
function trigUp(id){document.getElementById('upf-'+id)?.click();}
async function doUp(id,input){
  if(!input.files[0])return;const b=findB(id);if(!b)return;
  toast('📤 업로드 중...');const fd=new FormData();fd.append('image',input.files[0]);
  try{const res=await fetch(UPLOAD_URL,{method:'POST',body:fd});const data=await res.json();
    if(data.uploaded&&data.url){b.data.url=data.url;renderAll();if(selB?.blockId===id){showRP(b);}toast('✅ 업로드 완료');}
    else toast('❌ 업로드 실패');}catch(e){toast('❌ 오류: '+e.message);}
}
function syncAll(){
  rows.forEach(row=>row.columns.forEach((col,ci)=>col.blocks.forEach((block,bi)=>{
    const d=block.data;
    const ce=document.getElementById('ce-'+block.id);if(ce)d.text=ce.innerHTML;
    const wt=document.getElementById('wt-'+block.id);if(wt)d.title=wt.innerHTML;
    const wb=document.getElementById('wb-'+block.id);if(wb)d.text=wb.innerHTML;
    if(block.type==='list')d.items=(d.items||[]).map((_,i)=>{const el=document.getElementById('li-'+block.id+'-'+i);return el?el.innerHTML:_;});
    if(block.type==='table')(d.rows||[]).forEach((r,ri)=>r.forEach((_,tci)=>{const el=document.getElementById('td-'+block.id+'-'+ri+'-'+tci);if(el)d.rows[ri][tci]=el.innerHTML;}));
    if(block.type==='faq')d.items=(d.items||[]).map((_,i)=>{const fq=document.getElementById('fq-'+block.id+'-'+i);const fa=document.getElementById('fa-'+block.id+'-'+i);return{q:fq?fq.innerHTML:_.q,a:fa?fa.innerHTML:_.a};});
    if(block.type==='h2'&&!d.sectionId&&d.text){const sl=d.text.replace(/<[^>]+>/g,'').trim().toLowerCase().replace(/\s+/g,'-').replace(/[^a-z0-9가-힣\-_]/g,'').slice(0,40);if(sl){d.sectionId=sl;row.sectionId=sl;}}
  })));
}
function toJson(){return JSON.stringify({rows:rows.map(row=>({id:'row-'+row.id,sectionId:row.sectionId||'',cols:row.cols,columns:row.columns.map((col,ci)=>({span:row.colSpans[ci]||Math.floor(12/row.cols),blocks:col.blocks}))}))});}
function doSave(){
  const title=document.getElementById('tb_title').value.trim();
  if(!title){toast('⚠️ 제목을 입력해주세요');document.getElementById('tb_title').focus();return;}
  if(rows.length===0){toast('⚠️ 블록을 하나 이상 추가해주세요');return;}
  syncAll();
  document.getElementById('f_title').value=title;
  document.getElementById('f_cat').value=document.getElementById('tb_cat').value;
  document.getElementById('f_content').value=toJson();
  document.getElementById('fwrite').submit();
}
function doPreview(){
  syncAll();const data=JSON.parse(toJson());
  const toc=data.rows.filter(r=>r.sectionId).map(r=>{const h2=r.columns.flatMap(c=>c.blocks).find(b=>b.type==='h2');return{id:r.sectionId,label:h2?.data?.text?.replace(/<[^>]+>/g,'')||r.sectionId};});
  let html=`<!DOCTYPE html><html><head><meta charset="UTF-8"><title>미리보기</title><style>*{box-sizing:border-box;margin:0;padding:0}body{font-family:sans-serif;color:#1a1a2e;background:#f5f7fa}.layout{display:flex;max-width:1060px;margin:0 auto;padding:48px 24px;gap:48px}aside{width:200px;flex-shrink:0;position:sticky;top:24px;align-self:flex-start;background:#fff;border-radius:10px;padding:16px;border:1px solid #e1e4e8}aside h4{font-size:11px;font-weight:700;color:#25456b;margin-bottom:10px;padding-bottom:8px;border-bottom:1px solid #eef1f6}aside ul{list-style:none;display:flex;flex-direction:column;gap:2px}aside li a{display:block;font-size:12px;color:#374151;text-decoration:none;padding:4px 8px;border-radius:5px}aside li a:hover{background:#f0f4ff;color:#25456b}article{flex:1;min-width:0}.pb-row{display:flex;flex-wrap:wrap;gap:20px;margin-bottom:24px}.pb-col{flex:1;min-width:0}${[1,2,3,4,5,6,7,8,9,10,11,12].map(n=>`.pb-col-${n}{flex:${n}}`).join('')}h2{font-size:20px;font-weight:800;color:#25456b;margin:36px 0 14px;padding-bottom:10px;border-bottom:2px solid #4a7ab5;display:flex;align-items:center;gap:10px}h2::before{content:'';display:block;width:4px;min-width:4px;height:20px;background:#25456b;border-radius:2px;flex-shrink:0}h3{font-size:16px;font-weight:700;color:#1a1a2e;margin:24px 0 10px}h4{font-size:14px;font-weight:700;color:#333;margin:16px 0 8px}p{font-size:15px;line-height:1.85;color:#333;margin-bottom:14px}blockquote{border-left:3px solid #99b5d7;background:#f8fbff;padding:12px 16px;border-radius:0 6px 6px 0;margin:16px 0;font-style:italic;color:#25456b}.warning{background:#fffbf0;border:1.5px solid #fabe00;border-radius:8px;padding:14px;margin:16px 0}.warning strong{font-size:11px;font-weight:800;color:#dd9700;display:block;margin-bottom:6px}hr{border:none;border-top:1px solid #e8e4de;margin:32px 0}ul{padding-left:22px;margin-bottom:14px}li{font-size:15px;line-height:1.75;margin-bottom:4px}table{width:100%;border-collapse:collapse;margin:16px 0;font-size:13px}td,th{border:1.5px solid #e5e7eb;padding:8px 12px}th{background:#25456b;color:#fabe00;font-weight:700}img{max-width:100%;border-radius:6px;margin:16px 0;display:block}.pb-btn{display:inline-flex;padding:10px 22px;border-radius:8px;background:linear-gradient(135deg,#000136,#25456b);color:#fff;font-weight:700;text-decoration:none;font-size:14px}.pb-faq{display:flex;flex-direction:column;gap:0;border:1.5px solid #e8eaf0;border-radius:10px;overflow:hidden;margin:16px 0}.pb-faq-item{border-bottom:1px solid #e8eaf0}.pb-faq-item:last-child{border-bottom:none}.pb-faq-q{list-style:none;padding:14px 16px;font-size:15px;font-weight:600;color:#1a1a2e;cursor:pointer;display:flex;align-items:center;justify-content:space-between;gap:10px;user-select:none}.pb-faq-q::after{content:'＋';font-size:14px;color:#8090b0;flex-shrink:0;transition:transform .2s}.pb-faq-item[open] .pb-faq-q::after{content:'－'}.pb-faq-a{padding:0 16px 14px;font-size:14px;line-height:1.75;color:#555}@media(max-width:768px){.layout{flex-direction:column}aside{width:100%;position:static}.pb-row{flex-direction:column}[class*=pb-col-]{flex:0 0 100%!important}}</style></head><body><div class="layout">`;
  if(toc.length)html+=`<aside><h4>목차</h4><ul>${toc.map(t=>`<li><a href="#${t.id}">${t.label}</a></li>`).join('')}</ul></aside>`;
  html+=`<article>`;
  data.rows.forEach(row=>{const ia=row.sectionId?` id="${row.sectionId}"`:' ';html+=`<div class="pb-row"${ia}>`;row.columns.forEach(col=>{html+=`<div class="pb-col pb-col-${col.span}">`;col.blocks.forEach(b=>{const d=b.data||{};switch(b.type){case 'h2':html+=`<h2>${d.text||''}</h2>`;break;case 'h3':html+=`<h3>${d.text||''}</h3>`;break;case 'h4':html+=`<h4>${d.text||''}</h4>`;break;case 'paragraph':html+=`<p>${d.text||''}</p>`;break;case 'quote':html+=`<blockquote>${d.text||''}</blockquote>`;break;case 'image':if(d.url){html+=`<figure style="margin:16px 0"><img src="${d.url}" alt="${d.alt||''}" style="max-width:100%;border-radius:${d.borderRadius||6}px;display:block">${d.alt?`<figcaption style="font-size:12px;color:#8090b0;text-align:center;margin-top:6px;font-style:italic">${d.alt}</figcaption>`:''}</figure>`;}break;case 'list':html+=`<ul>${(d.items||[]).map(it=>`<li>${it}</li>`).join('')}</ul>`;break;case 'warning':html+=`<div class="warning"><strong>${d.title||''}</strong><p>${d.text||''}</p></div>`;break;case 'delimiter':html+=`<hr>`;break;case 'table':if(d.rows)html+=`<table>${d.rows.map((r,ri)=>`<tr>${r.map(c=>ri===0?`<th>${c}</th>`:`<td>${c}</td>`).join('')}</tr>`).join('')}</table>`;break;case 'button':html+=`<a class="pb-btn" href="${d.href||'#'}">${d.text||'버튼'}</a>`;break;case 'faq':if(d.items)html+=`<div class="pb-faq">${d.items.map(item=>`<details class="pb-faq-item"><summary class="pb-faq-q">${item.q||''}</summary><div class="pb-faq-a">${item.a||''}</div></details>`).join('')}</div>`;break;}});html+=`</div>`;});html+=`</div>`;});
  html+=`</article></div></body></html>`;const w=window.open('','_blank');w.document.write(html);w.document.close();
}
let tT;function toast(msg){const t=document.getElementById('toast');document.getElementById('toast-msg').textContent=msg;t.classList.add('show');clearTimeout(tT);tT=setTimeout(()=>t.classList.remove('show'),2000);}
document.addEventListener('keydown',e=>{if(e.key==='Escape')closePicker();if((e.metaKey||e.ctrlKey)&&e.key==='s'){e.preventDefault();doSave();}});
// 썸네일 초기화
let thumbnailUrl = <?= json_encode($existing_thumbnail ?? '') ?>;
(function initThumbnail(){
  if(thumbnailUrl) setTnPreview(thumbnailUrl);
})();

function toggleThumbnail(){
  const panel=document.getElementById('tn-panel');
  const overlay=document.getElementById('tn-overlay');
  const btn=document.getElementById('tn-toggle-btn');
  const isOpen=panel.classList.contains('open');
  if(isOpen){closeThumbnail();}
  else{panel.classList.add('open');overlay.classList.add('open');btn.classList.add('tn-active');}
}
function closeThumbnail(){
  document.getElementById('tn-panel').classList.remove('open');
  document.getElementById('tn-overlay').classList.remove('open');
  document.getElementById('tn-toggle-btn').classList.remove('tn-active');
}
function trigTnUpload(){document.getElementById('tn-file').click();}
async function doTnUpload(input){
  if(!input.files[0])return;
  toast('📤 썸네일 업로드 중...');
  const fd=new FormData();fd.append('image',input.files[0]);
  try{
    const res=await fetch(UPLOAD_URL,{method:'POST',body:fd});
    const data=await res.json();
    if(data.uploaded&&data.url){setTnPreview(data.url);toast('✅ 썸네일 설정 완료');}
    else toast('❌ 업로드 실패');
  }catch(e){toast('❌ 오류: '+e.message);}
  input.value='';
}
function setTnPreview(url){
  thumbnailUrl=url;
  document.getElementById('f_thumbnail').value=url;
  const img=document.getElementById('tn-img');
  const ph=document.getElementById('tn-placeholder');
  const del=document.getElementById('tn-del-btn');
  const disp=document.getElementById('tn-url-display');
  img.src=url; img.style.display='block'; ph.style.display='none';
  del.style.display=''; disp.textContent=url;
  document.getElementById('tn-toggle-btn').style.outline='2px solid var(--ac)';
}
function removeThumbnail(){
  thumbnailUrl='';
  document.getElementById('f_thumbnail').value='';
  const img=document.getElementById('tn-img');
  const ph=document.getElementById('tn-placeholder');
  const del=document.getElementById('tn-del-btn');
  const disp=document.getElementById('tn-url-display');
  img.src=''; img.style.display='none'; ph.style.display='flex';
  del.style.display='none'; disp.textContent='미설정';
  document.getElementById('tn-toggle-btn').style.outline='';
  toast('🗑 썸네일 제거됨');
}

renderAll();
</script>
</body>
</html>