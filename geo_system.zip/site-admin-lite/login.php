<?php
require_once __DIR__ . '/inc/db.php';
require_once __DIR__ . '/inc/auth.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $u = trim($_POST['username'] ?? '');
    $p = (string)($_POST['password'] ?? '');

    $row = sql_fetch("SELECT * FROM admin_users WHERE username = '" . sql_real_escape_string($u) . "' LIMIT 1");

    if ($row && !empty($row['password_hash']) && password_verify($p, $row['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['sal_admin_id']   = $row['username'];
        $_SESSION['sal_admin_name'] = $row['username'];
        $redirect = isset($_GET['url']) && $_GET['url'] !== '' ? $_GET['url'] : './index.php';
        header('Location: ' . $redirect);
        exit;
    }
    $error = '아이디 또는 비밀번호가 올바르지 않습니다.';
}

// 관리자 계정이 하나도 없으면 설치가 안 된 것 — 안내
$has_admin = sql_fetch("SELECT COUNT(*) as cnt FROM admin_users");
$need_install = empty($has_admin['cnt']);
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>관리자 로그인</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0;font-family:-apple-system,'Pretendard',sans-serif}
  body{min-height:100vh;display:flex;align-items:center;justify-content:center;background:#f3f4f6}
  .box{width:340px;background:#fff;border-radius:16px;box-shadow:0 8px 30px rgba(0,0,0,.08);padding:36px}
  h1{font-size:18px;font-weight:800;margin-bottom:24px;color:#111827}
  label{display:block;font-size:13px;font-weight:600;color:#374151;margin-bottom:6px}
  input{width:100%;padding:11px 12px;border:1px solid #d1d5db;border-radius:8px;font-size:14px;margin-bottom:16px;outline:none}
  input:focus{border-color:#2563eb}
  button{width:100%;padding:12px;border:none;border-radius:8px;background:#2563eb;color:#fff;font-weight:700;font-size:14px;cursor:pointer}
  button:hover{background:#1d4ed8}
  .err{background:#fef2f2;color:#dc2626;font-size:13px;padding:10px 12px;border-radius:8px;margin-bottom:16px}
  .warn{background:#fffbeb;color:#b45309;font-size:12.5px;padding:10px 12px;border-radius:8px;margin-bottom:16px;line-height:1.5}
  .warn a{color:#b45309;font-weight:700}
</style>
</head>
<body>
  <div class="box">
    <h1>사이트 관리자 로그인</h1>
    <?php if ($need_install): ?>
      <div class="warn">관리자 계정이 아직 없습니다. 먼저 <a href="./install.php">install.php</a>에서 초기 설정을 진행하세요.</div>
    <?php endif; ?>
    <?php if ($error): ?><div class="err"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <form method="post">
      <label>아이디</label>
      <input type="text" name="username" autocomplete="username" required autofocus>
      <label>비밀번호</label>
      <input type="password" name="password" autocomplete="current-password" required>
      <button type="submit">로그인</button>
    </form>
  </div>
</body>
</html>
