<?php
/**
 * reset.php — site-admin-lite가 만든 테이블만 전부 삭제하고 처음 상태로 되돌린다.
 * 기존 사이트(g5_*, md_* 등 원본 테이블)는 절대 건드리지 않는다 — 아래 목록 외 어떤 것도 DROP하지 않음.
 * 실행 후 install.php를 다시 열면 새로 설치할 수 있다.
 */
require_once __DIR__ . '/inc/db.php';

// site-admin-lite 소유 테이블만 — 이 목록 밖은 절대 건드리지 않는다
$owned_tables = ['admin_users', 'dm_config', 'dm_page_seo', 'sal_column', 'sal_column_cat', 'sal_case', 'sal_case_cat'];

$exists = [];
foreach ($owned_tables as $t) {
    $r = mysqli_query($connect_db, "SHOW TABLES LIKE '{$t}'");
    if ($r && mysqli_num_rows($r) > 0) $exists[] = $t;
}

$done = false;
$err  = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (trim($_POST['confirm'] ?? '') !== '초기화') {
        $err = '확인 문구가 정확하지 않습니다. "초기화"라고 정확히 입력해주세요.';
    } else {
        foreach ($exists as $t) {
            mysqli_query($connect_db, "DROP TABLE IF EXISTS `{$t}`");
        }
        $done = true;
    }
}
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>DB 초기화</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0;font-family:-apple-system,'Pretendard',sans-serif}
  body{min-height:100vh;display:flex;align-items:center;justify-content:center;background:#f3f4f6}
  .box{width:460px;background:#fff;border-radius:16px;box-shadow:0 8px 30px rgba(0,0,0,.08);padding:36px}
  h1{font-size:18px;font-weight:800;margin-bottom:8px;color:#111827}
  p.sub{font-size:13px;color:#6b7280;margin-bottom:18px;line-height:1.6}
  .warn{background:#fef2f2;border:1px solid #fecaca;color:#b91c1c;font-size:12.5px;padding:14px 16px;
    border-radius:10px;margin-bottom:18px;line-height:1.7}
  .tlist{background:#f9fafb;border:1px solid #e5e7eb;border-radius:10px;padding:12px 14px;margin-bottom:18px;
    font-size:12.5px;color:#374151}
  .tlist code{background:#eef2ff;color:#4338ca;padding:2px 6px;border-radius:5px;font-size:11.5px;margin:2px 2px 2px 0;display:inline-block}
  label{display:block;font-size:13px;font-weight:600;color:#374151;margin-bottom:6px}
  input{width:100%;padding:11px 12px;border:1px solid #d1d5db;border-radius:8px;font-size:14px;margin-bottom:16px;outline:none}
  button{width:100%;padding:12px;border:none;border-radius:8px;background:#dc2626;color:#fff;font-weight:700;font-size:14px;cursor:pointer}
  .ok{background:#ecfdf5;color:#047857;font-size:13px;padding:14px 16px;border-radius:8px;line-height:1.7}
  .err{background:#fef2f2;color:#dc2626;font-size:13px;padding:10px 12px;border-radius:8px;margin-bottom:16px}
  a.btn{display:inline-block;margin-top:16px;color:#2563eb;font-weight:700;font-size:13px;text-decoration:none}
</style>
</head>
<body>
  <div class="box">
    <h1>site-admin-lite DB 초기화</h1>
    <?php if ($done): ?>
      <div class="ok">초기화 완료. site-admin-lite가 만든 테이블 <?= count($exists) ?>개를 전부 삭제했습니다.<br>
      기존 사이트 원본 테이블(그누보드/Medis 등)은 건드리지 않았습니다.</div>
      <a class="btn" href="./install.php">install.php에서 새로 설치하기 →</a>
    <?php else: ?>
      <p class="sub">이 사이트에 이미 설치되어 있던 site-admin-lite 데이터를 전부 지우고 처음 상태로 되돌립니다.</p>
      <div class="warn">⚠️ 되돌릴 수 없습니다. 칼럼·임상케이스·SEO 설정·관리자 계정이 전부 삭제됩니다.<br>
      기존 사이트의 원본 테이블(그누보드 g5_*, Medis md_* 등)은 목록에 없으므로 삭제되지 않습니다.</div>
      <div class="tlist">
        삭제 대상 (<?= count($exists) ?>개 존재):
        <?php if (!$exists): ?><br><span style="color:#9ca3af">삭제할 테이블이 없습니다 — 이미 초기 상태입니다.</span>
        <?php else: foreach ($exists as $t): ?><code><?= htmlspecialchars($t) ?></code><?php endforeach; endif; ?>
      </div>
      <?php if ($err): ?><div class="err"><?= htmlspecialchars($err) ?></div><?php endif; ?>
      <?php if ($exists): ?>
      <form method="post">
        <label>계속하려면 <b>초기화</b> 라고 입력하세요</label>
        <input type="text" name="confirm" autocomplete="off" autofocus placeholder="초기화">
        <button type="submit">전부 삭제하고 초기화</button>
      </form>
      <?php else: ?>
        <a class="btn" href="./install.php">install.php로 이동 →</a>
      <?php endif; ?>
    <?php endif; ?>
  </div>
</body>
</html>
